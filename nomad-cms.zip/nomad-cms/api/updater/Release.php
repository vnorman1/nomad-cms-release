<?php
/**
 * NOMAD CMS — signed release and ZIP contract.
 * Authenticates exact manifest bytes before trusting package hashes. ZIP entries
 * are checked against an authenticated inventory before any live code is touched.
 */
declare(strict_types=1);

namespace NomadUpdate;

final class Release
{
    public static function semver(mixed $value): bool
    {
        return is_string($value) && strlen($value) < 100
            && preg_match('~^(?:0|[1-9]\d*)\.(?:0|[1-9]\d*)\.(?:0|[1-9]\d*)(?:-[0-9A-Za-z.-]+)?$~D', $value) === 1;
    }

    public static function verify(string $bytes, string $signature, array $keys): array
    {
        if (strlen($bytes) > 2097152 || strlen($signature) > 16384) {
            throw new UpdateException('MANIFEST_LIMIT', 'Release manifest exceeds size limit.');
        }
        $envelope = json_decode($signature, true, 8, JSON_THROW_ON_ERROR);
        $id = $envelope['key_id'] ?? null;
        $raw = isset($envelope['signature']) && is_string($envelope['signature']) ? base64_decode($envelope['signature'], true) : false;
        if (!is_string($id) || !isset($keys[$id]) || $raw === false) {
            throw new UpdateException('UNTRUSTED_SIGNER', 'Release signer is not trusted for this source.');
        }
        $key = openssl_pkey_get_public($keys[$id]);
        $details = $key === false ? false : openssl_pkey_get_details($key);
        if ($details === false || $details['type'] !== OPENSSL_KEYTYPE_RSA || $details['bits'] < 4096
            || openssl_verify($bytes, $raw, $key, OPENSSL_ALGO_SHA256) !== 1) {
            throw new UpdateException('INVALID_SIGNATURE', 'Release signature verification failed.');
        }
        $release = json_decode($bytes, true, 32, JSON_THROW_ON_ERROR);
        self::validate($release);
        if (($release['key_id'] ?? null) !== $id) {
            throw new UpdateException('INVALID_SIGNATURE', 'Release signer identity mismatch.');
        }
        return $release;
    }

    public static function validate(mixed $release): void
    {
        if (!is_array($release) || ($release['format'] ?? null) !== 'nomad-release/v1'
            || ($release['product'] ?? null) !== 'nomad-cms'
            || !self::semver($release['version'] ?? null)
            || !self::semver($release['min_upgrade_version'] ?? null)
            || !self::semver($release['min_rollback_version'] ?? null)
            || !is_string($release['build_id'] ?? null) || strlen($release['build_id']) > 100
            || !is_int($release['storage_epoch'] ?? null)
            || !is_bool($release['manual_upgrade'] ?? null)
            || !is_string($release['min_php'] ?? null)
            || !is_int($release['updater_protocol'] ?? null)) {
            throw new UpdateException('INVALID_RELEASE', 'Invalid release contract.');
        }
        foreach (['sha256', 'manifest_sha256'] as $field) {
            if (!is_string($release['archive'][$field] ?? null) || !preg_match('~^[a-f0-9]{64}$~D', $release['archive'][$field])) {
                throw new UpdateException('INVALID_RELEASE', 'Missing package digest.');
            }
        }
        foreach (['size' => Files::MAX_ARCHIVE, 'unpacked_size' => Files::MAX_UNPACKED, 'file_count' => Files::MAX_FILES] as $field => $max) {
            if (!is_int($release['archive'][$field] ?? null) || $release['archive'][$field] < 1 || $release['archive'][$field] > $max) {
                throw new UpdateException('PACKAGE_LIMIT', 'Invalid package bounds.');
            }
        }
        if (!is_string($release['archive']['name'] ?? null) || !preg_match('~^[A-Za-z0-9._-]+\.zip$~D', $release['archive']['name'])) {
            throw new UpdateException('INVALID_RELEASE', 'Invalid package asset name.');
        }
        if (isset($release['migrations']) && (!is_array($release['migrations']) || count($release['migrations']) > 100)) {
            throw new UpdateException('INVALID_RELEASE', 'Invalid migration plan.');
        }
        foreach ($release['migrations'] ?? [] as $migration) {
            if (!is_array($migration) || !is_string($migration['id'] ?? null)
                || !preg_match('~^[a-zA-Z0-9._-]{1,100}$~D', $migration['id'])
                || !in_array($migration['database'] ?? '', ['auth', 'content', 'massive', 'schema'], true)
                || !is_string($migration['file'] ?? null) || !Files::managed($migration['file'])
                || !str_starts_with($migration['file'], 'api/integrations/update-migrations/')
                || ($migration['backward_compatible'] ?? false) !== true) {
                throw new UpdateException('INVALID_MIGRATION', 'Only explicit backward-compatible migrations are supported.');
            }
        }
    }

    public static function compatibility(array $release, array $current, array $storage = []): ?string
    {
        if ($release['updater_protocol'] !== 1) {
            return 'This release requires a bootstrap upgrade.';
        }
        if ($release['manual_upgrade']) {
            return 'This release requires a manual storage migration.';
        }
        if (version_compare(PHP_VERSION, $release['min_php'], '<')) {
            return 'PHP ' . $release['min_php'] . ' or newer is required.';
        }
        if (version_compare($current['version'], $release['min_upgrade_version'], '<')) {
            return 'Upgrade to ' . $release['min_upgrade_version'] . ' first.';
        }
        if ($release['storage_epoch'] !== ($storage['epoch'] ?? $current['storageEpoch'] ?? 1)) {
            return 'The release is incompatible with the current storage format.';
        }
        $floor = $storage['rollback_floor'] ?? $current['minRollbackVersion'] ?? '1.0.0';
        if (version_compare($release['version'], $floor, '<')) {
            return 'The current storage requires CMS ' . $floor . ' or newer.';
        }
        if (version_compare($current['version'], $release['min_rollback_version'], '<')) {
            return 'The release cannot safely restore the current code on failure.';
        }
        return null;
    }

    public static function inspectArchive(string $path, array $release, bool $local = false): array
    {
        if (!is_file($path) || filesize($path) !== $release['archive']['size']
            || !hash_equals($release['archive']['sha256'], hash_file('sha256', $path))) {
            throw new UpdateException('ARCHIVE_HASH', 'Package size or SHA-256 verification failed.');
        }
        $zip = new \ZipArchive();
        if ($zip->open($path, \ZipArchive::RDONLY | \ZipArchive::CHECKCONS) !== true) {
            throw new UpdateException('INVALID_ZIP', 'Invalid ZIP archive.');
        }
        try {
            $prefix = 'nomad-cms/';
            $stat = $zip->statName($prefix . 'package-manifest.json');
            if ($stat === false || $stat['size'] > 4194304) {
                throw new UpdateException('INVALID_ZIP', 'Package inventory is missing or oversized.');
            }
            $bytes = $zip->getFromName($prefix . 'package-manifest.json');
            if (!is_string($bytes) || !hash_equals($release['archive']['manifest_sha256'], hash('sha256', $bytes))) {
                throw new UpdateException('MANIFEST_HASH', 'Package inventory digest mismatch.');
            }
            $inventory = json_decode($bytes, true, 32, JSON_THROW_ON_ERROR);
            $files = $inventory['files'] ?? null;
            if (($inventory['format'] ?? '') !== 'nomad-package/v1' || !is_array($files) || count($files) > Files::MAX_FILES
                || count($files) !== $release['archive']['file_count']) {
                throw new UpdateException('INVALID_ZIP', 'Invalid package inventory.');
            }
            $total = 0;
            foreach ($files as $name => $file) {
                $kind = $file['kind'] ?? 'code';
                if (!is_string($name) || !is_array($file)
                    || ($kind === 'code' ? !Files::managed($name) : ($local || !Files::installOnly($name)))
                    || !in_array($kind, ['code', 'bootstrap'], true)
                    || !is_int($file['size'] ?? null) || $file['size'] < 0 || $file['size'] > Files::MAX_FILE
                    || !is_string($file['sha256'] ?? null) || !preg_match('~^[a-f0-9]{64}$~D', $file['sha256'])) {
                    throw new UpdateException('UNSAFE_PACKAGE', 'Package contains a forbidden file.');
                }
                $total += $file['size'];
            }
            if ($total !== $release['archive']['unpacked_size'] || $total > Files::MAX_UNPACKED) {
                throw new UpdateException('PACKAGE_LIMIT', 'Unpacked package size mismatch.');
            }
            $seen = [];
            $actual = [];
            if ($zip->numFiles > Files::MAX_FILES + 4000) {
                throw new UpdateException('PACKAGE_LIMIT', 'Too many ZIP entries.');
            }
            for ($i = 0; $i < $zip->numFiles; $i++) {
                $entry = $zip->statIndex($i);
                $name = $entry['name'];
                $canonical = strtolower(rtrim($name, '/'));
                if (isset($seen[$canonical]) || !Files::relative(rtrim($name, '/')) || !str_starts_with($name, $prefix)) {
                    throw new UpdateException('UNSAFE_ZIP', 'Duplicate or unsafe ZIP path.');
                }
                $seen[$canonical] = true;
                $zip->getExternalAttributesIndex($i, $opsys, $attributes);
                $type = ($attributes >> 16) & 0170000;
                if ($opsys === \ZipArchive::OPSYS_UNIX && !in_array($type, [0, 0100000, 0040000], true)) {
                    throw new UpdateException('UNSAFE_ZIP', 'ZIP links and special files are forbidden.');
                }
                if (str_ends_with($name, '/')) {
                    continue;
                }
                $relative = substr($name, strlen($prefix));
                if ($relative === 'package-manifest.json') {
                    continue;
                }
                if (!isset($files[$relative]) || $entry['size'] !== $files[$relative]['size'] || ($entry['encryption_method'] ?? 0) !== 0) {
                    throw new UpdateException('UNSAFE_ZIP', 'Unexpected, encrypted or incorrectly sized ZIP entry.');
                }
                $actual[$relative] = true;
            }
            if (count($actual) !== count($files)) {
                throw new UpdateException('INVALID_ZIP', 'ZIP inventory is incomplete.');
            }
            return $files;
        } finally {
            $zip->close();
        }
    }

    /** Each extraction writes one verified file; cursors are persisted by callers. */
    public static function extractOne(\ZipArchive $zip, string $root, string $name, array $file): void
    {
        $path = Files::target($root, $name);
        Files::directory(dirname($path));
        $input = $zip->getStream('nomad-cms/' . $name);
        $output = fopen($path . '.part', 'wb');
        if ($input === false || $output === false) {
            throw new UpdateException('EXTRACTION_FAILED', 'Cannot open package entry.', 500);
        }
        $hash = hash_init('sha256');
        $size = 0;
        try {
            while (!feof($input)) {
                $bytes = fread($input, 65536);
                if ($bytes === false || ($bytes === '' && !feof($input))) {
                    throw new UpdateException('EXTRACTION_FAILED', 'Cannot read ZIP entry.', 500);
                }
                $size += strlen($bytes);
                if ($size > $file['size'] || fwrite($output, $bytes) !== strlen($bytes)) {
                    throw new UpdateException('EXTRACTION_FAILED', 'Package size or write validation failed.', 500);
                }
                hash_update($hash, $bytes);
            }
        } finally {
            fclose($input);
            fclose($output);
        }
        if ($size !== $file['size'] || !hash_equals($file['sha256'], hash_final($hash))) {
            throw new UpdateException('ENTRY_HASH', 'Package entry checksum mismatch.');
        }
        if (str_ends_with($name, '.php')) {
            token_get_all((string) file_get_contents($path . '.part'), TOKEN_PARSE);
        }
        chmod($path . '.part', 0644);
        if (!rename($path . '.part', $path)) {
            throw new UpdateException('EXTRACTION_FAILED', 'Cannot finalize extracted entry.', 500);
        }
    }
}
