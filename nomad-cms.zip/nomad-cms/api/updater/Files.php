<?php
/**
 * NOMAD CMS — immutable update filesystem primitives.
 * Keeps package ownership separate from persistent customer data and bootstrap
 * infrastructure. Every live mutation is path checked and atomically renamed.
 */
declare(strict_types=1);

namespace NomadUpdate;

final class UpdateException extends \RuntimeException
{
    public function __construct(public readonly string $errorCode, string $message, int $status = 400)
    {
        parent::__construct($message, $status);
    }
}

final class Files
{
    public const MAX_FILES = 12000;
    public const MAX_FILE = 33554432;
    public const MAX_UNPACKED = 268435456;
    public const MAX_ARCHIVE = 67108864;

    public static function json(string $path, array $default = []): array
    {
        if (!is_file($path)) {
            return $default;
        }
        if (is_link($path) || filesize($path) > 4194304) {
            throw new UpdateException('INVALID_STATE', 'Unsafe or oversized state file.', 500);
        }
        $data = json_decode((string) file_get_contents($path), true, 64, JSON_THROW_ON_ERROR);
        if (!is_array($data)) {
            throw new UpdateException('INVALID_STATE', 'Invalid state document.', 500);
        }
        return $data;
    }

    public static function writeJson(string $path, array $data): void
    {
        self::write($path, json_encode($data, JSON_THROW_ON_ERROR | JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES) . "\n");
    }

    public static function write(string $path, string $bytes, int $mode = 0600): void
    {
        self::directory(dirname($path));
        if (is_link($path)) {
            throw new UpdateException('UNSAFE_PATH', 'Symlink destinations are forbidden.');
        }
        $tmp = $path . '.tmp-' . bin2hex(random_bytes(6));
        $handle = fopen($tmp, 'xb');
        if ($handle === false) {
            throw new UpdateException('WRITE_FAILED', 'Cannot create temporary file.', 500);
        }
        try {
            chmod($tmp, $mode);
            $offset = 0;
            while ($offset < strlen($bytes)) {
                $written = fwrite($handle, substr($bytes, $offset, 65536));
                if ($written === false || $written === 0) {
                    throw new UpdateException('WRITE_FAILED', 'Cannot persist file.', 500);
                }
                $offset += $written;
            }
            fflush($handle);
            if (function_exists('fsync') && !fsync($handle)) {
                throw new UpdateException('WRITE_FAILED', 'Cannot synchronize file.', 500);
            }
        } finally {
            fclose($handle);
        }
        if (!rename($tmp, $path)) {
            @unlink($tmp);
            throw new UpdateException('WRITE_FAILED', 'Cannot atomically replace file.', 500);
        }
    }

    public static function directory(string $path, int $mode = 0700): void
    {
        if (is_link($path)) {
            throw new UpdateException('UNSAFE_PATH', 'Symlink directories are forbidden.');
        }
        if (!is_dir($path)) {
            if (dirname($path) !== $path) {
                self::directory(dirname($path), $mode);
            }
            if (!mkdir($path, $mode) && !is_dir($path)) {
                throw new UpdateException('WRITE_FAILED', 'Cannot create update directory.', 500);
            }
        }
    }

    public static function relative(string $path): bool
    {
        return $path !== '' && strlen($path) <= 512 && !preg_match('~[\\\\:\x00-\x1f\x7f]~', $path)
            && !str_starts_with($path, '/') && !preg_match('~(^|/)(\.|\.\.|)(/|$)~', $path);
    }

    public static function managed(string $path): bool
    {
        if (!self::relative($path) || str_contains($path, '/.') || str_starts_with($path, '.')) {
            return false;
        }
        if (preg_match('~^api/vendor/lbuchs/webauthn/_test/rootCertificates/[A-Za-z0-9_-]+\.pem$~D', $path)) {
            return true; // Public attestation certificates, never customer keys.
        }
        if (preg_match('~(?:\.(?:sqlite|db)(?:[.-]|$)|\.(?:lock|log|pem|key)$|\.env(?:\.|$))~i', $path)) {
            return false;
        }
        if (in_array($path, ['version.json', 'sitemap.xsl', 'api/bootstrap.php', 'api/index.php', 'api/router.php', 'api/notification-integrations.php', 'api/composer.json', 'api/composer.lock'], true)) {
            return true;
        }
        return (bool) preg_match('~^(?:nomad/(?:assets/|fonts/|index\.html$|[^/]+\.(?:ico|png|svg|webmanifest)$)|api/(?:src|endpoints|vendor|integrations|lib|bin|analytics|external|f|scripts)/)~', $path);
    }

    public static function installOnly(string $path): bool
    {
        return in_array($path, ['.htaccess', 'api/.htaccess', 'api/update-guard.php', 'api/rescue.php', 'api/data/.htaccess', 'api/databases/.htaccess', 'api/src/.htaccess', 'api/lib/.htaccess', 'api/f/.htaccess', 'api/external/.htaccess', 'api/static/.htaccess', 'api/storage/updates/.htaccess', 'api/nomad-update.php', 'api/updater/install-defaults/nomad.schema.json'], true)
            || (self::relative($path) && str_starts_with($path, 'api/updater/'));
    }

    public static function target(string $root, string $relative): string
    {
        if (!self::relative($relative)) {
            throw new UpdateException('UNSAFE_PATH', 'Invalid relative path.');
        }
        $path = rtrim($root, '/');
        foreach (explode('/', $relative) as $part) {
            $path .= '/' . $part;
            if (is_link($path)) {
                throw new UpdateException('UNSAFE_PATH', 'Symlink paths are forbidden.');
            }
        }
        return $path;
    }

    /** Scan only explicit code roots; mutable paths never enter a code backup. */
    public static function inventory(string $root, bool $includeVendor = true): array
    {
        $files = [];
        $roots = ['version.json', 'sitemap.xsl', 'api/bootstrap.php', 'api/index.php', 'api/router.php', 'api/notification-integrations.php', 'api/composer.json', 'api/composer.lock', 'nomad', 'api/src', 'api/endpoints', 'api/vendor', 'api/integrations', 'api/lib', 'api/bin', 'api/analytics', 'api/external', 'api/f', 'api/scripts'];
        foreach ($roots as $relative) {
            if (!$includeVendor && $relative === 'api/vendor') {
                continue;
            }
            $path = self::target($root, $relative);
            if (is_file($path)) {
                $items = [$path];
            } elseif (is_dir($path)) {
                $items = new \RecursiveIteratorIterator(new \RecursiveDirectoryIterator($path, \FilesystemIterator::SKIP_DOTS));
            } else {
                continue;
            }
            foreach ($items as $item) {
                $full = (string) $item;
                $name = substr($full, strlen(rtrim($root, '/')) + 1);
                if (is_link($full)) {
                    throw new UpdateException('UNSAFE_PATH', 'Code contains a symlink: ' . $name);
                }
                if (!self::managed($name)) {
                    continue;
                }
                self::target($root, $name);
                $size = filesize($full);
                if ($size === false || $size > self::MAX_FILE || count($files) >= self::MAX_FILES) {
                    throw new UpdateException('PACKAGE_LIMIT', 'Code exceeds update limits.');
                }
                $files[$name] = ['size' => $size, 'sha256' => hash_file('sha256', $full)];
            }
        }
        ksort($files);
        if (array_sum(array_column($files, 'size')) > self::MAX_UNPACKED) {
            throw new UpdateException('PACKAGE_LIMIT', 'Code exceeds unpacked size limit.');
        }
        return $files;
    }

    /** Removal is confined to an owned operation directory, never a live tree. */
    public static function removeTree(string $path): void
    {
        if (is_link($path)) {
            unlink($path);
        } elseif (is_dir($path)) {
            foreach (new \FilesystemIterator($path, \FilesystemIterator::SKIP_DOTS) as $item) {
                self::removeTree($item->getPathname());
            }
            if (!rmdir($path)) {
                throw new UpdateException('CLEANUP_FAILED', 'Cannot remove temporary directory.', 500);
            }
        } elseif (is_file($path) && !unlink($path)) {
            throw new UpdateException('CLEANUP_FAILED', 'Cannot remove temporary file.', 500);
        }
    }
}
