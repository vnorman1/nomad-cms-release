<?php
/**
 * NOMAD CMS — early application request and CLI maintenance guard.
 * Executes before Composer. Shared locks allow a cutover to drain existing
 * requests; persistent maintenance state prevents new requests entering code.
 */
declare(strict_types=1);

if (!defined('NOMAD_UPDATE_PROBE') && empty($GLOBALS['nomad_update_application_lock'])) {
    $nomadUpdateRoot = dirname(__DIR__, 2);
    $nomadUpdatePath = $nomadUpdateRoot . '/api/storage/updates';
    if (is_file($nomadUpdatePath . '/maintenance.json')) {
        require_once __DIR__ . '/load.php';
        if (PHP_SAPI === 'cli') {
            fwrite(STDERR, "NOMAD CMS update maintenance is active; worker skipped.\n");
            exit(75);
        }
        \NomadUpdate\Controller::dispatch($nomadUpdateRoot);
    }
    if (!is_dir($nomadUpdatePath)) {
        mkdir($nomadUpdatePath, 0700, true);
    }
    $nomadUpdateLock = fopen($nomadUpdatePath . '/application.lock', 'c');
    if ($nomadUpdateLock === false || !flock($nomadUpdateLock, LOCK_SH)) {
        http_response_code(503);
        exit('NOMAD CMS is temporarily unavailable.');
    }
    // Check again after locking: maintenance may have started while waiting.
    if (is_file($nomadUpdatePath . '/maintenance.json')) {
        flock($nomadUpdateLock, LOCK_UN);
        fclose($nomadUpdateLock);
        if (PHP_SAPI === 'cli') {
            exit(75);
        }
        require_once __DIR__ . '/load.php';
        \NomadUpdate\Controller::dispatch($nomadUpdateRoot);
    }
    $GLOBALS['nomad_update_application_lock'] = $nomadUpdateLock;
}
