<?php
/**
 * NOMAD CMS — independent update runtime loader.
 * Uses a fixed immutable file list; Composer and the live application are not
 * required for downloads, state inspection, maintenance or code recovery.
 */
declare(strict_types=1);

require_once __DIR__ . '/Files.php';
require_once __DIR__ . '/Http.php';
require_once __DIR__ . '/Release.php';
require_once __DIR__ . '/Store.php';
require_once __DIR__ . '/Engine.php';
require_once __DIR__ . '/Controller.php';
