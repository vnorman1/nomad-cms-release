<?php
/**
 * NOMAD CMS — bounded HTTPS transport for signed software packages.
 * Resolves and pins public addresses on every redirect, scopes bearer credentials
 * to one origin, streams bytes to disk and checkpoints ranged downloads.
 */
declare(strict_types=1);

namespace NomadUpdate;

final class Http
{
    /** The injectable transport exists for isolated tests, never HTTP input. */
    public function __construct(private readonly ?\Closure $transport = null)
    {
    }

    public static function publicIp(string $ip): bool
    {
        if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) === false) {
            return false;
        }
        if (str_contains($ip, ':')) {
            $packed = inet_pton($ip);
            // Only globally routed unicast IPv6; excludes mapped IPv4, NAT64,
            // local multicast and transition tunnels which can reach private IPv4.
            // Special-purpose/documentation prefixes follow the IANA registry:
            // https://www.iana.org/assignments/iana-ipv6-special-registry/
            return $packed !== false && (ord($packed[0]) & 0xe0) === 0x20
                && substr($packed, 0, 2) !== "\x20\x02"
                && !(substr($packed, 0, 2) === "\x20\x01" && (ord($packed[2]) & 0xfe) === 0)
                && substr($packed, 0, 4) !== "\x20\x01\x0d\xb8"
                && !(substr($packed, 0, 2) === "\x3f\xff" && (ord($packed[2]) & 0xf0) === 0);
        }
        return (int) explode('.', $ip)[0] < 224
            && !preg_match('~^(?:0\.|100\.(?:6[4-9]|[78][0-9]|9[0-9]|1[01][0-9]|12[0-7])\.|192\.0\.(?:0|2)\.|192\.88\.99\.|198\.(?:18|19)\.|198\.51\.100\.|203\.0\.113\.)~', $ip);
    }

    public static function origin(string $url): string
    {
        $parts = parse_url($url);
        if (!is_array($parts) || ($parts['scheme'] ?? '') !== 'https'
            || !isset($parts['host']) || isset($parts['user']) || isset($parts['pass'])
            || isset($parts['fragment']) || (isset($parts['port']) && $parts['port'] !== 443)
            || !preg_match('~^[a-zA-Z0-9.-]{1,253}$~', $parts['host'])
            || preg_match('~[\x00-\x20\x7f\\\\]~', $url)) {
            throw new UpdateException('INVALID_URL', 'A public HTTPS URL on port 443 is required.');
        }
        return 'https://' . strtolower($parts['host']);
    }

    private function resolve(string $url): array
    {
        self::origin($url);
        $host = (string) parse_url($url, PHP_URL_HOST);
        if (filter_var($host, FILTER_VALIDATE_IP)) {
            $addresses = [$host];
        } else {
            $records = dns_get_record($host, DNS_A | DNS_AAAA);
            $addresses = [];
            foreach ($records ?: [] as $record) {
                if (isset($record['ip']) || isset($record['ipv6'])) {
                    $addresses[] = $record['ip'] ?? $record['ipv6'];
                }
            }
        }
        if ($addresses === []) {
            throw new UpdateException('DNS_FAILED', 'Update source DNS resolution failed.', 502);
        }
        foreach ($addresses as $ip) {
            if (!self::publicIp($ip)) {
                throw new UpdateException('SSRF_BLOCKED', 'The update source resolves to a non-public address.');
            }
        }
        return [$host, $addresses[0]];
    }

    public function bytes(string $url, ?array $credential = null, array $headers = [], int $limit = 2097152): array
    {
        if ($this->transport !== null) {
            return ($this->transport)('bytes', $url, $credential, $headers, $limit);
        }
        $tmp = tmpfile();
        if ($tmp === false) {
            throw new UpdateException('WRITE_FAILED', 'Cannot create HTTP spool.', 500);
        }
        try {
            $result = $this->request($url, $tmp, 0, $limit, $credential, $headers, false);
            rewind($tmp);
            $result['body'] = stream_get_contents($tmp);
            return $result;
        } finally {
            fclose($tmp);
        }
    }

    public function download(string $url, string $path, int $expected, ?array $credential = null): bool
    {
        if ($expected < 1 || $expected > Files::MAX_ARCHIVE) {
            throw new UpdateException('PACKAGE_LIMIT', 'Invalid archive size.');
        }
        if ($this->transport !== null) {
            return ($this->transport)('download', $url, $path, $expected, $credential);
        }
        $offset = is_file($path) ? filesize($path) : 0;
        if ($offset === $expected) {
            return true;
        }
        if ($offset > $expected || is_link($path)) {
            throw new UpdateException('INVALID_DOWNLOAD', 'Invalid download checkpoint.');
        }
        Files::directory(dirname($path));
        $out = fopen($path, 'ab');
        if ($out === false) {
            throw new UpdateException('WRITE_FAILED', 'Cannot open download.', 500);
        }
        try {
            $this->request($url, $out, $offset, $expected, $credential, [], true);
        } finally {
            fclose($out);
        }
        clearstatcache(true, $path);
        return filesize($path) === $expected;
    }

    private function request(string $url, $out, int $offset, int $limit, ?array $credential, array $extra, bool $resumable): array
    {
        for ($redirect = 0; $redirect <= 5; $redirect++) {
            [$host, $ip] = $this->resolve($url);
            $headers = ['User-Agent: NomadCMS/1 (+https://github.com/vnorman1/nomad-cms-release)', 'Accept: application/vnd.github+json', 'X-GitHub-Api-Version: 2026-03-10'];
            foreach ($extra as $name => $value) {
                if (!in_array(strtolower($name), ['if-none-match', 'accept'], true) || preg_match('~[\r\n]~', (string) $value)) {
                    throw new UpdateException('INVALID_HEADER', 'Unsupported HTTP header.');
                }
                $headers[] = $name . ': ' . $value;
            }
            if ($credential !== null && self::origin($url) === $credential['origin']) {
                if (preg_match('~[\r\n]~', $credential['token'])) {
                    throw new UpdateException('INVALID_TOKEN', 'Invalid source credential.');
                }
                $headers[] = 'Authorization: Bearer ' . $credential['token'];
            }
            $response = [];
            $status = 0;
            $written = 0;
            $overflow = false;
            $writeFailed = false;
            $rangeInvalid = false;
            $start = microtime(true);
            $curl = curl_init($url);
            curl_setopt_array($curl, [
                CURLOPT_FOLLOWLOCATION => false,
                CURLOPT_PROTOCOLS => CURLPROTO_HTTPS,
                CURLOPT_PROXY => '',
                CURLOPT_CONNECTTIMEOUT_MS => 2500,
                CURLOPT_TIMEOUT_MS => 4500,
                CURLOPT_SSL_VERIFYPEER => true,
                CURLOPT_SSL_VERIFYHOST => 2,
                CURLOPT_HTTPHEADER => $headers,
                CURLOPT_RESOLVE => [$host . ':443:' . (str_contains($ip, ':') ? '[' . $ip . ']' : $ip)],
                CURLOPT_HEADERFUNCTION => static function ($curl, string $line) use (&$response, &$status): int {
                    if (preg_match('~^HTTP/\S+ (\d+)~', $line, $m)) {
                        $status = (int) $m[1];
                        $response = [];
                    } elseif (str_contains($line, ':')) {
                        [$name, $value] = explode(':', $line, 2);
                        $response[strtolower(trim($name))] = trim($value);
                    }
                    return strlen($line);
                },
                CURLOPT_WRITEFUNCTION => static function ($curl, string $bytes) use ($out, $offset, $limit, $resumable, &$response, &$status, &$written, &$overflow, &$writeFailed, &$rangeInvalid): int {
                    if ($status < 200 || $status >= 300) {
                        return strlen($bytes);
                    }
                    if ($resumable && ($offset > 0 || $status === 206)
                        && ($status !== 206 || !preg_match('~^bytes ' . $offset . '-\d+/' . $limit . '$~', $response['content-range'] ?? ''))) {
                        $rangeInvalid = true;
                        return 0;
                    }
                    if ($offset + $written + strlen($bytes) > $limit) {
                        $overflow = true;
                        return 0;
                    }
                    $length = fwrite($out, $bytes);
                    if ($length !== strlen($bytes)) {
                        $writeFailed = true;
                        return 0;
                    }
                    $written += $length;
                    return $length;
                },
            ]);
            if ($resumable) {
                curl_setopt($curl, CURLOPT_RANGE, $offset . '-' . min($limit - 1, $offset + 2097151));
            }
            $ok = curl_exec($curl);
            $errno = curl_errno($curl);
            curl_close($curl);
            fflush($out);
            if ($overflow || $writeFailed || $rangeInvalid) {
                throw new UpdateException($rangeInvalid ? 'RANGE_UNSUPPORTED' : 'DOWNLOAD_FAILED', $rangeInvalid ? 'Source does not support a safe ranged download.' : 'Download size or write validation failed.', 502);
            }
            if (in_array($status, [301, 302, 303, 307, 308], true)) {
                $location = $response['location'] ?? '';
                if (str_starts_with($location, '/') && !str_starts_with($location, '//')) {
                    $location = self::origin($url) . $location;
                }
                self::origin($location);
                $url = $location;
                continue;
            }
            if ($status === 403 || $status === 429) {
                $retry = max(60, min(86400, (int) ($response['retry-after'] ?? 60)));
                if (($response['x-ratelimit-remaining'] ?? null) === '0') {
                    $retry = max($retry, (int) ($response['x-ratelimit-reset'] ?? 0) - time());
                }
                throw new UpdateException('RATE_LIMIT:' . $retry, 'Update source temporarily refused the request.', 429);
            }
            if (!in_array($status, [200, 206, 304], true)) {
                throw new UpdateException('SOURCE_HTTP_' . $status, 'Update source returned HTTP ' . $status . '.', 502);
            }
            if ($ok === false && !($resumable && $written > 0 && $errno === CURLE_OPERATION_TIMEDOUT)) {
                throw new UpdateException('NETWORK_FAILED', 'Update source connection failed.', 502);
            }
            return ['status' => $status, 'headers' => $response, 'elapsed' => microtime(true) - $start];
        }
        throw new UpdateException('REDIRECT_LIMIT', 'Too many update source redirects.', 502);
    }
}
