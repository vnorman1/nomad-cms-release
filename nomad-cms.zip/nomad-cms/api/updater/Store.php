<?php
/**
 * NOMAD CMS — durable update control store and source trust.
 * Customer databases are never used for worker state. Capabilities and rescue
 * secrets are hashed; origin-bound source credentials use native AES-GCM.
 */
declare(strict_types=1);

namespace NomadUpdate;

final class Store
{
    public readonly string $path;

    public function __construct(public readonly string $root)
    {
        Files::directory(Files::target($root, 'api'), 0755);
        $this->path = Files::target($root, 'api/storage/updates');
        Files::directory($this->path);
        $deny = "Require all denied\nDeny from all\n";
        if (!is_file($this->path . '/.htaccess')) {
            Files::write($this->path . '/.htaccess', $deny, 0644);
        }
        Files::directory($this->path . '/operations');
        Files::directory($this->path . '/rollback');
    }

    public function current(): array
    {
        return Files::json($this->root . '/version.json', ['version' => '1.0.0', 'buildId' => 'legacy', 'storageEpoch' => 1, 'minRollbackVersion' => '1.0.0']);
    }

    public function settings(): array
    {
        $builtin = Files::json($this->root . '/api/updater/trusted-keys.json');
        return array_replace_recursive([
            'retention_bytes' => 20971520,
            'keys' => [],
            'sources' => ['official' => [
                'id' => 'official', 'name' => 'NOMAD CMS', 'kind' => 'github',
                'repo' => 'vnorman1/nomad-cms-release', 'key_ids' => array_keys($builtin),
            ]],
        ], Files::json($this->path . '/settings.json'));
    }

    public function publicSettings(): array
    {
        $settings = $this->settings();
        foreach ($settings['sources'] as &$source) {
            $source['has_token'] = isset($source['credential']);
            unset($source['credential']);
        }
        unset($source);
        $keys = Files::json($this->root . '/api/updater/trusted-keys.json');
        foreach ($settings['keys'] as $id => $key) {
            $keys[$id] = $key['pem'];
        }
        $builtins = Files::json($this->root . '/api/updater/trusted-keys.json');
        $keyNames = array_map(static fn($key) => $key['name'], $settings['keys']);
        $settings['keys'] = [];
        foreach ($keys as $id => $pem) {
            $settings['keys'][$id] = [
                'name' => isset($builtins[$id]) ? 'NOMAD CMS' : ($keyNames[$id] ?? $id),
                'fingerprint' => hash('sha256', $pem),
                'builtin' => isset($builtins[$id]),
            ];
        }
        $settings['rescue_configured'] = is_file($this->path . '/rescue.json');
        return $settings;
    }

    public function source(string $id): array
    {
        $source = $this->settings()['sources'][$id] ?? null;
        if (!is_array($source)) {
            throw new UpdateException('UNKNOWN_SOURCE', 'Unknown update source.');
        }
        return $source;
    }

    public function keys(array $source): array
    {
        $builtin = Files::json($this->root . '/api/updater/trusted-keys.json');
        $all = $builtin;
        foreach ($this->settings()['keys'] as $id => $key) {
            $all[$id] = $key['pem'];
        }
        return array_intersect_key($all, array_flip($source['key_ids']));
    }

    public function credential(array $source): ?array
    {
        if (!isset($source['credential'])) {
            return null;
        }
        $item = $source['credential'];
        $plain = openssl_decrypt(base64_decode($item['value'], true), 'aes-256-gcm', $this->encryptionKey(), OPENSSL_RAW_DATA, base64_decode($item['iv'], true), base64_decode($item['tag'], true), $item['origin']);
        if ($plain === false) {
            throw new UpdateException('CREDENTIAL_FAILED', 'Cannot decrypt source credential.', 500);
        }
        return ['origin' => $item['origin'], 'token' => $plain];
    }

    private function encryptionKey(): string
    {
        $path = Files::target($this->root, 'api/keys/update-encryption.key');
        if (!is_file($path)) {
            Files::write($path, random_bytes(32));
        }
        $key = file_get_contents($path);
        if ($key === false || strlen($key) !== 32) {
            throw new UpdateException('CREDENTIAL_FAILED', 'Update encryption key is unavailable.', 500);
        }
        return $key;
    }

    public function configure(array $input): array
    {
        return $this->locked(function () use ($input): array {
            if ($this->active() !== null) {
                throw new UpdateException('UPDATE_BUSY', 'Finish or cancel the active operation before changing trust.', 409);
            }
            $settings = $this->settings();
            $action = $input['action'] ?? '';
            if ($action === 'retention') {
                $bytes = $input['bytes'] ?? null;
                if (!is_int($bytes) || $bytes < 20971520 || $bytes > 1073741824) {
                    throw new UpdateException('INVALID_SETTINGS', 'Retention must be between 20 MiB and 1 GiB.');
                }
                $settings['retention_bytes'] = $bytes;
            } elseif ($action === 'add_key') {
                $pem = $input['pem'] ?? null;
                $name = $input['name'] ?? null;
                if (!is_string($pem) || strlen($pem) > 16384 || !is_string($name) || $name === '' || strlen($name) > 100) {
                    throw new UpdateException('INVALID_KEY', 'A name and RSA-4096 public key are required.');
                }
                $key = openssl_pkey_get_public($pem);
                $details = $key === false ? false : openssl_pkey_get_details($key);
                if ($details === false || $details['type'] !== OPENSSL_KEYTYPE_RSA || $details['bits'] < 4096) {
                    throw new UpdateException('INVALID_KEY', 'An RSA public key of at least 4096 bits is required.');
                }
                $pem = $details['key'];
                $id = hash('sha256', $pem);
                $settings['keys'][$id] = ['name' => $name, 'pem' => $pem];
            } elseif ($action === 'remove_key') {
                $id = $input['id'] ?? '';
                if (!is_string($id)) {
                    throw new UpdateException('INVALID_KEY', 'Invalid key identifier.');
                }
                if (isset(Files::json($this->root . '/api/updater/trusted-keys.json')[$id])) {
                    throw new UpdateException('PROTECTED_KEY', 'Built-in publisher keys require a bootstrap upgrade.');
                }
                unset($settings['keys'][$id]);
                foreach ($settings['sources'] as &$source) {
                    if ($source['id'] !== 'official') {
                        $source['key_ids'] = array_values(array_diff($source['key_ids'], [$id]));
                    }
                }
                unset($source);
            } elseif ($action === 'source') {
                $id = $input['id'] ?? '';
                if (!is_string($id) || !preg_match('~^[a-z0-9_-]{1,50}$~D', $id) || $id === 'official') {
                    throw new UpdateException('INVALID_SOURCE', 'Use a unique custom source identifier.');
                }
                $url = $input['manifest_url'] ?? null;
                $keyIds = $input['key_ids'] ?? null;
                if (!is_string($url) || !is_array($keyIds) || $keyIds === [] || count($keyIds) > 20) {
                    throw new UpdateException('INVALID_SOURCE', 'A manifest URL and trusted keys are required.');
                }
                Http::origin($url);
                $known = array_merge(array_keys($settings['keys']), array_keys(Files::json($this->root . '/api/updater/trusted-keys.json')));
                foreach ($keyIds as $keyId) {
                    if (!is_string($keyId) || !in_array($keyId, $known, true)) {
                        throw new UpdateException('INVALID_KEY', 'Unknown source signing key.');
                    }
                }
                $source = ['id' => $id, 'kind' => 'manifest', 'name' => $id, 'manifest_url' => $url, 'key_ids' => array_values(array_unique($keyIds))];
                if (isset($input['zip_url']) && $input['zip_url'] !== '') {
                    if (!is_string($input['zip_url'])) {
                        throw new UpdateException('INVALID_URL', 'Invalid ZIP URL.');
                    }
                    Http::origin($input['zip_url']);
                    $source['zip_url'] = $input['zip_url'];
                }
                if (isset($input['token']) && $input['token'] !== '') {
                    if (!is_string($input['token']) || strlen($input['token']) > 4096 || preg_match('~[\r\n]~', $input['token'])) {
                        throw new UpdateException('INVALID_TOKEN', 'Invalid source bearer token.');
                    }
                    if (isset($input['token_origin']) && !is_string($input['token_origin'])) {
                        throw new UpdateException('INVALID_URL', 'Invalid token origin.');
                    }
                    $origin = Http::origin($input['token_origin'] ?? $url);
                    $iv = random_bytes(12);
                    $value = openssl_encrypt($input['token'], 'aes-256-gcm', $this->encryptionKey(), OPENSSL_RAW_DATA, $iv, $tag, $origin);
                    $source['credential'] = ['origin' => $origin, 'iv' => base64_encode($iv), 'tag' => base64_encode($tag), 'value' => base64_encode($value)];
                }
                $settings['sources'][$id] = $source;
            } elseif ($action === 'remove_source') {
                $id = $input['id'] ?? '';
                if (!is_string($id) || $id === 'official') {
                    throw new UpdateException('INVALID_SOURCE', 'The official source cannot be removed.');
                }
                unset($settings['sources'][$id]);
            } else {
                throw new UpdateException('INVALID_SETTINGS', 'Unknown settings action.');
            }
            Files::writeJson($this->path . '/settings.json', $settings);
            return $this->publicSettings();
        });
    }

    public function active(): ?array
    {
        $pointer = Files::json($this->path . '/active.json');
        $operation = isset($pointer['id']) ? $this->operation($pointer['id']) : null;
        return $operation !== null && !in_array($operation['stage'], ['completed', 'rolled_back', 'failed', 'cancelled'], true)
            ? $operation : null;
    }

    public function operation(string $id): array
    {
        if (!preg_match('~^[a-f0-9]{32}$~D', $id)) {
            throw new UpdateException('INVALID_OPERATION', 'Invalid operation identifier.');
        }
        $data = Files::json($this->path . '/operations/' . $id . '/state.json');
        if ($data === []) {
            throw new UpdateException('UNKNOWN_OPERATION', 'Update operation not found.', 404);
        }
        return $data;
    }

    public function save(array $operation): void
    {
        $operation['updated_at'] = time();
        Files::writeJson($this->path . '/operations/' . $operation['id'] . '/state.json', $operation);
    }

    public function event(array &$operation, string $message): void
    {
        $operation['events'][] = ['id' => count($operation['events']) + 1, 'time' => time(), 'stage' => $operation['stage'], 'message' => $message];
        $operation['events'] = array_slice($operation['events'], -100);
        $this->save($operation);
    }

    public function locked(\Closure $callback): mixed
    {
        $lock = fopen($this->path . '/worker.lock', 'c');
        if ($lock === false || !flock($lock, LOCK_EX | LOCK_NB)) {
            if (is_resource($lock)) {
                fclose($lock);
            }
            throw new UpdateException('UPDATE_BUSY', 'Another update worker is running.', 409);
        }
        try {
            return $callback();
        } finally {
            flock($lock, LOCK_UN);
            fclose($lock);
        }
    }

    public static function publicOperation(?array $operation): ?array
    {
        if ($operation === null) {
            return null;
        }
        return array_intersect_key($operation, array_flip(['id', 'stage', 'kind', 'version', 'cursor', 'total', 'events', 'error', 'updated_at', 'required_free_bytes', 'downloaded_bytes', 'archive_size', 'probe_action']));
    }

    public function rotateRescue(): string
    {
        $token = bin2hex(random_bytes(32));
        Files::writeJson($this->path . '/rescue.json', ['hash' => hash('sha256', $token), 'created_at' => time()]);
        return $token;
    }

    public function verifyRescue(string $token): bool
    {
        return $this->locked(function () use ($token): bool {
            $ratePath = $this->path . '/rescue-rate.json';
            $rate = Files::json($ratePath, ['start' => time(), 'failures' => 0]);
            if (time() - $rate['start'] > 300) {
                $rate = ['start' => time(), 'failures' => 0];
            }
            if ($rate['failures'] >= 5) {
                throw new UpdateException('RESCUE_RATE_LIMIT', 'Wait five minutes before retrying recovery.', 429);
            }
            $hash = Files::json($this->path . '/rescue.json')['hash'] ?? '';
            $valid = strlen($token) === 64 && $hash !== '' && hash_equals($hash, hash('sha256', $token));
            $rate['failures'] += $valid ? 0 : 1;
            Files::writeJson($ratePath, $rate);
            return $valid;
        });
    }
}
