<?php
/**
 * NOMAD CMS — source for the generated single-file web installer.
 * The release builder embeds this and the native verification/HTTP primitives.
 * A locally configured ownership secret protects every step and is carried to
 * the CMS administrator wizard; no application code is needed before deployment.
 */
declare(strict_types=1);

namespace NomadUpdate;

final class Installer
{
    public static function dispatch(string $root, array $builtinKeys, string $script, ?Http $transport = null): never
    {
        try {
            $secret = defined('NOMAD_SETUP_TOKEN') ? NOMAD_SETUP_TOKEN : '';
            if (!is_string($secret) || strlen($secret) < 32) {
                self::page('Set NOMAD_SETUP_TOKEN to a unique secret of at least 32 characters before uploading this file.');
            }
            if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'GET') {
                self::page();
            }
            if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST' || ($_SERVER['HTTP_X_NOMAD_UPDATE'] ?? '') !== '1') {
                throw new UpdateException('METHOD_NOT_ALLOWED', 'Use a same-origin JSON POST.', 405);
            }
            $raw = file_get_contents('php://input', false, null, 0, 65537);
            if ($raw === false || strlen($raw) > 65536) {
                throw new UpdateException('INVALID_INPUT', 'Installer request is too large.');
            }
            $input = json_decode($raw, true, 32, JSON_THROW_ON_ERROR);
            if (!is_array($input)) {
                throw new UpdateException('INVALID_INPUT', 'Installer JSON object required.');
            }
            $private = $root . '/api/storage/updates';
            $statePath = $private . '/setup.json';
            if (is_file($private . '/setup-complete.json') || is_file($root . '/api/nomad-install.lock')) {
                throw new UpdateException('SETUP_DISABLED', 'This installer has already completed.', 403);
            }
            if (($input['action'] ?? '') === 'login') {
                if (!is_string($input['secret'] ?? null) || !hash_equals($secret, $input['secret'])) {
                    throw new UpdateException('SETUP_FORBIDDEN', 'Invalid installation secret.', 403);
                }
                self::preflight($root);
                $state = Files::json($statePath);
                if ($state === []) {
                    foreach (scandir($root) ?: [] as $entry) {
                        if (!in_array($entry, ['.', '..', basename($script)], true)) {
                            throw new UpdateException('NONEMPTY_TARGET', 'Use an empty installation directory.');
                        }
                    }
                    // Protect private state before creating it. The complete,
                    // authenticated web configuration is installed last.
                    Files::write($root . '/.htaccess', "RewriteEngine On\nRewriteRule ^(?:api|nomad)(?:/|$) - [F,L,NC]\n", 0644);
                    $store = new Store($root);
                    $keys = $builtinKeys;
                    if (isset($input['public_key']) && $input['public_key'] !== '') {
                        $key = is_string($input['public_key']) ? openssl_pkey_get_public($input['public_key']) : false;
                        $details = $key === false ? false : openssl_pkey_get_details($key);
                        if ($details === false || $details['type'] !== OPENSSL_KEYTYPE_RSA || $details['bits'] < 4096) {
                            throw new UpdateException('INVALID_KEY', 'Supply an RSA-4096 public key.');
                        }
                        $keys[hash('sha256', $details['key'])] = $details['key'];
                    }
                    $manifest = $input['manifest_url'] ?? '';
                    if (!is_string($manifest)) {
                        throw new UpdateException('INVALID_URL', 'Invalid manifest URL.');
                    }
                    if ($manifest !== '') {
                        Http::origin($manifest);
                    }
                    $zip = $input['zip_url'] ?? '';
                    if (!is_string($zip)) {
                        throw new UpdateException('INVALID_URL', 'Invalid ZIP URL.');
                    }
                    if ($zip !== '') {
                        Http::origin($zip);
                    }
                    $state = ['owner_hash' => hash('sha256', $secret), 'stage' => 'protection', 'cursor' => 0,
                        'keys' => $keys, 'manifest_url' => $manifest, 'zip_url' => $zip,
                        'nonce' => bin2hex(random_bytes(16))];
                    Files::write($private . '/probe-' . $state['nonce'] . '.txt', $state['nonce'], 0644);
                } elseif (!hash_equals($state['owner_hash'], hash('sha256', $secret))) {
                    throw new UpdateException('SETUP_FORBIDDEN', 'This interrupted setup belongs to another installer secret.', 403);
                }
                $claim = bin2hex(random_bytes(32));
                Files::writeJson($private . '/setup-claim.json', ['hash' => hash('sha256', $claim), 'expires' => time() + 86400]);
                setcookie('nomad_setup_claim', $claim, ['expires' => time() + 86400, 'path' => '/', 'secure' => true, 'httponly' => true, 'samesite' => 'Strict']);
                Files::writeJson($statePath, $state);
                self::reply($state);
            }
            $claim = Files::json($private . '/setup-claim.json');
            $cookie = $_COOKIE['nomad_setup_claim'] ?? '';
            if (!is_string($cookie) || ($claim['expires'] ?? 0) < time() || !hash_equals($claim['hash'] ?? '', hash('sha256', $cookie))) {
                throw new UpdateException('SETUP_FORBIDDEN', 'Sign in with the installation secret.', 403);
            }
            $store = new Store($root);
            $store->locked(function () use ($root, $private, $statePath, $input, $script, $transport): void {
                $state = Files::json($statePath);
                $http = $transport ?? new Http();
                $work = $private . '/setup-work';
                Files::directory($work);
                switch ($state['stage']) {
                    case 'protection':
                        if (($input['nonce'] ?? null) !== $state['nonce'] || !in_array($input['status'] ?? null, [403, 404], true)) {
                            throw new UpdateException('PROTECTION_FAILED', 'Private storage protection could not be verified.');
                        }
                        @unlink($private . '/probe-' . $state['nonce'] . '.txt');
                        $state['stage'] = $state['manifest_url'] === '' ? 'catalog' : 'manifest';
                        $state['signature_url'] = $state['manifest_url'] . '.sig';
                        break;
                    case 'catalog':
                        $response = $http->bytes('https://api.github.com/repos/vnorman1/nomad-cms-release/releases/latest');
                        $release = json_decode($response['body'], true, 32, JSON_THROW_ON_ERROR);
                        $assets = [];
                        foreach ($release['assets'] ?? [] as $asset) {
                            $assets[$asset['name']] = $asset['browser_download_url'];
                        }
                        if (!isset($assets['release.json'], $assets['release.json.sig'], $assets['nomad-cms.zip'])) {
                            throw new UpdateException('MISSING_ASSET', 'No signed installation release is available.');
                        }
                        $state['manifest_url'] = $assets['release.json'];
                        $state['signature_url'] = $assets['release.json.sig'];
                        $state['zip_url'] = $assets['nomad-cms.zip'];
                        $state['stage'] = 'manifest';
                        break;
                    case 'manifest':
                        $response = $http->bytes($state['manifest_url']);
                        Files::write($work . '/release.json', $response['body']);
                        $state['stage'] = 'signature';
                        break;
                    case 'signature':
                        $response = $http->bytes($state['signature_url'], null, [], 16384);
                        $state['release'] = Release::verify((string) file_get_contents($work . '/release.json'), $response['body'], $state['keys']);
                        if ($state['release']['updater_protocol'] !== 1 || $state['release']['manual_upgrade']
                            || version_compare(PHP_VERSION, $state['release']['min_php'], '<')) {
                            throw new UpdateException('INCOMPATIBLE_RELEASE', 'This release is not supported by this installer.');
                        }
                        if ($state['zip_url'] === '') {
                            $url = parse_url($state['manifest_url']);
                            $path = $url['path'] ?? '/release.json';
                            $state['zip_url'] = Http::origin($state['manifest_url']) . substr($path, 0, strrpos($path, '/') + 1) . $state['release']['archive']['name'];
                        }
                        $required = $state['release']['archive']['size'] + 2 * $state['release']['archive']['unpacked_size'] + 16777216;
                        if (disk_free_space($root) < $required) {
                            throw new UpdateException('DISK_SPACE', 'Insufficient free space for installation.');
                        }
                        $state['stage'] = 'download';
                        break;
                    case 'download':
                        if ($http->download($state['zip_url'], $work . '/incoming.zip', $state['release']['archive']['size'])) {
                            $state['stage'] = 'verify';
                        }
                        break;
                    case 'verify':
                        $state['files'] = Release::inspectArchive($work . '/incoming.zip', $state['release']);
                        $state['stage'] = 'extract';
                        break;
                    case 'extract':
                        $zip = new \ZipArchive();
                        if ($zip->open($work . '/incoming.zip', \ZipArchive::RDONLY) !== true) {
                            throw new UpdateException('INVALID_ZIP', 'Cannot reopen installation archive.');
                        }
                        $names = array_keys($state['files']);
                        $until = microtime(true) + 3.5;
                        try {
                            while ($state['cursor'] < count($names) && microtime(true) < $until) {
                                $name = $names[$state['cursor']];
                                Release::extractOne($zip, $work . '/stage', $name, $state['files'][$name]);
                                $state['cursor']++;
                            }
                        } finally {
                            $zip->close();
                        }
                        if ($state['cursor'] === count($names)) {
                            $state['stage'] = 'deploy';
                            $state['cursor'] = 0;
                        }
                        break;
                    case 'deploy':
                        $names = array_keys($state['files']);
                        // The root gate stays closed until the entire code tree
                        // exists; authenticated configuration is deployed last.
                        $names = array_values(array_filter($names, static fn($name) => $name !== '.htaccess'));
                        $until = microtime(true) + 3.5;
                        while ($state['cursor'] < count($names) && microtime(true) < $until) {
                            $name = $names[$state['cursor']];
                            $source = Files::target($work . '/stage', $name);
                            $target = Files::target($root, $name);
                            Files::directory(dirname($target), 0755);
                            if (!copy($source, $target . '.setup-part') || !rename($target . '.setup-part', $target)) {
                                throw new UpdateException('WRITE_FAILED', 'Cannot deploy installation file.');
                            }
                            chmod($target, 0644);
                            $state['cursor']++;
                            Files::writeJson($statePath, $state);
                        }
                        if ($state['cursor'] === count($names)) {
                            $state['stage'] = 'complete';
                        }
                        break;
                    case 'complete':
                        $version = Files::json($root . '/version.json');
                        if (($version['version'] ?? null) !== $state['release']['version'] || ($version['buildId'] ?? null) !== $state['release']['build_id']) {
                            throw new UpdateException('VERSION_MISMATCH', 'Installed version does not match the authenticated release.');
                        }
                        $baseline = $root . '/api/data/nomad.schema.json';
                        if (!is_file($baseline)) {
                            Files::directory(dirname($baseline));
                            if (!copy($root . '/api/updater/install-defaults/nomad.schema.json', $baseline)) {
                                throw new UpdateException('WRITE_FAILED', 'Cannot seed schema defaults.');
                            }
                        }
                        if (!is_file($work . '/stage/.htaccess') || !copy($work . '/stage/.htaccess', $root . '/.htaccess')) {
                            throw new UpdateException('WRITE_FAILED', 'Cannot activate protected web configuration.');
                        }
                        Files::writeJson($private . '/setup-complete.json', ['version' => $version['version'], 'completed_at' => time()]);
                        Files::removeTree($work);
                        @unlink($script);
                        $state['stage'] = 'done';
                        break;
                    default:
                        throw new UpdateException('INVALID_SETUP_STATE', 'Unknown installation stage.');
                }
                Files::writeJson($statePath, $state);
                self::reply($state);
            });
        } catch (\Throwable $error) {
            self::reply(['stage' => 'error', 'error' => $error->getMessage()], $error instanceof UpdateException ? max(400, $error->getCode()) : 500);
        }
        exit;
    }

    private static function preflight(string $root): void
    {
        if (version_compare(PHP_VERSION, '8.2.0', '<') || !is_writable($root)) {
            throw new UpdateException('PREFLIGHT_FAILED', 'PHP 8.2+ and a writable directory are required.');
        }
        if (empty($_SERVER['HTTPS']) || $_SERVER['HTTPS'] === 'off') {
            throw new UpdateException('HTTPS_REQUIRED', 'Open the installer over HTTPS.');
        }
        foreach (['pdo_sqlite', 'curl', 'zip', 'openssl', 'tokenizer'] as $extension) {
            if (!extension_loaded($extension)) {
                throw new UpdateException('MISSING_EXTENSION', 'Required PHP extension: ' . $extension);
            }
        }
    }

    private static function reply(array $state, int $status = 200): never
    {
        http_response_code($status);
        header('Content-Type: application/json; charset=utf-8');
        header('Cache-Control: no-store');
        $public = array_intersect_key($state, array_flip(['stage', 'cursor', 'error', 'nonce']));
        if ($state['stage'] === 'protection') {
            $public['url'] = '/api/storage/updates/probe-' . $state['nonce'] . '.txt';
        }
        echo json_encode(['success' => $status === 200] + $public, JSON_THROW_ON_ERROR);
        exit;
    }

    private static function page(string $message = ''): never
    {
        header('Content-Type: text/html; charset=utf-8');
        header('Cache-Control: no-store');
        header("Content-Security-Policy: default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'");
        echo '<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>NOMAD CMS Setup</title><style>body{font:16px system-ui;max-width:680px;margin:8vh auto;padding:24px;background:#101114;color:#eee}input,textarea,button{font:inherit;box-sizing:border-box;padding:10px;margin:8px 0;width:100%}pre{white-space:pre-wrap}</style><h1>NOMAD CMS Setup</h1><p>' . htmlspecialchars($message, ENT_QUOTES, 'UTF-8') . '</p>';
        if ($message !== '') {
            exit;
        }
        echo <<<'HTML'
<form id="setup"><label>Installation secret / Telepítési titok<input id="secret" type="password" required autocomplete="off"></label>
<details><summary>Custom source / Egyéni forrás</summary><input id="manifest" type="url" placeholder="https://mirror.example/release.json"><input id="zip" type="url" placeholder="Optional ZIP URL"><textarea id="key" placeholder="Optional trusted publisher RSA-4096 public key"></textarea></details>
<button id="submit">Install / Telepítés</button></form><pre id="state"></pre>
<script>
const form=document.getElementById('setup'),state=document.getElementById('state');let busy=false;
async function post(body){const response=await fetch(location.pathname,{method:'POST',headers:{'Content-Type':'application/json','X-Nomad-Update':'1'},body:JSON.stringify(body)});const data=await response.json();if(!data.success)throw Error(data.error);return data;}
form.onsubmit=async event=>{event.preventDefault();if(busy)return;busy=true;document.getElementById('submit').disabled=true;try{let data=await post({action:'login',secret:document.getElementById('secret').value,manifest_url:document.getElementById('manifest').value,zip_url:document.getElementById('zip').value,public_key:document.getElementById('key').value});document.getElementById('secret').value='';while(data.stage!=='done'){state.textContent=data.stage+' '+(data.cursor||'');if(data.stage==='protection'){const check=await fetch(data.url,{cache:'no-store'});data=await post({action:'step',nonce:data.nonce,status:check.status});}else{data=await post({action:'step'});}await new Promise(r=>setTimeout(r,250));}location.href='/nomad/install';}catch(error){state.textContent=error.message;}finally{busy=false;document.getElementById('submit').disabled=false;}};
</script></html>
HTML;
        exit;
    }
}
