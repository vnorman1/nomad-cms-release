<?php
/**
 * NOMAD CMS — independent update HTTP and cron controller.
 * Requires operation-bound capabilities for work, same-origin POSTs for browser
 * mutations and a separate high-entropy rescue secret. SSE only reads state.
 */
declare(strict_types=1);

namespace NomadUpdate;

final class Controller
{
    public static function input(): array
    {
        $raw = file_get_contents('php://input', false, null, 0, 65537);
        if ($raw === false || strlen($raw) > 65536) {
            throw new UpdateException('INVALID_INPUT', 'Request body exceeds 64 KiB.');
        }
        try {
            $input = $raw === '' ? [] : json_decode($raw, true, 32, JSON_THROW_ON_ERROR);
        } catch (\JsonException) {
            throw new UpdateException('INVALID_INPUT', 'A valid JSON object is required.');
        }
        if (!is_array($input) || ($input !== [] && array_is_list($input))) {
            throw new UpdateException('INVALID_INPUT', 'A JSON object is required.');
        }
        return $input;
    }

    public static function cookie(string $id, string $ticket): void
    {
        setcookie('nomad_update', $id . '.' . $ticket, [
            'expires' => time() + 86400, 'path' => '/', 'secure' => self::https(),
            'httponly' => true, 'samesite' => 'Strict',
        ]);
    }

    public static function https(): bool
    {
        return (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
            || ($_SERVER['SERVER_PORT'] ?? '') === '443';
    }

    public static function json(array $data, int $status = 200): never
    {
        http_response_code($status);
        header('Content-Type: application/json; charset=utf-8');
        header('Cache-Control: no-store');
        header('X-Content-Type-Options: nosniff');
        echo json_encode($data, JSON_THROW_ON_ERROR | JSON_UNESCAPED_SLASHES);
        exit;
    }

    public static function dispatch(string $root): never
    {
        $store = new Store($root);
        $engine = new Engine($store);
        if (PHP_SAPI === 'cli') {
            self::cli($engine);
        }
        try {
            $action = $_GET['action'] ?? 'maintenance';
            if (!is_string($action)) {
                throw new UpdateException('INVALID_ACTION', 'Invalid update action.');
            }
            if ($action === 'maintenance') {
                self::maintenance($engine);
            }
            $method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
            if (in_array($action, ['step', 'probe', 'start', 'cancel', 'rescue'], true)) {
                if ($method !== 'POST' || ($_SERVER['HTTP_X_NOMAD_UPDATE'] ?? '') !== '1') {
                    throw new UpdateException('METHOD_NOT_ALLOWED', 'A same-origin JSON POST with X-Nomad-Update is required.', 405);
                }
                $origin = $_SERVER['HTTP_ORIGIN'] ?? '';
                $expectedOrigin = (self::https() ? 'https://' : 'http://') . ($_SERVER['HTTP_HOST'] ?? '');
                $browserOrigin = Files::json($store->path . '/browser-origin.json')['origin'] ?? $expectedOrigin;
                if ($origin !== '' && $origin !== $expectedOrigin && $origin !== $browserOrigin) {
                    throw new UpdateException('FORBIDDEN_ORIGIN', 'Cross-origin update requests are forbidden.', 403);
                }
            } elseif ($method !== 'GET' || !in_array($action, ['status', 'events'], true)) {
                throw new UpdateException('METHOD_NOT_ALLOWED', 'Unsupported update action or method.', 405);
            }
            if ($action === 'rescue') {
                $body = self::input();
                if (!is_string($body['token'] ?? null) || !$store->verifyRescue($body['token'])) {
                    throw new UpdateException('RESCUE_FORBIDDEN', 'Recovery secret is invalid.', 403);
                }
                $active = $store->active();
                if ($active !== null) {
                    $engine->cancel($active['id']);
                    $op = $store->operation($active['id']);
                    if ($op['mutation_started']) {
                        $capability = $engine->issueCapability($op['id'], 'rescue');
                        self::cookie($op['id'], $capability['ticket']);
                        self::json(['success' => true, 'operation' => $capability['operation']]);
                    }
                }
                $slots = Files::json($store->path . '/slots.json');
                if ($slots === []) {
                    throw new UpdateException('SLOT_UNAVAILABLE', 'No local rollback package is available.');
                }
                $prepared = $engine->prepareRollback($slots[0]['id'], 'rescue');
                self::cookie($prepared['operation']['id'], $prepared['ticket']);
                self::json(['success' => true, 'operation' => $prepared['operation']]);
            }
            $cookie = $_COOKIE['nomad_update'] ?? '';
            if (!is_string($cookie) || !preg_match('~^([a-f0-9]{32})\.([a-f0-9]{64})$~D', $cookie, $matches)) {
                throw new UpdateException('INVALID_CAPABILITY', 'An authorized update session is required.', 403);
            }
            $op = $engine->authorize($matches[1], $matches[2]);
            if ($action === 'start' && $op['actor'] !== 'rescue') {
                throw new UpdateException('FRESH_ADMIN_REQUIRED', 'Approve activation from the authenticated Updates settings page.', 403);
            }
            if ($action === 'events') {
                header('Content-Type: text/event-stream');
                header('Cache-Control: no-store');
                header('X-Accel-Buffering: no');
                echo 'id: ' . ($op['updated_at'] ?? time()) . "\nevent: progress\ndata: " . json_encode(Store::publicOperation($op), JSON_THROW_ON_ERROR) . "\n\n";
                echo "retry: 1500\n\n";
                exit;
            }
            $result = match ($action) {
                'step' => $engine->step($op['id']),
                'probe' => $engine->probe($op['id']),
                'start' => $engine->start($op['id']),
                'cancel' => $engine->cancel($op['id']),
                default => Store::publicOperation($op),
            };
            self::json(['success' => true, 'operation' => $result]);
        } catch (\Throwable $error) {
            self::json(['success' => false, 'error' => $error->getMessage(), 'code' => $error instanceof UpdateException ? $error->errorCode : 'UPDATE_FAILED'], $error instanceof UpdateException ? max(400, $error->getCode()) : 500);
        }
    }

    private static function cli(Engine $engine): never
    {
        $command = $_SERVER['argv'][1] ?? '--help';
        if ($command === '--resume') {
            $op = $engine->store->active();
            if ($op !== null && !in_array($op['stage'], ['ready', 'manifest', 'signature', 'download', 'verify', 'extract', 'local'], true)) {
                // One application probe per process prevents class/autoloader reuse
                // across a rollback. A once-per-minute cron is sufficient.
                $result = in_array($op['stage'], ['migrate', 'health', 'rollback_health'], true)
                    ? $engine->probe($op['id']) : $engine->step($op['id']);
                fwrite(STDOUT, json_encode($result, JSON_THROW_ON_ERROR) . "\n");
            }
            exit(0);
        }
        fwrite(STDOUT, "Usage: php api/nomad-update.php --resume\nResumes authorized activation/recovery only; never starts or approves a release.\n");
        exit($command === '--help' ? 0 : 1);
    }

    private static function maintenance(Engine $engine): never
    {
        try {
            $engine->recover();
        } catch (\Throwable) {
            // The authenticated rescue UI remains available during recovery errors.
        }
        http_response_code(503);
        header('Retry-After: 5');
        header('Cache-Control: no-store');
        header('Content-Type: text/html; charset=utf-8');
        header("Content-Security-Policy: default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; connect-src 'self'; form-action 'self'; frame-ancestors 'none'; base-uri 'none'");
        echo <<<'HTML'
<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>NOMAD CMS — Maintenance</title><style>body{font:16px system-ui;max-width:640px;margin:12vh auto;padding:24px;background:#101114;color:#eee}button,input{font:inherit;padding:10px;margin:8px 0}pre{white-space:pre-wrap;color:#bbb}a{color:#bbb}</style>
<h1>NOMAD CMS</h1><p>Maintenance / Karbantartás</p><pre id="state">Checking recovery state…</pre>
<button id="resume">Continue / Folytatás</button><form id="rescue"><label>Recovery secret / Helyreállítási titok<br><input id="secret" type="password" autocomplete="off" required></label><br><button>Restore / Visszaállítás</button></form>
<a href="/nomad/">Return to CMS / Vissza a CMS-hez</a>
<script>
const endpoint='/api/nomad-update.php?action=';
async function request(action,body){const r=await fetch(endpoint+action,{method:body?'POST':'GET',headers:body?{'Content-Type':'application/json','X-Nomad-Update':'1'}:{},body:body?JSON.stringify(body):undefined});const data=await r.json();if(!data.success)throw Error(data.error);return data.operation;}
let running=false;
async function resume(approve=false){if(running)return;running=true;try{for(;;){let op=await request('status');document.getElementById('state').textContent=op.stage+'\n'+(op.error?.message||'');if(['completed','rolled_back','failed','cancelled'].includes(op.stage))break;if(op.stage==='ready'){if(!approve)break;op=await request('start',{});}else{op=await request(['migrate','health','rollback_health'].includes(op.stage)?'probe':'step',{});}await new Promise(r=>setTimeout(r,300));}}catch(e){document.getElementById('state').textContent=e.message;}finally{running=false;}}
document.getElementById('resume').onclick=()=>resume(true);
document.getElementById('rescue').onsubmit=async e=>{e.preventDefault();try{await request('rescue',{token:document.getElementById('secret').value});document.getElementById('secret').value='';resume(true);}catch(error){document.getElementById('state').textContent=error.message;}};
resume();
</script></html>
HTML;
        exit;
    }
}
