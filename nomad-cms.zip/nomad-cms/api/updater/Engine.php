<?php
/**
 * NOMAD CMS — resumable code update and rollback state machine.
 * Journals intent before every live mutation; customer data and bootstrap files
 * never belong to its write set. Separate probe requests isolate application
 * failures from the immutable recovery engine. No shell or daemon is required.
 */
declare(strict_types=1);

namespace NomadUpdate;

final class Engine
{
    public function __construct(public readonly Store $store, private readonly Http $http = new Http(), private readonly ?\Closure $probeHandler = null)
    {
    }

    public function status(): array
    {
        $pointer = Files::json($this->store->path . '/active.json');
        $operation = isset($pointer['id']) ? $this->store->operation($pointer['id']) : null;
        $slots = Files::json($this->store->path . '/slots.json');
        foreach ($slots as &$slot) {
            $slot['blocked_reason'] = Release::compatibility($slot['release'], $this->store->current(), $this->storage());
            unset($slot['release']);
        }
        unset($slot);
        return [
            'current' => $this->store->current(), 'settings' => $this->store->publicSettings(),
            'slots' => array_values($slots), 'operation' => Store::publicOperation($operation),
            'maintenance' => is_file($this->store->path . '/maintenance.json'),
            'free_bytes' => disk_free_space($this->store->root),
        ];
    }

    private function storage(): array
    {
        return Files::json($this->store->path . '/storage.json', [
            'epoch' => $this->store->current()['storageEpoch'] ?? 1,
            'rollback_floor' => $this->store->current()['minRollbackVersion'] ?? '1.0.0',
        ]);
    }

    public function catalog(string $sourceId, bool $force = false): array
    {
        $source = $this->store->source($sourceId);
        $path = $this->store->path . '/catalog-' . $sourceId . '.json';
        $cache = Files::json($path, ['checked_at' => 0, 'releases' => []]);
        if (($cache['retry_at'] ?? 0) > time() || (!$force && $cache['checked_at'] + 21600 > time())) {
            return $cache;
        }
        if ($force && $cache['checked_at'] + 60 > time()) {
            return $cache;
        }
        $credential = $this->store->credential($source);
        try {
            if ($source['kind'] === 'github') {
                $headers = isset($cache['etag']) ? ['If-None-Match' => $cache['etag']] : [];
                $response = $this->http->bytes('https://api.github.com/repos/' . $source['repo'] . '/releases?per_page=30', $credential, $headers);
                if ($response['status'] === 304) {
                    $cache['checked_at'] = time();
                    unset($cache['error'], $cache['retry_at']);
                    Files::writeJson($path, $cache);
                    return $cache;
                }
                $rows = json_decode($response['body'], true, 32, JSON_THROW_ON_ERROR);
                if (!is_array($rows) || count($rows) > 30) {
                    throw new UpdateException('INVALID_CATALOG', 'Invalid GitHub release list.');
                }
                $releases = [];
                foreach ($rows as $row) {
                    $version = ltrim($row['tag_name'] ?? '', 'v');
                    if (($row['draft'] ?? true) || !Release::semver($version)) {
                        continue;
                    }
                    $assets = [];
                    foreach ($row['assets'] ?? [] as $asset) {
                        if (isset($asset['name'], $asset['browser_download_url'])) {
                            Http::origin($asset['browser_download_url']);
                            $assets[$asset['name']] = $asset['browser_download_url'];
                        }
                    }
                    $releases[] = [
                        'id' => (string) $row['id'], 'version' => $version, 'prerelease' => (bool) ($row['prerelease'] ?? false),
                        'name' => substr((string) ($row['name'] ?? $version), 0, 200),
                        'notes' => substr((string) ($row['body'] ?? ''), 0, 20000),
                        'release_url' => $row['html_url'] ?? null,
                        'download_url' => $assets['nomad-cms.zip'] ?? null,
                        'manifest_url' => $assets['release.json'] ?? null,
                        'signature_url' => $assets['release.json.sig'] ?? null,
                        'assets' => $assets,
                        'blocked_reason' => isset($assets['release.json'], $assets['release.json.sig'], $assets['nomad-cms.zip']) ? null : 'This legacy release has no signed installation package.',
                    ];
                }
                usort($releases, static fn($a, $b) => version_compare($b['version'], $a['version']));
                $cache = ['checked_at' => time(), 'etag' => $response['headers']['etag'] ?? '', 'releases' => $releases];
            } else {
                $response = $this->http->bytes($source['manifest_url'], $credential);
                $signature = $this->http->bytes($source['manifest_url'] . '.sig', $credential, [], 16384);
                $release = Release::verify($response['body'], $signature['body'], $this->store->keys($source));
                $url = $source['zip_url'] ?? self::assetUrl($source['manifest_url'], $release['archive']['name']);
                $cache = ['checked_at' => time(), 'releases' => [[
                    'id' => $release['build_id'], 'version' => $release['version'],
                    'prerelease' => str_contains($release['version'], '-'), 'name' => $release['version'],
                    'notes' => (string) ($release['notes'] ?? ''), 'release_url' => null,
                    'download_url' => $url, 'manifest_url' => $source['manifest_url'],
                    'signature_url' => $source['manifest_url'] . '.sig',
                    'blocked_reason' => Release::compatibility($release, $this->store->current(), $this->storage()),
                ]]];
            }
        } catch (\Throwable $error) {
            $cache['error'] = $error->getMessage();
            $delay = $error instanceof UpdateException && str_starts_with($error->errorCode, 'RATE_LIMIT:')
                ? (int) substr($error->errorCode, 11) : 60;
            $cache['retry_at'] = time() + max(60, $delay);
        }
        Files::writeJson($path, $cache);
        return $cache;
    }

    private static function assetUrl(string $manifest, string $name): string
    {
        $parts = parse_url($manifest);
        $path = $parts['path'] ?? '/release.json';
        return Http::origin($manifest) . substr($path, 0, strrpos($path, '/') + 1) . rawurlencode($name);
    }

    public function prepare(string $sourceId, string $releaseId, string $actor): array
    {
        $catalog = $this->catalog($sourceId);
        $candidate = null;
        foreach ($catalog['releases'] as $item) {
            if ($item['id'] === $releaseId) {
                $candidate = $item;
            }
        }
        if ($candidate === null || $candidate['blocked_reason'] !== null) {
            throw new UpdateException('RELEASE_UNAVAILABLE', $candidate['blocked_reason'] ?? 'Release is not available in the source catalog.');
        }
        return $this->create([
            'kind' => 'update', 'source_id' => $sourceId, 'candidate' => $candidate,
            'stage' => 'manifest', 'version' => $candidate['version'],
        ], $actor);
    }

    public function prepareRollback(string $slotId, string $actor): array
    {
        $slot = null;
        foreach (Files::json($this->store->path . '/slots.json') as $item) {
            if ($item['id'] === $slotId) {
                $slot = $item;
            }
        }
        if ($slot === null || !preg_match('~^[a-f0-9]{32}$~D', $slotId)) {
            throw new UpdateException('SLOT_UNAVAILABLE', 'Rollback slot is unavailable.');
        }
        $reason = Release::compatibility($slot['release'], $this->store->current(), $this->storage());
        if ($reason !== null) {
            throw new UpdateException('INCOMPATIBLE_RELEASE', $reason);
        }
        return $this->create(['kind' => 'rollback', 'slot_id' => $slotId, 'release' => $slot['release'], 'stage' => 'local', 'version' => $slot['version']], $actor);
    }

    private function create(array $data, string $actor): array
    {
        return $this->store->locked(function () use ($data, $actor): array {
            if ($this->store->active() !== null) {
                throw new UpdateException('UPDATE_BUSY', 'Another update operation is active.', 409);
            }
            $id = bin2hex(random_bytes(16));
            $ticket = bin2hex(random_bytes(32));
            $operation = $data + [
                'id' => $id, 'actor' => $actor, 'ticket_hash' => hash('sha256', $ticket),
                'ticket_expires' => time() + 86400, 'created_at' => time(),
                'updated_at' => time(), 'events' => [], 'cursor' => 0, 'total' => 0,
                'mutation_started' => false, 'committed' => false,
            ];
            $this->store->event($operation, 'Operation prepared; the installed code is unchanged.');
            Files::writeJson($this->store->path . '/active.json', ['id' => $id]);
            return ['operation' => Store::publicOperation($operation), 'ticket' => $ticket];
        });
    }

    public function authorize(string $id, string $ticket): array
    {
        $op = $this->store->operation($id);
        if (strlen($ticket) !== 64 || $op['ticket_expires'] < time() || !hash_equals($op['ticket_hash'], hash('sha256', $ticket))) {
            throw new UpdateException('INVALID_CAPABILITY', 'Update capability is invalid or expired.', 403);
        }
        return $op;
    }

    public function issueCapability(string $id, string $actor): array
    {
        return $this->store->locked(function () use ($id, $actor): array {
            $op = $this->store->operation($id);
            $ticket = bin2hex(random_bytes(32));
            $op['ticket_hash'] = hash('sha256', $ticket);
            $op['ticket_expires'] = time() + 86400;
            $op['actor'] = $actor;
            $this->store->save($op);
            return ['operation' => Store::publicOperation($op), 'ticket' => $ticket];
        });
    }

    public function start(string $id, ?string $approvalActor = null): array
    {
        return $this->store->locked(function () use ($id, $approvalActor): array {
            $op = $this->store->operation($id);
            if ($op['stage'] === 'ready') {
                $this->preflight($op);
                $op['stage'] = 'maintenance';
                $op['approved_by'] = $approvalActor ?? $op['actor'];
                $op['approved_at'] = time();
                $op['cursor'] = 0;
                $this->store->event($op, 'Activation authorized.');
            } elseif ($op['stage'] !== 'maintenance') {
                throw new UpdateException('NOT_READY', 'Prepare and verify the package before activation.', 409);
            }
            return Store::publicOperation($op);
        });
    }

    public function cancel(string $id): array
    {
        return $this->store->locked(function () use ($id): array {
            $op = $this->store->operation($id);
            if (in_array($op['stage'], ['completed', 'rolled_back', 'failed', 'cancelled'], true)) {
                return Store::publicOperation($op);
            }
            if ($op['mutation_started']) {
                $this->beginRollback($op, 'Operation cancelled; restoring previous code.');
            } elseif (!in_array($op['stage'], ['completed', 'rolled_back', 'failed', 'cancelled'], true)) {
                $op['stage'] = 'cancelled';
                $this->clearMaintenance($op);
                $this->store->event($op, 'Operation cancelled.');
                $this->clean($op);
            }
            return Store::publicOperation($op);
        });
    }

    public function step(string $id): array
    {
        return $this->store->locked(function () use ($id): array {
            $op = $this->store->operation($id);
            $lock = null;
            try {
                if (in_array($op['stage'], ['maintenance', 'snapshot', 'apply', 'migrate', 'health', 'finalize', 'rollback_extract', 'rollback_apply', 'rollback_health'], true)) {
                    Files::writeJson($this->store->path . '/maintenance.json', ['id' => $id]);
                    $lock = fopen($this->store->path . '/application.lock', 'c');
                    if ($lock === false || !flock($lock, LOCK_EX | LOCK_NB)) {
                        return Store::publicOperation($op);
                    }
                }
                $this->advance($op);
            } catch (\Throwable $error) {
                $this->failure($op, $error);
            } finally {
                if (is_resource($lock)) {
                    flock($lock, LOCK_UN);
                    fclose($lock);
                }
            }
            return Store::publicOperation($this->store->operation($id));
        });
    }

    private function advance(array &$op): void
    {
        $dir = $this->directory($op);
        $deadline = microtime(true) + 3.5;
        switch ($op['stage']) {
            case 'manifest':
                $source = $this->store->source($op['source_id']);
                $response = $this->http->bytes($op['candidate']['manifest_url'], $this->store->credential($source));
                Files::write($dir . '/release.json', $response['body']);
                $op['stage'] = 'signature';
                $this->store->event($op, 'Release manifest downloaded.');
                break;
            case 'signature':
                $source = $this->store->source($op['source_id']);
                $response = $this->http->bytes($op['candidate']['signature_url'], $this->store->credential($source), [], 16384);
                Files::write($dir . '/release.json.sig', $response['body']);
                $release = Release::verify((string) file_get_contents($dir . '/release.json'), $response['body'], $this->store->keys($source));
                if ($release['version'] !== $op['version']) {
                    throw new UpdateException('RELEASE_CHANGED', 'Release version changed during preparation.');
                }
                $reason = Release::compatibility($release, $this->store->current(), $this->storage());
                if ($reason !== null) {
                    throw new UpdateException('INCOMPATIBLE_RELEASE', $reason);
                }
                $op['release'] = $release;
                $op['download_url'] = $source['zip_url'] ?? $op['candidate']['assets'][$release['archive']['name']] ?? $op['candidate']['download_url'];
                if (!is_string($op['download_url'])) {
                    throw new UpdateException('MISSING_ASSET', 'The signed package asset is unavailable.');
                }
                Http::origin($op['download_url']);
                $op['archive_size'] = $release['archive']['size'];
                $this->preflight($op);
                $op['stage'] = 'download';
                $this->store->event($op, 'Release signature and compatibility verified.');
                break;
            case 'download':
                $source = $this->store->source($op['source_id']);
                $done = $this->http->download($op['download_url'], $dir . '/incoming.zip', $op['release']['archive']['size'], $this->store->credential($source));
                $op['downloaded_bytes'] = is_file($dir . '/incoming.zip') ? filesize($dir . '/incoming.zip') : 0;
                if ($done) {
                    $op['stage'] = 'verify';
                }
                $this->store->save($op);
                break;
            case 'local':
                if (!copy($this->store->path . '/rollback/' . $op['slot_id'] . '.zip', $dir . '/incoming.zip')) {
                    throw new UpdateException('SLOT_UNAVAILABLE', 'Cannot read the selected rollback package.');
                }
                $op['stage'] = 'verify';
                $this->store->save($op);
                break;
            case 'verify':
                $op['files'] = Release::inspectArchive($dir . '/incoming.zip', $op['release'], $op['kind'] === 'rollback');
                $op['total'] = count($op['files']);
                $op['cursor'] = 0;
                $op['stage'] = 'extract';
                $this->store->event($op, 'Package digest and ZIP inventory verified.');
                break;
            case 'extract':
            case 'rollback_extract':
                $recovering = $op['stage'] === 'rollback_extract';
                $files = $recovering ? $op['backup_files'] : $op['files'];
                $zip = new \ZipArchive();
                if ($zip->open($dir . ($recovering ? '/outgoing.zip' : '/incoming.zip'), \ZipArchive::RDONLY) !== true) {
                    throw new UpdateException('INVALID_ZIP', 'Cannot reopen verified package.');
                }
                try {
                    $names = array_keys($files);
                    while ($op['cursor'] < count($names) && microtime(true) < $deadline) {
                        $name = $names[$op['cursor']];
                        if (($files[$name]['kind'] ?? 'code') === 'code') {
                            Release::extractOne($zip, $dir . ($recovering ? '/restore' : '/stage'), $name, $files[$name]);
                        }
                        $op['cursor']++;
                        if ($op['cursor'] % 20 === 0) {
                            $this->store->save($op);
                        }
                    }
                } finally {
                    $zip->close();
                }
                $this->store->save($op);
                if ($op['cursor'] === count($names)) {
                    $op['cursor'] = 0;
                    $op['stage'] = $recovering ? 'rollback_apply' : 'ready';
                    if (!$recovering) {
                        $version = Files::json($dir . '/stage/version.json');
                        if (($version['version'] ?? null) !== $op['release']['version'] || ($version['buildId'] ?? null) !== $op['release']['build_id']) {
                            throw new UpdateException('VERSION_MISMATCH', 'Package version does not match the signed release.');
                        }
                        $this->preflight($op);
                    }
                    $this->store->event($op, $recovering ? 'Previous code staged for recovery.' : 'Package ready. Review and start activation.');
                }
                break;
            case 'maintenance':
                $this->preflight($op);
                $op['backup_files'] = Files::inventory($this->store->root);
                $op['previous'] = $this->store->current();
                $op['stage'] = 'snapshot';
                $op['cursor'] = 0;
                $op['total'] = count($op['backup_files']);
                $this->store->event($op, 'Maintenance active; application requests drained.');
                break;
            case 'snapshot':
                $zip = new \ZipArchive();
                if ($zip->open($dir . '/outgoing.zip', \ZipArchive::CREATE) !== true) {
                    throw new UpdateException('BACKUP_FAILED', 'Cannot create current-code backup.', 500);
                }
                try {
                    $names = array_keys($op['backup_files']);
                    $count = 0;
                    while ($op['cursor'] < count($names) && $count++ < 150 && microtime(true) < $deadline - 1) {
                        $name = $names[$op['cursor']];
                        if (!$zip->addFile(Files::target($this->store->root, $name), 'nomad-cms/' . $name)) {
                            throw new UpdateException('BACKUP_FAILED', 'Cannot archive current code.', 500);
                        }
                        $op['cursor']++;
                    }
                    if ($op['cursor'] === count($names)) {
                        $manifest = json_encode(['format' => 'nomad-package/v1', 'files' => $op['backup_files']], JSON_THROW_ON_ERROR | JSON_UNESCAPED_SLASHES);
                        $zip->addFromString('nomad-cms/package-manifest.json', $manifest);
                    }
                } finally {
                    if (!$zip->close()) {
                        throw new UpdateException('BACKUP_FAILED', 'Cannot finalize current-code backup.', 500);
                    }
                }
                if ($op['cursor'] === count($names)) {
                    $op['backup_release'] = $this->localRelease($op['previous'], $op['backup_files'], $dir . '/outgoing.zip', $manifest);
                    Release::inspectArchive($dir . '/outgoing.zip', $op['backup_release'], true);
                    $slots = Files::json($this->store->path . '/slots.json');
                    $retained = isset($slots[0]) ? $slots[0]['size'] : 0;
                    if ($op['backup_release']['archive']['size'] + $retained > $this->store->settings()['retention_bytes']) {
                        throw new UpdateException('RETENTION_LIMIT', 'Increase the rollback storage budget before updating.');
                    }
                    $op['write_set'] = array_values(array_unique(array_merge(array_keys($op['backup_files']), array_keys(array_filter($op['files'], static fn($file) => ($file['kind'] ?? 'code') === 'code')))));
                    $op['cursor'] = 0;
                    $op['total'] = count($op['write_set']);
                    $op['stage'] = 'apply';
                    $this->store->event($op, 'Exact installed code backed up and verified.');
                } else {
                    $this->store->save($op);
                }
                break;
            case 'apply':
            case 'rollback_apply':
                $restoring = $op['stage'] === 'rollback_apply';
                $files = $restoring ? $op['backup_files'] : $op['files'];
                if (!$op['mutation_started']) {
                    $op['mutation_started'] = true;
                    $this->store->save($op);
                }
                while ($op['cursor'] < count($op['write_set']) && microtime(true) < $deadline) {
                    $name = $op['write_set'][$op['cursor']];
                    $destination = Files::target($this->store->root, $name);
                    if (isset($files[$name]) && ($files[$name]['kind'] ?? 'code') === 'code') {
                        $source = Files::target($dir . ($restoring ? '/restore' : '/stage'), $name);
                        $this->replace($source, $destination, $files[$name]['sha256']);
                    } elseif (is_file($destination) && !unlink($destination)) {
                        throw new UpdateException('WRITE_FAILED', 'Cannot remove retired code file.', 500);
                    }
                    $this->invalidate($destination);
                    $op['cursor']++;
                    if ($op['cursor'] % 10 === 0) {
                        $this->store->save($op);
                    }
                }
                $this->store->save($op);
                if ($op['cursor'] === count($op['write_set'])) {
                    $op['cursor'] = 0;
                    $op['stage'] = $restoring ? 'rollback_health' : ($op['kind'] === 'rollback' ? 'health' : 'migrate');
                    $op['probe_action'] = $restoring || $op['kind'] === 'rollback' ? 'health' : 'migrate';
                    $this->store->event($op, $restoring ? 'Previous code restored; verifying health.' : 'Code installed; application probes required.');
                }
                break;
            case 'migrate':
            case 'health':
            case 'rollback_health':
                $op['probe_action'] = $op['stage'] === 'migrate' ? 'migrate' : 'health';
                $this->store->save($op);
                break;
            case 'finalize':
                $this->finalize($op);
                break;
        }
    }

    /** Runs only in its own HTTP/CLI request, after authorization and locking. */
    public function probe(string $id): array
    {
        return $this->store->locked(function () use ($id): array {
            $op = $this->store->operation($id);
            if (!in_array($op['stage'], ['migrate', 'health', 'rollback_health'], true)) {
                throw new UpdateException('PROBE_NOT_READY', 'Application probe is not ready.', 409);
            }
            if (isset($op['probe_started'])) {
                // A prior request exited/fataled without returning to the engine.
                // Acquiring the worker lock proves it is no longer running.
                $this->failure($op, new UpdateException('PROBE_TERMINATED', 'The previous application probe terminated unexpectedly.', 500));
                return Store::publicOperation($this->store->operation($id));
            }
            $lock = fopen($this->store->path . '/application.lock', 'c');
            if ($lock === false || !flock($lock, LOCK_EX | LOCK_NB)) {
                if (is_resource($lock)) {
                    fclose($lock);
                }
                throw new UpdateException('UPDATE_BUSY', 'Application requests have not drained.', 409);
            }
            $op['probe_started'] = time();
            $this->store->save($op);
            try {
                if (!defined('NOMAD_UPDATE_PROBE')) {
                    define('NOMAD_UPDATE_PROBE', true);
                }
                $restoring = $op['stage'] === 'rollback_health';
                $release = $restoring ? $op['backup_release'] : $op['release'];
                $callback = $this->probeHandler ?? require $this->store->root . '/api/integrations/update-probe.php';
                $result = $callback($op['stage'] === 'migrate' ? 'migrate' : 'health', $release, $op['cursor']);
                if (!is_array($result) || !isset($result['done'])) {
                    throw new UpdateException('PROBE_FAILED', 'Invalid application probe result.', 500);
                }
                $op['cursor'] = (int) ($result['cursor'] ?? $op['cursor']);
                unset($op['probe_started']);
                if ($result['done']) {
                    $op['cursor'] = 0;
                    unset($op['probe_action']);
                    if ($restoring) {
                        $op['stage'] = 'rolled_back';
                        $this->clearMaintenance($op);
                        $this->store->event($op, 'Previous code is healthy; customer data was preserved.');
                        $this->clean($op);
                    } else {
                        $op['stage'] = $op['stage'] === 'migrate' ? 'health' : 'finalize';
                        $this->store->event($op, $op['stage'] === 'health' ? 'Migrations completed.' : 'Application health verified.');
                    }
                } else {
                    $this->store->event($op, 'Migration checkpoint committed.');
                }
            } catch (\Throwable $error) {
                $this->failure($op, $error);
            } finally {
                flock($lock, LOCK_UN);
                fclose($lock);
            }
            return Store::publicOperation($this->store->operation($id));
        });
    }

    private function preflight(array &$op): void
    {
        foreach (['pdo_sqlite', 'curl', 'zip', 'openssl', 'tokenizer'] as $extension) {
            if (!extension_loaded($extension)) {
                throw new UpdateException('MISSING_EXTENSION', 'Required PHP extension: ' . $extension);
            }
        }
        if (version_compare(PHP_VERSION, '8.2.0', '<') || !is_writable($this->store->root)) {
            throw new UpdateException('PREFLIGHT_FAILED', 'PHP 8.2+ and a writable installation are required.');
        }
        if ((bool) ini_get('opcache.enable') && PHP_SAPI !== 'cli') {
            $restriction = (string) ini_get('opcache.restrict_api');
            if (!function_exists('opcache_invalidate') || ($restriction !== '' && !str_starts_with($this->store->root . '/api/nomad-update.php', $restriction))) {
                throw new UpdateException('OPCACHE_UNSUPPORTED', 'OPcache invalidation is unavailable.');
            }
        }
        if (!is_file($this->store->root . '/api/nomad-install.lock')) {
            throw new UpdateException('NOT_INSTALLED', 'Complete CMS installation before updating.');
        }
        $proof = Files::json($this->store->path . '/protection.json');
        if (PHP_SAPI !== 'cli' && ($proof['verified_at'] ?? 0) < time() - 3600) {
            throw new UpdateException('PROTECTION_UNVERIFIED', 'Verify private storage protection before preparing an update.');
        }
        $reason = Release::compatibility($op['release'], $this->store->current(), $this->storage());
        if ($reason !== null) {
            throw new UpdateException('INCOMPATIBLE_RELEASE', $reason);
        }
        $inventory = Files::inventory($this->store->root);
        $oldSize = array_sum(array_column($inventory, 'size'));
        $largest = max([0, ...array_column($inventory, 'size')]);
        $op['required_free_bytes'] = $oldSize + $op['release']['archive']['size'] + $op['release']['archive']['unpacked_size'] + 2 * $largest + 16777216;
        if (disk_free_space($this->store->root) < $op['required_free_bytes']) {
            throw new UpdateException('DISK_SPACE', 'Insufficient free space for staging and recovery.');
        }
        foreach (array_keys($inventory) as $name) {
            if (!is_writable(Files::target($this->store->root, $name)) || !is_writable(dirname(Files::target($this->store->root, $name)))) {
                throw new UpdateException('WRITE_PERMISSION', 'A managed code file or directory is not writable.');
            }
        }
    }

    private function directory(array $op): string
    {
        return $this->store->path . '/operations/' . $op['id'];
    }

    private function localRelease(array $version, array $files, string $zip, string $manifest): array
    {
        return [
            'format' => 'nomad-release/v1', 'product' => 'nomad-cms', 'version' => $version['version'],
            'build_id' => $version['buildId'] ?? 'legacy', 'min_php' => $version['minPhp'] ?? '8.2.0',
            'updater_protocol' => 1, 'storage_epoch' => $this->storage()['epoch'],
            'min_upgrade_version' => '1.0.0', 'min_rollback_version' => $this->storage()['rollback_floor'],
            'manual_upgrade' => false, 'migrations' => [],
            'archive' => ['name' => 'nomad-cms.zip', 'size' => filesize($zip), 'sha256' => hash_file('sha256', $zip),
                'manifest_sha256' => hash('sha256', $manifest), 'unpacked_size' => array_sum(array_column($files, 'size')), 'file_count' => count($files)],
        ];
    }

    private function replace(string $source, string $destination, string $expected): void
    {
        if (!is_file($source) || !hash_equals($expected, hash_file('sha256', $source))) {
            throw new UpdateException('STAGING_CHANGED', 'A verified staging file changed.');
        }
        Files::directory(dirname($destination), 0755);
        $tmp = $destination . '.nomad-update-part';
        if (is_link($tmp)) {
            throw new UpdateException('UNSAFE_PATH', 'Unsafe temporary destination.');
        }
        $in = fopen($source, 'rb');
        $out = fopen($tmp, 'wb');
        if ($in === false || $out === false) {
            throw new UpdateException('WRITE_FAILED', 'Cannot open code replacement.', 500);
        }
        try {
            if (stream_copy_to_stream($in, $out) !== filesize($source) || !fflush($out)
                || (function_exists('fsync') && !fsync($out))) {
                throw new UpdateException('WRITE_FAILED', 'Cannot persist code replacement.', 500);
            }
        } finally {
            fclose($in);
            fclose($out);
        }
        chmod($tmp, 0644);
        if (!rename($tmp, $destination)) {
            throw new UpdateException('WRITE_FAILED', 'Cannot activate code replacement.', 500);
        }
    }

    private function invalidate(string $path): void
    {
        clearstatcache(true, $path);
        if (str_ends_with($path, '.php') && function_exists('opcache_invalidate')) {
            $invalidated = @opcache_invalidate($path, true);
            if (!$invalidated && function_exists('opcache_is_script_cached') && @opcache_is_script_cached($path)) {
                throw new UpdateException('OPCACHE_FAILED', 'Cannot invalidate an active PHP script.', 500);
            }
        }
    }

    private function beginRollback(array &$op, string $message): void
    {
        unset($op['probe_started']);
        $outgoing = $this->directory($op) . '/outgoing.zip';
        $retained = $this->store->path . '/rollback/' . $op['id'] . '.zip';
        if (!is_file($outgoing) && is_file($retained) && !copy($retained, $outgoing)) {
            throw new UpdateException('RECOVERY_FAILED', 'Cannot reopen the retained recovery package.', 500);
        }
        $op['stage'] = 'rollback_extract';
        $op['cursor'] = 0;
        $op['total'] = count($op['backup_files']);
        unset($op['probe_action']);
        Release::inspectArchive($this->directory($op) . '/outgoing.zip', $op['backup_release'], true);
        $this->store->event($op, $message);
    }

    private function failure(array &$op, \Throwable $error): void
    {
        unset($op['probe_started']);
        $op['error'] = ['code' => $error instanceof UpdateException ? $error->errorCode : 'UPDATE_FAILED', 'message' => $error->getMessage()];
        if ($op['committed']) {
            $op['stage'] = 'completed';
            $this->clearMaintenance($op);
            $this->store->event($op, 'Update committed; temporary cleanup needs attention.');
        } elseif ($op['mutation_started']) {
            if (str_starts_with($op['stage'], 'rollback_')) {
                $this->store->event($op, 'Recovery paused; retry or use the rescue entry point.');
            } else {
                $this->beginRollback($op, 'Activation failed; restoring previous code.');
            }
        } else {
            $op['stage'] = 'failed';
            $this->clearMaintenance($op);
            $this->store->event($op, 'Operation failed before code activation.');
            $this->clean($op);
        }
    }

    private function finalize(array &$op): void
    {
        $dir = $this->directory($op);
        $destination = $this->store->path . '/rollback/' . $op['id'] . '.zip';
        if (!is_file($destination) && !rename($dir . '/outgoing.zip', $destination)) {
            throw new UpdateException('SLOT_ROTATION_FAILED', 'Cannot retain previous code.', 500);
        }
        $old = Files::json($this->store->path . '/slots.json');
        $remaining = array_values(array_filter($old, fn($slot) => $slot['id'] !== $op['id']));
        $slots = array_slice(array_merge([[
            'id' => $op['id'], 'version' => $op['previous']['version'], 'build_id' => $op['previous']['buildId'] ?? 'legacy',
            'size' => filesize($destination), 'created_at' => time(), 'release' => $op['backup_release'],
        ]], $remaining), 0, 2);
        $storage = $this->storage();
        if (version_compare($op['release']['min_rollback_version'], $storage['rollback_floor'], '>')) {
            $storage['rollback_floor'] = $op['release']['min_rollback_version'];
        }
        Files::writeJson($this->store->path . '/storage.json', $storage);
        Files::writeJson($this->store->path . '/slots.json', $slots);
        $op['committed'] = true;
        $this->store->save($op);
        $this->clearMaintenance($op);
        $op['stage'] = 'completed';
        $this->store->event($op, 'Update completed; rollback slots rotated.');
        foreach ($old as $slot) {
            if (!in_array($slot['id'], array_column($slots, 'id'), true)) {
                @unlink($this->store->path . '/rollback/' . $slot['id'] . '.zip');
            }
        }
        $this->clean($op);
    }

    private function clearMaintenance(array $op): void
    {
        $flag = $this->store->path . '/maintenance.json';
        if ((Files::json($flag)['id'] ?? null) === $op['id'] && !unlink($flag)) {
            throw new UpdateException('MAINTENANCE_FAILED', 'Cannot leave maintenance mode.', 500);
        }
    }

    private function clean(array $op): void
    {
        $dir = $this->directory($op);
        foreach (['incoming.zip', 'outgoing.zip', 'stage', 'restore', 'release.json', 'release.json.sig'] as $name) {
            Files::removeTree($dir . '/' . $name);
        }
        if (in_array($op['stage'], ['completed', 'rolled_back', 'failed', 'cancelled'], true)) {
            unset($op['files'], $op['backup_files'], $op['write_set'], $op['candidate']);
            $this->store->save($op);
        }
    }

    /** Anonymous traffic can only recover an already authorized, stale cutover. */
    public function recover(): void
    {
        $flag = Files::json($this->store->path . '/maintenance.json');
        if (!isset($flag['id'])) {
            return;
        }
        $op = $this->store->operation($flag['id']);
        if ($op['stage'] === 'finalize') {
            $this->step($op['id']);
            return;
        }
        if ($op['updated_at'] > time() - 120 && !str_starts_with($op['stage'], 'rollback_')) {
            return;
        }
        if (!str_starts_with($op['stage'], 'rollback_')) {
            $this->store->locked(function () use (&$op): void {
                $op = $this->store->operation($op['id']);
                if ($op['committed'] || in_array($op['stage'], ['completed', 'rolled_back'], true)) {
                    $this->clearMaintenance($op);
                } elseif ($op['mutation_started']) {
                    $this->beginRollback($op, 'Stale activation detected; automatic recovery started.');
                } else {
                    $op['stage'] = 'failed';
                    $this->clearMaintenance($op);
                    $this->store->event($op, 'Interrupted before activation; installed code is intact.');
                }
            });
        }
        $op = $this->store->operation($op['id']);
        if ($op['stage'] === 'rollback_health') {
            $this->probe($op['id']);
        } elseif (str_starts_with($op['stage'], 'rollback_')) {
            $this->step($op['id']);
        }
    }
}
