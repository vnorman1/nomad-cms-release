<?php
/**
 * NOMAD CMS - Collection Migration CLI Script
 * High-performance migration tool for converting monolithic JSON slots to row-backed collections
 *
 * CLI Usage:
 *   php api/scripts/migrate-collections.php --dry-run
 *   php api/scripts/migrate-collections.php --apply [--slot=projects]
 *   php api/scripts/migrate-collections.php --rollback --slot=projects
 *   php api/scripts/migrate-collections.php --schema-migration=mapping.json [--slot=projects] [--apply]
 *
 * Features:
 * - Non-destructive dry-run mode using read-only SQLite connections
 * - Rollback mechanism restoring previous slot state from collection_migration_archives
 * - Schema transformation support with field remapping and type migrations
 * - Atomic execution per slot with automatic database backup checkpoints
 * - Zero memory overhead streaming migration for massive collections
 *
 * Storage: Migrates slots table JSON -> collection_slots, collection_items, collection_blocks
 */
declare(strict_types=1);

require_once dirname(__DIR__, 1) . '/update-guard.php';
if (PHP_SAPI !== "cli") {
    http_response_code(404);
    exit();
}
require dirname(__DIR__) . "/vendor/autoload.php";
\Dotenv\Dotenv::createImmutable(dirname(__DIR__))->safeLoad();
use NomadCMS\Database\CollectionDatabase;
use NomadCMS\Services\RelationService;
$options = getopt("", [
    "dry-run",
    "apply",
    "slot:",
    "rollback",
    "schema-migration:",
]);
if (isset($options["apply"]) && isset($options["rollback"])) {
    throw new InvalidArgumentException("Choose apply or rollback");
}
if (
    !isset($options["apply"]) &&
    !isset($options["rollback"]) &&
    !isset($options["schema-migration"])
) {
    $file =
        dirname(__DIR__) .
        "/databases/" .
        ($_ENV["DB_CONTENT_DATABASE"] ?? "database.sqlite");
    $readonly = new PDO("sqlite:file:" . $file . "?mode=ro", null, null, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);
    $property = new ReflectionProperty(
        \NomadCMS\Database\ContentDatabase::class,
        "instance"
    );
    $property->setValue(null, $readonly);
}
$schema = \NomadCMS\Services\Schema\SchemaProvider::schema();
$slots = isset($options["slot"])
    ? [$options["slot"] => $schema["slots"][$options["slot"]] ?? null]
    : array_filter(
        $schema["slots"] ?? [],
        fn($s) => ($s["type"] ?? "") === "collection"
    );
try {
    foreach ($slots as $key => $definition) {
        if (!$definition || ($definition["type"] ?? "") !== "collection") {
            throw new InvalidArgumentException("Unknown collection: " . $key);
        }
        if (isset($options["schema-migration"])) {
            $mapping = json_decode(
                file_get_contents($options["schema-migration"]),
                true,
                512,
                JSON_THROW_ON_ERROR
            );
            $report = \NomadCMS\Services\CollectionSchemaMigration::apply(
                $key,
                $mapping,
                !isset($options["apply"])
            );
        } elseif (isset($options["rollback"])) {
            CollectionDatabase::rollbackMigration($key);
            $report = ["slot" => $key, "status" => "rolled_back"];
        } else {
            $report = CollectionDatabase::migrate(
                $key,
                $definition,
                !isset($options["apply"])
            );
        }
        echo json_encode(
            $report,
            JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES
        ) . PHP_EOL;
    }
} catch (Throwable $e) {
    fwrite(STDERR, $e->getMessage() . PHP_EOL);
    exit(1);
}
