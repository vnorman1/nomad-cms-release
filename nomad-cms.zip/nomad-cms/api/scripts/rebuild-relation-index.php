<?php
/**
 * NOMAD CMS — CLI collection relation audit and resumable repair.
 * Defaults to read-only audit. --repair rewrites only derived relations in bounded batches.
 * Usage: php api/scripts/rebuild-relation-index.php articles [--repair] [--after=123]
 */
declare(strict_types=1);

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}
require __DIR__ . '/../bootstrap.php';

use NomadCMS\Services\RelationIndexService;

$key = $argv[1] ?? '';
$repair = in_array('--repair', $argv, true);
$after = 0;
foreach (array_slice($argv, 2) as $argument) {
    if (preg_match('/^--after=([0-9]+)$/D', $argument, $match)) {
        $after = (int) $match[1];
    } elseif ($argument !== '--repair') {
        fwrite(STDERR, "Unknown option: $argument\n");
        exit(1);
    }
}
try {
    $mismatches = 0;
    do {
        $page = RelationIndexService::page($key, $after, 128, $repair);
        $after = $page['after'];
        $mismatches += $page['mismatches'];
        echo json_encode($page + ['repair' => $repair], JSON_THROW_ON_ERROR) . PHP_EOL;
    } while (!$page['done']);
    exit($mismatches > 0 && !$repair ? 2 : 0);
} catch (Throwable $error) {
    fwrite(STDERR, $error->getMessage() . PHP_EOL);
    exit(1);
}
