<?php
/**
 * NOMAD CMS - Stateless File Server
 * Serves files by filename: /api/endpoints/f.php?f={filename}
 * 
 * Pretty URL format (display): /{ext}/{filename}
 * Actual download: f.php?f={filename}
 * 
 * No mapping needed - filename is the identifier
 */

declare(strict_types=1);

require_once __DIR__ . '/../bootstrap.php';
require_once __DIR__ . '/../lib/file.php';

use NomadCMS\Middleware\AuthMiddleware;

// Handle CORS preflight
handlePreflight();

$filename = $_GET['f'] ?? '';

if (empty($filename)) {
    http_response_code(400);
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'error' => 'No filename provided']);
    exit;
}

// Security: prevent path traversal
if (strpos($filename, '..') !== false || strpos($filename, '/') !== false) {
    http_response_code(400);
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'error' => 'Invalid filename']);
    exit;
}

try {
    $dirs = getFileDirectories();
    
    // Check if it's a secure file first (.nomad in secure folder)
    $securePath = $dirs['secure'] . $filename . '.nomad';
    $publicPath = $dirs['public'] . $filename;
    
    if (file_exists($securePath)) {
        // Secure file - requires:
        // 1. Signed URL, OR
        // 2. Session auth (logged in user), OR
        // 3. Pro API key with encrypted_read permission
        $signature = $_GET['sig'] ?? '';
        $expires = intval($_GET['exp'] ?? 0);
        $authenticated = false;
        
        // 1. Try signed URL first
        if (!empty($signature) && $expires > 0) {
            if (verifySignedUrl($filename, $signature, $expires)) {
                $authenticated = true;
            } else {
                http_response_code(403);
                header('Content-Type: application/json');
                echo json_encode(['success' => false, 'error' => 'Invalid or expired signature']);
                exit;
            }
        }
        
        // 2. Try session/API key auth
        if (!$authenticated) {
            $user = AuthMiddleware::optionalAuth();
            
            if ($user) {
                // Check if API key auth
                if (isset($user->source) && $user->source === 'api_key') {
                    // API key auth - must be pro key with encrypted_read permission
                    $apiKeyData = AuthMiddleware::getApiKeyData();
                    
                    if (!$apiKeyData || $apiKeyData['key_type'] !== 'enhanced') {
                        http_response_code(403);
                        header('Content-Type: application/json');
                        echo json_encode([
                            'success' => false, 
                            'error' => 'Secure files require Pro API key (nmk_pro_). Standard API keys cannot access encrypted data.'
                        ]);
                        exit;
                    }
                    
                    if (!($apiKeyData['can_encrypted_read'] ?? false)) {
                        http_response_code(403);
                        header('Content-Type: application/json');
                        echo json_encode([
                            'success' => false, 
                            'error' => 'This Pro API key does not have encrypted_read permission.'
                        ]);
                        exit;
                    }
                    
                    $authenticated = true;
                } else {
                    // Session auth (logged in user) - allowed
                    $authenticated = true;
                }
            }
        }
        
        if (!$authenticated) {
            http_response_code(401);
            header('Content-Type: application/json');
            echo json_encode(['success' => false, 'error' => 'Authentication required for secure files']);
            exit;
        }
        
        // Get decrypted file using STREAMING (memory-safe)
        $result = getSecureFile($filename, true); // streamMode = true
        $metadata = $result['metadata'];
        
        $mimeType = $metadata['mimeType'] ?? 'application/octet-stream';
        $originalName = $metadata['originalName'] ?? $filename;
        
        if ($result['isStreamed'] && isset($result['tempPath'])) {
            // STREAMING MODE: Serve from temp file
            $tempPath = $result['tempPath'];
            $fileSize = filesize($tempPath);
            
            header('Content-Type: ' . $mimeType);
            header('Content-Disposition: attachment; filename="' . $originalName . '"');
            header('Content-Length: ' . $fileSize);
            header('Cache-Control: no-store, no-cache, must-revalidate');
            header('Pragma: no-cache');
            
            readfile($tempPath);
            @unlink($tempPath); // Cleanup
        } else {
            // LEGACY MODE: Content in memory
            $content = $result['content'];
            
            header('Content-Type: ' . $mimeType);
            header('Content-Disposition: attachment; filename="' . $originalName . '"');
            header('Content-Length: ' . strlen($content));
            header('Cache-Control: no-store, no-cache, must-revalidate');
            header('Pragma: no-cache');
            
            echo $content;
        }
        
    } elseif (file_exists($publicPath)) {
        // Public file - serve directly
        $mimeType = mime_content_type($publicPath) ?: 'application/octet-stream';
        
        header('Content-Type: ' . $mimeType);
        header('Content-Disposition: inline; filename="' . $filename . '"');
        header('Content-Length: ' . filesize($publicPath));
        header('Cache-Control: public, max-age=31536000');
        
        readfile($publicPath);
        
    } else {
        http_response_code(404);
        header('Content-Type: application/json');
        echo json_encode(['success' => false, 'error' => 'File not found']);
    }
    
} catch (Exception $e) {
    http_response_code(500);
    header('Content-Type: application/json');
    echo json_encode([
        'success' => false,
        'error' => ($_ENV['APP_DEBUG'] ?? 'false') === 'true' ? $e->getMessage() : 'Internal server error',
    ]);
}
