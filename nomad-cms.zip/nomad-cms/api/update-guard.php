<?php
/**
 * NOMAD CMS — stable API compatibility bridge to the update guard.
 * All application entry points load this before the mutable Composer autoloader.
 */
declare(strict_types=1);

require_once __DIR__ . '/updater/guard.php';
