<?php
/**
 * NOMAD CMS — independent rescue entry point.
 * Displays the immutable maintenance/recovery interface. Restoring code requires
 * a POST authenticated with the separately generated recovery secret.
 */
declare(strict_types=1);

require_once __DIR__ . '/updater/load.php';
\NomadUpdate\Controller::dispatch(dirname(__DIR__));
