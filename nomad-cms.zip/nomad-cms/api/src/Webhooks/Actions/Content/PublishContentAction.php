<?php
/**
 * NOMAD CMS - Publish Content Action
 * 
 * Publishes or unpublishes content.
 */

declare(strict_types=1);

namespace NomadCMS\Webhooks\Actions\Content;

use NomadCMS\Webhooks\Actions\BaseAction;
use NomadCMS\Webhooks\Actions\ActionContext;
use NomadCMS\Webhooks\Actions\ActionResult;
use NomadCMS\Database\ContentDatabase;
use NomadCMS\Database\MassiveDatabase;

class PublishContentAction extends BaseAction
{
    public function getType(): string
    {
        return 'publish_content';
    }
    
    public function getName(): string
    {
        return 'Tartalom Publikálása';
    }
    
    public function getDescription(): string
    {
        return 'Tartalom publikálása vagy visszavonása';
    }
    
    public function getCategory(): string
    {
        return 'content';
    }
    
    public function getIcon(): string
    {
        return '📢';
    }
    
    public function getConfigSchema(): array
    {
        return [
            'type' => 'object',
            'required' => ['slot', 'action'],
            'properties' => [
                'slot' => [
                    'type' => 'string',
                    'title' => 'Slot',
                    'description' => 'A slot neve',
                ],
                'action' => [
                    'type' => 'string',
                    'title' => 'Művelet',
                    'enum' => ['publish', 'unpublish', 'toggle'],
                    'default' => 'publish',
                ],
                'match_field' => [
                    'type' => 'string',
                    'title' => 'Egyeztetési mező',
                    'default' => 'id',
                ],
                'match_source' => [
                    'type' => 'string',
                    'title' => 'Egyeztetési érték forrása',
                    'default' => '$.id',
                ],
                'published_at_field' => [
                    'type' => 'string',
                    'title' => 'Publikálás dátum mező',
                    'default' => 'published_at',
                ],
                'status_field' => [
                    'type' => 'string',
                    'title' => 'Státusz mező',
                    'default' => 'status',
                ],
            ],
        ];
    }
    
    public function getExpectedFields(): array
    {
        return ['id', 'slug'];
    }
    
    public function execute(ActionContext $context): ActionResult
    {
        $startTime = microtime(true);
        
        try {
            $slot = $context->getConfig('slot');
            $action = $context->getConfig('action', 'publish');
            $matchField = $context->getConfig('match_field', 'id');
            $matchSource = $context->getConfig('match_source', '$.id');
            $statusField = $context->getConfig('status_field', 'status');
            $publishedAtField = $context->getConfig('published_at_field', 'published_at');
            
            $mapper = new \NomadCMS\Webhooks\PayloadMapper();
            $matchValue = $mapper->evaluateJsonPath($matchSource, $context->originalPayload);
            
            if ($matchValue === null) {
                return ActionResult::failure("Match value not found at path: {$matchSource}");
            }
            
            $slotType = $this->getSlotType($slot);
            $options = [
                'changed_by' => 'webhook:action:' . ($context->endpoint['name'] ?? 'unknown'),
                'version_intent' => 'system', // Programmatic write: always a commit, unaffected by shadow/autosave feature
            ];
            
            // Determine new status
            $now = date('Y-m-d H:i:s');
            
            if ($slotType === 'massive') {
                $massive = new MassiveDatabase($slot);
                
                if ($matchField === 'id') {
                    $existing = $massive->find((int)$matchValue);
                } else {
                    $results = $massive->query()->where($matchField, '=', $matchValue)->limit(1)->get();
                    $existing = $results[0] ?? null;
                }
                
                if (!$existing) {
                    return ActionResult::failure("Content not found");
                }
                
                $currentStatus = $existing[$statusField] ?? 'draft';
                $newStatus = $this->determineStatus($action, $currentStatus);
                
                $updateData = [$statusField => $newStatus];
                if ($newStatus === 'published' && empty($existing[$publishedAtField])) {
                    $updateData[$publishedAtField] = $now;
                }
                
                $massive->update($existing['id'], $updateData);
                
                $result = [
                    'id' => $existing['id'],
                    'slot' => $slot,
                    'old_status' => $currentStatus,
                    'new_status' => $newStatus,
                ];
            } elseif ($slotType === 'collection') {
                \NomadCMS\Database\CollectionDatabase::ensureReady($slot);
                $result = \NomadCMS\Database\CollectionDatabase::transaction(function () use ($slot, $matchField, $matchValue, $context, $statusField, $publishedAtField, $action, $now, $options): array {
                    $existing=\NomadCMS\Database\CollectionDatabase::findByField($slot,$matchField,$matchValue);
                    if (!$existing) {
                        throw new \OutOfBoundsException('Collection item not found');
                    }
                    $state = \NomadCMS\Database\CollectionDatabase::state($slot);
                    $definition = json_decode($state['schema_json'], true, 512, JSON_THROW_ON_ERROR);
                    $explicitStatusField = $context->getConfig('status_field');
                    if (!is_string($explicitStatusField) || $explicitStatusField === '') {
                        $statusField = $definition['publishedField'] ?? 'status';
                    }
                    $booleanField = $statusField === ($definition['publishedField'] ?? null);
                    foreach ($definition['fields'] ?? [] as $field) {
                        if (($field['id'] ?? null) === $statusField && ($field['type'] ?? null) === 'boolean') {
                            $booleanField = true;
                        }
                    }
                    $currentStatus = $existing[$statusField] ?? ($booleanField ? false : 'draft');
                    if ($booleanField) {
                        $currentPublished = filter_var($currentStatus, FILTER_VALIDATE_BOOLEAN);
                        $newStatus = match ($action) {
                            'publish' => true,
                            'unpublish' => false,
                            'toggle' => !$currentPublished,
                            default => throw new \InvalidArgumentException('Unknown publication action'),
                        };
                    } else {
                        $newStatus = $this->determineStatus($action, (string) $currentStatus);
                    }
                    $updateData=[$statusField=>$newStatus];
                    if (($newStatus === true || $newStatus === 'published') && empty($existing[$publishedAtField])) {
                        $updateData[$publishedAtField] = $now;
                    }
                    \NomadCMS\Database\CollectionDatabase::writeItem($slot,$existing['_dndId'],$updateData,'update',$options);
                    return ['slot' => $slot, 'old_status' => $currentStatus, 'new_status' => $newStatus];
                });
            } else {
                $contentDb = new ContentDatabase();
                $existing = ContentDatabase::getSlot($slot);
                
                // For object slots
                if ($slotType === 'object') {
                    $currentStatus = $existing[$statusField] ?? 'draft';
                    $newStatus = $this->determineStatus($action, $currentStatus);
                    
                    $existing[$statusField] = $newStatus;
                    if ($newStatus === 'published' && empty($existing[$publishedAtField])) {
                        $existing[$publishedAtField] = $now;
                    }
                    
                    ContentDatabase::saveSlot($slot, $existing, $options);
                    
                    $result = [
                        'slot' => $slot,
                        'old_status' => $currentStatus,
                        'new_status' => $newStatus,
                    ];
                } else {
                    // For list/collection slots
                    $found = false;
                    foreach ($existing as $key => &$item) {
                        $itemMatch = ($matchField === 'slug' && $key == $matchValue) ||
                                     ($this->getNestedValue($item, $matchField) == $matchValue);
                        
                        if ($itemMatch) {
                            $currentStatus = $item[$statusField] ?? 'draft';
                            $newStatus = $this->determineStatus($action, $currentStatus);
                            
                            $item[$statusField] = $newStatus;
                            if ($newStatus === 'published' && empty($item[$publishedAtField])) {
                                $item[$publishedAtField] = $now;
                            }
                            
                            $found = true;
                            $result = [
                                'slot' => $slot,
                                'key' => $key,
                                'old_status' => $currentStatus,
                                'new_status' => $newStatus,
                            ];
                            break;
                        }
                    }
                    
                    if (!$found) {
                        return ActionResult::failure("Content not found");
                    }
                    
                    ContentDatabase::saveSlot($slot, $existing, $options);
                }
            }
            
            $executionTime = (int)((microtime(true) - $startTime) * 1000);
            
            return new ActionResult(
                success: true,
                data: $result,
                statusCode: 200,
                executionTimeMs: $executionTime
            );
            
        } catch (\Exception $e) {
            $this->log('Publish content failed', ['error' => $e->getMessage()]);
            return ActionResult::failure($e->getMessage());
        }
    }
    
    private function determineStatus(string $action, string $currentStatus): string
    {
        return match ($action) {
            'publish' => 'published',
            'unpublish' => 'draft',
            'toggle' => $currentStatus === 'published' ? 'draft' : 'published',
            default => 'published',
        };
    }
    
    private function getNestedValue(array $data, string $path): mixed
    {
        $keys = explode('.', $path);
        $value = $data;
        
        foreach ($keys as $key) {
            if (!is_array($value) || !array_key_exists($key, $value)) {
                return null;
            }
            $value = $value[$key];
        }
        
        return $value;
    }
    
    private function getSlotType(string $slot): string
    {
        return \NomadCMS\Services\RelationService::getSlotType($slot);
    }
}
