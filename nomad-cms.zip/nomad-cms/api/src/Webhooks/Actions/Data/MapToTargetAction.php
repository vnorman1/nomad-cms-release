<?php
/**
 * NOMAD CMS - Map To Target Action
 *
 * Exposes the automapper as a first-class webhook action, so a mapping can sit
 * inside an existing action chain ("map the booking, THEN post to Slack") rather
 * than being a parallel mechanism the action system knows nothing about.
 *
 * All the logic lives in MappingExecutor; this class is the adapter to the
 * ActionInterface contract. Keeping it thin matters: the executor is also driven
 * directly by the receiver and by replay, and three callers sharing one
 * implementation is the only way those three paths cannot drift apart.
 *
 * @package NomadCMS\Webhooks\Actions\Data
 */

declare(strict_types=1);

namespace NomadCMS\Webhooks\Actions\Data;

use NomadCMS\Webhooks\Actions\ActionContext;
use NomadCMS\Webhooks\Actions\ActionResult;
use NomadCMS\Webhooks\Actions\BaseAction;
use NomadCMS\Webhooks\Mapping\MappingExecutor;

class MapToTargetAction extends BaseAction
{
    protected bool $requiresProvider = false;

    public function getType(): string
    {
        return 'map_to_target';
    }

    public function getName(): string
    {
        return 'Mentés a beállított célba (automapper)';
    }

    public function getDescription(): string
    {
        return 'A jóváhagyott mező-összekötések alapján elmenti a beérkező adatot '
            . 'a végponthoz beállított űrlapba, adatbázis táblába vagy gyűjteménybe.';
    }

    public function getCategory(): string
    {
        return 'data';
    }

    public function getIcon(): string
    {
        return '🔗';
    }

    public function getConfigSchema(): array
    {
        // Intentionally almost empty. The destination and the field pairings are
        // configured in the mapper UI and stored on the endpoint / in
        // webhook_mapping_rules - NOT duplicated into this action's config.
        // Two places to configure the same thing would guarantee they disagree.
        return [
            'type' => 'object',
            'properties' => [
                'event_type' => [
                    'type' => 'string',
                    'title' => 'Csak erre az eseménytípusra',
                    'description' => 'Üresen hagyva minden eseménytípusra lefut.',
                ],
            ],
            'required' => [],
        ];
    }

    public function getExpectedFields(): array
    {
        // The mapper reads the ORIGINAL payload, not the action chain's mapped
        // payload, so it expects nothing from an upstream action.
        return [];
    }

    public function validateConfig(array $config): array
    {
        $errors = [];

        $eventType = $config['event_type'] ?? null;
        if ($eventType !== null && $eventType !== '' && !is_string($eventType)) {
            $errors['event_type'] = 'Az eseménytípusnak szövegnek kell lennie.';
        }

        return $errors;
    }

    public function execute(ActionContext $context): ActionResult
    {
        $endpoint = $context->endpoint;

        if (($endpoint['endpoint_key'] ?? null) === null) {
            // The action system passes endpoints in several shapes depending on
            // the caller; without a slug we cannot load the rules, and guessing
            // would risk writing with another endpoint's mapping.
            return ActionResult::failure('A művelethez a végpont azonosítója szükséges.');
        }

        $configuredEventType = $context->getConfig('event_type');
        $eventType = is_string($configuredEventType) && $configuredEventType !== ''
            ? $configuredEventType
            : ($context->triggerEvent !== '' ? $context->triggerEvent : null);

        $executor = new MappingExecutor();

        // The ORIGINAL payload, deliberately. An upstream TransformDataAction may
        // have reshaped the mapped payload, but the user's rules were authored
        // against the shape the provider actually sends.
        $result = $executor->execute($endpoint, $context->originalPayload, null, $eventType);

        if ($result->skipped) {
            return ActionResult::success(
                ['skipped' => true, 'reason' => $result->error],
                ['status' => $result->status]
            );
        }

        if (!$result->success) {
            return ActionResult::failure((string) $result->error, null, ['status' => $result->status]);
        }

        return ActionResult::success(
            [
                'target' => $result->target,
                'record_id' => $result->recordId,
                'fields_written' => array_keys($result->values),
            ],
            ['rules_applied' => $result->rulesApplied]
        );
    }
}
