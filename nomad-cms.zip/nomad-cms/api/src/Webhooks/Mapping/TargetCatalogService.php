<?php
/**
 * NOMAD CMS - Mapping Target Catalog
 *
 * Builds the two-level "Hova mentsük a CMS-ben?" selector: first the KIND of
 * destination, then the concrete one, then its fields.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * WHY THREE KINDS AND NOT ONE
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *   form     A Form's submission inbox. The best default for anything that
 *            looks like a lead or a booking, because it INHERITS the whole
 *            Forms module: the inbox UI, CSV export, notification e-mails,
 *            retention, and - critically - envelope encryption. Mapping a
 *            Cal.com booking into an encrypted form is the only path that
 *            leaves no plaintext personal data at rest.
 *   massive  A `massive` type slot. Right for high-volume, append-only data
 *            where the Forms inbox semantics would be noise. Schemaless by
 *            design, which is handled explicitly below.
 *   content  A regular content slot. Right when the webhook genuinely publishes
 *            CONTENT (a product feed, a changelog entry) rather than recording
 *            an interaction.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * WRITE MODE IS PART OF THE CATALOG, NOT AN IMPLEMENTATION DETAIL
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * An `object` slot holds ONE value. Mapping a webhook into it does not add a
 * record, it REPLACES the existing one - every event overwriting the last. That
 * is occasionally what someone wants ("always show the latest build status") and
 * usually a mistake. So every target declares write_mode, and the UI is expected
 * to warn on 'overwrite'. Hiding this distinction behind a uniform "save" verb
 * would be the single easiest way to make a laymen-friendly tool destroy data.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * SCHEMALESS MASSIVE SLOTS
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * A massive slot can legitimately declare no fields at all (the one in this
 * repository's schema does). Offering an empty dropdown would be a dead end, so
 * such a target is marked schemaless and its field list is DISCOVERED from the
 * keys of existing rows, with the UI free to accept a new name as well. The
 * strict-select behaviour is kept for targets that do declare a schema, because
 * there a free-text field name is almost always a typo.
 *
 * @package NomadCMS\Webhooks\Mapping
 */

declare(strict_types=1);

namespace NomadCMS\Webhooks\Mapping;

use NomadCMS\Database\MassiveDatabase;
use NomadCMS\Services\Forms\FormService;
use PDO;
use Throwable;

final class TargetCatalogService
{
    /** Ceiling on discovered field names for a schemaless target */
    private const MAX_DISCOVERED_FIELDS = 60;

    /** Rows inspected when discovering a schemaless slot's shape */
    private const DISCOVERY_SAMPLE_ROWS = 25;

    /** A record is appended per event */
    public const WRITE_APPEND = 'append';

    /** The single existing record is replaced per event */
    public const WRITE_OVERWRITE = 'overwrite';

    /**
     * Full catalog for the two-level selector.
     *
     * @return array{groups: array<int, array<string, mixed>>}
     */
    public function catalog(): array
    {
        return [
            'groups' => [
                [
                    'kind' => WebhookEventsSchema::TARGET_FORM,
                    'label' => 'Űrlap beérkező üzenetek',
                    'description' => 'A beérkező adat úgy jelenik meg, mint egy űrlap-kitöltés: '
                        . 'megnyitható a postafiókban, exportálható CSV-be, és ha az űrlap titkosított, titkosítva tárolódik.',
                    'recommended' => true,
                    'targets' => $this->formTargets(),
                ],
                [
                    'kind' => WebhookEventsSchema::TARGET_MASSIVE,
                    'label' => 'Adatbázis tábla (nagy mennyiségű adat)',
                    'description' => 'Sok ezer rekordhoz. Minden esemény új sort hoz létre.',
                    'recommended' => false,
                    'targets' => $this->massiveTargets(),
                ],
                [
                    'kind' => WebhookEventsSchema::TARGET_CONTENT,
                    'label' => 'Gyűjtemény / tartalom',
                    'description' => 'Akkor válaszd, ha a webhook valódi TARTALMAT hoz, amit meg is jelenítesz az oldalon.',
                    'recommended' => false,
                    'targets' => $this->contentTargets(),
                ],
            ],
        ];
    }

    /**
     * One resolved target, or null when it does not exist (or is not writable).
     *
     * The executor calls this to validate a rule's destination before writing,
     * so a form deleted after the rule was created fails loudly instead of
     * silently dropping events.
     *
     * @return array<string, mixed>|null
     */
    public function findTarget(string $kind, string $key): ?array
    {
        foreach ($this->catalog()['groups'] as $group) {
            if ($group['kind'] !== $kind) {
                continue;
            }
            foreach ($group['targets'] as $target) {
                if ($target['key'] === $key) {
                    return $target;
                }
            }
        }

        return null;
    }

    // =========================================================================
    // FORMS
    // =========================================================================

    /**
     * @return array<int, array<string, mixed>>
     */
    private function formTargets(): array
    {
        $targets = [];

        try {
            $forms = FormService::listAll();
        } catch (Throwable $e) {
            error_log('[WebhookMapping] Form target enumeration failed: ' . $e->getMessage());
            return [];
        }

        foreach ($forms as $form) {
            $data = is_array($form['data'] ?? null) ? $form['data'] : [];
            $slug = (string) ($data['slug'] ?? '');
            if ($slug === '') {
                continue;
            }

            $fields = [];
            foreach ((array) ($data['fields'] ?? []) as $field) {
                if (!is_array($field)) {
                    continue;
                }
                $name = (string) ($field['name'] ?? '');
                if ($name === '') {
                    continue;
                }

                $fields[] = $this->describeTargetField(
                    $name,
                    (string) ($field['label'] ?? $name),
                    (string) ($field['type'] ?? 'text'),
                    (bool) ($field['required'] ?? false),
                    // A field the form itself marks as personal data is worth
                    // flagging in the mapper, so a user notices when they are
                    // about to route a name into a PII column.
                    (bool) ($field['pii'] ?? false)
                );
            }

            $targets[] = [
                'kind' => WebhookEventsSchema::TARGET_FORM,
                'key' => $slug,
                'label' => (string) ($data['name'] ?? $slug),
                'description' => (string) ($data['description'] ?? ''),
                'write_mode' => self::WRITE_APPEND,
                'schemaless' => false,
                'encrypted' => FormService::isEncrypted($form),
                'fields' => $fields,
            ];
        }

        return $targets;
    }

    // =========================================================================
    // MASSIVE SLOTS
    // =========================================================================

    /**
     * @return array<int, array<string, mixed>>
     */
    private function massiveTargets(): array
    {
        $targets = [];

        foreach ($this->schemaSlots() as $key => $slot) {
            if (($slot['type'] ?? null) !== 'massive') {
                continue;
            }

            $fields = $this->schemaFields($slot);
            $schemaless = $fields === [];

            if ($schemaless) {
                // An empty dropdown is a dead end for a non-technical user, so
                // infer the shape from what is already stored.
                $fields = $this->discoverMassiveFields((string) $key);
            }

            $targets[] = [
                'kind' => WebhookEventsSchema::TARGET_MASSIVE,
                'key' => (string) $key,
                'label' => (string) ($slot['label'] ?? $key),
                'description' => (string) ($slot['description'] ?? ''),
                'write_mode' => self::WRITE_APPEND,
                'schemaless' => $schemaless,
                'encrypted' => false,
                'fields' => $fields,
            ];
        }

        return $targets;
    }

    /**
     * Derive candidate field names from the JSON keys of existing rows.
     *
     * @return array<int, array<string, mixed>>
     */
    private function discoverMassiveFields(string $slotKey): array
    {
        try {
            MassiveDatabase::ensureTable($slotKey);
            $db = MassiveDatabase::getInstance();
            $table = 'massive_' . preg_replace('/[^a-zA-Z0-9_]/', '_', $slotKey);

            $stmt = $db->prepare("SELECT data FROM {$table} ORDER BY id DESC LIMIT ?");
            $stmt->execute([self::DISCOVERY_SAMPLE_ROWS]);
        } catch (Throwable $e) {
            return [];
        }

        $seen = [];
        foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
            $decoded = json_decode((string) ($row['data'] ?? ''), true);
            if (!is_array($decoded)) {
                continue;
            }
            foreach (array_keys($decoded) as $name) {
                $name = (string) $name;
                if ($name !== '' && !isset($seen[$name])) {
                    $seen[$name] = true;
                }
            }
            if (count($seen) >= self::MAX_DISCOVERED_FIELDS) {
                break;
            }
        }

        $fields = [];
        foreach (array_keys($seen) as $name) {
            $fields[] = $this->describeTargetField($name, $name, 'text', false, false, true);
        }

        return $fields;
    }

    // =========================================================================
    // CONTENT SLOTS
    // =========================================================================

    /**
     * @return array<int, array<string, mixed>>
     */
    private function contentTargets(): array
    {
        $targets = [];

        foreach ($this->schemaSlots() as $key => $slot) {
            $type = (string) ($slot['type'] ?? 'object');
            if (!in_array($type, ['object', 'list', 'collection'], true)) {
                continue;
            }

            $targets[] = [
                'kind' => WebhookEventsSchema::TARGET_CONTENT,
                'key' => (string) $key,
                'label' => (string) ($slot['label'] ?? $key),
                'description' => (string) ($slot['description'] ?? ''),
                'slot_type' => $type,
                // The distinction that decides whether events accumulate or
                // trample each other.
                'write_mode' => $type === 'object' ? self::WRITE_OVERWRITE : self::WRITE_APPEND,
                'schemaless' => false,
                'encrypted' => false,
                'fields' => $this->schemaFields($slot),
            ];
        }

        return $targets;
    }

    // =========================================================================
    // SCHEMA ACCESS
    // =========================================================================

    /**
     * Slot definitions from nomad.schema.json, memoised per request.
     *
     * @return array<string, array<string, mixed>>
     */
    private function schemaSlots(): array
    {
        static $slots = null;

        if ($slots !== null) {
            return $slots;
        }

        $slots = [];
        $decoded = \NomadCMS\Services\Schema\SchemaProvider::schema();
        if (is_array($decoded) && is_array($decoded['slots'] ?? null)) {
            foreach ($decoded['slots'] as $key => $slot) {
                if (is_array($slot)) {
                    $slots[(string) $key] = $slot;
                }
            }
        }

        return $slots;
    }

    /**
     * @param array<string, mixed> $slot
     * @return array<int, array<string, mixed>>
     */
    private function schemaFields(array $slot): array
    {
        $fields = [];

        foreach ((array) ($slot['fields'] ?? []) as $field) {
            if (!is_array($field)) {
                continue;
            }
            $id = (string) ($field['id'] ?? $field['name'] ?? '');
            if ($id === '') {
                continue;
            }

            $field = \NomadCMS\Services\Schema\TemporalField::normalize($field);
            $type = (string) ($field['type'] ?? 'text');

            // Structural field types have no scalar to receive a webhook value.
            // Offering them would produce a mapping that cannot possibly work.
            if (in_array($type, ['blocks', 'gallery', 'relation', 'relation_many'], true)) {
                continue;
            }

            $fields[] = $this->describeTargetField(
                $id,
                (string) ($field['label'] ?? $id),
                $type,
                (bool) ($field['required'] ?? false),
                false
            ) + array_intersect_key($field, ['granularity' => true, 'extraGranularity' => true]);
        }

        return $fields;
    }

    // =========================================================================
    // FIELD DESCRIPTION
    // =========================================================================

    /**
     * @return array<string, mixed>
     */
    private function describeTargetField(
        string $name,
        string $label,
        string $type,
        bool $required,
        bool $pii,
        bool $discovered = false
    ): array {
        return [
            'name' => $name,
            'label' => $label,
            'type' => $type,
            'required' => $required,
            'pii' => $pii,
            // Whether this name came from a declared schema or was inferred from
            // stored data, so the UI can say so rather than implying certainty.
            'discovered' => $discovered,
            // Precomputed so the heuristic does not have to re-tokenise every
            // target field for every candidate source field (that product is
            // what makes a naive matcher quadratic and slow).
            'canonical' => FieldSynonyms::canonicalFor($name)
                ?? FieldSynonyms::canonicalFor($label),
        ];
    }
}
