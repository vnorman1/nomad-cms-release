<?php
/**
 * NOMAD CMS - Webhook Event Replay Service
 *
 * Re-runs events that are already in the store against the CURRENT rules.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * WHY THIS IS NOT OPTIONAL
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * The whole onboarding flow depends on it. A user connects Cal.com, fires two or
 * three test bookings in LEARNING mode, uses those events to build the mapping,
 * and then goes live. Without replay, those first bookings - the only real data
 * they had to work with - are stranded in the event store forever, and the user's
 * very first impression is "I set it up and nothing appeared".
 *
 * It is also the repair tool. When a mapping was wrong, or a required field was
 * unmapped and a week of events landed as `failed`, replay is what fixes the
 * week rather than asking the provider to re-send.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * THREE PROPERTIES IT MUST HAVE
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * 1. IDEMPOTENT. An event already `mapped` is skipped. Pressing the button twice
 *    must not create two booking records - and a user who is unsure whether the
 *    first click worked WILL press it twice.
 * 2. FAULT-TOLERANT PER ITEM. One bad event does not abort the batch. Otherwise a
 *    single malformed payload from six months ago blocks every later event
 *    behind it, and the failure looks like "replay is broken".
 * 3. BOUNDED. A hard per-run cap, because replay writes to live content and an
 *    unbounded run on a busy endpoint would be a self-inflicted flood.
 *
 * @package NomadCMS\Webhooks\Mapping
 */

declare(strict_types=1);

namespace NomadCMS\Webhooks\Mapping;

use NomadCMS\Security\WebhookService;
use Throwable;

final class ReplayService
{
    /** Events processed per replay call by default */
    public const DEFAULT_BATCH = 25;

    /** Hard ceiling, even if a caller asks for more */
    public const MAX_BATCH = 500;

    private MappingExecutor $executor;
    private WebhookService $webhookService;

    public function __construct(?MappingExecutor $executor = null, ?WebhookService $webhookService = null)
    {
        $this->executor = $executor ?? new MappingExecutor();
        $this->webhookService = $webhookService ?? new WebhookService();
    }

    /**
     * Replay stored events for one endpoint.
     *
     * @param string $endpointSlug
     * @param array{event_ids?: array<int,int>, statuses?: array<int,string>, event_type?: string|null, limit?: int} $options
     * @return array{
     *     endpoint: string,
     *     attempted: int,
     *     mapped: int,
     *     failed: int,
     *     skipped: int,
     *     more_pending: bool,
     *     results: array<int, array<string, mixed>>
     * }
     */
    public function replay(string $endpointSlug, array $options = []): array
    {
        $endpoint = $this->webhookService->getEndpointByKey($endpointSlug);
        if ($endpoint === null) {
            throw new \RuntimeException('Ismeretlen végpont: ' . $endpointSlug);
        }

        $limit = max(1, min(self::MAX_BATCH, (int) ($options['limit'] ?? self::DEFAULT_BATCH)));
        $events = $this->loadReplayable($endpointSlug, $options, $limit);

        $mapped = 0;
        $failed = 0;
        $skipped = 0;
        $results = [];

        foreach ($events as $event) {
            $eventId = (int) $event['id'];

            // Property 1: idempotency. Checked per event rather than filtered in
            // SQL, so an event that got mapped by a concurrent live delivery
            // between the query and this loop is still respected.
            if ($this->executor->alreadyMapped($eventId)) {
                $skipped++;
                $results[] = [
                    'event_id' => $eventId,
                    'outcome' => 'skipped',
                    'message' => 'Ez az esemény már el volt mentve.',
                ];
                continue;
            }

            // Property 2: one bad event must not abort the batch.
            try {
                $payload = json_decode((string) $event['payload'], true);
                if (!is_array($payload)) {
                    throw new \RuntimeException('A tárolt payload nem érvényes JSON.');
                }

                $result = $this->executor->execute(
                    $endpoint,
                    $payload,
                    $eventId,
                    $event['event_type'] !== null ? (string) $event['event_type'] : null
                );

                if ($result->skipped) {
                    $skipped++;
                    $results[] = [
                        'event_id' => $eventId,
                        'outcome' => 'skipped',
                        'message' => (string) $result->error,
                    ];
                } elseif ($result->success) {
                    $mapped++;
                    $results[] = [
                        'event_id' => $eventId,
                        'outcome' => 'mapped',
                        'target' => $result->target,
                        'record_id' => $result->recordId,
                    ];
                } else {
                    $failed++;
                    $results[] = [
                        'event_id' => $eventId,
                        'outcome' => 'failed',
                        'message' => (string) $result->error,
                    ];
                }
            } catch (Throwable $e) {
                $failed++;
                $this->recordFailure($eventId, $e->getMessage());
                $results[] = [
                    'event_id' => $eventId,
                    'outcome' => 'failed',
                    'message' => $e->getMessage(),
                ];
            }
        }

        return [
            'endpoint' => $endpointSlug,
            'attempted' => count($events),
            'mapped' => $mapped,
            'failed' => $failed,
            'skipped' => $skipped,
            'more_pending' => count($events) >= $limit,
            'results' => $results,
        ];
    }

    /**
     * How many events could be replayed right now.
     *
     * Shown before the button is pressed, because "replay 340 events into your
     * live content" is a decision the user should make deliberately.
     *
     * @param array<int, string>|null $statuses
     */
    public function replayableCount(string $endpointSlug, ?array $statuses = null): int
    {
        WebhookEventsSchema::ensureTables();
        $db = WebhookEventsSchema::db();
        $table = WebhookEventsSchema::TABLE_EVENTS;

        $statuses = $this->normaliseStatuses($statuses);
        $placeholders = implode(',', array_fill(0, count($statuses), '?'));

        $stmt = $db->prepare("
            SELECT COUNT(*) FROM {$table}
            WHERE endpoint_slug = ? AND status IN ({$placeholders})
        ");
        $stmt->execute(array_merge([$endpointSlug], $statuses));

        return (int) $stmt->fetchColumn();
    }

    // =========================================================================
    // INTERNALS
    // =========================================================================

    /**
     * @param array<string, mixed> $options
     * @return array<int, array<string, mixed>>
     */
    private function loadReplayable(string $endpointSlug, array $options, int $limit): array
    {
        WebhookEventsSchema::ensureTables();
        $db = WebhookEventsSchema::db();
        $table = WebhookEventsSchema::TABLE_EVENTS;

        // An explicit id list wins: the event inbox lets a user replay ONE row,
        // and that must work regardless of its current status.
        $eventIds = array_values(array_filter(array_map(
            static fn($id) => (int) $id,
            (array) ($options['event_ids'] ?? [])
        )));

        if ($eventIds !== []) {
            $eventIds = array_slice($eventIds, 0, $limit);
            $placeholders = implode(',', array_fill(0, count($eventIds), '?'));

            $stmt = $db->prepare("
                SELECT id, payload, event_type, status FROM {$table}
                WHERE endpoint_slug = ? AND id IN ({$placeholders})
                ORDER BY created_at ASC, id ASC
            ");
            $stmt->execute(array_merge([$endpointSlug], $eventIds));

            return $stmt->fetchAll();
        }

        $statuses = $this->normaliseStatuses($options['statuses'] ?? null);
        $placeholders = implode(',', array_fill(0, count($statuses), '?'));

        $sql = "SELECT id, payload, event_type, status FROM {$table}
                WHERE endpoint_slug = ? AND status IN ({$placeholders})";
        $params = array_merge([$endpointSlug], $statuses);

        $eventType = $options['event_type'] ?? null;
        if (is_string($eventType) && $eventType !== '') {
            $sql .= ' AND event_type = ?';
            $params[] = $eventType;
        }

        // OLDEST first: replaying a booking history in the order it happened is
        // what a human expects, and it makes the resulting inbox read correctly.
        $sql .= ' ORDER BY created_at ASC, id ASC LIMIT ?';
        $params[] = $limit;

        $stmt = $db->prepare($sql);
        $stmt->execute($params);

        return $stmt->fetchAll();
    }

    /**
     * Which statuses are eligible when the caller does not say.
     *
     * `mapped` is deliberately absent from the default: those are already
     * written, and including them would make the common "replay everything"
     * button look like it did a lot of work while every item was skipped.
     *
     * @param array<int, string>|null $statuses
     * @return array<int, string>
     */
    private function normaliseStatuses(?array $statuses): array
    {
        $default = [
            WebhookEventsSchema::STATUS_UNVERIFIED,
            WebhookEventsSchema::STATUS_VERIFIED,
            WebhookEventsSchema::STATUS_FAILED,
        ];

        if ($statuses === null || $statuses === []) {
            return $default;
        }

        $valid = array_values(array_intersect($statuses, WebhookEventsSchema::STATUSES));

        return $valid === [] ? $default : $valid;
    }

    private function recordFailure(int $eventId, string $error): void
    {
        try {
            $table = WebhookEventsSchema::TABLE_EVENTS;
            WebhookEventsSchema::db()->prepare("
                UPDATE {$table} SET status = ?, error = ? WHERE id = ?
            ")->execute([
                WebhookEventsSchema::STATUS_FAILED,
                mb_substr($error, 0, 1000),
                $eventId,
            ]);
        } catch (Throwable $e) {
            error_log('[WebhookMapping] Replay failure bookkeeping failed: ' . $e->getMessage());
        }
    }
}
