<?php
/**
 * NOMAD CMS - Payload Normalizer (provider adapters)
 *
 * Rewrites a recognised provider payload into a STABLE namespace that a mapping
 * rule can be bound to safely.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * WHY THIS LAYER EXISTS AT ALL
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * Without it, Typeform mapping is silently, permanently wrong. Typeform's own
 * documentation states:
 *
 *     "The answers array is populated only with answered questions. If a
 *      question isn't answered because it's not required or it's skipped by a
 *      Logic Jump, it won't be in the webhook payload."
 *
 * So a user who maps `$.form_response.answers[1].email` against their first
 * test submission is, on the next submission where an earlier optional question
 * was skipped, mapping a COMPLETELY DIFFERENT question - with no error, no
 * warning, and a plausible-looking value in the wrong column. The stable
 * identifier is `answers[].field.id`, and the question text lives in a separate
 * `definition.fields[]` array joined on that same id.
 *
 * Addressing that needs a filter expression (`answers[?(@.field.id=='X')]`).
 * The project's existing JSONPath engine (PayloadMapper) supports `[0]`,
 * `[-1]` and `[*]` but not filters - verified in its parsePathSegments(). Two
 * options followed: extend the engine, or normalise before mapping.
 *
 * Normalising was chosen deliberately. PayloadMapper is already relied upon by
 * the webhook ACTION system, so adding a new expression grammar to it puts
 * existing, working chains at risk for a benefit only this feature needs. An
 * adapter in front is additive: unrecognised payloads pass through untouched,
 * and the engine keeps its current semantics exactly.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * WHAT ELSE THE ADAPTERS FIX
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * Cal.com  `responses.email` is a {label, value, isHidden} WRAPPER, not a
 *          value - and on a hidden field the `value` key is absent entirely
 *          (not null), so naive traversal warns. The adapter unwraps it, and
 *          also unwraps the doubly-nested `location.value.value` shape.
 *
 * Cal.com  BOOKING_* payloads nest everything under `payload`, while
 *          MEETING_STARTED / MEETING_ENDED are FLAT. A rule bound to
 *          `$.payload.startTime` cannot work for the flat variants. The adapter
 *          produces identical keys for both, so ONE rule covers every trigger.
 *
 * Cal.com  the payload carries two emails - `organizer.email` (the CMS owner)
 *          and `attendees[0].email` (the customer). The adapter promotes the
 *          customer to `attendee.*` and leaves the owner under `organizer.*`,
 *          which is what lets the heuristic pick the right one by role instead
 *          of by luck.
 *
 * Stripe   `customer_email` is usually null while `customer_details.email`
 *          holds the real address. The adapter coalesces them into
 *          `customer.email`, so the user is not offered two candidates of which
 *          one is always empty.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * WHAT IT DELIBERATELY DOES NOT DO
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * It does not key Typeform answers by `ref`. Typeform documents that a ref is
 * only persistent when the form was built through the Create API; forms built
 * in the admin panel get a SYSTEM-GENERATED ref that "will be different in
 * every payload". Using it would reintroduce the exact instability this class
 * exists to remove.
 *
 * It does not convert units or reformat dates. `amount.total` stays in minor
 * units. That is a per-rule decision (see WebhookEventsSchema::TRANSFORMS),
 * because whether 2198 should land as 2198 or 21.98 depends on the target
 * field, not on the provider.
 *
 * @package NomadCMS\Webhooks\Mapping
 */

declare(strict_types=1);

namespace NomadCMS\Webhooks\Mapping;

/**
 * The result of normalising one payload.
 */
final class NormalizedPayload
{
    /**
     * @param string $provider One of PayloadNormalizer::PROVIDERS
     * @param array<string, mixed> $data The stable namespace (nested arrays)
     * @param array<string, string> $labels Dotted normalized path => human label
     *                                      supplied BY THE PROVIDER (not guessed)
     */
    public function __construct(
        public readonly string $provider,
        public readonly array $data,
        public readonly array $labels = [],
        public readonly ?string $eventType = null
    ) {}

    public function isGeneric(): bool
    {
        return $this->provider === PayloadNormalizer::PROVIDER_GENERIC;
    }

    /**
     * Human label for a normalized path, when the provider gave us one.
     */
    public function labelFor(string $path): ?string
    {
        return $this->labels[$path] ?? null;
    }
}

final class PayloadNormalizer
{
    public const PROVIDER_CALCOM = 'calcom';
    public const PROVIDER_TYPEFORM = 'typeform';
    public const PROVIDER_STRIPE = 'stripe';
    public const PROVIDER_GENERIC = 'generic';

    /** @var array<int, string> */
    public const PROVIDERS = [
        self::PROVIDER_CALCOM,
        self::PROVIDER_TYPEFORM,
        self::PROVIDER_STRIPE,
        self::PROVIDER_GENERIC,
    ];

    /**
     * Human-readable provider names for the UI.
     *
     * @var array<string, string>
     */
    public const PROVIDER_LABELS = [
        self::PROVIDER_CALCOM => 'Cal.com',
        self::PROVIDER_TYPEFORM => 'Typeform',
        self::PROVIDER_STRIPE => 'Stripe',
        self::PROVIDER_GENERIC => 'Egyéb szolgáltatás',
    ];

    // =========================================================================
    // DETECTION
    // =========================================================================

    /**
     * Identify the provider from structural markers only.
     *
     * Deliberately not based on headers or User-Agent: a replayed event read
     * back out of the store has neither, and the normalizer must behave
     * identically for a live delivery and a replay of the same bytes.
     */
    public static function detect(array $payload): string
    {
        // Cal.com is the only one of the three that uses `triggerEvent`, in both
        // its wrapped and flat shapes.
        if (isset($payload['triggerEvent'])) {
            return self::PROVIDER_CALCOM;
        }

        if (isset($payload['form_response']) && is_array($payload['form_response'])) {
            return self::PROVIDER_TYPEFORM;
        }
        if (($payload['event_type'] ?? null) === 'form_response') {
            return self::PROVIDER_TYPEFORM;
        }

        // Stripe: an Event envelope wrapping a resource that names its own type.
        $object = $payload['data']['object'] ?? null;
        if (is_array($object) && isset($object['object']) && isset($payload['type'])) {
            return self::PROVIDER_STRIPE;
        }

        return self::PROVIDER_GENERIC;
    }

    // =========================================================================
    // ENTRY POINT
    // =========================================================================

    public function normalize(array $payload): NormalizedPayload
    {
        return match (self::detect($payload)) {
            self::PROVIDER_CALCOM => $this->normalizeCalcom($payload),
            self::PROVIDER_TYPEFORM => $this->normalizeTypeform($payload),
            self::PROVIDER_STRIPE => $this->normalizeStripe($payload),
            default => new NormalizedPayload(
                self::PROVIDER_GENERIC,
                $payload,
                [],
                $payload['event'] ?? $payload['event_type'] ?? null
            ),
        };
    }

    // =========================================================================
    // CAL.COM
    // =========================================================================

    private function normalizeCalcom(array $payload): NormalizedPayload
    {
        $trigger = is_string($payload['triggerEvent'] ?? null) ? $payload['triggerEvent'] : null;

        // The single most important line in this adapter: collapse the wrapped
        // and flat shapes into one booking array, so `booking.startTime` means
        // the same thing for BOOKING_CREATED and MEETING_STARTED alike.
        $booking = (isset($payload['payload']) && is_array($payload['payload']))
            ? $payload['payload']
            : $payload;

        $data = [];
        $labels = [];

        // --- Booking scalars -------------------------------------------------
        foreach ([
            'title' => 'title',
            'startTime' => 'startTime',
            'endTime' => 'endTime',
            'status' => 'status',
            'uid' => 'uid',
            'location' => 'location',
            'additionalNotes' => 'additionalNotes',
            'description' => 'description',
            'price' => 'price',
            'currency' => 'currency',
            'length' => 'length',
            'eventTitle' => 'eventTitle',
            'eventTypeId' => 'eventTypeId',
            'bookingId' => 'bookingId',
            'cancellationReason' => 'cancellationReason',
            'rejectionReason' => 'rejectionReason',
        ] as $source => $target) {
            if (array_key_exists($source, $booking) && !is_array($booking[$source])) {
                $data['booking'][$target] = $booking[$source];
            }
        }

        // --- The customer -----------------------------------------------------
        // attendees[0] is the booker. Promoting it to a first-class `attendee.*`
        // namespace is what makes the customer/owner distinction legible to both
        // the heuristic and the human reading the mapper table.
        $attendees = is_array($booking['attendees'] ?? null) ? $booking['attendees'] : [];
        $firstAttendee = is_array($attendees[0] ?? null) ? $attendees[0] : [];

        foreach (['email', 'name', 'firstName', 'lastName', 'phoneNumber', 'timeZone'] as $key) {
            if (array_key_exists($key, $firstAttendee) && !is_array($firstAttendee[$key])) {
                $data['attendee'][$key] = $firstAttendee[$key];
            }
        }
        if ($attendees !== []) {
            // Kept whole so an advanced user can still address extra guests.
            $data['attendees'] = $attendees;
        }

        // --- The CMS owner ----------------------------------------------------
        // `organizer` in wrapped payloads, `user` in the flat MEETING_* ones.
        $organizer = is_array($booking['organizer'] ?? null)
            ? $booking['organizer']
            : (is_array($booking['user'] ?? null) ? $booking['user'] : []);

        foreach (['email', 'name', 'username', 'timeZone'] as $key) {
            if (array_key_exists($key, $organizer) && !is_array($organizer[$key])) {
                $data['organizer'][$key] = $organizer[$key];
            }
        }

        // --- Booking form answers --------------------------------------------
        $responses = is_array($booking['responses'] ?? null) ? $booking['responses'] : [];
        foreach ($responses as $key => $wrapper) {
            $safeKey = $this->safeKey((string) $key);
            if ($safeKey === null) {
                continue;
            }

            if (!is_array($wrapper)) {
                // Some triggers (INSTANT_MEETING) send plain scalars here.
                $data['responses'][$safeKey] = $wrapper;
                continue;
            }

            // array_key_exists, not isset/??: on a hidden field the `value` key
            // is genuinely ABSENT, and we want to record "this field exists but
            // carried nothing" rather than skip it - the mapper UI showing an
            // empty field is more honest than pretending it does not exist.
            $value = array_key_exists('value', $wrapper) ? $wrapper['value'] : null;
            $data['responses'][$safeKey] = $this->unwrapNestedValue($value);

            // The provider's own label beats any synonym dictionary we could
            // write, because it is the text the person filling the form read.
            if (isset($wrapper['label']) && is_string($wrapper['label']) && $wrapper['label'] !== '') {
                $labels['responses.' . $safeKey] = $this->humaniseProviderLabel($wrapper['label']);
            }
        }

        // --- Event metadata ---------------------------------------------------
        if ($trigger !== null) {
            $data['event']['trigger'] = $trigger;
        }
        if (isset($payload['createdAt']) && is_string($payload['createdAt'])) {
            $data['event']['createdAt'] = $payload['createdAt'];
        }
        if (isset($booking['metadata']) && is_array($booking['metadata'])) {
            $data['metadata'] = $booking['metadata'];
        }

        return new NormalizedPayload(self::PROVIDER_CALCOM, $data, $labels, $trigger);
    }

    /**
     * Cal.com sometimes nests a value inside another {value: ...} object
     * (e.g. location => {value: {optionValue: '', value: 'integrations:...'}}).
     * Reduce that to the innermost scalar so a mapping rule gets a usable value.
     */
    private function unwrapNestedValue(mixed $value): mixed
    {
        $guard = 0;
        while (is_array($value) && array_key_exists('value', $value) && $guard < 5) {
            $value = $value['value'];
            $guard++;
        }

        return $value;
    }

    // =========================================================================
    // TYPEFORM
    // =========================================================================

    private function normalizeTypeform(array $payload): NormalizedPayload
    {
        $response = is_array($payload['form_response'] ?? null) ? $payload['form_response'] : [];
        $definition = is_array($response['definition'] ?? null) ? $response['definition'] : [];
        $fields = is_array($definition['fields'] ?? null) ? $definition['fields'] : [];
        $answers = is_array($response['answers'] ?? null) ? $response['answers'] : [];

        $data = [];
        $labels = [];

        // --- The whole point: index answers by FIELD ID -----------------------
        // Every answer becomes answers.<FIELD_ID>, which resolves to the same
        // question no matter how many optional questions the respondent skipped.
        $answersByFieldId = [];
        foreach ($answers as $answer) {
            if (!is_array($answer)) {
                continue;
            }
            $fieldId = $answer['field']['id'] ?? null;
            if (!is_string($fieldId) || $fieldId === '') {
                continue;
            }
            $safeId = $this->safeKey($fieldId);
            if ($safeId === null) {
                continue;
            }
            $answersByFieldId[$safeId] = $this->typeformAnswerValue($answer);
        }

        // Emit EVERY declared question, not just the answered ones. A field the
        // respondent skipped this time still needs to appear in the mapper table
        // (otherwise the available field list would flicker between events), so
        // it is emitted as null.
        foreach ($fields as $field) {
            if (!is_array($field)) {
                continue;
            }
            $fieldId = $field['id'] ?? null;
            if (!is_string($fieldId) || $fieldId === '') {
                continue;
            }
            $safeId = $this->safeKey($fieldId);
            if ($safeId === null) {
                continue;
            }

            $data['answers'][$safeId] = $answersByFieldId[$safeId] ?? null;

            // definition.fields[].title is the actual question text - by far the
            // best label source available anywhere in this feature.
            if (isset($field['title']) && is_string($field['title']) && $field['title'] !== '') {
                $labels['answers.' . $safeId] = $this->truncateLabel($field['title']);
            }
        }

        // Answers whose field is absent from the definition (should not happen,
        // but a payload we cannot fully explain must not lose data).
        foreach ($answersByFieldId as $safeId => $value) {
            if (!isset($data['answers'][$safeId])) {
                $data['answers'][$safeId] = $value;
            }
        }

        // --- Metadata ---------------------------------------------------------
        foreach (['form_id' => 'id', 'token' => 'token', 'submitted_at' => 'submittedAt', 'landed_at' => 'landedAt'] as $src => $dst) {
            if (isset($response[$src]) && !is_array($response[$src])) {
                $data['form'][$dst] = $response[$src];
            }
        }
        if (isset($definition['title']) && is_string($definition['title'])) {
            $data['form']['title'] = $definition['title'];
        }

        // Hidden fields are a documented, deliberately-populated channel
        // (UTM parameters, internal user ids) and are frequently what a user
        // most wants to map, so they get first-class paths.
        if (is_array($response['hidden'] ?? null)) {
            foreach ($response['hidden'] as $key => $value) {
                $safeKey = $this->safeKey((string) $key);
                if ($safeKey !== null && !is_array($value)) {
                    $data['hidden'][$safeKey] = $value;
                }
            }
        }

        if (isset($response['calculated']['score'])) {
            $data['form']['score'] = $response['calculated']['score'];
        }

        if (isset($payload['event_id']) && is_string($payload['event_id'])) {
            $data['event']['id'] = $payload['event_id'];
        }
        $eventType = is_string($payload['event_type'] ?? null) ? $payload['event_type'] : null;
        if ($eventType !== null) {
            $data['event']['type'] = $eventType;
        }

        return new NormalizedPayload(self::PROVIDER_TYPEFORM, $data, $labels, $eventType);
    }

    /**
     * Reduce one Typeform answer object to a single scalar (or array of labels).
     *
     * Typeform puts the value under a key NAMED AFTER the answer type, which is
     * why a generic flattener produces `answers[3].date` for one form and
     * `answers[3].number` for the next.
     */
    private function typeformAnswerValue(array $answer): mixed
    {
        $type = is_string($answer['type'] ?? null) ? $answer['type'] : null;

        // Structured types first - their value is not at $answer[$type] directly.
        if ($type === 'choice') {
            return $answer['choice']['label'] ?? $answer['choice']['other'] ?? null;
        }
        if ($type === 'choices') {
            $choices = $answer['choices'] ?? null;
            if (is_array($choices)) {
                // Multi-select shape: {ids, labels, refs, other?}
                if (isset($choices['labels']) && is_array($choices['labels'])) {
                    $labels = $choices['labels'];
                    if (isset($choices['other']) && is_string($choices['other'])) {
                        $labels[] = $choices['other'];
                    }
                    return $labels;
                }
                // Checkbox shape: a list of {id, label, ref}
                $labels = [];
                foreach ($choices as $choice) {
                    if (is_array($choice) && isset($choice['label'])) {
                        $labels[] = $choice['label'];
                    }
                }
                return $labels === [] ? null : $labels;
            }
            return null;
        }
        if ($type === 'signature') {
            return $answer['signature']['url'] ?? null;
        }
        if ($type === 'payment') {
            return $answer['payment']['amount'] ?? null;
        }
        if ($type === 'multi_format') {
            $mf = is_array($answer['multi_format'] ?? null) ? $answer['multi_format'] : [];
            return $mf['text'] ?? $mf['transcript'] ?? null;
        }

        // Scalar types: the value sits at the key named after the type
        // (text, email, date, number, boolean, url, file_url, phone_number).
        if ($type !== null && array_key_exists($type, $answer) && !is_array($answer[$type])) {
            return $answer[$type];
        }

        // Last resort for a type we have never seen: take the first scalar that
        // is not bookkeeping. Better a mappable value than silently nothing.
        foreach ($answer as $key => $value) {
            if (in_array($key, ['type', 'field', 'answer_url'], true)) {
                continue;
            }
            if (!is_array($value)) {
                return $value;
            }
        }

        return null;
    }

    // =========================================================================
    // STRIPE
    // =========================================================================

    private function normalizeStripe(array $payload): NormalizedPayload
    {
        $object = is_array($payload['data']['object'] ?? null) ? $payload['data']['object'] : [];
        $details = is_array($object['customer_details'] ?? null) ? $object['customer_details'] : [];

        $data = [];
        $labels = [];

        // --- Resolve the customer once ---------------------------------------
        // customer_email is the PREFILL parameter and is usually null on a
        // completed session; customer_details.email is what the buyer actually
        // entered. Offering both to a non-technical user would guarantee that
        // half of them pick the one that is always empty.
        $email = $this->firstNonEmpty([
            $details['email'] ?? null,
            $object['customer_email'] ?? null,
        ]);
        if ($email !== null) {
            $data['customer']['email'] = $email;
        }
        foreach (['name' => 'name', 'phone' => 'phone'] as $src => $dst) {
            if (isset($details[$src]) && !is_array($details[$src])) {
                $data['customer'][$dst] = $details[$src];
            }
        }
        if (is_array($details['address'] ?? null)) {
            foreach ($details['address'] as $key => $value) {
                $safeKey = $this->safeKey((string) $key);
                if ($safeKey !== null && !is_array($value)) {
                    $data['customer']['address'][$safeKey] = $value;
                }
            }
        }
        if (isset($object['customer']) && is_string($object['customer'])) {
            $data['customer']['id'] = $object['customer'];
        }

        // --- Money -------------------------------------------------------------
        // Still MINOR units. Converting here would be wrong: whether 2198 should
        // become 21.98 depends on the target field's type, so it is a per-rule
        // transform (TRANSFORM_MINOR_TO_MAJOR), proposed by the heuristic.
        foreach (['amount_total' => 'total', 'amount_subtotal' => 'subtotal'] as $src => $dst) {
            if (isset($object[$src]) && !is_array($object[$src])) {
                $data['amount'][$dst] = $object[$src];
            }
        }
        if (isset($object['currency']) && is_string($object['currency'])) {
            $data['amount']['currency'] = $object['currency'];
        }

        // --- Order / session ---------------------------------------------------
        foreach ([
            'id' => 'id',
            'payment_status' => 'paymentStatus',
            'status' => 'status',
            'mode' => 'mode',
            'client_reference_id' => 'reference',
            'payment_intent' => 'paymentIntent',
            'invoice' => 'invoice',
            'subscription' => 'subscription',
        ] as $src => $dst) {
            if (array_key_exists($src, $object) && !is_array($object[$src])) {
                $data['order'][$dst] = $object[$src];
            }
        }

        if (is_array($object['metadata'] ?? null)) {
            foreach ($object['metadata'] as $key => $value) {
                $safeKey = $this->safeKey((string) $key);
                if ($safeKey !== null && !is_array($value)) {
                    $data['metadata'][$safeKey] = $value;
                }
            }
        }

        $eventType = is_string($payload['type'] ?? null) ? $payload['type'] : null;
        if ($eventType !== null) {
            $data['event']['type'] = $eventType;
        }
        if (isset($payload['id']) && is_string($payload['id'])) {
            $data['event']['id'] = $payload['id'];
        }
        if (isset($object['object']) && is_string($object['object'])) {
            $data['event']['resource'] = $object['object'];
        }

        return new NormalizedPayload(self::PROVIDER_STRIPE, $data, $labels, $eventType);
    }

    // =========================================================================
    // HELPERS
    // =========================================================================

    /**
     * Reject keys that would break dotted-path addressing.
     *
     * A provider key containing '.', '[' or ']' cannot be addressed by the
     * JSONPath engine without ambiguity, so it is dropped from the normalized
     * namespace rather than silently producing a path that resolves to
     * something else. Such keys remain reachable through the RAW namespace.
     */
    private function safeKey(string $key): ?string
    {
        if ($key === '' || strlen($key) > 128) {
            return null;
        }

        return preg_match('/^[A-Za-z0-9_-]+$/', $key) === 1 ? $key : null;
    }

    /**
     * @param array<int, mixed> $candidates
     */
    private function firstNonEmpty(array $candidates): mixed
    {
        foreach ($candidates as $candidate) {
            if ($candidate !== null && $candidate !== '') {
                return $candidate;
            }
        }

        return null;
    }

    /**
     * Cal.com labels arrive as snake_case tokens ('email_address',
     * 'additional_notes'). Turn them into something a human reads as a label.
     */
    private function humaniseProviderLabel(string $label): string
    {
        if (str_contains($label, ' ')) {
            // Already a sentence (custom booking questions) - leave it alone.
            return $this->truncateLabel($label);
        }

        return $this->truncateLabel(ucfirst(str_replace(['_', '-'], ' ', $label)));
    }

    private function truncateLabel(string $label): string
    {
        $label = trim(preg_replace('/\s+/', ' ', $label) ?? $label);

        return mb_strlen($label) > 120 ? mb_substr($label, 0, 117) . '…' : $label;
    }
}
