<?php
/**
 * NOMAD CMS - Webhook Event Retention Service
 *
 * Sweeps the raw event store and closes stale learning windows.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * WHY RETENTION IS THE PRIMARY PII CONTROL HERE
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * webhook_events.payload is stored as plaintext JSON on purpose: the mapper UI
 * has to read it to show a user which fields arrived, and the heuristic has to
 * sample it to score candidates. Encryption would defeat both and rule out
 * SQLite JSON1 access.
 *
 * That choice is only defensible because the data does not linger. So the sweep
 * deletes events of EVERY status once they pass the window - including
 * `mapped` ones. That deserves saying out loud, because "keep what we
 * successfully processed" is the intuitive rule and it is the wrong one here:
 * a mapped event's durable copy already lives in the target (for an encrypted
 * Form, inside the Forms envelope ciphertext), so retaining the raw payload
 * afterwards keeps a SECOND, unencrypted copy of the same personal data for no
 * operational gain. The audit trail we actually need - which endpoint produced
 * which record - survives in mapped_target / mapped_record_id, and those are
 * not personal data.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * WHY THIS MODULE HAS A DEFAULT WINDOW AND FORMS DOES NOT
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * FormRetentionService deliberately refuses to assume a default: silently
 * deleting a business's leads because a setting happened to default to 30 days
 * would be worse than keeping them. A form submission is the record itself.
 *
 * A webhook event is not the record - it is the envelope the record arrived in.
 * Keeping envelopes forever has no business value, and an unbounded plaintext
 * PII table has real cost. So this module DOES default (30 days,
 * WebhookEventsSchema::DEFAULT_RETENTION_DAYS), overridable via
 * WEBHOOK_EVENT_RETENTION_DAYS.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * TWO INDEPENDENT BOUNDS
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * 1. TIME (retention window) - the PII control described above.
 * 2. ROW COUNT per endpoint (MAX_EVENTS_PER_ENDPOINT) - a burst control, so one
 *    chatty endpoint cannot fill the database inside a single window.
 *
 * Eviction under (2) removes the oldest NON-mapped rows first. Within the
 * window, a mapped event is the more useful one to keep (it explains where a
 * record came from), so a flood of unmapped noise should not push it out.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * HOW IT RUNS WITHOUT CRON
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * Same piggyback mechanism the rest of the project uses
 * (bootstrap.php::registerPiggybackProcessing(), after
 * fastcgi_finish_request() so no visitor ever waits), sampled and hard-capped.
 * A manual trigger also exists on the admin endpoint.
 *
 * @package NomadCMS\Webhooks\Mapping
 */

declare(strict_types=1);

namespace NomadCMS\Webhooks\Mapping;

use NomadCMS\Database\AuthDatabase;
use Throwable;

final class WebhookEventRetentionService
{
    /** Rows removed per sweep by default */
    public const DEFAULT_MAX_PER_RUN = 500;

    /** Hard cap for a manually triggered sweep */
    public const MAX_PER_RUN = 20000;

    /** Percentage of requests that trigger a piggyback sweep */
    private const PIGGYBACK_SAMPLE_PERCENT = 2;

    /**
     * Run a full maintenance pass.
     *
     * @param int $maxRows Ceiling on rows deleted in this run
     * @return array{
     *     retention_days:int,
     *     expired_deleted:int,
     *     evicted:int,
     *     endpoints_closed:int,
     *     more_pending:bool
     * }
     */
    public static function sweep(int $maxRows = self::DEFAULT_MAX_PER_RUN): array
    {
        $maxRows = max(1, min(self::MAX_PER_RUN, $maxRows));
        $retentionDays = self::retentionDays();

        $expiredDeleted = self::deleteExpired($retentionDays, $maxRows);

        // Whatever budget is left goes to cap enforcement, so a single run can
        // never delete more than the caller allowed.
        $remaining = max(0, $maxRows - $expiredDeleted);
        $evicted = $remaining > 0 ? self::enforcePerEndpointCap($remaining) : 0;

        $closed = self::closeExpiredLearningWindows();

        $summary = [
            'retention_days' => $retentionDays,
            'expired_deleted' => $expiredDeleted,
            'evicted' => $evicted,
            'endpoints_closed' => $closed,
            'more_pending' => ($expiredDeleted + $evicted) >= $maxRows,
        ];

        if ($expiredDeleted > 0 || $evicted > 0 || $closed > 0) {
            error_log('[WebhookMapping] Retention sweep: ' . json_encode($summary));
        }

        return $summary;
    }

    /**
     * Report what a sweep WOULD do, without touching anything.
     *
     * Used by the admin UI so an operator can see the cost before triggering a
     * manual run.
     *
     * @return array{retention_days:int, expired:int, over_cap:int, total:int, learning_open:int}
     */
    public static function preview(): array
    {
        WebhookEventsSchema::ensureTables();
        $db = WebhookEventsSchema::db();
        $table = WebhookEventsSchema::TABLE_EVENTS;
        $retentionDays = self::retentionDays();

        $expiredStmt = $db->prepare("SELECT COUNT(*) FROM {$table} WHERE created_at < ?");
        $expiredStmt->execute([self::cutoff($retentionDays)]);

        $total = (int) $db->query("SELECT COUNT(*) FROM {$table}")->fetchColumn();

        $overCap = 0;
        foreach (self::endpointRowCounts() as $count) {
            if ($count > WebhookEventsSchema::MAX_EVENTS_PER_ENDPOINT) {
                $overCap += $count - WebhookEventsSchema::MAX_EVENTS_PER_ENDPOINT;
            }
        }

        return [
            'retention_days' => $retentionDays,
            'expired' => (int) $expiredStmt->fetchColumn(),
            'over_cap' => $overCap,
            'total' => $total,
            'learning_open' => self::openLearningEndpointCount(),
        ];
    }

    // =========================================================================
    // TIME-BASED RETENTION
    // =========================================================================

    /**
     * Delete every event older than the window, regardless of status.
     *
     * The subselect-with-LIMIT shape keeps one sweep bounded even on a table
     * that has been neglected for months, so a first run after an upgrade
     * cannot lock massive.sqlite for a long time.
     */
    private static function deleteExpired(int $retentionDays, int $maxRows): int
    {
        WebhookEventsSchema::ensureTables();
        $db = WebhookEventsSchema::db();
        $table = WebhookEventsSchema::TABLE_EVENTS;

        $stmt = $db->prepare("
            DELETE FROM {$table}
            WHERE id IN (
                SELECT id FROM {$table}
                WHERE created_at < ?
                ORDER BY created_at ASC
                LIMIT ?
            )
        ");
        $stmt->execute([self::cutoff($retentionDays), $maxRows]);

        return $stmt->rowCount();
    }

    // =========================================================================
    // PER-ENDPOINT CAP
    // =========================================================================

    /**
     * Trim any endpoint that holds more than MAX_EVENTS_PER_ENDPOINT rows.
     *
     * Ordering is `status = 'mapped'` ASC first, then created_at ASC: unmapped
     * noise goes before a mapped event of the same age.
     */
    private static function enforcePerEndpointCap(int $budget): int
    {
        WebhookEventsSchema::ensureTables();
        $db = WebhookEventsSchema::db();
        $table = WebhookEventsSchema::TABLE_EVENTS;
        $cap = WebhookEventsSchema::MAX_EVENTS_PER_ENDPOINT;

        $removed = 0;

        foreach (self::endpointRowCounts() as $slug => $count) {
            if ($budget <= 0) {
                break;
            }
            if ($count <= $cap) {
                continue;
            }

            $excess = min($count - $cap, $budget);

            $stmt = $db->prepare("
                DELETE FROM {$table}
                WHERE id IN (
                    SELECT id FROM {$table}
                    WHERE endpoint_slug = ?
                    ORDER BY (status = ?) ASC, created_at ASC
                    LIMIT ?
                )
            ");
            $stmt->execute([$slug, WebhookEventsSchema::STATUS_MAPPED, $excess]);

            $deleted = $stmt->rowCount();
            $removed += $deleted;
            $budget -= $deleted;
        }

        return $removed;
    }

    /**
     * @return array<string, int> endpoint_slug => row count
     */
    private static function endpointRowCounts(): array
    {
        WebhookEventsSchema::ensureTables();
        $db = WebhookEventsSchema::db();
        $table = WebhookEventsSchema::TABLE_EVENTS;

        $rows = $db->query("
            SELECT endpoint_slug, COUNT(*) AS c
            FROM {$table}
            GROUP BY endpoint_slug
        ")->fetchAll();

        $counts = [];
        foreach ($rows as $row) {
            $counts[(string) $row['endpoint_slug']] = (int) $row['c'];
        }

        return $counts;
    }

    // =========================================================================
    // LEARNING WINDOW
    // =========================================================================

    /**
     * Flip endpoints whose learning window has elapsed to live mode.
     *
     * EventIngestService::effectiveMode() already TREATS such an endpoint as
     * live, so this changes no behaviour - it makes the stored state agree with
     * the enforced state. That matters for honesty in the UI: an admin looking
     * at the endpoint list must not see "Teszt mód" next to an endpoint that
     * has in fact been rejecting unsigned traffic for a week.
     *
     * A learning endpoint with a NULL window is closed too, matching the
     * fail-closed reading in effectiveMode().
     */
    public static function closeExpiredLearningWindows(): int
    {
        try {
            $db = AuthDatabase::getInstance();
            $stmt = $db->prepare("
                UPDATE webhook_endpoints
                SET ingest_mode = ?
                WHERE ingest_mode = ?
                  AND (learning_expires_at IS NULL OR learning_expires_at < ?)
            ");
            $stmt->execute([
                WebhookEventsSchema::MODE_LIVE,
                WebhookEventsSchema::MODE_LEARNING,
                gmdate('c'),
            ]);

            return $stmt->rowCount();
        } catch (Throwable $e) {
            error_log('[WebhookMapping] Learning window close failed: ' . $e->getMessage());
            return 0;
        }
    }

    /**
     * Endpoints still genuinely inside their learning window.
     */
    public static function openLearningEndpointCount(): int
    {
        try {
            $db = AuthDatabase::getInstance();
            $stmt = $db->prepare("
                SELECT COUNT(*) FROM webhook_endpoints
                WHERE ingest_mode = ?
                  AND learning_expires_at IS NOT NULL
                  AND learning_expires_at >= ?
            ");
            $stmt->execute([WebhookEventsSchema::MODE_LEARNING, gmdate('c')]);

            return (int) $stmt->fetchColumn();
        } catch (Throwable $e) {
            return 0;
        }
    }

    // =========================================================================
    // CONFIG
    // =========================================================================

    /**
     * Effective retention window in days.
     *
     * Clamped to at least 1 day: a misconfigured 0 must not turn the sweep into
     * "delete everything on the next request", which would silently destroy the
     * mapper's field samples and make the UI look broken.
     */
    public static function retentionDays(): int
    {
        $configured = $_ENV['WEBHOOK_EVENT_RETENTION_DAYS'] ?? null;

        if ($configured === null || !is_numeric($configured)) {
            return WebhookEventsSchema::DEFAULT_RETENTION_DAYS;
        }

        return max(1, min(3650, (int) $configured));
    }

    private static function cutoff(int $retentionDays): string
    {
        return gmdate('Y-m-d H:i:s', time() - ($retentionDays * 86400));
    }

    // =========================================================================
    // PIGGYBACK
    // =========================================================================

    /**
     * Entry point for the piggyback shutdown handler.
     *
     * Fully guarded: this runs AFTER the response is flushed, so a throw here
     * would be invisible to the user yet could still abort other queued work.
     */
    public static function piggyback(): void
    {
        try {
            if (random_int(1, 100) > self::PIGGYBACK_SAMPLE_PERCENT) {
                return;
            }

            // Skip entirely on installations that never received a webhook, so
            // this costs one cheap COUNT rather than a sweep.
            if (!self::hasAnyEvents()) {
                // Still worth closing stale learning windows: an endpoint could
                // have been created and never called.
                self::closeExpiredLearningWindows();
                return;
            }

            self::sweep(200);
        } catch (Throwable $e) {
            error_log('[WebhookMapping] Retention piggyback error: ' . $e->getMessage());
        }
    }

    public static function hasAnyEvents(): bool
    {
        try {
            WebhookEventsSchema::ensureTables();
            $table = WebhookEventsSchema::TABLE_EVENTS;

            return (int) WebhookEventsSchema::db()
                ->query("SELECT EXISTS(SELECT 1 FROM {$table} LIMIT 1)")
                ->fetchColumn() === 1;
        } catch (Throwable $e) {
            return false;
        }
    }
}
