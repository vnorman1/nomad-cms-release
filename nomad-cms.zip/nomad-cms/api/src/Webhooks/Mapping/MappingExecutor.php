<?php
/**
 * NOMAD CMS - Mapping Executor
 *
 * Turns approved rules into an actual record in the chosen destination.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * IT REUSES THE EXISTING JSONPATH ENGINE
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * Rules are compiled into the `[target_field => source_path]` shape that
 * {@see \NomadCMS\Webhooks\PayloadMapper} already consumes, and evaluated by it.
 * No second expression engine is introduced: the webhook ACTION system depends
 * on that class, and two evaluators with subtly different semantics would be a
 * permanent source of "it works in the mapper preview but not live" bugs.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * WHY IT DOES NOT DELEGATE TO CreateContentAction
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * The obvious reuse candidate would have been the existing
 * Actions\Content\CreateContentAction. It cannot be used for massive slots,
 * because its createMassiveContent() does:
 *
 *     $massive = new MassiveDatabase($slot);
 *     $id = $massive->insert($data);
 *
 * MassiveDatabase has no constructor and its insert() signature is
 * insert(string $slotKey, array $data, ...) - so that call raises a TypeError
 * ("Argument #1 ($slotKey) must be of type string, array given"). Verified
 * against the real class before writing this. Building the automapper's live
 * write path on top of a method that throws would have made every massive
 * mapping fail in production while the unit tests of the mapper itself passed.
 *
 * This executor therefore calls the storage APIs directly, with their real
 * signatures. The pre-existing bug in CreateContentAction is left alone rather
 * than fixed in passing - it belongs to the action system and touching it here
 * would mean changing behaviour of chains nobody asked us to change.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * TWO GATES BEFORE ANY WRITE
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * 1. MODE. Learning mode never writes. This is checked here as well as in the
 *    ingest, because replay also comes through this class and must obey the same
 *    rule.
 * 2. TARGET EXISTS. A rule pointing at a deleted form fails loudly with a
 *    message naming the form, instead of silently dropping the event. Silent
 *    drops are the worst possible failure for this feature: the user believes
 *    their bookings are being recorded.
 *
 * @package NomadCMS\Webhooks\Mapping
 */

declare(strict_types=1);

namespace NomadCMS\Webhooks\Mapping;

use NomadCMS\Database\ContentDatabase;
use NomadCMS\Database\MassiveDatabase;
use NomadCMS\Services\Forms\FormNotifier;
use NomadCMS\Services\Forms\FormService;
use NomadCMS\Services\Forms\FormSubmissionService;
use NomadCMS\Services\NotificationService\Support;
use NomadCMS\Webhooks\PayloadMapper;
use Throwable;

/**
 * Outcome of mapping one event.
 */
final class MappingResult
{
    public function __construct(
        public readonly bool $success,
        public readonly string $status,
        public readonly ?string $target = null,
        public readonly ?string $recordId = null,
        public readonly ?string $error = null,
        public readonly array $values = [],
        public readonly int $rulesApplied = 0,
        public readonly bool $skipped = false
    ) {}

    public static function skip(string $reason): self
    {
        return new self(true, WebhookEventsSchema::STATUS_VERIFIED, null, null, $reason, [], 0, true);
    }
}

final class MappingExecutor
{
    private PayloadMapper $payloadMapper;
    private PayloadNormalizer $normalizer;
    private MappingRuleRepository $rules;
    private TargetCatalogService $catalog;

    public function __construct(
        ?PayloadMapper $payloadMapper = null,
        ?PayloadNormalizer $normalizer = null,
        ?MappingRuleRepository $rules = null,
        ?TargetCatalogService $catalog = null
    ) {
        $this->payloadMapper = $payloadMapper ?? new PayloadMapper();
        $this->normalizer = $normalizer ?? new PayloadNormalizer();
        $this->rules = $rules ?? new MappingRuleRepository();
        $this->catalog = $catalog ?? new TargetCatalogService();
    }

    // =========================================================================
    // ENTRY POINT
    // =========================================================================

    /**
     * Map one stored event into the endpoint's configured destination.
     *
     * @param array<string, mixed> $endpoint Row from webhook_endpoints
     * @param array<string, mixed> $payload Decoded raw payload
     * @param int|null $eventId When given, the event row's status is updated
     */
    public function execute(array $endpoint, array $payload, ?int $eventId = null, ?string $eventType = null): MappingResult
    {
        $slug = (string) ($endpoint['endpoint_key'] ?? '');
        $endpointId = isset($endpoint['id']) ? (int) $endpoint['id'] : null;

        try {
            // --- Gate 1: mode ------------------------------------------------
            $mode = (new EventIngestService())->effectiveMode($endpoint);
            if ($mode !== WebhookEventsSchema::MODE_LIVE) {
                return MappingResult::skip('Teszt / tanuló mód: a CMS-be nem írunk.');
            }

            $targetKind = (string) ($endpoint['target_kind'] ?? '');
            $targetKey = (string) ($endpoint['target_key'] ?? '');
            if ($targetKind === '' || $targetKey === '') {
                return MappingResult::skip('Nincs beállítva mentési cél ehhez a végponthoz.');
            }

            // --- Gate 2: the target still exists -----------------------------
            $target = $this->catalog->findTarget($targetKind, $targetKey);
            if ($target === null) {
                return $this->fail(
                    $eventId,
                    sprintf('A mentési cél nem található: %s / %s. Lehet, hogy törölték.', $targetKind, $targetKey),
                    $targetKind . ':' . $targetKey,
                    $endpointId
                );
            }

            // --- Compile and evaluate ----------------------------------------
            $eventType ??= (new EventIngestService())->detectEventType($payload);
            $rules = $this->rules->forEndpoint($slug, $eventType);

            if ($rules === []) {
                return MappingResult::skip('Ehhez a végponthoz még nincs jóváhagyott összekötés.');
            }

            $values = $this->buildValues($payload, $rules);

            if ($values === []) {
                return $this->fail(
                    $eventId,
                    'A szabályok egyike sem talált értéket ebben az eseményben.',
                    $targetKind . ':' . $targetKey,
                    $endpointId
                );
            }

            // --- Validate against the destination ----------------------------
            $missing = $this->missingRequiredFields($target, $values);
            if ($missing !== []) {
                return $this->fail(
                    $eventId,
                    sprintf(
                        'Kötelező célmező nincs kitöltve: %s. Kösd össze egy beérkező adattal.',
                        implode(', ', $missing)
                    ),
                    $targetKind . ':' . $targetKey,
                    $endpointId
                );
            }

            // --- Write --------------------------------------------------------
            $recordId = $this->write($targetKind, $target, $values, $payload);

            $this->markMapped($eventId, $targetKind . ':' . $targetKey, $recordId, $endpointId);

            return new MappingResult(
                success: true,
                status: WebhookEventsSchema::STATUS_MAPPED,
                target: $targetKind . ':' . $targetKey,
                recordId: $recordId,
                values: $values,
                rulesApplied: count($rules)
            );
        } catch (Throwable $e) {
            error_log('[WebhookMapping] Execution failed: ' . $e->getMessage());

            return $this->fail($eventId, $e->getMessage(), null, $endpointId);
        }
    }

    // =========================================================================
    // VALUE BUILDING
    // =========================================================================

    /**
     * Evaluate every rule against the payload and apply its transform.
     *
     * @param array<int, array<string, mixed>> $rules
     * @return array<string, mixed>
     */
    public function buildValues(array $payload, array $rules): array
    {
        // Normalise once, not per rule. Both namespaces are kept available
        // because a single endpoint can legitimately have some rules bound to
        // the curated namespace and others to the raw one (an advanced user
        // reaching for a field the adapter does not promote).
        $normalized = $this->normalizer->normalize($payload);

        $values = [];

        foreach ($rules as $rule) {
            $space = (string) ($rule['source_space'] ?? WebhookEventsSchema::SPACE_RAW);
            $haystack = $space === WebhookEventsSchema::SPACE_NORMALIZED ? $normalized->data : $payload;

            $raw = $this->payloadMapper->evaluateJsonPath((string) $rule['source_path'], $haystack);

            if ($raw === null) {
                // A rule that finds nothing contributes nothing. It is NOT an
                // error on its own: an optional question the respondent skipped
                // is the normal case, and writing an empty string would be worse
                // than leaving the column untouched.
                continue;
            }

            $transformed = $this->applyTransform($raw, $rule['transform'] ?? null);
            if ($transformed === null || $transformed === '') {
                continue;
            }

            $values[(string) $rule['target_field']] = $transformed;
        }

        return $values;
    }

    /**
     * Apply one value transform.
     */
    public function applyTransform(mixed $value, ?string $transform): mixed
    {
        if ($transform === null || $transform === '') {
            return $this->flatten($value);
        }

        $value = $this->flatten($value);

        return match ($transform) {
            WebhookEventsSchema::TRANSFORM_TRIM => is_string($value) ? trim($value) : $value,
            WebhookEventsSchema::TRANSFORM_LOWER => is_string($value) ? mb_strtolower($value) : $value,
            WebhookEventsSchema::TRANSFORM_DATE_ISO => $this->toIsoDate($value),
            WebhookEventsSchema::TRANSFORM_MINOR_TO_MAJOR => $this->minorToMajor($value),
            WebhookEventsSchema::TRANSFORM_PHONE_E164 => $this->toE164($value),
            default => $value,
        };
    }

    /**
     * Reduce a non-scalar to something a text column can hold.
     *
     * Arrays are joined rather than JSON-encoded: a user who mapped Cal.com's
     * `guests` list into a text field wants to read the addresses, not a JSON
     * literal.
     */
    private function flatten(mixed $value): mixed
    {
        if (is_bool($value)) {
            return $value ? 'igen' : 'nem';
        }
        if (!is_array($value)) {
            return $value;
        }

        $scalars = [];
        foreach ($value as $element) {
            if (is_scalar($element)) {
                $scalars[] = (string) $element;
            }
        }

        return $scalars === [] ? null : implode(', ', $scalars);
    }

    /**
     * Normalise a datetime to a plain ISO date.
     *
     * A `date` column receiving "2024-01-01T10:00:00Z" would either store the
     * time too or reject the value depending on the target; normalising here
     * makes the outcome predictable.
     */
    private function toIsoDate(mixed $value): mixed
    {
        if (!is_string($value) || $value === '') {
            return $value;
        }

        // Fast path for values already in the right shape, so a well-formed
        // input never depends on strtotime()'s looser parsing.
        if (preg_match('/^(\d{4}-\d{2}-\d{2})/', $value, $m) === 1) {
            return $m[1];
        }

        $timestamp = strtotime($value);

        return $timestamp === false ? $value : gmdate('Y-m-d', $timestamp);
    }

    /**
     * Divide by 100 for providers that report money in minor units.
     */
    private function minorToMajor(mixed $value): mixed
    {
        if (!is_numeric($value)) {
            return $value;
        }

        $major = ((float) $value) / 100;

        // Keep an integer result integral, so 2000 minor units reads as 20 and
        // not 20.0 in the record.
        return $major === floor($major) ? (int) $major : round($major, 2);
    }

    /**
     * Best-effort E.164. Deliberately conservative: an unrecognised format is
     * returned untouched rather than mangled into something that looks valid.
     */
    private function toE164(mixed $value): mixed
    {
        if (!is_string($value) || $value === '') {
            return $value;
        }

        $digits = preg_replace('/[^0-9+]/', '', $value) ?? $value;

        if (str_starts_with($digits, '+')) {
            return '+' . preg_replace('/[^0-9]/', '', substr($digits, 1));
        }
        if (str_starts_with($digits, '00')) {
            return '+' . substr(preg_replace('/[^0-9]/', '', $digits) ?? '', 2);
        }

        return $value;
    }

    // =========================================================================
    // VALIDATION
    // =========================================================================

    /**
     * Required destination fields that no rule filled.
     *
     * @param array<string, mixed> $target
     * @param array<string, mixed> $values
     * @return array<int, string>
     */
    private function missingRequiredFields(array $target, array $values): array
    {
        $missing = [];

        foreach ((array) ($target['fields'] ?? []) as $field) {
            if (!is_array($field) || ($field['required'] ?? false) !== true) {
                continue;
            }
            $name = (string) ($field['name'] ?? '');
            if ($name !== '' && !array_key_exists($name, $values)) {
                // Reported by LABEL, because the user chose the mapping in a UI
                // that shows labels, not column names.
                $missing[] = (string) ($field['label'] ?? $name);
            }
        }

        return $missing;
    }

    // =========================================================================
    // WRITES
    // =========================================================================

    /**
     * @param array<string, mixed> $target
     * @param array<string, mixed> $values
     * @param array<string, mixed> $payload
     */
    private function write(string $kind, array $target, array $values, array $payload): string
    {
        return match ($kind) {
            WebhookEventsSchema::TARGET_FORM => $this->writeForm($target, $values),
            WebhookEventsSchema::TARGET_MASSIVE => $this->writeMassive($target, $values),
            WebhookEventsSchema::TARGET_CONTENT => $this->writeContent($target, $values),
            default => throw new \RuntimeException('Ismeretlen céltípus: ' . $kind),
        };
    }

    /**
     * @param array<string, mixed> $target
     * @param array<string, mixed> $values
     */
    private function writeForm(array $target, array $values): string
    {
        $slug = (string) $target['key'];
        $form = FormService::findBySlug($slug);

        if ($form === null) {
            throw new \RuntimeException(sprintf('Az űrlap nem található: %s', $slug));
        }

        // FormSubmissionService handles envelope encryption, the blind index and
        // the inbox metadata, so a mapped booking is indistinguishable from a
        // real submission - which is exactly the point of choosing a form target.
        $created = FormSubmissionService::create($form, $values, [
            'origin' => 'webhook',
            'content_type' => 'application/json',
            // No IP: the request came from the provider's servers, and recording
            // it as if it were the data subject's address would be misleading.
            'ip' => null,
            'user_agent' => 'NomadCMS-Webhook-Automapper',
        ]);

        // The public submit endpoint (endpoints/public/forms.php) fires both of
        // these right after the same FormSubmissionService::create() call - a
        // mapped webhook record went dark on both because this path bypasses
        // that endpoint entirely. Without this, connecting a webhook to a form
        // whose admin then enables "e-mail notification" produces submissions
        // that appear in the inbox but never send a single e-mail, which is
        // silent and easy to mistake for the feature being broken rather than
        // simply never having been wired up for this path.
        //
        // Never allowed to affect the ingest's own success/failure: a webhook
        // provider gets a 200 for its POST regardless of whether the CMS's own
        // SMTP profile or outgoing webhooks are working, exactly as a bad
        // notification setup does not fail a real visitor's form submission.
        try {
            FormNotifier::sendEmail($form, (int) ($created['id'] ?? 0), $values);
            FormNotifier::dispatchWebhook($form, $created, $values);
        } catch (\Throwable $e) {
            error_log('[MappingExecutor] Form notification failed for "' . $slug . '": ' . $e->getMessage());
        }

        return (string) ($created['uuid'] ?? $created['id'] ?? '');
    }

    /**
     * @param array<string, mixed> $target
     * @param array<string, mixed> $values
     */
    private function writeMassive(array $target, array $values): string
    {
        $slotKey = (string) $target['key'];

        // Correct static call with the real signature - see the class docblock on
        // why CreateContentAction is not used here.
        $id = MassiveDatabase::insert($slotKey, $values);

        return (string) $id;
    }

    /**
     * @param array<string, mixed> $target
     * @param array<string, mixed> $values
     */
    private function writeContent(array $target, array $values): string
    {
        $slotKey = (string) $target['key'];
        $slotType = (string) ($target['slot_type'] ?? 'object');

        if ($slotType === 'object') {
            // Declared as WRITE_OVERWRITE in the catalog, and it really does
            // overwrite: there is one value and this event becomes it.
            ContentDatabase::saveSlot($slotKey, $values, [
                'slot_type' => 'object',
                'version_intent' => 'system', // Programmatic write: always a commit, unaffected by shadow/autosave feature
            ]);

            return $slotKey;
        }

        if ($slotType === 'collection') {
            \NomadCMS\Database\CollectionDatabase::ensureReady($slotKey);
            $uid=$values['_dndId']??\NomadCMS\Services\RelationService::generateUid();
            $result=\NomadCMS\Database\CollectionDatabase::writeItem($slotKey,(string)$uid,$values,'create',['version_intent'=>'system']);
            return $result['item']['_dndId'];
        }
        $existing = ContentDatabase::getSlot($slotKey);
        $items = is_array($existing) ? $existing : [];
        if (!array_is_list($items)) {
            // A slot declared as a list but holding an object would silently
            // become a single-element list and lose the previous content.
            throw new \RuntimeException(sprintf(
                'A(z) "%s" gyűjtemény tartalma nem lista, ezért nem tudunk hozzáfűzni.',
                $slotKey
            ));
        }

        // A stable per-item id, matching the convention the CMS uses for
        // list/collection items elsewhere.
        $values['_dndId'] = $values['_dndId'] ?? \NomadCMS\Services\RelationService::generateUid();
        $items[] = $values;

        ContentDatabase::saveSlot($slotKey, $items, [
            'slot_type' => $slotType,
            'version_intent' => 'system', // Programmatic write: always a commit, unaffected by shadow/autosave feature
        ]);

        return (string) $values['_dndId'];
    }

    // =========================================================================
    // EVENT BOOKKEEPING
    // =========================================================================

    private function markMapped(?int $eventId, string $target, string $recordId, ?int $endpointId = null): void
    {
        if ($eventId === null) {
            return;
        }

        WebhookEventsSchema::ensureTables();
        $table = WebhookEventsSchema::TABLE_EVENTS;

        $db = WebhookEventsSchema::db();
        Support::transaction($db, static function () use ($db, $table, $target, $recordId, $eventId, $endpointId): void {
            $db->prepare("
                UPDATE {$table}
                SET status = ?, mapped_at = ?, mapped_target = ?, mapped_record_id = ?, error = NULL
                WHERE id = ?
            ")->execute([
                WebhookEventsSchema::STATUS_MAPPED,
                gmdate('c'),
                $target,
                $recordId,
                $eventId,
            ]);
            if ($endpointId !== null) {
                WebhookNotificationJournal::record($db, $eventId, $endpointId, 'mapped', $target);
            }
        });
    }

    private function fail(?int $eventId, string $error, ?string $target, ?int $endpointId = null): MappingResult
    {
        if ($eventId !== null) {
            WebhookEventsSchema::ensureTables();
            $table = WebhookEventsSchema::TABLE_EVENTS;

            $db = WebhookEventsSchema::db();
            Support::transaction($db, static function () use ($db, $table, $error, $target, $eventId, $endpointId): void {
                $db->prepare("
                    UPDATE {$table} SET status = ?, error = ?, mapped_target = ? WHERE id = ?
                ")->execute([
                    WebhookEventsSchema::STATUS_FAILED,
                    mb_substr($error, 0, 1000),
                    $target,
                    $eventId,
                ]);
                if ($endpointId !== null) {
                    WebhookNotificationJournal::record($db, $eventId, $endpointId, 'failed', $target);
                }
            });
        }

        return new MappingResult(
            success: false,
            status: WebhookEventsSchema::STATUS_FAILED,
            target: $target,
            error: $error
        );
    }

    /**
     * True when this event has already been written to its destination.
     *
     * Both the live path and replay consult this, so a re-delivery cannot create
     * a second booking record.
     */
    public function alreadyMapped(int $eventId): bool
    {
        WebhookEventsSchema::ensureTables();
        $table = WebhookEventsSchema::TABLE_EVENTS;

        $stmt = WebhookEventsSchema::db()->prepare("SELECT status FROM {$table} WHERE id = ?");
        $stmt->execute([$eventId]);

        return $stmt->fetchColumn() === WebhookEventsSchema::STATUS_MAPPED;
    }
}
