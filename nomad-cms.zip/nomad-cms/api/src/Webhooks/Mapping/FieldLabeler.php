<?php
/**
 * NOMAD CMS - Field Labeler
 *
 * Turns a machine key into something a non-technical user recognises.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * LABEL PRECEDENCE, BEST TO WORST
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * 1. THE PROVIDER'S OWN LABEL. Typeform hands us the literal question text
 *    ("What is your first name?"); Cal.com hands us the booking question's
 *    label. Nothing we could infer beats the words the person filling in the
 *    form actually read, so this always wins.
 * 2. THE SYNONYM DICTIONARY. `customer_email` -> "Ügyfél E-mail címe".
 * 3. HUMANISED RAW KEY. `weird_vendor_field` -> "Weird vendor field".
 *
 * The raw key is ALWAYS shown in parentheses after the label. That is not
 * decoration: without it a user comparing two similar fields ("E-mail cím" from
 * `attendee.email` and "E-mail cím" from `organizer.email`) would have no way to
 * tell them apart, and the friendly label would become actively harmful.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * ROLE PREFIXING
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * When the path carries a role token the label says whose field it is
 * ("Ügyfél E-mail címe" vs "Szervező E-mail címe"). This is the same signal the
 * heuristic scores on, surfaced to the human so they can sanity-check the
 * automapper's choice rather than trust it blindly.
 *
 * @package NomadCMS\Webhooks\Mapping
 */

declare(strict_types=1);

namespace NomadCMS\Webhooks\Mapping;

final class FieldLabeler
{
    /**
     * Hungarian prefixes for the two roles.
     *
     * @var array<string, string>
     */
    private const ROLE_PREFIX = [
        'customer' => 'Ügyfél',
        'owner' => 'Szervező',
    ];

    /**
     * Segment names that read as an owner in Hungarian and are worth naming
     * explicitly, because "Ügyfél" would be wrong and a bare label misleading.
     *
     * @var array<string, string>
     */
    private const SEGMENT_PREFIX = [
        'attendee' => 'Résztvevő',
        'attendees' => 'Résztvevő',
        'organizer' => 'Szervező',
        'customer' => 'Ügyfél',
        'megrendelo' => 'Megrendelő',
        'booking' => 'Foglalás',
        'order' => 'Rendelés',
        'form' => 'Űrlap',
        'event' => 'Esemény',
        'hidden' => 'Rejtett',
        'metadata' => 'Egyéni',
        'amount' => 'Fizetés',
    ];

    /**
     * Build the display label for one field.
     *
     * @param string $path Dotted path within its namespace (e.g. "attendee.email")
     * @param string|null $providerLabel Label supplied by the provider, if any
     * @return array{label:string, display:string, canonical:string|null, role:string|null}
     */
    public function describe(string $path, ?string $providerLabel = null): array
    {
        $leaf = $this->leafKey($path);
        $canonical = FieldSynonyms::canonicalFor($leaf) ?? FieldSynonyms::canonicalFor($path);
        $role = FieldSynonyms::roleFor($path);

        // A provider whose keys are OPAQUE IDS (Typeform's `SMEUb7VJz92Q`) puts
        // all the meaning in the label. Without consulting it, such a field has
        // no canonical group at all and the automapper cannot place it - which
        // would make the feature useless for exactly the provider that needs it
        // most. The label is only consulted as a FALLBACK, so a key that already
        // says what it is keeps deciding.
        if ($canonical === null && $providerLabel !== null && trim($providerLabel) !== '') {
            $canonical = FieldSynonyms::canonicalFor($providerLabel);
        }

        if ($providerLabel !== null && trim($providerLabel) !== '') {
            // Precedence 1. Not prefixed with a role: the provider's wording is
            // already the user's wording, and bolting "Ügyfél" onto a full
            // sentence reads as broken Hungarian.
            $label = $this->tidy($providerLabel);
        } elseif ($canonical !== null) {            // Precedence 2.
            $base = FieldSynonyms::labelForGroup($canonical) ?? $this->humanise($leaf);
            $label = $this->applyPrefix($base, $path, $role);
        } else {
            // Precedence 3.
            $label = $this->applyPrefix($this->humanise($leaf), $path, $role);
        }

        return [
            'label' => $label,
            // The raw key is never hidden - see the class docblock.
            'display' => $label . ' (' . $leaf . ')',
            'canonical' => $canonical,
            'role' => $role,
        ];
    }

    /**
     * Prefix a label with the owning entity, when we can name one.
     */
    private function applyPrefix(string $base, string $path, ?string $role): string
    {
        $segments = explode('.', $path);
        array_pop($segments); // drop the leaf

        // Prefer the concrete parent segment ("Résztvevő") over the abstract
        // role ("Ügyfél"), because it matches what the user sees in the payload.
        foreach (array_reverse($segments) as $segment) {
            $key = strtolower($segment);
            if (isset(self::SEGMENT_PREFIX[$key])) {
                return self::SEGMENT_PREFIX[$key] . ' ' . $this->lcfirstUtf8($base);
            }
        }

        if ($role !== null && isset(self::ROLE_PREFIX[$role])) {
            return self::ROLE_PREFIX[$role] . ' ' . $this->lcfirstUtf8($base);
        }

        return $base;
    }

    /**
     * `weird_vendor_field` -> `Weird vendor field`, `startTime` -> `Start time`.
     *
     * Sentence case, not Title Case: the dictionary labels are written as
     * sentences ("Dátum / időpont", "E-mail cím"), so a humanised fallback in
     * Title Case would look like a different kind of thing in the same column.
     */
    private function humanise(string $key): string
    {
        $spaced = preg_replace('/([a-z0-9])([A-Z])/', '$1 $2', $key) ?? $key;
        $spaced = str_replace(['_', '-'], ' ', $spaced);
        $spaced = trim(preg_replace('/\s+/', ' ', $spaced) ?? $spaced);

        if ($spaced === '') {
            return $key;
        }

        $spaced = mb_strtolower($spaced);

        return mb_strtoupper(mb_substr($spaced, 0, 1)) . mb_substr($spaced, 1);
    }

    /**
     * Last segment of a dotted path, with any array index stripped.
     */
    public function leafKey(string $path): string
    {
        $segments = explode('.', $path);
        $leaf = (string) end($segments);

        // `attendees[0]` -> `attendees`
        $leaf = preg_replace('/\[[^\]]*\]$/', '', $leaf) ?? $leaf;

        return $leaf === '' ? $path : $leaf;
    }

    private function tidy(string $label): string
    {
        $label = trim(preg_replace('/\s+/', ' ', $label) ?? $label);

        return mb_strlen($label) > 120 ? mb_substr($label, 0, 117) . '…' : $label;
    }

    private function lcfirstUtf8(string $value): string
    {
        if ($value === '') {
            return $value;
        }

        // Only lowercase the first character when the word is not an acronym
        // ("E-mail cím" must stay "E-mail cím", not become "e-mail cím" mid-label
        // in a way that looks like a typo).
        $first = mb_substr($value, 0, 1);
        $rest = mb_substr($value, 1);

        if ($rest !== '' && mb_strtoupper(mb_substr($rest, 0, 1)) === mb_substr($rest, 0, 1)
            && mb_strtolower(mb_substr($rest, 0, 1)) !== mb_substr($rest, 0, 1)) {
            // Second character is also uppercase - looks like an acronym.
            return $value;
        }

        return mb_strtolower($first) . $rest;
    }
}
