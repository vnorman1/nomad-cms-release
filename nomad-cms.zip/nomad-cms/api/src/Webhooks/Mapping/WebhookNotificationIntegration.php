<?php

/**
 * NOMAD CMS - Central incoming webhook notifications.
 * Registers permission-checked mapping alerts and explicit machine outputs.
 * Successes require a routing rule; payloads and endpoint credentials never leave the source.
 */

declare(strict_types=1);

namespace NomadCMS\Webhooks\Mapping;

use NomadCMS\Services\NotificationService\Events\EventDefinition;
use NomadCMS\Services\NotificationService\NotificationException;
use NomadCMS\Services\NotificationService\NotificationModule;
use NomadCMS\Services\NotificationService\Support;

/** Domain policies shared by HTTP, cron and CLI notification consumers. */
final class WebhookNotificationIntegration
{
    public const MAPPED = 'webhooks.mapping.succeeded';
    public const FAILED = 'webhooks.mapping.failed';
    public const TARGET = 'webhooks.endpoint';
    public const SILENT_AUDIENCE = 'webhooks.silent';

    public function __construct(private NotificationModule $module)
    {
    }

    public function register(): void
    {
        $this->module->audiences->register(self::SILENT_AUDIENCE, static fn(): array => []);
        foreach ([self::MAPPED, self::FAILED] as $type) {
            $failed = $type === self::FAILED;
            $this->module->events->register(new EventDefinition(
                type: $type,
                source: 'webhooks',
                render: function (array $event) use ($failed): array {
                    $id = (string) $event['data']['endpoint_id'];
                    $endpoint = $this->endpoint($id);
                    $name = mb_substr(trim(str_replace(["\r", "\n"], ' ', (string) ($endpoint['name'] ?? 'Webhook'))), 0, 200);
                    return [
                        'title' => $failed ? 'Webhook adatmentési hiba' : 'Webhook adatai elmentve',
                        'message' => $failed ? 'Nem sikerült a bejövő adatok mentése: ' . $name : 'A bejövő adatok mentése sikerült: ' . $name,
                        'target' => ['kind' => self::TARGET, 'id' => $id],
                        'presentation' => ['key' => 'webhookMapping', 'params' => [
                            'endpoint' => $name, 'outcome' => $failed ? 'failed' : 'mapped',
                        ]],
                    ];
                },
                canRead: fn(array $event, string $user): bool => $this->canRead((string) $event['data']['endpoint_id'], $user),
                windowSeconds: 120,
                machineOutputs: true,
                filterFields: ['data.endpoint_id', 'data.target_kind'],
                allowedChannels: ['in_app', 'email', 'webhook', 'audit'],
                presentationKey: 'webhookMapping',
                presentationParams: ['endpoint', 'outcome']
            ));
        }
        $this->module->targets->register(self::TARGET, function (array $target, string $user): string {
            if (!$this->canRead($target['id'], $user)) {
                throw new NotificationException('target_unavailable', 404);
            }
            return '/webhooks/' . rawurlencode($this->endpoint($target['id'])['endpoint_key']) . '/mapping';
        });
    }

    private function endpoint(string $id): ?array
    {
        if (Support::one($this->module->db, "SELECT 1 FROM sqlite_master WHERE type='table' AND name='webhook_endpoints'") === null) {
            return null;
        }
        return Support::one($this->module->db, 'SELECT id,name,endpoint_key FROM webhook_endpoints WHERE id=?', [$id]);
    }

    private function canRead(string $id, string $user): bool
    {
        return $this->module->access->has($user, 'webhooks:read:*') && $this->endpoint($id) !== null;
    }
}
