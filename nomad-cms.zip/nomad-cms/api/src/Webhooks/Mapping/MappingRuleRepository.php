<?php
/**
 * NOMAD CMS - Mapping Rule Repository
 *
 * Persists the pairings a user approved, which is what turns the automapper from
 * a one-off convenience into something that learns.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * UPSERT, NOT INSERT
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * Approving the same pairing twice is a completely ordinary thing for a user to
 * do (open the mapper, accept everything, come back tomorrow, accept everything
 * again). If that produced a second row, MappingExecutor would evaluate the same
 * source path twice for the same target field and the rule list in the UI would
 * fill up with duplicates.
 *
 * The schema has a UNIQUE index for this, but it depends on expression-index
 * support (SQLite 3.9+) because event_type is nullable and SQLite treats NULLs
 * as distinct in a UNIQUE index. So the dedupe is ALSO enforced here in
 * application code: on an old SQLite the index is simply absent, and the
 * repository must not start duplicating rows because of it.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * ONE TARGET FIELD, ONE RULE
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * saveMany() replaces any existing active rule for a (event_type, target_field)
 * pair rather than adding to it. Two sources writing to one field would mean the
 * last one evaluated wins - a race whose outcome depends on row order, which is
 * exactly the kind of behaviour a non-technical user can never debug.
 *
 * @package NomadCMS\Webhooks\Mapping
 */

declare(strict_types=1);

namespace NomadCMS\Webhooks\Mapping;

use PDO;

final class MappingRuleRepository
{
    /**
     * Active rules for one endpoint.
     *
     * @param string|null $eventType When given, returns rules for that event
     *                               type PLUS the event-agnostic ones (NULL),
     *                               because a rule with no event type means
     *                               "every event".
     * @return array<int, array<string, mixed>>
     */
    public function forEndpoint(string $endpointSlug, ?string $eventType = null, bool $activeOnly = true): array
    {
        WebhookEventsSchema::ensureTables();
        $db = WebhookEventsSchema::db();
        $table = WebhookEventsSchema::TABLE_RULES;

        $sql = "SELECT * FROM {$table} WHERE endpoint_slug = ?";
        $params = [$endpointSlug];

        if ($activeOnly) {
            $sql .= ' AND is_active = 1';
        }

        if ($eventType !== null && $eventType !== '') {
            $sql .= " AND (event_type IS NULL OR event_type = '' OR event_type = ?)";
            $params[] = $eventType;
        }

        $sql .= ' ORDER BY target_field ASC, id ASC';

        $stmt = $db->prepare($sql);
        $stmt->execute($params);

        return array_map([$this, 'hydrate'], $stmt->fetchAll(PDO::FETCH_ASSOC));
    }

    /**
     * Rules from OTHER endpoints, for cross-endpoint transfer suggestions.
     *
     * Capped, and newest first: an installation with years of history should not
     * load thousands of rows to score one payload, and recent decisions reflect
     * the user's current intent better than old ones.
     *
     * @return array<int, array<string, mixed>>
     */
    public function transferable(string $excludeEndpointSlug, int $limit = 200): array
    {
        WebhookEventsSchema::ensureTables();
        $db = WebhookEventsSchema::db();
        $table = WebhookEventsSchema::TABLE_RULES;

        $stmt = $db->prepare("
            SELECT * FROM {$table}
            WHERE endpoint_slug != ? AND is_active = 1 AND origin = ?
            ORDER BY updated_at DESC, id DESC
            LIMIT ?
        ");
        // origin = user only: transferring a rule that was itself only a
        // heuristic guess would compound one inference on top of another.
        $stmt->execute([$excludeEndpointSlug, WebhookEventsSchema::ORIGIN_USER, max(1, min(1000, $limit))]);

        return array_map([$this, 'hydrate'], $stmt->fetchAll(PDO::FETCH_ASSOC));
    }

    /**
     * Everything the heuristic should consider: this endpoint's own rules first,
     * then transferable ones.
     *
     * @return array<int, array<string, mixed>>
     */
    public function learnedFor(string $endpointSlug, ?string $eventType = null): array
    {
        return array_merge(
            $this->forEndpoint($endpointSlug, $eventType),
            $this->transferable($endpointSlug)
        );
    }

    // =========================================================================
    // WRITES
    // =========================================================================

    /**
     * Persist a batch of approved pairings.
     *
     * @param array<int, array<string, mixed>> $rules
     * @return array{saved:int, replaced:int, ids:array<int,int>}
     */
    public function saveMany(string $endpointSlug, array $rules, ?int $createdBy = null): array
    {
        WebhookEventsSchema::ensureTables();
        $db = WebhookEventsSchema::db();

        $saved = 0;
        $replaced = 0;
        $ids = [];

        $ownTransaction = !$db->inTransaction();
        if ($ownTransaction) {
            $db->beginTransaction();
        }

        try {
            foreach ($rules as $rule) {
                $normalised = $this->validate($endpointSlug, $rule);

                // One rule per target field per event type - see the class
                // docblock on why two sources for one field is not allowed.
                $replaced += $this->deactivateConflicting(
                    $endpointSlug,
                    $normalised['event_type'],
                    $normalised['target_field'],
                    $normalised['source_path']
                );

                $existing = $this->findIdentical($normalised);
                if ($existing !== null) {
                    $this->update($existing, $normalised);
                    $ids[] = $existing;
                } else {
                    $ids[] = $this->insert($normalised, $createdBy);
                }

                $saved++;
            }

            if ($ownTransaction) {
                $db->commit();
            }
        } catch (\Throwable $e) {
            if ($ownTransaction && $db->inTransaction()) {
                $db->rollBack();
            }
            throw $e;
        }

        return ['saved' => $saved, 'replaced' => $replaced, 'ids' => $ids];
    }

    /**
     * Delete one rule, scoped to its endpoint so an id from another endpoint
     * cannot be removed by guessing.
     */
    public function delete(string $endpointSlug, int $ruleId): bool
    {
        WebhookEventsSchema::ensureTables();
        $db = WebhookEventsSchema::db();
        $table = WebhookEventsSchema::TABLE_RULES;

        $stmt = $db->prepare("DELETE FROM {$table} WHERE id = ? AND endpoint_slug = ?");
        $stmt->execute([$ruleId, $endpointSlug]);

        return $stmt->rowCount() > 0;
    }

    /**
     * Remove every rule of an endpoint (used when the target changes).
     */
    public function deleteForEndpoint(string $endpointSlug): int
    {
        WebhookEventsSchema::ensureTables();
        $db = WebhookEventsSchema::db();
        $table = WebhookEventsSchema::TABLE_RULES;

        $stmt = $db->prepare("DELETE FROM {$table} WHERE endpoint_slug = ?");
        $stmt->execute([$endpointSlug]);

        return $stmt->rowCount();
    }

    /**
     * Drop rules that point at a destination the endpoint no longer uses.
     *
     * Called when the user changes an endpoint's target. Keeping the old rules
     * would be worse than useless: they would still match by source path and the
     * executor would try to write into a form the endpoint is no longer bound
     * to.
     */
    public function pruneForeignTargets(string $endpointSlug, string $targetKind, string $targetKey): int
    {
        WebhookEventsSchema::ensureTables();
        $db = WebhookEventsSchema::db();
        $table = WebhookEventsSchema::TABLE_RULES;

        $stmt = $db->prepare("
            DELETE FROM {$table}
            WHERE endpoint_slug = ? AND (target_kind != ? OR target_key != ?)
        ");
        $stmt->execute([$endpointSlug, $targetKind, $targetKey]);

        return $stmt->rowCount();
    }

    /**
     * Drop the rule (any event type) feeding one specific target field.
     *
     * Called when a Form field itself is deleted (see the `remove-target-field`
     * admin action) - a rule pointing at a column that no longer exists would
     * otherwise sit there until the next save, matching nothing and confusing
     * whoever next opens the mapper wondering why a "connected" field has no
     * corresponding column.
     */
    public function deleteForTargetField(
        string $endpointSlug,
        string $targetKind,
        string $targetKey,
        string $targetField
    ): int {
        WebhookEventsSchema::ensureTables();
        $db = WebhookEventsSchema::db();
        $table = WebhookEventsSchema::TABLE_RULES;

        $stmt = $db->prepare("
            DELETE FROM {$table}
            WHERE endpoint_slug = ? AND target_kind = ? AND target_key = ? AND target_field = ?
        ");
        $stmt->execute([$endpointSlug, $targetKind, $targetKey, $targetField]);

        return $stmt->rowCount();
    }

    // =========================================================================
    // INTERNALS
    // =========================================================================

    /**
     * @param array<string, mixed> $rule
     * @return array<string, mixed>
     */
    private function validate(string $endpointSlug, array $rule): array
    {
        $sourcePath = trim((string) ($rule['source_path'] ?? ''));
        $targetField = trim((string) ($rule['target_field'] ?? ''));
        $targetKind = (string) ($rule['target_kind'] ?? '');
        $targetKey = trim((string) ($rule['target_key'] ?? ''));

        if ($sourcePath === '' || $targetField === '') {
            throw new \InvalidArgumentException('A szabályhoz forrás- és célmező is kell.');
        }
        if (!str_starts_with($sourcePath, '$')) {
            // Every rule is evaluated by PayloadMapper, which only recognises
            // JSONPath. Rejecting here means a malformed path fails at save time
            // (where a human can fix it) rather than silently yielding null on
            // every future event.
            throw new \InvalidArgumentException('A forrás útvonalnak JSONPath-nak kell lennie ($ jellel kezdődik).');
        }
        if (!in_array($targetKind, WebhookEventsSchema::TARGET_KINDS, true)) {
            throw new \InvalidArgumentException('Érvénytelen céltípus.');
        }
        if (!preg_match('/^[A-Za-z0-9_-]{1,64}$/', $targetKey)) {
            throw new \InvalidArgumentException('Érvénytelen cél azonosító.');
        }
        if (!preg_match('/^[A-Za-z0-9_.-]{1,128}$/', $targetField)) {
            throw new \InvalidArgumentException('Érvénytelen célmező név.');
        }

        $space = (string) ($rule['source_space'] ?? WebhookEventsSchema::SPACE_RAW);
        if (!in_array($space, WebhookEventsSchema::SOURCE_SPACES, true)) {
            throw new \InvalidArgumentException('Érvénytelen forrás-névtér.');
        }

        $transform = $rule['transform'] ?? null;
        if ($transform !== null && $transform !== '' && !in_array($transform, WebhookEventsSchema::TRANSFORMS, true)) {
            throw new \InvalidArgumentException('Érvénytelen átalakítás.');
        }

        $origin = (string) ($rule['origin'] ?? WebhookEventsSchema::ORIGIN_USER);
        if (!in_array($origin, WebhookEventsSchema::ORIGINS, true)) {
            $origin = WebhookEventsSchema::ORIGIN_USER;
        }

        $eventType = $rule['event_type'] ?? null;
        $eventType = ($eventType === null || $eventType === '') ? null : substr((string) $eventType, 0, 128);

        return [
            'endpoint_slug' => $endpointSlug,
            'event_type' => $eventType,
            'source_space' => $space,
            'source_path' => substr($sourcePath, 0, 512),
            'target_kind' => $targetKind,
            'target_key' => $targetKey,
            'target_field' => $targetField,
            'transform' => ($transform === null || $transform === '') ? null : (string) $transform,
            // A rule the user approved is certain by definition. The heuristic's
            // own confidence score is not persisted as the rule's confidence,
            // because once a human has said yes the estimate is irrelevant.
            'confidence' => $origin === WebhookEventsSchema::ORIGIN_USER
                ? 1.0
                : round((float) ($rule['confidence'] ?? 0.5), 3),
            'origin' => $origin,
        ];
    }

    /**
     * @param array<string, mixed> $rule
     */
    private function findIdentical(array $rule): ?int
    {
        $db = WebhookEventsSchema::db();
        $table = WebhookEventsSchema::TABLE_RULES;

        $stmt = $db->prepare("
            SELECT id FROM {$table}
            WHERE endpoint_slug = ?
              AND COALESCE(event_type, '') = ?
              AND source_space = ?
              AND source_path = ?
              AND target_kind = ?
              AND target_key = ?
              AND target_field = ?
            LIMIT 1
        ");
        $stmt->execute([
            $rule['endpoint_slug'],
            $rule['event_type'] ?? '',
            $rule['source_space'],
            $rule['source_path'],
            $rule['target_kind'],
            $rule['target_key'],
            $rule['target_field'],
        ]);

        $id = $stmt->fetchColumn();

        return $id === false ? null : (int) $id;
    }

    /**
     * Remove any OTHER active rule writing into the same target field.
     *
     * @param array<string, mixed> $rule
     */
    private function deactivateConflicting(
        string $endpointSlug,
        ?string $eventType,
        string $targetField,
        string $keepSourcePath
    ): int {
        $db = WebhookEventsSchema::db();
        $table = WebhookEventsSchema::TABLE_RULES;

        $stmt = $db->prepare("
            DELETE FROM {$table}
            WHERE endpoint_slug = ?
              AND COALESCE(event_type, '') = ?
              AND target_field = ?
              AND source_path != ?
        ");
        $stmt->execute([$endpointSlug, $eventType ?? '', $targetField, $keepSourcePath]);

        return $stmt->rowCount();
    }

    /**
     * @param array<string, mixed> $rule
     */
    private function insert(array $rule, ?int $createdBy): int
    {
        $db = WebhookEventsSchema::db();
        $table = WebhookEventsSchema::TABLE_RULES;

        $stmt = $db->prepare("
            INSERT INTO {$table}
                (endpoint_slug, event_type, source_space, source_path, target_kind, target_key,
                 target_field, transform, confidence, origin, is_active, created_by)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?)
        ");
        $stmt->execute([
            $rule['endpoint_slug'],
            $rule['event_type'],
            $rule['source_space'],
            $rule['source_path'],
            $rule['target_kind'],
            $rule['target_key'],
            $rule['target_field'],
            $rule['transform'],
            $rule['confidence'],
            $rule['origin'],
            $createdBy,
        ]);

        return (int) $db->lastInsertId();
    }

    /**
     * @param array<string, mixed> $rule
     */
    private function update(int $id, array $rule): void
    {
        $db = WebhookEventsSchema::db();
        $table = WebhookEventsSchema::TABLE_RULES;

        $stmt = $db->prepare("
            UPDATE {$table}
            SET transform = ?, confidence = ?, origin = ?, is_active = 1, updated_at = CURRENT_TIMESTAMP
            WHERE id = ?
        ");
        $stmt->execute([$rule['transform'], $rule['confidence'], $rule['origin'], $id]);
    }

    /**
     * @param array<string, mixed> $row
     * @return array<string, mixed>
     */
    private function hydrate(array $row): array
    {
        return [
            'id' => (int) $row['id'],
            'endpoint_slug' => (string) $row['endpoint_slug'],
            'event_type' => $row['event_type'] !== null && $row['event_type'] !== '' ? (string) $row['event_type'] : null,
            'source_space' => (string) $row['source_space'],
            'source_path' => (string) $row['source_path'],
            'target_kind' => (string) $row['target_kind'],
            'target_key' => (string) $row['target_key'],
            'target_field' => (string) $row['target_field'],
            'transform' => $row['transform'] !== null && $row['transform'] !== '' ? (string) $row['transform'] : null,
            'confidence' => (float) $row['confidence'],
            'origin' => (string) $row['origin'],
            'is_active' => (bool) $row['is_active'],
            'created_by' => $row['created_by'] !== null ? (int) $row['created_by'] : null,
            'created_at' => (string) $row['created_at'],
            'updated_at' => (string) $row['updated_at'],
        ];
    }
}
