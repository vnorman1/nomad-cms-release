<?php
/**
 * NOMAD CMS - Payload Introspector
 *
 * Turns the last N stored events of an endpoint into the field list the mapper
 * UI renders.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * WHY IT SAMPLES SEVERAL EVENTS AND NOT JUST THE LATEST
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * A single payload cannot tell you which fields are RELIABLE. Stripe's
 * `customer_email` is null on a completed session while
 * `customer_details.email` holds the address; Typeform omits skipped questions;
 * Cal.com hides optional booking questions. Looking at one event, all of these
 * look equally trustworthy.
 *
 * So every field carries two rates measured across the sample:
 *   present_rate   in how many events did the path exist at all
 *   non_null_rate  in how many did it carry a usable value
 *
 * The heuristic uses non_null_rate to break ties, and the UI uses it to sort
 * "always filled" fields above "sometimes empty" ones. That is the difference
 * between an automapper that picks `customer_details.email` and one that picks
 * `customer_email` and quietly writes nothing.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * SAMPLE VALUES ARE MASKED
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * Showing a sample is what makes the mapper usable - "is this the field I want?"
 * is answered by seeing the value, not the key. But the mapper page is a normal
 * admin page: it is rendered in a browser, kept in browser history, and may be
 * screen-shared while someone asks for help. So values are masked before they
 * leave the server: enough shape to recognise the field, not enough to be a
 * disclosure. Masking happens HERE rather than in the UI, so the full value is
 * never in the HTTP response at all.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * BLOBS ARE EXCLUDED
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * Cal.com's newer payloads carry `attendeeIcsContent` - a multi-line VCALENDAR
 * string. It is never a field anyone maps, it would dominate the list visually,
 * and its masked sample is meaningless. Anything over MAX_VALUE_LENGTH, or
 * matching a known container format, is dropped from the field list.
 *
 * @package NomadCMS\Webhooks\Mapping
 */

declare(strict_types=1);

namespace NomadCMS\Webhooks\Mapping;

final class PayloadIntrospector
{
    /** Longest string still treated as a mappable value */
    private const MAX_VALUE_LENGTH = 600;

    /** Deepest nesting level walked, guarding against pathological payloads */
    private const MAX_DEPTH = 8;

    /** Ceiling on how many fields one endpoint can offer */
    private const MAX_FIELDS = 300;

    /** Array elements sampled per list (the first is representative enough) */
    private const MAX_ARRAY_ELEMENTS = 2;

    /**
     * Signatures of container formats that are never a mappable value.
     *
     * @var array<int, string>
     */
    private const BLOB_MARKERS = [
        'BEGIN:VCALENDAR',
        'BEGIN:VEVENT',
        '-----BEGIN',
        '<?xml',
        'data:image/',
    ];

    private FieldLabeler $labeler;
    private PayloadNormalizer $normalizer;

    public function __construct(?FieldLabeler $labeler = null, ?PayloadNormalizer $normalizer = null)
    {
        $this->labeler = $labeler ?? new FieldLabeler();
        $this->normalizer = $normalizer ?? new PayloadNormalizer();
    }

    // =========================================================================
    // ENTRY POINTS
    // =========================================================================

    /**
     * Build the field list for an endpoint from its stored events.
     *
     * @param string $endpointSlug
     * @param string|null $eventType Restrict the sample to one event type
     * @param int $sampleSize
     * @return array{
     *     provider:string,
     *     provider_label:string,
     *     space:string,
     *     event_types:array<int,string>,
     *     sampled_events:int,
     *     fields:array<int,array<string,mixed>>
     * }
     */
    public function describeEndpoint(
        string $endpointSlug,
        ?string $eventType = null,
        int $sampleSize = WebhookEventsSchema::FIELD_SAMPLE_SIZE
    ): array {
        $events = $this->loadSample($endpointSlug, $eventType, $sampleSize);

        if ($events === []) {
            return [
                'provider' => PayloadNormalizer::PROVIDER_GENERIC,
                'provider_label' => PayloadNormalizer::PROVIDER_LABELS[PayloadNormalizer::PROVIDER_GENERIC],
                'space' => WebhookEventsSchema::SPACE_RAW,
                'event_types' => [],
                'sampled_events' => 0,
                'fields' => [],
            ];
        }

        return $this->describePayloads(array_column($events, 'payload'), array_values(array_unique(
            array_filter(array_column($events, 'event_type'), static fn($t) => is_string($t) && $t !== '')
        )));
    }

    /**
     * Same analysis over payloads supplied directly.
     *
     * Kept public and separate so the suite can exercise the introspector on the
     * documented fixtures without seeding the database first.
     *
     * @param array<int, array<string, mixed>> $payloads
     * @param array<int, string> $eventTypes
     * @return array<string, mixed>
     */
    public function describePayloads(array $payloads, array $eventTypes = []): array
    {
        $normalized = [];
        $labels = [];
        $provider = PayloadNormalizer::PROVIDER_GENERIC;

        foreach ($payloads as $payload) {
            if (!is_array($payload)) {
                continue;
            }
            $result = $this->normalizer->normalize($payload);
            $normalized[] = $result->data;
            $labels += $result->labels;

            // First recognised provider wins. A single endpoint receiving two
            // different providers is a misconfiguration, not a use case.
            if ($provider === PayloadNormalizer::PROVIDER_GENERIC) {
                $provider = $result->provider;
            }
        }

        if ($normalized === []) {
            return [
                'provider' => $provider,
                'provider_label' => PayloadNormalizer::PROVIDER_LABELS[$provider] ?? $provider,
                'space' => WebhookEventsSchema::SPACE_RAW,
                'event_types' => $eventTypes,
                'sampled_events' => 0,
                'fields' => [],
            ];
        }

        // A recognised provider is addressed through the curated namespace; an
        // unknown one has no curated namespace, so its raw shape IS the space.
        $space = $provider === PayloadNormalizer::PROVIDER_GENERIC
            ? WebhookEventsSchema::SPACE_RAW
            : WebhookEventsSchema::SPACE_NORMALIZED;

        return [
            'provider' => $provider,
            'provider_label' => PayloadNormalizer::PROVIDER_LABELS[$provider] ?? $provider,
            'space' => $space,
            'event_types' => $eventTypes,
            'sampled_events' => count($normalized),
            'fields' => $this->collectFields($normalized, $labels, $space),
        ];
    }

    // =========================================================================
    // FIELD COLLECTION
    // =========================================================================

    /**
     * Walk every sampled payload and merge the observations per path.
     *
     * @param array<int, array<string, mixed>> $payloads
     * @param array<string, string> $providerLabels
     * @return array<int, array<string, mixed>>
     */
    private function collectFields(array $payloads, array $providerLabels, string $space): array
    {
        $observations = [];
        $total = count($payloads);

        foreach ($payloads as $payload) {
            $seen = [];
            $this->walk($payload, '', $observations, $seen, 0);
        }

        $fields = [];
        foreach ($observations as $path => $obs) {
            $described = $this->labeler->describe($path, $providerLabels[$path] ?? null);

            $fields[] = [
                'space' => $space,
                'path' => '$.' . $path,
                'dotted_path' => $path,
                'key' => $this->labeler->leafKey($path),
                'label' => $described['label'],
                'display' => $described['display'],
                'canonical' => $described['canonical'],
                'role' => $described['role'],
                'type' => $obs['type'],
                'sample' => $obs['sample'],
                'is_list' => $obs['is_list'],
                'list_length' => $obs['list_length'],
                'present_rate' => $total > 0 ? round($obs['present'] / $total, 3) : 0.0,
                'non_null_rate' => $total > 0 ? round($obs['non_null'] / $total, 3) : 0.0,
            ];
        }

        // Reliable fields first, then alphabetically for a stable UI order that
        // does not reshuffle when a new event arrives.
        usort($fields, static function ($a, $b) {
            if ($a['non_null_rate'] !== $b['non_null_rate']) {
                return $b['non_null_rate'] <=> $a['non_null_rate'];
            }
            return strcmp($a['dotted_path'], $b['dotted_path']);
        });

        return array_slice($fields, 0, self::MAX_FIELDS);
    }

    /**
     * Depth-first walk recording one observation per leaf path.
     *
     * @param array<string, array<string, mixed>> $observations
     * @param array<string, bool> $seen Paths already counted for THIS payload
     */
    private function walk(mixed $node, string $prefix, array &$observations, array &$seen, int $depth): void
    {
        if ($depth > self::MAX_DEPTH || count($observations) >= self::MAX_FIELDS * 2) {
            return;
        }

        if (!is_array($node)) {
            $this->record($prefix, $node, $observations, $seen, false, null);
            return;
        }

        if ($node === []) {
            // An empty array is still a fact worth surfacing: the field exists.
            $this->record($prefix, null, $observations, $seen, true, 0);
            return;
        }

        $isList = array_is_list($node);

        if ($isList) {
            // Record the list itself, so a user can map "how many items".
            $this->record($prefix, null, $observations, $seen, true, count($node));

            // Then sample the first element(s). Indexing by [0] is safe here in
            // a way it is NOT for Typeform answers, because these are
            // homogeneous collections (attendees, line items) rather than a
            // heterogeneous answer list whose order depends on what was skipped.
            $limit = min(self::MAX_ARRAY_ELEMENTS, count($node));
            for ($i = 0; $i < $limit; $i++) {
                $this->walk($node[$i], $prefix . '[' . $i . ']', $observations, $seen, $depth + 1);
            }
            return;
        }

        foreach ($node as $key => $value) {
            $keyString = (string) $key;
            $childPath = $prefix === '' ? $keyString : $prefix . '.' . $keyString;
            $this->walk($value, $childPath, $observations, $seen, $depth + 1);
        }
    }

    /**
     * @param array<string, array<string, mixed>> $observations
     * @param array<string, bool> $seen
     */
    private function record(
        string $path,
        mixed $value,
        array &$observations,
        array &$seen,
        bool $isList,
        ?int $listLength
    ): void {
        if ($path === '') {
            return;
        }

        if (is_string($value) && $this->isBlob($value)) {
            return;
        }

        if (!isset($observations[$path])) {
            $observations[$path] = [
                'present' => 0,
                'non_null' => 0,
                'type' => $this->inferType($value, $isList),
                'sample' => null,
                'is_list' => $isList,
                'list_length' => $listLength,
            ];
        }

        // Count each path once per payload, even if a list produced it twice.
        if (!isset($seen[$path])) {
            $seen[$path] = true;
            $observations[$path]['present']++;
        }

        if ($value !== null && $value !== '') {
            $observations[$path]['non_null']++;

            // Keep the FIRST non-empty sample we see. Later events overwriting
            // it would make the UI flicker between renders for no benefit.
            if ($observations[$path]['sample'] === null) {
                $observations[$path]['sample'] = $this->maskSample($path, $value);
                $observations[$path]['type'] = $this->inferType($value, $isList);
            }
        }
    }

    // =========================================================================
    // TYPE INFERENCE
    // =========================================================================

    private function inferType(mixed $value, bool $isList): string
    {
        if ($isList) {
            return 'list';
        }
        if ($value === null) {
            return 'null';
        }
        if (is_bool($value)) {
            return 'boolean';
        }
        if (is_int($value) || is_float($value)) {
            return 'number';
        }
        if (!is_string($value)) {
            return 'unknown';
        }

        if (filter_var($value, FILTER_VALIDATE_EMAIL) !== false) {
            return 'email';
        }
        if (preg_match('#^https?://#i', $value) === 1) {
            return 'url';
        }
        if ($this->looksLikeDateTime($value)) {
            return 'datetime';
        }
        if ($this->looksLikePhone($value)) {
            return 'phone';
        }
        if (is_numeric($value)) {
            return 'numeric_string';
        }

        return 'string';
    }

    public function looksLikeDateTime(string $value): bool
    {
        // ISO-8601-ish or plain date. Deliberately strict: strtotime() alone
        // happily parses "Guest User" as a date on some builds, which would let
        // the heuristic offer a name for a date field.
        return preg_match('/^\d{4}-\d{2}-\d{2}([T ]\d{2}:\d{2}(:\d{2})?)?/', $value) === 1;
    }

    public function looksLikePhone(string $value): bool
    {
        $digits = preg_replace('/[^0-9]/', '', $value) ?? '';

        return preg_match('/^[+0-9][0-9 ()\-\/]{6,24}$/', $value) === 1
            && strlen($digits) >= 7
            && strlen($digits) <= 15;
    }

    private function isBlob(string $value): bool
    {
        if (strlen($value) > self::MAX_VALUE_LENGTH) {
            return true;
        }

        foreach (self::BLOB_MARKERS as $marker) {
            if (str_contains($value, $marker)) {
                return true;
            }
        }

        // Multi-line content is a document, not a field value. Two newlines
        // rather than one, so a two-line textarea answer still counts as a value.
        return substr_count($value, "\n") > 2;
    }

    // =========================================================================
    // MASKING
    // =========================================================================

    /**
     * Reduce a value to a recognisable but non-disclosing sample.
     */
    public function maskSample(string $path, mixed $value): mixed
    {
        if (is_bool($value)) {
            return $value ? 'igen' : 'nem';
        }
        if (is_int($value) || is_float($value)) {
            return $value;
        }
        if (is_array($value)) {
            // A list of scalars (Cal.com `guests`) - mask each element.
            $masked = [];
            foreach (array_slice($value, 0, 3) as $element) {
                $masked[] = is_string($element) ? $this->maskString($element) : $element;
            }
            return $masked;
        }
        if (!is_string($value)) {
            return null;
        }

        return $this->maskString($value);
    }

    private function maskString(string $value): string
    {
        if (filter_var($value, FILTER_VALIDATE_EMAIL) !== false) {
            // Keep the domain: it is what tells a user "yes, this is the
            // customer's address" without revealing who the customer is.
            [$local, $domain] = explode('@', $value, 2);
            $head = mb_substr($local, 0, 1);

            return $head . str_repeat('*', max(2, min(6, mb_strlen($local) - 1))) . '@' . $domain;
        }

        if ($this->looksLikePhone($value)) {
            $digits = preg_replace('/[^0-9]/', '', $value) ?? '';
            $tail = substr($digits, -3);

            return '******' . $tail;
        }

        // Dates, statuses, ids, currencies and the like are shown as-is: they
        // are what the user needs to recognise the field, and they are not
        // identifying on their own.
        if (mb_strlen($value) <= 40) {
            return $value;
        }

        return mb_substr($value, 0, 37) . '…';
    }

    // =========================================================================
    // SAMPLING
    // =========================================================================

    /**
     * @return array<int, array{payload:array<string,mixed>, event_type:string|null}>
     */
    private function loadSample(string $endpointSlug, ?string $eventType, int $sampleSize): array
    {
        WebhookEventsSchema::ensureTables();
        $db = WebhookEventsSchema::db();
        $table = WebhookEventsSchema::TABLE_EVENTS;

        $sampleSize = max(1, min(200, $sampleSize));

        $sql = "SELECT payload, event_type FROM {$table} WHERE endpoint_slug = ?";
        $params = [$endpointSlug];

        if ($eventType !== null && $eventType !== '') {
            $sql .= ' AND event_type = ?';
            $params[] = $eventType;
        }

        // created_at DESC is served by idx_..._slug_created without a sort.
        $sql .= ' ORDER BY created_at DESC, id DESC LIMIT ?';
        $params[] = $sampleSize;

        $stmt = $db->prepare($sql);
        $stmt->execute($params);

        $events = [];
        foreach ($stmt->fetchAll() as $row) {
            $decoded = json_decode((string) $row['payload'], true);
            if (is_array($decoded)) {
                $events[] = [
                    'payload' => $decoded,
                    'event_type' => $row['event_type'] !== null ? (string) $row['event_type'] : null,
                ];
            }
        }

        return $events;
    }

    /**
     * Distinct event types seen on an endpoint, for the UI's event filter.
     *
     * @return array<int, string>
     */
    public function eventTypes(string $endpointSlug): array
    {
        WebhookEventsSchema::ensureTables();
        $db = WebhookEventsSchema::db();
        $table = WebhookEventsSchema::TABLE_EVENTS;

        $stmt = $db->prepare("
            SELECT DISTINCT event_type FROM {$table}
            WHERE endpoint_slug = ? AND event_type IS NOT NULL AND event_type != ''
            ORDER BY event_type ASC
        ");
        $stmt->execute([$endpointSlug]);

        return array_map(static fn($r) => (string) $r['event_type'], $stmt->fetchAll());
    }
}
