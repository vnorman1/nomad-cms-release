<?php
/**
 * NOMAD CMS - Heuristic Mapper
 *
 * Proposes source-field -> target-field pairings, so the user's job is reduced
 * to glancing at a list and pressing accept.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * THE SCORING LADDER
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *   1.00  LEARNED     the user already approved this exact pairing on this
 *                     endpoint. Nothing outranks a human decision.
 *   0.80  TRANSFERRED the same pairing was approved on a DIFFERENT endpoint.
 *                     Strong, but not certain: two endpoints can send similar
 *                     payloads to different destinations.
 *   0.90  DICTIONARY  both sides resolve to the same canonical meaning
 *                     (attendee_email and email are both `email`).
 *   0.50- FUZZY       token overlap plus edit distance on the leaf key.
 *   0.75
 *
 * Note that DICTIONARY outranks TRANSFERRED deliberately. A synonym match on
 * THIS payload is more trustworthy than a decision made about a different
 * endpoint's payload, because the transferred rule may be pointing at a path
 * that means something else here.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * THE THREE THINGS THAT STOP CONFIDENT NONSENSE
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * 1. ROLE PENALTY. A Cal.com booking carries the organizer's email (the site
 *    owner) and the attendee's (the customer). Both are perfect `email`
 *    matches. Without a role signal a coin flip decides whether every booking
 *    record gets the owner's own address - and it would never look like a bug.
 *    Owner-role candidates are therefore penalised hard.
 *
 * 2. RELIABILITY WEIGHTING. The introspector measures how often each field
 *    actually carried a value. Stripe's `customer_email` is null on a completed
 *    session while `customer_details.email` holds the address; weighting by
 *    non_null_rate is what makes the mapper pick the one that works.
 *
 * 3. VALUE-SHAPE GATES. A target field typed `email` will not accept a source
 *    whose sampled values are not email-shaped, no matter how well the names
 *    match. `contact_id` contains the token `contact`, and a numeric id must not
 *    be offered for an email column because of it.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * ONE-TO-ONE ASSIGNMENT
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * Scores alone are not an answer. Offering both `attendee.email` and
 * `organizer.email` for the same target field would put the decision back on the
 * user for exactly the case they are least equipped to judge. So candidates are
 * sorted by score and assigned greedily, each source and each target used at
 * most once. The result is a list the user can accept wholesale.
 *
 * @package NomadCMS\Webhooks\Mapping
 */

declare(strict_types=1);

namespace NomadCMS\Webhooks\Mapping;

final class HeuristicMapper
{
    /** Below this, no suggestion is offered at all. */
    public const MIN_CONFIDENCE = 0.5;

    /**
     * Hard ceiling on how many suggestions come back from one suggest() call.
     *
     * The 1:1 assignment above already prevents duplicates, but it does not
     * prevent VOLUME: a target with forty columns against a forty-field
     * payload can legitimately clear MIN_CONFIDENCE on every single pairing,
     * and presenting forty "suggestions" at once is not a shortlist any more
     * - it is just the whole table with a sparkle icon on it, which defeats
     * the entire point of "glance and accept". Candidates are already sorted
     * by confidence descending (see the usort below), so truncating here
     * keeps exactly the strongest N and drops the rest back into
     * unmatched_targets/unmatched_sources, where the table/canvas still let
     * the user map them by hand - nothing is hidden, only de-prioritised.
     */
    public const MAX_SUGGESTIONS = 15;

    public const ORIGIN_LEARNED = 'learned';
    public const ORIGIN_TRANSFERRED = 'transferred';
    public const ORIGIN_DICTIONARY = 'dictionary';

    /**
     * Matched on the SHAPE OF THE VALUE rather than on any name.
     *
     * Not a fallback curiosity - it is the only thing that works for a provider
     * whose keys are opaque ids. Typeform's field key is `SMEUb7VJz92Q`; no
     * dictionary will ever match it. But its sampled values are email-shaped and
     * the target column expects an email, and that is real evidence.
     */
    public const ORIGIN_SHAPE = 'shape';

    public const ORIGIN_FUZZY = 'fuzzy';

    private const SCORE_LEARNED = 1.0;
    private const SCORE_DICTIONARY = 0.9;
    private const SCORE_TRANSFERRED = 0.8;

    /**
     * Shape agreement on a DISTINCTIVE type.
     *
     * Below dictionary and transferred: agreeing on "this is an email" is weaker
     * than agreeing on what the field is called, because a payload can contain
     * several email-shaped values.
     */
    private const SCORE_SHAPE = 0.7;

    /** Lifts a candidate that clearly belongs to the other party. */
    private const ROLE_CUSTOMER_BONUS = 0.06;

    /**
     * Pushes down a candidate that belongs to US.
     *
     * Large on purpose: it must be able to demote a perfect dictionary match
     * (0.90 -> 0.55) below a merely good one, because a wrong-party email that
     * looks right is the worst failure this feature can produce.
     */
    private const ROLE_OWNER_PENALTY = 0.35;

    /** Applied when the sample never showed a value, so shape is unverifiable. */
    private const UNVERIFIABLE_FACTOR = 0.6;

    /**
     * Propose pairings.
     *
     * @param array<int, array<string, mixed>> $sourceFields From PayloadIntrospector
     * @param array<int, array<string, mixed>> $targetFields From TargetCatalogService
     * @param array<int, array<string, mixed>> $learnedRules Rows from webhook_mapping_rules
     * @param string $endpointSlug The endpoint being mapped
     * @return array{
     *     suggestions: array<int, array<string, mixed>>,
     *     unmatched_sources: array<int, string>,
     *     unmatched_targets: array<int, string>
     * }
     */
    public function suggest(
        array $sourceFields,
        array $targetFields,
        array $learnedRules = [],
        string $endpointSlug = ''
    ): array {
        $candidates = [];

        foreach ($sourceFields as $source) {
            foreach ($targetFields as $target) {
                $candidate = $this->score($source, $target, $learnedRules, $endpointSlug);
                if ($candidate !== null) {
                    $candidates[] = $candidate;
                }
            }
        }

        // Highest score first; ties broken by reliability, then by path so the
        // output is deterministic (a UI that reshuffles between refreshes for no
        // reason destroys the user's trust faster than a wrong suggestion).
        usort($candidates, static function ($a, $b) {
            if ($a['confidence'] !== $b['confidence']) {
                return $b['confidence'] <=> $a['confidence'];
            }
            if ($a['_non_null'] !== $b['_non_null']) {
                return $b['_non_null'] <=> $a['_non_null'];
            }
            return strcmp($a['source_path'], $b['source_path']);
        });

        $usedSources = [];
        $usedTargets = [];
        $suggestions = [];

        foreach ($candidates as $candidate) {
            if (isset($usedSources[$candidate['source_path']]) || isset($usedTargets[$candidate['target_field']])) {
                continue;
            }

            $usedSources[$candidate['source_path']] = true;
            $usedTargets[$candidate['target_field']] = true;

            unset($candidate['_non_null']);
            $suggestions[] = $candidate;
        }

        // Keep only the strongest MAX_SUGGESTIONS - the list is already sorted
        // by confidence descending, so this is exactly "drop the weakest
        // tail". Anything cut here is not lost: it falls through to the
        // unmatched_* lists below (recomputed from THIS truncated set, not
        // the pre-truncation one), where the table/canvas still offer it as
        // a normal, empty, mappable row - just without a sparkle on it.
        if (count($suggestions) > self::MAX_SUGGESTIONS) {
            $suggestions = array_slice($suggestions, 0, self::MAX_SUGGESTIONS);

            $usedSources = [];
            $usedTargets = [];
            foreach ($suggestions as $kept) {
                $usedSources[$kept['source_path']] = true;
                $usedTargets[$kept['target_field']] = true;
            }
        }

        $unmatchedSources = [];
        foreach ($sourceFields as $source) {
            $path = (string) $source['path'];
            if (!isset($usedSources[$path])) {
                $unmatchedSources[] = $path;
            }
        }

        $unmatchedTargets = [];
        foreach ($targetFields as $target) {
            $name = (string) $target['name'];
            if (!isset($usedTargets[$name])) {
                $unmatchedTargets[] = $name;
            }
        }

        return [
            'suggestions' => $suggestions,
            'unmatched_sources' => $unmatchedSources,
            'unmatched_targets' => $unmatchedTargets,
        ];
    }

    // =========================================================================
    // SCORING
    // =========================================================================

    /**
     * @param array<string, mixed> $source
     * @param array<string, mixed> $target
     * @param array<int, array<string, mixed>> $learnedRules
     * @return array<string, mixed>|null
     */
    private function score(array $source, array $target, array $learnedRules, string $endpointSlug): ?array
    {
        $sourcePath = (string) $source['path'];
        $sourceSpace = (string) ($source['space'] ?? WebhookEventsSchema::SPACE_RAW);
        $targetName = (string) $target['name'];

        // --- A human decision short-circuits everything -----------------------
        $learned = $this->findLearnedRule($learnedRules, $sourceSpace, $sourcePath, $targetName, $endpointSlug);
        if ($learned !== null) {
            return $this->candidate(
                $source,
                $target,
                $learned['same_endpoint'] ? self::SCORE_LEARNED : self::SCORE_TRANSFERRED,
                $learned['same_endpoint'] ? self::ORIGIN_LEARNED : self::ORIGIN_TRANSFERRED,
                $learned['same_endpoint']
                    ? 'Ezt a párosítást korábban te magad hagytad jóvá.'
                    : 'Egy másik végponton már összekötötted ugyanezt a két mezőt.',
                $learned['transform']
            );
        }

        // --- Value-shape gate BEFORE name scoring ----------------------------
        // Checked first so a strong name match cannot smuggle an incompatible
        // value past the gate on score alone.
        $sourceType = (string) ($source['type'] ?? 'string');
        $compatibility = $this->typeCompatibility($sourceType, $target);
        if ($compatibility === 'reject') {
            return null;
        }

        $sourceCanonical = $source['canonical'] ?? null;
        $targetCanonical = $target['canonical'] ?? null;

        $base = null;
        $origin = null;
        $reason = null;

        if ($sourceCanonical !== null && $sourceCanonical === $targetCanonical) {
            $base = self::SCORE_DICTIONARY;
            $origin = self::ORIGIN_DICTIONARY;
            $reason = sprintf(
                'A „%s” és a „%s” ugyanazt jelenti: %s.',
                (string) $source['key'],
                $targetName,
                FieldSynonyms::labelForGroup((string) $sourceCanonical) ?? (string) $sourceCanonical
            );
        } elseif ($this->shapesAgreeDistinctively($sourceType, $target)) {
            // The only route that works for opaque-keyed providers.
            $base = self::SCORE_SHAPE;
            $origin = self::ORIGIN_SHAPE;
            $reason = sprintf(
                'A beérkező érték %s, és a „%s” mező is ilyet vár.',
                $this->shapeInHungarian($sourceType),
                (string) ($target['label'] ?? $targetName)
            );
        } else {
            $similarity = $this->nameSimilarity((string) $source['key'], $targetName, (string) ($target['label'] ?? ''));
            if ($similarity > 0.0) {
                // Map similarity onto 0.50-0.75, so a fuzzy hit can never reach
                // dictionary confidence.
                $base = 0.5 + ($similarity * 0.25);
                $origin = self::ORIGIN_FUZZY;
                $reason = sprintf('A mezőnevek hasonlítanak: „%s” ↔ „%s”.', (string) $source['key'], $targetName);
            }
        }

        if ($base === null) {
            return null;
        }

        // --- Role adjustment --------------------------------------------------
        $role = $source['role'] ?? null;
        if ($role === 'customer') {
            $base += self::ROLE_CUSTOMER_BONUS;
            $reason .= ' Ez az ügyfél adata.';
        } elseif ($role === 'owner') {
            $base -= self::ROLE_OWNER_PENALTY;
            $reason .= ' FIGYELEM: ez a szervező (a te) adata, nem az ügyfélé.';
        }

        // --- Reliability weighting -------------------------------------------
        $nonNull = (float) ($source['non_null_rate'] ?? 1.0);
        $base *= (0.6 + (0.4 * $nonNull));
        if ($nonNull < 1.0) {
            $reason .= sprintf(' A mintában az esetek %d%%-ában volt kitöltve.', (int) round($nonNull * 100));
        }

        if ($compatibility === 'unverifiable') {
            // Never saw a value, so the shape gate could not run.
            $base *= self::UNVERIFIABLE_FACTOR;
            $reason .= ' A mintában nem szerepelt érték, ezért érdemes ellenőrizni.';
        }

        $base = round(min(1.0, max(0.0, $base)), 3);

        if ($base < self::MIN_CONFIDENCE) {
            // Better an empty row the user fills in than a confident mistake.
            return null;
        }

        return $this->candidate($source, $target, $base, (string) $origin, (string) $reason, $this->suggestTransform($source, $target));
    }

    /**
     * @param array<string, mixed> $source
     * @param array<string, mixed> $target
     * @return array<string, mixed>
     */
    private function candidate(
        array $source,
        array $target,
        float $confidence,
        string $origin,
        string $reason,
        ?string $transform
    ): array {
        return [
            'source_space' => (string) ($source['space'] ?? WebhookEventsSchema::SPACE_RAW),
            'source_path' => (string) $source['path'],
            'source_label' => (string) ($source['display'] ?? $source['path']),
            'source_sample' => $source['sample'] ?? null,
            'target_field' => (string) $target['name'],
            'target_label' => (string) ($target['label'] ?? $target['name']),
            'confidence' => round($confidence, 3),
            'origin' => $origin,
            'reason' => $reason,
            'transform' => $transform,
            '_non_null' => (float) ($source['non_null_rate'] ?? 1.0),
        ];
    }

    // =========================================================================
    // LEARNED RULES
    // =========================================================================

    /**
     * @param array<int, array<string, mixed>> $rules
     * @return array{same_endpoint:bool, transform:string|null}|null
     */
    private function findLearnedRule(
        array $rules,
        string $sourceSpace,
        string $sourcePath,
        string $targetField,
        string $endpointSlug
    ): ?array {
        $fallback = null;

        foreach ($rules as $rule) {
            if ((string) ($rule['source_path'] ?? '') !== $sourcePath) {
                continue;
            }
            if ((string) ($rule['target_field'] ?? '') !== $targetField) {
                continue;
            }
            if ((string) ($rule['source_space'] ?? WebhookEventsSchema::SPACE_RAW) !== $sourceSpace) {
                continue;
            }

            $transform = isset($rule['transform']) && $rule['transform'] !== ''
                ? (string) $rule['transform']
                : null;

            if ((string) ($rule['endpoint_slug'] ?? '') === $endpointSlug) {
                // Exact match on this endpoint - cannot be beaten.
                return ['same_endpoint' => true, 'transform' => $transform];
            }

            $fallback ??= ['same_endpoint' => false, 'transform' => $transform];
        }

        return $fallback;
    }

    // =========================================================================
    // TYPE GATES
    // =========================================================================

    /**
     * @param array<string, mixed> $target
     * @return string 'ok' | 'unverifiable' | 'reject'
     */
    private function typeCompatibility(string $sourceType, array $target): string
    {
        // --- Class-level exclusions ------------------------------------------
        // Independent of the expected shape, because these are wrong for reasons
        // no name could redeem. Without this, Cal.com's `hideCalendarNotes`
        // (a BOOLEAN whose key tokenises to `notes`) scores a perfect dictionary
        // match against a `message` field - and the automapper would confidently
        // write "nem" into every booking's message column.
        if (!$this->sourceClassAllowed($sourceType, $target)) {
            return 'reject';
        }

        $expected = $this->expectedShape($target);
        if ($expected === null) {
            return 'ok';
        }

        if ($sourceType === 'null') {
            // The field exists but the sample never carried a value, so we
            // cannot check its shape. Downgrade rather than reject: a Typeform
            // question skipped in every sampled submission is still legitimately
            // mappable.
            return 'unverifiable';
        }

        $accepted = match ($expected) {
            'email' => ['email'],
            'phone' => ['phone', 'numeric_string'],
            'datetime' => ['datetime'],
            'numeric' => ['number', 'numeric_string'],
            'url' => ['url'],
            'postalish' => ['numeric_string', 'number', 'string'],
            default => null,
        };

        if ($accepted === null) {
            return 'ok';
        }

        return in_array($sourceType, $accepted, true) ? 'ok' : 'reject';
    }

    /**
     * Reject value CLASSES that cannot sensibly land in this kind of column.
     *
     * @param array<string, mixed> $target
     */
    private function sourceClassAllowed(string $sourceType, array $target): bool
    {
        $targetType = strtolower((string) ($target['type'] ?? 'text'));
        $booleanTargets = ['boolean', 'checkbox'];

        // A list has no single value to write into a scalar column.
        if ($sourceType === 'list') {
            return false;
        }

        if ($sourceType === 'boolean') {
            // A yes/no answer belongs in a yes/no column. Anywhere else it
            // becomes the literal string "nem", which is never what was meant.
            return in_array($targetType, $booleanTargets, true);
        }

        if (in_array($targetType, $booleanTargets, true)) {
            // Conversely, only a boolean (or an explicitly unverifiable field)
            // should be offered for a checkbox.
            return in_array($sourceType, ['boolean', 'null'], true);
        }

        return true;
    }

    /**
     * True when source and target agree on a DISTINCTIVE value shape.
     *
     * Distinctive means "a shape that is unlikely to be a coincidence". `string`
     * and `numeric` are excluded: half a payload is strings, so agreeing on
     * "both are text" carries no information and would generate noise.
     *
     * @param array<string, mixed> $target
     */
    private function shapesAgreeDistinctively(string $sourceType, array $target): bool
    {
        $expected = $this->expectedShape($target);
        if ($expected === null) {
            return false;
        }

        return match ($expected) {
            'email' => $sourceType === 'email',
            'phone' => $sourceType === 'phone',
            'datetime' => $sourceType === 'datetime',
            'url' => $sourceType === 'url',
            default => false,
        };
    }

    private function shapeInHungarian(string $sourceType): string
    {
        return match ($sourceType) {
            'email' => 'e-mail cím',
            'phone' => 'telefonszám',
            'datetime' => 'dátum',
            'url' => 'webcím',
            default => 'megfelelő formátumú',
        };
    }

    /**
     * The value shape a target field demands, from its declared type first and
     * its canonical meaning second.
     *
     * Declared type wins because it is a fact about the destination column,
     * whereas the canonical group is our inference about its name.
     *
     * @param array<string, mixed> $target
     */
    private function expectedShape(array $target): ?string
    {
        $declared = strtolower((string) ($target['type'] ?? ''));

        $fromDeclaredType = match ($declared) {
            'email' => 'email',
            'tel' => 'phone',
            'date', 'datetime' => 'datetime',
            'number' => 'numeric',
            'url' => 'url',
            default => null,
        };

        if ($fromDeclaredType !== null) {
            return $fromDeclaredType;
        }

        $canonical = $target['canonical'] ?? null;

        return is_string($canonical) ? FieldSynonyms::valueShape($canonical) : null;
    }

    // =========================================================================
    // TRANSFORMS
    // =========================================================================

    /**
     * Propose a value transform where the raw value would otherwise be wrong.
     *
     * @param array<string, mixed> $source
     * @param array<string, mixed> $target
     */
    private function suggestTransform(array $source, array $target): ?string
    {
        $sourceType = (string) ($source['type'] ?? 'string');
        $sourceCanonical = $source['canonical'] ?? null;
        $targetType = strtolower((string) ($target['type'] ?? ''));

        // Money in minor units. Stripe reports `amount_total: 2198` meaning
        // 21.98; copying it verbatim into a price column is a hundredfold error
        // that looks like a plausible number, which is why it is proposed
        // automatically rather than left to the user to notice.
        if ($sourceCanonical === FieldSynonyms::AMOUNT
            && $sourceType === 'number'
            && $this->pathSuggestsMinorUnits((string) $source['path'])) {
            return WebhookEventsSchema::TRANSFORM_MINOR_TO_MAJOR;
        }

        // A date column receiving an ISO timestamp with a time component.
        if ($targetType === 'date' && !isset($target['granularity']) && !isset($target['extraGranularity']) && $sourceType === 'datetime') {
            return WebhookEventsSchema::TRANSFORM_DATE_ISO;
        }

        if ($targetType === 'tel' && $sourceType === 'phone') {
            return WebhookEventsSchema::TRANSFORM_PHONE_E164;
        }

        if ($targetType === 'email' && $sourceType === 'email') {
            // Lowercasing an address makes it usable as a dedupe key later, and
            // is never destructive (the local part is case-insensitive at every
            // provider that matters in practice).
            return WebhookEventsSchema::TRANSFORM_LOWER;
        }

        return null;
    }

    /**
     * True for paths whose provider is known to report money in minor units.
     *
     * Deliberately narrow. Guessing "any integer amount must be cents" would
     * divide a Cal.com `price: 0` or a webshop's forint total by 100 and be a
     * far more damaging error than the one it prevents.
     */
    private function pathSuggestsMinorUnits(string $path): bool
    {
        $tokens = FieldSynonyms::tokeniseWithNoise($path);

        // The Stripe adapter's namespace, plus Stripe's own raw key.
        return (in_array('amount', $tokens, true) && in_array('total', $tokens, true))
            || in_array('subtotal', $tokens, true);
    }

    // =========================================================================
    // FUZZY NAME MATCHING
    // =========================================================================

    /**
     * Similarity in [0, 1] between a source leaf key and a target field.
     *
     * Combines token overlap (catches `guest_email` vs `email`) with normalised
     * edit distance (catches `emial` and `e_mail`). Both are needed: overlap
     * alone misses typos, distance alone rates `name` and `date` as similar.
     */
    private function nameSimilarity(string $sourceKey, string $targetName, string $targetLabel): float
    {
        $best = 0.0;

        foreach (array_filter([$targetName, $targetLabel]) as $candidate) {
            $sourceTokens = FieldSynonyms::tokenise($sourceKey);
            $targetTokens = FieldSynonyms::tokenise((string) $candidate);

            if ($sourceTokens === [] || $targetTokens === []) {
                continue;
            }

            $overlap = count(array_intersect($sourceTokens, $targetTokens));
            $jaccard = $overlap / count(array_unique(array_merge($sourceTokens, $targetTokens)));

            $a = implode('', $sourceTokens);
            $b = implode('', $targetTokens);
            $maxLen = max(strlen($a), strlen($b));
            $distance = $maxLen > 0 ? 1.0 - (levenshtein($a, $b) / $maxLen) : 0.0;

            // Overlap weighted higher: a shared whole token is much stronger
            // evidence than a small edit distance between short words.
            $score = ($jaccard * 0.7) + (max(0.0, $distance) * 0.3);

            $best = max($best, $score);
        }

        // Below this the "similarity" is noise - `date` and `name` differ by two
        // edits out of four characters and would otherwise score 0.5.
        return $best >= 0.45 ? min(1.0, $best) : 0.0;
    }
}
