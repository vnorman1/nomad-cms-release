<?php
/**
 * NOMAD CMS - Webhook Event Ingest Service
 *
 * The store-first entry point for incoming webhooks.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * WHY STORE-FIRST AT ALL
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * The old path validated a signature and then threw the payload away (it was
 * only ever error_log()'d). That makes the "connect a webhook in 3 clicks"
 * promise impossible: a non-technical user cannot map fields they have never
 * seen, and they cannot see fields unless we keep a sample.
 *
 * So a new endpoint starts in LEARNING mode: it accepts the provider's test
 * fire even without a shared secret, stores the raw body, and shows the user
 * the field list. It does NOT write to the CMS. Once the user is happy they
 * flip the endpoint to LIVE, at which point a signature becomes mandatory and
 * verified events are mapped into the chosen target automatically.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * THE STORAGE GATE - AND WHY INVALID SIGNATURES ARE *NOT* STORED WHEN LIVE
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *   mode      | signature | stored | status              | HTTP
 *   ----------|-----------|--------|---------------------|-----
 *   learning  | absent    | yes    | unverified          | 200
 *   learning  | valid     | yes    | verified            | 200
 *   learning  | wrong     | yes    | unverified          | 200
 *   live      | valid     | yes    | verified -> mapped  | 200
 *   live      | absent    | NO     | -                   | 401
 *   live      | wrong     | NO     | -                   | 401
 *
 * The last two rows are the important design decision. Storing rejected
 * requests would feel more "auditable", but it hands anyone who learns the
 * endpoint slug a write primitive into the event table. Combined with the
 * per-endpoint row cap that would become an EVICTION attack: flood the
 * endpoint with garbage and the oldest genuine events get swept out. Since a
 * live endpoint's legitimate traffic is always signed, refusing to store
 * unsigned traffic costs nothing and removes the amplification entirely.
 * Rejected attempts are logged instead.
 *
 * Learning mode does accept unsigned writes, and is bounded on four sides:
 * the per-endpoint rate limit, the 24-hour learning window
 * (learning_expires_at, after which the endpoint behaves as live), the
 * retention sweep, and the per-endpoint row cap.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * AN UNKNOWN SLUG STORES NOTHING
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * Resolution happens before any write. Without that, a scanner hitting random
 * slugs could grow the table without bound, and no rate limit keyed on the
 * endpoint would help (each miss is a different key).
 *
 * @package NomadCMS\Webhooks\Mapping
 */

declare(strict_types=1);

namespace NomadCMS\Webhooks\Mapping;

use NomadCMS\Middleware\WebhookMiddleware;
use NomadCMS\Security\EncryptionService;
use NomadCMS\Security\WebhookService;
use PDO;

/**
 * Outcome of an ingest attempt.
 *
 * Carries everything the HTTP layer needs to answer, plus everything the
 * background mapping step needs to run - so the endpoint script itself holds
 * no policy.
 */
final class IngestResult
{
    public function __construct(
        public readonly int $httpStatus,
        public readonly array $body,
        public readonly ?array $endpoint = null,
        public readonly ?int $eventId = null,
        public readonly ?array $payload = null,
        public readonly string $signatureState = WebhookEventsSchema::SIG_NONE,
        public readonly string $effectiveMode = WebhookEventsSchema::MODE_LEARNING,
        public readonly bool $shouldProcess = false,
        public readonly bool $stored = false,
        public readonly ?string $eventType = null,
        public readonly ?int $retryAfter = null
    ) {}

    public function isAccepted(): bool
    {
        return $this->httpStatus >= 200 && $this->httpStatus < 300;
    }
}

final class EventIngestService
{
    /** JSON depth ceiling, matching WebhookMiddleware::JSON_MAX_DEPTH */
    private const JSON_MAX_DEPTH = 64;

    /**
     * Header names whose VALUE must never reach the database.
     *
     * The presence of the header is still recorded (as the string '[redacted]'),
     * because "did this request carry a signature at all?" is genuinely useful
     * when helping a user debug their setup - while the credential itself is
     * useless to us and a liability at rest.
     *
     * Matching is done on a normalised lowercase name, and any header whose
     * name merely CONTAINS one of these markers is redacted too, so provider
     * specific variants (x-cal-signature-256, typeform-signature,
     * x-hub-signature-256, ...) are covered without enumerating them.
     */
    private const REDACT_HEADER_MARKERS = [
        'authorization',
        'cookie',
        'signature',
        'api-key',
        'apikey',
        'token',
        'secret',
        'password',
    ];

    private WebhookService $webhookService;

    public function __construct(?WebhookService $webhookService = null)
    {
        $this->webhookService = $webhookService ?? new WebhookService();
    }

    /**
     * Resolve, guard, and (when the gate allows) persist one incoming request.
     *
     * @param string $endpointKey Slug from the URL
     * @param string|null $rawBody Raw request body; read from php://input when null
     * @param array<string, string>|null $headers Request headers; read from $_SERVER when null
     */
    public function ingest(string $endpointKey, ?string $rawBody = null, ?array $headers = null): IngestResult
    {
        $incomingEnabled = filter_var($_ENV['WEBHOOKS_INCOMING_ENABLED'] ?? true, FILTER_VALIDATE_BOOLEAN);
        if (!$incomingEnabled) {
            return $this->reject(503, 'Az beérkező webhookok le vannak tiltva.');
        }

        // --- 1. Slug shape. Cheapest possible rejection, before any I/O. ----
        if (!preg_match('/^[a-z0-9-]{3,64}$/', $endpointKey)) {
            return $this->reject(400, 'Érvénytelen végpont-azonosító.');
        }

        // --- 2. Resolve the endpoint. Unknown slug => nothing is stored. ----
        $endpoint = $this->webhookService->getEndpointByKey($endpointKey);
        if ($endpoint === null || !$endpoint['is_active']) {
            // Deliberately the same response for "does not exist" and "is
            // disabled": a scanner should not be able to enumerate which slugs
            // are real.
            return $this->reject(404, 'Ismeretlen végpont.');
        }

        // --- 3. Rate limit, before we read or parse a body. -----------------
        $rate = WebhookMiddleware::checkRateLimit($endpointKey);
        if (!($rate['allowed'] ?? true)) {
            error_log(sprintf(
                '[WebhookIngest] Rate limit hit: endpoint=%s current=%s max=%s',
                $endpointKey,
                (string) ($rate['current'] ?? '?'),
                (string) ($rate['max'] ?? '?')
            ));

            return new IngestResult(
                httpStatus: 429,
                body: ['success' => false, 'error' => 'Túl sok kérés. Próbáld később.'],
                endpoint: $endpoint,
                retryAfter: (int) ($rate['retry_after'] ?? 60)
            );
        }

        // --- 4. Body: presence and size. ------------------------------------
        $rawBody ??= (string) file_get_contents('php://input');

        if ($rawBody === '') {
            return $this->reject(400, 'Üres kérés-törzs.', $endpoint);
        }

        $payloadBytes = strlen($rawBody);
        if ($payloadBytes > WebhookEventsSchema::MAX_PAYLOAD_BYTES) {
            error_log(sprintf(
                '[WebhookIngest] Payload too large: endpoint=%s bytes=%d limit=%d',
                $endpointKey,
                $payloadBytes,
                WebhookEventsSchema::MAX_PAYLOAD_BYTES
            ));

            return $this->reject(413, 'A payload túl nagy.', $endpoint);
        }

        // --- 5. JSON. Store only well-formed documents, so every later JSON1
        //        query and every mapper read can assume valid JSON. ----------
        $payload = json_decode($rawBody, true, self::JSON_MAX_DEPTH);
        if (json_last_error() !== JSON_ERROR_NONE || !is_array($payload)) {
            return $this->reject(400, 'Érvénytelen JSON payload.', $endpoint);
        }

        // --- 6. Signature state (never throws; absent is a valid state). ----
        $headers ??= $this->collectHeaders();
        $signatureState = $this->evaluateSignature($endpoint, $rawBody, $headers);

        // --- 7. Effective mode. An expired learning window silently becomes
        //        live, which is what closes the unsigned-write hole. ---------
        $effectiveMode = $this->effectiveMode($endpoint);

        // --- 8. The storage gate. -------------------------------------------
        //
        // In live mode, HOW a request proves itself depends on the endpoint's
        // auth mode:
        //
        //   url_token   the unguessable URL it was sent to IS the proof, exactly
        //               as Discord/Slack/Zapier treat their own webhook URLs.
        //               A signature, if one happens to be present, is still
        //               recorded - but it is not required.
        //   signature   an HMAC over the body must verify. Required for anything
        //               that authorises something (payments above all), and what
        //               every endpoint created before auth modes existed uses.
        //
        // The url_token branch is only sound because createEndpoint() refuses to
        // put a short, human-chosen key on such an endpoint; without that
        // constraint this would reduce to "anyone who guesses a slug may write".
        $authMode = (string) ($endpoint['auth_mode'] ?? WebhookEventsSchema::AUTH_MODE_SIGNATURE);
        $requiresSignature = $authMode === WebhookEventsSchema::AUTH_MODE_SIGNATURE;

        if ($effectiveMode === WebhookEventsSchema::MODE_LIVE
            && $requiresSignature
            && $signatureState !== WebhookEventsSchema::SIG_VALID) {
            error_log(sprintf(
                '[WebhookIngest] Rejected unsigned/invalid request on live endpoint=%s state=%s ip=%s',
                $endpointKey,
                $signatureState,
                WebhookMiddleware::getClientIp()
            ));

            return $this->reject(401, 'Érvénytelen vagy hiányzó aláírás.', $endpoint);
        }

        // A wrong signature is refused even in url_token mode. The URL alone would
        // have been enough, but a sender that signs and signs WRONG is either
        // misconfigured or not who it claims to be, and silently accepting it
        // would make the signature setting meaningless once enabled.
        if ($effectiveMode === WebhookEventsSchema::MODE_LIVE
            && !$requiresSignature
            && $signatureState === WebhookEventsSchema::SIG_INVALID) {
            error_log(sprintf(
                '[WebhookIngest] Rejected badly-signed request on url_token endpoint=%s ip=%s',
                $endpointKey,
                WebhookMiddleware::getClientIp()
            ));

            return $this->reject(401, 'Az aláírás nem stimmel.', $endpoint);
        }

        // --- 9. Persist. -----------------------------------------------------
        $eventType = $this->detectEventType($payload);
        $idempotencyKey = $this->extractIdempotencyKey($headers, $payload);

        // An event counts as VERIFIED when it satisfied whatever this endpoint
        // requires - a valid signature, or arrival at a live url_token endpoint
        // whose unguessable URL is the credential. Marking the latter
        // "unverified" would make the event inbox claim nothing was authenticated
        // when in fact the endpoint's own rule was met.
        $authenticated = $signatureState === WebhookEventsSchema::SIG_VALID
            || (!$requiresSignature && $effectiveMode === WebhookEventsSchema::MODE_LIVE);

        $status = $authenticated
            ? WebhookEventsSchema::STATUS_VERIFIED
            : WebhookEventsSchema::STATUS_UNVERIFIED;

        $eventId = $this->persist(
            $endpointKey,
            $eventType,
            $rawBody,
            $this->sanitiseHeaders($headers),
            $status,
            $signatureState,
            $idempotencyKey,
            $payloadBytes
        );

        if ($eventId === null) {
            // The only expected cause is the UNIQUE idempotency index: the
            // provider re-delivered an event we already have. That is a success
            // from the provider's point of view, so answer 200 and do nothing.
            return new IngestResult(
                httpStatus: 200,
                body: ['success' => true, 'message' => 'Már feldolgozott esemény (duplikátum).', 'duplicate' => true],
                endpoint: $endpoint,
                payload: $payload,
                signatureState: $signatureState,
                effectiveMode: $effectiveMode,
                eventType: $eventType
            );
        }

        $this->webhookService->touchEndpoint((int) $endpoint['id']);

        $shouldProcess = $effectiveMode === WebhookEventsSchema::MODE_LIVE && $authenticated;

        return new IngestResult(
            httpStatus: 200,
            body: [
                'success' => true,
                'message' => $shouldProcess
                    ? 'Esemény elfogadva feldolgozásra.'
                    : 'Esemény eltárolva (teszt / tanuló mód, a CMS-be nem írunk).',
                'event_id' => $eventId,
                'mode' => $effectiveMode,
            ],
            endpoint: $endpoint,
            eventId: $eventId,
            payload: $payload,
            signatureState: $signatureState,
            effectiveMode: $effectiveMode,
            shouldProcess: $shouldProcess,
            stored: true,
            eventType: $eventType
        );
    }

    // =========================================================================
    // MODE
    // =========================================================================

    /**
     * The mode actually in force for this request.
     *
     * A learning endpoint whose window has elapsed is treated as live, so an
     * endpoint someone created and forgot about does not stay open to unsigned
     * traffic forever. A NULL window means "no expiry recorded" - for a
     * learning endpoint that is treated as EXPIRED rather than eternal,
     * because failing closed is the only safe reading of missing data here.
     */
    public function effectiveMode(array $endpoint): string
    {
        $stored = $endpoint['ingest_mode'] ?? WebhookEventsSchema::MODE_LIVE;

        if ($stored !== WebhookEventsSchema::MODE_LEARNING) {
            return WebhookEventsSchema::MODE_LIVE;
        }

        $expiresAt = $endpoint['learning_expires_at'] ?? null;
        if ($expiresAt === null || $expiresAt === '') {
            return WebhookEventsSchema::MODE_LIVE;
        }

        $expiry = strtotime((string) $expiresAt);
        if ($expiry === false || $expiry <= time()) {
            return WebhookEventsSchema::MODE_LIVE;
        }

        return WebhookEventsSchema::MODE_LEARNING;
    }

    // =========================================================================
    // SIGNATURE
    // =========================================================================

    /**
     * Classify the request's signature without ever throwing.
     *
     * @param array<string, string> $headers
     * @return string One of WebhookEventsSchema::SIGNATURE_STATES
     */
    public function evaluateSignature(array $endpoint, string $rawBody, array $headers): string
    {
        $signatureData = $this->extractSignature($endpoint, $headers);

        if ($signatureData['signature'] === null || $signatureData['signature'] === '') {
            return WebhookEventsSchema::SIG_NONE;
        }

        try {
            $secret = EncryptionService::decrypt((string) $endpoint['secret']);
        } catch (\Throwable $e) {
            error_log('[WebhookIngest] Secret decrypt failed: ' . $e->getMessage());
            return WebhookEventsSchema::SIG_INVALID;
        }

        if ($secret === '' || strlen($secret) < 8) {
            return WebhookEventsSchema::SIG_INVALID;
        }

        $valid = $this->webhookService->verifySignatureWithFormat(
            $rawBody,
            (string) $signatureData['signature'],
            $secret,
            $signatureData['timestamp'],
            (string) ($endpoint['signature_format'] ?? 'auto')
        );

        return $valid ? WebhookEventsSchema::SIG_VALID : WebhookEventsSchema::SIG_INVALID;
    }

    /**
     * Read the signature (and any timestamp) out of the supplied headers.
     *
     * Mirrors WebhookMiddleware's header handling but works on an injected
     * header map rather than $_SERVER, so the ingest path is testable without
     * a live request.
     *
     * @param array<string, string> $headers
     * @return array{signature: string|null, timestamp: int|null}
     */
    private function extractSignature(array $endpoint, array $headers): array
    {
        $normalised = [];
        foreach ($headers as $name => $value) {
            $normalised[strtolower((string) $name)] = (string) $value;
        }

        $candidates = [strtolower((string) ($endpoint['signature_header'] ?? 'X-Webhook-Signature'))];
        // Provider defaults, so an endpoint left on the generic header name
        // still verifies traffic from a known provider.
        foreach ([
            'x-nomad-signature',
            'x-cal-signature-256',
            'typeform-signature',
            'stripe-signature',
            'x-hub-signature-256',
            'x-hub-signature',
            'x-webhook-signature',
            'x-signature',
        ] as $fallback) {
            $candidates[] = $fallback;
        }

        $raw = null;
        foreach (array_unique($candidates) as $candidate) {
            if (isset($normalised[$candidate]) && $normalised[$candidate] !== '') {
                $raw = $normalised[$candidate];
                break;
            }
        }

        if ($raw === null) {
            return ['signature' => null, 'timestamp' => null];
        }

        $timestamp = null;

        // Stripe-style combined header: t=...,v1=...
        if (preg_match('/t=(\d+)/', $raw, $m)) {
            $timestamp = (int) $m[1];
        }
        if (preg_match('/v1=([A-Fa-f0-9]+)/', $raw, $m)) {
            $raw = $m[1];
        }

        if ($timestamp === null) {
            $timestampHeader = $endpoint['timestamp_header'] ?? null;
            $tsCandidates = [];
            if ($timestampHeader) {
                $tsCandidates[] = strtolower((string) $timestampHeader);
            }
            $tsCandidates = array_merge($tsCandidates, [
                'x-webhook-timestamp',
                'x-timestamp',
                'x-hook-timestamp',
            ]);

            foreach ($tsCandidates as $candidate) {
                if (isset($normalised[$candidate]) && $normalised[$candidate] !== '') {
                    $timestamp = (int) $normalised[$candidate];
                    break;
                }
            }
        }

        return ['signature' => trim($raw), 'timestamp' => $timestamp];
    }

    // =========================================================================
    // HEADERS
    // =========================================================================

    /**
     * Build a header map from $_SERVER (HTTP_* entries).
     *
     * @return array<string, string>
     */
    public function collectHeaders(): array
    {
        if (function_exists('getallheaders')) {
            $headers = getallheaders();
            if (is_array($headers) && $headers !== []) {
                return array_map(static fn($v) => (string) $v, $headers);
            }
        }

        $headers = [];
        foreach ($_SERVER as $key => $value) {
            if (!is_string($key) || !str_starts_with($key, 'HTTP_')) {
                continue;
            }
            $name = str_replace(' ', '-', ucwords(strtolower(str_replace('_', ' ', substr($key, 5)))));
            $headers[$name] = (string) $value;
        }

        return $headers;
    }

    /**
     * Strip credential VALUES while keeping the header names.
     *
     * This runs before the row is written, so a credential never lands in
     * massive.sqlite and therefore never lands in a backup either.
     *
     * @param array<string, string> $headers
     * @return array<string, string>
     */
    public function sanitiseHeaders(array $headers): array
    {
        $clean = [];

        foreach ($headers as $name => $value) {
            $lower = strtolower((string) $name);
            $redact = false;

            foreach (self::REDACT_HEADER_MARKERS as $marker) {
                if (str_contains($lower, $marker)) {
                    $redact = true;
                    break;
                }
            }

            $clean[(string) $name] = $redact
                ? '[redacted]'
                : $this->truncate((string) $value, 512);
        }

        return $clean;
    }

    private function truncate(string $value, int $max): string
    {
        return strlen($value) > $max ? substr($value, 0, $max) . '…' : $value;
    }

    // =========================================================================
    // EVENT TYPE & IDEMPOTENCY
    // =========================================================================

    /**
     * Pull the provider's event name out of the payload.
     *
     * The three keys checked here are exactly the three the supported
     * providers use: Cal.com sends `triggerEvent`, Stripe sends `type`,
     * Typeform sends `event_type`. `event` is the loose convention many
     * smaller services follow.
     */
    public function detectEventType(array $payload): ?string
    {
        foreach (['triggerEvent', 'type', 'event_type', 'event'] as $key) {
            $value = $payload[$key] ?? null;
            if (is_string($value) && $value !== '') {
                return $this->truncate($value, 128);
            }
        }

        return null;
    }

    /**
     * @param array<string, string> $headers
     */
    private function extractIdempotencyKey(array $headers, array $payload): ?string
    {
        foreach ($headers as $name => $value) {
            $lower = strtolower((string) $name);
            if (in_array($lower, ['x-idempotency-key', 'idempotency-key', 'x-webhook-id'], true)
                && $value !== '') {
                return $this->truncate((string) $value, 128);
            }
        }

        // Fall back to a provider-supplied event id where one exists. We
        // deliberately do NOT hash the whole body as a last resort: two
        // genuinely distinct events can legitimately carry identical bodies
        // (think two "meeting started" pings for a recurring slot), and a
        // body hash would silently drop the second one.
        foreach ([
            $payload['id'] ?? null,                      // Stripe evt_...
            $payload['event_id'] ?? null,                 // Typeform
            $payload['idempotencyKey'] ?? null,           // Cal.com flat variants
        ] as $candidate) {
            if (is_string($candidate) && $candidate !== '') {
                return $this->truncate($candidate, 128);
            }
        }

        return null;
    }

    // =========================================================================
    // PERSISTENCE
    // =========================================================================

    /**
     * Insert the event row.
     *
     * @return int|null The new id, or null when the idempotency index rejected
     *                  the row as a duplicate.
     */
    private function persist(
        string $endpointSlug,
        ?string $eventType,
        string $rawPayload,
        array $sanitisedHeaders,
        string $status,
        string $signatureState,
        ?string $idempotencyKey,
        int $payloadBytes
    ): ?int {
        WebhookEventsSchema::ensureTables();
        $db = WebhookEventsSchema::db();
        $table = WebhookEventsSchema::TABLE_EVENTS;

        $ownTransaction = !$db->inTransaction();
        if ($ownTransaction) {
            $db->beginTransaction();
        }

        try {
            $stmt = $db->prepare("
                INSERT INTO {$table}
                    (endpoint_slug, event_type, payload, headers, status, signature_state, idempotency_key, payload_bytes)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ");
            $stmt->execute([
                $endpointSlug,
                $eventType,
                $rawPayload,
                json_encode($sanitisedHeaders, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
                $status,
                $signatureState,
                $idempotencyKey,
                $payloadBytes,
            ]);

            $id = (int) $db->lastInsertId();

            if ($ownTransaction) {
                $db->commit();
            }

            return $id;
        } catch (\PDOException $e) {
            if ($ownTransaction && $db->inTransaction()) {
                $db->rollBack();
            }

            if ($this->isUniqueViolation($e)) {
                return null;
            }

            throw $e;
        }
    }

    private function isUniqueViolation(\PDOException $e): bool
    {
        $message = strtolower($e->getMessage());

        return str_contains($message, 'unique constraint failed')
            || str_contains($message, 'constraint violation');
    }

    // =========================================================================
    // HELPERS
    // =========================================================================

    private function reject(int $status, string $error, ?array $endpoint = null): IngestResult
    {
        return new IngestResult(
            httpStatus: $status,
            body: ['success' => false, 'error' => $error],
            endpoint: $endpoint
        );
    }
}
