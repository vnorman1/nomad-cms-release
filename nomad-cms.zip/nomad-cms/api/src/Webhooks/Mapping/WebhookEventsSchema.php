<?php
/**
 * NOMAD CMS - Webhook Events & Mapping Rules Schema
 *
 * Storage layout for the incoming-webhook event store and the learned
 * field-mapping rules that drive the automapper.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * WHY DEDICATED TABLES AND NOT MassiveDatabase's GENERIC DOC STORE
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * The Forms module (see {@see \NomadCMS\Services\Forms\FormsSchema}) stores its
 * documents through MassiveDatabase::ensureTable(), i.e. as `massive_<slot>`
 * tables shaped (id, data JSON, owner_uuid, created_at, updated_at) plus an
 * FTS5 companion. That is the right call there, because submissions need
 * full-text search and per-item ownership.
 *
 * The event store's access pattern is different. Every query filters on
 * endpoint_slug and/or status and orders by created_at:
 *
 *   - the mapper UI reads the last N events of ONE endpoint
 *   - the event inbox filters by status across endpoints
 *   - the retention sweep selects unverified rows older than X
 *   - the replay job walks the stored events of one endpoint
 *
 * Those are plain column predicates. Putting them inside a JSON blob would
 * force json_extract() expression indexes for values that are never anything
 * but scalars, and would pay a json_extract() per row for the ones the planner
 * cannot serve from an index. Real columns are both faster and simpler here,
 * so this module owns two normal tables in massive.sqlite instead.
 *
 * What we DO borrow from FormsSchema is its operational discipline:
 *   - ensureTables() is memoised per process (see $tablesReady)
 *   - index creation is guarded by a sqlite_version() check and never fatal
 *   - a failed migration degrades performance, never availability
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * PAYLOAD IS STORED AS PLAINTEXT JSON - ON PURPOSE
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * webhook_events.payload is the discovery surface of the whole feature: the
 * mapper UI has to read it to show the user which fields arrived, and the
 * heuristic mapper has to sample it to score candidates. Encrypting it would
 * make both impossible without a decrypt-everything step on every page load,
 * and would rule out SQLite JSON1 (json_extract) access entirely.
 *
 * The personal data in a raw payload is therefore protected by:
 *   - RETENTION, not secrecy: unverified events are swept after
 *     DEFAULT_RETENTION_DAYS (see WebhookEventRetentionService)
 *   - the TARGET's own protection: when an event is mapped into an encrypted
 *     Form, the durable copy lives in the Forms envelope ciphertext
 *   - HEADER SANITISATION on write: credentials never enter the table at all
 *     (see EventIngestService::sanitiseHeaders)
 *   - sample-value MASKING in the mapper API, so the UI never echoes a full
 *     email address or phone number back to the browser
 *
 * @package NomadCMS\Webhooks\Mapping
 */

declare(strict_types=1);

namespace NomadCMS\Webhooks\Mapping;

use NomadCMS\Database\MassiveDatabase;
use PDO;

final class WebhookEventsSchema
{
    /** Raw incoming event store */
    public const TABLE_EVENTS = 'webhook_events';

    /** Learned / approved field mapping rules */
    public const TABLE_RULES = 'webhook_mapping_rules';

    // =========================================================================
    // EVENT LIFECYCLE
    // =========================================================================

    /** Stored, signature absent or not yet checked. NEVER written to the CMS. */
    public const STATUS_UNVERIFIED = 'unverified';

    /** Signature verified, but no mapping has run yet (no rules, or no target). */
    public const STATUS_VERIFIED = 'verified';

    /** Successfully mapped into a target record. */
    public const STATUS_MAPPED = 'mapped';

    /** Mapping was attempted and failed (bad signature, validation, target error). */
    public const STATUS_FAILED = 'failed';

    /** Deliberately skipped (user chose not to map this event type). */
    public const STATUS_IGNORED = 'ignored';

    /** @var array<int, string> */
    public const STATUSES = [
        self::STATUS_UNVERIFIED,
        self::STATUS_VERIFIED,
        self::STATUS_MAPPED,
        self::STATUS_FAILED,
        self::STATUS_IGNORED,
    ];

    // =========================================================================
    // SIGNATURE STATE
    // =========================================================================

    /** No signature was presented (only tolerated in learning mode). */
    public const SIG_NONE = 'none';

    /** Signature present and correct. */
    public const SIG_VALID = 'valid';

    /** Signature present but wrong - a real red flag worth keeping. */
    public const SIG_INVALID = 'invalid';

    /** @var array<int, string> */
    public const SIGNATURE_STATES = [self::SIG_NONE, self::SIG_VALID, self::SIG_INVALID];

    // =========================================================================
    // INGEST MODES (stored on webhook_endpoints)
    // =========================================================================

    /**
     * Test / learning mode - the default for a new endpoint.
     *
     * Accepts unsigned requests so the user can fire a test event from the
     * provider and immediately see the field list, but NEVER writes to the CMS.
     */
    public const MODE_LEARNING = 'learning';

    /**
     * Live mode - a request that proves itself is mapped into the configured
     * target automatically. How it proves itself depends on AUTH_MODE_* below.
     */
    public const MODE_LIVE = 'live';

    /** @var array<int, string> */
    public const MODES = [self::MODE_LEARNING, self::MODE_LIVE];

    // =========================================================================
    // AUTHENTICATION MODES
    // =========================================================================

    /**
     * The URL is the credential.
     *
     * ═══════════════════════════════════════════════════════════════════════
     * WHY THIS IS A LEGITIMATE MODE AND NOT A SHORTCUT
     * ═══════════════════════════════════════════════════════════════════════
     *
     * Discord, Slack and Zapier all authenticate their own incoming webhooks
     * exactly this way: the URL contains an unguessable token, and possession of
     * the URL is the proof. It is the industry norm for this shape of problem.
     *
     * It removes the single hardest step of setting up a webhook. Asking a
     * content manager which HTTP header their provider signs with, and which of
     * eight hash constructions it uses, is asking a question they cannot answer -
     * and getting it wrong produces an indistinguishable 401.
     *
     * ═══════════════════════════════════════════════════════════════════════
     * WHAT MAKES IT SAFE, AND WHAT DOES NOT
     * ═══════════════════════════════════════════════════════════════════════
     *
     * It is safe ONLY because the path segment is high-entropy. A friendly slug
     * like "stripe-payments" is guessable, so this mode REFUSES to work with one:
     * the key is generated (URL_TOKEN_BYTES of randomness) and short keys are
     * rejected. That constraint is the whole security argument, which is why it is
     * enforced in WebhookService rather than left to the UI.
     *
     * The residual risk is URL leakage through server logs and error reports.
     * There is no browser involved in a server-to-server delivery, so there is no
     * Referer exposure. Rate limiting, the retention sweep and the fact that a
     * mapped event can only ever write into the ONE configured target bound the
     * damage. For anything where that is not enough - payments, in particular -
     * AUTH_MODE_SIGNATURE exists and the UI steers Stripe/GitHub towards it.
     */
    public const AUTH_MODE_URL_TOKEN = 'url_token';

    /**
     * HMAC signature over the body, verified against a shared secret.
     *
     * Required for providers that sign (Stripe, GitHub, Cal.com, Typeform) and
     * the right choice whenever the payload authorises something.
     */
    public const AUTH_MODE_SIGNATURE = 'signature';

    /** @var array<int, string> */
    public const AUTH_MODES = [self::AUTH_MODE_URL_TOKEN, self::AUTH_MODE_SIGNATURE];

    /**
     * Randomness in the generated URL token.
     *
     * 24 bytes is 192 bits, rendered as 48 hex characters. Far beyond guessable,
     * and still short enough to paste into a provider's URL field without the
     * user suspecting something went wrong.
     */
    public const URL_TOKEN_BYTES = 24;

    /**
     * Shortest endpoint key accepted in url_token mode.
     *
     * Enforced because the entropy of this string IS the authentication. A
     * hand-typed key would silently downgrade the endpoint to "anyone who can
     * guess a slug may post here".
     */
    public const MIN_URL_TOKEN_LENGTH = 32;

    // =========================================================================
    // TARGET KINDS (two-level target selector)
    // =========================================================================

    /** Native Form submission inbox (inherits Forms encryption + CSV export) */
    public const TARGET_FORM = 'form';

    /** A `massive` type slot (high-volume collections) */
    public const TARGET_MASSIVE = 'massive';

    /** A regular content slot (object / list) */
    public const TARGET_CONTENT = 'content';

    /** @var array<int, string> */
    public const TARGET_KINDS = [self::TARGET_FORM, self::TARGET_MASSIVE, self::TARGET_CONTENT];

    // =========================================================================
    // RULE PROVENANCE & SOURCE NAMESPACE
    // =========================================================================

    /** Explicitly approved by a human - the strongest signal we have. */
    public const ORIGIN_USER = 'user';

    /** Auto-created by the heuristic mapper (only when auto-apply is on). */
    public const ORIGIN_HEURISTIC = 'heuristic';

    /** @var array<int, string> */
    public const ORIGINS = [self::ORIGIN_USER, self::ORIGIN_HEURISTIC];

    /** source_path points into the untouched provider payload. */
    public const SPACE_RAW = 'raw';

    /**
     * source_path points into the PayloadNormalizer output.
     *
     * Required for providers whose raw shape cannot be addressed stably - most
     * importantly Typeform, whose `answers` array omits unanswered questions,
     * so `answers[1]` silently means a DIFFERENT question from one submission
     * to the next. See PayloadNormalizer for the full argument.
     */
    public const SPACE_NORMALIZED = 'normalized';

    /** @var array<int, string> */
    public const SOURCE_SPACES = [self::SPACE_RAW, self::SPACE_NORMALIZED];

    // =========================================================================
    // VALUE TRANSFORMS
    // =========================================================================

    /** Trim surrounding whitespace. */
    public const TRANSFORM_TRIM = 'trim';

    /** Lowercase (useful for emails used as a dedupe key). */
    public const TRANSFORM_LOWER = 'lower';

    /** Normalise any parseable datetime to ISO-8601. */
    public const TRANSFORM_DATE_ISO = 'date_iso';

    /**
     * Divide by 100.
     *
     * Stripe reports money in MINOR units: `amount_total: 2198` means 21.98.
     * Copying it verbatim into a price field is a two-orders-of-magnitude bug,
     * so the heuristic proposes this transform whenever an amount-like key
     * carries an integer.
     */
    public const TRANSFORM_MINOR_TO_MAJOR = 'minor_to_major';

    /** Best-effort E.164 phone normalisation. */
    public const TRANSFORM_PHONE_E164 = 'phone_e164';

    /** @var array<int, string> */
    public const TRANSFORMS = [
        self::TRANSFORM_TRIM,
        self::TRANSFORM_LOWER,
        self::TRANSFORM_DATE_ISO,
        self::TRANSFORM_MINOR_TO_MAJOR,
        self::TRANSFORM_PHONE_E164,
    ];

    // =========================================================================
    // LIMITS
    // =========================================================================

    /** Hard ceiling on a stored payload. Larger requests are rejected with 413. */
    public const MAX_PAYLOAD_BYTES = 262144; // 256 KB

    /** Unsigned/unmapped events are swept after this many days. */
    public const DEFAULT_RETENTION_DAYS = 30;

    /** Never keep more than this many events per endpoint (oldest evicted). */
    public const MAX_EVENTS_PER_ENDPOINT = 500;

    /** A new endpoint stays open for unsigned traffic for this long. */
    public const LEARNING_WINDOW_SECONDS = 86400; // 24 hours

    /** How many recent events the introspector samples to build the field list. */
    public const FIELD_SAMPLE_SIZE = 25;

    // =========================================================================
    // SCHEMA CREATION
    // =========================================================================

    /**
     * Guard so the (idempotent, but not free) schema check runs once per
     * process rather than once per repository call - same reasoning as
     * FormsSchema::$tablesReady.
     */
    private static bool $tablesReady = false;

    /** Guard for the one-time index migration. */
    private static bool $indexesReady = false;

    /**
     * Create both tables and their indexes. Idempotent and memoised.
     */
    public static function ensureTables(): void
    {
        if (self::$tablesReady) {
            return;
        }

        $db = self::db();

        $events = self::TABLE_EVENTS;
        $db->exec("
            CREATE TABLE IF NOT EXISTS {$events} (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                endpoint_slug TEXT NOT NULL,
                event_type TEXT,
                payload TEXT NOT NULL,
                headers TEXT,
                status TEXT NOT NULL DEFAULT '" . self::STATUS_UNVERIFIED . "',
                signature_state TEXT,
                idempotency_key TEXT,
                payload_bytes INTEGER,
                mapped_at TEXT,
                mapped_target TEXT,
                mapped_record_id TEXT,
                error TEXT,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
        ");

        $rules = self::TABLE_RULES;
        $db->exec("
            CREATE TABLE IF NOT EXISTS {$rules} (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                endpoint_slug TEXT NOT NULL,
                event_type TEXT,
                source_space TEXT NOT NULL DEFAULT '" . self::SPACE_RAW . "',
                source_path TEXT NOT NULL,
                target_kind TEXT NOT NULL,
                target_key TEXT NOT NULL,
                target_field TEXT NOT NULL,
                transform TEXT,
                confidence REAL DEFAULT 1.0,
                origin TEXT NOT NULL DEFAULT '" . self::ORIGIN_USER . "',
                is_active INTEGER DEFAULT 1,
                created_by INTEGER,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
        ");

        WebhookNotificationJournal::install($db);

        self::$tablesReady = true;

        self::ensureIndexes();
    }

    /**
     * Create the indexes the event inbox, retention sweep and mapper depend on.
     *
     * Index choice, and why each one exists:
     *
     *   idx_events_slug_created   the mapper UI's "last N events of THIS
     *                             endpoint" query. Compound, with created_at in
     *                             the index, so one index satisfies both the
     *                             filter and the ORDER BY - the same lesson
     *                             FormsSchema documents about standalone status
     *                             indexes making the global inbox slower.
     *   idx_events_status_created the cross-endpoint event inbox and the
     *                             retention sweep's candidate scan.
     *   idx_events_idem           idempotency. UNIQUE + partial, so the huge
     *                             majority of rows (providers that send no
     *                             idempotency key) are not indexed at all and
     *                             do not collide with each other on NULL.
     *   idx_rules_lookup          every mapping execution loads the active
     *                             rules of one endpoint; this is the hot path
     *                             of the live ingest.
     *   idx_rules_identity        UNIQUE, and the reason approving the same
     *                             pairing twice updates instead of duplicating.
     *
     * Partial indexes need SQLite >= 3.8.0 (2013). On anything older this
     * silently does nothing: the module keeps working, just without the
     * dedupe guarantee, rather than fataling on an ancient shared host.
     */
    public static function ensureIndexes(): void
    {
        if (self::$indexesReady) {
            return;
        }
        self::$indexesReady = true;

        $db = self::db();
        $events = self::TABLE_EVENTS;
        $rules = self::TABLE_RULES;

        try {
            $db->exec(
                "CREATE INDEX IF NOT EXISTS idx_{$events}_slug_created
                 ON {$events}(endpoint_slug, created_at DESC)"
            );
            $db->exec(
                "CREATE INDEX IF NOT EXISTS idx_{$events}_status_created
                 ON {$events}(status, created_at DESC)"
            );
            $db->exec(
                "CREATE INDEX IF NOT EXISTS idx_{$rules}_lookup
                 ON {$rules}(endpoint_slug, is_active)"
            );

            if (self::supportsPartialIndexes($db)) {
                $db->exec(
                    "CREATE UNIQUE INDEX IF NOT EXISTS idx_{$events}_idem
                     ON {$events}(endpoint_slug, idempotency_key)
                     WHERE idempotency_key IS NOT NULL"
                );
            }

            // Rule identity. NULL event_type means "any event", and SQLite
            // treats NULLs as distinct in a UNIQUE index, which would let a
            // duplicate any-event rule slip through. We therefore fold NULL to
            // '' via COALESCE in the index expression - this needs expression
            // index support (3.9+), so it is attempted separately and the
            // application-level upsert in MappingRuleRepository does not rely
            // on it being present.
            if (self::supportsExpressionIndexes($db)) {
                $db->exec(
                    "CREATE UNIQUE INDEX IF NOT EXISTS idx_{$rules}_identity
                     ON {$rules}(
                         endpoint_slug,
                         COALESCE(event_type, ''),
                         source_space,
                         source_path,
                         target_kind,
                         target_key,
                         target_field
                     )"
                );
            }
        } catch (\PDOException $e) {
            // A failed index build must never break webhook ingestion - the
            // queries still work, just slower. Log and continue.
            error_log('[WebhookMapping] Index migration skipped: ' . $e->getMessage());
        }
    }

    /**
     * Partial indexes (CREATE INDEX ... WHERE) need SQLite 3.8.0+.
     */
    private static function supportsPartialIndexes(PDO $db): bool
    {
        return version_compare(self::sqliteVersion($db), '3.8.0', '>=');
    }

    /**
     * Expression indexes (CREATE INDEX ... ON t(expr)) need SQLite 3.9.0+.
     */
    private static function supportsExpressionIndexes(PDO $db): bool
    {
        return version_compare(self::sqliteVersion($db), '3.9.0', '>=');
    }

    private static function sqliteVersion(PDO $db): string
    {
        return (string) $db->query('SELECT sqlite_version()')->fetchColumn();
    }

    /**
     * Shared PDO handle for massive.sqlite.
     */
    public static function db(): PDO
    {
        return MassiveDatabase::getInstance();
    }

    /**
     * Reset the memoisation guards.
     *
     * Test-only seam: a suite that drops the tables to check the migration is
     * re-runnable would otherwise be lied to by the process-level cache.
     */
    public static function resetSchemaCacheForTests(): void
    {
        self::$tablesReady = false;
        self::$indexesReady = false;
    }
}
