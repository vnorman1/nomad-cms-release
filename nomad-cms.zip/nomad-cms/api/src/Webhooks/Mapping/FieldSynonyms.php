<?php
/**
 * NOMAD CMS - Field Synonym Dictionary
 *
 * The single source of truth for "what does this field mean?", shared by the
 * labeler (which turns a raw key into Hungarian prose for the UI) and the
 * heuristic mapper (which scores candidate pairings).
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * WHY ONE FILE, AND WHY PHP ONLY
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * An earlier option was to ship this table to the browser too, so the mapper UI
 * could score instantly without a round trip. That was rejected: two copies of
 * a synonym table drift, and with no JavaScript test runner in this project the
 * TypeScript copy would drift SILENTLY. The frontend therefore asks the server
 * (action=suggest) and only performs text SEARCH locally.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * ROLE TOKENS - THE MOST IMPORTANT PART OF THIS FILE
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * A Cal.com booking payload contains TWO email addresses: the organizer's (the
 * CMS owner) and the attendee's (the customer). A dictionary that only knows
 * "email means email" will happily map the site owner's own address into every
 * booking record, forever, without erring once.
 *
 * So keys are scored on TWO axes: what the field IS (canonical group) and WHOSE
 * it is (role). ROLE_CUSTOMER tokens lift a candidate, ROLE_OWNER tokens push it
 * down. This is what makes the automapper trustworthy enough to offer to a
 * non-technical user with an "accept all" button.
 *
 * @package NomadCMS\Webhooks\Mapping
 */

declare(strict_types=1);

namespace NomadCMS\Webhooks\Mapping;

final class FieldSynonyms
{
    // =========================================================================
    // CANONICAL GROUPS
    // =========================================================================

    public const EMAIL = 'email';
    public const NAME = 'name';
    public const FIRST_NAME = 'first_name';
    public const LAST_NAME = 'last_name';
    public const PHONE = 'phone';
    public const DATE = 'date';
    public const END_DATE = 'end_date';
    public const MESSAGE = 'message';
    public const SUBJECT = 'subject';
    public const COMPANY = 'company';
    public const AMOUNT = 'amount';
    public const CURRENCY = 'currency';
    public const ADDRESS = 'address';
    public const CITY = 'city';
    public const POSTAL_CODE = 'postal_code';
    public const COUNTRY = 'country';
    public const QUANTITY = 'quantity';
    public const STATUS = 'status';
    public const URL = 'url';
    public const REFERENCE = 'reference';
    public const TITLE = 'title';
    public const LOCATION = 'location';

    /**
     * Token sets per canonical group.
     *
     * Tokens are matched against a NORMALISED key (lowercased, camelCase split,
     * separators collapsed to underscores). Hungarian variants are first-class,
     * not an afterthought: a Nomad form's field keys are routinely `nev`,
     * `telefon`, `uzenet`, and the whole UI is Hungarian.
     *
     * @var array<string, array<int, string>>
     */
    public const GROUPS = [
        self::EMAIL => [
            'email', 'e_mail', 'mail', 'email_address', 'mail_address', 'emailaddress',
            'from_email', 'contact_email', 'payer_email', 'booker_email', 'recipient_email',
            'e_mail_cim', 'email_cim', 'levelezesi_cim',
        ],
        self::NAME => [
            'name', 'full_name', 'fullname', 'display_name', 'displayname', 'user_name',
            'username', 'contact_name', 'nev', 'teljes_nev', 'nev_teljes',
        ],
        self::FIRST_NAME => [
            'first_name', 'firstname', 'given_name', 'givenname', 'forename',
            'keresztnev', 'utonev',
        ],
        self::LAST_NAME => [
            'last_name', 'lastname', 'surname', 'family_name', 'familyname',
            'csaladi_nev', 'vezeteknev',
        ],
        self::PHONE => [
            'phone', 'phone_number', 'phonenumber', 'tel', 'telephone', 'mobile',
            'mobile_number', 'cell', 'msisdn', 'sms_number',
            'telefon', 'telefonszam', 'mobilszam',
        ],
        self::DATE => [
            'date', 'start_time', 'starttime', 'starts_at', 'startsat', 'start_date',
            'scheduled_at', 'scheduled_for', 'appointment_date', 'booking_date',
            'event_date', 'when', 'submitted_at', 'submittedat', 'created_at', 'createdat',
            'datum', 'idopont', 'kezdes', 'kezdo_datum',
        ],
        self::END_DATE => [
            'end_time', 'endtime', 'ends_at', 'endsat', 'end_date', 'finish_time',
            'befejezes', 'veg_datum', 'zaro_datum',
        ],
        self::MESSAGE => [
            'message', 'note', 'notes', 'comment', 'comments', 'body', 'description',
            'additional_notes', 'additionalnotes', 'remarks', 'feedback', 'text',
            'uzenet', 'megjegyzes', 'leiras', 'szoveg',
        ],
        self::SUBJECT => [
            'subject', 'topic', 'reason', 'targy', 'tema',
        ],
        self::COMPANY => [
            'company', 'company_name', 'organisation', 'organization',
            'organisation_name', 'organization_name', 'business',
            'ceg', 'cegnev', 'szervezet',
        ],
        self::AMOUNT => [
            'amount', 'amount_total', 'amounttotal', 'total', 'total_amount', 'price',
            'sum', 'subtotal', 'grand_total', 'value', 'fee',
            'osszeg', 'ar', 'vegosszeg', 'dij',
        ],
        self::CURRENCY => [
            'currency', 'currency_code', 'penznem', 'valuta',
        ],
        self::ADDRESS => [
            'address', 'street', 'street_address', 'line1', 'address_line1',
            'cim', 'utca', 'lakcim', 'szallitasi_cim',
        ],
        self::CITY => [
            'city', 'town', 'locality', 'varos', 'telepules',
        ],
        self::POSTAL_CODE => [
            'postal_code', 'postalcode', 'zip', 'zip_code', 'zipcode', 'postcode',
            'iranyitoszam', 'psz',
        ],
        self::COUNTRY => [
            'country', 'country_code', 'orszag',
        ],
        self::QUANTITY => [
            'quantity', 'qty', 'count', 'items', 'pieces', 'db', 'darab', 'mennyiseg',
        ],
        self::STATUS => [
            'status', 'state', 'payment_status', 'paymentstatus', 'stage',
            'allapot', 'statusz',
        ],
        self::URL => [
            'url', 'link', 'website', 'web', 'homepage', 'weblap', 'honlap',
        ],
        self::REFERENCE => [
            'reference', 'ref', 'order_id', 'orderid', 'order_number', 'invoice_id',
            'transaction_id', 'external_id', 'uid', 'client_reference_id',
            'azonosito', 'rendelesszam', 'bizonylatszam',
        ],
        self::TITLE => [
            'title', 'headline', 'event_title', 'eventtitle', 'summary',
            'cim_megnevezes', 'megnevezes', 'esemeny',
        ],
        self::LOCATION => [
            'location', 'venue', 'place', 'room', 'helyszin', 'terem',
        ],
    ];

    /**
     * Hungarian display labels for each canonical group.
     *
     * @var array<string, string>
     */
    public const LABELS = [
        self::EMAIL => 'E-mail cím',
        self::NAME => 'Név',
        self::FIRST_NAME => 'Keresztnév',
        self::LAST_NAME => 'Családi név',
        self::PHONE => 'Telefonszám',
        self::DATE => 'Dátum / időpont',
        self::END_DATE => 'Befejezés időpontja',
        self::MESSAGE => 'Üzenet',
        self::SUBJECT => 'Tárgy',
        self::COMPANY => 'Cég / szervezet',
        self::AMOUNT => 'Összeg',
        self::CURRENCY => 'Pénznem',
        self::ADDRESS => 'Cím',
        self::CITY => 'Város',
        self::POSTAL_CODE => 'Irányítószám',
        self::COUNTRY => 'Ország',
        self::QUANTITY => 'Mennyiség',
        self::STATUS => 'Állapot',
        self::URL => 'Webcím',
        self::REFERENCE => 'Azonosító',
        self::TITLE => 'Megnevezés',
        self::LOCATION => 'Helyszín',
    ];

    // =========================================================================
    // ROLE TOKENS
    // =========================================================================

    /**
     * Tokens that mark a field as belonging to the OTHER party - the person who
     * booked, bought or submitted. This is almost always what the user wants.
     *
     * @var array<int, string>
     */
    public const ROLE_CUSTOMER = [
        'attendee', 'attendees', 'guest', 'guests', 'customer', 'client', 'buyer',
        'booker', 'invitee', 'respondent', 'participant', 'payer', 'contact',
        'submitter', 'lead', 'subscriber',
        'vendo', 'megrendelo', 'vevo', 'ugyfel', 'resztvevo', 'jelentkezo',
    ];

    /**
     * Tokens that mark a field as belonging to OUR side. Mapping these into a
     * customer record is the classic silent mistake, so they are penalised.
     *
     * @var array<int, string>
     */
    public const ROLE_OWNER = [
        'organizer', 'organiser', 'host', 'owner', 'user', 'admin', 'agent',
        'staff', 'employee', 'sender', 'account', 'merchant', 'team',
        'szervezo', 'gazda', 'tulajdonos', 'ugyintezo',
    ];

    /**
     * Structural noise that carries no meaning and should be stripped before
     * matching, so `data.object.customer_details.email` reduces to the same
     * tokens as `customer.email`.
     *
     * @var array<int, string>
     */
    public const NOISE_TOKENS = [
        'payload', 'data', 'object', 'attributes', 'body', 'content', 'fields',
        'field', 'value', 'values', 'details', 'detail', 'info', 'properties',
        'response', 'responses', 'answers', 'answer', 'result', 'item', 'record',
        'the', 'a', 'an', 'my', 'your',
    ];

    // =========================================================================
    // TYPE EXPECTATIONS
    // =========================================================================

    /**
     * What a value must plausibly look like for a group to be proposed.
     *
     * This is the second guard against confident nonsense: `invoice_id` contains
     * no email-ish token, but `contact_id` does contain `contact`, and without a
     * value check a numeric id could still be offered for an email field.
     *
     * @var array<string, string>
     */
    public const VALUE_SHAPES = [
        self::EMAIL => 'email',
        self::PHONE => 'phone',
        self::DATE => 'datetime',
        self::END_DATE => 'datetime',
        self::AMOUNT => 'numeric',
        self::QUANTITY => 'numeric',
        self::URL => 'url',
        self::POSTAL_CODE => 'postalish',
    ];

    // =========================================================================
    // API
    // =========================================================================

    /**
     * Reverse index: token => canonical group. Built once per process.
     *
     * @return array<string, string>
     */
    public static function tokenIndex(): array
    {
        static $index = null;

        if ($index === null) {
            $index = [];
            foreach (self::GROUPS as $group => $tokens) {
                foreach ($tokens as $token) {
                    // First writer wins, so the order inside GROUPS is the
                    // tie-break for a token that appears in two groups
                    // (e.g. 'text' could be message or title).
                    $index[$token] ??= $group;
                }
            }
        }

        return $index;
    }

    /**
     * Split a key or path into comparable tokens.
     *
     * Handles camelCase (`startTime` -> start, time), separators
     * (`email-address`), and drops structural noise.
     *
     * @return array<int, string>
     */
    public static function tokenise(string $key): array
    {
        // camelCase / PascalCase -> snake_case
        $normalised = preg_replace('/([a-z0-9])([A-Z])/', '$1_$2', $key) ?? $key;
        $normalised = strtolower($normalised);
        $normalised = preg_replace('/[^a-z0-9]+/', '_', $normalised) ?? $normalised;

        $tokens = array_values(array_filter(
            explode('_', $normalised),
            static fn($t) => $t !== ''
        ));

        return array_values(array_filter(
            $tokens,
            static fn($t) => !in_array($t, self::NOISE_TOKENS, true)
        ));
    }

    /**
     * Best canonical group for a key, or null when nothing matches.
     *
     * Strategy: try the whole normalised leaf first (so `email_address` matches
     * as a unit rather than as `email` + `address`, which would be ambiguous),
     * then progressively shorter token windows, then single tokens.
     */
    public static function canonicalFor(string $key): ?string
    {
        $index = self::tokenIndex();
        $tokens = self::tokenise($key);

        if ($tokens === []) {
            return null;
        }

        // Longest windows first: a two-token match like `first_name` must beat
        // the single-token `name`.
        for ($window = min(3, count($tokens)); $window >= 1; $window--) {
            for ($start = 0; $start + $window <= count($tokens); $start++) {
                $candidate = implode('_', array_slice($tokens, $start, $window));
                if (isset($index[$candidate])) {
                    return $index[$candidate];
                }
            }
        }

        return null;
    }

    /**
     * Role of a path: 'customer', 'owner' or null.
     *
     * Examined over the WHOLE path, not just the leaf, because the role almost
     * always lives in an ancestor segment (`attendee.email`, `organizer.email`).
     */
    public static function roleFor(string $path): ?string
    {
        $tokens = self::tokeniseWithNoise($path);

        foreach ($tokens as $token) {
            if (in_array($token, self::ROLE_CUSTOMER, true)) {
                return 'customer';
            }
        }
        foreach ($tokens as $token) {
            if (in_array($token, self::ROLE_OWNER, true)) {
                return 'owner';
            }
        }

        return null;
    }

    /**
     * Tokenise WITHOUT dropping noise words.
     *
     * Role detection must not use tokenise(): 'user' is a ROLE_OWNER token and
     * 'responses' is noise, so stripping noise first is fine for meaning but
     * would be wrong if a role word were ever added to the noise list. Keeping
     * these two paths separate makes that impossible to get wrong by accident.
     *
     * @return array<int, string>
     */
    public static function tokeniseWithNoise(string $key): array
    {
        $normalised = preg_replace('/([a-z0-9])([A-Z])/', '$1_$2', $key) ?? $key;
        $normalised = strtolower($normalised);
        $normalised = preg_replace('/[^a-z0-9]+/', '_', $normalised) ?? $normalised;

        return array_values(array_filter(
            explode('_', $normalised),
            static fn($t) => $t !== ''
        ));
    }

    /**
     * Hungarian label for a canonical group.
     */
    public static function labelForGroup(string $group): ?string
    {
        return self::LABELS[$group] ?? null;
    }

    /**
     * Expected value shape for a group, or null when anything goes.
     */
    public static function valueShape(string $group): ?string
    {
        return self::VALUE_SHAPES[$group] ?? null;
    }
}
