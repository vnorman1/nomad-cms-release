<?php

/**
 * NOMAD CMS - Incoming webhook notification journal.
 * Couples mapping outcomes to durable, metadata-only notification intents.
 * No central database or transport is required while recording an outcome.
 */

declare(strict_types=1);

namespace NomadCMS\Webhooks\Mapping;

use NomadCMS\Services\NotificationService\Migrations\Schema;
use NomadCMS\Services\NotificationService\Support;
use PDO;

/** Source-owned intents survive central outages and raw-event retention. */
final class WebhookNotificationJournal
{
    public static function install(PDO $db): void
    {
        Schema::source($db);
        $db->exec(<<<'SQL'
CREATE TABLE IF NOT EXISTS webhook_notification_journal (
 event_id INTEGER NOT NULL, outcome TEXT NOT NULL CHECK(outcome IN ('mapped','failed')),
 endpoint_id INTEGER NOT NULL, target_kind TEXT NOT NULL, created_at INTEGER NOT NULL,
 bridged_at INTEGER, PRIMARY KEY(event_id,outcome)
);
CREATE INDEX IF NOT EXISTS webhook_notification_pending
 ON webhook_notification_journal(created_at,event_id) WHERE bridged_at IS NULL;
SQL);
    }

    /** Must run in the transaction that records the mapping outcome. */
    public static function record(PDO $db, int $eventId, int $endpointId, string $outcome, ?string $target): void
    {
        if (!$db->inTransaction()) {
            throw new \LogicException('Webhook outcome transaction required');
        }
        $event = Support::one($db, 'SELECT created_at FROM webhook_events WHERE id=?', [$eventId]);
        if ($event === null) {
            return;
        }
        // Never retain mapped values, error messages, headers or the provider payload.
        $targetKind = explode(':', $target ?? '', 2)[0];
        Support::run($db, 'INSERT OR IGNORE INTO webhook_notification_journal
            (event_id,outcome,endpoint_id,target_kind,created_at) VALUES(?,?,?,?,?)',
            [$eventId, $outcome, $endpointId, $targetKind, strtotime($event['created_at']) ?: time()]);
    }
}
