<?php

/**
 * NOMAD CMS - Incoming webhook notification outbox bridge.
 * Publishes bounded, replay-safe metadata events from durable mapping outcomes.
 * Acknowledgement and source outbox insertion share one SQLite transaction.
 */

declare(strict_types=1);

namespace NomadCMS\Webhooks\Mapping;

use NomadCMS\Services\NotificationService\Contracts\DomainEvent;
use NomadCMS\Services\NotificationService\Events\SourcePublisher;
use NomadCMS\Services\NotificationService\Support;
use PDO;

/** No transport, source migration or historical-event backfill happens here. */
final class WebhookNotificationBridge
{
    public function __construct(private PDO $source, private PDO $central, private SourcePublisher $publisher, private \Closure $clock)
    {
    }

    public function run(int $limit = 50, ?float $deadline = null): int
    {
        if (Support::one($this->source, "SELECT 1 FROM sqlite_master WHERE type='table' AND name='webhook_notification_journal'") === null) {
            return 0;
        }
        $count = 0;
        while ($count < max(0, min(50, $limit)) && ($deadline === null || microtime(true) < $deadline)) {
            $worked = Support::transaction($this->source, function (): bool {
                $row = Support::one($this->source, 'SELECT * FROM webhook_notification_journal WHERE bridged_at IS NULL ORDER BY created_at,event_id LIMIT 1');
                if ($row === null) {
                    return false;
                }
                $endpoint = Support::one($this->central, 'SELECT id FROM webhook_endpoints WHERE id=?', [$row['endpoint_id']]);
                if ($endpoint !== null) {
                    $this->publisher->record($this->source, new DomainEvent([
                        'source' => 'webhooks',
                        'type' => $row['outcome'] === 'failed' ? WebhookNotificationIntegration::FAILED : WebhookNotificationIntegration::MAPPED,
                        'occurrence_key' => $row['event_id'] . ':' . $row['outcome'],
                        'occurred_at' => gmdate('c', (int) $row['created_at']),
                        'subject' => ['kind' => WebhookNotificationIntegration::TARGET, 'id' => (string) $endpoint['id']],
                        'audience' => $row['outcome'] === 'failed' ? ['kind' => 'all_users'] : ['kind' => WebhookNotificationIntegration::SILENT_AUDIENCE],
                        'data' => ['endpoint_id' => (int) $endpoint['id'], 'target_kind' => $row['target_kind']],
                    ]));
                }
                Support::run($this->source, 'UPDATE webhook_notification_journal SET bridged_at=? WHERE event_id=? AND outcome=?',
                    [($this->clock)(), $row['event_id'], $row['outcome']]);
                return true;
            });
            if (!$worked) {
                break;
            }
            $count++;
        }
        // Pending intents survive retention; completed receipts need no raw-event lifetime.
        Support::run($this->source, 'DELETE FROM webhook_notification_journal WHERE rowid IN
            (SELECT rowid FROM webhook_notification_journal j WHERE bridged_at IS NOT NULL AND bridged_at<?
             AND NOT EXISTS(SELECT 1 FROM webhook_events e WHERE e.id=j.event_id) LIMIT 500)',
            [($this->clock)() - 604800]);
        return $count;
    }
}
