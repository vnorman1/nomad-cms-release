<?php

/**
 * NOMAD CMS - Cron Lock Manager
 *
 * Provides non-blocking, operating-system level mutual exclusion (flock)
 * to prevent concurrent worker processes from stepping on each other or
 * causing SQLite lock contention.
 *
 * @package NomadCMS\Cron
 */

declare(strict_types=1);

namespace NomadCMS\Cron;

final class LockManager
{
    private string $lockDir;
    private string $globalLockFile;
    /** @var resource|null */
    private $globalFileHandle = null;

    public function __construct(?string $lockDir = null)
    {
        $this->lockDir = $lockDir ?? dirname(__DIR__, 2) . '/data/locks';
        $this->ensureLockDirectory();
        $this->globalLockFile = $this->lockDir . '/cron_worker.lock';
    }

    public function __destruct()
    {
        $this->releaseGlobalLock();
    }

    private function ensureLockDirectory(): void
    {
        if (!is_dir($this->lockDir)) {
            @mkdir($this->lockDir, 0775, true);
        }
    }

    /**
     * Attempt to acquire an exclusive, non-blocking lock for the worker process.
     *
     * @return bool True if lock acquired, false if another worker is already running.
     */
    public function acquireGlobalLock(): bool
    {
        if ($this->globalFileHandle !== null) {
            return true; // Already acquired in this process
        }

        $this->ensureLockDirectory();

        $handle = @fopen($this->globalLockFile, 'c+');
        if (!$handle) {
            error_log('[Cron LockManager] Failed to open lock file: ' . $this->globalLockFile);
            return false;
        }

        $locked = flock($handle, LOCK_EX | LOCK_NB, $wouldBlock);

        if (!$locked) {
            fclose($handle);
            return false;
        }

        $this->globalFileHandle = $handle;

        // Write process metadata into the lock file
        $metadata = json_encode([
            'pid' => getmypid(),
            'started_at' => time(),
            'hostname' => gethostname(),
            'sapi' => PHP_SAPI,
        ], JSON_UNESCAPED_SLASHES);

        if ($metadata !== false) {
            ftruncate($handle, 0);
            rewind($handle);
            fwrite($handle, $metadata);
            fflush($handle);
        }

        return true;
    }

    /**
     * Release the global worker lock and close the file handle.
     */
    public function releaseGlobalLock(): void
    {
        if ($this->globalFileHandle !== null) {
            try {
                ftruncate($this->globalFileHandle, 0);
                flock($this->globalFileHandle, LOCK_UN);
                fclose($this->globalFileHandle);
            } catch (\Throwable $e) {
                // Ignore errors during shutdown cleanup
            }
            $this->globalFileHandle = null;
        }
    }

    /**
     * Check whether another worker holds the global lock without keeping it.
     */
    public function isGlobalLocked(): bool
    {
        if ($this->globalFileHandle !== null) {
            return true;
        }

        if (!file_exists($this->globalLockFile)) {
            return false;
        }

        $handle = @fopen($this->globalLockFile, 'c+');
        if (!$handle) {
            return false;
        }

        $locked = flock($handle, LOCK_EX | LOCK_NB);
        if ($locked) {
            // Lock was available, release immediately
            flock($handle, LOCK_UN);
            fclose($handle);
            return false;
        }

        fclose($handle);
        return true;
    }

    /**
     * Read metadata of currently active lock holder if available.
     *
     * @return array<string, mixed>|null
     */
    public function getActiveLockInfo(): ?array
    {
        if (!file_exists($this->globalLockFile)) {
            return null;
        }

        $content = @file_get_contents($this->globalLockFile);
        if (!$content) {
            return null;
        }

        $data = json_decode($content, true);
        return is_array($data) ? $data : null;
    }
}
