<?php

/**
 * NOMAD CMS - Presence Cleanup Task
 *
 * Purges inactive active editor presence tracking records older than 65 seconds
 * from system.sqlite (system_presence table).
 *
 * @package NomadCMS\Cron\Tasks
 */

declare(strict_types=1);

namespace NomadCMS\Cron\Tasks;

use NomadCMS\Cron\AbstractTask;
use NomadCMS\Cron\CronContext;
use NomadCMS\Cron\TaskResult;
use NomadCMS\Database\AuthDatabase;

final class PresenceCleanupTask extends AbstractTask
{
    public function getName(): string
    {
        return 'presence_cleanup';
    }

    public function getDescription(): string
    {
        return 'Purge stale active editor presence records older than 65 seconds';
    }

    public function getDefaultInterval(): int
    {
        return 60; // Every 1 minute (aligned with 65s TTL)
    }

    public function run(CronContext $context): TaskResult
    {
        $db = AuthDatabase::getInstance();

        // Check if presence table exists
        $checkStmt = $db->query("SELECT name FROM sqlite_master WHERE type='table' AND name='system_presence'");
        if (!$checkStmt->fetchColumn()) {
            return $this->success(0, 'system_presence table does not exist yet');
        }

        $ttlCutoff = time() - 65;
        $stmt = $db->prepare('DELETE FROM system_presence WHERE last_seen < ?');
        $stmt->execute([$ttlCutoff]);

        $deleted = $stmt->rowCount();

        return $this->success($deleted, sprintf('Purged %d expired presence records', $deleted));
    }
}
