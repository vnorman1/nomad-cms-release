<?php

/**
 * NOMAD CMS - Database Maintenance Task
 *
 * Runs routine SQLite maintenance (WAL checkpoint TRUNCATE, PRAGMA optimize)
 * across the 3 SQLite databases (system, content, massive) to prevent WAL file bloat
 * and ensure query planner performance.
 *
 * @package NomadCMS\Cron\Tasks
 */

declare(strict_types=1);

namespace NomadCMS\Cron\Tasks;

use NomadCMS\Cron\AbstractTask;
use NomadCMS\Cron\CronContext;
use NomadCMS\Cron\TaskResult;
use NomadCMS\Database\AuthDatabase;
use NomadCMS\Database\ContentDatabase;
use NomadCMS\Database\MassiveDatabase;
use Throwable;

final class DatabaseMaintenanceTask extends AbstractTask
{
    public function getName(): string
    {
        return 'db_maintenance';
    }

    public function getDescription(): string
    {
        return 'Execute SQLite WAL checkpoint and PRAGMA optimize on all database files';
    }

    public function getDefaultInterval(): int
    {
        return 86400; // Every 24 hours (daily)
    }

    public function run(CronContext $context): TaskResult
    {
        $databases = [
            'system' => AuthDatabase::getInstance(),
            'content' => ContentDatabase::getInstance(),
            'massive' => MassiveDatabase::getInstance(),
        ];

        $optimized = 0;
        $errors = [];

        foreach ($databases as $name => $db) {
            try {
                // 1. Non-blocking checkpoint WAL frames into main DB without exclusive locking
                $db->exec('PRAGMA wal_checkpoint(PASSIVE)');

                // 2. Refresh query planner statistics
                $db->exec('PRAGMA optimize');

                $optimized++;
            } catch (Throwable $e) {
                $errors[] = "{$name}: " . $e->getMessage();
            }
        }

        if (!empty($errors)) {
            return $this->error('Maintenance completed with errors: ' . implode('; ', $errors), $optimized);
        }

        return $this->success($optimized, sprintf('Optimized and checkpointed %d databases (system, content, massive)', $optimized));
    }
}
