<?php

/**
 * NOMAD CMS - Central notification cron task.
 * Registers each notification stage with the existing locked cron scheduler.
 * Uses the shared remaining deadline and refuses network delivery in piggyback mode.
 */

declare(strict_types=1);

namespace NomadCMS\Cron\Tasks;

use NomadCMS\Cron\AbstractTask;
use NomadCMS\Cron\CronContext;
use NomadCMS\Cron\TaskResult;
use NomadCMS\Database\AuthDatabase;
use NomadCMS\Services\NotificationService\BackgroundRunner;
use NomadCMS\Services\NotificationService\Migrations\Schema;
use NomadCMS\Services\NotificationService\NotificationModule;

/** One bounded stage; the scheduler owns locking, scheduling and diagnostics. */
final class NotificationTask extends AbstractTask
{
    public function __construct(private string $name)
    {
        if (!in_array($name, BackgroundRunner::TASKS, true)) {
            throw new \InvalidArgumentException('Unknown notification task');
        }
    }

    public function getName(): string
    {
        return $this->name;
    }

    public function getDescription(): string
    {
        return 'Central notifications: ' . str_replace('_', ' ', $this->name);
    }

    public function getDefaultInterval(): int
    {
        return $this->name === 'notification_retention' ? 3600 : 60;
    }

    public function run(CronContext $context): TaskResult
    {
        if (!Schema::installed(AuthDatabase::getInstance(false))) {
            return $this->success(0, 'Notification migration required');
        }
        if ($context->isPiggyback() && in_array($this->name, ['event_delivery', 'notification_retention'], true)) {
            return TaskResult::skipped($this->name, 'Scheduled worker required');
        }
        $budget = max(0, $context->getRemainingTime() - 1);
        if ($this->name === 'event_delivery') {
            $budget = min(15, $budget);
        }
        $deadline = microtime(true) + $budget;
        $count = (new BackgroundRunner(NotificationModule::create()))->run($this->name, $deadline);
        return $this->success($count, 'Notification stage completed');
    }
}
