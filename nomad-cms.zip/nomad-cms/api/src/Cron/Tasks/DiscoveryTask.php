<?php
/**
 * NOMAD CMS — public discovery cron adapter.
 * Advances the same bounded sitemap/LLM generation used by public requests, independently of SEO Studio.
 * Honors dry runs and remaining execution time; public requests supply the cron-free fallback.
 */
declare(strict_types=1);

namespace NomadCMS\Cron\Tasks;

use NomadCMS\Cron\AbstractTask;
use NomadCMS\Cron\CronContext;
use NomadCMS\Cron\TaskResult;
use NomadCMS\Services\DiscoveryService;

final class DiscoveryTask extends AbstractTask
{
    public function getName(): string
    {
        return 'public_discovery';
    }

    public function getDescription(): string
    {
        return 'Build bounded public sitemap and LLM discovery generations';
    }

    public function getDefaultInterval(): int
    {
        return 30;
    }

    public function run(CronContext $context): TaskResult
    {
        if ($context->isDryRun() || $context->isPiggyback() || $context->getRemainingTime() < 1.0) {
            return $this->success(0, 'Public discovery waits for explicit cron or a public index request');
        }
        try {
            $service = DiscoveryService::production();
            $result = $service->work(min(10.0, $context->getRemainingTime() - 0.5));
            return $this->success($result['batches'], $result['ready'] ? 'A complete generation is available' : 'Generation checkpoint saved');
        } catch (\Throwable $error) {
            return $this->error($error->getMessage(), 0);
        }
    }
}
