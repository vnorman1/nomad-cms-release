<?php

/**
 * NOMAD CMS - Webhook Queue Task
 *
 * Dispatches queued outgoing webhook events and retries failed calls
 * using exponential backoff.
 *
 * @package NomadCMS\Cron\Tasks
 */

declare(strict_types=1);

namespace NomadCMS\Cron\Tasks;

use NomadCMS\Cron\AbstractTask;
use NomadCMS\Cron\CronContext;
use NomadCMS\Cron\TaskResult;
use NomadCMS\Services\WebhookQueueService;

final class WebhookQueueTask extends AbstractTask
{
    public function getName(): string
    {
        return 'webhook_queue';
    }

    public function getDescription(): string
    {
        return 'Dispatch outgoing webhooks & retry queue with exponential backoff';
    }

    public function getDefaultInterval(): int
    {
        return 60; // Every 1 minute
    }

    public function run(CronContext $context): TaskResult
    {
        if ($context->isPiggyback()) {
            // The lightweight request fallback owns throttling; scheduled workers
            // alone use this task's larger fan-out and network delivery budget.
            return TaskResult::skipped($this->getName(), 'Dedicated webhook fallback or scheduled worker required');
        }
        \NomadCMS\Services\CollectionWebhookOutbox::relay();
        $service = WebhookQueueService::getInstance();
        $pending = $service->getPendingCount();

        if ($pending === 0) {
            return $this->success(0, 'No pending webhooks in queue');
        }

        $stats = $service->processQueue();
        $processed = (int)($stats['processed'] ?? 0);
        $succeeded = (int)($stats['succeeded'] ?? 0);
        $failed = (int)($stats['failed'] ?? 0);

        return $this->success(
            $processed,
            sprintf('Processed %d webhooks (%d succeeded, %d failed)', $processed, $succeeded, $failed)
        );
    }
}
