<?php
/**
 * NOMAD CMS — Schema migration safety net.
 * Advances one durable job per infrequent run; idle installations do no work.
 * Critical recovery is allowed to finish after an approver loses authority.
 */

declare(strict_types=1);

namespace NomadCMS\Cron\Tasks;

use NomadCMS\Cron\AbstractTask;
use NomadCMS\Cron\CronContext;
use NomadCMS\Cron\TaskResult;
use NomadCMS\Services\Schema\SchemaEngine;
use NomadCMS\Services\Schema\SchemaProvider;
use NomadCMS\Services\Schema\SchemaStore;

final class SchemaMigrationTask extends AbstractTask
{
    public function getName(): string
    {
        return 'schema_migration';
    }

    public function getDescription(): string
    {
        return 'Recover schema cutovers and advance one bounded assessment batch';
    }

    public function getDefaultInterval(): int
    {
        return 300;
    }

    public function shouldLog(): bool
    {
        return false;
    }

    public function run(CronContext $context): TaskResult
    {
        if (!is_file(SchemaStore::path())) {
            return $this->skipped('Schema registry not initialized');
        }
        try {
            $result = (new SchemaEngine(SchemaProvider::store()))->work(64);
            return $this->success((int) ($result['processed'] ?? 0));
        } catch (\Throwable $error) {
            return $this->error($error->getMessage());
        } finally {
            SchemaProvider::release();
        }
    }
}
