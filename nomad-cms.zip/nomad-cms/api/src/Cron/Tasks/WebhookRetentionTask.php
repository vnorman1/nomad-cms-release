<?php

/**
 * NOMAD CMS - Webhook Retention Task
 *
 * Enforces GDPR storage limitation on raw inbound webhook events and
 * cleans up old outbound delivery attempts and stale processing locks.
 *
 * @package NomadCMS\Cron\Tasks
 */

declare(strict_types=1);

namespace NomadCMS\Cron\Tasks;

use NomadCMS\Cron\AbstractTask;
use NomadCMS\Cron\CronContext;
use NomadCMS\Cron\TaskResult;
use NomadCMS\Services\WebhookQueueService;
use NomadCMS\Webhooks\Mapping\WebhookEventRetentionService;

final class WebhookRetentionTask extends AbstractTask
{
    public function getName(): string
    {
        return 'webhook_retention';
    }

    public function getDescription(): string
    {
        return 'Purge old raw inbound webhook payloads (GDPR) and cleanup delivery logs';
    }

    public function getDefaultInterval(): int
    {
        return 3600; // Every 1 hour
    }

    public function run(CronContext $context): TaskResult
    {
        $inboundCleaned = 0;
        $outboundCleaned = 0;

        // 1. Inbound webhook event store retention sweep (automapper raw payloads)
        if (class_exists(WebhookEventRetentionService::class)) {
            $inboundResult = WebhookEventRetentionService::sweep();
            $inboundCleaned = (int)($inboundResult['expired_deleted'] ?? 0) + (int)($inboundResult['evicted'] ?? 0);
        }

        // 2. Outbound queue retention cleanup (3 days retention) & stale lock cleanup (5 min)
        if (class_exists(WebhookQueueService::class)) {
            $queueService = WebhookQueueService::getInstance();
            $outboundCleaned = $queueService->cleanup(3);
            $queueService->cleanupStaleProcessing(5);
        }

        $total = $inboundCleaned + $outboundCleaned;

        return $this->success(
            $total,
            sprintf('Purged %d inbound events and %d outbound delivery logs', $inboundCleaned, $outboundCleaned)
        );
    }
}
