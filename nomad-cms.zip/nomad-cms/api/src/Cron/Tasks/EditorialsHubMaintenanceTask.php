<?php

/**
 * NOMAD CMS - Editorials Hub EditorialsHubMaintenanceTask.
 *
 * Locked cron maintenance for Hub expiration and already-committed transfer recovery.
 * Backend-only PHP/SQLite module; resource budgets and authorization are enforced at service boundaries.
 *
 * @package NomadCMS\Cron\Tasks
 */

declare(strict_types=1);

namespace NomadCMS\Cron\Tasks;

use NomadCMS\Cron\AbstractTask;
use NomadCMS\Cron\CronContext;
use NomadCMS\Cron\TaskResult;
use NomadCMS\Database\MassiveDatabase;
use NomadCMS\Services\EditorialsHub\Contracts\HubRequestContext;
use NomadCMS\Services\EditorialsHub\EditorialsHubModule;
use NomadCMS\Services\EditorialsHub\Maintenance\MaintenanceService;

/** Locked cron maintenance for Hub expiration and already-committed transfer recovery. */
final class EditorialsHubMaintenanceTask extends AbstractTask
{
    public function getName(): string
    {
        return 'editorials_hub_maintenance';
    }
    public function getDescription(): string
    {
        return 'Expire Hub threads and reconcile destination receipts in bounded batches';
    }
    public function getDefaultInterval(): int
    {
        return 60;
    }
    public function run(CronContext $context): TaskResult
    {
        $db = MassiveDatabase::getInstance(true);
        if (!EditorialsHubModule::installed($db)) {
            return $this->success(0, 'Editorials Hub is not installed');
        }
        $secret = hash('sha256', 'editorials-maintenance:' . ($_ENV['ENCRYPTION_KEY'] ?? ''));
        $actor = new HubRequestContext('editorials-maintenance', $secret, static fn($p)=>true, static fn($s)=>true, true);
        $directory = \NomadCMS\Services\EditorialsHub\HubConfig::storageDirectory();
        if (!is_dir($directory)) {
            mkdir($directory, 0700, true);
        }
        $lock = fopen($directory . '/maintenance.lock', 'c');
        if (!$lock || !flock($lock, LOCK_EX | LOCK_NB)) {
            if ($lock) {
                fclose($lock);
            } return $this->success(0, 'Editorials maintenance is already running');
        }
        try {
            $stats = (new MaintenanceService(new EditorialsHubModule($db, $actor)))->run();
        } finally {
            flock($lock, LOCK_UN);
            fclose($lock);
        }
        return $this->success(array_sum($stats), json_encode($stats, JSON_THROW_ON_ERROR));
    }
}
