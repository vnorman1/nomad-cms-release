<?php

/**
 * NOMAD CMS - Media Queue Task
 *
 * Downloads and converts queued external images to WebP for Forge imports
 * and Smart Ingest requests.
 *
 * @package NomadCMS\Cron\Tasks
 */

declare(strict_types=1);

namespace NomadCMS\Cron\Tasks;

use NomadCMS\Cron\AbstractTask;
use NomadCMS\Cron\CronContext;
use NomadCMS\Cron\TaskResult;
use NomadCMS\Services\SmartIngestService;

final class MediaQueueTask extends AbstractTask
{
    public function getName(): string
    {
        return 'media_queue';
    }

    public function getDescription(): string
    {
        return 'Download and convert pending Forge and Smart Ingest media items';
    }

    public function getDefaultInterval(): int
    {
        return 60; // Every 1 minute
    }

    public function run(CronContext $context): TaskResult
    {
        $statsBefore = SmartIngestService::getQueueStats();
        $pending = $statsBefore['pending'] ?? 0;

        if ($pending === 0) {
            return $this->success(0, 'No pending media items in queue');
        }

        // Process batch (limit according to execution time budget)
        $limit = $context->isPiggyback() ? 2 : 20;
        $results = SmartIngestService::processPendingQueue($limit);

        $processed = (int)($results['processed'] ?? 0);
        $failed = (int)($results['failed'] ?? 0);

        return $this->success(
            $processed,
            sprintf('Processed %d media downloads (%d failed)', $processed, $failed)
        );
    }
}
