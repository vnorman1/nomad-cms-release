<?php

/**
 * NOMAD CMS - Form Batch Flush Task
 *
 * Flushes overdue form submission notification e-mail and webhook batches.
 *
 * @package NomadCMS\Cron\Tasks
 */

declare(strict_types=1);

namespace NomadCMS\Cron\Tasks;

use NomadCMS\Cron\AbstractTask;
use NomadCMS\Cron\CronContext;
use NomadCMS\Cron\TaskResult;
use NomadCMS\Services\Forms\FormNotificationBatchService;
use NomadCMS\Services\Forms\FormWebhookBatchService;

final class FormBatchFlushTask extends AbstractTask
{
    public function getName(): string
    {
        return 'form_batch_flush';
    }

    public function getDescription(): string
    {
        return 'Flush pending form notification email & webhook batches that are due';
    }

    public function getDefaultInterval(): int
    {
        return 60; // Every 1 minute
    }

    public function run(CronContext $context): TaskResult
    {
        $emailBatchesFlushed = 0;
        $webhookBatchesFlushed = 0;

        if (class_exists(FormNotificationBatchService::class)) {
            $emailResults = FormNotificationBatchService::flushAllDue();
            $emailBatchesFlushed = is_array($emailResults) ? count($emailResults) : (int)$emailResults;
        }

        if (class_exists(FormWebhookBatchService::class)) {
            $webhookResults = FormWebhookBatchService::flushAllDue();
            $webhookBatchesFlushed = is_array($webhookResults) ? count($webhookResults) : (int)$webhookResults;
        }

        $total = $emailBatchesFlushed + $webhookBatchesFlushed;

        return $this->success(
            $total,
            sprintf('Flushed %d email batches and %d webhook batches', $emailBatchesFlushed, $webhookBatchesFlushed)
        );
    }
}
