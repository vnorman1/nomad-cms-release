<?php
/**
 * NOMAD CMS - Collection Cache Cron Task
 * Background task for asynchronous static cache and manifest generation
 * 
 * Features:
 * - Revision-aware queue processing from collection_jobs table
 * - Incremental static cache document generation without blocking user requests
 * - Automatic retry handling with backoff and error logging (attempts & last_error)
 * - Bounded batch execution (max 3 queued jobs per cron run)
 * - Multi-language manifest and chunk cache compilation
 * 
 * Storage: collection_jobs, collection_cache_entries, filesystem (/cache/content/{slot})
 */
declare(strict_types=1);
namespace NomadCMS\Cron\Tasks;
use NomadCMS\Cron\AbstractTask;
use NomadCMS\Cron\CronContext;
use NomadCMS\Cron\TaskResult;
use NomadCMS\Database\CollectionDatabase;
use NomadCMS\Services\StaticCacheService;
final class CollectionCacheTask extends AbstractTask
{
    public function getName(): string { return 'collection_cache'; }
    public function getDescription(): string { return 'Publish revision-checked collection documents and indexes'; }
    public function getDefaultInterval(): int { return 30; }
    public function run(CronContext $context): TaskResult
    {
        $db=CollectionDatabase::getInstance();
        $jobs=$db->query('SELECT slot_key,revision FROM collection_jobs ORDER BY queued_at LIMIT 3')->fetchAll();
        $count=0;
        foreach($jobs as $job) {
            try { if(StaticCacheService::rebuildRowCollection($job['slot_key'])) $count++; }
            catch(\Throwable $e) {
                $db->prepare('UPDATE collection_jobs SET attempts=attempts+1,last_error=? WHERE slot_key=? AND revision=?')->execute([substr($e->getMessage(),0,1000),$job['slot_key'],$job['revision']]);
                return $this->error($e->getMessage(),$count);
            }
        }
        return $this->success($count,'Collection cache jobs processed');
    }
}
