<?php

/**
 * NOMAD CMS - Analytics Ingest Task
 *
 * Ingests fast-path analytics append-only spool files into SQLite event storage.
 *
 * @package NomadCMS\Cron\Tasks
 */

declare(strict_types=1);

namespace NomadCMS\Cron\Tasks;

use NomadCMS\Cron\AbstractTask;
use NomadCMS\Cron\CronContext;
use NomadCMS\Cron\TaskResult;
use NomadCMS\Services\Analytics\AnalyticsSettingsService;
use NomadCMS\Services\Analytics\SpoolIngestService;

final class AnalyticsIngestTask extends AbstractTask
{
    public function getName(): string
    {
        return 'analytics_spool';
    }

    public function getDescription(): string
    {
        return 'Ingest fast-path analytics spool files into SQLite event storage';
    }

    public function getDefaultInterval(): int
    {
        return 60; // Every 1 minute
    }

    public function isEnabled(): bool
    {
        return class_exists(AnalyticsSettingsService::class)
            && AnalyticsSettingsService::getInstance()->isEnabled();
    }

    public function run(CronContext $context): TaskResult
    {
        if (!$this->isEnabled()) {
            return $this->skipped('Analytics module is disabled');
        }

        $limit = $context->isPiggyback() ? 300 : 1000;
        $result = SpoolIngestService::ingest($limit);

        if ($result['skipped'] ?? false) {
            return $this->skipped('Ingest lock held by another process');
        }

        $linesIngested = (int)($result['lines_ingested'] ?? 0);
        $filesProcessed = (int)($result['files_processed'] ?? 0);

        return $this->success(
            $linesIngested,
            sprintf('Ingested %d events across %d spool files', $linesIngested, $filesProcessed)
        );
    }
}
