<?php

/**
 * NOMAD CMS - Form Retention Task
 *
 * Enforces GDPR storage limitation by deleting form submissions that have
 * exceeded their form-specific retention_days setting.
 *
 * @package NomadCMS\Cron\Tasks
 */

declare(strict_types=1);

namespace NomadCMS\Cron\Tasks;

use NomadCMS\Cron\AbstractTask;
use NomadCMS\Cron\CronContext;
use NomadCMS\Cron\TaskResult;
use NomadCMS\Services\Forms\FormRetentionService;

final class FormRetentionTask extends AbstractTask
{
    public function getName(): string
    {
        return 'form_retention';
    }

    public function getDescription(): string
    {
        return 'Enforce GDPR storage limitation on form submissions by retention_days';
    }

    public function getDefaultInterval(): int
    {
        return 21600; // Every 6 hours
    }

    public function run(CronContext $context): TaskResult
    {
        if (!class_exists(FormRetentionService::class)) {
            return $this->skipped('Form module not available');
        }

        $result = FormRetentionService::sweep();
        $deleted = (int)($result['deleted'] ?? 0);
        $formsScanned = (int)($result['forms_scanned'] ?? 0);

        return $this->success(
            $deleted,
            sprintf('Scanned %d forms, purged %d expired submissions', $formsScanned, $deleted)
        );
    }
}
