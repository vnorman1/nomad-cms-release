<?php

/**
 * NOMAD CMS - Uptime & Heartbeat Task
 *
 * Records periodic worker heartbeat timestamp in system.sqlite for uptime
 * health monitoring, alerting, and dashboard indicators.
 *
 * Intentionally does NOT write to system_cron_logs on every tick to avoid
 * flooding the log table with low-value heartbeat noise.
 *
 * @package NomadCMS\Cron\Tasks
 */

declare(strict_types=1);

namespace NomadCMS\Cron\Tasks;

use NomadCMS\Cron\AbstractTask;
use NomadCMS\Cron\CronContext;
use NomadCMS\Cron\TaskResult;

final class UptimeHeartbeatTask extends AbstractTask
{
    public function getName(): string
    {
        return 'uptime_heartbeat';
    }

    public function getDescription(): string
    {
        return 'Record worker heartbeat timestamp for health monitoring & status dashboard';
    }

    public function getDefaultInterval(): int
    {
        return 60; // Every 1 minute / every run
    }

    /**
     * Suppress per-execution log rows — only the task state row (last_run_at)
     * is updated. This prevents thousands of low-value heartbeat entries from
     * filling system_cron_logs over the 7-day retention window.
     */
    public function shouldLog(): bool
    {
        return false;
    }

    public function isDue(?int $lastRunAt, int $interval): bool
    {
        return true; // Always execute on every worker cycle
    }

    public function run(CronContext $context): TaskResult
    {
        $memoryMb = round(memory_get_peak_usage(true) / (1024 * 1024), 2);
        $sapi = PHP_SAPI;
        $mode = $context->getRunnerMode();

        return $this->success(
            1,
            sprintf('Heartbeat active [mode: %s, sapi: %s, memory: %.2f MB]', $mode, $sapi, $memoryMb)
        );
    }
}
