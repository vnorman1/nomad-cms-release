<?php

/**
 * NOMAD CMS - Analytics Aggregation Task
 *
 * Runs daily analytics aggregation, finalizes elapsed days, and purges
 * expired raw events (0-PII compliance).
 *
 * @package NomadCMS\Cron\Tasks
 */

declare(strict_types=1);

namespace NomadCMS\Cron\Tasks;

use NomadCMS\Cron\AbstractTask;
use NomadCMS\Cron\CronContext;
use NomadCMS\Cron\TaskResult;
use NomadCMS\Services\Analytics\AnalyticsRetentionService;
use NomadCMS\Services\Analytics\AnalyticsSettingsService;

final class AnalyticsAggregationTask extends AbstractTask
{
    public function getName(): string
    {
        return 'analytics_aggregation';
    }

    public function getDescription(): string
    {
        return 'Aggregate daily analytics totals, finalize elapsed days, and purge expired raw events';
    }

    public function getDefaultInterval(): int
    {
        return 3600; // Every 1 hour
    }

    public function isEnabled(): bool
    {
        return class_exists(AnalyticsSettingsService::class)
            && AnalyticsSettingsService::getInstance()->isEnabled();
    }

    public function run(CronContext $context): TaskResult
    {
        if (!$this->isEnabled()) {
            return $this->skipped('Analytics module is disabled');
        }

        $result = AnalyticsRetentionService::sweep();
        $rawPurged = (int)($result['raw_days_purged'] ?? 0);
        $aggregatePurged = (int)($result['aggregate_days_purged'] ?? 0);
        $quotaPurged = (int)($result['quota_days_purged'] ?? 0);

        return $this->success(
            $rawPurged + $aggregatePurged + $quotaPurged,
            sprintf('Aggregated stats, purged %d raw days, %d aggregate days, %d quota days', $rawPurged, $aggregatePurged, $quotaPurged)
        );
    }
}
