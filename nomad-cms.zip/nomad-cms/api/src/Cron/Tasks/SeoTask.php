<?php
/**
 * NOMAD CMS — SEO Studio shared-hosting maintenance task.
 * Skips ordinary piggyback requests; explicit web/CLI cron gets resumable non-audit jobs.
 * Audits run only through an explicitly requested target check, never this maintenance task.
 * @package NomadCMS\Cron\Tasks
 */
declare(strict_types=1);

namespace NomadCMS\Cron\Tasks;

use NomadCMS\Cron\AbstractTask;
use NomadCMS\Cron\CronContext;
use NomadCMS\Cron\TaskResult;
use NomadCMS\Database\ContentDatabase;
use NomadCMS\Services\Seo\Schema;
use NomadCMS\Services\Seo\SeoModule;

/** TaskManager adapter without schema migration side effects. */
final class SeoTask extends AbstractTask
{
    public function getName(): string
    {
        return 'seo_studio';
    }

    public function getDescription(): string
    {
        return 'SEO indexes, image imports, sitemaps, statistics, deletion recovery and cache maintenance';
    }

    public function getDefaultInterval(): int
    {
        return 60;
    }

    public function run(CronContext $context): TaskResult
    {
        if ($context->isPiggyback() || $context->isDryRun() || !Schema::installed(ContentDatabase::getInstance(false))) {
            return $this->success(0, 'SEO worker requires explicit cron and installation');
        }
        try {
            $result = SeoModule::production(true)->maintenance->work(min(20, max(0.05, $context->getRemainingTime() - 0.5)), true);
            return $this->success($result['jobs'], 'SEO jobs processed');
        } catch (\Throwable $error) {
            return $this->error($error->getMessage(), 0);
        }
    }
}
