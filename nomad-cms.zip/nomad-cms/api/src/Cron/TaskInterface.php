<?php

/**
 * NOMAD CMS - Cron Task Interface
 *
 * Contract that all background and scheduled tasks must implement.
 *
 * @package NomadCMS\Cron
 */

declare(strict_types=1);

namespace NomadCMS\Cron;

interface TaskInterface
{
    /**
     * Unique alphanumeric identifier for this task (e.g. 'webhook_queue').
     */
    public function getName(): string;

    /**
     * Human-readable description for administrative views and logs.
     */
    public function getDescription(): string;

    /**
     * Default execution interval in seconds (e.g. 60 for 1 minute, 3600 for 1 hour).
     */
    public function getDefaultInterval(): int;

    /**
     * Whether this task is enabled by default in configuration.
     */
    public function isEnabled(): bool;

    /**
     * Determine if this task is due for execution based on its last run timestamp and interval.
     */
    public function isDue(?int $lastRunAt, int $interval): bool;

    /**
     * Whether this task should write an entry to system_cron_logs on each run.
     * Override and return false for high-frequency tasks that would otherwise
     * produce excessive log noise (e.g. heartbeat).
     */
    public function shouldLog(): bool;

    /**
     * Execute the task logic.
     *
     * @param CronContext $context Runtime context containing execution limits, runner mode, and logger.
     * @return TaskResult Execution outcome, duration, items processed, and error/status message.
     */
    public function run(CronContext $context): TaskResult;
}
