<?php

/**
 * NOMAD CMS - Cron Task Result Value Object
 *
 * Encapsulates the execution metrics, processed item count, duration,
 * memory peak, and status of a single cron task run.
 *
 * @package NomadCMS\Cron
 */

declare(strict_types=1);

namespace NomadCMS\Cron;

final class TaskResult
{
    private string $taskName;
    private string $status;
    private int $itemsProcessed;
    private float $durationMs;
    private int $memoryPeakBytes;
    private ?string $message;
    private ?string $error;

    public function __construct(
        string $taskName,
        string $status,
        int $itemsProcessed = 0,
        float $durationMs = 0.0,
        int $memoryPeakBytes = 0,
        ?string $message = null,
        ?string $error = null
    ) {
        $this->taskName = $taskName;
        $this->status = $status;
        $this->itemsProcessed = max(0, $itemsProcessed);
        $this->durationMs = max(0.0, $durationMs);
        $this->memoryPeakBytes = $memoryPeakBytes > 0 ? $memoryPeakBytes : memory_get_peak_usage(true);
        $this->message = $message;
        $this->error = $error;
    }

    public static function success(string $taskName, int $itemsProcessed = 0, ?string $message = null): self
    {
        return new self(
            taskName: $taskName,
            status: CronSchema::STATUS_SUCCESS,
            itemsProcessed: $itemsProcessed,
            message: $message
        );
    }

    public static function error(string $taskName, string $error, int $itemsProcessed = 0): self
    {
        return new self(
            taskName: $taskName,
            status: CronSchema::STATUS_ERROR,
            itemsProcessed: $itemsProcessed,
            error: $error
        );
    }

    public static function skipped(string $taskName, ?string $reason = null): self
    {
        return new self(
            taskName: $taskName,
            status: CronSchema::STATUS_SKIPPED,
            itemsProcessed: 0,
            message: $reason
        );
    }

    public function getTaskName(): string
    {
        return $this->taskName;
    }

    public function getStatus(): string
    {
        return $this->status;
    }

    public function isSuccess(): bool
    {
        return $this->status === CronSchema::STATUS_SUCCESS;
    }

    public function isError(): bool
    {
        return $this->status === CronSchema::STATUS_ERROR;
    }

    public function isSkipped(): bool
    {
        return $this->status === CronSchema::STATUS_SKIPPED;
    }

    public function getItemsProcessed(): int
    {
        return $this->itemsProcessed;
    }

    public function getDurationMs(): float
    {
        return $this->durationMs;
    }

    public function setDurationMs(float $durationMs): self
    {
        $this->durationMs = max(0.0, $durationMs);
        return $this;
    }

    public function getMemoryPeakBytes(): int
    {
        return $this->memoryPeakBytes;
    }

    public function setMemoryPeakBytes(int $bytes): self
    {
        $this->memoryPeakBytes = $bytes;
        return $this;
    }

    public function getMessage(): ?string
    {
        return $this->message;
    }

    public function getError(): ?string
    {
        return $this->error;
    }

    /**
     * Convert result to associative array representation.
     *
     * @return array<string, mixed>
     */
    public function toArray(): array
    {
        return [
            'task' => $this->taskName,
            'status' => $this->status,
            'items_processed' => $this->itemsProcessed,
            'duration_ms' => round($this->durationMs, 2),
            'memory_peak_mb' => round($this->memoryPeakBytes / (1024 * 1024), 2),
            'message' => $this->message,
            'error' => $this->error,
        ];
    }
}
