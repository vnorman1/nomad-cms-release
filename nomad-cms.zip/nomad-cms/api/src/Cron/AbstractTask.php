<?php

/**
 * NOMAD CMS - Abstract Cron Task
 *
 * Base class providing default scheduling logic, result helper methods,
 * and error boundary wrappers for cron tasks.
 *
 * @package NomadCMS\Cron
 */

declare(strict_types=1);

namespace NomadCMS\Cron;

abstract class AbstractTask implements TaskInterface
{
    /**
     * Default implementation: task is enabled unless specified otherwise.
     */
    public function isEnabled(): bool
    {
        return true;
    }

    /**
     * Default implementation: write a log row after each execution.
     * Override and return false to suppress log entries for high-frequency tasks.
     */
    public function shouldLog(): bool
    {
        return true;
    }

    /**
     * Standard due calculation based on last run timestamp and interval.
     */
    public function isDue(?int $lastRunAt, int $interval): bool
    {
        if ($lastRunAt === null || $lastRunAt <= 0) {
            return true;
        }

        $now = time();
        return ($lastRunAt + $interval) <= $now;
    }

    protected function success(int $itemsProcessed = 0, ?string $message = null): TaskResult
    {
        return TaskResult::success($this->getName(), $itemsProcessed, $message);
    }

    protected function error(string $errorMessage, int $itemsProcessed = 0): TaskResult
    {
        return TaskResult::error($this->getName(), $errorMessage, $itemsProcessed);
    }

    protected function skipped(?string $reason = null): TaskResult
    {
        return TaskResult::skipped($this->getName(), $reason);
    }
}
