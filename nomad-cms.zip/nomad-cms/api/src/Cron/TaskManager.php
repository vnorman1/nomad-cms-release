<?php

/**
 * NOMAD CMS - Cron Task Manager
 *
 * Central orchestrator for discovering, scheduling, locking, executing,
 * and logging all background tasks in the system.
 *
 * @package NomadCMS\Cron
 */

declare(strict_types=1);

namespace NomadCMS\Cron;

use PDO;
use Throwable;

final class TaskManager
{
    private static ?self $instance = null;

    /** @var array<string, TaskInterface> */
    private array $tasks = [];
    private LockManager $lockManager;
    private PDO $db;

    public static function getInstance(): self
    {
        return self::$instance ??= new self();
    }

    public function __construct(?LockManager $lockManager = null, ?PDO $db = null)
    {
        if (!\NomadCMS\Security\PanicModeService::isActive()) {
            CronSchema::ensureTables();
        }
        $this->db = $db ?? CronSchema::db();
        $this->lockManager = $lockManager ?? new LockManager();
        $this->registerDefaultTasks();
    }

    /**
     * Register a new task.
     */
    public function registerTask(TaskInterface $task): self
    {
        $this->tasks[$task->getName()] = $task;
        return $this;
    }

    /**
     * Get a registered task by name.
     */
    public function getTask(string $name): ?TaskInterface
    {
        return $this->tasks[$name] ?? null;
    }

    /**
     * Get all registered tasks.
     *
     * @return array<string, TaskInterface>
     */
    public function getAllTasks(): array
    {
        return $this->tasks;
    }

    /**
     * Register all built-in system tasks.
     */
    private function registerDefaultTasks(): void
    {
        $defaultTasks = [
            // Give the central inbox a bounded opportunity before unrelated network queues.
            new Tasks\NotificationTask('event_outbox_relay'),
            new Tasks\NotificationTask('event_router'),
            new Tasks\NotificationTask('notification_batch_flush'),
            new Tasks\NotificationTask('event_delivery'),
            new Tasks\NotificationTask('notification_retention'),
            new Tasks\WebhookQueueTask(),
            new Tasks\MediaQueueTask(),
            new Tasks\SchemaMigrationTask(),
            new Tasks\CollectionCacheTask(),
            new Tasks\SeoTask(),
            new Tasks\DiscoveryTask(),
            new Tasks\FormBatchFlushTask(),
            new Tasks\AnalyticsIngestTask(),
            new Tasks\PresenceCleanupTask(),
            new Tasks\EditorialsHubMaintenanceTask(),
            new Tasks\WebhookRetentionTask(),
            new Tasks\FormRetentionTask(),
            new Tasks\AnalyticsAggregationTask(),
            new Tasks\DatabaseMaintenanceTask(),
            new Tasks\UptimeHeartbeatTask(),
        ];

        foreach ($defaultTasks as $task) {
            $this->registerTask($task);
        }
    }

    /**
     * Synchronize registered task definitions with the database state.
     */
    public function syncTasksWithDatabase(): void
    {
        $stmt = $this->db->prepare('
            INSERT INTO ' . CronSchema::TABLE_TASKS . ' (
                task_name, description, interval_seconds, is_enabled, next_due_at, updated_at
            ) VALUES (
                :name, :desc, :interval, :enabled, 0, :now
            )
            ON CONFLICT(task_name) DO UPDATE SET
                description = excluded.description,
                updated_at = excluded.updated_at
        ');

        $now = time();
        foreach ($this->tasks as $task) {
            $stmt->execute([
                ':name' => $task->getName(),
                ':desc' => $task->getDescription(),
                ':interval' => $task->getDefaultInterval(),
                ':enabled' => $task->isEnabled() ? 1 : 0,
                ':now' => $now,
            ]);
        }
    }

    /**
     * Recover any tasks stuck in 'running' state beyond the configured timeout.
     */
    public function recoverStaleTasks(int $stuckTimeoutSeconds = 300): int
    {
        $cutoff = time() - $stuckTimeoutSeconds;

        $stmt = $this->db->prepare('
            UPDATE ' . CronSchema::TABLE_TASKS . '
            SET last_status = :error_status,
                last_error = :stale_msg,
                consecutive_failures = consecutive_failures + 1,
                updated_at = :now
            WHERE last_status = :running_status
              AND updated_at < :cutoff
        ');

        $stmt->execute([
            ':error_status' => CronSchema::STATUS_ERROR,
            ':stale_msg' => 'Execution timed out or aborted unexpectedly (stale lock recovered)',
            ':running_status' => CronSchema::STATUS_RUNNING,
            ':cutoff' => $cutoff,
            ':now' => time(),
        ]);

        return $stmt->rowCount();
    }

    /**
     * Execute all due tasks (or a single specified task) under a global lock.
     *
     * @param CronContext $context Execution context
     * @param string|null $specificTask Optional specific task name to run
     * @param bool $force If true, runs task regardless of schedule
     * @return array<string, mixed> Execution summary
     */
    public function runDueTasks(
        CronContext $context,
        ?string $specificTask = null,
        bool $force = false,
        ?array $allowedTasks = null
    ): array {
        return \NomadCMS\Security\PanicMutationGuard::run(function () use ($context, $specificTask, $force, $allowedTasks): array {
            // Cron is always enabled — disable by simply not running the worker.

            // 1. Acquire global lock
            if (!$this->lockManager->acquireGlobalLock()) {
                $lockInfo = $this->lockManager->getActiveLockInfo();
                return [
                    'success' => false,
                    'status' => 'locked',
                    'message' => 'Another worker process is currently running',
                    'lock_info' => $lockInfo,
                    'results' => [],
                ];
            }

            try {
                // 2. Ensure schema is ready and tasks are registered in DB
                $this->syncTasksWithDatabase();

                // 3. Recover any stale tasks from previous crashes
                $this->recoverStaleTasks(CronSchema::STUCK_TIMEOUT_SECONDS);

                // 4. Fetch current task states from DB
                $states = $this->fetchTaskStates();

                $results = [];
                $tasksToRun = $specificTask !== null
                    ? (isset($this->tasks[$specificTask]) ? [$specificTask => $this->tasks[$specificTask]] : [])
                    : $this->tasks;

                // Filter by allowed tasks scope if specified (and not wildcard '*')
                if ($allowedTasks !== null && !in_array('*', $allowedTasks, true)) {
                    // uptime_heartbeat is always included for accurate uptime tracking
                    $allowedLookup = array_flip($allowedTasks);
                    $allowedLookup['uptime_heartbeat'] = true;
                    $tasksToRun = array_intersect_key($tasksToRun, $allowedLookup);
                }

                if ($specificTask !== null && empty($tasksToRun)) {
                    return [
                        'success' => false,
                        'status' => 'not_found',
                        'message' => "Task '{$specificTask}' not found or not permitted for this token",
                        'results' => [],
                    ];
                }

                foreach ($tasksToRun as $name => $task) {
                    if (\NomadCMS\Security\PanicModeService::isActive()) {
                        break;
                    }
                    // Check if global time budget is exceeded
                    if ($context->isTimeExceeded(1.5)) {
                        $context->log("Time budget exceeded. Postponing remaining tasks.");
                        break;
                    }

                    $state = $states[$name] ?? null;
                    $isEnabled = (bool)($state['is_enabled'] ?? $task->isEnabled());
                    $lastRunAt = isset($state['last_run_at']) ? (int)$state['last_run_at'] : null;
                    $interval = (int)($state['interval_seconds'] ?? $task->getDefaultInterval());

                    if (!$isEnabled && !$force) {
                        $results[$name] = [
                            'status' => 'skipped',
                            'reason' => 'disabled',
                        ];
                        continue;
                    }

                    // Apply exponential backoff for repeatedly failing tasks.
                    // After BACKOFF_THRESHOLD consecutive failures the effective interval
                    // is doubled for each additional failure, capped at BACKOFF_MAX_MULTIPLIER.
                    $consecutiveFailures = (int)($state['consecutive_failures'] ?? 0);
                    $effectiveInterval   = $interval;
                    if (!$force && $consecutiveFailures > CronSchema::BACKOFF_THRESHOLD) {
                        $exponent          = min($consecutiveFailures - CronSchema::BACKOFF_THRESHOLD, (int)log(CronSchema::BACKOFF_MAX_MULTIPLIER, 2));
                        $backoffMultiplier = min(CronSchema::BACKOFF_MAX_MULTIPLIER, 2 ** $exponent);
                        $effectiveInterval = $interval * $backoffMultiplier;
                        $context->log(sprintf(
                            'Task %s has %d consecutive failures — backoff x%d (effective interval: %ds)',
                            $name, $consecutiveFailures, $backoffMultiplier, $effectiveInterval
                        ));
                    }

                    $isDue = $force || $task->isDue($lastRunAt, $effectiveInterval);

                    if (!$isDue) {
                        $results[$name] = [
                            'status'              => 'skipped',
                            'reason'              => 'not_due',
                            'next_due_in_seconds' => max(0, ($lastRunAt + $effectiveInterval) - time()),
                        ];
                        continue;
                    }

                    // Execute the task
                    $result = $this->executeTask($task, $context, $interval);
                    $results[$name] = $result->toArray();
                }

                // 5. Purge old cron logs
                $this->purgeOldLogs();

                return [
                    'success' => true,
                    'status' => 'completed',
                    'executed_count' => count(array_filter($results, fn($r) => ($r['status'] ?? '') !== 'skipped')),
                    'total_scanned' => count($tasksToRun),
                    'duration_ms' => round($context->getElapsedTime() * 1000, 2),
                    'results' => $results,
                ];

            } finally {
                $this->lockManager->releaseGlobalLock();
            }
        });
    }

    /**
     * Execute a single task with measurement, error trapping, and state persistence.
     */
    private function executeTask(TaskInterface $task, CronContext $context, ?int $interval = null): TaskResult
    {
        $name = $task->getName();
        $startMicro = microtime(true);
        $startTs = time();

        $context->log("Starting task: {$name}...");

        if ($context->isDryRun()) {
            $context->log("Dry-run mode: skipping execution of {$name}");
            return TaskResult::skipped($name, 'dry_run');
        }

        // Mark task as running in DB
        $this->markTaskRunning($name);

        try {
            $result = $task->run($context);
        } catch (Throwable $e) {
            $errorMsg = $e->getMessage();
            $context->log("Error in task {$name}: {$errorMsg}");
            error_log("[Cron Task Error] [{$name}] " . $e->getMessage() . "\n" . $e->getTraceAsString());
            $result = TaskResult::error($name, $errorMsg);
        }

        $durationMs = (microtime(true) - $startMicro) * 1000;
        $result->setDurationMs($durationMs);

        // Persist completion state and log entry
        $this->markTaskCompleted($task, $result, $startTs, $interval);

        $context->log(sprintf(
            "Finished task: %s | Status: %s | Processed: %d | Duration: %.2f ms",
            $name,
            $result->getStatus(),
            $result->getItemsProcessed(),
            $durationMs
        ));

        return $result;
    }

    /**
     * Mark task as running in system_cron_tasks.
     */
    private function markTaskRunning(string $name): void
    {
        $stmt = $this->db->prepare('
            UPDATE ' . CronSchema::TABLE_TASKS . '
            SET last_status = :status,
                updated_at = :now
            WHERE task_name = :name
        ');
        $stmt->execute([
            ':status' => CronSchema::STATUS_RUNNING,
            ':now' => time(),
            ':name' => $name,
        ]);
    }

    /**
     * Mark task completed (success/error/skipped) and record execution log.
     */
    private function markTaskCompleted(TaskInterface $task, TaskResult $result, int $startTs, ?int $interval = null): void
    {
        $name = $task->getName();
        $now = time();

        if ($interval === null) {
            $stmtInterval = $this->db->prepare('SELECT interval_seconds FROM ' . CronSchema::TABLE_TASKS . ' WHERE task_name = :name');
            $stmtInterval->execute([':name' => $name]);
            $dbInterval = $stmtInterval->fetchColumn();
            $interval = ($dbInterval !== false && is_numeric($dbInterval) && (int)$dbInterval > 0)
                ? (int)$dbInterval
                : $task->getDefaultInterval();
        }

        $nextDueAt = $now + $interval;

        // Update task state row
        $stmt = $this->db->prepare(<<<SQL
            UPDATE system_cron_tasks
            SET last_run_at   = :last_run,
                next_due_at   = :next_due,
                last_duration_ms = :duration,
                last_status   = :status,
                last_error    = :error,
                consecutive_failures = CASE WHEN :status = 'error' THEN consecutive_failures + 1 ELSE 0 END,
                total_runs    = total_runs + 1,
                updated_at    = :now
            WHERE task_name   = :name
        SQL);


        $stmt->execute([
            ':last_run' => $now,
            ':next_due' => $nextDueAt,
            ':duration' => $result->getDurationMs(),
            ':status' => $result->getStatus(),
            ':error' => $result->getError(),
            ':now' => $now,
            ':name' => $name,
        ]);

        // Insert log record only if the task opts in (suppressed for high-frequency tasks like heartbeat)
        if ($task->shouldLog()) {
            $logStmt = $this->db->prepare('
                INSERT INTO ' . CronSchema::TABLE_LOGS . ' (
                    task_name, runner_mode, started_at, duration_ms, status,
                    items_processed, memory_peak_bytes, message
                ) VALUES (
                    :name, :mode, :started, :duration, :status,
                    :items, :memory, :message
                )
            ');

            $logStmt->execute([
                ':name'    => $name,
                ':mode'    => $result->getStatus() === CronSchema::STATUS_SKIPPED ? 'skipped' : 'worker',
                ':started' => $startTs,
                ':duration'=> $result->getDurationMs(),
                ':status'  => $result->getStatus(),
                ':items'   => $result->getItemsProcessed(),
                ':memory'  => $result->getMemoryPeakBytes(),
                ':message' => $result->getError() ?? $result->getMessage(),
            ]);
        }
    }

    /**
     * Fetch existing task state rows indexed by task_name.
     *
     * @return array<string, array<string, mixed>>
     */
    public function fetchTaskStates(): array
    {
        $stmt = $this->db->query('SELECT * FROM ' . CronSchema::TABLE_TASKS);
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $states = [];
        foreach ($rows as $row) {
            $states[$row['task_name']] = $row;
        }

        return $states;
    }

    /**
     * Purge execution logs older than retention window.
     */
    public function purgeOldLogs(): int
    {
        $cutoff = time() - (CronSchema::LOG_RETENTION_DAYS * 86400);

        $stmt = $this->db->prepare('DELETE FROM ' . CronSchema::TABLE_LOGS . ' WHERE started_at < ?');
        $stmt->execute([$cutoff]);

        return $stmt->rowCount();
    }

    /**
     * Returns the timestamp of the last recorded cron heartbeat.
     */
    public function getLastHeartbeatTime(): ?int
    {
        try {
            $stmt = $this->db->prepare('
                SELECT last_run_at FROM ' . CronSchema::TABLE_TASKS . ' 
                WHERE task_name = "uptime_heartbeat" LIMIT 1
            ');
            $stmt->execute();
            $val = $stmt->fetchColumn();

            return $val !== false && $val !== null ? (int)$val : null;
        } catch (\Throwable $e) {
            return null;
        }
    }

    /**
     * Check if active cron runner (CLI or Web-Cron) is operating normally.
     * Normal = heartbeat recorded within last 5 minutes (300 seconds).
     */
    public function isExternalCronActive(): bool
    {
        $lastHeartbeat = $this->getLastHeartbeatTime();
        if ($lastHeartbeat === null) {
            return false;
        }

        return (time() - $lastHeartbeat) <= CronSchema::HEARTBEAT_LIVENESS_WINDOW;
    }

    /**
     * Passive Piggyback Fallback hook: executed on user request shutdown ONLY if
     * no external cron has run recently.
     */
    public static function runPiggybackFallback(): void
    {
        try {
            $manager = self::getInstance();

            // If a real cron or web-cron is active, do nothing on visitor requests!
            if ($manager->isExternalCronActive()) {
                return;
            }

            // Otherwise, run a small time-bounded slice (max 2 seconds)
            $context = new CronContext(
                runnerMode: CronSchema::MODE_PIGGYBACK,
                maxExecutionTime: 2,
                isDryRun: false,
                isVerbose: false
            );

            $manager->runDueTasks($context);
        } catch (Throwable $e) {
            error_log('[Cron Piggyback Fallback Error] ' . $e->getMessage());
        }
    }
}
