<?php

/**
 * NOMAD CMS - Cron Context
 *
 * Provides contextual runtime parameters (runner mode, deadlines, dry-run flags, logger)
 * to individual tasks during their execution.
 *
 * @package NomadCMS\Cron
 */

declare(strict_types=1);

namespace NomadCMS\Cron;

final class CronContext
{
    private string $runnerMode;
    private float $startTime;
    private int $maxExecutionTime;
    private bool $isDryRun;
    private bool $isVerbose;
    /** @var callable|null */
    private $logger;

    public function __construct(
        string $runnerMode = CronSchema::MODE_CLI,
        int $maxExecutionTime = 55,
        bool $isDryRun = false,
        bool $isVerbose = false,
        ?callable $logger = null
    ) {
        $this->runnerMode = $runnerMode;
        $this->startTime = microtime(true);
        $this->maxExecutionTime = max(1, $maxExecutionTime);
        $this->isDryRun = $isDryRun;
        $this->isVerbose = $isVerbose;
        $this->logger = $logger;
    }

    public function getRunnerMode(): string
    {
        return $this->runnerMode;
    }

    public function isCli(): bool
    {
        return $this->runnerMode === CronSchema::MODE_CLI;
    }

    public function isWeb(): bool
    {
        return $this->runnerMode === CronSchema::MODE_WEB;
    }

    public function isPiggyback(): bool
    {
        return $this->runnerMode === CronSchema::MODE_PIGGYBACK;
    }

    public function getStartTime(): float
    {
        return $this->startTime;
    }

    public function getMaxExecutionTime(): int
    {
        return $this->maxExecutionTime;
    }

    public function getElapsedTime(): float
    {
        return microtime(true) - $this->startTime;
    }

    public function getRemainingTime(): float
    {
        return max(0.0, (float)$this->maxExecutionTime - $this->getElapsedTime());
    }

    public function isTimeExceeded(float $safetyMarginSeconds = 1.0): bool
    {
        return $this->getRemainingTime() <= $safetyMarginSeconds;
    }

    public function isDryRun(): bool
    {
        return $this->isDryRun;
    }

    public function isVerbose(): bool
    {
        return $this->isVerbose;
    }

    public function log(string $message): void
    {
        if ($this->logger !== null) {
            ($this->logger)($message);
        } elseif ($this->isVerbose) {
            $timestamp = date('Y-m-d H:i:s');
            echo "[{$timestamp}] {$message}\n";
        }
    }
}
