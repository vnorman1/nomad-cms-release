<?php

/**
 * NOMAD CMS - Cron Token Service
 *
 * Manages dynamically generated, database-backed Web-Cron authentication tokens
 * with fine-grained task permissions (scoping).
 *
 * @package NomadCMS\Cron
 */

declare(strict_types=1);

namespace NomadCMS\Cron;

use PDO;
use RuntimeException;

final class CronTokenService
{
    private PDO $db;

    public function __construct(?PDO $db = null)
    {
        CronSchema::ensureTables();
        $this->db = $db ?? CronSchema::db();
    }

    /**
     * List all registered Web-Cron tokens.
     *
     * @return array<int, array<string, mixed>>
     */
    public function listTokens(): array
    {
        $stmt = $this->db->query('
            SELECT id, name, token_prefix, allowed_tasks, is_active, last_used_at, total_calls, created_by, created_at, updated_at
            FROM ' . CronSchema::TABLE_TOKENS . '
            ORDER BY id DESC
        ');

        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

        return array_map(function (array $row): array {
            $allowedTasks = json_decode((string)($row['allowed_tasks'] ?? '["*"]'), true);
            return [
                'id' => (int)$row['id'],
                'name' => (string)$row['name'],
                'token_prefix' => (string)$row['token_prefix'],
                'allowed_tasks' => is_array($allowedTasks) ? $allowedTasks : ['*'],
                'is_active' => (bool)$row['is_active'],
                'last_used_at' => $row['last_used_at'] !== null ? (int)$row['last_used_at'] : null,
                'last_used_formatted' => $row['last_used_at'] !== null ? date('Y-m-d H:i:s', (int)$row['last_used_at']) : null,
                'total_calls' => (int)$row['total_calls'],
                'created_by' => $row['created_by'] !== null ? (int)$row['created_by'] : null,
                'created_at' => (string)$row['created_at'],
            ];
        }, $rows);
    }

    /**
     * Create a new Web-Cron token with specific task scopes.
     *
     * @param string $name Human-readable label for the token (e.g. "cPanel General Cron")
     * @param array<int, string> $allowedTasks List of allowed task names or ['*'] for all
     * @param int|null $userId Creating user ID
     * @return array{id: int, name: string, token_prefix: string, plain_token: string, allowed_tasks: array, created_at: string}
     */
    public function createToken(string $name, array $allowedTasks = ['*'], ?int $userId = null): array
    {
        $name = trim($name);
        if ($name === '') {
            throw new RuntimeException('Token name is required');
        }

        // Normalize allowed tasks: if empty or contains '*', default to ['*']
        if (empty($allowedTasks) || in_array('*', $allowedTasks, true)) {
            $allowedTasks = ['*'];
        } else {
            $allowedTasks = array_values(array_unique(array_filter(array_map('strval', $allowedTasks))));
        }

        // Generate cryptographically secure token
        $plainToken = 'cron_' . bin2hex(random_bytes(24));
        $tokenPrefix = substr($plainToken, 0, 10) . '...';
        $tokenHash = hash('sha256', $plainToken);

        $now = date('Y-m-d H:i:s');
        $tasksJson = json_encode($allowedTasks, JSON_UNESCAPED_SLASHES);

        $stmt = $this->db->prepare('
            INSERT INTO ' . CronSchema::TABLE_TOKENS . ' (
                name, token_prefix, token_hash, allowed_tasks, is_active, created_by, created_at, updated_at
            ) VALUES (
                :name, :prefix, :hash, :tasks, 1, :user_id, :created_at, :updated_at
            )
        ');

        $stmt->execute([
            ':name' => $name,
            ':prefix' => $tokenPrefix,
            ':hash' => $tokenHash,
            ':tasks' => $tasksJson,
            ':user_id' => $userId,
            ':created_at' => $now,
            ':updated_at' => $now,
        ]);

        $id = (int)$this->db->lastInsertId();

        return [
            'id' => $id,
            'name' => $name,
            'token_prefix' => $tokenPrefix,
            'plain_token' => $plainToken,
            'allowed_tasks' => $allowedTasks,
            'created_at' => $now,
        ];
    }

    /**
     * Verify a plaintext token against stored database tokens or fallback .env secret.
     *
     * @param string $plainToken
     * @return array{valid: bool, source: string, name: string, allowed_tasks: array<string>, token_id: int|null}|null
     */
    public function verifyToken(string $plainToken): ?array
    {
        $plainToken = trim($plainToken);
        if ($plainToken === '') {
            return null;
        }

        $tokenHash = hash('sha256', $plainToken);

        // 1. Check database tokens
        $stmt = $this->db->prepare('
            SELECT id, name, allowed_tasks, is_active
            FROM ' . CronSchema::TABLE_TOKENS . '
            WHERE token_hash = :hash AND is_active = 1
            LIMIT 1
        ');
        $stmt->execute([':hash' => $tokenHash]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($row) {
            $now = time();
            $nowDate = date('Y-m-d H:i:s');

            // Record usage
            $updateStmt = $this->db->prepare('
                UPDATE ' . CronSchema::TABLE_TOKENS . '
                SET last_used_at = :last_used,
                    total_calls = total_calls + 1,
                    updated_at = :updated_at
                WHERE id = :id
            ');
            $updateStmt->execute([
                ':last_used' => $now,
                ':updated_at' => $nowDate,
                ':id' => $row['id'],
            ]);

            $allowedTasks = json_decode((string)($row['allowed_tasks'] ?? '["*"]'), true);

            return [
                'valid'         => true,
                'source'        => 'db',
                'name'          => (string)$row['name'],
                'allowed_tasks' => is_array($allowedTasks) ? $allowedTasks : ['*'],
                'token_id'      => (int)$row['id'],
            ];
        }

        // 2. Check fallback .env CRON_SECRET
        $envSecret = getenv('CRON_SECRET') ?: ($_ENV['CRON_SECRET'] ?? null);
        if (!empty($envSecret) && is_string($envSecret) && hash_equals($envSecret, $plainToken)) {
            return [
                'valid'         => true,
                'source'        => 'env',
                'name'          => 'Environment CRON_SECRET',
                'allowed_tasks' => ['*'],
                'token_id'      => null,
            ];
        }

        return null;
    }

    /**
     * Delete a token by ID.
     */
    public function deleteToken(int $id): bool
    {
        $stmt = $this->db->prepare('DELETE FROM ' . CronSchema::TABLE_TOKENS . ' WHERE id = ?');
        $stmt->execute([$id]);

        return $stmt->rowCount() > 0;
    }

    /**
     * Update a Web-Cron token's name, allowed tasks scope, and/or active status.
     *
     * @param int $id
     * @param string|null $name
     * @param array<string>|null $allowedTasks
     * @param bool|null $isActive
     * @return bool
     */
    public function updateToken(int $id, ?string $name = null, ?array $allowedTasks = null, ?bool $isActive = null): bool
    {
        $fields = [];
        $params = [':id' => $id, ':updated_at' => date('Y-m-d H:i:s')];

        if ($name !== null) {
            $name = trim($name);
            if ($name === '') {
                throw new RuntimeException('A token neve nem lehet üres.');
            }
            $fields[] = 'name = :name';
            $params[':name'] = $name;
        }

        if ($allowedTasks !== null) {
            if (empty($allowedTasks) || in_array('*', $allowedTasks, true)) {
                $allowedTasks = ['*'];
            } else {
                $allowedTasks = array_values(array_unique(array_filter(array_map('strval', $allowedTasks))));
            }
            $fields[] = 'allowed_tasks = :allowed_tasks';
            $params[':allowed_tasks'] = json_encode($allowedTasks, JSON_UNESCAPED_SLASHES);
        }

        if ($isActive !== null) {
            $fields[] = 'is_active = :is_active';
            $params[':is_active'] = $isActive ? 1 : 0;
        }

        if (empty($fields)) {
            return true;
        }

        $fields[] = 'updated_at = :updated_at';
        $sql = 'UPDATE ' . CronSchema::TABLE_TOKENS . ' SET ' . implode(', ', $fields) . ' WHERE id = :id';
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);

        return $stmt->rowCount() > 0;
    }

    /**
     * Toggle a token's active status.
     */
    public function toggleToken(int $id, bool $isActive): bool
    {
        return $this->updateToken($id, null, null, $isActive);
    }
}

