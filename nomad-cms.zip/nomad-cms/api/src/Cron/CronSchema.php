<?php

/**
 * NOMAD CMS - Cron & Background Worker Schema
 *
 * Defines and maintains the system_cron_tasks and system_cron_logs tables
 * in system.sqlite. Every task registered in the system has a corresponding
 * state record here, tracking its scheduling interval, execution stats,
 * and historical runs.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * STORAGE MODEL - system.sqlite
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * system_cron_tasks:
 *   task_name            TEXT PK       -- unique identifier (e.g. 'webhook_queue')
 *   description          TEXT NOT NULL -- human-readable description
 *   interval_seconds     INTEGER       -- scheduled frequency in seconds
 *   is_enabled           INTEGER (0|1) -- toggleable from admin/config
 *   last_run_at          INTEGER       -- Unix timestamp of last run
 *   next_due_at          INTEGER       -- Unix timestamp when task is next due
 *   last_duration_ms     REAL          -- duration of the last execution
 *   last_status          TEXT          -- 'pending'|'running'|'success'|'error'|'skipped'
 *   last_error           TEXT          -- error message if last run failed
 *   consecutive_failures INTEGER       -- count of consecutive failures
 *   total_runs           INTEGER       -- total lifetime runs
 *   updated_at           INTEGER       -- Unix timestamp of record update
 *
 * system_cron_logs:
 *   id                   INTEGER PK AUTOINCREMENT
 *   task_name            TEXT NOT NULL
 *   runner_mode          TEXT NOT NULL -- 'cli' | 'web' | 'piggyback'
 *   started_at           INTEGER NOT NULL
 *   duration_ms          REAL NOT NULL
 *   status               TEXT NOT NULL -- 'success' | 'error' | 'skipped'
 *   items_processed      INTEGER DEFAULT 0
 *   memory_peak_bytes    INTEGER NOT NULL
 *   message              TEXT DEFAULT NULL
 *   created_at           TEXT DEFAULT CURRENT_TIMESTAMP
 *
 * @package NomadCMS\Cron
 */

declare(strict_types=1);

namespace NomadCMS\Cron;

use NomadCMS\Database\AuthDatabase;
use PDO;

final class CronSchema
{
    public const TABLE_TASKS = 'system_cron_tasks';
    public const TABLE_LOGS = 'system_cron_logs';
    public const TABLE_TOKENS = 'system_cron_tokens';

    /** Task Status Constants */
    public const STATUS_PENDING  = 'pending';
    public const STATUS_RUNNING  = 'running';
    public const STATUS_SUCCESS  = 'success';
    public const STATUS_ERROR    = 'error';
    public const STATUS_SKIPPED  = 'skipped';

    /** Runner Modes */
    public const MODE_CLI        = 'cli';
    public const MODE_WEB        = 'web';
    public const MODE_PIGGYBACK  = 'piggyback';

    /**
     * Hardcoded operational defaults — no .env required.
     * Adjust here if you need to tune behaviour for your deployment.
     */
    /** Maximum execution seconds for CLI worker runs (leave 5s safety before crontab next tick). */
    public const CLI_MAX_EXECUTION_TIME  = 55;
    /** Maximum execution seconds for Web-Cron HTTP runs. */
    public const WEB_MAX_EXECUTION_TIME  = 25;
    /** Seconds after which a task stuck in STATUS_RUNNING is considered stale and recovered. */
    public const STUCK_TIMEOUT_SECONDS   = 300;
    /** Days of cron execution log entries to retain. */
    public const LOG_RETENTION_DAYS      = 7;
    /** Heartbeat task interval in seconds (also used for external-cron liveness window). */
    public const HEARTBEAT_INTERVAL      = 60;
    /** Seconds since last heartbeat before the cron is considered inactive. */
    public const HEARTBEAT_LIVENESS_WINDOW = 300;
    /** Maximum consecutive failures before exponential backoff kicks in. */
    public const BACKOFF_THRESHOLD       = 5;
    /** Maximum backoff multiplier cap (2^N, never exceeds this). */
    public const BACKOFF_MAX_MULTIPLIER  = 16;

    private static bool $ready = false;

    /**
     * Ensure required tables and indexes exist in system.sqlite.
     */
    public static function ensureTables(): void
    {
        if (self::$ready) {
            return;
        }

        $db = self::db();

        $db->exec(
            'CREATE TABLE IF NOT EXISTS ' . self::TABLE_TASKS . ' (
                task_name            TEXT PRIMARY KEY,
                description          TEXT NOT NULL,
                interval_seconds     INTEGER NOT NULL DEFAULT 60,
                is_enabled           INTEGER NOT NULL DEFAULT 1,
                last_run_at          INTEGER DEFAULT NULL,
                next_due_at          INTEGER NOT NULL DEFAULT 0,
                last_duration_ms     REAL DEFAULT 0,
                last_status          TEXT DEFAULT \'pending\',
                last_error           TEXT DEFAULT NULL,
                consecutive_failures INTEGER NOT NULL DEFAULT 0,
                total_runs           INTEGER NOT NULL DEFAULT 0,
                updated_at           INTEGER NOT NULL
            )'
        );

        $db->exec(
            'CREATE INDEX IF NOT EXISTS idx_cron_next_due 
             ON ' . self::TABLE_TASKS . ' (is_enabled, next_due_at)'
        );

        $db->exec(
            'CREATE TABLE IF NOT EXISTS ' . self::TABLE_LOGS . ' (
                id                   INTEGER PRIMARY KEY AUTOINCREMENT,
                task_name            TEXT NOT NULL,
                runner_mode          TEXT NOT NULL,
                started_at           INTEGER NOT NULL,
                duration_ms          REAL NOT NULL,
                status               TEXT NOT NULL,
                items_processed      INTEGER DEFAULT 0,
                memory_peak_bytes    INTEGER NOT NULL,
                message              TEXT DEFAULT NULL,
                created_at           TEXT DEFAULT CURRENT_TIMESTAMP
            )'
        );

        $db->exec(
            'CREATE INDEX IF NOT EXISTS idx_cron_logs_task_created 
             ON ' . self::TABLE_LOGS . ' (task_name, started_at DESC)'
        );

        $db->exec(
            'CREATE INDEX IF NOT EXISTS idx_cron_logs_started 
             ON ' . self::TABLE_LOGS . ' (started_at)'
        );

        $db->exec(
            'CREATE TABLE IF NOT EXISTS ' . self::TABLE_TOKENS . ' (
                id                   INTEGER PRIMARY KEY AUTOINCREMENT,
                name                 TEXT NOT NULL,
                token_prefix         TEXT NOT NULL,
                token_hash           TEXT UNIQUE NOT NULL,
                allowed_tasks        TEXT NOT NULL DEFAULT \'["*"]\',
                is_active            INTEGER NOT NULL DEFAULT 1,
                last_used_at         INTEGER DEFAULT NULL,
                total_calls          INTEGER NOT NULL DEFAULT 0,
                created_by           INTEGER DEFAULT NULL,
                created_at           TEXT DEFAULT CURRENT_TIMESTAMP,
                updated_at           TEXT DEFAULT CURRENT_TIMESTAMP
            )'
        );

        $db->exec(
            'CREATE INDEX IF NOT EXISTS idx_cron_tokens_hash 
             ON ' . self::TABLE_TOKENS . ' (token_hash)'
        );

        $db->exec(
            'CREATE INDEX IF NOT EXISTS idx_cron_tokens_active 
             ON ' . self::TABLE_TOKENS . ' (is_active)'
        );

        self::$ready = true;
    }

    /**
     * Shared PDO handle for system.sqlite.
     */
    public static function db(): PDO
    {
        return AuthDatabase::getInstance();
    }

    /**
     * Reset memoisation guard (useful in testing).
     */
    public static function resetReadyFlag(): void
    {
        self::$ready = false;
    }
}
