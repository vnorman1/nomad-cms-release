<?php
/**
 * NOMAD CMS — Media filename aliases.
 * Keeps existing URLs, stored content and signed historical versions usable after
 * explicit format conversion. Indexed aliases are flattened and never point outside uploads.
 */
declare(strict_types=1);

namespace NomadCMS\Services;

use NomadCMS\Database\ContentDatabase;
use PDO;

/** Resolves local media identities without rewriting CMS content or historical signatures. */
final class MediaAliasService
{
    public static function ensureSchema(PDO $db): void
    {
        $db->exec('CREATE TABLE IF NOT EXISTS media_aliases (
            filename TEXT PRIMARY KEY,
            target_filename TEXT NOT NULL,
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        )');
        $db->exec('CREATE INDEX IF NOT EXISTS idx_media_alias_target ON media_aliases(target_filename,filename)');
    }

    private static function exists(PDO $db): bool
    {
        return (bool)$db->query("SELECT 1 FROM sqlite_master WHERE type='table' AND name='media_aliases'")->fetchColumn();
    }

    public static function resolve(string $filename, ?PDO $db = null): string
    {
        $db ??= ContentDatabase::getInstance();
        if (!self::exists($db)) {
            return $filename;
        }
        $stmt = $db->prepare('SELECT target_filename FROM media_aliases WHERE filename=?');
        $stmt->execute([$filename]);
        $target = $stmt->fetchColumn();
        return is_string($target) ? $target : $filename;
    }

    public static function references(string $filename, PDO $db): array
    {
        $filename = self::resolve($filename, $db);
        if (!self::exists($db)) {
            return [$filename];
        }
        $stmt = $db->prepare('SELECT filename FROM media_aliases WHERE target_filename=?');
        $stmt->execute([$filename]);
        return array_merge([$filename], $stmt->fetchAll(PDO::FETCH_COLUMN));
    }

    public static function mergeCounts(array $counts, PDO $db): array
    {
        if (!self::exists($db)) {
            return $counts;
        }
        $stmt = $db->query('SELECT filename,target_filename FROM media_aliases');
        while ($alias = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $source = $alias['filename'];
            $target = $alias['target_filename'];
            $counts[$target] = ($counts[$target] ?? 0) + ($counts[$source] ?? 0);
            unset($counts[$source]);
        }
        return $counts;
    }

    /** Caller owns the metadata/file migration transaction. */
    public static function register(string $filename, string $target, PDO $db): void
    {
        $db->prepare('UPDATE media_aliases SET target_filename=? WHERE target_filename=?')->execute([$target, $filename]);
        $db->prepare('INSERT INTO media_aliases(filename,target_filename) VALUES (?,?)
            ON CONFLICT(filename) DO UPDATE SET target_filename=excluded.target_filename')->execute([$filename, $target]);
    }

    public static function remove(string $filename, PDO $db): void
    {
        if (self::exists($db)) {
            $db->prepare('DELETE FROM media_aliases WHERE target_filename=? OR filename=?')->execute([$filename, $filename]);
        }
    }
}
