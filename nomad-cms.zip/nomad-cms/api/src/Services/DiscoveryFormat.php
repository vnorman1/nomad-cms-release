<?php
/**
 * NOMAD CMS — public discovery entry formatting.
 * Preserves schema publication, localization and Markdown link conventions without loading blocks.
 * Formats one item at a time; sitemap and LLM inclusion are independent.
 */
declare(strict_types=1);

namespace NomadCMS\Services;

final class DiscoveryFormat
{
    public function __construct(private readonly array $schema, private readonly string $origin)
    {
    }

    public function languages(): array
    {
        $i18n = $this->schema['i18n'] ?? [];
        $languages = !empty($i18n['enabled']) ? ($i18n['languages'] ?? []) : [];
        if (count($languages) < 2) {
            return [''];
        }
        foreach ($languages as $language) {
            if (!is_string($language) || !preg_match('/^[a-zA-Z0-9_-]{1,32}$/D', $language)) {
                throw new \RuntimeException('Invalid discovery locale');
            }
        }
        if (count(array_unique(array_map('strtolower', $languages))) !== count($languages)) {
            throw new \RuntimeException('Discovery locales must be distinct without regard to case');
        }
        return array_values($languages);
    }

    public static function segment(string $value): string
    {
        return preg_match('/^[a-z0-9_-]{1,64}$/D', $value) && !str_starts_with($value, 'g-')
            ? $value : 'g-' . substr(hash('sha256', $value), 0, 24);
    }

    public function localized(mixed $value, string $locale): mixed
    {
        if (!is_array($value)) {
            return $value;
        }
        $default = $this->schema['i18n']['defaultLanguage'] ?? 'hu';
        $fallback = reset($value);
        return $value[$locale] ?? $value[$default] ?? ($fallback === false ? '' : $fallback);
    }

    public static function clean(mixed $value, int $limit = 250): string
    {
        if (is_array($value)) {
            $pieces = [];
            array_walk_recursive($value, static function ($part) use (&$pieces): void {
                if (is_string($part)) {
                    $pieces[] = $part;
                }
            });
            $value = implode(' ', $pieces);
        }
        $value = is_scalar($value) ? (string) $value : '';
        $value = trim(preg_replace('/\s+/u', ' ', html_entity_decode(strip_tags($value), ENT_QUOTES | ENT_HTML5, 'UTF-8')) ?? '');
        if (mb_strlen($value, 'UTF-8') > $limit) {
            $value = mb_substr($value, 0, $limit - 3, 'UTF-8') . '...';
        }
        return $value;
    }

    public static function label(mixed $value, int $limit = 120): string
    {
        return str_replace(['\\', '[', ']'], ['\\\\', '\\[', '\\]'], self::clean($value, $limit));
    }

    private function slug(mixed $value, string $locale): string
    {
        $value = $this->localized($value, $locale);
        if (!is_string($value) && !is_numeric($value)) {
            return '';
        }
        $slug = (string) $value;
        if (preg_match('/[\sA-ZÁÉÍÓÖŐÚÜŰáéíóöőúüűäëïôûñçß]/u', $slug)) {
            $slug = strtr($slug, [
                'á' => 'a', 'é' => 'e', 'í' => 'i', 'ó' => 'o', 'ö' => 'o', 'ő' => 'o', 'ú' => 'u', 'ü' => 'u', 'ű' => 'u',
                'Á' => 'a', 'É' => 'e', 'Í' => 'i', 'Ó' => 'o', 'Ö' => 'o', 'Ő' => 'o', 'Ú' => 'u', 'Ü' => 'u', 'Ű' => 'u',
                'ä' => 'a', 'ë' => 'e', 'ï' => 'i', 'ô' => 'o', 'û' => 'u', 'ñ' => 'n', 'ç' => 'c', 'ß' => 'ss',
            ]);
            $slug = trim(preg_replace('/[^a-z0-9]+/', '-', strtolower($slug)), '-');
        }
        return $slug;
    }

    private function published(array $item, array $config): bool
    {
        $field = $config['publishedField'] ?? null;
        if ($field !== null) {
            $value = $item[$field] ?? false;
        } elseif (isset($item['status'])) {
            return in_array($item['status'], ['stabil', 'mukodo', 'published', 'active'], true);
        } else {
            $value = true;
            foreach (['published', 'isPublished', 'active', 'isActive'] as $implicit) {
                if (array_key_exists($implicit, $item)) {
                    $value = $item[$implicit];
                    break;
                }
            }
        }
        return filter_var($value, FILTER_VALIDATE_BOOLEAN, FILTER_NULL_ON_FAILURE) ?? !empty($value);
    }

    private function field(array $item, array $config, string $setting, array $fallback, string $locale): mixed
    {
        if (isset($config[$setting], $item[$config[$setting]])) {
            return $this->localized($item[$config[$setting]], $locale);
        }
        foreach ($fallback as $field) {
            if (isset($item[$field])) {
                $value = $this->localized($item[$field], $locale);
                if ($setting !== 'summaryField' || self::clean($value) !== '') {
                    return $value;
                }
            }
        }
        return '';
    }

    /** Yield independent XML and Markdown entries, including localized slugs and alternate URLs. */
    public function entries(string $key, array $config, array $item, bool $static = false): \Generator
    {
        if ($static) {
            $config = $item;
        }
        if (!$static && !$this->published($item, $config)) {
            return;
        }
        $sitemap = $static || !empty($config['isSitemap']);
        $llms = $static || ($config['isLlms'] ?? $sitemap);
        $paths = [];
        foreach ($this->languages() as $locale) {
            if ($static) {
                $path = $item['path'] ?? '/';
            } else {
                $slug = $this->slug($item[$config['slugField'] ?? 'slug'] ?? $item['slug'] ?? $item['id'] ?? null, $locale);
                if ($slug === '') {
                    continue;
                }
                $path = str_replace('{slug}', $slug, $config['urlPattern'] ?? '/' . $key . '/{slug}');
            }
            $paths[$locale] = '/' . ltrim((string) $path, '/');
        }
        foreach ($paths as $locale => $path) {
            $pagePath = ($locale !== '' ? '/' . $locale : '') . ($locale !== '' && $path === '/' ? '' : $path);
            $url = $this->origin . $pagePath;
            if (mb_strlen($url, 'UTF-8') >= 2048 || preg_match('/[\x00-\x20<>]/', $url)) {
                throw new \RuntimeException('Invalid discovery URL');
            }
            $group = ($locale !== '' ? $locale . '/' : '') . ($static ? 'pages' : 'slots/' . self::segment($key));
            $title = $static ? 'Pages' : self::clean($this->localized($config['label'] ?? ucfirst($key), $locale), 120);
            if ($sitemap) {
                $xml = '<url><loc>' . self::xml($url) . '</loc>';
                if ($locale !== '') {
                    foreach ($paths as $altLocale => $altPath) {
                        $xml .= '<xhtml:link rel="alternate" hreflang="' . self::xml($altLocale) . '" href="'
                            . self::xml($this->origin . '/' . $altLocale . ($altPath === '/' ? '' : $altPath)) . '"/>';
                    }
                    $default = $this->schema['i18n']['xDefaultLanguage'] ?? $this->schema['i18n']['defaultLanguage'] ?? 'hu';
                    if (isset($paths[$default])) {
                        $xml .= '<xhtml:link rel="alternate" hreflang="x-default" href="'
                            . self::xml($this->origin . '/' . $default . ($paths[$default] === '/' ? '' : $paths[$default])) . '"/>';
                    }
                }
                if (($config['includeLastmod'] ?? true) !== false) {
                    $date = $static ? ($item['lastmod'] ?? $item['_schemaDate'] ?? null)
                        : (!empty($config['lastmodField']) ? ($item[$config['lastmodField']] ?? null)
                            : ($item['_collectionMeta']['public_updated_at'] ?? $item['updatedAt'] ?? $item['updated_at'] ?? $item['_slotDate'] ?? null));
                    if (is_string($date) && preg_match('/^(\d{4})-(\d{2})-(\d{2})(?:$|T| )/', $date, $match)
                        && checkdate((int) $match[2], (int) $match[3], (int) $match[1])) {
                        $xml .= '<lastmod>' . substr($date, 0, 10) . '</lastmod>';
                    }
                }
                $xml .= '<changefreq>' . self::xml($config['changefreq'] ?? ($static ? 'monthly' : 'weekly')) . '</changefreq>';
                $xml .= '<priority>' . self::xml((string) ($config['priority'] ?? ($static ? '0.5' : '0.7'))) . "</priority></url>\n";
                yield ['kind'  =>  'xml', 'grp'  =>  $group, 'locale'  =>  $locale, 'title'  =>  $title, 'loc'  =>  $url, 'body'  =>  $xml];
            }
            if ($llms) {
                if ($static) {
                    $label = $this->localized($item['label'] ?? ($path === '/' ? 'Főoldal' : trim($path, '/')), $locale);
                    $summary = $this->localized($item['description'] ?? '', $locale);
                } else {
                    $label = $this->field($item, $config, 'titleField', ['title', 'name', 'label', 'heading'], $locale);
                    $summary = $this->field($item, $config, 'summaryField', ['summary', 'excerpt', 'description', 'lead'], $locale);
                    $label = $label === '' || $label === null ? basename($path) : $label;
                }
                if (($this->schema['llms']['format'] ?? 'md') === 'md') {
                    $url = $this->origin . '/llms' . ($locale !== '' ? '/' . $locale : '')
                        . ($static && $path === '/' ? '/home' : $path);
                }
                // Encode Markdown delimiters without changing the linked URL's meaning.
                $url = str_replace(['(', ')', ' ', '\\'], ['%28', '%29', '%20', '%5C'], $url);
                $body = '- [' . self::label($label) . '](' . $url . ')';
                $summary = self::clean($summary);
                $body .= ($summary !== '' ? ': ' . self::label($summary, 250) : '') . "\n";
                yield ['kind'  =>  'md', 'grp'  =>  $group, 'locale'  =>  $locale, 'title'  =>  $title, 'loc'  =>  $url, 'body'  =>  $body];
            }
        }
    }

    public static function xml(string $text): string
    {
        return htmlspecialchars($text, ENT_QUOTES | ENT_XML1, 'UTF-8');
    }
}
