<?php
/**
 * NOMAD CMS — Bounded, schema-validated collection filter predicates.
 * Uses bound JSON paths and values; blocks stay in their separate storage table.
 * Predicates augment the existing ownership, publication and FTS query scopes.
 */
declare(strict_types=1);

namespace NomadCMS\Services;

final class CollectionFilters
{
    /** @return array{0: list<string>, 1: list<mixed>} SQL conditions and bound values. */
    public static function compile(mixed $filters, array $schema): array
    {
        if (!is_array($filters) || !array_is_list($filters) || count($filters) > 8) {
            throw new \InvalidArgumentException('Invalid collection filters');
        }
        $fields = [];
        foreach ($schema['fields'] ?? [] as $field) {
            $fields[$field['id']] = $field;
        }
        $conditions = [];
        $params = [];
        foreach ($filters as $filter) {
            if (!is_array($filter) || !is_string($filter['field'] ?? null)
                || !isset($fields[$filter['field']]) || !is_string($filter['operator'] ?? null)) {
                throw new \InvalidArgumentException('Unknown collection filter field');
            }
            $field = $fields[$filter['field']];
            $operator = $filter['operator'];
            $allowed = ['empty', 'not_empty'];
            if ($field['type'] === 'boolean') $allowed = array_merge($allowed, ['is_true', 'is_false']);
            if (in_array($field['type'], ['select', 'multiselect'], true)) $allowed[] = 'equals';
            if (!in_array($operator, $allowed, true)) {
                throw new \InvalidArgumentException('Invalid collection filter operator');
            }
            if ($field['type'] === 'blocks') {
                $exists = "EXISTS (SELECT 1 FROM collection_blocks b WHERE b.item_row_id=i.row_id AND b.field_id=? AND ((json_type(b.data)='array' AND json_array_length(b.data)>0) OR (json_type(b.data)='object' AND json_type(b.data,'$.type')='text')))";
                $params[] = $filter['field'];
            } else {
                // Quote a schema-validated key; the complete JSON path is still bound.
                $path = '$.' . json_encode($filter['field'], JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR);
                $exists = 'EXISTS (SELECT 1 FROM json_tree(i.data, ?) v WHERE ';
                $params[] = $path;
                if ($operator === 'is_true' || $operator === 'is_false') {
                    $exists .= 'v.type=?)';
                    $params[] = $operator === 'is_true' ? 'true' : 'false';
                } elseif ($operator === 'equals') {
                    $value = $filter['value'] ?? null;
                    $options = array_column($field['options'] ?? [], 'value');
                    if (!is_string($value) || !in_array($value, $options, true)) {
                        throw new \InvalidArgumentException('Invalid collection filter value');
                    }
                    $exists .= "v.type='text' AND v.atom=?)";
                    $params[] = $value;
                } elseif (in_array($field['type'], ['image', 'gif', 'gallery', 'video', 'audio', 'file'], true)) {
                    // ALT/filename metadata alone does not mean there is a media source.
                    $exists .= "v.type='text' AND length(trim(v.atom, char(9)||char(10)||char(13)||' '))>0 AND (v.key IS NULL OR v.key NOT IN ('alt','filename','originalName','size','encrypted','width','height','mime','mimeType','type')) AND v.path NOT GLOB '*.alt' AND v.path NOT GLOB '*.alt.*')";
                } else {
                    $exists .= "v.type NOT IN ('null','object','array') AND (v.type<>'text' OR length(trim(v.atom, char(9)||char(10)||char(13)||' '))>0))";
                }
            }
            $conditions[] = $operator === 'empty' ? 'NOT ' . $exists : $exists;
        }
        return [$conditions, $params];
    }
}
