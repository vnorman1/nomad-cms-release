<?php
/**
 * NOMAD CMS — Authoritative Forge import boundary.
 * Validates every record before any media/write side effects, assigns new
 * storage identities, and uses native writers for encryption, indexes, history
 * and block separation. Collection/list/object writes are atomic per import.
 */
declare(strict_types=1);

namespace NomadCMS\Services;

use NomadCMS\Database\CollectionDatabase;
use NomadCMS\Database\ContentDatabase;
use NomadCMS\Database\MassiveDatabase;
use NomadCMS\Services\Schema\SchemaDefinition;
use NomadCMS\Services\Schema\SchemaProvider;

final class ForgeImportService
{
    /** Decode only top-level records and structural CMS fields as associative arrays. */
    public static function decode(string $json, array $slot): array
    {
        $records = json_decode($json, false, 65, JSON_THROW_ON_ERROR);
        if (!is_array($records) || !array_is_list($records)) {
            throw new \InvalidArgumentException('Forge payload must be an array of objects', 422);
        }
        $fields = SchemaDefinition::fields($slot);
        foreach ($records as &$record) {
            if (!$record instanceof \stdClass) {
                throw new \InvalidArgumentException('Every Forge record must be an object', 422);
            }
            $record = get_object_vars($record);
            // Storage metadata from foreign exports cannot target existing items.
            unset($record['_dndId'], $record['_version'], $record['_updated_at'], $record['client_updated_at']);
            foreach ($fields as $field) {
                $id = $field['id'];
                if (!array_key_exists($id, $record)) {
                    if (array_key_exists('defaultValue', $field)) {
                        $record[$id] = $field['defaultValue'];
                    }
                    continue;
                }
                if (!empty($field['localized']) && $record[$id] instanceof \stdClass) {
                    $record[$id] = get_object_vars($record[$id]);
                    foreach ($record[$id] as &$locale) {
                        $locale = self::structural($locale, $field['type']);
                    }
                    unset($locale);
                } else {
                    $record[$id] = self::structural($record[$id], $field['type']);
                }
            }
        }
        unset($record);
        return $records;
    }

    private static function structural(mixed $value, string $type): mixed
    {
        if ($type === 'json') {
            return $value;
        }
        if ($type === 'blocks' && is_array($value)) {
            return array_map(static function ($block) {
                if ($block instanceof \stdClass) {
                    $block = get_object_vars($block);
                }
                if (is_array($block) && isset($block['type'], $block['data'])) {
                    $block['data'] = self::structural($block['data'], $block['type']);
                }
                return $block;
            }, $value);
        }
        return $value instanceof \stdClass ? get_object_vars($value) : $value;
    }

    /** @return array<int, array<string, mixed>> All errors, bounded for the response. */
    public static function issues(array $records, array $slot): array
    {
        $issues = [];
        if ($records === []) {
            return [['row' => null, 'sourcePath' => [], 'targetPath' => [], 'code' => 'EMPTY_IMPORT', 'message' => 'No records to import']];
        }
        if (($slot['type'] ?? '') === 'object' && count($records) !== 1) {
            return [['row' => null, 'sourcePath' => [], 'targetPath' => [], 'code' => 'SELECT_RECORD', 'message' => 'Select exactly one source record for an object slot']];
        }
        foreach ($records as $index => $record) {
            foreach (SchemaDefinition::issues($record, $slot) as $entry) {
                $issues[] = ['row' => $index + 1, 'sourcePath' => [], 'targetPath' => [['kind' => 'key', 'value' => $entry['path']]], 'code' => 'SCHEMA_VALIDATION', 'message' => $entry['message']];
            }
            foreach (SchemaDefinition::fields($slot) as $field) {
                if ($field['type'] !== 'blocks') {
                    continue;
                }
                $value = $record[$field['id']] ?? null;
                $locales = !empty($field['localized']) && is_array($value) ? $value : ['' => $value];
                foreach ($locales as $locale => $blocks) {
                    if (!is_array($blocks) || !array_is_list($blocks)) {
                        continue;
                    }
                    $ids = [];
                    foreach ($blocks as $blockIndex => $block) {
                        $id = is_array($block) ? ($block['id'] ?? '') : '';
                        $type = is_array($block) ? ($block['type'] ?? '') : '';
                        if (!is_string($id) || $id === '' || isset($ids[$id]) || !in_array($type, SchemaDefinition::TYPES, true)
                            || in_array($type, ['slug', 'boolean', 'select', 'multiselect', 'array', 'blocks', 'relation', 'relation_many'], true)
                            || !array_key_exists('data', $block)) {
                            $path = [['kind' => 'key', 'value' => $field['id']]];
                            if ($locale !== '') {
                                $path[] = ['kind' => 'key', 'value' => (string) $locale];
                            }
                            $path[] = ['kind' => 'index', 'value' => $blockIndex];
                            $issues[] = ['row' => $index + 1, 'sourcePath' => [], 'targetPath' => $path, 'code' => 'INVALID_BLOCK', 'message' => 'Native blocks require a unique id, supported type and data'];
                        }
                        if (is_string($id)) {
                            $ids[$id] = true;
                        }
                    }
                }
            }
            if (count($issues) >= 100) {
                return array_slice($issues, 0, 100);
            }
        }
        return $issues;
    }

    /** Import already validated records through native storage boundaries. */
    public static function write(array $records, string $key): int
    {
        $slot = SchemaProvider::slot($key);
        if (!$slot) {
            throw new \RuntimeException('SCHEMA_SLOT_ARCHIVED', 410);
        }
        SchemaProvider::assertWritable($key);
        $issues = self::issues($records, $slot);
        if ($issues !== []) {
            throw new \InvalidArgumentException('SCHEMA_VALIDATION_FAILED: ' . json_encode($issues, JSON_THROW_ON_ERROR), 422);
        }
        if ($slot['type'] === 'massive') {
            return MassiveDatabase::bulkInsert($key, $records, (bool) ($slot['massive']['encrypted'] ?? false), $slot['massive']['searchableFields'] ?? []);
        }
        if ($slot['type'] === 'collection') {
            CollectionDatabase::ensureReady($key);
            $count = CollectionDatabase::transaction(static function () use ($records, $key): int {
                foreach ($records as $record) {
                    unset($record['_dndId'], $record['_version']);
                    CollectionDatabase::writeItem($key, null, $record, 'create', ['changed_by' => 'forge-import']);
                }
                return count($records);
            });
            CollectionApiService::invalidateAfterCommit($key);
            return $count;
        }
        return CollectionDatabase::transaction(static function () use ($records, $key, $slot): int {
            $existing = ContentDatabase::getSlotWithVersion($key);
            $data = $slot['type'] === 'object' ? $records[0] : array_merge(is_array($existing['data'] ?? null) ? $existing['data'] : [], RelationService::ensureItemUids($records)[0]);
            ContentDatabase::saveSlot($key, $data, [
                'slot_type' => $slot['type'],
                'changed_by' => 'forge-import',
                'version_intent' => 'system',
                'replace' => $slot['type'] === 'object',
                'expected_hash' => $existing['hash'] ?? null,
            ]);
            return $slot['type'] === 'object' ? 1 : count($records);
        });
    }
}
