<?php
/**
 * NOMAD CMS - Collection History Service
 * Version history and audit trail manager for individual collection items
 *
 * Features:
 * - Item-specific version log queries with pagination and RBAC/ownership scoping
 * - Detailed version diff inspection (content payload & blocks references)
 * - Cryptographic integrity validation (HMAC-SHA256 tampering detection)
 * - Atomic version restoration to prior revisions without affecting peers
 *
 * Endpoints: Integrated via /api/endpoints/versions.php
 * Storage: collection_item_versions, collection_history_blocks
 */

declare(strict_types=1);
namespace NomadCMS\Services;
use NomadCMS\Database\CollectionDatabase;
use NomadCMS\Database\ContentDatabase;
use NomadCMS\Middleware\AuthMiddleware;

final class CollectionHistoryService
{
    public static function handle(
        string $key,
        string $action,
        string $method,
        array $query,
        array $body
    ): array {
        AuthMiddleware::requireSlotAccess($key);
        AuthMiddleware::requirePermission("versions:read:*");
        $all = AuthMiddleware::hasPermission("content:read:*", $key);
        if (!$all && !AuthMiddleware::hasGrantedScope("content:read:own")) {
            AuthMiddleware::requirePermission("content:read:*");
        }
        $db = CollectionDatabase::getInstance();
        if ($action === "collection_history" && $method === "GET") {
            $where = "v.slot_key=?";
            $params = [$key];
            // Older pre-cap histories obey the configured limit immediately, without a write on GET.
            $maximum = max(0, CollectionDatabase::getVersioningSettings()->getMaxVersions());
            $where .= ' AND v.id IN (SELECT id FROM collection_item_versions WHERE slot_key=? ORDER BY id DESC LIMIT ?)';
            array_push($params, $key, $maximum);
            if (isset($query["item_uid"])) {
                $where .= " AND v.item_uid=?";
                $params[] = $query["item_uid"];
            }
            if (!$all) {
                $where .=
                    " AND EXISTS(SELECT 1 FROM slot_ownership o WHERE o.slot_key=v.slot_key AND o.item_uid=v.item_uid AND o.owner_uuid=?)";
                $params[] = AuthMiddleware::getCurrentUser()->uuid;
            }
            if (empty($query['include_shadows'])) $where.=" AND v.version_type<>'shadow'";
            $users = [];
            $actorName = static function (string $actor) use (&$users): string {
                if (!array_key_exists($actor, $users)) {
                    $user = \NomadCMS\Database\UserRepository::findByUuid($actor);
                    $name = $user ? trim(($user['first_name'] ?? '') . ' ' . ($user['last_name'] ?? '')) : '';
                    $users[$actor] = $name !== '' ? $name : ($user['email'] ?? '');
                }
                return $users[$actor] ?: (!preg_match('/^[0-9a-f-]{32,36}$/i', $actor) ? $actor : 'User');
            };
            $search = trim(mb_substr((string) ($query['search'] ?? ''), 0, 200));
            if ($search !== '') {
                $db->sqliteCreateFunction('nomad_history_actor', $actorName, 1);
                $db->sqliteCreateFunction('nomad_history_match', \NomadCMS\Services\Versioning\HistorySearch::matches(...), 2);
                $where .= " AND nomad_history_match(COALESCE(v.change_summary,'') || ' ' || COALESCE(v.item_label,'') || ' ' || COALESCE(v.version_name,'') || ' ' || v.changed_by || ' ' || nomad_history_actor(v.changed_by) || ' #' || v.id, ?)";
                $params[] = $search;
            }
            if (isset($query['snapshot_id'])) $snapshot=max(0,(int)$query['snapshot_id']);
            else { $s=$db->prepare('SELECT COALESCE(MAX(id),0) FROM collection_item_versions v WHERE '.$where); $s->execute($params); $snapshot=(int)$s->fetchColumn(); }
            $where.=' AND v.id<=?'; $params[]=$snapshot;
            $limit=max(1,min(100,(int)($query['limit']??50))); $offset=max(0,(int)($query['offset']??0));
            $count=$db->prepare('SELECT COUNT(*) FROM collection_item_versions v WHERE '.$where); $count->execute($params);
            $total=(int)$count->fetchColumn();
            $s=$db->prepare('SELECT id,item_uid,revision,operation,schema_hash,changed_by,created_at,change_summary,item_label,version_type,version_name,LENGTH(data) AS content_size FROM collection_item_versions v WHERE '.$where.' ORDER BY id DESC LIMIT '.$limit.' OFFSET '.$offset);
            $s->execute($params); $history=$s->fetchAll();
            foreach ($history as &$version) {
                $version['changed_by_name'] = $actorName($version['changed_by']);
            }
            unset($version);
            return ['success'=>true,'history'=>$history,'total_count'=>$total,'offset'=>$offset,'limit'=>$limit,'snapshot_id'=>$snapshot,'schema_revision'=>CollectionDatabase::state($key)['schema_hash']];
        }
        if ($action==='collection_delete_all'&&$method==='POST') {
            \NomadCMS\Middleware\CSRFMiddleware::validateForSession();
            AuthMiddleware::requirePermission('system:admin:*');
            $where='slot_key=?'; $params=[$key];
            if (!$all) { $where.=' AND EXISTS(SELECT 1 FROM slot_ownership o WHERE o.slot_key=collection_item_versions.slot_key AND o.item_uid=collection_item_versions.item_uid AND o.owner_uuid=?)'; $params[]=AuthMiddleware::getCurrentUser()->uuid; }
            CollectionDatabase::transaction(function() use($db,$where,$params) { $s=$db->prepare('DELETE FROM collection_item_versions WHERE '.$where); $s->execute($params); });
            return ['success'=>true];
        }
        $id = (int) ($body["history_id"] ?? ($query["history_id"] ?? 0));
        $s = $db->prepare(
            "SELECT item_uid FROM collection_item_versions WHERE id=? AND slot_key=?"
        );
        $s->execute([$id, $key]);
        $uid = $s->fetchColumn();
        if (
            $uid === false ||
            (!$all &&
                ContentDatabase::getOwner($key, $uid) !==
                    AuthMiddleware::getCurrentUser()->uuid)
        ) {
            throw new \OutOfBoundsException("Version not found");
        }
        if ($action==='collection_version'&&$method==='GET') {
            $version=CollectionDatabase::historyItem($id);
            $s=$db->prepare('SELECT id FROM collection_item_versions WHERE slot_key=? AND item_uid=? AND id<? ORDER BY id DESC LIMIT 1'); $s->execute([$key,$uid,$id]); $previousId=$s->fetchColumn();
            $old=$previousId ? CollectionDatabase::historyItem((int)$previousId)['item'] : (object)[];
            $new=$version['operation']==='delete'?(object)[]:$version['item'];
            $diff=(new \NomadCMS\Services\Versioning\DiffEngine())->computeDiff(json_encode($old,JSON_THROW_ON_ERROR),json_encode($new,JSON_THROW_ON_ERROR));
            if (!$diff['success']) throw new \RuntimeException('Version diff could not be reconstructed');
            $version['diff_forward_json']=json_encode($diff['diff_forward'],JSON_THROW_ON_ERROR|JSON_UNESCAPED_UNICODE);
            $version['diff_backward_json']=(new \NomadCMS\Services\Versioning\DiffEngine())->computeBackwardDiff($version['diff_forward_json']);
            $currentRow = CollectionDatabase::row($key, $uid);
            return ['success'=>true,'version'=>$version,'current_content'=>CollectionDatabase::getItem($key,$uid),'current_revision'=>$currentRow['revision']??null,'current_updated_at'=>$currentRow['updated_at']??null,'schema_revision'=>CollectionDatabase::state($key)['schema_hash']];
        }
        if (in_array($action,['collection_rename','collection_delete_version','collection_promote'],true)&&$method==='POST') {
            \NomadCMS\Middleware\CSRFMiddleware::validateForSession();
            AuthMiddleware::requirePermission('versions:restore:*');
            CollectionDatabase::transaction(function() use($db,$key,$id,$action,$body) {
                if ($action==='collection_delete_version') {
                    $s=$db->prepare('SELECT version_type FROM collection_item_versions WHERE id=? AND slot_key=?'); $s->execute([$id,$key]);
                    if ($s->fetchColumn()==='named'&&empty($body['force_named'])) throw new \InvalidArgumentException('Named version requires explicit confirmation');
                    $db->prepare('DELETE FROM collection_item_versions WHERE id=? AND slot_key=?')->execute([$id,$key]);
                } else {
                    $name=trim((string)($body['name']??''));
                    $targetType=$body['target_type']??'named';
                    if ($action==='collection_promote' && !in_array($targetType,['commit','named'],true)) throw new \InvalidArgumentException('Invalid version type');
                    if (mb_strlen($name)>100 || ($action==='collection_promote' && $targetType==='named' && $name==='')) throw new \InvalidArgumentException('Version name must contain 1–100 characters');
                    if ($action==='collection_rename'&&($name===''||mb_strlen($name)>100)) throw new \InvalidArgumentException('Version name must contain 1–100 characters');
                    $type=$action==='collection_rename'?'named':$targetType;
                    $db->prepare('UPDATE collection_item_versions SET version_type=?,version_name=? WHERE id=? AND slot_key=?')->execute([$type,$type==='named'?$name:null,$id,$key]);
                }
            });
            return ['success'=>true];
        }
        if ($action === "collection_restore" && $method === "POST") {
            \NomadCMS\Middleware\CSRFMiddleware::validateForSession();
            AuthMiddleware::requirePermission("versions:restore:*");
            if (
                !AuthMiddleware::hasPermission("content:update:*", $key) &&
                (!AuthMiddleware::hasGrantedScope("content:update:own") ||
                    ContentDatabase::getOwner($key, $uid) !==
                        AuthMiddleware::getCurrentUser()->uuid)
            ) {
                AuthMiddleware::requirePermission("content:update:*");
            }
            $options = [
                "changed_by" => AuthMiddleware::getCurrentUser()->uuid,
                "owner_uuid" => AuthMiddleware::getCurrentUser()->uuid,
            ];
            foreach (
                ["expected_revision", "expected_schema_revision", "client_updated_at"]
                as $field
            ) {
                if (isset($body[$field])) {
                    $options[$field] = $body[$field];
                }
            }
            if (
                !isset($options["expected_schema_revision"]) ||
                (CollectionDatabase::row($key, $uid) &&
                    !isset($options["expected_revision"]))
            ) {
                throw new \InvalidArgumentException(
                    "Restore requires current item and schema revisions"
                );
            }
            $result = CollectionDatabase::restoreItem($id, $options);
            StaticCacheService::markCollectionDirty($key);
            SitemapService::markDirty();
            return $result;
        }
        throw new \InvalidArgumentException(
            "Unsupported collection history operation"
        );
    }
}
