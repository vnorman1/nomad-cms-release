<?php
/**
 * NOMAD CMS — optional standalone SPA metadata gateway.
 * Disabled by default, identical initial head for every User-Agent, no body rendering.
 * Remote cache uses bounded ETag revalidation and fails to the original shell instead of stale metadata.
 * @package NomadCMS\Services\Seo
 */
declare(strict_types=1);

namespace NomadCMS\Services\Seo;

/** Portable local/remote PHP adapter with no framework or session dependency. */
final class SpaGateway
{
    public function __construct(private readonly array $config, private readonly FileStore $files, private readonly ?HttpClient $http = null, private readonly ?\Closure $local = null, private readonly ?\Closure $clock = null)
    {
    }

    public function handle(string $uri, string $shell, string $method = 'GET', bool $draft = false): array
    {
        $result = ['status' => 200, 'headers' => ['Content-Type' => 'text/html; charset=utf-8', 'Accept-Ranges' => 'none'], 'body' => $shell];
        if (!in_array($method, ['GET', 'HEAD'], true)) {
            return ['status' => 405, 'headers' => ['Allow' => 'GET, HEAD', 'Cache-Control' => 'no-store'], 'body' => ''];
        }
        if (empty($this->config['enabled'])) {
            return $this->finish($result, $method);
        }
        $query = parse_url($uri, PHP_URL_QUERY) ?? '';
        parse_str($query, $parameters);
        if ($draft || isset($parameters['draftkey']) || isset($parameters['preview'])) {
            $result['headers']['Cache-Control'] = 'private, no-store';
            $result['headers']['X-Robots-Tag'] = 'noindex';
            return $this->finish($result, $method);
        }
        try {
            $path = Support::path(parse_url($uri, PHP_URL_PATH) ?: '/');
            $base = rtrim((string) ($this->config['basePath'] ?? ''), '/');
            if ($base !== '' && ($path === $base || str_starts_with($path, $base . '/'))) {
                $path = substr($path, strlen($base)) ?: '/';
            }
            foreach ($this->config['excludedPrefixes'] ?? ['/api/', '/nomad/', '/assets/'] as $prefix) {
                if ($path === rtrim($prefix, '/') || str_starts_with($path, $prefix)) {
                    $result['headers']['Cache-Control'] = 'no-store';
                    return $this->finish($result, $method);
                }
            }
            $metadata = $this->local ? ($this->local)($path) : $this->remote($path, hash('sha256', $shell));
            $result['body'] = HtmlHeadInjector::inject($shell, $metadata);
            $result['headers']['Cache-Control'] = 'public, max-age=' . min(60, max(0, (int) ($this->config['ttl'] ?? 60)));
            $result['headers']['X-Nomad-SEO'] = 'injected';
        } catch (SeoException $error) {
            if ($error->errorCode === 'route_unavailable' || ($error->status === 404 && ($error->details['registered'] ?? false))) {
                $result['status'] = 404;
                $result['headers']['X-Robots-Tag'] = 'noindex';
                $result['body'] = HtmlHeadInjector::inject($shell, ['title' => '', 'description' => '', 'canonical' => '', 'hreflang' => [], 'robots' => ['index' => false, 'follow' => false], 'og' => ['title' => '', 'description' => '', 'image' => '']]);
            }
            $result['headers']['Cache-Control'] = 'no-store';
            $result['headers']['X-Nomad-SEO'] = $error->errorCode;
            if ($error->errorCode !== 'route_unregistered') {
                error_log('[seo.gateway] ' . $error->errorCode);
            }
        } catch (\Throwable $error) {
            error_log('[seo.gateway] invalid_response');
            $result['headers']['Cache-Control'] = 'no-store';
            $result['headers']['X-Nomad-SEO'] = 'unavailable';
        }
        return $this->finish($result, $method);
    }

    private function finish(array $result, string $method): array
    {
        $result['headers']['Content-Length'] = (string) strlen($result['body']);
        if ($method === 'HEAD') {
            $result['body'] = '';
        }
        return $result;
    }

    private function remote(string $path, string $buildHash): array
    {
        if (!$this->http || empty($this->config['metaUrl'])) {
            throw new SeoException('gateway_configuration_required', 503);
        }
        $key = hash('sha256', $this->config['metaUrl'] . '|' . $path);
        return $this->files->locked('gateway:' . $key, function () use ($path, $buildHash, $key): array {
            $file = 'cache/gateway/' . $key . '.json';
            $cached = null;
            if (is_file($this->files->path($file)) && filesize($this->files->path($file)) <= 70000) {
                try {
                    $cached = Support::decode(file_get_contents($this->files->path($file)));
                } catch (\Throwable) {
                    $cached = null;
                }
            }
            $now = $this->clock ? ($this->clock)() : microtime(true);
            if ($cached && $cached['build'] === $buildHash && $now - $cached['time'] < min(60, (int) ($this->config['ttl'] ?? 60))) {
                return HtmlHeadInjector::validate($cached['metadata']);
            }
            $headers = $cached && $cached['build'] === $buildHash && !empty($cached['etag']) ? ['If-None-Match' => $cached['etag']] : [];
            $response = $this->http->get($this->config['metaUrl'] . '?path=' . rawurlencode($path), 65536, 2, 0, $headers);
            if ($response['status'] === 304 && $cached && $headers) {
                $metadata = HtmlHeadInjector::validate($cached['metadata']);
            } elseif ($response['status'] === 200) {
                $metadata = HtmlHeadInjector::validate(Support::decode($response['body']));
                if (($metadata['path'] ?? null) !== $path || empty($metadata['revision'])) {
                    throw new SeoException('invalid_metadata_response', 503);
                }
            } elseif ($response['status'] === 404) {
                $error = Support::decode($response['body']);
                throw new SeoException(($error['details']['registered'] ?? false) ? 'route_unavailable' : 'route_unregistered', 404, $error['details'] ?? []);
            } else {
                throw new SeoException('gateway_upstream_failed', 503);
            }
            $this->store($file, Support::json(['build' => $buildHash, 'time' => $now, 'etag' => $response['headers']['etag'] ?? $cached['etag'] ?? null, 'metadata' => $metadata]));
            return $metadata;
        });
    }

    /** Reserve bytes before writing, so an interrupted write can only overcount the budget. */
    private function store(string $file, string $bytes): void
    {
        $this->files->locked('gateway-quota', function () use ($file, $bytes): void {
            $quota = min(33554432, max(65536, (int) ($this->config['quotaBytes'] ?? 33554432)));
            $ledgerFile = 'cache/gateway-budget.json';
            $ledgerPath = $this->files->path($ledgerFile);
            $ledger = is_file($ledgerPath) ? Support::decode(file_get_contents($ledgerPath)) : ['bytes' => 0, 'cursor' => 0];
            $old = is_file($this->files->path($file)) ? filesize($this->files->path($file)) : 0;
            $needed = strlen($bytes) - $old;
            $iterator = new \DirectoryIterator($this->files->directory('cache/gateway'));
            $scanned = 0;
            try {
                $iterator->seek((int) $ledger['cursor']);
            } catch (\OutOfBoundsException) {
                $iterator->rewind();
                $ledger['cursor'] = 0;
            }
            while ($iterator->valid() && $scanned < 100 && $ledger['bytes'] + $needed > $quota) {
                if ($iterator->isFile() && $iterator->getPathname() !== $this->files->path($file) && str_ends_with($iterator->getFilename(), '.json')) {
                    $size = $iterator->getSize();
                    if (unlink($iterator->getPathname())) {
                        $ledger['bytes'] = max(0, $ledger['bytes'] - $size);
                    }
                }
                $iterator->next();
                $scanned++;
            }
            $ledger['cursor'] = $iterator->valid() ? $iterator->key() : 0;
            if ($ledger['bytes'] + $needed > $quota) {
                $this->files->write($ledgerFile, Support::json($ledger));
                return;
            }
            $ledger['bytes'] = max(0, $ledger['bytes'] + $needed);
            $this->files->write($ledgerFile, Support::json($ledger));
            $this->files->write($file, $bytes);
        });
    }
}
