<?php
/**
 * NOMAD CMS — atomic OG cache and render concurrency control.
 * A target/effective-language pair owns one file. Hash validation also repairs interrupted file/DB commits.
 * Open file handles pin the served version across concurrent atomic replacements.
 * @package NomadCMS\Services\Seo
 */
declare(strict_types=1);

namespace NomadCMS\Services\Seo;

use PDO;

/** Public image delivery, draft preview and generation-aware deletion. */
final class OgCache
{
    public function __construct(
        private readonly PDO $db,
        private readonly Metadata $metadata,
        private readonly TargetRegistry $targets,
        private readonly Templates $templates,
        private readonly Assets $assets,
        private readonly OgRenderer $renderer,
        private readonly Settings $settings,
        private readonly FileStore $files,
        private readonly \Closure $clock,
        private readonly ?OgContext $ogContext = null,
    ) {
    }

    public function image(string $id, string $locale, bool $force = false): array
    {
        return $this->savedImage($id, $locale, $force, true);
    }

    /** Authorized regeneration needs a published saved source, but not configured delivery origins. */
    public function regenerate(string $id, string $locale): array
    {
        return $this->savedImage($id, $locale, true, false);
    }

    private function savedImage(string $id, string $locale, bool $force, bool $requirePublicUrls): array
    {
        $public = $this->metadata->effective($id, $locale, true, [], false, $requirePublicUrls);
        $locale = $public['imageLocale'];
        if (\NomadCMS\Security\PanicModeService::isReadOnlyRequest()) {
            $cached = Support::one($this->db, 'SELECT * FROM seo_og_cache WHERE target_id=? AND locale=?', [$id, $locale]);
            $path = $cached ? $this->files->path($cached['file']) : null;
            if (!$path || !is_file($path) || hash_file('sha256', $path) !== $cached['file_hash']) {
                throw new SeoException('image_unavailable', 503);
            }
            // Published visibility was checked above. Serve the last verified
            // artifact without render locks, asset imports, or cache touches.
            return $this->delivery($path, $cached['file_hash'], $locale, true);
        }
        return $this->files->locked('og:' . $id . ':' . $locale, function () use ($id, $locale, $force, $requirePublicUrls): array {
            for ($attempt = 0; $attempt < 3; $attempt++) {
                $public = $this->metadata->effective($id, $locale, true, [], false, $requirePublicUrls);
                $meta = $this->metadata->effective($id, $locale, false, [], false);
                $settings = $this->settings->get()['data'];
                if ($meta['effectiveImageMode'] !== 'custom' && !$meta['templateId']) {
                    throw new SeoException('template_not_active', 503);
                }
                $template = $meta['imageMode'] === 'custom' ? ['version' => 1, 'width' => 1200, 'height' => 630, 'background' => ['color' => '#ffffff'], 'layers' => [['id' => 'custom', 'type' => 'image', 'assetId' => $meta['customAssetId'], 'x' => 0, 'y' => 0, 'width' => 1200, 'height' => 630, 'fit' => 'cover']]] : $this->templates->active($meta['templateId']);
                $context = $this->ogContext ? OgContext::rendererContext($this->ogContext->resolve($template, $id, $locale)) : $meta['context'];
                // First-use registration may have added a live CMS media reference without copying it.
                $resources = $this->renderer->resources($template, $context, $settings['defaultFontId']);
                $current = $this->metadata->effective($id, $locale, true, [], false, $requirePublicUrls);
                if ($public['revision'] === $current['revision']) {
                    break;
                }
                // Font imports persist their hash. Re-read all inputs after importing or a concurrent save.
                if ($attempt === 2) {
                    throw new SeoException('render_input_changed', 409);
                }
            }
            $hash = hash('sha256', Support::json(['renderer' => 3, 'revision' => $public['revision'], 'template' => $template, 'context' => $context, 'resources' => array_column($resources, 'hash', 'path')]));
            $cached = Support::one($this->db, 'SELECT * FROM seo_og_cache WHERE target_id=? AND locale=?', [$id, $locale]);
            $file = 'cache/og/' . $id . '_' . $locale . '.png';
            $path = $this->files->path($file);
            if (!$force && $cached && $cached['render_hash'] === $hash && is_file($path) && hash_file('sha256', $path) === $cached['file_hash']) {
                $time = (int) ($this->clock)();
                if ((int) $cached['last_used_at'] < $time - 3600) {
                    Support::query($this->db, 'UPDATE seo_og_cache SET last_used_at=? WHERE target_id=? AND locale=?', [$time, $id, $locale]);
                }
                return $this->delivery($path, $cached['file_hash'], $locale, true) + ['revision' => $public['revision'], 'template' => $meta['imageTemplate'], 'imageMode' => $meta['effectiveImageMode']];
            }
            $bytes = $this->renderSlot(fn () => $this->renderer->render($template, $context, $resources));
            $fileHash = hash('sha256', $bytes);
            $this->files->locked('og-quota', function () use ($id, $locale, $public, $file, $bytes, $hash, $fileHash, $requirePublicUrls): void {
                $this->reserve($id, $locale, strlen($bytes));
                Support::transaction($this->db, function () use ($id, $locale, $public, $file, $bytes, $hash, $fileHash, $requirePublicUrls): void {
                    $current = $this->metadata->effective($id, $locale, true, [], false, $requirePublicUrls);
                    if ($current['revision'] !== $public['revision']) {
                        throw new SeoException('render_input_changed', 409);
                    }
                    $target = $this->targets->get($id);
                    $this->files->write($file, $bytes);
                    $time = (int) ($this->clock)();
                    Support::query($this->db, 'INSERT INTO seo_og_cache(target_id,locale,file,render_hash,file_hash,generation,bytes,generated_at,last_used_at) VALUES (?,?,?,?,?,?,?,?,?) ON CONFLICT(target_id,locale) DO UPDATE SET file=excluded.file,render_hash=excluded.render_hash,file_hash=excluded.file_hash,generation=excluded.generation,bytes=excluded.bytes,generated_at=excluded.generated_at,last_used_at=excluded.last_used_at', [$id, $locale, $file, $hash, $fileHash, $target['generation'], strlen($bytes), $time, $time]);
                });
            });
            return $this->delivery($path, $fileHash, $locale, false) + ['revision' => $public['revision'], 'template' => $meta['imageTemplate'], 'imageMode' => $meta['effectiveImageMode']];
        });
    }

    /** Private image preview works for unpublished targets and never changes the public cache. */
    public function targetPreview(string $id, string $locale, array $changes): string
    {
        $meta = $this->metadata->effective($id, $locale, false, $changes, false);
        if ($meta['imageMode'] === 'inherit') {
            $meta = $this->metadata->effective($id, $meta['mainLocale'], false, [], false);
            $locale = $meta['mainLocale'];
            $changes = [];
        }
        if ($meta['effectiveImageMode'] === 'custom') {
            if (!$meta['customAssetId']) {
                throw new SeoException('custom_asset_required');
            }
            $document = ['version' => 1, 'width' => 1200, 'height' => 630, 'background' => ['color' => '#ffffff'], 'layers' => [['id' => 'custom', 'type' => 'image', 'assetId' => $meta['customAssetId'], 'x' => 0, 'y' => 0, 'width' => 1200, 'height' => 630, 'fit' => 'cover']]];
        } else {
            $document = $this->templates->active($meta['templateId']);
        }
        if ($this->ogContext) {
            $context = OgContext::rendererContext($this->ogContext->resolve($document, $id, $locale, $changes));
            return $this->renderPreview($document, $context);
        }
        return $this->preview($document, array_intersect_key($meta['context'], array_fill_keys(Templates::BINDINGS, true)));
    }

    private function reserve(string $id, string $locale, int $bytes): void
    {
        $quota = $this->settings->get()['data']['ogQuotaBytes'];
        $old = (int) (Support::one($this->db, 'SELECT bytes FROM seo_og_cache WHERE target_id=? AND locale=?', [$id, $locale])['bytes'] ?? 0);
        $total = (int) Support::one($this->db, 'SELECT COALESCE(SUM(bytes),0) AS bytes FROM seo_og_cache')['bytes'];
        if ($bytes > $quota) {
            throw new SeoException('og_quota_exceeded', 503);
        }
        $rows = Support::query($this->db, 'SELECT * FROM seo_og_cache WHERE NOT (target_id=? AND locale=?) ORDER BY last_used_at LIMIT 100', [$id, $locale])->fetchAll(PDO::FETCH_ASSOC);
        foreach ($rows as $row) {
            if ($total - $old + $bytes <= $quota) {
                return;
            }
            try {
                $this->files->locked('og:' . $row['target_id'] . ':' . $row['locale'], function () use ($row, &$total): void {
                    if (is_file($this->files->path($row['file']))) {
                        unlink($this->files->path($row['file']));
                    }
                    Support::query($this->db, 'DELETE FROM seo_og_cache WHERE target_id=? AND locale=?', [$row['target_id'], $row['locale']]);
                    $total -= (int) $row['bytes'];
                }, false);
            } catch (SeoException $error) {
                if ($error->errorCode !== 'render_busy') {
                    throw $error;
                }
            }
        }
        if ($total - $old + $bytes > $quota) {
            throw new SeoException('og_quota_busy', 503, ['retry_after' => 1]);
        }
    }

    private function delivery(string $path, string $hash, string $locale, bool $hit): array
    {
        $stream = fopen($path, 'rb');
        if (!$stream) {
            throw new SeoException('image_unavailable', 503);
        }
        return ['stream' => $stream, 'size' => fstat($stream)['size'], 'etag' => '"' . $hash . '"', 'locale' => $locale, 'cache_hit' => $hit];
    }

    private function renderSlot(callable $render): string
    {
        for ($slot = 0; $slot < 2; $slot++) {
            try {
                return $this->files->locked('global-render:' . $slot, $render, false);
            } catch (SeoException $error) {
                if ($error->errorCode !== 'render_busy') {
                    throw $error;
                }
            }
        }
        throw new SeoException('render_busy', 503, ['retry_after' => 1]);
    }

    public function preview(array $document, array $context, ?string $targetId = null, ?string $locale = null): string
    {
        $this->templates->validate($document, $targetId === null);
        foreach ($context as $field => $value) {
            if (!in_array($field, Templates::BINDINGS, true) || ($value !== null && !is_string($value))) {
                throw new SeoException('invalid_preview_context');
            }
            if (is_string($value)) {
                Support::text($value, 2000);
            }
        }
        if ($targetId !== null) {
            if (!$this->ogContext || $locale === null) {
                throw new SeoException('preview_target_required');
            }
            $context = OgContext::rendererContext($this->ogContext->resolve($document, $targetId, $locale));
        }
        return $this->renderPreview($document, $context);
    }

    private function renderPreview(array $document, array $context): string
    {
        $resources = $this->renderer->resources($document, $context, $this->settings->get()['data']['defaultFontId']);
        return $this->renderSlot(fn () => $this->renderer->render($document, $context, $resources));
    }

    public function deleteGeneration(string $id, int $generation): void
    {
        if ($this->db->inTransaction()) {
            throw new SeoException('commit_required', 409);
        }
        foreach (Support::query($this->db, 'SELECT locale FROM seo_og_cache WHERE target_id=?', [$id])->fetchAll(PDO::FETCH_ASSOC) as $entry) {
            $this->files->locked('og:' . $id . ':' . $entry['locale'], function () use ($id, $generation, $entry): void {
                Support::transaction($this->db, function () use ($id, $generation, $entry): void {
                    $target = $this->targets->get($id);
                    if ((int) $target['generation'] !== $generation || $target['public']) {
                        return;
                    }
                    $cache = Support::one($this->db, 'SELECT * FROM seo_og_cache WHERE target_id=? AND locale=?', [$id, $entry['locale']]);
                    if ($cache && is_file($this->files->path($cache['file']))) {
                        if (!unlink($this->files->path($cache['file']))) {
                            throw new SeoException('file_delete_failed', 503);
                        }
                    }
                    Support::query($this->db, 'DELETE FROM seo_og_cache WHERE target_id=? AND locale=?', [$id, $entry['locale']]);
                });
            });
        }
    }
}
