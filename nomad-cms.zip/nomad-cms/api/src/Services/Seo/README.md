# SEO & Social Studio — backend

PHP/SQLite modul, React SEO & Social Studio adminfelülettel. A szolgáltatások a `NomadCMS\Services\Seo` névtérben külön osztályokként működnek. A `SeoModule` konstruktorába külön PDO-kapcsolat, séma, óra, fájltár és HTTP-kliens adható. A HTTP-határ a meglévő hitelesítésből és RBAC-ból dolgozik, a célokhoz a slot-/tulajdonosi jogosultságot is ellenőrzi. A `bindLifecycle()` egy injektált modult köt ugyanazon PDO tárolási hookjaihoz.

Lépésenkénti beállítás és a képmappák magyarázata: [SEO & Social Studio használata](../../../../docs/seo-social-studio.md).

## Telepítés

Új CMS-telepítésnél az Installer futtatja a migrációt. Meglévő telepítésnél:

```bash
php api/bin/seo.php migrate
php api/bin/seo.php configure https://www.example.com https://cms.example.com/api
php api/bin/seo.php work 20
```

A migráció idempotens, nem fut kérésenként. Megőrzi a később visszavont szerepkör-jogosultságokat. A legacy `staticPages` egyszer importálódik, az eddigi nyelvi URL-ekkel. A collection-index tartós job/cursor alapján, legfeljebb 200 soros adagokban épül. A kész célok folyamatosan elérhetők, miközben a többi indexelése halad.

A publikus URL és az API URL külön konfiguráció: soha nem a kérés `Host` fejléce adja a canonical címet. Az URL-beállítások hiányakor a publikus kiszolgálás `503 public_urls_required` választ ad. A főnyelvet a CMS sémája, a route nyelvét a pontos regisztrált útvonal határozza meg.

A TaskManager `seo_studio` feladata explicit CLI/web cron alatt fut. A cron kizárólag indexelést, képimportot, sitemap-építést, statisztikát és cache-karbantartást végez; sem CMS-, sem élő auditot nem indít. Piggyback-kérés nem indít SEO-karbantartást. A meglévő worker/web-cron mellett a fenti SEO CLI is futtatható a tárhely időzítőjéből.

## Fontok és OG-sablonok

Nincs beépített font, Inter sem. A két kezdő sablon piszkozat: először fontot kell választani, majd aktiválni őket.

- `POST /api/admin/seo/fonts`: multipart `file`, opcionális `name`; statikus TTF, legfeljebb 2 MiB. SFNT-táblák, tartományok és próbamérés ellenőrzött; WOFF/OTF/variable TTF elutasított.
- Ugyanerre a végpontra JSON: `{"source":"google","family":"Roboto","weight":700,"italic":false}`. A regisztráció nem tölt le fájlt. Az első előnézet, aktiválás vagy hitelesített fontletöltés a kiválasztott statikus TTF-et importálja, majd a későbbi használat helyi fájlból történik. Inter Google-importja tiltott. CSS vagy letöltési hiba esetén `google_truetype_unavailable`/`google_font_unavailable` érkezik; feltöltött TTF továbbra is használható.
- A Google ajánlási lista a capabilities válaszban van. A listázás/telepítés nem indít fontletöltést. A szolgáltató aktuális CSS-válasza kötelezően TTF-re és statikus binárisra validált; nem próbál WOFF2-t GD-be tölteni. A Google-font rekord a szolgáltatói licencoldalra is hivatkozik.
- A settings `defaultFontId` mezője vagy a szövegréteg `fontId` mezője adja a fontot. Hiánya `font_required`; nincs néma helyettesítés.
- Hivatkozott font, asset vagy sablon törlése `409 resource_in_use`, felhasználási listával. Piszkozatok és mentett sablonverziók hivatkozásai is védettek.

Grafikai asset: a médiatár meglévő JPEG/PNG/WebP képére mutató hivatkozás, legfeljebb 50 MiB és 50 MP forrással. A fejlécvizsgálat és a hash-számítás nem olvassa a teljes kódolt fájlt a PHP memóriájába. Rendereléskor a GD közvetlenül a helyi fájlt dekódolja, majd legfeljebb 640 000 pixel/1200 px méretű rasztert tart meg, és a JPEG EXIF-forgatását ezen alkalmazza. A dekódolás átmeneti natív memóriaigénye a forrás felbontásával nő; a forráskorlát nem jelent 64 MiB memóriaigényt minden elfogadott képnél. A korábbi önálló assetazonosítók továbbra is kiszolgálhatók. Az assetválasz `mime`, egész `width` és `height` mezőt ad, privát fájlútvonalat nem. A hitelesített `/assets/{id}/file` az eredetit a tényleges formátummal szolgálja ki; a kész publikus OG továbbra is 1200 × 630 PNG.

JSON `{"media":"filename.png"}` élő hivatkozást regisztrál az `uploads` mappában lévő helyi médiára; privát assetfájlt nem másol és nem generál. Az eredeti fájl helye, neve és tartalma megmarad. A médiatár `?t=...` cache-busting paraméterét és a fragmentet a helyi képazonosítás figyelmen kívül hagyja, abszolút URL-nél az origin és az API mount továbbra is egyezzen a konfigurációval. A `media_id` mezővel rendelkező korábbi assetazonosítók is a forrás aktuális fájlját használják, függetlenül a korábbi privát másolat meglététől. A forrás hashét és méretét a feloldás élőben olvassa; ugyanazon fájlnév alatti csere érvényteleníti a metaadat-/OG-cache függőségeit. A forgatás és a méretkorlát rendereléskor, memóriában érvényesül, médiaeredetű normalizált fájl nem keletkezik.

A `POST /assets` kizárólag `{"media":"/api/uploads/image.png?t=..."}` hivatkozást fogad. Külön képfeltöltés és távoli URL-import `media_library_required` (422) hibát ad. A lista fájlnévenként egy hivatkozást mutat; a régi assetazonosítók kompatibilisek maradnak. A publikus renderer távoli képet nem kér le. A kész, 1200 × 630 OG-kép továbbra is külön, újragenerálható cachefájl.

A slot borítómezője assetazonosítót, helyi médiafájlnevet vagy a konfigurált CMS `/uploads/` URL-jét is tartalmazhatja. Helyi média feloldásakor csak élő hivatkozás regisztrálódik: a worker és a renderer sem másolja át a forrásképet a SEO privát assettárába. Mentés és publikus render nem tölt le távoli borítóképet. A Világos Termék kezdősablon jobb oldali, lekerekített borítózónát is tartalmaz.

Sablondokumentum:

```json
{
  "version": 1,
  "width": 1200,
  "height": 630,
  "background": {"color": "#101827"},
  "layers": [
    {
      "id": "headline",
      "type": "text",
      "binding": "title",
      "fontId": "uploaded-font-id",
      "x": 80, "y": 160, "width": 1040, "height": 300,
      "fontSize": 48, "minFontSize": 30,
      "maxLines": 3, "lineHeight": 1.2,
      "align": "left", "color": "#ffffff", "opacity": 1
    }
  ]
}
```

A `layers` tömb sorrendje a festési sorrend. Maximum 30 réteg. Típusok: `text`, `image`, `rectangle`, `roundedRectangle`, `ellipse`. Kép: `assetId` vagy `binding:"cover"`, `fit:"cover"|"contain"`, `focus:[0.5,0.5]`, `radius`. Fix szöveg: `text`. Engedett kötés: title, description, author, category, date, siteName, cover. A háttér `gradient:{"from":"#101827","to":"#334155","direction":"horizontal"}` alakban is megadható. A sablon adat, nem végrehajtható kód.

Mentés: `POST /templates`, majd `PUT /templates/{id}` `name` és `draft` mezőkkel. Aktiválás: `POST /templates/{id}/activate`. Az aktív verzió külön, változatlan JSON; piszkozatmentés nem módosítja a publikus képet. Előnézet: `POST /og/preview` `document` és `context` mezőkkel, közvetlen PNG és `private, no-store` válasszal.

## API-szerződés

Admin prefix: `/api/admin/seo`, emberi JWT/session hitelesítéssel; API-/draftkulcs nem adminjogosultság. Követelmény `seo:read:*`, `seo:update:*` vagy kezelő műveletnél `seo:manage:*`. Tartalomcélokon a meglévő `content:read/update:*` ellenőrzés slot-/item-kontextusban történik, valamint külön slot access szükséges. A globális előzmények és statisztika globális tartalomolvasást igényel; audit csak egyedi célra indítható. A szerepköri migráció viewerhez SEO-olvasást, editorhoz olvasást/frissítést ad; admin a meglévő wildcardot használja.

Módosítható rekordoknál a GET `revision` és `updated_at` értékét a következő kérésben `revision` és `client_updated_at` mezőként kell elküldeni. Új nyelvi dokumentum/binding revíziója 0, időbélyege üres. Revízió/időbélyeg eltérés: 409. Validáció: 422. Sessionös módosításokhoz a meglévő CSRF-header szükséges. A `data` objektum részleges módosítás; `null` és üres szöveg öröklést ad, `false` saját érték.

A revízió nemnegatív egész szám vagy annak decimális szövege; boolean, tört, tömb és hibás számszöveg `422 invalid_revision`. A kliensidőbélyeg szöveg legyen (`422 invalid_client_timestamp`). A nem üres JSON-kéréstörzs gyökere objektum, a query értékei skalárok. A metaadatdokumentum nyelve a CMS konfigurált nyelvei közül választható.

| Végpont | Metódus / tartalom |
|---|---|
| `/capabilities`, `/settings` | GET; settings PUT `{revision,client_updated_at,data}` |
| `/slots/{slot}` | GET/PUT mezőkötések, `urlPattern`, nyelvi `paths`, `templateId`, `auditProfile` |
| `/routes`, `/routes/{id}` | GET/POST, GET/PUT/PATCH/DELETE; `data:{label,mainLocale,active,paths,title,description,templateId,auditProfile}` |
| `/targets` | GET `cursor`, `limit<=100`, opcionális `slot`; jogosultság szerint szűrt oldal |
| `/targets/{id}/metadata?lang=hu` | GET dokumentum és effektív adatok; PATCH felülírások |
| `/targets/{id}/audit?lang=hu` | GET kizárólag mentett CMS/live eredmények; nullable eredmény és score, `cms_state`/`live_state`: `not_checked`, `stale`, `current` |
| `/targets/{id}/audit-runs?lang=hu` | POST `{live:boolean}` szinkron CMS, illetve CMS+élő ellenőrzés, terminális futáseredménnyel |
| `/targets/{id}/preview?lang=hu` | POST `{data}` nem mentett metaadat/kártyamodellek, auditszámítás nélkül |
| `/fonts`, `/fonts/{id}`, `/fonts/{id}/file` | GET/POST, GET/PATCH/DELETE, hitelesített GET TTF |
| `/assets`, `/assets/{id}` | GET/POST, GET/PATCH/DELETE |
| `/templates`, `/templates/{id}` | GET/POST, GET/PUT/PATCH/DELETE |
| `/templates/{id}/clone`, `/activate` | POST; clone `name`, activate revízió/időbélyeg |
| `/og/preview` | POST PNG, nem mentett rétegdokumentumból |
| `/targets/{id}/og/regenerate?lang=hu` | POST; `revision` itt a cél `generation` mezője, hozzá a cél `updated_at` |
| `/audit-runs`, `/audit-runs/{id}`, `/cancel` | GET lapozott előzmény, GET részlet, POST megszakítás; globális POST: `410 global_audits_retired` |
| `/social-stats` | GET `target`, `from`, `to`; legfeljebb 366 nap |
| `/robots/test` | POST `{path,agent}` szabályteszt |
| `/spa-gateway/package`, `/spa-gateway/check` | Kezelői GET ZIP, POST konfigurált publikus oldalellenőrzés |

Publikus: `GET|HEAD /api/seo/meta?path=/hu/news/article&lang=hu`, illetve `GET|HEAD /api/seo/og/{targetId}.png?lang=hu&v=…`. Metaadatválaszban strukturált title/description/canonical/hreflang/robots/OG/Twitter, escape-elt `head`, `sources`, `revision`, `etag`. Az ETag-es kérés 304-et ad. Nyelvi mismatch 422. Ismeretlen útvonal 404 `registered:false`; visszavont útvonal 404 `registered:true`. A draftkulcs nem jogosít publikus SEO-adatok vagy képek olvasására.

OG-módok: főnyelven alapból generated, más nyelven inherit. Generated saját nyelvi metaadatból készül; custom az adott nyelv hivatkozott médiaképét használja; inherit a főnyelv aktuális képét és fájlját használja. Canonical mindig a kért nyelv tényleges útvonala, nem a fallback nyelve.

## Audit, hálózat és karbantartás

CMS- és élő audit kizárólag az adott tartalom ellenőrzőgombjára számolódik. Megnyitás, szerkesztés, előnézet, mentés és cron nem számol auditot. A régi eredmények a forrásrevízió/szabályverzió vagy élő érvényesség változásakor elavultként jelennek meg; nem frissülnek automatikusan. A mentett tartalom ellenőrzése előtt a helyi módosításokat menteni kell. Az élő audit a regisztrált publikus URL nyers HTML-jét vizsgálja, és összeveti a CMS-adatokkal. Az auditprofil a titleMin/Max, descriptionMin/Max, minWords mezőkkel állítható. Alapajánlás 30–60, 70–160 karakter, cikkhez 300 szó; statikus route-nál minWords=0. Ezek szerkesztési ajánlások, nem Google-korlátok.

A `seo-audit-v2` szabályverzió a CMS-ben a mentett metaadatot, publikus URL-beállításokat, aktív képsablont és robots-szabályt ellenőrzi. Csak létező, kötött tartalomtörzsön végez blokkellenőrzést; nem talál ki H1-et a SEO-címből, és nem feltételezi, hogy a weboldal fejlécét a blokkok tartalmazzák. A szándékos noindex és a még nem publikált tartalom tájékoztatás, nem kritikus hiba. Az élő HTML-ben a CMS-sel ellentétes indexelési beállítás viszont hiba. Nem 200-as vagy nem HTML HTTP-válasznál a további HTML-szabályokat kihagyja; kliensoldali alkalmazáshéjnál egy renderelési jelzést ad, fiktív H1-/szószámhibák nélkül.

A pillanatkép `checked_at`, `url`, `counts:{error,warning,info}`, `checked` és `skipped` mezőkkel jelzi a ténylegesen ellenőrzött hatókört; `metrics:{words,characters}` csak feldolgozott tartalomnál van. Az előzmény `data.result.cms` és opcionális `data.result.live` alatt `{score,errors,warnings,info}` összesítést őriz az adott futásból. A futás `errors` mezője végrehajtási hibaszám, a SEO-találatok száma külön szerepel; későbbi ellenőrzés nem írja át a történeti összesítést.

100 pontról indul, kódonként egyszer error −10, warning −3. Piros 0–49, sárga 50–79, zöld 80–100; kritikus elérhetőségi vagy a kívánttal ellentétes indexelési hiba mindig piros. Friss élő eredménynél a minimum score az összesített érték. Elavult/hiányzó élő mérésnél a CMS-score ideiglenes. A `register()` egyedi szabályt is enged a PHP-szolgáltatásban.

HTTP: explicit host-allowlist, minden DNS IPv4/IPv6 cím vizsgálata, pinning, átirányításonként ismételt ellenőrzés, proxy tiltás, TLS-ellenőrzés. A DNS-feloldó a tárhely `/etc/resolv.conf` fájljában beállított rekurzív szervereket használja, a teljes HTTP-időkereten belül; CNAME-követése és válaszvalidációja korlátos. DNS-konfiguráció hiánya vagy csonkolt válasz explicit hiba, a gateway ilyenkor az eredeti shellre esik vissza. Audit maximum 8 s, 3 redirect, 2 MiB kibontott HTML. A DOM-memória védelmében 12 000 elem feletti HTML külön `html_complexity_limit` eredményt ad. Nem tölt külső entitást és nem futtat JavaScriptet.

Sitemap: a közös registry aktív/indexelhető útvonalai, deklarált nyelvi alternatívákkal, 50 000 URL / 50 MiB darabolással. A build XML-fájlba streamel, tartós cursorral és fájlpozícióval folytatható. A régi sitemap/robots URL-ek megmaradnak. A `?refresh=1` hitelesített/CSRF-védett kérés 202-es újraépítési sorba állítást ad. Hideg sitemapnál 503 + Retry-After érkezik, amíg a cron elkészíti.

Képcache: privát, stabil fájl, atomikus csere, hash és generáció, külön műveleti domainek 32 lockcsíkkal (összesen legfeljebb 297 lockállomány), két globális renderhely. Cache-találat nem használ GD-t. Kvóta alapból 256 MiB, régi fájlok eviktálhatók. Törlés/visszavonás tranzakcióban tiltja a publikusságot és tartós törlési jobot rögzít; fizikai törlés commit után, generáció-ellenőrzéssel történik. Az árva/90 napja nem kért képek karbantartáskor törölhetők. A fontok és az assetek megmaradnak, a kép újragenerálható.

Social: verziózott Facebook/Slack/Twitter/LinkedIn UA-besorolás; külön GET, 304 és HEAD. Spoolból idempotens napi aggregálás `massive.sqlite`-ba. Előnézet és saját audit nem növeli. A mutató platformnak besorolt backend-kérésszám, nem közvetlen megosztásszám. IP és teljes UA nincs eltárolva.

## SPA, fájlvédelem és mentés

A letölthető ZIP külön PHP-adapter, konfigurációmintával, Apache/Nginx útmutatóval és saját osztálybetöltéssel. Alapból kikapcsolt; helyben direkt publikus szolgáltatás, távolban 60 s ETag-cache, 2 s / 64 KiB lekérési korlát, 32 MiB cachekvóta működik. Nincs User-Agent szerinti HTML vagy Vary. Hibánál eredeti shell + no-store, visszavont route-nál 404/noindex, ismeretlen route-nál meglévő SPA-fallback. CSP, nonce, asset- és script-hivatkozások megmaradnak. Range figyelmen kívül hagyva teljes 200-as HTML érkezik, a tagek a charset után.

A gateway cache-e a publikus gyökéren kívül legyen. A CMS `storage/seo` és `storage/og` könyvtárak közvetlen webes elérése tiltott az Apache/dev-router szabályokban. Nginxen az API-vhostban külön `location ^~ /api/storage/seo/ { deny all; }` és `/api/storage/og/` tiltás szükséges, a tényleges mountnak megfelelően.

A meglévő BackupService a privát `storage/seo/fonts`, `assets` és marker fájlokat, valamint a három SQLite-adatbázist menti. A `cache` nevű alkönyvtárak kizártak: OG/gateway/sitemap regenerálható. Visszaállítás után migráció + worker újraépíti az index/cache állapotot. Hiányzó OG-cache fájl automatikusan regenerálódik, a font/asset hiánya explicit hibát ad.

Médiához kötött assetnél a kiszolgálás az eredeti `uploads` fájlt olvassa; a régi privát másolat hiánya nem `asset_file_missing` hiba. Közvetlenül feltöltött, hiányzó privát assetfájlnál a kiszolgálás azonos SHA-256 hashű, sértetlen privát példányból próbálja helyreállítani a fájlt. Ennek hiányában az `asset_file_missing` részletei új kép médiatárba feltöltését és hivatkozását jelölik javításként.

## Saját tesztek és mért eredmények

A gyökérbeli, kizárólag backend HTTP e2e tesztcsomag minden kategóriához külön ideiglenes adatbázist és loopback PHP-szervert használ. A frontend csomag a valódi SPA-t Chromium alatt, determinisztikus API-válaszokkal ellenőrzi; az éles API-t nem hívja.

```bash
php tests/seosocial/run.php
php tests/seosocial/run.php images-storage templates-rendering
npm --prefix frontend run test:seosocial:e2e
```

Részletes backend kategóriák: [tests/seosocial](../../../../tests/seosocial/README.md).

```bash
php api/tests/SeoStudioTest.php
php api/tests/SeoStudioHttpTest.php
php api/tests/SeoStudioScaleTest.php 100000
php api/tests/SeoStudioBenchmark.php
php api/tests/CollectionRowsTest.php
php api/tests/CollectionDiffRoundtripTest.php
```

A tesztek saját ideiglenes adatbázisokat/fájltárakat használnak. A font a tesztben feltöltést szimuláló, már jelen lévő vendor fixture; éles alapértelmezésként nem használjuk. A Google-/CMS-hálózat determinisztikus tesztadapterrel ellenőrzött, internetes fontletöltés nincs a tesztekben.

Végleges ellenőrzés: 124 funkcionális, 211 HTTP-/jogosultsági ellenőrzés, 35 collection regressziós assertion és 11 diff-roundtrip eset sikeres.

Mérés PHP 8.4.16 / macOS alatt: 100 000 cél → 200 005 publikus nyelvi URL, 5 sitemap, 68,178 s index és 5,479 s sitemap, 8 MiB PHP-csúcs. A munka több cron-turnusban ugyanazzal a cursorral folytatható.

Lokális benchmark végleges futása: hideg render P50/P95 31,533/55,193 ms; OG cache 0,783/1,150 ms; helyi gateway 0,260/0,350 ms; távoli adapter friss helyi cache-e 0,134/0,215 ms. 2 MiB HTML-audit 220,381/225,960 ms. Elkülönített render/audit-worker: 60 211 200 byte natív RSS, 8 388 608 byte PHP-csúcs. A teljes tesztadat-generáló/importáló benchmark-folyamat 95 961 088 byte RSS-t használt; ezt külön jelentjük. A tárhely és a valódi távoli hálózat P50/P95 értékeit telepítés után kell mérni.

A Google CSS-endpointot a renderer User-Agentjével külön élő próbában is ellenőriztük: Roboto 700 statikus TTF URL-t adott, a 61 120 byte-os ideiglenes font a modul bináris validációján átment. A végleges DNS-/HTTP-kliens élő CSS-próbája 360 ms alatt sikerült. Ez sem kerül a projektbe vagy az alapértelmezett sablonba.

A React adminfelület része a modulnak; a kliens SDK és API Playground-katalógus a külön integrációs szerződéseket használja. Az API és a PHP-adapter szerződései ebben a modulban már elérhetők.

Források: [Google Fonts CSS API](https://developers.google.com/fonts/docs/getting_started), [Google Fonts fájlok és statikus változatok](https://developers.google.com/fonts/docs/developer_api), [Google JavaScript SEO](https://developers.google.com/search/docs/crawling-indexing/javascript/dynamic-rendering), [snippet-ajánlások](https://developers.google.com/search/docs/appearance/snippet), [sitemap protokollkorlátok](https://developers.google.com/search/docs/crawling-indexing/sitemaps/build-sitemap).

## Studio sémamezők és keresés

A v1 OG-dokumentum opcionális `schemaSlotKey` mezővel egy tartalomcsoporthoz köthető. A szöveg-/képréteg `fieldPath` forrást használhat a szemantikus `binding` helyett. A szövegréteg `textTransform` értékei: `none`, `uppercase`, `lowercase`, `capitalize`; a szerver a tördelés előtt alkalmazza, a tartalmat nem módosítja. Az általános sablonok továbbra is több tartalomcsoporthoz használhatók; a közvetlen mezőkötéses sablon csak a saját sémájához rendelhető.

A capabilities `slots[].bindingFields` leírása `path`, `label`, `type`, `kind` és `localized` mezőket tartalmaz. A `POST /og/context` `{document,targetId,locale}` bemenetre kizárólag a hivatkozott sémamezők `fields` értékeit, szemantikus `context` értékeit és `warnings` listáját adja; a privát `/og/preview` ugyanígy feloldja a cél mezőit. A lokalizált JSON-gyökér feloldása megelőzi a belső útvonal bejárását. A képek normalizált helyi assetet használnak, a publikus renderer nem tölt le távoli képet.

A sablon-/font-/assetlisták `q`, `cursor`, `limit` paramétereket támogatnak; a névkeresés FTS5 `unicode61 remove_diacritics 2` indexet használ. Sablonnál `slot` a kompatibilis sémára, `active=1` az aktív sablonokra szűr. A listaválasz összefoglaló, nem tartalmaz teljes `draft` dokumentumot. A thumbnail és szerkesztés a részletvégpontot használja.

A kifejezetten futtatott idempotens migráció indexeli a meglévő erőforrásokat, törli a régi `cms_audit` jobokat és `audit_mode_changed` indokkal lezárja a régi függő auditfutásokat. A mentett auditok és történeti futások megmaradnak. A migráció nem fut közönséges GET kérésből.
