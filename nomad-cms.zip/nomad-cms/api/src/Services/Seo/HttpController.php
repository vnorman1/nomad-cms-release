<?php
/**
 * NOMAD CMS — SEO HTTP dispatch and authorization boundary.
 * Thin handlers enforce methods, fresh user state, contextual slot/ownership grants and session CSRF.
 * Public metadata is anonymous-only; drafts and administrative binaries never enter public caches.
 * @package NomadCMS\Services\Seo
 */
declare(strict_types=1);

namespace NomadCMS\Services\Seo;

use NomadCMS\Database\AuthDatabase;
use NomadCMS\Middleware\AuthMiddleware;
use NomadCMS\Middleware\CSRFMiddleware;

/** Backend-only API; public and administrative dispatch cannot be mixed. */
final class HttpController
{
    private const METHODS = [
        'capabilities' => ['GET'], 'settings' => ['GET', 'PUT'], 'slot' => ['GET', 'PUT'],
        'routes' => ['GET', 'POST'], 'route' => ['GET', 'PUT', 'PATCH', 'DELETE'],
        'sitemap_rebuild' => ['POST'], 'overview' => ['GET'], 'health' => ['GET'], 'resolve' => ['GET'], 'target_og_preview' => ['POST'], 'target_run' => ['POST'], 'asset_file' => ['GET'], 'template_usages' => ['GET'],
        'targets' => ['GET'], 'metadata' => ['GET', 'PATCH'], 'audit' => ['GET'], 'preview' => ['POST'],
        'fonts' => ['GET', 'POST'], 'font' => ['GET', 'PATCH', 'DELETE'], 'font_file' => ['GET'],
        'assets' => ['GET', 'POST'], 'asset' => ['GET', 'PATCH', 'DELETE'],
        'templates' => ['GET', 'POST'], 'template' => ['GET', 'PUT', 'PATCH', 'DELETE'],
        'clone' => ['POST'], 'activate' => ['POST'], 'og_preview' => ['POST'], 'og_context' => ['POST'], 'regenerate' => ['POST'],
        'audit_runs' => ['GET', 'POST'], 'audit_run' => ['GET'], 'cancel_run' => ['POST'],
        'social_stats' => ['GET'], 'gateway_package' => ['GET'], 'gateway_check' => ['POST'], 'robots_test' => ['POST'],
    ];

    public static function admin(): void
    {
        self::guard(function (): void {
            self::validateQuery();
            $action = (string) ($_GET['_seo_action'] ?? '');
            $method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
            self::method(self::METHODS[$action] ?? [], $method);
            $module = SeoModule::production($action === 'social_stats');
            $user = AuthMiddleware::requireAuth();
            if (($user->source ?? '') === 'api_key') {
                throw new SeoException('human_session_required', 403);
            }
            $fresh = Support::one(AuthDatabase::getInstance(false), 'SELECT role_slug,role,is_admin,is_new_user,locked_until FROM users WHERE uuid=?', [$user->uuid ?? '']);
            if (!$fresh || $fresh['is_new_user'] || ($fresh['locked_until'] !== null && strtotime($fresh['locked_until']) > time())) {
                throw new SeoException('unauthorized', 401);
            }
            foreach (['role_slug', 'role', 'is_admin'] as $field) {
                $user->$field = $fresh[$field];
            }
            $manage = in_array($action, ['settings', 'slot', 'routes', 'route', 'fonts', 'font', 'font_file', 'assets', 'asset', 'templates', 'template', 'clone', 'activate', 'gateway_package', 'gateway_check', 'robots_test', 'health', 'template_usages', 'sitemap_rebuild'], true);
            AuthMiddleware::requirePermission('seo:' . ($manage && ($method !== 'GET' || str_starts_with($action, 'gateway_') || in_array($action, ['health', 'template_usages'], true)) ? 'manage' : ($method === 'GET' || in_array($action, ['preview', 'target_og_preview', 'og_preview', 'og_context'], true) ? 'read' : 'update')) . ':*');
            if ($method !== 'GET') {
                CSRFMiddleware::validateForSession();
            }
            if (session_status() === PHP_SESSION_ACTIVE) {
                session_write_close();
            }
            $id = (string) ($_GET['id'] ?? '');
            $defaultLocale = in_array($action, ['metadata', 'audit', 'preview', 'regenerate', 'target_og_preview', 'target_run'], true) ? $module->targets->get($id)['main_locale'] : $module->targets->mainLocale();
            $locale = Support::locale((string) ($_GET['lang'] ?? $defaultLocale));
            if (in_array($action, ['metadata', 'audit', 'preview', 'regenerate', 'target_og_preview', 'target_run'], true)) {
                self::targetAccess($module->targets->get($id), $method === 'GET' || in_array($action, ['preview', 'target_og_preview'], true) ? 'read' : 'update');
            }
            if ($action === 'slot') {
                AuthMiddleware::requireSlotAccess((string) ($_GET['slot'] ?? ''));
                AuthMiddleware::requirePermission('content:' . ($method === 'GET' ? 'read' : 'update') . ':*', (string) $_GET['slot']);
            }
            $multipart = in_array($action, ['fonts', 'assets'], true) && isset($_FILES['file']);
            $input = $method === 'GET' || $multipart ? [] : self::body();
            $result = self::execute($module, $action, $method, $id, $locale, $input, (string) $user->uuid);
            if (isset($result['png'])) {
                header('Content-Type: image/png');
                header('Cache-Control: private, no-store');
                echo $result['png'];
            } elseif (isset($result['download'])) {
                header('Content-Type: ' . $result['mime']);
                header('Cache-Control: private, no-store');
                header('X-Content-Type-Options: nosniff');
                header('Content-Disposition: attachment; filename="' . $result['name'] . '"');
                readfile($result['download']);
            } else {
                self::json($result, 'private, no-store');
            }
            $module->maintenance->deletions(microtime(true) + 0.1);
        });
    }

    private static function execute(SeoModule $module, string $action, string $method, string $id, string $locale, array $input, string $actor): array
    {
        $cursor = Support::text((string) ($_GET['cursor'] ?? ''), 2048);
        $limit = min(100, max(1, (int) ($_GET['limit'] ?? 50)));
        switch ($action) {
            case 'capabilities':
                $capabilities = $module->capabilities();
                $capabilities['permissions'] = ['manage' => AuthMiddleware::hasPermission('seo:manage:*'), 'update' => AuthMiddleware::hasPermission('seo:update:*'), 'globalRead' => AuthMiddleware::hasPermission('content:read:*')];
                $capabilities['slots'] = [];
                foreach ($module->targets->schema['slots'] ?? [] as $key => $definition) {
                    $user = AuthMiddleware::getCurrentUser();
                    if (($definition['type'] ?? '') !== 'massive' && ($user->is_admin || \NomadCMS\Services\RBACService::canAccessSlot($user, $key))) {
                        $capabilities['slots'][] = ['key' => $key, 'label' => $definition['label'] ?? $key, 'type' => $definition['type'] ?? 'object', 'fields' => array_map(static fn ($field) => ['id' => $field['id'], 'label' => $field['label'] ?? $field['id'], 'type' => $field['type'], 'localized' => (bool) ($field['localized'] ?? false)], $definition['fields'] ?? []), 'bindingFields' => $module->schemaFields->fields($key)];
                    }
                }
                return $capabilities;
            case 'settings':
                if ($method === 'GET') {
                    return $module->settings->get();
                }
                $before = $module->settings->get()['data'];
                $result = $module->settings->save($input);
                if ($before['publicSiteUrl'] !== $result['data']['publicSiteUrl'] || $before['apiBaseUrl'] !== $result['data']['apiBaseUrl']) {
                    $module->site->invalidate();
                }
                return $result;
            case 'slot':
                $slot = (string) $_GET['slot'];
                return $method === 'GET' ? $module->targets->binding($slot) : $module->targets->saveBinding($slot, $input);
            case 'routes':
                if ($method === 'GET') {
                    $page = $module->targets->list($cursor, $limit, '');
                    $page['items'] = array_map(fn ($target) => $module->targets->route($target['id']), $page['items']);
                    return $page;
                }
                $result = $module->targets->route(null, $input);
                $module->site->invalidate();
                return $result;
            case 'route':
                if ($method === 'GET') {
                    return $module->targets->route($id);
                }
                if ($method === 'DELETE') {
                    $module->targets->deleteRoute($id, $input);
                    $result = ['deleted' => true];
                } else {
                    $result = $module->targets->route($id, $input);
                }
                $module->site->invalidate();
                return $result;
            case 'targets':
                $page = $module->admin->page($_GET, self::readPredicate($module));
                $page['items'] = array_map(static function ($target) {
                    $target['can_update'] = AuthMiddleware::hasPermission('seo:update:*') && ($target['kind'] === 'route' || AuthMiddleware::hasPermission('content:update:*', $target['slot_key'], $target['item_uid'] ?: null));
                    return $target;
                }, $page['items']);
                return $page;
            case 'overview':
                return $module->admin->overview(self::readPredicate($module));
            case 'sitemap_rebuild':
                $module->site->invalidate();
                http_response_code(202);
                return ['queued' => true];
            case 'health':
                return $module->admin->health();
            case 'resolve':
                $slot = (string) ($_GET['slot'] ?? '');
                $definition = $module->targets->schema['slots'][$slot] ?? null;
                $kind = $definition === null ? '' : ($definition['type'] ?? 'object');
                if (!in_array($kind, ['object', 'list', 'collection'], true)) {
                    throw new SeoException('slot_not_found', 404);
                }
                $uid = $kind === 'object' ? '' : Support::text((string) ($_GET['item'] ?? ''), 200);
                if ($kind !== 'object' && $uid === '') {
                    throw new SeoException('item_required');
                }
                $reference = ['kind' => $kind, 'slot_key' => $slot, 'item_uid' => $uid];
                self::targetAccess($reference, 'read');
                if ($module->targets->source($reference, false) === null) {
                    // A declared singleton has no item identity until its first explicit save.
                    // Keep GET read-only for content and let the drawer offer that save.
                    if ($kind === 'object') {
                        return ['state' => 'unsaved'];
                    }
                    throw new SeoException('target_not_found', 404);
                }
                $module->targets->synchronize($slot, $kind === 'collection' ? $uid : null);
                $target = Support::one($module->db, 'SELECT * FROM seo_targets WHERE kind=? AND slot_key=? AND item_uid=?', [$kind, $slot, $uid]);
                return ['state' => 'ready', 'target' => $target];
            case 'target_og_preview':
                return ['png' => $module->og->targetPreview($id, $locale, $input['data'] ?? [])];
            case 'target_run':
                return $module->maintenance->startRun($input, $id, $locale);
            case 'asset_file':
                $path = $module->assets->imagePath($id);
                $mime = Assets::imageMime($path);
                $extension = match ($mime) {
                    'image/jpeg' => 'jpg',
                    'image/webp' => 'webp',
                    default => 'png',
                };
                return ['download' => $path, 'mime' => $mime, 'name' => $id . '.' . $extension];
            case 'template_usages':
                return self::templateUsages($module, $id, $cursor, $limit);
            case 'metadata':
                if ($method === 'GET') {
                    $target = $module->targets->get($id);
                    $target['generation'] = (int) $target['generation'];
                    $target['can_update'] = AuthMiddleware::hasPermission('seo:update:*') && ($target['kind'] === 'route' || AuthMiddleware::hasPermission('content:update:*', $target['slot_key'], $target['item_uid'] ?: null));
                    return ['document' => $module->metadata->document($id, $locale), 'effective' => $module->metadata->effective($id, $locale, false, [], false), 'target' => $target];
                }
                $result = $module->metadata->save($id, $locale, $input, $actor);
                $module->site->invalidate();
                return $result;
            case 'audit':
                return $module->audit->result($id, $locale);
            case 'preview':
                return $module->metadata->preview($id, $locale, $input['data'] ?? []);
            case 'fonts':
            case 'assets':
                $type = $action === 'fonts' ? 'font' : 'asset';
                if ($method === 'GET') {
                    return $module->assets->list($type, $cursor, $limit, (string) ($_GET['q'] ?? ''));
                }
                if ($type === 'font' && ($input['source'] ?? '') === 'google') {
                    return $module->assets->googleFont($input['family'] ?? '', (int) ($input['weight'] ?? 700), (bool) ($input['italic'] ?? false));
                }
                if ($type === 'asset' && isset($input['media'])) {
                    return self::importMedia($module, $input['media']);
                }
                if ($type === 'asset') {
                    throw new SeoException('media_library_required', 422);
                }
                $bytes = self::upload(2097152);
                $name = (string) ($_POST['name'] ?? $_FILES['file']['name'] ?? '');
                return $module->assets->uploadFont($name, $bytes);
            case 'font':
            case 'asset':
                if ($method === 'GET') {
                    return $module->assets->publicResource($module->assets->get($action, $id)) + ['usages' => $module->assets->usages($action, $id)];
                }
                if ($method === 'DELETE') {
                    $module->assets->delete($action, $id, $input);
                    return ['deleted' => true];
                }
                return $module->assets->rename($action, $id, $input);
            case 'font_file':
                return ['download' => $module->assets->fontPath($id), 'mime' => 'font/ttf', 'name' => $id . '.ttf'];
            case 'templates':
                return $method === 'GET' ? $module->templates->list($cursor, $limit, (string) ($_GET['q'] ?? ''), isset($_GET['slot']) ? (string) $_GET['slot'] : null, ($_GET['active'] ?? '') === '1') : $module->templates->save(null, $input);
            case 'template':
                if ($method === 'DELETE') {
                    $module->templates->delete($id, $input);
                    return ['deleted' => true];
                }
                return $method === 'GET' ? $module->templates->get($id) : $module->templates->save($id, $input);
            case 'clone':
                Support::version($module->templates->get($id), $input);
                return $module->templates->clone($id, $input['name'] ?? 'Copy');
            case 'activate':
                return $module->templates->activate($id, $input, $module->settings->get()['data']['defaultFontId']);
            case 'og_preview':
            case 'og_context':
                $targetId = isset($input['targetId']) ? Support::text($input['targetId'], 200) : null;
                $previewLocale = Support::locale((string) ($input['locale'] ?? $module->targets->mainLocale()));
                if ($targetId !== null) {
                    self::targetAccess($module->targets->get($targetId), 'read');
                }
                if ($action === 'og_context') {
                    if ($targetId === null) {
                        throw new SeoException('preview_target_required');
                    }
                    $module->templates->validate($input['document'] ?? [], false);
                    return $module->ogContext->resolve($input['document'], $targetId, $previewLocale);
                }
                return ['png' => $module->og->preview($input['document'] ?? [], $input['context'] ?? [], $targetId, $previewLocale)];
            case 'regenerate':
                $target = $module->targets->get($id);
                Support::version(['revision' => $target['generation'], 'updated_at' => $target['updated_at']], $input);
                $image = $module->og->regenerate($id, $locale);
                fclose($image['stream']);
                unset($image['stream']);
                return $image;
            case 'audit_runs':
                AuthMiddleware::requirePermission('content:read:*');
                if ($method === 'POST') {
                    throw new SeoException('global_audits_retired', 410);
                }
                return self::auditHistoryPage($module, $cursor, $limit);
            case 'audit_run':
            case 'cancel_run':
                $run = $module->maintenance->run($id);
                if (isset($run['data']['target'])) {
                    self::targetAccess($module->targets->get($run['data']['target']), $action === 'audit_run' ? 'read' : 'update');
                } else {
                    AuthMiddleware::requirePermission('content:read:*');
                }
                return $action === 'audit_run' ? $module->maintenance->run($id) : $module->maintenance->cancel($id, $input);
            case 'social_stats':
                $target = isset($_GET['target']) ? (string) $_GET['target'] : null;
                if ($target) {
                    self::targetAccess($module->targets->get($target), 'read');
                } else {
                    AuthMiddleware::requirePermission('content:read:*');
                }
                $statistics = $module->social->stats($target, (string) ($_GET['from'] ?? gmdate('Y-m-d', time() - 30 * 86400)), (string) ($_GET['to'] ?? gmdate('Y-m-d')));
                $statistics['targets'] = array_values(array_filter($statistics['targets'], static function ($entry) use ($module): bool {
                    $targetRecord = Support::one($module->db, 'SELECT * FROM seo_targets WHERE id=?', [$entry['target_id']]);
                    return $targetRecord !== null && self::canRead($targetRecord);
                }));
                return $statistics;
            case 'gateway_package':
                return ['download' => (new GatewayPackage($module))->build(), 'mime' => 'application/zip', 'name' => 'nomad-spa-gateway.zip'];
            case 'gateway_check':
                return (new GatewayPackage($module))->check();
            case 'robots_test':
                return ['allowed' => $module->site->robotsAllows(Support::path($input['path'] ?? '/'), Support::text($input['agent'] ?? '*', 200))];
        }
        throw new SeoException('not_found', 404);
    }

    /** SQL access scope exactly mirrors content ownership and slot-access checks. */
    private static function readPredicate(SeoModule $module): array
    {
        $user = AuthMiddleware::getCurrentUser();
        if (!empty($user->is_admin)) {
            return ['1=1', []];
        }
        $slots = [];
        foreach ($module->targets->schema['slots'] ?? [] as $slot => $definition) {
            if (\NomadCMS\Services\RBACService::canAccessSlot($user, $slot)) {
                $slots[] = $slot;
            }
        }
        if (!$slots) {
            return ["t.kind='route'", []];
        }
        $scope = 't.slot_key IN (' . implode(',', array_fill(0, count($slots), '?')) . ')';
        $parameters = $slots;
        if (!AuthMiddleware::hasPermission('content:read:*')) {
            if (!AuthMiddleware::hasGrantedScope('content:read:own')) {
                return ["t.kind='route'", []];
            }
            $scope .= ' AND EXISTS (SELECT 1 FROM slot_ownership o WHERE o.slot_key=t.slot_key AND ((t.item_uid=\'\' AND o.item_uid IS NULL) OR o.item_uid=t.item_uid) AND o.owner_uuid=?)';
            $parameters[] = $user->uuid;
        }
        return ["(t.kind='route' OR (" . $scope . '))', $parameters];
    }

    /** Join bounded history summaries without per-row requests or running fresh audits. */
    private static function auditHistoryPage(SeoModule $module, string $cursor, int $limit): array
    {
        [$scope, $scopeParameters] = self::readPredicate($module);
        $sql = "SELECT r.*,t.id AS summary_id,t.slot_key AS summary_slot_key,t.kind AS summary_kind,
                p.title AS summary_title,p.path AS summary_path
            FROM seo_audit_runs r
            LEFT JOIN seo_targets t ON t.id=json_extract(r.data,'$.target')
            LEFT JOIN seo_admin_projection p ON p.target_id=t.id
                AND p.locale=COALESCE(json_extract(r.data,'$.locale'),t.main_locale)
            WHERE r.id>? AND (t.id IS NULL OR (" . $scope . '))
            ORDER BY r.id LIMIT CAST(? AS INTEGER)';
        $rows = Support::query($module->db, $sql, [$cursor, ...$scopeParameters, $limit + 1])->fetchAll(\PDO::FETCH_ASSOC);
        $more = count($rows) > $limit;
        if ($more) {
            array_pop($rows);
        }
        $items = array_map(static function (array $row): array {
            $summary = $row['summary_id'] === null ? null : [
                'title' => $row['summary_title'] ?? '',
                'path' => $row['summary_path'],
                'slot_key' => $row['summary_slot_key'],
                'kind' => $row['summary_kind'],
            ];
            foreach (['summary_id', 'summary_title', 'summary_path', 'summary_slot_key', 'summary_kind'] as $field) {
                unset($row[$field]);
            }
            $row['data'] = Support::decode($row['data']);
            $row['revision'] = (int) $row['revision'];
            $row['processed'] = (int) $row['processed'];
            $row['errors'] = (int) $row['errors'];
            $row['targetSummary'] = $summary;
            return $row;
        }, $rows);

        return ['items' => $items, 'next_cursor' => $more ? end($rows)['id'] : null];
    }

    private static function templateUsages(SeoModule $module, string $id, string $cursor, int $limit): array
    {
        $module->templates->get($id);
        $items = [];
        $total = 0;
        $statement = Support::query($module->db, "SELECT owner_type,owner_id FROM seo_asset_usages WHERE type='template' AND resource_id=? ORDER BY owner_type,owner_id", [$id]);
        while ($entry = $statement->fetch(\PDO::FETCH_ASSOC)) {
            $visible = $entry['owner_type'] === 'settings';
            if ($entry['owner_type'] === 'slot') {
                $user = AuthMiddleware::getCurrentUser();
                $visible = ($user->is_admin || \NomadCMS\Services\RBACService::canAccessSlot($user, $entry['owner_id'])) && AuthMiddleware::hasPermission('content:read:*', $entry['owner_id']);
            } elseif (in_array($entry['owner_type'], ['document', 'route'], true)) {
                $target = Support::one($module->db, 'SELECT * FROM seo_targets WHERE id=?', [explode(':', $entry['owner_id'], 2)[0]]);
                $visible = $target && self::canRead($target);
            }
            if ($visible) {
                $total++;
                $key = $entry['owner_type'] . ':' . $entry['owner_id'];
                if ($key > $cursor && count($items) < $limit + 1) {
                    $entry['label'] = $entry['owner_id'];
                    if ($entry['owner_type'] === 'settings') {
                        $entry['label'] = 'Site defaults';
                    } elseif (in_array($entry['owner_type'], ['document', 'route'], true)) {
                        $parts = explode(':', $entry['owner_id'], 2);
                        $entry['target_id'] = $parts[0];
                        $entry['locale'] = $parts[1] ?? $module->targets->get($parts[0])['main_locale'];
                        $projection = Support::one($module->db, 'SELECT title,path FROM seo_admin_projection WHERE target_id=? AND locale=?', [$parts[0], $entry['locale']]);
                        $entry['label'] = $projection['title'] ?? ($entry['owner_type'] === 'route' ? $module->targets->route($parts[0])['data']['label'] : $parts[0]);
                        $entry['path'] = $projection['path'] ?? null;
                    }
                    $items[] = $entry + ['cursor' => $key];
                }
            }
        }
        $more = count($items) > $limit;
        if ($more) {
            array_pop($items);
        }
        return ['items' => $items, 'total' => $total, 'next_cursor' => $more ? end($items)['cursor'] : null];
    }

    private static function importMedia(SeoModule $module, string $media): array
    {
        AuthMiddleware::requirePermission('media:read:*');
        $filename = Assets::mediaName($media, $module->settings->get()['data']['apiBaseUrl']);
        if ($filename === null) {
            throw new SeoException('invalid_local_media');
        }
        return $module->assets->importLocal($filename);
    }

    private static function canRead(array $target): bool
    {
        if ($target['kind'] === 'route') {
            return true;
        }
        $user = AuthMiddleware::getCurrentUser();
        return $user !== null && (!empty($user->is_admin) || \NomadCMS\Services\RBACService::canAccessSlot($user, $target['slot_key'])) && AuthMiddleware::hasPermission('content:read:*', $target['slot_key'], $target['item_uid'] ?: null);
    }

    private static function targetAccess(array $target, string $action): void
    {
        if ($target['kind'] !== 'route') {
            AuthMiddleware::requireSlotAccess($target['slot_key']);
            AuthMiddleware::requirePermission('content:' . $action . ':*', $target['slot_key'], $target['item_uid'] ?: null);
        }
    }

    public static function public(): void
    {
        self::guard(function (): void {
            self::validateQuery();
            $method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
            self::method(['GET', 'HEAD'], $method);
            $module = SeoModule::production();
            $action = (string) ($_GET['_seo_action'] ?? 'meta');
            if ($action === 'og') {
                $id = (string) ($_GET['id'] ?? '');
                $locale = Support::locale((string) ($_GET['lang'] ?? $module->targets->get($id)['main_locale']));
                $image = $module->og->image($id, $locale);
                $status = ($_SERVER['HTTP_IF_NONE_MATCH'] ?? '') === $image['etag'] ? 304 : 200;
                try {
                    try {
                        if (!\NomadCMS\Security\PanicModeService::isReadOnlyRequest()) {
                            $module->social->record($id, $image['locale'], $_SERVER['HTTP_USER_AGENT'] ?? '', $method, $status);
                        }
                    } catch (\Throwable $error) {
                        error_log('[seo.statistics] ' . $error->getMessage());
                    }
                    http_response_code($status);
                    header('Content-Type: image/png');
                    header('ETag: ' . $image['etag']);
                    header('Cache-Control: public, max-age=60, must-revalidate');
                    header('X-Content-Type-Options: nosniff');
                    if ($status !== 304) {
                        header('Content-Length: ' . $image['size']);
                        if ($method === 'GET') {
                            fpassthru($image['stream']);
                        }
                    }
                } finally {
                    fclose($image['stream']);
                }
                return;
            }
            if ($action === 'sitemap' || $action === 'robots') {
                $file = $action === 'sitemap' ? $module->site->sitemapFile(isset($_GET['part']) ? (int) $_GET['part'] : null, $_GET['g'] ?? null) : null;
                $robots = $action === 'robots' ? $module->site->robots() : null;
                header('Content-Type: ' . ($action === 'robots' ? 'text/plain' : 'application/xml') . '; charset=utf-8');
                header('Cache-Control: public, max-age=60, must-revalidate');
                header('Content-Length: ' . ($file ? filesize($file) : strlen($robots)));
                if ($method === 'GET') {
                    if ($action === 'robots') {
                        echo $robots;
                    } else {
                        readfile($file);
                    }
                }
                return;
            }
            if ($action !== 'meta') {
                throw new SeoException('not_found', 404);
            }
            $meta = $module->metadata->forPath((string) ($_GET['path'] ?? '/'), isset($_GET['lang']) ? (string) $_GET['lang'] : null);
            header('ETag: ' . $meta['etag']);
            if (($_SERVER['HTTP_IF_NONE_MATCH'] ?? '') === $meta['etag']) {
                http_response_code(304);
                header('Cache-Control: public, max-age=60, must-revalidate');
                return;
            }
            if ($method === 'HEAD') {
                header('Content-Type: application/json; charset=utf-8');
                header('Cache-Control: public, max-age=60, must-revalidate');
                return;
            }
            self::json($meta, 'public, max-age=60, must-revalidate');
        });
    }

    private static function method(array $allowed, string $method): void
    {
        if (!$allowed) {
            throw new SeoException('not_found', 404);
        }
        if (!in_array($method, $allowed, true)) {
            header('Allow: ' . implode(', ', $allowed));
            throw new SeoException('method_not_allowed', 405);
        }
    }

    /** Reject array query values before scalar casts can corrupt the JSON response. */
    private static function validateQuery(): void
    {
        foreach ($_GET as $value) {
            if (is_array($value)) {
                throw new SeoException('invalid_input');
            }
        }
    }

    private static function upload(int $limit): string
    {
        $file = $_FILES['file'] ?? [];
        if (($file['error'] ?? -1) !== UPLOAD_ERR_OK || !is_uploaded_file($file['tmp_name'] ?? '') || ($file['size'] ?? 0) > $limit) {
            throw new SeoException('invalid_upload');
        }
        $stream = fopen($file['tmp_name'], 'rb');
        try {
            $bytes = stream_get_contents($stream, $limit + 1);
        } finally {
            fclose($stream);
        }
        if (strlen($bytes) > $limit) {
            throw new SeoException('upload_size_limit');
        }
        return $bytes;
    }

    private static function body(): array
    {
        $stream = fopen('php://input', 'rb');
        $raw = stream_get_contents($stream, 262145);
        fclose($stream);
        if (strlen($raw) > 262144) {
            throw new SeoException('request_size_limit', 413);
        }
        $input = Support::decode($raw);
        if ($raw !== '' && !str_starts_with(ltrim($raw), '{')) {
            throw new SeoException('invalid_json');
        }
        return $input;
    }

    private static function json(array $value, string $cache): void
    {
        $json = Support::json($value);
        if (strlen($json) > (str_starts_with($cache, 'public') ? 65536 : 1048576)) {
            throw new SeoException('response_size_limit', 503);
        }
        header('Content-Type: application/json; charset=utf-8');
        header('Cache-Control: ' . $cache);
        echo $json;
    }

    private static function guard(callable $operation): void
    {
        try {
            $operation();
        } catch (SeoException $error) {
            http_response_code($error->status);
            if (isset($error->details['retry_after'])) {
                header('Retry-After: ' . $error->details['retry_after']);
            }
            self::json(['success' => false, 'error' => $error->errorCode, 'details' => $error->details], 'no-store');
        } catch (\JsonException | \TypeError | \ValueError $error) {
            http_response_code(422);
            self::json(['success' => false, 'error' => 'invalid_input'], 'no-store');
        } catch (\Throwable $error) {
            error_log('[seo.http] ' . $error->getMessage());
            http_response_code(503);
            self::json(['success' => false, 'error' => 'seo_unavailable'], 'no-store');
        }
    }
}
