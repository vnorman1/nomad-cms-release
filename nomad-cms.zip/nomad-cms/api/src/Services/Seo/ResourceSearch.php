<?php
/**
 * NOMAD CMS — indexed, cursor-based SEO resource search.
 * FTS5 unicode61 removes diacritics; bounded keyset pages retain the existing resource cursor.
 * Only internal resource table names are accepted and user search terms are bound parameters.
 * @package NomadCMS\Services\Seo
 */
declare(strict_types=1);

namespace NomadCMS\Services\Seo;

use PDO;

/** Shared resource query builder for fonts, images and template pickers. */
final class ResourceSearch
{
    public static function page(PDO $db, string $table, string $columns, string $cursor, int $limit, string $query, string $condition = '', array $conditionParameters = [], string $joins = ''): array
    {
        if (!in_array($table, ['seo_fonts', 'seo_assets', 'seo_templates'], true)) {
            throw new \InvalidArgumentException('Unknown SEO resource table');
        }
        $limit = max(1, min(100, $limit));
        $query = Support::text($query, 128);
        $parameters = [$cursor];
        $sql = 'SELECT ' . $columns . ' FROM ' . $table . ' r' . $joins;
        preg_match_all('/[\p{L}\p{N}_]+/u', $query, $matches);
        if ($matches[0]) {
            $fts = $table . '_fts';
            if (!Support::one($db, "SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", [$fts])) {
                throw new SeoException('migration_required', 503);
            }
            $sql .= ' JOIN ' . $fts . ' ON ' . $fts . '.rowid=r.rowid WHERE r.id>? AND ' . $fts . ' MATCH ?';
            $parameters[] = implode(' AND ', array_map(static fn ($term) => '"' . $term . '"*', array_slice($matches[0], 0, 12)));
        } else {
            $sql .= ' WHERE r.id>?';
        }
        if ($condition !== '') {
            $sql .= ' AND (' . $condition . ')';
            array_push($parameters, ...$conditionParameters);
        }
        $sql .= ' ORDER BY r.id LIMIT CAST(? AS INTEGER)';
        $parameters[] = $limit + 1;
        $rows = Support::query($db, $sql, $parameters)->fetchAll(PDO::FETCH_ASSOC);
        $more = count($rows) > $limit;
        if ($more) {
            array_pop($rows);
        }
        return ['items' => $rows, 'next_cursor' => $more ? end($rows)['id'] : null];
    }
}
