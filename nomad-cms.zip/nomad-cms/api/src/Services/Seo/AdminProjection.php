<?php
/**
 * NOMAD CMS — bounded administrative SEO projections.
 * Collection lists use the existing content indexes; only visible rows refresh their SEO summaries.
 * Authorization predicates are applied in SQL before counts, pagination and cursors.
 * @package NomadCMS\Services\Seo
 */
declare(strict_types=1);

namespace NomadCMS\Services\Seo;

use PDO;

/** Read models for the Studio; mutations remain in the original domain services. */
final class AdminProjection
{
    public function __construct(private readonly SeoModule $module)
    {
    }

    public function refresh(string $id, ?string $requestedLocale = null): void
    {
        $target = $this->module->targets->get($id);
        $settings = $this->module->settings->get();
        $locales = $requestedLocale === null ? array_unique([$target['main_locale'], ...$this->module->targets->locales(), ...array_column($this->module->targets->paths($id), 'locale')]) : [Support::locale($requestedLocale)];
        Support::transaction($this->module->db, function () use ($id, $target, $settings, $locales): void {
            foreach ($locales as $locale) {
                $meta = $this->module->metadata->effective($id, $locale, false, [], false);
                $template = Support::one($this->module->db, 'SELECT active_version FROM seo_templates WHERE id=?', [$meta['templateId']]);
                Support::query($this->module->db, 'INSERT INTO seo_admin_projection(target_id,locale,title,path,source_generation,settings_revision,effective_revision,template_id,template_version,cover_status,image_mode,indexable) VALUES (?,?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(target_id,locale) DO UPDATE SET title=excluded.title,path=excluded.path,source_generation=excluded.source_generation,settings_revision=excluded.settings_revision,effective_revision=excluded.effective_revision,template_id=excluded.template_id,template_version=excluded.template_version,cover_status=excluded.cover_status,image_mode=excluded.image_mode,indexable=excluded.indexable WHERE (title,path,source_generation,settings_revision,effective_revision,template_id,template_version,cover_status,image_mode,indexable) IS NOT (excluded.title,excluded.path,excluded.source_generation,excluded.settings_revision,excluded.effective_revision,excluded.template_id,excluded.template_version,excluded.cover_status,excluded.image_mode,excluded.indexable)', [
                    $id, $locale, $meta['title'], $meta['path'] ?? '', (int) $target['generation'], $this->module->settings->projectionRevision(), $meta['revision'], $meta['templateId'], $template['active_version'] ?? null, $meta['coverStatus'], $meta['effectiveImageMode'], (int) $meta['robots']['index'],
                ]);
            }
        });
    }

    public function rebuild(string $cursor, int $limit = 200): array
    {
        $targets = Support::query($this->module->db, 'SELECT id FROM seo_targets WHERE id>? ORDER BY id LIMIT CAST(? AS INTEGER)', [$cursor, min(200, max(1, $limit))])->fetchAll(PDO::FETCH_ASSOC);
        foreach ($targets as $target) {
            $this->refresh($target['id']);
            $cursor = $target['id'];
        }
        return ['cursor' => $cursor, 'done' => count($targets) < min(200, max(1, $limit))];
    }

    /** The caller supplies a trusted RBAC SQL predicate using alias t, never user SQL. */
    public function page(array $filters, array $access = ['1=1', []]): array
    {
        if (!Support::one($this->module->db, "SELECT 1 FROM sqlite_master WHERE name='seo_admin_projection'")) {
            throw new SeoException('migration_required', 503);
        }
        $locale = Support::locale($filters['lang'] ?? $this->module->targets->mainLocale());
        if (!in_array($locale, $this->module->targets->locales(), true)) {
            throw new SeoException('invalid_locale');
        }
        $limit = min(100, max(1, (int) ($filters['limit'] ?? 50)));
        $search = Support::text((string) ($filters['q'] ?? ''), 200);
        $cursor = $this->decodeCursor((string) ($filters['cursor'] ?? ''));
        $candidates = [];
        $kind = (string) ($filters['kind'] ?? '');
        if (!in_array($kind, ['', 'object', 'list', 'collection', 'route'], true)) {
            throw new SeoException('invalid_target_filter');
        }
        if (isset($filters['published']) && $filters['published'] !== '' && !in_array((string) $filters['published'], ['0', '1'], true)) {
            throw new SeoException('invalid_target_filter');
        }
        if (!in_array($filters['audit'] ?? '', ['', 'red', 'yellow', 'green', 'pending', 'provisional', 'not_checked', 'stale', 'current'], true)) {
            throw new SeoException('invalid_target_filter');
        }
        $query = null;
        if ($search !== '') {
            preg_match_all('/[\p{L}\p{N}]+/u', $search, $tokens);
            if (!$tokens[0]) {
                return ['items' => [], 'next_cursor' => null];
            }
            $query = implode(' AND ', array_map(static fn ($token) => '"' . $token . '"*', array_slice($tokens[0], 0, 20)));
        }
        if ($cursor[0] === 'collection' && ($kind === '' || $kind === 'collection')) {
            $candidates = $this->collectionCandidates($filters, $access, $cursor, $query, $limit + 1);
        }
        if (count($candidates) <= $limit && $kind !== 'collection') {
            $where = ["t.kind<>'collection'", '(' . $access[0] . ')', 't.id>?'];
            $parameters = [...$access[1], $cursor[0] === 'target' ? $cursor[1] : ''];
            $this->candidateFilters($filters, $where, $parameters);
            if ($query !== null) {
                $where[] = 't.id IN (SELECT target_id FROM seo_admin_projection WHERE id IN (SELECT rowid FROM seo_admin_fts WHERE seo_admin_fts MATCH ?))';
                $parameters[] = $query;
            }
            $parameters[] = $limit + 1 - count($candidates);
            $targets = Support::query($this->module->db, 'SELECT t.id,t.kind,t.slot_key,t.item_uid FROM seo_targets t WHERE ' . implode(' AND ', $where) . ' ORDER BY t.id LIMIT CAST(? AS INTEGER)', $parameters)->fetchAll(PDO::FETCH_ASSOC);
            $candidates = [...$candidates, ...$targets];
        }
        $more = count($candidates) > $limit;
        $candidates = array_slice($candidates, 0, $limit);
        if (!$candidates) {
            return ['items' => [], 'next_cursor' => null];
        }
        $ids = [];
        foreach ($candidates as &$candidate) {
            if ($candidate['kind'] === 'collection') {
                // RBAC was already applied to the raw source reference before these bounded writes.
                $this->module->targets->synchronize($candidate['slot_key'], $candidate['item_uid']);
                $candidate['id'] = Support::one($this->module->db, "SELECT id FROM seo_targets WHERE kind='collection' AND slot_key=? AND item_uid=?", [$candidate['slot_key'], $candidate['item_uid']])['id'];
            }
            $this->refresh($candidate['id'], $locale);
            $ids[] = $candidate['id'];
        }
        unset($candidate);
        $scope = ['(' . $access[0] . ') AND t.id IN (' . implode(',', array_fill(0, count($ids), '?')) . ')', [...$access[1], ...$ids]];
        // A source FTS match must survive even when the selected locale has another translated title.
        $result = $this->projectionPage(array_replace($filters, ['q' => '', 'cursor' => '', 'limit' => 100]), $scope);
        $positions = array_flip($ids);
        usort($result['items'], static fn ($a, $b) => $positions[$a['id']] <=> $positions[$b['id']]);
        $last = end($candidates);
        $result['next_cursor'] = $more ? $this->encodeCursor($last) : null;
        return $result;
    }

    /** Source queries reuse the collection's unique reference index and existing multilingual FTS. */
    private function collectionCandidates(array $filters, array $access, array $cursor, ?string $query, int $limit): array
    {
        $slots = [];
        foreach ($this->module->targets->schema['slots'] ?? [] as $slot => $definition) {
            if (($definition['type'] ?? '') === 'collection') {
                $slots[] = $slot;
            }
        }
        if (!$slots || !Support::one($this->module->db, "SELECT 1 FROM sqlite_master WHERE name='collection_items'")) {
            return [];
        }
        $reviewed = in_array($filters['audit'] ?? '', ['red', 'yellow', 'green', 'current', 'stale'], true);
        if ($query === null && !$reviewed) {
            // Explicit per-slot UID ranges preserve both columns of the existing unique index.
            // A combined IN(slot)/tuple predicate makes SQLite rescan a whole slot on later pages.
            sort($slots, SORT_STRING);
            $rows = [];
            foreach ($slots as $slot) {
                if (strcmp($slot, $cursor[1]) < 0 || (!empty($filters['slot']) && $filters['slot'] !== $slot)) {
                    continue;
                }
                $where = ['(' . $access[0] . ')', 't.slot_key=?', 't.item_uid>?'];
                $parameters = [...$access[1], $slot, $slot === $cursor[1] ? $cursor[2] : ''];
                $this->candidateFilters($filters, $where, $parameters);
                $parameters[] = $limit - count($rows);
                $source = "SELECT COALESCE(existing.id,'') AS id,'collection' AS kind,c.slot_key,c.item_uid,c.published AS public
                    FROM collection_items c LEFT JOIN seo_targets existing ON existing.kind='collection' AND existing.slot_key=c.slot_key AND existing.item_uid=c.item_uid";
                $batch = Support::query($this->module->db, 'SELECT t.id,t.kind,t.slot_key,t.item_uid FROM (' . $source . ') t WHERE ' . implode(' AND ', $where) . ' ORDER BY t.item_uid LIMIT CAST(? AS INTEGER)', $parameters)->fetchAll(PDO::FETCH_ASSOC);
                $rows = [...$rows, ...$batch];
                if (count($rows) >= $limit) {
                    break;
                }
            }
            return $rows;
        }
        $where = ['(' . $access[0] . ')', 't.slot_key IN (' . implode(',', array_fill(0, count($slots), '?')) . ')', '(t.slot_key,t.item_uid)>(?,?)'];
        $parameters = [...$access[1], ...$slots, $cursor[1], $cursor[2]];
        $this->candidateFilters($filters, $where, $parameters);
        if ($reviewed) {
            $where[] = "t.source_row_id IN (SELECT matched.row_id FROM seo_audits a JOIN seo_targets registered ON registered.id=a.target_id JOIN collection_items matched ON matched.slot_key=registered.slot_key AND matched.item_uid=registered.item_uid WHERE a.locale=? AND a.kind='cms' AND registered.kind='collection')";
            $parameters[] = Support::locale($filters['lang'] ?? $this->module->targets->mainLocale());
        }
        if ($query !== null) {
            $matches = ["SELECT matched.row_id FROM seo_admin_fts f JOIN seo_admin_projection p ON p.id=f.rowid JOIN seo_targets registered ON registered.id=p.target_id JOIN collection_items matched ON matched.slot_key=registered.slot_key AND matched.item_uid=registered.item_uid WHERE seo_admin_fts MATCH ? AND registered.kind='collection' AND p.source_generation=registered.generation"];
            $parameters[] = $query;
            if (Support::one($this->module->db, "SELECT 1 FROM sqlite_master WHERE name='collection_fts'")) {
                $matches[] = 'SELECT rowid FROM collection_fts WHERE collection_fts MATCH ?';
                $parameters[] = $query;
            }
            $where[] = 't.source_row_id IN (' . implode(' UNION ', $matches) . ')';
        }
        $parameters[] = $limit;
        // Search must visit FTS row IDs first; otherwise SQLite may walk the entire slot index.
        $collection = 'collection_items c NOT INDEXED';
        $source = "SELECT COALESCE(existing.id,'') AS id,'collection' AS kind,c.slot_key,c.item_uid,c.published AS public,c.row_id AS source_row_id
            FROM {$collection} LEFT JOIN seo_targets existing ON existing.kind='collection' AND existing.slot_key=c.slot_key AND existing.item_uid=c.item_uid";
        return Support::query($this->module->db, 'SELECT t.id,t.kind,t.slot_key,t.item_uid FROM (' . $source . ') t WHERE ' . implode(' AND ', $where) . ' ORDER BY t.slot_key,t.item_uid LIMIT CAST(? AS INTEGER)', $parameters)->fetchAll(PDO::FETCH_ASSOC);
    }

    private function candidateFilters(array $filters, array &$where, array &$parameters): void
    {
        foreach (['slot' => 'slot_key', 'kind' => 'kind', 'published' => 'public'] as $filter => $column) {
            if (isset($filters[$filter]) && $filters[$filter] !== '') {
                $where[] = 't.' . $column . '=?';
                $parameters[] = $filter === 'published' ? (int) $filters[$filter] : (string) $filters[$filter];
            }
        }
        $audit = $filters['audit'] ?? '';
        $locale = Support::locale($filters['lang'] ?? $this->module->targets->mainLocale());
        if (in_array($audit, ['not_checked', 'pending'], true)) {
            $where[] = "NOT EXISTS (SELECT 1 FROM seo_audits a WHERE a.target_id=t.id AND a.locale=? AND a.kind='cms')";
            $parameters[] = $locale;
        } elseif (in_array($audit, ['current', 'stale', 'red', 'yellow', 'green'], true)) {
            // Compact snapshot existence is a safe indexed prefilter. Scores and freshness are
            // evaluated after refreshing the visible source; expired live findings cannot exclude
            // a currently green CMS result, and stale evidence must never receive a success color.
            $where[] = "EXISTS (SELECT 1 FROM seo_audits cms WHERE cms.target_id=t.id AND cms.locale=? AND cms.kind='cms')";
            $parameters[] = $locale;
        }
    }

    /** Opaque cursors follow indexed source references rather than hashes requiring full sorting. */
    private function decodeCursor(string $cursor): array
    {
        if ($cursor === '') {
            return ['collection', '', ''];
        }
        if (!str_starts_with($cursor, 'source:')) {
            return ['target', Support::text($cursor, 2048), ''];
        }
        $decoded = base64_decode(substr($cursor, 7), true);
        $parts = $decoded === false ? null : json_decode($decoded, true);
        if (!is_array($parts) || count($parts) !== 3 || !in_array($parts[0] ?? null, ['collection', 'target'], true) || !is_string($parts[1]) || !is_string($parts[2])) {
            throw new SeoException('invalid_cursor');
        }
        return $parts;
    }

    private function encodeCursor(array $target): string
    {
        return 'source:' . base64_encode(Support::json($target['kind'] === 'collection' ? ['collection', $target['slot_key'], $target['item_uid']] : ['target', $target['id'], '']));
    }

    /** The caller supplies a trusted RBAC SQL predicate using alias t, never user SQL. */
    private function projectionPage(array $filters, array $access = ['1=1', []]): array
    {
        if (!Support::one($this->module->db, "SELECT 1 FROM sqlite_master WHERE name='seo_admin_projection'")) {
            throw new SeoException('migration_required', 503);
        }
        $locale = Support::locale($filters['lang'] ?? $this->module->targets->mainLocale());
        $cursor = Support::text((string) ($filters['cursor'] ?? ''), 2048);
        $limit = min(100, max(1, (int) ($filters['limit'] ?? 50)));
        $where = ['t.id>?', '(' . $access[0] . ')'];
        $parameters = [...$this->auditParameters(), $locale, $locale, $locale, $cursor, ...$access[1]];
        if (!empty($filters['slot'])) {
            $where[] = 't.slot_key=?';
            $parameters[] = (string) $filters['slot'];
        }
        if (!empty($filters['kind'])) {
            if (!in_array($filters['kind'], ['object', 'list', 'collection', 'route'], true)) {
                throw new SeoException('invalid_target_filter');
            }
            $where[] = 't.kind=?';
            $parameters[] = $filters['kind'];
        }
        if (isset($filters['published']) && $filters['published'] !== '') {
            if (!in_array((string) $filters['published'], ['0', '1'], true)) {
                throw new SeoException('invalid_target_filter');
            }
            $where[] = 't.public=?';
            $parameters[] = (int) $filters['published'];
        }
        $search = Support::text((string) ($filters['q'] ?? ''), 200);
        if ($search !== '') {
            preg_match_all('/[\p{L}\p{N}]+/u', $search, $tokens);
            if (!$tokens[0]) {
                return ['items' => [], 'next_cursor' => null];
            }
            $where[] = 'p.id IN (SELECT rowid FROM seo_admin_fts WHERE seo_admin_fts MATCH ?)';
            $parameters[] = implode(' AND ', array_map(static fn ($token) => '"' . $token . '"*', array_slice($tokens[0], 0, 20)));
        }
        $sql = $this->scoredSelect($this->select() . ' WHERE ' . implode(' AND ', $where));
        $audit = $filters['audit'] ?? '';
        if (!in_array($audit, ['', 'red', 'yellow', 'green', 'pending', 'provisional', 'not_checked', 'stale', 'current'], true)) {
            throw new SeoException('invalid_target_filter');
        }
        $state = match ($audit) {
            'red', 'yellow', 'green' => ' WHERE color=? AND pending=0',
            'pending' => ' WHERE pending=1 OR score IS NULL',
            'provisional' => ' WHERE provisional=1',
            'not_checked', 'stale', 'current' => ' WHERE audit_state=?',
            default => '',
        };
        if (in_array($audit, ['red', 'yellow', 'green', 'not_checked', 'stale', 'current'], true)) {
            $parameters[] = $audit;
        }
        $parameters[] = $limit + 1;
        $rows = Support::query($this->module->db, 'SELECT * FROM (' . $sql . ')' . $state . ' ORDER BY id LIMIT CAST(? AS INTEGER)', $parameters)->fetchAll(PDO::FETCH_ASSOC);
        $more = count($rows) > $limit;
        if ($more) {
            array_pop($rows);
        }
        $rows = array_map($this->normalize(...), $rows);
        return ['items' => $rows, 'next_cursor' => $more ? end($rows)['id'] : null];
    }

    private function auditParameters(): array
    {
        $settings = $this->module->settings->get();
        return [
            $this->module->settings->projectionRevision(), Auditor::RULE_VERSION, Auditor::RULE_VERSION,
            Support::timestamp(($this->module->clock)() - (int) $settings['data']['liveAuditMaxAge']),
        ];
    }

    private function select(bool $mainLocale = false): string
    {
        // SQL calculates freshness from compact persisted snapshots without running audits.
        $locale = $mainLocale ? 't.main_locale' : '?';
        return "SELECT t.*,p.locale,COALESCE(NULLIF(p.title,''),r.label,t.slot_key,t.id) AS title,NULLIF(p.path,'') AS path,
            p.indexable,p.cover_status,
            (p.id IS NULL OR p.source_generation<>t.generation OR p.settings_revision<>? OR COALESCE(p.template_version,0)<>COALESCE(tp.active_version,0)) AS pending,
            CASE WHEN p.image_mode='custom' THEN 'custom' WHEN tp.active_version IS NULL THEN 'template_not_active' WHEN p.cover_status='import_required' THEN 'import_required' ELSE 'ready' END AS og_status,
            CASE WHEN c.source_revision=p.effective_revision AND json_extract(c.result,'$.rule_version')=? THEN json_extract(c.result,'$.score') ELSE NULL END AS cms_score,
            CASE WHEN l.source_revision=p.effective_revision AND json_extract(l.result,'$.rule_version')=? AND l.created_at>=? THEN json_extract(l.result,'$.score') ELSE NULL END AS live_score,
            c.target_id IS NOT NULL AS cms_checked,l.target_id IS NOT NULL AS live_checked,
            json_extract(c.result,'$.critical') AS cms_critical,json_extract(l.result,'$.critical') AS live_critical
            FROM seo_targets t LEFT JOIN seo_admin_projection p ON p.target_id=t.id AND p.locale={$locale}
            LEFT JOIN seo_routes r ON r.id=t.id LEFT JOIN seo_templates tp ON tp.id=p.template_id
            LEFT JOIN seo_audits c ON c.target_id=t.id AND c.locale={$locale} AND c.kind='cms'
            LEFT JOIN seo_audits l ON l.target_id=t.id AND l.locale={$locale} AND l.kind='live'";
    }

    /** Snapshot state is independent of index progress and never invokes the rule engine. */
    private function scoredSelect(string $sql): string
    {
        $sql = "SELECT raw.*,
            CASE WHEN pending OR cms_score IS NULL THEN NULL WHEN live_score IS NULL THEN cms_score ELSE MIN(cms_score,live_score) END AS score,
            CASE WHEN NOT cms_checked THEN 'not_checked' WHEN pending OR cms_score IS NULL THEN 'stale' ELSE 'current' END AS cms_state,
            CASE WHEN NOT live_checked THEN 'not_checked' WHEN pending OR live_score IS NULL THEN 'stale' ELSE 'current' END AS live_state
            FROM (" . $sql . ') raw';

        return "SELECT scored.*,cms_state AS audit_state,
            (cms_state<>'current' OR live_state<>'current') AS provisional,
            CASE WHEN score IS NULL THEN NULL WHEN cms_critical OR (live_score IS NOT NULL AND live_critical) OR score<50 THEN 'red' WHEN score<80 THEN 'yellow' ELSE 'green' END AS color
            FROM (" . $sql . ') scored';
    }

    private function normalize(array $row): array
    {
        $cms = $row['cms_score'];
        $live = $row['live_score'];
        $row['score'] = $cms === null || $row['pending'] ? null : (int) ($live === null ? $cms : min($cms, $live));
        $critical = $row['cms_critical'] || ($live !== null && $row['live_critical']);
        $row['color'] = $row['score'] === null ? null : ($critical || $row['score'] < 50 ? 'red' : ($row['score'] < 80 ? 'yellow' : 'green'));
        $row['provisional'] = $row['cms_state'] !== 'current' || $row['live_state'] !== 'current';
        $row['pending'] = (bool) $row['pending'];
        $row['indexable'] = (bool) $row['indexable'];
        $row['generation'] = (int) $row['generation'];
        $row['public'] = (int) $row['public'];
        unset($row['cms_score'], $row['live_score'], $row['cms_critical'], $row['live_critical'], $row['cms_checked'], $row['live_checked']);
        return $row;
    }

    public function overview(array $access): array
    {
        $sql = $this->scoredSelect($this->select(true) . ' WHERE ' . $access[0]);
        $row = Support::one($this->module->db, "SELECT COUNT(*) AS total,COALESCE(SUM(public),0) AS published,COALESCE(SUM(pending),0) AS pending,COALESCE(SUM(cms_state='current'),0) AS audited,COALESCE(SUM(cms_state<>'current'),0) AS needsAudit FROM (" . $sql . ') summaries', [...$this->auditParameters(), ...$access[1]]);
        return array_map('intval', $row) + ['issues' => $this->page(['audit' => 'red', 'limit' => 10], $access)['items']];
    }

    public function health(): array
    {
        $db = $this->module->db;
        $settings = $this->module->settings->get()['data'];
        $heartbeat = Support::one($db, "SELECT value FROM seo_settings WHERE key='worker_seen'")['value'] ?? null;
        $dirty = Support::one($db, "SELECT value FROM seo_settings WHERE key='sitemap_dirty'")['value'] ?? 'true';
        return [
            'configured' => $settings['publicSiteUrl'] !== '' && $settings['apiBaseUrl'] !== '',
            'renderer' => extension_loaded('gd') && function_exists('imagettfbbox'),
            'fonts' => (int) Support::one($db, 'SELECT COUNT(*) AS n FROM seo_fonts')['n'],
            'activeTemplates' => (int) Support::one($db, 'SELECT COUNT(*) AS n FROM seo_templates WHERE active_version IS NOT NULL')['n'],
            'jobs' => Support::query($db, 'SELECT kind,COUNT(*) AS count,MAX(attempts) AS attempts FROM seo_jobs GROUP BY kind')->fetchAll(PDO::FETCH_ASSOC),
            'worker' => ['last_seen' => $heartbeat, 'stale' => !$heartbeat || ($this->module->clock)() - strtotime($heartbeat) > 900],
            'sitemap' => ['dirty' => $dirty === 'true', 'ready' => is_file($this->module->files->path('cache/sitemaps/index.xml'))],
            'projection' => ['targets' => (int) Support::one($db, 'SELECT COUNT(*) AS n FROM seo_targets')['n'], 'projected' => (int) Support::one($db, 'SELECT COUNT(*) AS n FROM seo_admin_projection p JOIN seo_targets t ON t.id=p.target_id AND t.main_locale=p.locale AND t.generation=p.source_generation')['n']],
        ];
    }
}
