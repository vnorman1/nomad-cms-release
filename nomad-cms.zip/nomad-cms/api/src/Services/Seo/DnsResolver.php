<?php
/**
 * NOMAD CMS — deadline-bound DNS resolution for outbound SEO requests.
 * Queries the host's configured recursive resolvers directly, without blocking dns_get_record().
 * Accepts only matching DNS answers and follows bounded CNAME chains before HTTP address pinning.
 * @package NomadCMS\Services\Seo
 */
declare(strict_types=1);

namespace NomadCMS\Services\Seo;

/** Small UDP DNS adapter; truncated replies fail closed within the caller's deadline. */
final class DnsResolver
{
    public function __construct(private readonly ?array $servers = null)
    {
    }

    public function resolve(string $host, float $deadline): array
    {
        $addresses = [];
        foreach ([1, 28] as $type) {
            $name = $host;
            $visited = [];
            for ($hop = 0; $hop < 8; $hop++) {
                if (isset($visited[$name])) {
                    throw new SeoException('http_dns_cname_loop', 503);
                }
                $visited[$name] = true;
                $result = $this->query($name, $type, $deadline);
                $addresses = array_merge($addresses, $result['addresses']);
                if ($result['addresses'] !== [] || $result['canonical'] === $name) {
                    break;
                }
                $name = $result['canonical'];
                if ($hop === 7) {
                    throw new SeoException('http_dns_cname_limit', 503);
                }
            }
        }
        return array_values(array_unique($addresses));
    }

    private function query(string $host, int $type, float $deadline): array
    {
        $question = '';
        foreach (explode('.', rtrim($host, '.')) as $label) {
            if ($label === '' || strlen($label) > 63 || !preg_match('/^[a-zA-Z0-9_-]+$/D', $label)) {
                throw new SeoException('http_dns_name_invalid', 503);
            }
            $question .= chr(strlen($label)) . $label;
        }
        if (strlen($question) > 253) {
            throw new SeoException('http_dns_name_invalid', 503);
        }
        $question .= "\0" . pack('nn', $type, 1);
        $servers = $this->servers ?? self::systemServers();
        foreach ($servers as $index => $server) {
            if (!filter_var($server, FILTER_VALIDATE_IP)) {
                continue;
            }
            $remaining = $deadline - microtime(true);
            if ($remaining <= 0) {
                throw new SeoException('http_timeout', 504);
            }
            $attemptDeadline = microtime(true) + $remaining / max(1, count($servers) - $index);
            $id = random_int(1, 65535);
            $request = pack('nnnnnn', $id, 0x0100, 1, 0, 0, 0) . $question;
            $endpoint = 'udp://' . (str_contains($server, ':') ? '[' . $server . ']' : $server) . ':53';
            $socket = @stream_socket_client($endpoint, $errorNumber, $errorText, $remaining, STREAM_CLIENT_CONNECT);
            if ($socket === false) {
                continue;
            }
            try {
                stream_set_blocking($socket, false);
                if (fwrite($socket, $request) !== strlen($request)) {
                    continue;
                }
                while (($wait = $attemptDeadline - microtime(true)) > 0) {
                    $read = [$socket];
                    $write = $except = [];
                    $seconds = (int) floor($wait);
                    $microseconds = (int) (($wait - $seconds) * 1000000);
                    if (@stream_select($read, $write, $except, $seconds, $microseconds) !== 1) {
                        break;
                    }
                    $packet = fread($socket, 65536);
                    if (strlen($packet) < 12 || unpack('n', substr($packet, 0, 2))[1] !== $id) {
                        continue;
                    }
                    return self::answer($packet, $id, $host, $type);
                }
            } finally {
                fclose($socket);
            }
        }
        throw new SeoException(microtime(true) >= $deadline ? 'http_timeout' : 'http_dns_failed', 503);
    }

    /** Parse only the requested name and its CNAME chain, never unrelated additional records. */
    public static function answer(string $packet, int $id, string $host, int $type): array
    {
        if (strlen($packet) < 12) {
            throw new SeoException('http_dns_invalid_reply', 503);
        }
        $header = unpack('nid/nflags/nquestions/nanswers/nauthority/nadditional', substr($packet, 0, 12));
        if ($header['id'] !== $id || ($header['flags'] & 0x8000) === 0 || ($header['flags'] & 0x7800) !== 0 || ($header['flags'] & 0x0200) !== 0 || $header['questions'] !== 1 || !in_array($header['flags'] & 0x000f, [0, 3], true)) {
            throw new SeoException('http_dns_invalid_reply', 503);
        }
        $offset = 12;
        $question = self::name($packet, $offset);
        if ($offset + 4 > strlen($packet)) {
            throw new SeoException('http_dns_invalid_reply', 503);
        }
        $q = unpack('ntype/nclass', substr($packet, $offset, 4));
        $offset += 4;
        $host = strtolower(rtrim($host, '.'));
        if ($question !== $host || $q['type'] !== $type || $q['class'] !== 1) {
            throw new SeoException('http_dns_invalid_reply', 503);
        }
        $records = [];
        for ($index = 0; $index < $header['answers']; $index++) {
            $owner = self::name($packet, $offset);
            if ($offset + 10 > strlen($packet)) {
                throw new SeoException('http_dns_invalid_reply', 503);
            }
            $record = unpack('ntype/nclass/Nttl/nlength', substr($packet, $offset, 10));
            $offset += 10;
            $end = $offset + $record['length'];
            if ($end > strlen($packet)) {
                throw new SeoException('http_dns_invalid_reply', 503);
            }
            if ($record['class'] === 1 && $record['type'] === 5) {
                $cursor = $offset;
                $canonical = self::name($packet, $cursor);
                if ($cursor !== $end || (isset($records[$owner]['canonical']) && $records[$owner]['canonical'] !== $canonical)) {
                    throw new SeoException('http_dns_invalid_reply', 503);
                }
                $records[$owner]['canonical'] = $canonical;
            } elseif ($record['class'] === 1 && $record['type'] === $type) {
                if ($record['length'] !== ($type === 1 ? 4 : 16)) {
                    throw new SeoException('http_dns_invalid_reply', 503);
                }
                $records[$owner]['addresses'][] = inet_ntop(substr($packet, $offset, $record['length']));
            }
            $offset = $end;
        }
        $visited = [];
        for ($hop = 0; $hop < 8; $hop++) {
            if (isset($visited[$host])) {
                throw new SeoException('http_dns_cname_loop', 503);
            }
            $visited[$host] = true;
            if (!empty($records[$host]['addresses'])) {
                return ['addresses' => $records[$host]['addresses'], 'canonical' => $host];
            }
            if (empty($records[$host]['canonical'])) {
                return ['addresses' => [], 'canonical' => $host];
            }
            $host = $records[$host]['canonical'];
        }
        throw new SeoException('http_dns_cname_limit', 503);
    }

    private static function name(string $packet, int &$offset): string
    {
        $labels = [];
        $cursor = $offset;
        $jumped = false;
        $visited = [];
        while (true) {
            if ($cursor >= strlen($packet) || isset($visited[$cursor]) || count($visited) > 127) {
                throw new SeoException('http_dns_invalid_reply', 503);
            }
            $visited[$cursor] = true;
            $length = ord($packet[$cursor++]);
            if (($length & 0xc0) === 0xc0) {
                if ($cursor >= strlen($packet)) {
                    throw new SeoException('http_dns_invalid_reply', 503);
                }
                $pointer = (($length & 0x3f) << 8) | ord($packet[$cursor++]);
                if (!$jumped) {
                    $offset = $cursor;
                    $jumped = true;
                }
                $cursor = $pointer;
                continue;
            }
            if ($length > 63 || $cursor + $length > strlen($packet)) {
                throw new SeoException('http_dns_invalid_reply', 503);
            }
            if ($length === 0) {
                if (!$jumped) {
                    $offset = $cursor;
                }
                $name = strtolower(implode('.', $labels));
                if (strlen($name) > 253) {
                    throw new SeoException('http_dns_invalid_reply', 503);
                }
                return $name;
            }
            $label = substr($packet, $cursor, $length);
            if (!preg_match('/^[a-zA-Z0-9_-]+$/D', $label)) {
                throw new SeoException('http_dns_invalid_reply', 503);
            }
            $labels[] = $label;
            $cursor += $length;
        }
    }

    private static function systemServers(): array
    {
        $stream = @fopen('/etc/resolv.conf', 'rb');
        if ($stream === false) {
            throw new SeoException('http_dns_configuration_unavailable', 503);
        }
        try {
            $configuration = stream_get_contents($stream, 16384);
        } finally {
            fclose($stream);
        }
        preg_match_all('/^\s*nameserver\s+([^\s#]+).*$/m', $configuration, $matches);
        $servers = array_slice(array_values(array_unique($matches[1])), 0, 3);
        if ($servers === []) {
            throw new SeoException('http_dns_configuration_unavailable', 503);
        }
        return $servers;
    }
}
