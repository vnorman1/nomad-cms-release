<?php
/**
 * NOMAD CMS — versioned SEO configuration.
 * Public site and API origins are explicit, independent settings; fonts are opt-in resources.
 * @package NomadCMS\Services\Seo
 */
declare(strict_types=1);

namespace NomadCMS\Services\Seo;

use PDO;

/** Configuration repository with optimistic concurrency. */
final class Settings
{
    public const DEFAULTS = [
        'publicSiteUrl' => '', 'apiBaseUrl' => '', 'siteName' => '',
        'title' => '', 'description' => '', 'defaultFontId' => null,
        'defaultTemplateId' => 'dark-magazine', 'spaGatewayEnabled' => false,
        'httpAllowedHosts' => [], 'ogQuotaBytes' => 268435456,
        'gatewayQuotaBytes' => 33554432, 'liveAuditMaxAge' => 86400,
        'robots' => [['agent' => '*', 'disallow' => ['/api/', '/nomad/'], 'allow' => ['/api/seo/og/']]],
    ];

    public function __construct(private readonly PDO $db, private readonly \Closure $clock)
    {
    }

    public function get(): array
    {
        $row = Support::one($this->db, "SELECT * FROM seo_settings WHERE key='config'");
        if (!$row) {
            throw new SeoException('migration_required', 503);
        }
        return ['data' => array_replace(self::DEFAULTS, Support::decode($row['value'])), 'revision' => (int) $row['revision'], 'updated_at' => $row['updated_at']];
    }

    /** Operational limits and transport controls do not alter content, cards or editorial evidence. */
    public static function revisionSettings(array $data): array
    {
        return array_intersect_key($data, array_fill_keys([
            'publicSiteUrl', 'apiBaseUrl', 'siteName', 'title', 'description',
            'defaultFontId', 'defaultTemplateId', 'robots',
        ], true));
    }

    /** Track semantic projection changes independently of operational configuration writes. */
    public function projectionRevision(): int
    {
        $row = Support::one($this->db, "SELECT value FROM seo_settings WHERE key='metadata_revision'");
        return $row === null ? $this->get()['revision'] : (int) $row['value'];
    }

    public function save(array $input): array
    {
        return Support::transaction($this->db, function () use ($input): array {
            $current = $this->get();
            Support::version($current, $input);
            $data = array_replace($current['data'], array_intersect_key($input['data'] ?? [], self::DEFAULTS));
            foreach (['publicSiteUrl', 'apiBaseUrl'] as $field) {
                if ($data[$field] !== '') {
                    $data[$field] = rtrim(Support::url($data[$field]), '/');
                    $parts = parse_url($data[$field]);
                    if (isset($parts['query']) || isset($parts['fragment'])) {
                        throw new SeoException('invalid_base_url');
                    }
                }
            }
            foreach (['siteName', 'title', 'description'] as $field) {
                $data[$field] = Support::text($data[$field]);
            }
            foreach (['defaultFontId' => 'seo_fonts', 'defaultTemplateId' => 'seo_templates'] as $field => $table) {
                if ($data[$field] !== null && (!is_string($data[$field]) || !Support::one($this->db, 'SELECT id FROM ' . $table . ' WHERE id=?', [$data[$field]]))) {
                    throw new SeoException('resource_not_found', 422, ['field' => $field]);
                }
            }
            if ($data['defaultTemplateId']) {
                Templates::assertCompatible($this->db, $data['defaultTemplateId'], '');
            }
            if (!is_bool($data['spaGatewayEnabled'])) {
                throw new SeoException('invalid_gateway_setting');
            }
            foreach (['ogQuotaBytes', 'gatewayQuotaBytes'] as $field) {
                if (!is_int($data[$field]) || $data[$field] < 1048576 || $data[$field] > 1073741824) {
                    throw new SeoException('invalid_quota');
                }
            }
            if (!is_int($data['liveAuditMaxAge']) || $data['liveAuditMaxAge'] < 60 || $data['liveAuditMaxAge'] > 31536000) {
                throw new SeoException('invalid_audit_max_age');
            }
            foreach ($data['httpAllowedHosts'] as $host) {
                if (!is_string($host) || !preg_match('/^[a-z0-9.-]+$/Di', $host)) {
                    throw new SeoException('invalid_allowed_host');
                }
            }
            if (count($data['httpAllowedHosts']) > 20 || count($data['robots']) > 30) {
                throw new SeoException('configuration_limit');
            }
            foreach ($data['robots'] as $group) {
                if (!preg_match('/^[a-zA-Z0-9_*.-]+$/D', $group['agent'] ?? '')) {
                    throw new SeoException('invalid_robots');
                }
                foreach (['allow', 'disallow'] as $type) {
                    foreach ($group[$type] ?? [] as $path) {
                        if (!is_string($path) || strlen($path) > 2048 || preg_match('/[\r\n\x00]/', $path) || ($path !== '' && $path[0] !== '/')) {
                            throw new SeoException('invalid_robots');
                        }
                    }
                }
            }
            if ($data === $current['data']) {
                return $current;
            }
            $metadataChanged = self::revisionSettings($data) !== self::revisionSettings($current['data']);
            $projectionRevision = $metadataChanged ? $current['revision'] + 1 : $this->projectionRevision();
            if ($data['defaultFontId'] !== $current['data']['defaultFontId'] || $data['defaultTemplateId'] !== $current['data']['defaultTemplateId']) {
                Support::query($this->db, "DELETE FROM seo_asset_usages WHERE owner_type='settings' AND owner_id='config'");
            }
            foreach (['defaultFontId' => 'font', 'defaultTemplateId' => 'template'] as $field => $type) {
                if ($data[$field]) {
                    // Seed implicit defaults on the first real save without deleting unchanged dependencies.
                    Support::query($this->db, "INSERT OR IGNORE INTO seo_asset_usages(type,resource_id,owner_type,owner_id) VALUES (?,?,'settings','config')", [$type, $data[$field]]);
                }
            }
            $now = Support::timestamp(($this->clock)());
            Support::query($this->db, "UPDATE seo_settings SET value=?,revision=revision+1,updated_at=? WHERE key='config'", [Support::json($data), $now]);
            Support::query($this->db, "INSERT INTO seo_settings(key,value,revision,updated_at) VALUES ('metadata_revision',?,1,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value,revision=seo_settings.revision+1,updated_at=excluded.updated_at WHERE value<>excluded.value", [(string) $projectionRevision, $now]);
            return $this->get();
        });
    }
}
