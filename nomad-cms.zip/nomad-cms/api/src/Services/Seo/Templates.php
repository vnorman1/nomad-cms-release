<?php
/**
 * NOMAD CMS — versioned OG layer documents.
 * Draft saves never change the public active version; activation and dependency indexes are atomic.
 * Template bindings are data-only and cannot execute expressions or remote URLs.
 * @package NomadCMS\Services\Seo
 */
declare(strict_types=1);

namespace NomadCMS\Services\Seo;

use PDO;

/** Template validation, draft editing, immutable versions and activation. */
final class Templates
{
    public const BINDINGS = ['title', 'description', 'author', 'category', 'date', 'siteName', 'cover'];

    public function __construct(private readonly PDO $db, private readonly Assets $assets, private readonly \Closure $clock, private readonly ?SchemaFields $schemaFields = null)
    {
    }

    public function get(string $id): array
    {
        $row = Support::one($this->db, 'SELECT * FROM seo_templates WHERE id=?', [$id]) ?? throw new SeoException('template_not_found', 404);
        $row['draft'] = Support::decode($row['draft']);
        $row['revision'] = (int) $row['revision'];
        $active = Support::one($this->db, 'SELECT document,hash FROM seo_template_versions WHERE template_id=? AND version=?', [$id, $row['active_version']]);
        $row['active_document'] = $active ? Support::decode($active['document']) : null;
        $row['active_hash'] = $active['hash'] ?? null;
        return $row;
    }

    public function list(string $cursor = '', int $limit = 50, string $query = '', ?string $slot = null, bool $activeOnly = false): array
    {
        $scope = $activeOnly ? "json_extract(active.document,'$.schemaSlotKey')" : "json_extract(r.draft,'$.schemaSlotKey')";
        $conditions = $activeOnly ? ['r.active_version IS NOT NULL'] : [];
        $parameters = [];
        if ($slot !== null) {
            $conditions[] = '(' . $scope . ' IS NULL OR ' . $scope . '=?)';
            $parameters[] = $slot;
        }
        return ResourceSearch::page($this->db, 'seo_templates', 'r.id,r.name,r.active_version,r.revision,r.updated_at,' . $scope . ' AS schemaSlotKey', $cursor, $limit, $query, implode(' AND ', $conditions), $parameters, ' LEFT JOIN seo_template_versions active ON active.template_id=r.id AND active.version=r.active_version');
    }

    public function validate(array $document, bool $validateSchema = true): array
    {
        if (($document['version'] ?? null) !== 1 || ($document['width'] ?? null) !== 1200 || ($document['height'] ?? null) !== 630 || !is_array($document['layers'] ?? null) || !array_is_list($document['layers']) || count($document['layers']) > 30 || strlen(Support::json($document)) > 65536) {
            throw new SeoException('invalid_template_document');
        }
        $slot = $document['schemaSlotKey'] ?? null;
        if ($slot !== null && (!is_string($slot) || !preg_match('/^[\p{L}\p{N}_-]{1,200}$/uD', $slot) || ($validateSchema && !$this->schemaFields?->hasSlot($slot)))) {
            throw new SeoException('invalid_schema_slot');
        }
        self::color($document['background']['color'] ?? '#ffffff');
        if (isset($document['background']['gradient'])) {
            self::color($document['background']['gradient']['from'] ?? '');
            self::color($document['background']['gradient']['to'] ?? '');
            if (!in_array($document['background']['gradient']['direction'] ?? 'horizontal', ['horizontal', 'vertical'], true)) {
                throw new SeoException('invalid_gradient');
            }
        }
        $ids = [];
        foreach ($document['layers'] as $layer) {
            if (!in_array($layer['type'] ?? '', ['text', 'image', 'rectangle', 'roundedRectangle', 'ellipse'], true) || !preg_match('/^[a-zA-Z0-9_-]{1,64}$/D', $layer['id'] ?? '') || isset($ids[$layer['id']])) {
                throw new SeoException('invalid_layer');
            }
            $ids[$layer['id']] = true;
            foreach (['x' => [0, 1200], 'y' => [0, 630], 'width' => [1, 1200], 'height' => [1, 630], 'opacity' => [0, 1], 'radius' => [0, 315]] as $field => [$min, $max]) {
                $value = $layer[$field] ?? ($field === 'opacity' ? 1 : ($field === 'radius' ? 0 : null));
                if (!is_numeric($value) || !is_finite((float) $value) || $value < $min || $value > $max) {
                    throw new SeoException('invalid_layer_geometry', 422, ['layer' => $layer['id'], 'field' => $field]);
                }
            }
            if ($layer['x'] + $layer['width'] > 1200 || $layer['y'] + $layer['height'] > 630) {
                throw new SeoException('layer_outside_canvas');
            }
            if (isset($layer['binding']) && !in_array($layer['binding'], self::BINDINGS, true)) {
                throw new SeoException('invalid_layer_binding');
            }
            if (isset($layer['fieldPath'])) {
                $path = $layer['fieldPath'];
                if (!is_string($path) || !SchemaFields::validPath($path) || $slot === null || isset($layer['binding']) || !in_array($layer['type'], ['text', 'image'], true) || ($layer['type'] === 'image' && !empty($layer['assetId']))) {
                    throw new SeoException('invalid_layer_field');
                }
                $field = $this->schemaFields?->descriptor($slot, $path);
                if ($validateSchema && ($field === null || $field['kind'] !== ($layer['type'] === 'image' ? 'image' : 'text'))) {
                    throw new SeoException('incompatible_schema_field', 422, ['fieldPath' => $path]);
                }
            }
            if ($layer['type'] === 'text') {
                if (($layer['binding'] ?? null) === 'cover' || !in_array($layer['textTransform'] ?? 'none', ['none', 'uppercase', 'lowercase', 'capitalize'], true)) {
                    throw new SeoException('invalid_text_transform');
                }
                Support::text($layer['text'] ?? '', 2000);
                foreach (['fontSize' => [8, 160, 48], 'minFontSize' => [8, 160, 24], 'maxLines' => [1, 12, 3], 'lineHeight' => [0.8, 3, 1.2]] as $field => [$min, $max, $default]) {
                    $value = $layer[$field] ?? $default;
                    if (!is_numeric($value) || $value < $min || $value > $max) {
                        throw new SeoException('invalid_text_layout');
                    }
                }
                if (($layer['minFontSize'] ?? 24) > ($layer['fontSize'] ?? 48) || !in_array($layer['align'] ?? 'left', ['left', 'center', 'right'], true)) {
                    throw new SeoException('invalid_text_layout');
                }
                if (!empty($layer['fontId'])) {
                    $this->assets->get('font', $layer['fontId']);
                }
            }
            if ($layer['type'] === 'image') {
                if (isset($layer['binding']) && $layer['binding'] !== 'cover') {
                    throw new SeoException('invalid_layer_binding');
                }
                if (!empty($layer['assetId'])) {
                    $this->assets->get('asset', $layer['assetId']);
                }
                if (!in_array($layer['fit'] ?? 'cover', ['cover', 'contain'], true)) {
                    throw new SeoException('invalid_image_fit');
                }
                if (!is_array($layer['focus'] ?? [0.5, 0.5]) || count($layer['focus'] ?? [0.5, 0.5]) !== 2 || !array_is_list($layer['focus'] ?? [0.5, 0.5])) {
                    throw new SeoException('invalid_image_focus');
                }
                foreach ($layer['focus'] ?? [0.5, 0.5] as $value) {
                    if (!is_numeric($value) || $value < 0 || $value > 1) {
                        throw new SeoException('invalid_image_focus');
                    }
                }
            }
            self::color($layer['color'] ?? '#000000');
        }
        return $document;
    }

    public static function color(string $color): string
    {
        if (!preg_match('/^#[0-9a-fA-F]{6}$/D', $color)) {
            throw new SeoException('invalid_color');
        }
        return $color;
    }

    public function save(?string $id, array $input): array
    {
        return Support::transaction($this->db, function () use ($id, $input): array {
            $current = null;
            if ($id !== null) {
                $current = $this->get($id);
                Support::version($current, $input);
            }
            $id ??= Support::id();
            $document = $this->validate($input['draft'] ?? []);
            $name = Support::text($input['name'] ?? '', 200);
            if ($current && $current['name'] === $name && $current['draft'] === $document) {
                return $current;
            }
            Support::query($this->db, 'INSERT INTO seo_templates(id,name,draft,revision,updated_at) VALUES (?,?,?,1,?) ON CONFLICT(id) DO UPDATE SET name=excluded.name,draft=excluded.draft,revision=seo_templates.revision+1,updated_at=excluded.updated_at', [$id, $name, Support::json($document), Support::timestamp(($this->clock)())]);
            $this->indexDependencies($document, 'template_draft', $id);
            return $this->get($id);
        });
    }

    public function activate(string $id, array $input, ?string $defaultFont = null): array
    {
        $current = $this->get($id);
        Support::version($current, $input);
        $this->validate($current['draft']);
        $this->assertAssignmentScopes($id, $current['draft']);
        if ($current['active_hash'] === hash('sha256', Support::json($current['draft']))) {
            return $current;
        }
        // Network imports happen before the database transaction, only for explicitly selected fonts.
        foreach ($current['draft']['layers'] as $layer) {
            if ($layer['type'] === 'text') {
                $font = $layer['fontId'] ?? $defaultFont;
                if (!$font) {
                    throw new SeoException('font_required');
                }
                $this->assets->fontPath($font);
            }
        }
        return Support::transaction($this->db, function () use ($id, $input): array {
            $current = $this->get($id);
            Support::version($current, $input);
            $this->assertAssignmentScopes($id, $current['draft']);
            $row = Support::one($this->db, 'SELECT COALESCE(MAX(version),0)+1 AS version FROM seo_template_versions WHERE template_id=?', [$id]);
            $version = (int) $row['version'];
            $document = Support::json($current['draft']);
            Support::query($this->db, 'INSERT INTO seo_template_versions(template_id,version,document,hash,created_at) VALUES (?,?,?,?,?)', [$id, $version, $document, hash('sha256', $document), Support::timestamp(($this->clock)())]);
            Support::query($this->db, 'UPDATE seo_templates SET active_version=?,revision=revision+1,updated_at=? WHERE id=?', [$version, Support::timestamp(($this->clock)()), $id]);
            $this->indexDependencies($current['draft'], 'template_version', $id . ':' . $version);
            return $this->get($id);
        });
    }

    public function active(string $id): array
    {
        $row = Support::one($this->db, 'SELECT v.document,v.hash FROM seo_templates t JOIN seo_template_versions v ON v.template_id=t.id AND v.version=t.active_version WHERE t.id=?', [$id]);
        if (!$row) {
            throw new SeoException('template_not_active', 503);
        }
        return Support::decode($row['document']);
    }

    /** Enforce the same scope compatibility as the picker, including API clients. */
    public static function assertCompatible(PDO $db, string $id, string $slot): void
    {
        $row = Support::one($db, 'SELECT t.draft,v.document FROM seo_templates t LEFT JOIN seo_template_versions v ON v.template_id=t.id AND v.version=t.active_version WHERE t.id=?', [$id]);
        if ($row === null) {
            throw new SeoException('resource_not_found');
        }
        self::assertDocumentScope(Support::decode($row['document'] ?? $row['draft']), $slot);
    }

    private static function assertDocumentScope(array $document, string $slot): void
    {
        if (isset($document['schemaSlotKey']) && $document['schemaSlotKey'] !== $slot) {
            throw new SeoException('incompatible_template_scope', 422, ['schemaSlotKey' => $document['schemaSlotKey'], 'slot' => $slot]);
        }
    }

    private function assertAssignmentScopes(string $id, array $document): void
    {
        if (!isset($document['schemaSlotKey'])) {
            return;
        }
        $statement = Support::query($this->db, "SELECT owner_type,owner_id FROM seo_asset_usages WHERE type='template' AND resource_id=?", [$id]);
        while ($usage = $statement->fetch(PDO::FETCH_ASSOC)) {
            if ($usage['owner_type'] === 'slot') {
                self::assertDocumentScope($document, $usage['owner_id']);
            } elseif ($usage['owner_type'] === 'settings') {
                self::assertDocumentScope($document, '');
            } elseif (in_array($usage['owner_type'], ['route', 'document'], true)) {
                $target = Support::one($this->db, 'SELECT kind,slot_key FROM seo_targets WHERE id=?', [explode(':', $usage['owner_id'], 2)[0]]);
                if ($target !== null) {
                    self::assertDocumentScope($document, $target['kind'] === 'route' ? '' : $target['slot_key']);
                }
            }
        }
    }

    public function clone(string $id, string $name): array
    {
        return $this->save(null, ['name' => $name, 'draft' => $this->get($id)['draft']]);
    }

    public function delete(string $id, array $input): void
    {
        Support::transaction($this->db, function () use ($id, $input): void {
            Support::version($this->get($id), $input);
            $usages = $this->assets->usages('template', $id);
            if ($usages) {
                throw new SeoException('resource_in_use', 409, ['usages' => $usages]);
            }
            Support::query($this->db, "DELETE FROM seo_asset_usages WHERE (owner_type='template_draft' AND owner_id=?) OR (owner_type='template_version' AND owner_id LIKE ?)", [$id, $id . ':%']);
            Support::query($this->db, 'DELETE FROM seo_templates WHERE id=?', [$id]);
        });
    }

    private function indexDependencies(array $document, string $ownerType, string $ownerId): void
    {
        Support::query($this->db, 'DELETE FROM seo_asset_usages WHERE owner_type=? AND owner_id=?', [$ownerType, $ownerId]);
        foreach ($document['layers'] as $layer) {
            foreach (['fontId' => 'font', 'assetId' => 'asset'] as $field => $type) {
                if (!empty($layer[$field])) {
                    Support::query($this->db, 'INSERT OR IGNORE INTO seo_asset_usages(type,resource_id,owner_type,owner_id) VALUES (?,?,?,?)', [$type, $layer[$field], $ownerType, $ownerId]);
                }
            }
        }
    }

    public function seed(): void
    {
        foreach (['dark-magazine' => ['Sötét Magazin', '#101827', '#ffffff'], 'light-product' => ['Világos Termék', '#f3f4f6', '#111827']] as $id => [$name, $background, $color]) {
            if (Support::one($this->db, 'SELECT 1 FROM seo_templates WHERE id=?', [$id])) {
                continue;
            }
            $document = ['version' => 1, 'width' => 1200, 'height' => 630, 'background' => ['color' => $background], 'layers' => [
                ['id' => 'brand', 'type' => 'text', 'binding' => 'siteName', 'x' => 80, 'y' => 50, 'width' => 1040, 'height' => 65, 'fontSize' => 24, 'minFontSize' => 18, 'maxLines' => 1, 'color' => $color],
                ['id' => 'title', 'type' => 'text', 'binding' => 'title', 'x' => 80, 'y' => 180, 'width' => 1040, 'height' => 280, 'fontSize' => 48, 'minFontSize' => 30, 'maxLines' => 3, 'color' => $color],
                ['id' => 'author', 'type' => 'text', 'binding' => 'author', 'x' => 80, 'y' => 530, 'width' => 420, 'height' => 50, 'fontSize' => 20, 'minFontSize' => 16, 'maxLines' => 1, 'color' => '#6b7280'],
                ['id' => 'category', 'type' => 'text', 'binding' => 'category', 'x' => 600, 'y' => 530, 'width' => 520, 'height' => 50, 'fontSize' => 20, 'minFontSize' => 16, 'maxLines' => 1, 'align' => 'right', 'color' => '#6b7280'],
            ]];
            if ($id === 'light-product') {
                $document['layers'][1]['width'] = 620;
                array_splice($document['layers'], 1, 0, [[
                    'id' => 'cover', 'type' => 'image', 'binding' => 'cover',
                    'x' => 760, 'y' => 130, 'width' => 400, 'height' => 400,
                    'radius' => 32, 'fit' => 'cover', 'focus' => [0.5, 0.5],
                ]]);
            }
            Support::query($this->db, 'INSERT INTO seo_templates(id,name,draft,revision,updated_at) VALUES (?,?,?,1,?)', [$id, $name, Support::json($document), Support::timestamp(($this->clock)())]);
            // Starter templates remain drafts until a user selects a font and activates them.
        }
    }
}
