<?php
/**
 * NOMAD CMS — bounded, schema-aware social-image field bindings.
 * Exposes suitable scalar leaves and images without traversing relations or hydrating blocks.
 * Localized JSON roots resolve their leaves before falling back to the main language.
 * @package NomadCMS\Services\Seo
 */
declare(strict_types=1);

namespace NomadCMS\Services\Seo;

/** Immutable schema projection and safe value lookup for OG layer sources. */
final class SchemaFields
{
    private const TEXT_TYPES = ['text', 'textarea', 'richtext', 'number', 'email', 'url', 'date', 'time', 'datetime', 'select', 'slug', 'color'];
    private array $fieldCache = [];

    public function __construct(private readonly array $schema)
    {
    }

    public function hasSlot(string $slot): bool
    {
        $definition = $this->schema['slots'][$slot] ?? null;
        return is_array($definition) && in_array($definition['type'] ?? 'object', ['object', 'list', 'collection'], true);
    }

    public function fields(string $slot): array
    {
        if (isset($this->fieldCache[$slot])) {
            return $this->fieldCache[$slot];
        }
        if (!$this->hasSlot($slot)) {
            return [];
        }
        $result = [];
        foreach ($this->schema['slots'][$slot]['fields'] ?? [] as $field) {
            $id = $field['id'] ?? '';
            if (!is_string($id) || !self::validPath($id)) {
                continue;
            }
            $label = is_string($field['label'] ?? null) ? $field['label'] : $id;
            $localized = (bool) ($field['localized'] ?? false);
            $type = $field['type'] ?? '';
            if (in_array($type, self::TEXT_TYPES, true) || $type === 'image') {
                $result[] = ['path' => $id, 'label' => $label, 'type' => $type, 'kind' => $type === 'image' ? 'image' : 'text', 'localized' => $localized];
            } elseif ($type === 'json' && is_array($field['jsonSchema'] ?? null)) {
                // jsonSchema is NOMAD's example object, not a JSON Schema specification.
                $this->jsonLeaves($field['jsonSchema'], $id, $label, $localized, $result);
            }
        }
        return $this->fieldCache[$slot] = $result;
    }

    private function jsonLeaves(array $example, string $path, string $label, bool $localized, array &$result, int $depth = 0): void
    {
        if ($depth >= 8 || array_is_list($example)) {
            return;
        }
        foreach ($example as $key => $value) {
            if (!is_string($key) || !preg_match('/^[\p{L}\p{N}_-]+$/uD', $key)) {
                continue;
            }
            $next = $path . '.' . $key;
            if (is_string($value) || is_int($value) || is_float($value)) {
                $result[] = ['path' => $next, 'label' => $label . ' · ' . $key, 'type' => is_string($value) ? 'text' : 'number', 'kind' => 'text', 'localized' => $localized];
            } elseif (is_array($value)) {
                $this->jsonLeaves($value, $next, $label . ' · ' . $key, $localized, $result, $depth + 1);
            }
        }
    }

    public static function validPath(string $path): bool
    {
        return strlen($path) <= 200 && (bool) preg_match('/^[\p{L}\p{N}_-]+(?:\.[\p{L}\p{N}_-]+)*$/uD', $path);
    }

    public function descriptor(string $slot, string $path): ?array
    {
        foreach ($this->fields($slot) as $field) {
            if ($field['path'] === $path) {
                return $field;
            }
        }
        return null;
    }

    public function value(array $source, string $slot, string $path, string $locale, string $main): mixed
    {
        $descriptor = $this->descriptor($slot, $path);
        if ($descriptor === null) {
            return null;
        }
        $parts = explode('.', $path);
        $value = $source[array_shift($parts)] ?? null;
        $nested = static function (mixed $candidate) use ($parts): mixed {
            foreach ($parts as $part) {
                $candidate = is_array($candidate) ? ($candidate[$part] ?? null) : null;
            }
            return $candidate;
        };
        if ($descriptor['localized'] && is_array($value) && !array_is_list($value) && (array_key_exists($locale, $value) || array_key_exists($main, $value))) {
            return $nested($value[$locale] ?? null) ?? $nested($value[$main] ?? null);
        }
        return $nested($value);
    }

    /** Resolve language maps at any path boundary, including localized JSON roots. */
    public static function localizedPath(array $source, string $path, string $locale, string $main, bool $translatedOnly = false): mixed
    {
        $parts = explode('.', $path);
        $lookup = static function (string $language) use ($source, $parts, $main, $translatedOnly): mixed {
            $value = $source;
            $translated = false;
            foreach ($parts as $part) {
                if (is_array($value) && !array_is_list($value) && (array_key_exists($language, $value) || array_key_exists($main, $value))) {
                    $value = $value[$language] ?? null;
                    $translated = true;
                }
                $value = is_array($value) ? ($value[$part] ?? null) : null;
            }
            if (is_array($value) && !array_is_list($value) && (array_key_exists($language, $value) || array_key_exists($main, $value))) {
                $value = $value[$language] ?? null;
                $translated = true;
            }
            return $translatedOnly && !$translated ? null : $value;
        };
        $local = $lookup($locale);
        if ($translatedOnly || $local !== null || $locale === $main) {
            return $local;
        }
        return $lookup($main);
    }
}
