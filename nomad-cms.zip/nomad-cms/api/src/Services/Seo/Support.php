<?php
/**
 * NOMAD CMS — SEO persistence and validation primitives.
 * Prepared queries, nested transactions and canonical JSON; never owns CMS schemas.
 * @package NomadCMS\Services\Seo
 */
declare(strict_types=1);

namespace NomadCMS\Services\Seo;

use PDO;

/** Small persistence primitives shared by the independent SEO services. */
final class Support
{
    public static function query(PDO $db, string $sql, array $parameters = []): \PDOStatement
    {
        $statement = $db->prepare($sql);
        $statement->execute($parameters);
        return $statement;
    }

    public static function one(PDO $db, string $sql, array $parameters = []): ?array
    {
        $statement = self::query($db, $sql, $parameters);
        $row = $statement->fetch(PDO::FETCH_ASSOC);
        $statement->closeCursor();
        return $row ?: null;
    }

    public static function transaction(PDO $db, callable $operation): mixed
    {
        $nested = $db->inTransaction();
        $savepoint = 'seo_' . bin2hex(random_bytes(6));
        if ($nested) {
            $db->exec('SAVEPOINT ' . $savepoint);
        } else {
            $db->beginTransaction();
        }
        try {
            $value = $operation();
            if ($nested) {
                $db->exec('RELEASE SAVEPOINT ' . $savepoint);
            } else {
                $db->commit();
            }
            return $value;
        } catch (\Throwable $error) {
            if ($nested) {
                $db->exec('ROLLBACK TO SAVEPOINT ' . $savepoint);
                $db->exec('RELEASE SAVEPOINT ' . $savepoint);
            } elseif ($db->inTransaction()) {
                $db->rollBack();
            }
            throw $error;
        }
    }

    public static function json(mixed $value): string
    {
        return json_encode($value, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR);
    }

    public static function decode(?string $json): array
    {
        return $json === null || $json === '' ? [] : json_decode($json, true, 64, JSON_THROW_ON_ERROR);
    }

    public static function id(): string
    {
        return bin2hex(random_bytes(16));
    }

    public static function timestamp(float $time): string
    {
        return gmdate('Y-m-d\TH:i:s', (int) $time) . sprintf('.%06dZ', (int) (($time - floor($time)) * 1000000));
    }

    public static function version(array $row, array $input): void
    {
        if (!isset($input['revision'], $input['client_updated_at'])) {
            throw new SeoException('revision_required');
        }

        // Keep numeric string revisions compatible with PDO clients without coercing
        // malformed strings, fractions, booleans or arrays into a valid revision.
        $revision = $input['revision'];
        if ((!is_int($revision) && (!is_string($revision) || !preg_match('/^(0|[1-9][0-9]*)$/D', $revision)))
            || filter_var($revision, FILTER_VALIDATE_INT, ['options' => ['min_range' => 0]]) === false) {
            throw new SeoException('invalid_revision');
        }
        if (!is_string($input['client_updated_at'])) {
            throw new SeoException('invalid_client_timestamp');
        }
        if ((int) $revision !== (int) $row['revision'] || $input['client_updated_at'] !== $row['updated_at']) {
            throw new SeoException('version_conflict', 409, ['revision' => (int) $row['revision'], 'updated_at' => $row['updated_at']]);
        }
    }

    public static function path(string $path): string
    {
        if ($path === '' || strlen($path) > 2048 || $path[0] !== '/' || str_starts_with($path, '//') || preg_match('/[\x00-\x20\\\\?#]/', $path)) {
            throw new SeoException('invalid_path');
        }
        $segments = explode('/', $path);
        foreach ($segments as &$segment) {
            $decoded = rawurldecode($segment);
            if ($decoded === '.' || $decoded === '..' || preg_match('/[\x00-\x20\/\\\\?#]/', $decoded) || !mb_check_encoding($decoded, 'UTF-8')) {
                throw new SeoException('invalid_path');
            }
            $segment = rawurlencode($decoded);
        }
        return implode('/', $segments);
    }

    public static function locale(string $locale): string
    {
        if (!preg_match('/^[a-z]{2,3}(?:-[A-Za-z0-9]{2,8}){0,2}$/D', $locale)) {
            throw new SeoException('invalid_locale');
        }
        return $locale;
    }

    public static function text(mixed $value, int $maximum = 1000): string
    {
        if (!is_string($value) || !mb_check_encoding($value, 'UTF-8') || mb_strlen($value) > $maximum || preg_match('/[\x00-\x08\x0B\x0C\x0E-\x1F]/', $value)) {
            throw new SeoException('invalid_text');
        }
        return trim($value);
    }

    public static function url(string $url): string
    {
        $parts = parse_url($url);
        if (strlen($url) > 4096 || !$parts || !in_array($parts['scheme'] ?? '', ['https', 'http'], true) || empty($parts['host']) || isset($parts['user'], $parts['pass']) || isset($parts['user']) || preg_match('/[\x00-\x20]/', $url)) {
            throw new SeoException('invalid_url');
        }
        return $url;
    }

    public static function escape(string $value): string
    {
        return htmlspecialchars($value, ENT_QUOTES | ENT_SUBSTITUTE | ENT_HTML5, 'UTF-8');
    }
}
