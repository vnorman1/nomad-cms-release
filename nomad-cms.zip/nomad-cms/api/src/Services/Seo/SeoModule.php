<?php
/**
 * NOMAD CMS — SEO Studio composition root and storage lifecycle integration.
 * Dependencies are injectable; installation is explicit and saves never fetch HTTP or render images.
 * Lifecycle hooks participate in the caller's transaction and physical cleanup waits for commit.
 * @package NomadCMS\Services\Seo
 */
declare(strict_types=1);

namespace NomadCMS\Services\Seo;

use PDO;
use NomadCMS\Database\ContentDatabase;
use NomadCMS\Database\MassiveDatabase;
use NomadCMS\Database\AuthDatabase;
use NomadCMS\Services\RelationService;

/** Public composition root; separate services can also be instantiated directly. */
final class SeoModule
{
    public readonly Settings $settings;
    public readonly TargetRegistry $targets;
    public readonly Metadata $metadata;
    public readonly Assets $assets;
    public readonly Templates $templates;
    public readonly OgRenderer $renderer;
    public readonly OgCache $og;
    public readonly SchemaFields $schemaFields;
    public readonly OgContext $ogContext;
    public readonly Social $social;
    public readonly Auditor $audit;
    public readonly SiteHealth $site;
    public readonly Maintenance $maintenance;
    public readonly AdminProjection $admin;
    public readonly HttpClient $http;
    public readonly FileStore $files;
    public readonly \Closure $clock;
    private static ?\WeakMap $connections = null;
    private static ?\WeakMap $lifecycleModules = null;

    /** Bind a dependency-injected module to storage hooks using this connection (tests/custom hosts). */
    public function bindLifecycle(): void
    {
        self::$lifecycleModules ??= new \WeakMap();
        self::$lifecycleModules[$this->db] = $this;
    }

    public function __construct(
        public readonly PDO $db,
        ?PDO $massive = null,
        ?array $schema = null,
        ?FileStore $files = null,
        ?\Closure $clock = null,
        ?HttpClient $http = null,
        ?HttpClient $google = null,
        ?string $mediaDirectory = null,
    ) {
        if (!Schema::installed($db)) {
            throw new SeoException('migration_required', 503);
        }
        $this->clock = $clock ?? static fn (): float => microtime(true);
        $this->files = $files ?? new FileStore(dirname(__DIR__, 3) . '/storage/seo');
        $this->settings = new Settings($db, $this->clock);
        $config = $this->settings->get()['data'];
        $hosts = $config['httpAllowedHosts'];
        foreach (['publicSiteUrl', 'apiBaseUrl'] as $field) {
            $host = parse_url($config[$field], PHP_URL_HOST);
            if ($host) {
                $hosts[] = $host;
            }
        }
        $this->http = $http ?? new HttpClient(array_values(array_unique($hosts)));
        $this->targets = new TargetRegistry($db, $schema ?? RelationService::loadSchema(), $this->clock);
        $this->schemaFields = new SchemaFields($this->targets->schema);
        $this->assets = new Assets($db, $this->files, $this->clock, $google ?? new HttpClient(['fonts.googleapis.com', 'fonts.gstatic.com']), $mediaDirectory);
        $this->metadata = new Metadata($db, $this->targets, $this->settings, $this->clock, $this->schemaFields, $this->assets);
        $this->templates = new Templates($db, $this->assets, $this->clock, $this->schemaFields);
        $this->ogContext = new OgContext($db, $this->targets, $this->metadata, $this->settings, $this->schemaFields, $this->assets);
        $this->renderer = new OgRenderer($this->assets, $this->templates);
        $this->og = new OgCache($db, $this->metadata, $this->targets, $this->templates, $this->assets, $this->renderer, $this->settings, $this->files, $this->clock, $this->ogContext);
        $this->social = new Social($db, $massive, $this->files, $this->clock);
        $this->audit = new Auditor($db, $this->metadata, $this->settings, $this->http, $this->clock);
        $this->site = new SiteHealth($db, $this->settings, $this->targets, $this->files, $this->clock);
        $this->maintenance = new Maintenance($this);
        $this->admin = new AdminProjection($this);
        $this->metadata->setProjectionRefresher(fn (string $id) => $this->admin->refresh($id));
    }

    public static function production(bool $statistics = false): self
    {
        $db = ContentDatabase::getInstance(false);
        return self::$lifecycleModules[$db] ?? new self($db, $statistics ? MassiveDatabase::getInstance(true) : null);
    }

    public static function migrate(?PDO $db = null, ?PDO $massive = null, ?PDO $auth = null, ?FileStore $files = null, ?array $schema = null): self
    {
        $db ??= ContentDatabase::getInstance();
        Schema::migrate($db, $massive ?? MassiveDatabase::getInstance(), $auth ?? AuthDatabase::getInstance());
        return self::initialize($db, $massive, $schema, $files);
    }

    /** Fresh installations create the latest schema without replaying migrations. */
    public static function install(?PDO $db = null, ?PDO $massive = null, ?PDO $auth = null, ?FileStore $files = null, ?array $schema = null): self
    {
        $db ??= ContentDatabase::getInstance();
        $massive ??= MassiveDatabase::getInstance();
        Schema::install($db, $massive, $auth ?? AuthDatabase::getInstance());
        return self::initialize($db, $massive, $schema, $files);
    }

    /** Seed templates, targets and private storage after explicit schema setup. */
    private static function initialize(PDO $db, ?PDO $massive, ?array $schema, ?FileStore $files): self
    {
        $module = new self($db, $massive, $schema, $files);
        $module->templates->seed();
        $module->targets->importStaticPages();
        foreach ($module->targets->schema['slots'] ?? [] as $slot => $definition) {
            if (($definition['type'] ?? '') !== 'massive') {
                $module->targets->synchronize($slot);
            }
        }
        $module->site->invalidate();
        Support::query($db, 'INSERT OR IGNORE INTO seo_migrations(version,applied_at) VALUES (?,?)', [Schema::VERSION, Support::timestamp(($module->clock)())]);
        $module->files->directory('cache');
        $module->files->write('installed.json', Support::json(['version' => Schema::VERSION]));
        return $module;
    }

    public static function changed(PDO $db, string $slot, ?string $uid = null): void
    {
        if (!Schema::installed($db)) {
            return;
        }
        $module = self::$lifecycleModules[$db] ?? new self($db);
        $module->targets->synchronize($slot, $uid);
        $module->site->invalidate();
        self::$connections ??= new \WeakMap();
        if (!isset(self::$connections[$db])) {
            self::$connections[$db] = true;
            register_shutdown_function(static function () use ($db): void {
                self::afterCommit($db);
            });
        }
        if (!$db->inTransaction()) {
            self::afterCommit($db);
        }
    }

    public static function afterCommit(PDO $db): void
    {
        try {
            if ($db->inTransaction() || !Schema::installed($db)) {
                return;
            }
            (self::$lifecycleModules[$db] ?? new self($db))->maintenance->deletions(microtime(true) + 0.1);
        } catch (\Throwable $error) {
            // Commit has already succeeded. Retry the durable deletion job through cron.
            error_log('[seo.cleanup] ' . $error->getMessage());
        }
    }

    public static function mediaUsages(PDO $db, string $media): array
    {
        if (!Schema::installed($db)) {
            return [];
        }
        return Support::query($db, "SELECT id,name FROM seo_assets WHERE media_id=? UNION ALL SELECT owner_id AS id,'Pending cover import' AS name FROM seo_asset_usages WHERE type='media' AND resource_id=? AND owner_type='cover_pending' LIMIT 100", [$media, $media])->fetchAll(PDO::FETCH_ASSOC);
    }

    public function capabilities(): array
    {
        return ['locales' => $this->targets->locales(), 'mainLocale' => $this->targets->mainLocale(), 'schema_version' => Schema::VERSION, 'gd' => extension_loaded('gd'), 'freetype' => function_exists('imagettfbbox'), 'curl' => extension_loaded('curl'), 'canvas' => ['width' => 1200, 'height' => 630, 'maxLayers' => 30], 'bindings' => Templates::BINDINGS, 'imageModes' => ['inherit', 'generated', 'custom'], 'fonts' => ['bundled' => [], 'upload' => 'static_ttf', 'maxBytes' => 2097152, 'google' => ['recommendations' => Assets::GOOGLE_RECOMMENDATIONS, 'download' => 'on_demand']], 'spaGateway' => ['enabled' => $this->settings->get()['data']['spaGatewayEnabled'], 'bodyRendering' => false]];
    }
}
