<?php
/**
 * NOMAD CMS — explicit, idempotent SEO migrations.
 * Core definitions stay in database.sqlite; statistics and RBAC stay in their own databases.
 * Constructors and ordinary requests never execute schema migrations.
 * @package NomadCMS\Services\Seo
 */
declare(strict_types=1);

namespace NomadCMS\Services\Seo;

use PDO;

/** Owns only seo_* objects and one-time permission grants. */
final class Schema
{
    public const VERSION = 5;

    public static function installed(PDO $db): bool
    {
        return (bool) Support::one($db, "SELECT 1 FROM sqlite_master WHERE type='table' AND name='seo_settings'");
    }

    public static function migrate(PDO $db, ?PDO $massive = null, ?PDO $auth = null): void
    {
        Support::transaction($db, static function () use ($db): void {
            foreach (self::definitions() as $sql) {
                $db->exec($sql);
            }
            Support::query($db, "INSERT OR IGNORE INTO seo_settings(key,value,revision,updated_at) VALUES ('config','{}',1,?)", [Support::timestamp(microtime(true))]);
            self::installTriggers($db);
            if (!Support::one($db, 'SELECT 1 FROM seo_migrations WHERE version=2')) {
                Support::query($db, "INSERT OR IGNORE INTO seo_jobs(kind,job_key,payload) VALUES ('projection_rebuild','all',?)", [Support::json(['cursor' => ''])]);
                Support::query($db, 'INSERT INTO seo_migrations(version,applied_at) VALUES (2,?)', [Support::timestamp(microtime(true))]);
            }
            if (!Support::one($db, 'SELECT 1 FROM seo_migrations WHERE version=3')) {
                $columns = Support::query($db, 'PRAGMA table_info(seo_assets)')->fetchAll(PDO::FETCH_ASSOC);
                if (!in_array('source_hash', array_column($columns, 'name'), true)) {
                    $db->exec('ALTER TABLE seo_assets ADD COLUMN source_hash TEXT');
                }
                $db->exec('CREATE INDEX IF NOT EXISTS seo_asset_media_source ON seo_assets(media_id,source_hash)');
                self::resourceSearch($db);
                Support::query($db, 'INSERT INTO seo_migrations(version,applied_at) VALUES (3,?)', [Support::timestamp(microtime(true))]);
            }
            if (!Support::one($db, 'SELECT 1 FROM seo_migrations WHERE version=4')) {
                $now = Support::timestamp(microtime(true));
                Support::query($db, "DELETE FROM seo_jobs WHERE kind='cms_audit'");
                Support::query($db, "UPDATE seo_audit_runs SET state='cancelled',data=json_set(data,'$.cancelReason','audit_mode_changed'),revision=revision+1,updated_at=? WHERE state IN ('queued','running')", [$now]);
                Support::query($db, 'INSERT INTO seo_migrations(version,applied_at) VALUES (4,?)', [$now]);
            }
            if (!Support::one($db, 'SELECT 1 FROM seo_migrations WHERE version=5')) {
                // Canonical media references share a filename; retain historical IDs and their usages.
                $db->exec('CREATE INDEX IF NOT EXISTS seo_assets_media ON seo_assets(media_id,id)');
                Support::query($db, 'INSERT INTO seo_migrations(version,applied_at) VALUES (5,?)', [Support::timestamp(microtime(true))]);
            }
        });
        self::dependencies($massive, $auth);
    }

    /** Install the current schema directly; historical data upgrades are not run. */
    public static function install(PDO $db, ?PDO $massive = null, ?PDO $auth = null): void
    {
        if (self::installed($db)) {
            if (!Support::one($db, 'SELECT 1 FROM seo_migrations WHERE version=?', [self::VERSION])) {
                throw new \LogicException('SEO schema requires an explicit migration.');
            }
            self::dependencies($massive, $auth);
            return;
        }
        Support::transaction($db, static function () use ($db): void {
            foreach (self::definitions() as $sql) {
                $db->exec($sql);
            }
            Support::query($db, "INSERT INTO seo_settings(key,value,revision,updated_at) VALUES ('config','{}',1,?)", [Support::timestamp(microtime(true))]);
            $db->exec('CREATE INDEX seo_asset_media_source ON seo_assets(media_id,source_hash)');
            $db->exec('CREATE INDEX seo_assets_media ON seo_assets(media_id,id)');
            self::resourceSearch($db, false);
            self::installTriggers($db);
            for ($version = 2; $version <= self::VERSION; $version++) {
                Support::query($db, 'INSERT INTO seo_migrations(version,applied_at) VALUES (?,?)', [$version, Support::timestamp(microtime(true))]);
            }
        });
        self::dependencies($massive, $auth);
    }

    /** Statistics tables and one-time permission grants shared by install and update. */
    private static function dependencies(?PDO $massive, ?PDO $auth): void
    {
        if ($massive) {
            $massive->exec('CREATE TABLE IF NOT EXISTS seo_bot_daily (target_id TEXT NOT NULL, locale TEXT NOT NULL, platform TEXT NOT NULL, day TEXT NOT NULL, gets INTEGER NOT NULL DEFAULT 0, revalidations INTEGER NOT NULL DEFAULT 0, heads INTEGER NOT NULL DEFAULT 0, PRIMARY KEY(target_id,locale,platform,day)) WITHOUT ROWID');
            $massive->exec('CREATE TABLE IF NOT EXISTS seo_bot_batches (id TEXT PRIMARY KEY, processed_at TEXT NOT NULL)');
            $massive->exec('CREATE INDEX IF NOT EXISTS seo_bot_day ON seo_bot_daily(day,target_id)');
        }
        if ($auth) {
            Support::transaction($auth, static function () use ($auth): void {
                $auth->exec('CREATE TABLE IF NOT EXISTS seo_auth_migrations (version INTEGER PRIMARY KEY)');
                if (Support::one($auth, 'SELECT 1 FROM seo_auth_migrations WHERE version=?', [1])) {
                    return;
                }
                foreach (['viewer' => ['read'], 'editor' => ['read', 'update']] as $slug => $actions) {
                    $role = Support::one($auth, 'SELECT id FROM roles WHERE slug=?', [$slug]);
                    if ($role) {
                        foreach ($actions as $action) {
                            Support::query($auth, 'INSERT OR IGNORE INTO role_permissions(role_id,permission) VALUES (?,?)', [$role['id'], 'seo:' . $action . ':*']);
                        }
                    }
                }
                Support::query($auth, 'INSERT INTO seo_auth_migrations(version) VALUES (?)', [1]);
            });
        }
    }

    /** Install indexed resource search only during the explicit migration, including existing rows. */
    private static function resourceSearch(PDO $db, bool $rebuild = true): void
    {
        foreach (['seo_fonts', 'seo_assets', 'seo_templates'] as $table) {
            $fts = $table . '_fts';
            $db->exec("CREATE VIRTUAL TABLE IF NOT EXISTS {$fts} USING fts5(name,id,content='{$table}',content_rowid='rowid',tokenize='unicode61 remove_diacritics 2')");
            $db->exec("CREATE TRIGGER IF NOT EXISTS {$fts}_insert AFTER INSERT ON {$table} BEGIN INSERT INTO {$fts}(rowid,name,id) VALUES (NEW.rowid,NEW.name,NEW.id); END");
            $db->exec("CREATE TRIGGER IF NOT EXISTS {$fts}_delete AFTER DELETE ON {$table} BEGIN INSERT INTO {$fts}({$fts},rowid,name,id) VALUES ('delete',OLD.rowid,OLD.name,OLD.id); END");
            $db->exec("CREATE TRIGGER IF NOT EXISTS {$fts}_update AFTER UPDATE OF name,id ON {$table} BEGIN INSERT INTO {$fts}({$fts},rowid,name,id) VALUES ('delete',OLD.rowid,OLD.name,OLD.id); INSERT INTO {$fts}(rowid,name,id) VALUES (NEW.rowid,NEW.name,NEW.id); END");
            if ($rebuild) {
                $db->exec("INSERT INTO {$fts}({$fts}) VALUES ('rebuild')");
            }
        }
    }

    private static function definitions(): array
    {
        return [
            'CREATE TABLE IF NOT EXISTS seo_settings (key TEXT PRIMARY KEY,value TEXT NOT NULL,revision INTEGER NOT NULL,updated_at TEXT NOT NULL)',
            'CREATE TABLE IF NOT EXISTS seo_targets (id TEXT PRIMARY KEY,kind TEXT NOT NULL,slot_key TEXT NOT NULL DEFAULT \'\',item_uid TEXT NOT NULL DEFAULT \'\',main_locale TEXT NOT NULL,public INTEGER NOT NULL DEFAULT 0,source_revision TEXT NOT NULL DEFAULT \'\',generation INTEGER NOT NULL DEFAULT 1,updated_at TEXT NOT NULL,UNIQUE(kind,slot_key,item_uid))',
            'CREATE INDEX IF NOT EXISTS seo_targets_slot ON seo_targets(slot_key,id)',
            'CREATE TABLE IF NOT EXISTS seo_target_paths (target_id TEXT NOT NULL REFERENCES seo_targets(id) ON DELETE CASCADE,locale TEXT NOT NULL,path TEXT NOT NULL,active INTEGER NOT NULL DEFAULT 1,updated_at TEXT NOT NULL,PRIMARY KEY(target_id,locale,path)) WITHOUT ROWID',
            'CREATE UNIQUE INDEX IF NOT EXISTS seo_active_path ON seo_target_paths(path) WHERE active=1',
            'CREATE INDEX IF NOT EXISTS seo_path_target ON seo_target_paths(target_id,active,locale)',
            'CREATE TABLE IF NOT EXISTS seo_routes (id TEXT PRIMARY KEY REFERENCES seo_targets(id),label TEXT NOT NULL,data TEXT NOT NULL,revision INTEGER NOT NULL,updated_at TEXT NOT NULL)',
            'CREATE TABLE IF NOT EXISTS seo_slot_bindings (slot_key TEXT PRIMARY KEY,data TEXT NOT NULL,revision INTEGER NOT NULL,updated_at TEXT NOT NULL)',
            'CREATE TABLE IF NOT EXISTS seo_documents (target_id TEXT NOT NULL REFERENCES seo_targets(id) ON DELETE CASCADE,locale TEXT NOT NULL,data TEXT NOT NULL,revision INTEGER NOT NULL,updated_at TEXT NOT NULL,modified_by TEXT NOT NULL,PRIMARY KEY(target_id,locale)) WITHOUT ROWID',
            'CREATE TABLE IF NOT EXISTS seo_templates (id TEXT PRIMARY KEY,name TEXT NOT NULL,active_version INTEGER,draft TEXT NOT NULL,revision INTEGER NOT NULL,updated_at TEXT NOT NULL)',
            'CREATE TABLE IF NOT EXISTS seo_template_versions (template_id TEXT NOT NULL REFERENCES seo_templates(id) ON DELETE CASCADE,version INTEGER NOT NULL,document TEXT NOT NULL,hash TEXT NOT NULL,created_at TEXT NOT NULL,PRIMARY KEY(template_id,version)) WITHOUT ROWID',
            'CREATE TABLE IF NOT EXISTS seo_fonts (id TEXT PRIMARY KEY,name TEXT NOT NULL,source TEXT NOT NULL,data TEXT NOT NULL,file TEXT,hash TEXT,revision INTEGER NOT NULL,updated_at TEXT NOT NULL)',
            'CREATE TABLE IF NOT EXISTS seo_assets (id TEXT PRIMARY KEY,name TEXT NOT NULL,media_id TEXT,file TEXT NOT NULL,hash TEXT NOT NULL,width INTEGER NOT NULL,height INTEGER NOT NULL,revision INTEGER NOT NULL,updated_at TEXT NOT NULL,source_hash TEXT)',
            'CREATE TABLE IF NOT EXISTS seo_asset_usages (type TEXT NOT NULL,resource_id TEXT NOT NULL,owner_type TEXT NOT NULL,owner_id TEXT NOT NULL,PRIMARY KEY(type,resource_id,owner_type,owner_id)) WITHOUT ROWID',
            'CREATE INDEX IF NOT EXISTS seo_usage_resource ON seo_asset_usages(resource_id,type)',
            'CREATE INDEX IF NOT EXISTS seo_usage_owner ON seo_asset_usages(owner_type,owner_id)',
            'CREATE TABLE IF NOT EXISTS seo_og_cache (target_id TEXT NOT NULL REFERENCES seo_targets(id) ON DELETE CASCADE,locale TEXT NOT NULL,file TEXT NOT NULL,render_hash TEXT NOT NULL,file_hash TEXT NOT NULL,generation INTEGER NOT NULL,bytes INTEGER NOT NULL,generated_at INTEGER NOT NULL,last_bot_at INTEGER,last_used_at INTEGER NOT NULL,PRIMARY KEY(target_id,locale)) WITHOUT ROWID',
            'CREATE INDEX IF NOT EXISTS seo_og_lru ON seo_og_cache(last_used_at,target_id,locale)',
            'CREATE TABLE IF NOT EXISTS seo_audits (target_id TEXT NOT NULL REFERENCES seo_targets(id) ON DELETE CASCADE,locale TEXT NOT NULL,kind TEXT NOT NULL,source_revision TEXT NOT NULL,result TEXT NOT NULL,created_at TEXT NOT NULL,PRIMARY KEY(target_id,locale,kind)) WITHOUT ROWID',
            'CREATE TABLE IF NOT EXISTS seo_audit_runs (id TEXT PRIMARY KEY,state TEXT NOT NULL,cursor TEXT NOT NULL DEFAULT \'\',processed INTEGER NOT NULL DEFAULT 0,errors INTEGER NOT NULL DEFAULT 0,data TEXT NOT NULL,revision INTEGER NOT NULL,updated_at TEXT NOT NULL)',
            'CREATE TABLE IF NOT EXISTS seo_jobs (id INTEGER PRIMARY KEY AUTOINCREMENT,kind TEXT NOT NULL,job_key TEXT NOT NULL,payload TEXT NOT NULL,attempts INTEGER NOT NULL DEFAULT 0,available_at INTEGER NOT NULL DEFAULT 0,UNIQUE(kind,job_key))',
            'CREATE TABLE IF NOT EXISTS seo_admin_projection (id INTEGER PRIMARY KEY,target_id TEXT NOT NULL REFERENCES seo_targets(id) ON DELETE CASCADE,locale TEXT NOT NULL,title TEXT NOT NULL,path TEXT NOT NULL DEFAULT \'\',source_generation INTEGER NOT NULL,settings_revision INTEGER NOT NULL,effective_revision TEXT NOT NULL,template_id TEXT,template_version INTEGER,cover_status TEXT NOT NULL,image_mode TEXT NOT NULL,indexable INTEGER NOT NULL,UNIQUE(target_id,locale))',
            'CREATE INDEX IF NOT EXISTS seo_projection_locale ON seo_admin_projection(locale,target_id)',
            'CREATE VIRTUAL TABLE IF NOT EXISTS seo_admin_fts USING fts5(title,path,content=\'seo_admin_projection\',content_rowid=\'id\',tokenize=\'unicode61 remove_diacritics 2\')',
            "CREATE TRIGGER IF NOT EXISTS seo_projection_insert AFTER INSERT ON seo_admin_projection BEGIN INSERT INTO seo_admin_fts(rowid,title,path) VALUES (NEW.id,NEW.title,NEW.path); END",
            "CREATE TRIGGER IF NOT EXISTS seo_projection_delete AFTER DELETE ON seo_admin_projection BEGIN INSERT INTO seo_admin_fts(seo_admin_fts,rowid,title,path) VALUES ('delete',OLD.id,OLD.title,OLD.path); END",
            "CREATE TRIGGER IF NOT EXISTS seo_projection_update AFTER UPDATE ON seo_admin_projection BEGIN INSERT INTO seo_admin_fts(seo_admin_fts,rowid,title,path) VALUES ('delete',OLD.id,OLD.title,OLD.path); INSERT INTO seo_admin_fts(rowid,title,path) VALUES (NEW.id,NEW.title,NEW.path); END",
            'CREATE TABLE IF NOT EXISTS seo_migrations (version INTEGER PRIMARY KEY,applied_at TEXT NOT NULL)',
        ];
    }

    /** Atomic backstop for importers and legacy SQL writers bypassing PHP hooks. */
    private static function installTriggers(PDO $db): void
    {
        if (Support::one($db, "SELECT 1 FROM sqlite_master WHERE type='table' AND name='slots'")) {
            foreach (['INSERT' => 'insert', 'UPDATE OF data' => 'update'] as $event => $name) {
                $db->exec("CREATE TRIGGER IF NOT EXISTS seo_slots_{$name} AFTER {$event} ON slots BEGIN
                    UPDATE seo_targets SET generation=generation+1,source_revision='',updated_at=strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE slot_key=NEW.key;
                    INSERT INTO seo_jobs(kind,job_key,payload) VALUES ('sync_slot',NEW.key,json_object('slot',NEW.key)) ON CONFLICT(kind,job_key) DO UPDATE SET payload=excluded.payload;
                    INSERT INTO seo_settings(key,value,revision,updated_at) VALUES ('sitemap_dirty','true',1,strftime('%Y-%m-%dT%H:%M:%fZ','now')) ON CONFLICT(key) DO UPDATE SET value='true',revision=seo_settings.revision+1,updated_at=excluded.updated_at;
                END");
            }
            $db->exec("CREATE TRIGGER IF NOT EXISTS seo_slots_delete AFTER DELETE ON slots BEGIN
                UPDATE seo_targets SET public=0,generation=generation+1,updated_at=strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE slot_key=OLD.key;
                UPDATE seo_target_paths SET active=0 WHERE target_id IN (SELECT id FROM seo_targets WHERE slot_key=OLD.key);
                INSERT INTO seo_jobs(kind,job_key,payload) SELECT 'delete_files',id,json_object('target',id,'generation',generation) FROM seo_targets WHERE slot_key=OLD.key ON CONFLICT(kind,job_key) DO UPDATE SET payload=excluded.payload;
                INSERT INTO seo_settings(key,value,revision,updated_at) VALUES ('sitemap_dirty','true',1,strftime('%Y-%m-%dT%H:%M:%fZ','now')) ON CONFLICT(key) DO UPDATE SET value='true',revision=seo_settings.revision+1,updated_at=excluded.updated_at;
            END");
        }
        if (Support::one($db, "SELECT 1 FROM sqlite_master WHERE type='table' AND name='collection_items'")) {
            foreach (['INSERT' => 'insert', 'UPDATE OF data,published,content_hash' => 'update'] as $event => $name) {
                $db->exec("CREATE TRIGGER IF NOT EXISTS seo_collection_{$name} AFTER {$event} ON collection_items BEGIN
                    UPDATE seo_targets SET public=NEW.published,generation=generation+1,source_revision=NEW.content_hash,updated_at=NEW.updated_at WHERE kind='collection' AND slot_key=NEW.slot_key AND item_uid=NEW.item_uid;
                    UPDATE seo_target_paths SET active=0 WHERE NEW.published=0 AND target_id IN (SELECT id FROM seo_targets WHERE kind='collection' AND slot_key=NEW.slot_key AND item_uid=NEW.item_uid);
                    INSERT INTO seo_jobs(kind,job_key,payload) VALUES ('sync_item',NEW.slot_key||':'||NEW.item_uid,json_object('slot',NEW.slot_key,'uid',NEW.item_uid)) ON CONFLICT(kind,job_key) DO UPDATE SET payload=excluded.payload;
                    INSERT INTO seo_jobs(kind,job_key,payload) SELECT 'delete_files',id,json_object('target',id,'generation',generation) FROM seo_targets WHERE kind='collection' AND slot_key=NEW.slot_key AND item_uid=NEW.item_uid AND NEW.published=0 ON CONFLICT(kind,job_key) DO UPDATE SET payload=excluded.payload;
                    INSERT INTO seo_settings(key,value,revision,updated_at) VALUES ('sitemap_dirty','true',1,strftime('%Y-%m-%dT%H:%M:%fZ','now')) ON CONFLICT(key) DO UPDATE SET value='true',revision=seo_settings.revision+1,updated_at=excluded.updated_at;
                END");
            }
            $db->exec("CREATE TRIGGER IF NOT EXISTS seo_collection_delete AFTER DELETE ON collection_items BEGIN
                UPDATE seo_targets SET public=0,generation=generation+1,updated_at=strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE kind='collection' AND slot_key=OLD.slot_key AND item_uid=OLD.item_uid;
                UPDATE seo_target_paths SET active=0 WHERE target_id IN (SELECT id FROM seo_targets WHERE kind='collection' AND slot_key=OLD.slot_key AND item_uid=OLD.item_uid);
                INSERT INTO seo_jobs(kind,job_key,payload) SELECT 'delete_files',id,json_object('target',id,'generation',generation) FROM seo_targets WHERE kind='collection' AND slot_key=OLD.slot_key AND item_uid=OLD.item_uid ON CONFLICT(kind,job_key) DO UPDATE SET payload=excluded.payload;
                INSERT INTO seo_settings(key,value,revision,updated_at) VALUES ('sitemap_dirty','true',1,strftime('%Y-%m-%dT%H:%M:%fZ','now')) ON CONFLICT(key) DO UPDATE SET value='true',revision=seo_settings.revision+1,updated_at=excluded.updated_at;
            END");
        }
    }
}
