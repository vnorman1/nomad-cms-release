<?php
/**
 * NOMAD CMS — effective multilingual SEO metadata and safe head fragments.
 * Per-field inheritance preserves false values; public reads recheck source publication.
 * @package NomadCMS\Services\Seo
 */
declare(strict_types=1);

namespace NomadCMS\Services\Seo;

use PDO;

/** Metadata resolver shared by HTTP, sitemap, rendering and the local SPA adapter. */
final class Metadata
{
    private const TEXT_FIELDS = ['title', 'description', 'ogTitle', 'ogDescription', 'author', 'category', 'date'];
    private ?\Closure $projectionRefresher = null;

    public function __construct(
        private readonly PDO $db,
        private readonly TargetRegistry $targets,
        private readonly Settings $settings,
        private readonly \Closure $clock,
        private readonly ?SchemaFields $schemaFields = null,
        private readonly ?Assets $assets = null,
    ) {
    }

    /** Refresh this saved target's searchable titles atomically when the composition root provides it. */
    public function setProjectionRefresher(\Closure $refresh): void
    {
        $this->projectionRefresher = $refresh;
    }

    public function document(string $id, string $locale): array
    {
        $this->targets->get($id);
        Support::locale($locale);
        if (!in_array($locale, $this->targets->locales(), true)) {
            throw new SeoException('invalid_locale');
        }
        $row = Support::one($this->db, 'SELECT * FROM seo_documents WHERE target_id=? AND locale=?', [$id, $locale]);
        return ['data' => Support::decode($row['data'] ?? null), 'revision' => (int) ($row['revision'] ?? 0), 'updated_at' => $row['updated_at'] ?? ''];
    }

    public function save(string $id, string $locale, array $input, string $actor): array
    {
        return Support::transaction($this->db, function () use ($id, $locale, $input, $actor): array {
            $document = $this->document($id, $locale);
            Support::version($document, $input);
            $data = array_replace($document['data'], $input['data'] ?? []);
            $allowed = array_fill_keys([...self::TEXT_FIELDS, 'noindex', 'nofollow', 'templateId', 'imageMode', 'customAssetId'], true);
            if (array_diff_key($data, $allowed)) {
                throw new SeoException('unknown_metadata_field');
            }
            foreach ($data as $field => $value) {
                if ($value === null || $value === '') {
                    unset($data[$field]);
                    continue;
                }
                if (in_array($field, self::TEXT_FIELDS, true)) {
                    $data[$field] = Support::text($value);
                } elseif (in_array($field, ['noindex', 'nofollow'], true)) {
                    if (!is_bool($value)) {
                        throw new SeoException('invalid_boolean');
                    }
                } elseif ($field === 'imageMode') {
                    if (!in_array($value, ['inherit', 'generated', 'custom'], true)) {
                        throw new SeoException('invalid_image_mode');
                    }
                } elseif (!is_string($value) || !preg_match('/^[a-zA-Z0-9_-]{1,64}$/D', $value)) {
                    throw new SeoException('invalid_resource_id');
                }
            }
            if (($data['imageMode'] ?? '') === 'custom' && empty($data['customAssetId'])) {
                throw new SeoException('custom_asset_required');
            }
            foreach (['templateId' => 'seo_templates', 'customAssetId' => 'seo_assets'] as $field => $table) {
                if (isset($data[$field]) && !Support::one($this->db, 'SELECT id FROM ' . $table . ' WHERE id=?', [$data[$field]])) {
                    throw new SeoException('resource_not_found', 422, ['field' => $field]);
                }
            }
            if (isset($data['templateId'])) {
                $target = $this->targets->get($id);
                Templates::assertCompatible($this->db, $data['templateId'], $target['kind'] === 'route' ? '' : $target['slot_key']);
            }
            $now = Support::timestamp(($this->clock)());
            Support::query($this->db, 'INSERT INTO seo_documents(target_id,locale,data,revision,updated_at,modified_by) VALUES (?,?,?,1,?,?) ON CONFLICT(target_id,locale) DO UPDATE SET data=excluded.data,revision=seo_documents.revision+1,updated_at=excluded.updated_at,modified_by=excluded.modified_by', [$id, $locale, Support::json($data), $now, $actor]);
            $owner = $id . ':' . $locale;
            Support::query($this->db, "DELETE FROM seo_asset_usages WHERE owner_type='document' AND owner_id=?", [$owner]);
            foreach (['templateId' => 'template', 'customAssetId' => 'asset'] as $field => $type) {
                if (isset($data[$field])) {
                    Support::query($this->db, "INSERT OR IGNORE INTO seo_asset_usages(type,resource_id,owner_type,owner_id) VALUES (?,?,'document',?)", [$type, $data[$field], $owner]);
                }
            }
            Support::query($this->db, 'UPDATE seo_targets SET generation=generation+1,updated_at=? WHERE id=?', [$now, $id]);
            if ($this->projectionRefresher) {
                ($this->projectionRefresher)($id);
                Support::query($this->db, "DELETE FROM seo_jobs WHERE kind='projection' AND job_key=?", [$id]);
            } else {
                Support::query($this->db, "INSERT INTO seo_jobs(kind,job_key,payload) VALUES ('projection',?,?) ON CONFLICT(kind,job_key) DO UPDATE SET payload=excluded.payload", [$id, Support::json(['target' => $id])]);
            }
            return $this->document($id, $locale);
        });
    }

    /** Resolve unsaved card metadata without running checks or hydrating content blocks. */
    public function preview(string $id, string $locale, array $changes): array
    {
        $meta = $this->effective($id, $locale, false, $changes, false);
        unset($meta['context']);
        $searchCard = ['title' => $meta['title'], 'description' => $meta['description'], 'url' => $meta['canonical']];

        return [
            'metadata' => $meta,
            'cards' => [
                'google' => ['mobile' => $searchCard, 'desktop' => $searchCard],
                'facebook' => $meta['og'],
                'linkedin' => $meta['og'],
            ],
        ];
    }

    public function forPath(string $path, ?string $locale = null): array
    {
        $resolved = $this->targets->resolve($path, $locale);
        return $this->effective($resolved['target_id'], $resolved['locale']);
    }

    public function effective(string $id, string $locale, bool $public = true, array $preview = [], bool $includeBody = true, bool $requirePublicUrls = true): array
    {
        Support::locale($locale);
        $target = $this->targets->get($id);
        $source = $this->targets->source($target, !$public && $includeBody);
        if ($public && !$this->targets->isPublic($target, $source)) {
            throw new SeoException('route_unavailable', 404, ['registered' => true]);
        }
        $source ??= [];
        $settings = $this->settings->get()['data'];
        $main = $target['main_locale'];
        $primary = $this->document($id, $main)['data'];
        $local = $locale === $main ? $primary : $this->document($id, $locale)['data'];
        if ($preview) {
            foreach ($preview as $field => $value) {
                if (!in_array($field, [...self::TEXT_FIELDS, 'noindex', 'nofollow', 'templateId', 'imageMode', 'customAssetId'], true)) {
                    throw new SeoException('unknown_metadata_field');
                }
                if ($value !== null && in_array($field, self::TEXT_FIELDS, true)) {
                    Support::text($value);
                }
                if ($value !== null && in_array($field, ['noindex', 'nofollow'], true) && !is_bool($value)) {
                    throw new SeoException('invalid_boolean');
                }
            }
            if (isset($preview['imageMode']) && !in_array($preview['imageMode'], ['inherit', 'generated', 'custom'], true)) {
                throw new SeoException('invalid_image_mode');
            }
            foreach (['templateId' => 'seo_templates', 'customAssetId' => 'seo_assets'] as $field => $table) {
                if (!empty($preview[$field]) && (!is_string($preview[$field]) || !Support::one($this->db, 'SELECT id FROM ' . $table . ' WHERE id=?', [$preview[$field]]))) {
                    throw new SeoException('resource_not_found', 422, ['field' => $field]);
                }
            }
            if (!empty($preview['templateId'])) {
                Templates::assertCompatible($this->db, $preview['templateId'], $target['kind'] === 'route' ? '' : $target['slot_key']);
            }
            $local = array_replace($local, $preview);
            foreach ($local as $field => $value) {
                if ($value === null || $value === '') {
                    unset($local[$field]);
                }
            }
            if ($locale === $main) {
                $primary = $local;
            }
        }
        $binding = $target['kind'] === 'route' ? ['title' => 'title', 'description' => 'description', 'author' => 'author', 'category' => 'category', 'date' => 'date', 'cover' => 'cover', 'body' => 'body', 'templateId' => $source['templateId'] ?? null, 'auditProfile' => $source['auditProfile'] ?? ['minWords' => 0]] : $this->targets->binding($target['slot_key'])['data'];
        $values = [];
        $origins = [];
        foreach ([...self::TEXT_FIELDS, 'noindex', 'nofollow', 'templateId', 'customAssetId'] as $field) {
            $mapped = isset($binding[$field]) ? TargetRegistry::field($source, $binding[$field], $main, $main) : null;
            $mapped = is_scalar($mapped) ? $mapped : null;
            $default = match ($field) {
                'noindex', 'nofollow' => false,
                'templateId' => $binding['templateId'] ?? $settings['defaultTemplateId'],
                default => $settings[$field] ?? '',
            };
            $value = self::present($primary[$field] ?? null) ? $primary[$field] : (self::present($mapped) ? $mapped : $default);
            $origin = self::present($primary[$field] ?? null) ? 'override' : (self::present($mapped) ? 'content' : 'site');
            if ($locale !== $main) {
                $origin = 'main:' . $origin;
            }
            // A real translated content value precedes main-language fallback.
            // Read without fallback here, otherwise a missing translation would mask an override.
            if ($locale !== $main && isset($binding[$field]) && in_array($field, self::TEXT_FIELDS, true)) {
                $translated = TargetRegistry::translatedField($source, $binding[$field], $locale);
                if (is_scalar($translated) && self::present($translated)) {
                    $value = $translated;
                    $origin = 'content';
                }
            }
            if (self::present($local[$field] ?? null)) {
                $value = $local[$field];
                $origin = 'override';
            }
            $values[$field] = $value;
            if (in_array($field, self::TEXT_FIELDS, true) && is_scalar($value)) {
                $values[$field] = mb_substr(trim(strip_tags((string) $value)), 0, 1000);
            }
            $origins[$field] = $origin;
        }
        $imageMode = $local['imageMode'] ?? ($locale === $main ? 'generated' : 'inherit');
        if ($imageMode === 'inherit' && $locale === $main) {
            $imageMode = 'generated';
        }
        $imageLocale = $imageMode === 'inherit' ? $main : $locale;
        $effectiveImageMode = $imageMode === 'inherit' ? ($primary['imageMode'] ?? 'generated') : $imageMode;
        if ($effectiveImageMode === 'inherit') {
            $effectiveImageMode = 'generated';
        }
        if ($imageMode === 'inherit') {
            $values['customAssetId'] = $primary['customAssetId'] ?? '';
        }
        $paths = $this->targets->paths($id);
        $path = null;
        $alternates = [];
        foreach ($paths as $entry) {
            $alternates[$entry['locale']] = $settings['publicSiteUrl'] . $entry['path'];
            if ($entry['locale'] === $locale) {
                $path = $entry['path'];
            }
        }
        $xDefault = $this->targets->schema['i18n']['xDefaultLanguage'] ?? null;
        if ($xDefault && isset($alternates[$xDefault])) {
            $alternates['x-default'] = $alternates[$xDefault];
        }
        if ($public && $path === null) {
            throw new SeoException('locale_unavailable', 404);
        }
        if ($public && $requirePublicUrls && ($settings['publicSiteUrl'] === '' || $settings['apiBaseUrl'] === '')) {
            throw new SeoException('public_urls_required', 503);
        }
        $imageTemplate = $imageMode === 'inherit' ? ($primary['templateId'] ?? $binding['templateId'] ?? $settings['defaultTemplateId']) : $values['templateId'];
        $templateRow = Support::one($this->db, 'SELECT t.name,t.active_version,v.hash,v.document FROM seo_templates t LEFT JOIN seo_template_versions v ON v.template_id=t.id AND v.version=t.active_version WHERE t.id=?', [$imageTemplate]);
        $dependencies = ['template' => $templateRow['hash'] ?? null, 'version' => $templateRow['active_version'] ?? null];
        $rawCover = TargetRegistry::field($source, $binding['cover'], $locale, $main);
        $boundCover = Assets::cover($this->db, $rawCover, $settings['apiBaseUrl'], $this->assets);
        $dependencies['boundCover'] = $boundCover['hash'] ?? null;
        $dependencies['coverSource'] = $this->assets?->sourceFingerprint($rawCover, $settings['apiBaseUrl']);
        $imageDocument = Support::decode($templateRow['document'] ?? null);
        $schemaFields = $this->schemaFields ?? new SchemaFields($this->targets->schema);
        foreach ($imageDocument['layers'] ?? [] as $layer) {
            if (!isset($layer['fieldPath'])) {
                continue;
            }
            $schemaSlot = $imageDocument['schemaSlotKey'] ?? '';
            $descriptor = $schemaFields->descriptor($schemaSlot, $layer['fieldPath']);
            $dependencies['schema:' . $layer['fieldPath']] = $descriptor;
            if ($schemaSlot !== $target['slot_key'] || $descriptor === null) {
                continue;
            }
            $rawField = $schemaFields->value($source, $schemaSlot, $layer['fieldPath'], $locale, $main);
            $dependencies['field:' . $layer['fieldPath']] = $descriptor['kind'] === 'image'
                ? [Assets::cover($this->db, $rawField, $settings['apiBaseUrl'], $this->assets)['hash'] ?? $rawField, $this->assets?->sourceFingerprint($rawField, $settings['apiBaseUrl'])]
                : $rawField;
        }
        foreach (Support::decode($templateRow['document'] ?? null)['layers'] ?? [] as $layer) {
            foreach (['fontId' => 'seo_fonts', 'assetId' => 'seo_assets'] as $field => $table) {
                $resource = $layer[$field] ?? ($field === 'fontId' ? $settings['defaultFontId'] : null);
                if ($resource) {
                    $dependencies[$table . ':' . $resource] = $field === 'assetId' && $this->assets
                        ? $this->assets->resourceFingerprint($resource)
                        : (Support::one($this->db, 'SELECT hash FROM ' . $table . ' WHERE id=?', [$resource])['hash'] ?? null);
                }
            }
        }
        if ($values['customAssetId']) {
            $dependencies['custom'] = $this->assets
                ? $this->assets->resourceFingerprint($values['customAssetId'])
                : (Support::one($this->db, 'SELECT hash FROM seo_assets WHERE id=?', [$values['customAssetId']])['hash'] ?? null);
        }
        $revision = hash('sha256', Support::json([$target, Settings::revisionSettings($settings), $primary, $local, $paths, $alternates, $binding, $dependencies]));
        $canonical = $path === null || $settings['publicSiteUrl'] === '' ? '' : $settings['publicSiteUrl'] . $path;
        $image = $settings['apiBaseUrl'] === '' ? '' : $settings['apiBaseUrl'] . '/seo/og/' . rawurlencode($id) . '.png?lang=' . rawurlencode($imageLocale) . '&v=' . substr($revision, 0, 16);
        if ($settings['publicSiteUrl'] === '') {
            $alternates = [];
        }
        $result = [
            'targetId' => $id, 'locale' => $locale, 'mainLocale' => $main, 'path' => $path,
            'title' => (string) $values['title'], 'description' => (string) $values['description'],
            'canonical' => $canonical, 'hreflang' => $alternates,
            'robots' => ['index' => !$values['noindex'], 'follow' => !$values['nofollow']],
            'og' => ['title' => (string) ($values['ogTitle'] ?: $values['title']), 'description' => (string) ($values['ogDescription'] ?: $values['description']), 'url' => $canonical, 'image' => $image, 'imageWidth' => 1200, 'imageHeight' => 630, 'siteName' => $settings['siteName'], 'type' => $target['kind'] === 'route' ? 'website' : 'article', 'locale' => str_replace('-', '_', $locale)],
            'twitter' => ['card' => 'summary_large_image'],
            'imageMode' => $imageMode, 'effectiveImageMode' => $effectiveImageMode, 'imageLocale' => $imageLocale,
            'imageTemplate' => $effectiveImageMode === 'custom' || !$imageTemplate ? null : [
                'id' => $imageTemplate,
                'name' => $templateRow['name'] ?? $imageTemplate,
                'activeVersion' => isset($templateRow['active_version']) ? (int) $templateRow['active_version'] : null,
            ],
            'templateId' => $values['templateId'], 'customAssetId' => $values['customAssetId'],
            'sources' => $origins, 'revision' => $revision, 'etag' => '"' . $revision . '"',
        ];
        if (!$public) {
            $result['context'] = [
                'title' => $result['og']['title'], 'description' => $result['og']['description'],
                'author' => (string) $values['author'], 'category' => (string) $values['category'], 'date' => (string) $values['date'],
                'siteName' => $settings['siteName'],
                'cover' => $boundCover['id'] ?? null,
                'body' => $includeBody ? TargetRegistry::field($source, $binding['body'], $locale, $main) : null,
            ];
            $result['auditProfile'] = $binding['auditProfile'];
            $result['public'] = $this->targets->isPublic($target, $source);
            $result['coverStatus'] = $boundCover ? 'ready' : ($rawCover ? 'import_required' : 'none');
        }
        $result['head'] = self::head($result);
        return $result;
    }

    private static function present(mixed $value): bool
    {
        return $value !== null && $value !== '';
    }

    public static function head(array $meta): string
    {
        $escape = static fn (mixed $value): string => Support::escape((string) $value);
        $tags = ['<title>' . $escape($meta['title']) . '</title>'];
        $tags[] = '<meta name="description" content="' . $escape($meta['description']) . '">';
        $tags[] = '<meta name="robots" content="' . ($meta['robots']['index'] ? 'index' : 'noindex') . ',' . ($meta['robots']['follow'] ? 'follow' : 'nofollow') . '">';
        if ($meta['canonical'] !== '') {
            Support::url($meta['canonical']);
            $tags[] = '<link rel="canonical" href="' . $escape($meta['canonical']) . '">';
        }
        foreach ($meta['hreflang'] ?? [] as $locale => $url) {
            if ($locale !== 'x-default') {
                Support::locale($locale);
            }
            Support::url($url);
            $tags[] = '<link rel="alternate" hreflang="' . $escape($locale) . '" href="' . $escape($url) . '">';
        }
        foreach (['title', 'description', 'url', 'image', 'siteName', 'type', 'locale', 'imageWidth', 'imageHeight'] as $key) {
            if (!isset($meta['og'][$key])) {
                continue;
            }
            if (in_array($key, ['url', 'image'], true) && $meta['og'][$key] !== '') {
                Support::url($meta['og'][$key]);
            }
            $property = match ($key) {
                'siteName' => 'site_name', 'imageWidth' => 'image:width', 'imageHeight' => 'image:height', default => $key,
            };
            $tags[] = '<meta property="og:' . $property . '" content="' . $escape($meta['og'][$key]) . '">';
        }
        foreach (['card' => $meta['twitter']['card'] ?? 'summary_large_image', 'title' => $meta['og']['title'], 'description' => $meta['og']['description'], 'image' => $meta['og']['image']] as $key => $value) {
            $tags[] = '<meta name="twitter:' . $key . '" content="' . $escape($value) . '">';
        }
        return implode("\n", $tags);
    }
}
