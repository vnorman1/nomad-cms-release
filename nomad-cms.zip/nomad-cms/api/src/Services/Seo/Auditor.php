<?php
/**
 * NOMAD CMS — CMS and initial-HTML audit scorecards.
 * Rules deduct once per code, retain evidence and distinguish server metadata from client-only content.
 * DOM parsing is bounded and never resolves external entities or executes JavaScript.
 * @package NomadCMS\Services\Seo
 */
declare(strict_types=1);

namespace NomadCMS\Services\Seo;

use PDO;

/** Extensible rules, saved audit snapshots and unsaved preview card models. */
final class Auditor
{
    public const RULE_VERSION = 'seo-audit-v2';
    private array $rules = [];

    public function __construct(private readonly PDO $db, private readonly Metadata $metadata, private readonly Settings $settings, private readonly HttpClient $http, private readonly \Closure $clock)
    {
    }

    public function register(string $code, callable $rule): void
    {
        if (!preg_match('/^[a-z0-9_.-]{1,80}$/D', $code)) {
            throw new SeoException('invalid_rule_code');
        }
        $this->rules[$code] = $rule;
    }

    public static function score(array $issues): array
    {
        $score = 100;
        $seen = [];
        $critical = false;
        foreach ($issues as $issue) {
            if (!isset($seen[$issue['code']])) {
                $score -= $issue['severity'] === 'error' ? 10 : ($issue['severity'] === 'warning' ? 3 : 0);
                $seen[$issue['code']] = true;
            }
            $critical = $critical || ($issue['critical'] ?? false);
        }
        $score = max(0, $score);
        return ['score' => $score, 'color' => $critical || $score < 50 ? 'red' : ($score < 80 ? 'yellow' : 'green'), 'critical' => $critical];
    }

    private static function issue(string $code, string $severity, mixed $evidence, string $suggestion, bool $critical = false): array
    {
        return compact('code', 'severity', 'evidence', 'suggestion', 'critical');
    }

    public function cms(string $id, string $locale, array $preview = [], bool $save = true): array
    {
        $meta = $this->metadata->effective($id, $locale, false, $preview);
        $issues = $this->lengthRules($meta['title'], $meta['description'], $meta['auditProfile']);
        if (!$meta['public']) {
            $issues[] = self::issue('availability.unpublished', 'info', false, 'Publish this target before sharing it.');
        }
        if (!$meta['robots']['index']) {
            $issues[] = self::issue('indexing.noindex', 'info', 'noindex', 'Enable indexing when this page should appear in search.');
        }
        if ($meta['canonical'] === '') {
            $issues[] = self::issue('head.canonical', 'error', ['path' => $meta['path'], 'value' => ''], 'Configure the public site URL and a registered path for this language.', true);
        }
        if ($meta['og']['image'] === '') {
            $issues[] = self::issue('image.public_url', 'error', '', 'Configure the public API base URL so social platforms can retrieve the share image.', true);
        }
        $imageMeta = $meta['imageLocale'] === $locale ? $meta : $this->metadata->effective($id, $meta['imageLocale'], false, [], false);
        $template = Support::one($this->db, 'SELECT active_version FROM seo_templates WHERE id=?', [$imageMeta['templateId']]);
        if ($meta['effectiveImageMode'] === 'generated' && empty($template['active_version'])) {
            $issues[] = self::issue('image.template_unpublished', 'error', $imageMeta['templateId'], 'Publish the selected image template before sharing this page.');
        }
        $config = $this->settings->get()['data'];
        if ($meta['robots']['index'] && $meta['path'] && !SiteHealth::allows($config['robots'], $meta['path'])) {
            $issues[] = self::issue('indexing.robots_blocked', 'warning', $meta['path'], 'Review the robots.txt rules that prevent crawling this registered page.');
        }
        $body = self::bodyHtml($meta['context']['body']);
        $hasBody = trim($body) !== '';
        $html = '<html><head></head><body><main>' . $body . '</main></body></html>';
        [$dom, $xpath] = $this->parse($html);
        $metrics = $this->bodyMetrics($xpath);
        if ($hasBody) {
            // Stored blocks cannot prove the final page's H1: the website often renders it separately.
            $issues = [...$issues, ...$this->bodyRules($xpath, $meta['auditProfile'], $metrics, false)];
        }
        foreach ($this->rules as $code => $rule) {
            $custom = $rule($meta, $xpath, 'cms');
            if ($custom) {
                $issues[] = $custom + ['code' => $code];
            }
        }
        $result = $this->snapshot($issues, 'cms', $meta['revision']) + [
            'url' => $meta['canonical'],
            'metrics' => $metrics,
            'checked' => ['metadata', 'public_configuration', 'social_template', ...($hasBody ? ['stored_body'] : [])],
            'skipped' => ['website_html', 'website_heading', ...(!$hasBody ? ['stored_body'] : [])],
        ];
        if ($save && !$preview) {
            $this->persist($id, $locale, $result);
        }
        return $result;
    }

    public function live(string $id, string $locale): array
    {
        $meta = $this->metadata->effective($id, $locale, true, [], false);
        try {
            $response = $this->http->get($meta['canonical']);
            $result = $this->html($response['body'], $meta, $response);
        } catch (SeoException $error) {
            $issues = [self::issue('http.fetch_failed', 'error', $error->errorCode, 'Check the public URL, allowlist, TLS and hosting configuration.', true)];
            $result = $this->snapshot($issues, 'live', $meta['revision']) + ['url' => $meta['canonical'], 'checked' => ['http'], 'skipped' => ['website_html', 'website_body']];
        }
        $this->persist($id, $locale, $result);
        return $result;
    }

    public function html(string $html, array $expected, array $response = ['status' => 200, 'headers' => [], 'redirects' => []]): array
    {
        if (strlen($html) > 2097152) {
            throw new SeoException('html_size_limit');
        }
        $issues = [];
        if ($response['status'] !== 200) {
            $issues[] = self::issue('http.status', 'error', $response['status'], 'Serve an accessible public page with HTTP 200.', true);
        }
        $contentType = strtolower(trim(explode(';', $response['headers']['content-type'] ?? '')[0]));
        if ($contentType !== '' && !in_array($contentType, ['text/html', 'application/xhtml+xml'], true)) {
            $issues[] = self::issue('http.content_type', 'error', $contentType, 'Serve this page as HTML rather than an API response, download or image.', true);
        }
        if ($response['status'] === 200 && trim($html) === '') {
            $issues[] = self::issue('http.empty_body', 'error', 0, 'Return the page HTML in the public response; an empty response cannot be inspected or shared.', true);
        }
        if ($issues) {
            return $this->snapshot($issues, 'live', $expected['revision']) + [
                'url' => $response['url'] ?? $expected['canonical'],
                'checked' => ['http'],
                'skipped' => ['website_html', 'website_body'],
                'server_metadata' => false,
                'client_only_body' => false,
            ];
        }
        [$dom, $xpath] = $this->parse($html);
        if (!empty($response['redirects'])) {
            $issues[] = self::issue('http.redirect', 'warning', $response['redirects'], 'Register the final canonical URL directly.');
        }
        $profile = $expected['auditProfile'] ?? $this->metadata->effective($expected['targetId'], $expected['locale'], false, [], false)['auditProfile'];
        $titleNodes = $xpath->query('//head/title');
        $descriptionNodes = $xpath->query('//head/meta[translate(@name,"ABCDEFGHIJKLMNOPQRSTUVWXYZ","abcdefghijklmnopqrstuvwxyz")="description"]');
        $title = $titleNodes->item(0)?->textContent ?? '';
        $description = $descriptionNodes->item(0)?->getAttribute('content') ?? '';
        $bodyMetrics = $this->bodyMetrics($xpath);
        $clientOnly = $bodyMetrics['characters'] < 30 && $xpath->query('//*[@id="root" or @id="app"]')->length > 0 && $xpath->query('//script[@src]')->length > 0;
        $issues = [...$issues, ...$this->lengthRules(trim($title), trim($description), $profile), ...(!$clientOnly ? $this->bodyRules($xpath, $profile, $bodyMetrics) : [])];
        foreach (['title' => $titleNodes->length, 'description' => $descriptionNodes->length] as $field => $count) {
            if ($count > 1) {
                $issues[] = self::issue('head.duplicate_' . $field, 'error', $count, 'Keep exactly one ' . $field . ' in the initial head.');
            }
        }
        foreach (['title' => $title, 'description' => $description] as $field => $value) {
            if (trim($value) !== $expected[$field]) {
                $issues[] = self::issue('cms_html.' . $field, 'warning', ['cms' => $expected[$field], 'html' => mb_substr($value, 0, 1000)], 'Synchronize the server-rendered metadata with the CMS.');
            }
        }
        $canonicalNodes = $xpath->query('//head/link[translate(@rel,"ABCDEFGHIJKLMNOPQRSTUVWXYZ","abcdefghijklmnopqrstuvwxyz")="canonical"]');
        if ($canonicalNodes->length !== 1 || $canonicalNodes->item(0)?->getAttribute('href') !== $expected['canonical']) {
            $issues[] = self::issue('head.canonical', 'error', ['count' => $canonicalNodes->length, 'value' => $canonicalNodes->item(0)?->getAttribute('href')], 'Emit one canonical link to the registered language URL.');
        }
        $robots = [];
        foreach ($xpath->query('//head/meta[translate(@name,"ABCDEFGHIJKLMNOPQRSTUVWXYZ","abcdefghijklmnopqrstuvwxyz")="robots"]') as $node) {
            $robots[] = strtolower($node->getAttribute('content'));
        }
        $robots[] = strtolower($response['headers']['x-robots-tag'] ?? '');
        $noindex = (bool) preg_match('/\b(noindex|none)\b/', implode(',', $robots));
        if ($noindex) {
            $indexable = $expected['robots']['index'];
            $issues[] = self::issue('indexing.noindex', $indexable ? 'error' : 'info', $robots, $indexable ? 'Remove noindex when this page should be indexed.' : 'This page intentionally excludes search indexing, matching its saved settings.', $indexable);
        } elseif (!$expected['robots']['index']) {
            $issues[] = self::issue('indexing.unexpected_indexable', 'error', $robots, 'Emit noindex in the public HTML or HTTP headers to match this page’s saved privacy setting.', true);
        }
        $actualAlternates = [];
        foreach ($xpath->query('//head/link[@hreflang]') as $node) {
            $actualAlternates[$node->getAttribute('hreflang')] = $node->getAttribute('href');
        }
        foreach ($expected['hreflang'] as $locale => $url) {
            if (($actualAlternates[$locale] ?? '') !== $url) {
                $issues[] = self::issue('head.hreflang', 'warning', ['locale' => $locale, 'value' => $actualAlternates[$locale] ?? null], 'Use the actual registered language alternatives.');
            }
        }
        $social = [];
        foreach ($xpath->query('//head/meta[@property or @name]') as $node) {
            $key = strtolower($node->getAttribute('property') ?: $node->getAttribute('name'));
            $social[$key][] = $node->getAttribute('content');
        }
        foreach (['og:title' => $expected['og']['title'], 'og:description' => $expected['og']['description'], 'og:image' => $expected['og']['image'], 'og:url' => $expected['canonical'], 'twitter:card' => 'summary_large_image'] as $key => $value) {
            if (count($social[$key] ?? []) !== 1 || ($social[$key][0] ?? '') !== $value) {
                $issues[] = self::issue('head.social.' . str_replace(':', '_', $key), 'warning', $social[$key] ?? [], 'Emit one matching ' . $key . ' tag in the initial HTML.');
            }
        }
        if ($clientOnly) {
            $issues[] = self::issue('body.client_rendered', 'warning', ['initial_text_characters' => $bodyMetrics['characters']], 'Use SSR/SSG for crawlable body content; metadata injection only prepares the head.');
        }
        foreach ($this->rules as $code => $rule) {
            $custom = $rule($expected, $xpath, 'live');
            if ($custom) {
                $issues[] = $custom + ['code' => $code];
            }
        }
        return $this->snapshot($issues, 'live', $expected['revision']) + [
            'url' => $response['url'] ?? $expected['canonical'],
            'metrics' => $bodyMetrics,
            'checked' => ['http', 'website_html', ...(!$clientOnly ? ['website_body'] : [])],
            'skipped' => $clientOnly ? ['website_body'] : [],
            'server_metadata' => !array_filter($issues, static fn ($issue) => (str_starts_with($issue['code'], 'head.') && !str_ends_with($issue['code'], '_length')) || str_starts_with($issue['code'], 'cms_html.')),
            'client_only_body' => $clientOnly,
        ];
    }

    /** Preserve explicit check scope and counts alongside the immutable saved evidence. */
    private function snapshot(array $issues, string $kind, string $revision): array
    {
        $counts = ['error' => 0, 'warning' => 0, 'info' => 0];
        foreach ($issues as $issue) {
            $counts[$issue['severity']]++;
        }

        return self::score($issues) + [
            'issues' => $issues,
            'counts' => $counts,
            'kind' => $kind,
            'rule_version' => self::RULE_VERSION,
            'revision' => $revision,
            'checked_at' => Support::timestamp(($this->clock)()),
        ];
    }

    private function lengthRules(string $title, string $description, array $profile): array
    {
        $issues = [];
        foreach (['title' => [$title, $profile['titleMin'] ?? 30, $profile['titleMax'] ?? 60], 'description' => [$description, $profile['descriptionMin'] ?? 70, $profile['descriptionMax'] ?? 160]] as $field => [$value, $min, $max]) {
            $length = mb_strlen($value);
            if ($length === 0) {
                $issues[] = self::issue('head.missing_' . $field, 'error', 0, 'Provide a descriptive ' . $field . '.');
            } elseif ($length < $min || $length > $max) {
                $issues[] = self::issue('head.' . $field . '_length', 'warning', ['characters' => $length, 'recommended' => [$min, $max]], 'Review this editorial length recommendation; search engines may rewrite snippets.');
            }
        }
        return $issues;
    }

    private function parse(string $html): array
    {
        if (strlen($html) > 2097152) {
            throw new SeoException('html_size_limit');
        }
        $offset = 0;
        $nodes = 0;
        while (preg_match('/<[a-zA-Z][^>]*>/', $html, $match, PREG_OFFSET_CAPTURE, $offset)) {
            $offset = $match[0][1] + strlen($match[0][0]);
            if (++$nodes > 12000) {
                throw new SeoException('html_complexity_limit');
            }
        }
        $previous = libxml_use_internal_errors(true);
        try {
            $dom = new \DOMDocument();
            $dom->loadHTML('<?xml encoding="UTF-8">' . $html, LIBXML_NONET | LIBXML_COMPACT | LIBXML_NOERROR | LIBXML_NOWARNING);
            return [$dom, new \DOMXPath($dom)];
        } finally {
            libxml_clear_errors();
            libxml_use_internal_errors($previous);
        }
    }

    private function bodyRoot(\DOMXPath $xpath): \DOMNode
    {
        return $xpath->query('//main')->item(0) ?? $xpath->query('//article')->item(0) ?? $xpath->query('//body')->item(0) ?? $xpath->document->documentElement;
    }

    /** Count one text node at a time; never duplicate the complete HTML body in PHP memory. */
    private function bodyMetrics(\DOMXPath $xpath): array
    {
        $root = $this->bodyRoot($xpath);
        $words = 0;
        $characters = 0;
        foreach ($xpath->query('.//text()[not(ancestor::nav or ancestor::script or ancestor::style or ancestor::noscript or ancestor::header or ancestor::footer)]', $root) as $node) {
            $text = trim(preg_replace('/\s+/u', ' ', $node->nodeValue));
            if ($text === '') {
                continue;
            }
            $words += preg_match_all('/[\p{L}\p{N}]+(?:[\x27’-][\p{L}\p{N}]+)*/u', $text);
            $characters += mb_strlen($text) + ($characters > 0 ? 1 : 0);
        }
        return ['words' => $words, 'characters' => $characters];
    }

    private function bodyRules(\DOMXPath $xpath, array $profile, ?array $metrics = null, bool $checkPrimaryHeading = true): array
    {
        $issues = [];
        $root = $this->bodyRoot($xpath);
        $h1 = $xpath->query('.//h1', $root)->length;
        if ($checkPrimaryHeading && $h1 !== 1) {
            $issues[] = self::issue('body.h1', $h1 === 0 ? 'error' : 'warning', $h1, 'Use one descriptive primary heading.');
        }
        $previous = 0;
        foreach ($xpath->query('.//h1|.//h2|.//h3|.//h4|.//h5|.//h6', $root) as $heading) {
            $level = (int) substr($heading->nodeName, 1);
            if ($previous > 0 && $level > $previous + 1) {
                $issues[] = self::issue('body.heading_hierarchy', 'warning', ['previous' => $previous, 'next' => $level], 'Avoid skipping heading levels.');
            }
            $previous = $level;
        }
        foreach ($xpath->query('.//img[not(@alt)]', $root) as $image) {
            $issues[] = self::issue('body.image_alt', 'warning', mb_substr($image->getAttribute('src'), 0, 300), 'Add alternative text; an empty alt is valid for decorative images.');
        }
        $words = ($metrics ?? $this->bodyMetrics($xpath))['words'];
        $minimum = max(0, (int) ($profile['minWords'] ?? 300));
        if ($minimum > 0 && $words < $minimum) {
            $issues[] = self::issue('body.short', 'warning', ['words' => $words, 'recommended' => $minimum], 'Review whether the page sufficiently covers its topic.');
        }
        return $issues;
    }

    public static function bodyHtml(mixed $body, int $depth = 0): string
    {
        if ($depth > 64) {
            throw new SeoException('body_complexity_limit');
        }
        if (is_string($body)) {
            if (strlen($body) > 2097152) {
                throw new SeoException('body_size_limit');
            }
            return $body;
        }
        if (!is_array($body)) {
            return '';
        }
        if (isset($body['innerHTML'])) {
            $html = (string) $body['innerHTML'] . self::bodyHtml($body['innerBlocks'] ?? [], $depth + 1);
            if (strlen($html) > 2097152) {
                throw new SeoException('body_size_limit');
            }
            return $html;
        }
        if (isset($body['text']) && is_string($body['text'])) {
            return '<p>' . Support::escape($body['text']) . '</p>';
        }
        $html = '';
        foreach ($body as $key => $value) {
            if (is_int($key) || in_array($key, ['content', 'innerBlocks', 'blocks'], true)) {
                $html .= self::bodyHtml($value, $depth + 1);
                if (strlen($html) > 2097152) {
                    throw new SeoException('body_size_limit');
                }
            }
        }
        return $html;
    }

    private function persist(string $id, string $locale, array $result): void
    {
        Support::query($this->db, 'INSERT INTO seo_audits(target_id,locale,kind,source_revision,result,created_at) VALUES (?,?,?,?,?,?) ON CONFLICT(target_id,locale,kind) DO UPDATE SET source_revision=excluded.source_revision,result=excluded.result,created_at=excluded.created_at', [$id, $locale, $result['kind'], $result['revision'], Support::json($result), Support::timestamp(($this->clock)())]);
    }

    /** Read saved evidence and freshness only; opening an editor must never execute rules. */
    public function result(string $id, string $locale): array
    {
        $meta = $this->metadata->effective($id, $locale, false, [], false);
        $results = [];
        foreach (Support::query($this->db, 'SELECT * FROM seo_audits WHERE target_id=? AND locale=?', [$id, $locale])->fetchAll(PDO::FETCH_ASSOC) as $row) {
            $results[$row['kind']] = Support::decode($row['result']) + ['created_at' => $row['created_at']];
        }
        $cms = $results['cms'] ?? null;
        $live = $results['live'] ?? null;
        $cmsCurrent = $cms && ($cms['revision'] ?? null) === $meta['revision'] && ($cms['rule_version'] ?? null) === self::RULE_VERSION;
        $liveCurrent = $live && ($live['revision'] ?? null) === $meta['revision'] && ($live['rule_version'] ?? null) === self::RULE_VERSION
            && ($this->clock)() - strtotime($live['created_at']) <= $this->settings->get()['data']['liveAuditMaxAge'];
        $overall = $cmsCurrent ? ($liveCurrent ? min($cms['score'], $live['score']) : $cms['score']) : null;
        $critical = ($cmsCurrent && ($cms['critical'] ?? false)) || ($liveCurrent && ($live['critical'] ?? false));

        return [
            'cms' => $cms,
            'live' => $live,
            'cms_state' => $cms === null ? 'not_checked' : ($cmsCurrent ? 'current' : 'stale'),
            'live_state' => $live === null ? 'not_checked' : ($liveCurrent ? 'current' : 'stale'),
            'provisional' => !$cmsCurrent || !$liveCurrent,
            'score' => $overall,
            'color' => $overall === null ? null : ($critical || $overall < 50 ? 'red' : ($overall < 80 ? 'yellow' : 'green')),
        ];
    }

    public function preview(string $id, string $locale, array $changes): array
    {
        return $this->metadata->preview($id, $locale, $changes);
    }
}
