<?php
/**
 * NOMAD CMS — SEO targets and exact multilingual route registry.
 * Stores stable references, never duplicates collections; source reads remain row-backed.
 * Active paths are unique and removed paths remain tombstones for the SPA gateway.
 * @package NomadCMS\Services\Seo
 */
declare(strict_types=1);

namespace NomadCMS\Services\Seo;

use PDO;
use NomadCMS\Services\PublicPayloadService;

/** Source adapter, resumable indexer and static route repository. */
final class TargetRegistry
{
    public function __construct(
        private readonly PDO $db,
        public readonly array $schema,
        private readonly \Closure $clock,
    ) {
    }

    public function mainLocale(): string
    {
        return Support::locale($this->schema['i18n']['defaultLanguage'] ?? 'hu');
    }

    public function locales(): array
    {
        $i18n = $this->schema['i18n'] ?? [];
        if (empty($i18n['enabled'])) {
            return [$this->mainLocale()];
        }
        return array_map(static fn ($locale) => Support::locale(is_array($locale) ? $locale['code'] : $locale), $i18n['languages'] ?? [$this->mainLocale()]);
    }

    public function get(string $id): array
    {
        return Support::one($this->db, 'SELECT * FROM seo_targets WHERE id=?', [$id]) ?? throw new SeoException('target_not_found', 404);
    }

    public function list(string $cursor = '', int $limit = 50, ?string $slot = null): array
    {
        $limit = max(1, min(100, $limit));
        $sql = 'SELECT * FROM seo_targets WHERE id>?';
        $parameters = [$cursor];
        if ($slot !== null) {
            $sql .= ' AND slot_key=?';
            $parameters[] = $slot;
        }
        $parameters[] = $limit + 1;
        $rows = Support::query($this->db, $sql . ' ORDER BY id LIMIT CAST(? AS INTEGER)', $parameters)->fetchAll(PDO::FETCH_ASSOC);
        $more = count($rows) > $limit;
        if ($more) {
            array_pop($rows);
        }
        return ['items' => $rows, 'next_cursor' => $more ? end($rows)['id'] : null];
    }

    public function binding(string $slot): array
    {
        $definition = $this->schema['slots'][$slot] ?? throw new SeoException('slot_not_found', 404);
        $row = Support::one($this->db, 'SELECT * FROM seo_slot_bindings WHERE slot_key=?', [$slot]);
        $fields = $definition['fields'] ?? [];
        $images = array_values(array_filter($fields, static fn ($field) => ($field['type'] ?? '') === 'image'));
        $cover = $definition['coverField'] ?? (in_array('cover', array_column($fields, 'id'), true) ? 'cover' : ($images[0]['id'] ?? 'cover'));
        $defaults = [
            'title' => $definition['titleField'] ?? 'title',
            'description' => $definition['summaryField'] ?? 'description',
            'slug' => $definition['slugField'] ?? 'slug',
            'author' => 'author', 'category' => 'category', 'date' => 'date',
            'cover' => $cover, 'body' => 'content',
            'urlPattern' => $definition['urlPattern'] ?? '',
            'paths' => [], 'templateId' => null, 'auditProfile' => ['minWords' => 300],
        ];
        $data = array_replace($defaults, Support::decode($row['data'] ?? null));
        // Older settings forms persisted the literal default even when the slot had no cover field.
        if ($data['cover'] === 'cover' && !in_array('cover', array_column($fields, 'id'), true)) {
            $data['cover'] = $cover;
        }
        return ['data' => $data, 'revision' => (int) ($row['revision'] ?? 0), 'updated_at' => $row['updated_at'] ?? ''];
    }

    public function saveBinding(string $slot, array $input): array
    {
        return Support::transaction($this->db, function () use ($slot, $input): array {
            $current = $this->binding($slot);
            Support::version($current, $input);
            $data = array_replace($current['data'], $input['data'] ?? []);
            if (!empty($data['templateId'])) {
                Templates::assertCompatible($this->db, $data['templateId'], $slot);
            }
            foreach (['title', 'description', 'slug', 'author', 'category', 'date', 'cover', 'body'] as $field) {
                if (!is_string($data[$field]) || !preg_match('/^[a-zA-Z0-9_.-]*$/D', $data[$field])) {
                    throw new SeoException('invalid_field_binding');
                }
            }
            foreach ([$data['urlPattern'], ...array_values($data['paths'])] as $pattern) {
                if (!is_string($pattern) || strlen($pattern) > 2048 || ($pattern !== '' && $pattern[0] !== '/') || preg_match('/\{(?!slug\}|id\}|lang\})/', $pattern)) {
                    throw new SeoException('invalid_url_pattern');
                }
            }
            foreach ($data['paths'] as $locale => $pattern) {
                if (!in_array(Support::locale($locale), $this->locales(), true)) {
                    throw new SeoException('invalid_binding_locale');
                }
            }
            self::profile($data['auditProfile']);
            if (Support::json($data) === Support::json($current['data'])) {
                return $current;
            }
            Support::query($this->db, 'INSERT INTO seo_slot_bindings(slot_key,data,revision,updated_at) VALUES (?,?,1,?) ON CONFLICT(slot_key) DO UPDATE SET data=excluded.data,revision=seo_slot_bindings.revision+1,updated_at=excluded.updated_at', [$slot, Support::json($data), Support::timestamp(($this->clock)())]);
            $this->indexTemplateUsage('slot', $slot, $data['templateId']);
            // Only route changes require a slot-wide path rebuild. Metadata is resolved from live bindings.
            if (array_intersect_key($data, array_flip(['slug', 'urlPattern', 'paths'])) !== array_intersect_key($current['data'], array_flip(['slug', 'urlPattern', 'paths']))) {
                $kind = ($this->schema['slots'][$slot]['type'] ?? '') === 'collection' ? 'index' : 'sync_slot';
                Support::query($this->db, 'INSERT INTO seo_jobs(kind,job_key,payload) VALUES (?,?,?) ON CONFLICT(kind,job_key) DO UPDATE SET payload=excluded.payload', [$kind, $slot, Support::json(['slot' => $slot, 'cursor' => 0])]);
            }
            return $this->binding($slot);
        });
    }

    public function paths(string $id): array
    {
        return Support::query($this->db, 'SELECT locale,path FROM seo_target_paths WHERE target_id=? AND active=1 ORDER BY locale', [$id])->fetchAll(PDO::FETCH_ASSOC);
    }

    public function resolve(string $path, ?string $locale = null): array
    {
        $path = Support::path($path);
        $row = Support::one($this->db, 'SELECT p.*,t.public FROM seo_target_paths p JOIN seo_targets t ON t.id=p.target_id WHERE p.path=? ORDER BY p.active DESC,p.updated_at DESC LIMIT 1', [$path]);
        if (!$row) {
            throw new SeoException('route_unregistered', 404, ['registered' => false]);
        }
        if (!$row['active'] || !$row['public']) {
            throw new SeoException('route_unavailable', 404, ['registered' => true]);
        }
        if ($locale !== null && $locale !== $row['locale']) {
            throw new SeoException('locale_path_mismatch');
        }
        return $row;
    }

    public function source(array $target, bool $blocks = true): ?array
    {
        if ($target['kind'] === 'route') {
            $row = Support::one($this->db, 'SELECT data FROM seo_routes WHERE id=?', [$target['id']]);
            return $row ? Support::decode($row['data']) : null;
        }
        if ($target['kind'] === 'collection') {
            $row = Support::one($this->db, 'SELECT row_id,data,published FROM collection_items WHERE slot_key=? AND item_uid=?', [$target['slot_key'], $target['item_uid']]);
            if (!$row) {
                return null;
            }
            $item = Support::decode($row['data']);
            if ($blocks) {
                $statement = Support::query($this->db, 'SELECT field_id,locale,data FROM collection_blocks WHERE item_row_id=?', [$row['row_id']]);
                while ($block = $statement->fetch(PDO::FETCH_ASSOC)) {
                    if ($block['locale'] === '') {
                        $item[$block['field_id']] = Support::decode($block['data']);
                    } else {
                        $item[$block['field_id']][$block['locale']] = Support::decode($block['data']);
                    }
                }
            }
            return $item;
        }
        $row = Support::one($this->db, 'SELECT data FROM slots WHERE key=?', [$target['slot_key']]);
        if (!$row) {
            return null;
        }
        $data = Support::decode($row['data']);
        if ($target['kind'] === 'object') {
            return $data;
        }
        foreach ($data as $item) {
            if (is_array($item) && ($item['_dndId'] ?? null) === $target['item_uid']) {
                return $item;
            }
        }
        return null;
    }

    public function isPublic(array $target, ?array $source): bool
    {
        if (!$target['public'] || $source === null) {
            return false;
        }
        if ($target['kind'] === 'route') {
            return ($source['active'] ?? true) === true;
        }
        return PublicPayloadService::isItemPublished($this->schema['slots'][$target['slot_key']] ?? [], $source);
    }

    public static function field(array $source, string $field, string $locale, string $main): mixed
    {
        return SchemaFields::localizedPath($source, $field, $locale, $main);
    }

    /** Return only an explicitly translated field, never a shared scalar or main fallback. */
    public static function translatedField(array $source, string $field, string $locale): mixed
    {
        return SchemaFields::localizedPath($source, $field, $locale, $locale, true);
    }

    public function synchronize(string $slot, ?string $uid = null): void
    {
        $definition = $this->schema['slots'][$slot] ?? null;
        if (!$definition || ($definition['type'] ?? '') === 'massive') {
            return;
        }
        $kind = $definition['type'] ?? 'object';
        if ($kind === 'collection' && $uid !== null) {
            $target = ['kind' => 'collection', 'slot_key' => $slot, 'item_uid' => $uid];
            $this->syncSource($target, $this->source($target, false));
            return;
        }
        if ($kind === 'collection') {
            // Collection rebuilds are bounded jobs; never export the complete slot.
            Support::query($this->db, "INSERT OR IGNORE INTO seo_jobs(kind,job_key,payload) VALUES ('index',?,?)", [$slot, Support::json(['slot' => $slot, 'cursor' => 0])]);
            return;
        }
        $row = Support::one($this->db, 'SELECT data FROM slots WHERE key=?', [$slot]);
        $data = $row ? Support::decode($row['data']) : null;
        if ($kind === 'object') {
            $this->syncSource(['kind' => 'object', 'slot_key' => $slot, 'item_uid' => ''], $data);
            return;
        }
        $seen = [];
        foreach ($data ?? [] as $item) {
            if (!is_array($item) || empty($item['_dndId'])) {
                continue;
            }
            $seen[$item['_dndId']] = true;
            $this->syncSource(['kind' => 'list', 'slot_key' => $slot, 'item_uid' => (string) $item['_dndId']], $item);
        }
        $statement = Support::query($this->db, "SELECT * FROM seo_targets WHERE slot_key=? AND kind='list'", [$slot]);
        while ($target = $statement->fetch(PDO::FETCH_ASSOC)) {
            if (!isset($seen[$target['item_uid']])) {
                $this->syncSource($target, null);
            }
        }
    }

    public function indexBatch(string $slot, int $cursor, int $limit = 100): array
    {
        $statement = Support::query($this->db, 'SELECT item_uid,row_id,data FROM collection_items WHERE slot_key=? AND row_id>? ORDER BY row_id LIMIT CAST(? AS INTEGER)', [$slot, $cursor, min(200, max(1, $limit))]);
        $count = 0;
        while ($row = $statement->fetch(PDO::FETCH_ASSOC)) {
            $this->syncSource(['kind' => 'collection', 'slot_key' => $slot, 'item_uid' => $row['item_uid']], Support::decode($row['data']));
            $cursor = (int) $row['row_id'];
            $count++;
        }
        return ['cursor' => $cursor, 'done' => $count < min(200, max(1, $limit)), 'processed' => $count];
    }

    private function syncSource(array $reference, ?array $source): void
    {
        $existing = Support::one($this->db, 'SELECT id FROM seo_targets WHERE kind=? AND slot_key=? AND item_uid=?', [$reference['kind'], $reference['slot_key'], $reference['item_uid']]);
        $id = $existing['id'] ?? substr(hash('sha256', Support::json([$reference['kind'], $reference['slot_key'], $reference['item_uid']])), 0, 32);
        $binding = $this->binding($reference['slot_key'])['data'];
        $main = $this->mainLocale();
        $public = $source !== null && PublicPayloadService::isItemPublished($this->schema['slots'][$reference['slot_key']], $source);
        $hash = $source === null ? '' : hash('sha256', Support::json($source));
        if ($reference['kind'] === 'collection' && $source !== null) {
            $row = Support::one($this->db, 'SELECT content_hash FROM collection_items WHERE slot_key=? AND item_uid=?', [$reference['slot_key'], $reference['item_uid']]);
            $hash = $row['content_hash'];
        }
        $hash = hash('sha256', Support::json([$hash, $binding]));
        $now = Support::timestamp(($this->clock)());
        Support::transaction($this->db, function () use ($id, $reference, $binding, $main, $public, $source, $hash, $now): void {
            $old = Support::one($this->db, 'SELECT * FROM seo_targets WHERE id=?', [$id]);
            $paths = [];
            if ($public) {
                foreach ($this->locales() as $locale) {
                    $pattern = $binding['paths'][$locale] ?? $binding['urlPattern'];
                    if ($pattern === '') {
                        continue;
                    }
                    $slug = self::field($source, $binding['slug'], $locale, $main);
                    if (str_contains($pattern, '{slug}') && (!is_scalar($slug) || (string) $slug === '')) {
                        continue;
                    }
                    $path = str_replace(['{slug}', '{id}', '{lang}'], [rawurlencode((string) $slug), rawurlencode($reference['item_uid']), $locale], $pattern);
                    if (!isset($binding['paths'][$locale]) && !empty($this->schema['i18n']['enabled']) && !str_contains($pattern, '{lang}')) {
                        $path = '/' . $locale . ($path === '/' ? '/' : $path);
                    }
                    $paths[$locale] = Support::path($path);
                }
            }
            $oldPaths = $old ? array_column($this->paths($id), 'path', 'locale') : [];
            ksort($oldPaths);
            ksort($paths);
            if ($old && $old['source_revision'] === $hash && (bool) $old['public'] === $public && $old['main_locale'] === $main && $oldPaths === $paths) {
                return;
            }
            Support::query($this->db, 'INSERT INTO seo_targets(id,kind,slot_key,item_uid,main_locale,public,source_revision,updated_at) VALUES (?,?,?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET main_locale=excluded.main_locale,public=excluded.public,source_revision=excluded.source_revision,generation=seo_targets.generation+1,updated_at=excluded.updated_at', [$id, $reference['kind'], $reference['slot_key'], $reference['item_uid'], $main, (int) $public, $hash, $now]);
            $this->replacePaths($id, $paths, $now);
            Support::query($this->db, "INSERT INTO seo_jobs(kind,job_key,payload) VALUES ('projection',?,?) ON CONFLICT(kind,job_key) DO UPDATE SET payload=excluded.payload", [$id, Support::json(['target' => $id])]);
            $this->coverDependencies($id, $source, $binding, $main);
            if (!$public) {
                $this->queueDeletion($id);
            }
        });
    }

    public function replacePaths(string $id, array $paths, string $now): void
    {
        foreach ($paths as $locale => $path) {
            Support::locale($locale);
            $path = Support::path($path);
            $conflict = Support::one($this->db, 'SELECT target_id,locale FROM seo_target_paths WHERE path=? AND active=1 AND (target_id<>? OR locale<>?)', [$path, $id, $locale]);
            if ($conflict) {
                throw new SeoException('route_conflict', 422, ['path' => $path, 'target_id' => $conflict['target_id']]);
            }
        }
        Support::query($this->db, 'UPDATE seo_target_paths SET active=0,updated_at=? WHERE target_id=?', [$now, $id]);
        foreach ($paths as $locale => $path) {
            Support::query($this->db, 'INSERT INTO seo_target_paths(target_id,locale,path,active,updated_at) VALUES (?,?,?,1,?) ON CONFLICT(target_id,locale,path) DO UPDATE SET active=1,updated_at=excluded.updated_at', [$id, $locale, Support::path($path), $now]);
        }
    }

    public function queueDeletion(string $id): void
    {
        $target = $this->get($id);
        Support::query($this->db, "INSERT INTO seo_jobs(kind,job_key,payload) VALUES ('delete_files',?,?) ON CONFLICT(kind,job_key) DO UPDATE SET payload=excluded.payload", [$id, Support::json(['target' => $id, 'generation' => (int) $target['generation']])]);
    }

    public function route(?string $id, ?array $input = null): array
    {
        if ($input === null) {
            $row = Support::one($this->db, 'SELECT * FROM seo_routes WHERE id=?', [$id]) ?? throw new SeoException('route_not_found', 404);
            return ['id' => $id, 'data' => Support::decode($row['data']), 'revision' => (int) $row['revision'], 'updated_at' => $row['updated_at']];
        }
        if (!empty($input['data']['templateId'])) {
            Templates::assertCompatible($this->db, $input['data']['templateId'], '');
        }
        return Support::transaction($this->db, function () use ($id, $input): array {
            $current = $id === null ? null : $this->route($id);
            if ($current) {
                Support::version($current, $input);
            }
            $id ??= Support::id();
            $data = array_replace($current['data'] ?? ['mainLocale' => $this->mainLocale(), 'active' => true, 'paths' => [], 'auditProfile' => ['minWords' => 0]], $input['data'] ?? []);
            $main = Support::locale($data['mainLocale']);
            if (!is_bool($data['active']) || !isset($data['paths'][$main]) || count($data['paths']) > 20) {
                throw new SeoException('invalid_route');
            }
            self::profile($data['auditProfile']);
            $label = Support::text($data['label'] ?? '', 200);
            $now = Support::timestamp(($this->clock)());
            Support::query($this->db, 'INSERT INTO seo_targets(id,kind,item_uid,main_locale,public,source_revision,updated_at) VALUES (?,\'route\',?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET main_locale=excluded.main_locale,public=excluded.public,source_revision=excluded.source_revision,generation=seo_targets.generation+1,updated_at=excluded.updated_at', [$id, $id, $main, (int) $data['active'], hash('sha256', Support::json($data)), $now]);
            Support::query($this->db, 'INSERT INTO seo_routes(id,label,data,revision,updated_at) VALUES (?,?,?,1,?) ON CONFLICT(id) DO UPDATE SET label=excluded.label,data=excluded.data,revision=seo_routes.revision+1,updated_at=excluded.updated_at', [$id, $label, Support::json($data), $now]);
            $this->indexTemplateUsage('route', $id, $data['templateId'] ?? null);
            $this->replacePaths($id, $data['active'] ? $data['paths'] : [], $now);
            if (!$data['active']) {
                $this->queueDeletion($id);
            }
            Support::query($this->db, "INSERT INTO seo_jobs(kind,job_key,payload) VALUES ('projection',?,?) ON CONFLICT(kind,job_key) DO UPDATE SET payload=excluded.payload", [$id, Support::json(['target' => $id])]);
            return $this->route($id);
        });
    }

    public function deleteRoute(string $id, array $input): void
    {
        $current = $this->route($id);
        $input['data'] = array_replace($current['data'], ['active' => false]);
        $this->route($id, $input);
    }

    public function importStaticPages(): void
    {
        if (Support::one($this->db, "SELECT 1 FROM seo_settings WHERE key='static_imported'")) {
            return;
        }
        Support::transaction($this->db, function (): void {
            foreach ($this->schema['staticPages'] ?? $this->schema['seo']['staticPages'] ?? [] as $key => $page) {
                $path = is_string($key) && str_starts_with($key, '/') ? $key : ($page['url'] ?? $page['path'] ?? '/');
                $paths = [];
                foreach ($this->locales() as $locale) {
                    $paths[$locale] = !empty($this->schema['i18n']['enabled']) ? '/' . $locale . ($path === '/' ? '/' : $path) : $path;
                }
                $this->route(null, ['data' => ['label' => is_array($page['label'] ?? '') ? (string) ($page['label'][$this->mainLocale()] ?? '') : ($page['label'] ?? ''), 'title' => $page['label'] ?? '', 'description' => $page['description'] ?? '', 'paths' => $paths]]);
            }
            Support::query($this->db, "INSERT INTO seo_settings(key,value,revision,updated_at) VALUES ('static_imported','true',1,?)", [Support::timestamp(($this->clock)())]);
        });
    }

    private function indexTemplateUsage(string $type, string $id, ?string $template): void
    {
        Support::query($this->db, 'DELETE FROM seo_asset_usages WHERE owner_type=? AND owner_id=?', [$type, $id]);
        if ($template) {
            if (!Support::one($this->db, 'SELECT id FROM seo_templates WHERE id=?', [$template])) {
                throw new SeoException('template_not_found', 422);
            }
            Support::query($this->db, "INSERT INTO seo_asset_usages(type,resource_id,owner_type,owner_id) VALUES ('template',?,?,?)", [$template, $type, $id]);
        }
    }

    private static function profile(array $profile): void
    {
        foreach ($profile as $field => $value) {
            if (!in_array($field, ['minWords', 'titleMin', 'titleMax', 'descriptionMin', 'descriptionMax'], true) || !is_int($value) || $value < 0 || $value > 10000) {
                throw new SeoException('invalid_audit_profile');
            }
        }
    }

    private function coverDependencies(string $id, ?array $source, array $binding, string $main): void
    {
        Support::query($this->db, "DELETE FROM seo_asset_usages WHERE owner_type IN ('cover','cover_pending','field') AND owner_id>=? AND owner_id<?", [$id . ':', $id . ';']);
        if ($source === null || empty($binding['cover'])) {
            return;
        }
        $configuration = null;
        foreach ($this->locales() as $locale) {
            $raw = self::field($source, $binding['cover'], $locale, $main);
            if (!$raw) {
                continue;
            }
            $configuration ??= Support::decode(Support::one($this->db, "SELECT value FROM seo_settings WHERE key='config'")['value']);
            $asset = Assets::cover($this->db, $raw, $configuration['apiBaseUrl'] ?? '');
            if ($asset) {
                Support::query($this->db, "INSERT OR IGNORE INTO seo_asset_usages(type,resource_id,owner_type,owner_id) VALUES ('asset',?,'cover',?)", [$asset['id'], $id . ':' . $locale]);
                continue;
            }
            $media = Assets::mediaName($raw, $configuration['apiBaseUrl'] ?? '');
            if ($media !== null && (Support::one($this->db, 'SELECT filename FROM media_meta WHERE filename=?', [$media]) || Support::one($this->db, 'SELECT filename FROM media_meta WHERE filename=?', ['/api/uploads/' . $media]) || is_file(dirname(__DIR__, 3) . '/uploads/' . $media))) {
                Support::query($this->db, "INSERT OR IGNORE INTO seo_asset_usages(type,resource_id,owner_type,owner_id) VALUES ('media',?,'cover_pending',?)", [$media, $id . ':' . $locale]);
                Support::query($this->db, "INSERT OR IGNORE INTO seo_jobs(kind,job_key,payload) VALUES ('import_cover',?,?)", [$media, Support::json(['media' => $media])]);
            }
        }
    }
}
