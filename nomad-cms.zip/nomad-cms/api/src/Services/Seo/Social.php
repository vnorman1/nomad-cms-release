<?php
/**
 * NOMAD CMS — platform-classified OG request telemetry.
 * Counts backend requests, not shares. Durable bounded spool batches aggregate exactly once in massive.sqlite.
 * Raw IPs and complete User-Agent values are never retained.
 * @package NomadCMS\Services\Seo
 */
declare(strict_types=1);

namespace NomadCMS\Services\Seo;

use PDO;

/** Versioned bot classifier and low-contention daily aggregation. */
final class Social
{
    public const RULE_VERSION = '2026-10-v1';

    public function __construct(private readonly PDO $core, private readonly ?PDO $massive, private readonly FileStore $files, private readonly \Closure $clock)
    {
    }

    public static function platform(string $agent): ?string
    {
        $agent = strtolower(substr($agent, 0, 512));
        foreach (['facebook' => ['facebookexternalhit', 'facebot'], 'slack' => ['slackbot-linkexpanding', 'slack-imgproxy'], 'twitter' => ['twitterbot'], 'linkedin' => ['linkedinbot']] as $platform => $tokens) {
            foreach ($tokens as $token) {
                if (str_contains($agent, $token)) {
                    return $platform;
                }
            }
        }
        return null;
    }

    public function record(string $target, string $locale, string $agent, string $method, int $status, bool $internal = false): void
    {
        $platform = self::platform($agent);
        if ($internal || !$platform || !in_array($status, [200, 304], true) || !in_array($method, ['GET', 'HEAD'], true)) {
            return;
        }
        $kind = $method === 'HEAD' ? 'heads' : ($status === 304 ? 'revalidations' : 'gets');
        $time = (int) ($this->clock)();
        $line = Support::json([$target, $locale, $platform, gmdate('Y-m-d', $time), $kind, $time]) . "\n";
        $this->files->locked('social-spool', function () use ($line): void {
            $this->files->directory('cache/social');
            $path = $this->files->path('cache/social/current.ndjson');
            if (is_file($path) && filesize($path) >= 1048576) {
                rename($path, $this->files->path('cache/social/' . Support::id() . '.ndjson'));
            }
            if (file_put_contents($path, $line, FILE_APPEND | LOCK_EX) !== strlen($line)) {
                throw new SeoException('statistics_spool_unavailable', 503);
            }
        });
    }

    public function aggregate(float $deadline): int
    {
        if (!$this->massive) {
            return 0;
        }
        $this->files->locked('social-spool', function (): void {
            $path = $this->files->path('cache/social/current.ndjson');
            if (is_file($path) && filesize($path) > 0) {
                rename($path, $this->files->path('cache/social/' . Support::id() . '.ndjson'));
            }
        });
        $directory = $this->files->directory('cache/social');
        $processed = 0;
        foreach (new \DirectoryIterator($directory) as $file) {
            if (microtime(true) >= $deadline) {
                break;
            }
            if (!$file->isFile() || !preg_match('/^([a-f0-9]{32})\.ndjson$/D', $file->getFilename(), $match)) {
                continue;
            }
            $batch = $match[1];
            $path = $file->getPathname();
            $this->files->locked('social-batch:' . $batch, function () use ($batch, $path, &$processed): void {
                if (!is_file($path)) {
                    return;
                }
                Support::transaction($this->massive, function () use ($batch, $path, &$processed): void {
                    if (Support::one($this->massive, 'SELECT 1 FROM seo_bot_batches WHERE id=?', [$batch])) {
                        return;
                    }
                    $stream = fopen($path, 'rb');
                    try {
                        while (($line = fgets($stream, 1024)) !== false) {
                            [$target, $locale, $platform, $day, $kind, $time] = json_decode($line, true, 8, JSON_THROW_ON_ERROR);
                            if (!in_array($kind, ['gets', 'revalidations', 'heads'], true)) {
                                continue;
                            }
                            Support::query($this->massive, 'INSERT INTO seo_bot_daily(target_id,locale,platform,day,' . $kind . ') VALUES (?,?,?,?,1) ON CONFLICT(target_id,locale,platform,day) DO UPDATE SET ' . $kind . '=seo_bot_daily.' . $kind . '+1', [$target, $locale, $platform, $day]);
                            Support::query($this->core, 'UPDATE seo_og_cache SET last_bot_at=MAX(COALESCE(last_bot_at,0),?) WHERE target_id=? AND locale=?', [$time, $target, $locale]);
                            $processed++;
                        }
                    } finally {
                        fclose($stream);
                    }
                    Support::query($this->massive, 'INSERT INTO seo_bot_batches(id,processed_at) VALUES (?,?)', [$batch, Support::timestamp(($this->clock)())]);
                });
                unlink($path);
            });
        }
        return $processed;
    }

    public function stats(?string $target, string $from, string $to): array
    {
        if (!$this->massive || !preg_match('/^\d{4}-\d{2}-\d{2}$/D', $from) || !preg_match('/^\d{4}-\d{2}-\d{2}$/D', $to) || strtotime($to) - strtotime($from) > 366 * 86400) {
            throw new SeoException('invalid_statistics_range');
        }
        $sql = 'SELECT platform,SUM(gets) AS gets,SUM(revalidations) AS revalidations,SUM(heads) AS heads FROM seo_bot_daily WHERE day>=? AND day<=?';
        $parameters = [$from, $to];
        if ($target !== null) {
            $sql .= ' AND target_id=?';
            $parameters[] = $target;
        }
        $platforms = Support::query($this->massive, $sql . ' GROUP BY platform', $parameters)->fetchAll(PDO::FETCH_ASSOC);
        $targetSql = str_replace('SELECT platform,', 'SELECT target_id,locale,', $sql);
        $targets = Support::query($this->massive, $targetSql . ' GROUP BY target_id,locale ORDER BY gets DESC,target_id,locale LIMIT 100', $parameters)->fetchAll(PDO::FETCH_ASSOC);
        return ['classification_version' => self::RULE_VERSION, 'metric' => 'classified_backend_requests', 'platforms' => $platforms, 'targets' => $targets];
    }
}
