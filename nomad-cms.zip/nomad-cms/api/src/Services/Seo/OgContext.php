<?php
/**
 * NOMAD CMS — server-resolved OG template context.
 * Reads one authorized target without block hydration and resolves only referenced schema fields.
 * Local media is referenced dynamically; missing or removed fields produce explicit warnings.
 * @package NomadCMS\Services\Seo
 */
declare(strict_types=1);

namespace NomadCMS\Services\Seo;

use PDO;

/** Shared source resolution for private editor context and deterministic public rendering. */
final class OgContext
{
    public function __construct(
        private readonly PDO $db,
        private readonly TargetRegistry $targets,
        private readonly Metadata $metadata,
        private readonly Settings $settings,
        private readonly SchemaFields $schemaFields,
        private readonly Assets $assets,
    ) {
    }

    public function resolve(array $document, string $targetId, string $locale, array $changes = []): array
    {
        $target = $this->targets->get($targetId);
        $locale = Support::locale($locale);
        if (!in_array($locale, $this->targets->locales(), true)) {
            throw new SeoException('invalid_locale');
        }
        $metadata = $this->metadata->effective($targetId, $locale, false, $changes, false);
        $context = array_intersect_key($metadata['context'], array_fill_keys(Templates::BINDINGS, true));
        $fields = [];
        $warnings = [];
        $slot = $document['schemaSlotKey'] ?? '';
        $source = null;
        if (array_filter($document['layers'] ?? [], static fn ($layer) => $layer['type'] === 'image' && ($layer['binding'] ?? '') === 'cover')) {
            $source = $this->targets->source($target, false) ?? [];
            $coverPath = $target['kind'] === 'route' ? 'cover' : $this->targets->binding($target['slot_key'])['data']['cover'];
            $raw = TargetRegistry::field($source, $coverPath, $locale, $target['main_locale']);
            $context['cover'] = $this->image($raw, $targetId, $locale, 'cover', $warnings);
        }
        foreach ($document['layers'] ?? [] as $layer) {
            $path = $layer['fieldPath'] ?? null;
            if (!is_string($path) || array_key_exists($path, $fields)) {
                continue;
            }
            $fields[$path] = null;
            if ($slot !== $target['slot_key'] || $target['kind'] === 'route') {
                $warnings[] = ['code' => 'schema_slot_mismatch', 'fieldPath' => $path];
                continue;
            }
            $descriptor = $this->schemaFields->descriptor($slot, $path);
            if ($descriptor === null || $descriptor['kind'] !== ($layer['type'] === 'image' ? 'image' : 'text')) {
                $warnings[] = ['code' => 'schema_field_missing', 'fieldPath' => $path];
                continue;
            }
            $source ??= $this->targets->source($target, false) ?? [];
            $value = $this->schemaFields->value($source, $slot, $path, $locale, $target['main_locale']);
            if ($descriptor['kind'] === 'image') {
                $fields[$path] = $this->image($value, $targetId, $locale, $path, $warnings);
            } elseif (is_string($value) || is_int($value) || is_float($value)) {
                $text = $descriptor['type'] === 'richtext' ? html_entity_decode(strip_tags((string) $value), ENT_QUOTES | ENT_HTML5, 'UTF-8') : (string) $value;
                $fields[$path] = mb_substr($text, 0, 2000);
            }
            if ($fields[$path] === null || $fields[$path] === '') {
                $warnings[] = ['code' => 'schema_field_empty', 'fieldPath' => $path];
            }
        }
        return ['context' => $context, 'fields' => $fields, 'warnings' => $warnings];
    }

    private function image(mixed $value, string $targetId, string $locale, string $path, array &$warnings): ?string
    {
        $owner = $targetId . ':' . $locale . ':' . $path;
        if ($value === null || $value === '') {
            $this->imageDependency($owner, null);
            return null;
        }
        $apiBase = $this->settings->get()['data']['apiBaseUrl'];
        $filename = Assets::mediaName($value, $apiBase);
        $asset = is_string($value) ? Support::one($this->db, 'SELECT id,hash FROM seo_assets WHERE id=?', [$value]) : null;
        if ($asset === null) {
            if ($filename === null) {
                $warnings[] = ['code' => 'schema_image_unavailable', 'fieldPath' => $path];
                $this->imageDependency($owner, null);
                return null;
            }
            try {
                // Validate current source bytes even when this filename was registered earlier.
                $asset = $this->assets->importLocal($filename);
            } catch (SeoException $error) {
                $warnings[] = ['code' => $error->errorCode, 'fieldPath' => $path];
                $this->imageDependency($owner, null);
                return null;
            }
        }
        $this->imageDependency($owner, $asset['id']);
        return $asset['id'];
    }

    private function imageDependency(string $owner, ?string $assetId): void
    {
        $existing = Support::one($this->db, "SELECT resource_id FROM seo_asset_usages WHERE type='asset' AND owner_type='field' AND owner_id=?", [$owner]);
        if (($existing['resource_id'] ?? null) !== $assetId) {
            Support::transaction($this->db, function () use ($owner, $assetId): void {
                Support::query($this->db, "DELETE FROM seo_asset_usages WHERE owner_type='field' AND owner_id=?", [$owner]);
                if ($assetId !== null) {
                    Support::query($this->db, "INSERT INTO seo_asset_usages(type,resource_id,owner_type,owner_id) VALUES ('asset',?,'field',?)", [$assetId, $owner]);
                }
            });
        }
    }

    /** Field values occupy a reserved namespace, never arbitrary client expressions. */
    public static function rendererContext(array $resolved): array
    {
        $context = $resolved['context'];
        foreach ($resolved['fields'] as $path => $value) {
            $context['field:' . $path] = $value;
        }
        return $context;
    }
}
