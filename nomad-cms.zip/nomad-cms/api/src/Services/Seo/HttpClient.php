<?php
/**
 * NOMAD CMS — bounded HTTP fetches for audits, font imports and SPA metadata.
 * Exact host allowlist, public IPv4/IPv6 verification and DNS pinning on every redirect.
 * No ambient browser credentials or proxy environment is forwarded.
 * @package NomadCMS\Services\Seo
 */
declare(strict_types=1);

namespace NomadCMS\Services\Seo;

/** Secure HTTP adapter with injectable DNS/transport for deterministic security tests. */
class HttpClient
{
    public function __construct(
        private readonly array $allowedHosts,
        private readonly ?\Closure $resolver = null,
        private readonly ?\Closure $transport = null,
    ) {
    }

    public static function publicIp(string $ip): bool
    {
        $binary = @inet_pton($ip);
        if ($binary === false) {
            return false;
        }
        if (strlen($binary) === 16) {
            // Only global unicast IPv6. Reject mapped IPv4, NAT64, tunnels and documentation ranges.
            if ((ord($binary[0]) & 0xe0) !== 0x20 || substr($binary, 0, 4) === hex2bin('20010db8') || (substr($binary, 0, 2) === hex2bin('2001') && ord($binary[2]) < 2) || substr($binary, 0, 2) === hex2bin('2002') || (substr($binary, 0, 2) === hex2bin('3fff') && (ord($binary[2]) & 0xf0) === 0)) {
                return false;
            }
            return true;
        }
        if (!filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4 | FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) {
            return false;
        }
        $number = unpack('N', $binary)[1];
        foreach ([[0x64400000, 10], [0xc0000000, 24], [0xc0000200, 24], [0xc0586300, 24], [0xc6120000, 15], [0xc6336400, 24], [0xcb007100, 24], [0xe0000000, 4]] as [$network, $bits]) {
            $mask = (0xffffffff << (32 - $bits)) & 0xffffffff;
            if (($number & $mask) === $network) {
                return false;
            }
        }
        return true;
    }

    public function get(string $url, int $limit = 2097152, float $timeout = 8.0, int $redirects = 3, array $headers = []): array
    {
        $deadline = microtime(true) + $timeout;
        $history = [];
        for ($step = 0; $step <= $redirects; $step++) {
            $parts = parse_url(Support::url($url));
            $host = strtolower($parts['host']);
            $port = $parts['port'] ?? ($parts['scheme'] === 'https' ? 443 : 80);
            if (!in_array($host, array_map('strtolower', $this->allowedHosts), true) || !in_array($port, [80, 443], true) || str_contains($host, '%') || filter_var(trim($host, '[]'), FILTER_VALIDATE_IP)) {
                throw new SeoException('http_host_forbidden');
            }
            $addresses = $this->resolver ? ($this->resolver)($host, $deadline) : (new DnsResolver())->resolve($host, $deadline);
            if (!$addresses) {
                throw new SeoException('http_dns_failed', 503);
            }
            foreach ($addresses as $address) {
                if (!self::publicIp($address)) {
                    throw new SeoException('http_private_address');
                }
            }
            $remaining = $deadline - microtime(true);
            if ($remaining <= 0) {
                throw new SeoException('http_timeout', 504);
            }
            $response = $this->transport
                ? ($this->transport)($url, $addresses[0], $limit, $remaining, $headers)
                : $this->curl($url, $host, $port, $addresses[0], $limit, $remaining, $headers);
            if (strlen($response['body'] ?? '') > $limit) {
                throw new SeoException('http_response_too_large');
            }
            if (!in_array($response['status'], [301, 302, 303, 307, 308], true)) {
                return $response + ['url' => $url, 'redirects' => $history];
            }
            if ($step === $redirects || empty($response['headers']['location'])) {
                throw new SeoException('http_redirect_limit');
            }
            $next = self::redirect($url, $response['headers']['location']);
            if ($parts['scheme'] === 'https' && parse_url($next, PHP_URL_SCHEME) !== 'https') {
                throw new SeoException('http_insecure_redirect');
            }
            $history[] = ['url' => $url, 'status' => $response['status']];
            $url = $next;
        }
        throw new SeoException('http_redirect_limit');
    }

    public function head(string $url, float $timeout = 8.0): array
    {
        return $this->get($url, 65536, $timeout, 3, [':method' => 'HEAD']);
    }

    private function curl(string $url, string $host, int $port, string $address, int $limit, float $timeout, array $headers): array
    {
        if (!function_exists('curl_init')) {
            throw new SeoException('curl_required', 503);
        }
        $handle = curl_init($url);
        $body = '';
        $responseHeaders = [];
        $headerBytes = 0;
        $tooLarge = false;
        $requestHeaders = ['Accept: text/html,application/json,text/css,*/*;q=0.1'];
        foreach (['If-None-Match', 'User-Agent'] as $name) {
            if (isset($headers[$name]) && !preg_match('/[\r\n]/', $headers[$name])) {
                $requestHeaders[] = $name . ': ' . $headers[$name];
            }
        }
        curl_setopt_array($handle, [
            CURLOPT_FOLLOWLOCATION => false,
            CURLOPT_NOBODY => ($headers[':method'] ?? '') === 'HEAD',
            CURLOPT_PROTOCOLS => CURLPROTO_HTTP | CURLPROTO_HTTPS,
            CURLOPT_TIMEOUT_MS => max(1, (int) ($timeout * 1000)),
            CURLOPT_CONNECTTIMEOUT_MS => max(1, min(2000, (int) ($timeout * 1000))),
            CURLOPT_RESOLVE => [$host . ':' . $port . ':' . (str_contains($address, ':') ? '[' . $address . ']' : $address)],
            CURLOPT_PROXY => '', CURLOPT_SSL_VERIFYPEER => true, CURLOPT_SSL_VERIFYHOST => 2,
            CURLOPT_ENCODING => '', CURLOPT_USERAGENT => 'NomadCMS-SEO-Audit/1.0',
            CURLOPT_HTTPHEADER => $requestHeaders,
            CURLOPT_WRITEFUNCTION => static function ($curl, string $chunk) use (&$body, &$tooLarge, $limit): int {
                if (strlen($body) + strlen($chunk) > $limit) {
                    $tooLarge = true;
                    return 0;
                }
                $body .= $chunk;
                return strlen($chunk);
            },
            CURLOPT_HEADERFUNCTION => static function ($curl, string $line) use (&$responseHeaders, &$headerBytes): int {
                $headerBytes += strlen($line);
                if ($headerBytes > 65536) {
                    return 0;
                }
                if (str_starts_with($line, 'HTTP/')) {
                    $responseHeaders = [];
                } elseif (str_contains($line, ':')) {
                    [$key, $value] = explode(':', $line, 2);
                    $responseHeaders[strtolower(trim($key))] = trim($value);
                }
                return strlen($line);
            },
        ]);
        try {
            if (curl_exec($handle) === false) {
                throw new SeoException($tooLarge ? 'http_response_too_large' : (curl_errno($handle) === CURLE_OPERATION_TIMEDOUT ? 'http_timeout' : 'http_fetch_failed'), 503);
            }
            return ['status' => (int) curl_getinfo($handle, CURLINFO_RESPONSE_CODE), 'body' => $body, 'headers' => $responseHeaders];
        } finally {
            curl_close($handle);
        }
    }

    private static function redirect(string $base, string $location): string
    {
        if (preg_match('~^https?://~i', $location)) {
            return Support::url($location);
        }
        $parts = parse_url($base);
        $origin = $parts['scheme'] . '://' . $parts['host'] . (isset($parts['port']) ? ':' . $parts['port'] : '');
        if (str_starts_with($location, '//')) {
            return $parts['scheme'] . ':' . $location;
        }
        if ($location[0] === '/') {
            return $origin . $location;
        }
        return $origin . rtrim(dirname($parts['path'] ?? '/'), '/') . '/' . $location;
    }
}
