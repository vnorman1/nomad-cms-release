<?php
/**
 * NOMAD CMS — SEO domain errors.
 * Carries stable HTTP error codes and bounded validation details.
 * @package NomadCMS\Services\Seo
 */
declare(strict_types=1);

namespace NomadCMS\Services\Seo;

/** Domain error suitable for both HTTP and CLI consumers. */
final class SeoException extends \RuntimeException
{
    public function __construct(
        public readonly string $errorCode,
        public readonly int $status = 422,
        public readonly array $details = [],
    ) {
        parent::__construct($errorCode);
    }
}
