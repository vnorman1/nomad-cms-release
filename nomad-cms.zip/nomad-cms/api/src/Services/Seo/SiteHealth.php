<?php
/**
 * NOMAD CMS — bounded sitemap builds and structured robots policy.
 * Keyset cursors and checkpointed append positions support interrupted shared-hosting cron runs.
 * Only active, public and indexable registered language paths enter XML sitemaps.
 * @package NomadCMS\Services\Seo
 */
declare(strict_types=1);

namespace NomadCMS\Services\Seo;

use PDO;

/** Site-wide technical SEO using the same route registry as public metadata. */
final class SiteHealth
{
    private const HEADER = '<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" xmlns:xhtml="http://www.w3.org/1999/xhtml">';

    public function __construct(private readonly PDO $db, private readonly Settings $settings, private readonly TargetRegistry $targets, private readonly FileStore $files, private readonly \Closure $clock)
    {
    }

    public function invalidate(): void
    {
        Support::query($this->db, "INSERT INTO seo_settings(key,value,revision,updated_at) VALUES ('sitemap_dirty','true',1,?) ON CONFLICT(key) DO UPDATE SET value='true',revision=seo_settings.revision+1,updated_at=excluded.updated_at", [Support::timestamp(($this->clock)())]);
    }

    public function buildStep(int $batch = 500, int $urlLimit = 50000, int $byteLimit = 52428800): array
    {
        if ($this->db->inTransaction()) {
            throw new SeoException('commit_required', 409);
        }
        return $this->files->locked('sitemap-build', function () use ($batch, $urlLimit, $byteLimit): array {
            $config = $this->settings->get()['data'];
            if ($config['publicSiteUrl'] === '' || $config['apiBaseUrl'] === '') {
                throw new SeoException('public_urls_required', 503);
            }
            $row = Support::one($this->db, "SELECT * FROM seo_settings WHERE key='sitemap_build'");
            $state = $row ? Support::decode($row['value']) : ['generation' => Support::id(), 'cursor' => '', 'part' => 1, 'urls' => 0, 'bytes' => strlen(self::HEADER), 'total' => 0, 'dirty_revision' => (int) (Support::one($this->db, "SELECT revision FROM seo_settings WHERE key='sitemap_dirty'")['revision'] ?? 0)];
            $directory = 'cache/sitemaps/' . $state['generation'];
            $this->files->directory($directory);
            $file = $directory . '/' . $state['part'] . '.xml';
            if (!is_file($this->files->path($file))) {
                $this->files->write($file, self::HEADER);
            }
            $stream = fopen($this->files->path($file), 'c+b');
            ftruncate($stream, $state['bytes']);
            fseek($stream, $state['bytes']);
            $processed = 0;
            try {
                $statement = Support::query($this->db, 'SELECT p.*,m.data AS main_data,l.data AS local_data FROM seo_target_paths p JOIN seo_targets t ON t.id=p.target_id LEFT JOIN seo_documents m ON m.target_id=t.id AND m.locale=t.main_locale LEFT JOIN seo_documents l ON l.target_id=t.id AND l.locale=p.locale WHERE p.active=1 AND t.public=1 AND p.path>? ORDER BY p.path LIMIT CAST(? AS INTEGER)', [$state['cursor'], min(1000, max(1, $batch))]);
                while ($entry = $statement->fetch(PDO::FETCH_ASSOC)) {
                    $state['cursor'] = $entry['path'];
                    $processed++;
                    $main = Support::decode($entry['main_data']);
                    $local = Support::decode($entry['local_data']);
                    if ($local['noindex'] ?? $main['noindex'] ?? false) {
                        continue;
                    }
                    $xml = '<url><loc>' . Support::escape($config['publicSiteUrl'] . $entry['path']) . '</loc>';
                    $xml .= '<lastmod>' . gmdate('Y-m-d\TH:i:s\Z', strtotime($entry['updated_at'])) . '</lastmod>';
                    $alternates = $this->targets->paths($entry['target_id']);
                    foreach ($alternates as $alternate) {
                        $xml .= '<xhtml:link rel="alternate" hreflang="' . Support::escape($alternate['locale']) . '" href="' . Support::escape($config['publicSiteUrl'] . $alternate['path']) . '"/>';
                    }
                    foreach ($alternates as $alternate) {
                        if ($alternate['locale'] === ($this->targets->schema['i18n']['xDefaultLanguage'] ?? null)) {
                            $xml .= '<xhtml:link rel="alternate" hreflang="x-default" href="' . Support::escape($config['publicSiteUrl'] . $alternate['path']) . '"/>';
                            break;
                        }
                    }
                    $xml .= '</url>';
                    if ($state['urls'] >= $urlLimit || ($state['urls'] > 0 && $state['bytes'] + strlen($xml) + 9 > $byteLimit)) {
                        fwrite($stream, '</urlset>');
                        fclose($stream);
                        $state['part']++;
                        $state['urls'] = 0;
                        $state['bytes'] = strlen(self::HEADER);
                        $file = $directory . '/' . $state['part'] . '.xml';
                        $this->files->write($file, self::HEADER);
                        $stream = fopen($this->files->path($file), 'ab');
                    }
                    if (fwrite($stream, $xml) !== strlen($xml)) {
                        throw new SeoException('sitemap_write_failed', 503);
                    }
                    $state['bytes'] += strlen($xml);
                    $state['urls']++;
                    $state['total']++;
                }
                $done = $processed < min(1000, max(1, $batch));
                if ($done) {
                    fwrite($stream, '</urlset>');
                }
            } finally {
                fclose($stream);
            }
            if ($done) {
                $index = '<?xml version="1.0" encoding="UTF-8"?><sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">';
                for ($part = 1; $part <= $state['part']; $part++) {
                    $index .= '<sitemap><loc>' . Support::escape($config['apiBaseUrl'] . '/seo/sitemap/' . $part . '.xml?g=' . $state['generation']) . '</loc></sitemap>';
                }
                $index .= '</sitemapindex>';
                if ($state['part'] === 1) {
                    $this->files->copy($this->files->path($file), 'cache/sitemaps/index.xml');
                } else {
                    $this->files->write('cache/sitemaps/index.xml', $index);
                }
                Support::query($this->db, "DELETE FROM seo_settings WHERE key='sitemap_build'");
                Support::query($this->db, "UPDATE seo_settings SET value='false' WHERE key='sitemap_dirty' AND revision=?", [$state['dirty_revision']]);
            } else {
                Support::query($this->db, "INSERT INTO seo_settings(key,value,revision,updated_at) VALUES ('sitemap_build',?,1,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value,revision=seo_settings.revision+1,updated_at=excluded.updated_at", [Support::json($state), Support::timestamp(($this->clock)())]);
            }
            return $state + ['done' => $done];
        });
    }

    public function sitemapFile(?int $part = null, ?string $generation = null): string
    {
        if ($part === null) {
            $path = $this->files->path('cache/sitemaps/index.xml');
        } else {
            if ($part < 1 || $part > 100000 || !preg_match('/^[a-f0-9]{32}$/D', $generation ?? '')) {
                throw new SeoException('sitemap_not_found', 404);
            }
            $path = $this->files->path('cache/sitemaps/' . $generation . '/' . $part . '.xml');
        }
        if (!is_file($path)) {
            throw new SeoException('sitemap_pending', 503, ['retry_after' => 30]);
        }
        return $path;
    }

    public function robots(): string
    {
        $config = $this->settings->get()['data'];
        $lines = [];
        foreach ($config['robots'] as $group) {
            $lines[] = 'User-agent: ' . $group['agent'];
            foreach (['disallow' => 'Disallow', 'allow' => 'Allow'] as $key => $label) {
                foreach ($group[$key] ?? [] as $path) {
                    $lines[] = $label . ': ' . $path;
                }
            }
            $lines[] = '';
        }
        $lines[] = 'Sitemap: ' . $config['publicSiteUrl'] . '/sitemap.xml';
        return implode("\n", $lines) . "\n";
    }

    public function robotsAllows(string $path, string $agent = '*'): bool
    {
        return self::allows($this->settings->get()['data']['robots'], $path, $agent);
    }

    /** Evaluate the same saved robots policy for previews and technical content checks. */
    public static function allows(array $groups, string $path, string $agent = '*'): bool
    {
        $specific = array_filter($groups, static fn ($group) => $group['agent'] !== '*' && stripos($agent, $group['agent']) !== false);
        $groups = $specific ?: array_filter($groups, static fn ($group) => $group['agent'] === '*');
        $longest = -1;
        $allowed = true;
        foreach ($groups as $group) {
            foreach (['disallow' => false, 'allow' => true] as $type => $decision) {
                foreach ($group[$type] ?? [] as $rule) {
                    if ($rule === '') {
                        continue;
                    }
                    $pattern = str_replace(['\\*', '\\$'], ['.*', '$'], preg_quote($rule, '~'));
                    $length = strlen(str_replace(['*', '$'], '', $rule));
                    if (preg_match('~^' . $pattern . '~', $path) && ($length > $longest || ($length === $longest && $decision))) {
                        $longest = $length;
                        $allowed = $decision;
                    }
                }
            }
        }
        return $allowed;
    }
}
