<?php
/**
 * NOMAD CMS — durable SEO jobs, audit runs and quota maintenance.
 * Keyset maintenance is resumable and bounded; individual audits run only on an explicit administrative request.
 * Post-commit deletion jobs are generation-aware and retryable.
 * @package NomadCMS\Services\Seo
 */
declare(strict_types=1);

namespace NomadCMS\Services\Seo;

use PDO;

/** Budget-aware worker and garbage collector. */
final class Maintenance
{
    public function __construct(private readonly SeoModule $module)
    {
    }

    public function startRun(array $data, ?string $target = null, ?string $locale = null): array
    {
        if ($target === null) {
            throw new SeoException('global_audits_retired', 410);
        }
        if (array_key_exists('live', $data) && !is_bool($data['live'])) {
            throw new SeoException('invalid_audit_run');
        }
        if ($this->module->db->inTransaction()) {
            throw new SeoException('commit_required', 409);
        }
        $this->module->targets->get($target);
        $locale = Support::locale($locale ?? '');
        $live = $data['live'] ?? false;
        if ($live) {
            $this->module->metadata->effective($target, $locale, true, [], false);
        }

        try {
            return $this->module->files->locked('audit-target:' . $target . ':' . $locale, function () use ($target, $locale, $live): array {
                return $this->auditSlot(function () use ($target, $locale, $live): array {
                    $id = Support::id();
                    $runData = ['live' => $live, 'target' => $target, 'locale' => $locale];
                    Support::query($this->module->db, 'INSERT INTO seo_audit_runs(id,state,data,revision,updated_at) VALUES (?,\'running\',?,1,?)', [$id, Support::json($runData), Support::timestamp(($this->module->clock)())]);
                    $errorCount = 0;
                    try {
                        $cms = $this->module->audit->cms($target, $locale);
                        $runData['result']['cms'] = self::findingSummary($cms);
                        if ($live) {
                            $website = $this->module->audit->live($target, $locale);
                            $runData['result']['live'] = self::findingSummary($website);
                        }
                    } catch (\Throwable $error) {
                        $errorCount = 1;
                        error_log('[seo.audit-run] ' . $error->getMessage());
                        $runData['error'] = $error instanceof SeoException ? $error->errorCode : 'seo_unavailable';
                    }
                    Support::query($this->module->db, "UPDATE seo_audit_runs SET state='complete',processed=1,errors=?,data=?,revision=revision+1,updated_at=? WHERE id=? AND state<>'cancelled'", [$errorCount, Support::json($runData), Support::timestamp(($this->module->clock)()), $id]);

                    return $this->run($id);
                });
            }, false);
        } catch (SeoException $error) {
            if ($error->errorCode === 'render_busy') {
                throw new SeoException('audit_busy', 503, ['retry_after' => 1]);
            }
            throw $error;
        }
    }

    public function run(string $id): array
    {
        $row = Support::one($this->module->db, 'SELECT * FROM seo_audit_runs WHERE id=?', [$id]) ?? throw new SeoException('audit_run_not_found', 404);
        $row['data'] = Support::decode($row['data']);
        return $row;
    }

    /** History describes findings from this run even after its target or saved audit changes. */
    private static function findingSummary(array $result): array
    {
        return [
            'score' => $result['score'],
            'errors' => $result['counts']['error'],
            'warnings' => $result['counts']['warning'],
            'info' => $result['counts']['info'],
        ];
    }

    public function cancel(string $id, array $input): array
    {
        Support::transaction($this->module->db, function () use ($id, $input): void {
            Support::version($this->run($id), $input);
            Support::query($this->module->db, 'UPDATE seo_audit_runs SET state=\'cancelled\',revision=revision+1,updated_at=? WHERE id=?', [Support::timestamp(($this->module->clock)()), $id]);
        });
        return $this->run($id);
    }

    public function work(float $seconds = 20, bool $network = true): array
    {
        if ($this->module->db->inTransaction()) {
            throw new SeoException('commit_required', 409);
        }
        // Old installations may still have automatic audit jobs; discard them without executing checks.
        Support::query($this->module->db, "DELETE FROM seo_jobs WHERE kind='cms_audit'");
        Support::query($this->module->db, "INSERT INTO seo_settings(key,value,revision,updated_at) VALUES ('worker_seen',?,1,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value,updated_at=excluded.updated_at", [Support::timestamp(($this->module->clock)()), Support::timestamp(($this->module->clock)())]);
        $deadline = microtime(true) + min(50, max(0.05, $seconds));
        $count = $this->deletions($deadline);
        while (microtime(true) < $deadline - 0.05) {
            $job = Support::one($this->module->db, "SELECT * FROM seo_jobs WHERE kind NOT IN ('delete_files','delete_resource') AND available_at<=? ORDER BY id LIMIT 1", [(int) ($this->module->clock)()]);
            if (!$job) {
                break;
            }
            $this->module->files->locked('job:' . $job['id'], function () use ($job, &$count): void {
                $current = Support::one($this->module->db, 'SELECT * FROM seo_jobs WHERE id=?', [$job['id']]);
                if (!$current) {
                    return;
                }
                $payload = Support::decode($current['payload']);
                try {
                    $done = true;
                    if ($current['kind'] === 'projection') {
                        $this->module->admin->refresh($payload['target']);
                    } elseif ($current['kind'] === 'projection_rebuild') {
                        $batch = $this->module->admin->rebuild($payload['cursor'], 25);
                        $done = $batch['done'];
                        $payload['cursor'] = $batch['cursor'];
                    } elseif ($current['kind'] === 'import_cover') {
                        $asset = $this->module->assets->importLocal($payload['media']);
                        Support::transaction($this->module->db, function () use ($asset, $payload): void {
                            Support::query($this->module->db, "INSERT OR IGNORE INTO seo_asset_usages(type,resource_id,owner_type,owner_id) SELECT 'asset',?,'cover',owner_id FROM seo_asset_usages WHERE type='media' AND resource_id=? AND owner_type='cover_pending'", [$asset['id'], $payload['media']]);
                            $owners = Support::query($this->module->db, "SELECT owner_id FROM seo_asset_usages WHERE type='media' AND resource_id=? AND owner_type='cover_pending'", [$payload['media']])->fetchAll(PDO::FETCH_COLUMN);
                            foreach ($owners as $owner) {
                                $targetId = explode(':', $owner, 2)[0];
                                Support::query($this->module->db, "INSERT INTO seo_jobs(kind,job_key,payload) VALUES ('projection',?,?) ON CONFLICT(kind,job_key) DO UPDATE SET payload=excluded.payload", [$targetId, Support::json(['target' => $targetId])]);
                            }
                            Support::query($this->module->db, "DELETE FROM seo_asset_usages WHERE type='media' AND resource_id=? AND owner_type='cover_pending'", [$payload['media']]);
                        });
                    } elseif ($current['kind'] === 'sync_slot') {
                        $this->module->targets->synchronize($payload['slot']);
                    } elseif ($current['kind'] === 'sync_item') {
                        $this->module->targets->synchronize($payload['slot'], $payload['uid']);
                    } elseif ($current['kind'] === 'index') {
                        $batch = Support::transaction($this->module->db, fn () => $this->module->targets->indexBatch($payload['slot'], (int) $payload['cursor']));
                        $done = $batch['done'];
                        $payload['cursor'] = $batch['cursor'];
                    }
                    if ($done) {
                        Support::query($this->module->db, 'DELETE FROM seo_jobs WHERE id=? AND payload=?', [$current['id'], $current['payload']]);
                    } else {
                        Support::query($this->module->db, 'UPDATE seo_jobs SET payload=? WHERE id=? AND payload=?', [Support::json($payload), $current['id'], $current['payload']]);
                    }
                    $count++;
                } catch (\Throwable $error) {
                    $this->retry($current, $error);
                }
            });
        }
        $stats = $this->module->social->aggregate($deadline);
        $dirty = Support::one($this->module->db, "SELECT value FROM seo_settings WHERE key='sitemap_dirty'");
        while ($dirty && $dirty['value'] === 'true' && microtime(true) < $deadline - 0.1) {
            try {
                if ($this->module->site->buildStep()['done']) {
                    break;
                }
            } catch (SeoException $error) {
                if ($error->errorCode !== 'public_urls_required') {
                    throw $error;
                }
                break;
            }
        }
        if (microtime(true) < $deadline) {
            $this->garbageCollect($deadline);
        }
        return ['jobs' => $count, 'bot_requests' => $stats];
    }

    /** Limit simultaneous foreground audits without blocking a shared-hosting PHP worker. */
    private function auditSlot(callable $operation): array
    {
        for ($slot = 0; $slot < 2; $slot++) {
            try {
                return $this->module->files->locked('global-audit:' . $slot, $operation, false);
            } catch (SeoException $error) {
                if ($error->errorCode !== 'render_busy') {
                    throw $error;
                }
            }
        }
        throw new SeoException('audit_busy', 503, ['retry_after' => 1]);
    }

    public function deletions(float $deadline): int
    {
        $count = 0;
        $jobs = Support::query($this->module->db, "SELECT * FROM seo_jobs WHERE kind IN ('delete_files','delete_resource') AND available_at<=? ORDER BY id LIMIT 30", [(int) ($this->module->clock)()])->fetchAll(PDO::FETCH_ASSOC);
        foreach ($jobs as $job) {
            if (microtime(true) >= $deadline) {
                break;
            }
            try {
                $payload = Support::decode($job['payload']);
                if ($job['kind'] === 'delete_files') {
                    $this->module->og->deleteGeneration($payload['target'], (int) $payload['generation']);
                } else {
                    $used = Support::one($this->module->db, 'SELECT id FROM seo_fonts WHERE file=? UNION ALL SELECT id FROM seo_assets WHERE file=? LIMIT 1', [$payload['file'], $payload['file']]);
                    if (!$used && is_file($this->module->files->path($payload['file'])) && !unlink($this->module->files->path($payload['file']))) {
                        throw new SeoException('file_delete_failed', 503);
                    }
                }
                Support::query($this->module->db, 'DELETE FROM seo_jobs WHERE id=? AND payload=?', [$job['id'], $job['payload']]);
                $count++;
            } catch (\Throwable $error) {
                $this->retry($job, $error);
            }
        }
        return $count;
    }

    private function retry(array $job, \Throwable $error): void
    {
        Support::query($this->module->db, 'UPDATE seo_jobs SET attempts=attempts+1,available_at=? WHERE id=? AND payload=?', [(int) ($this->module->clock)() + min(3600, 2 ** min(11, (int) $job['attempts'] + 1)), $job['id'], $job['payload']]);
        error_log('[seo.job] ' . $job['kind'] . ': ' . $error->getMessage());
    }

    public function garbageCollect(float $deadline): array
    {
        $quota = $this->module->settings->get()['data']['ogQuotaBytes'];
        $total = (int) Support::one($this->module->db, 'SELECT COALESCE(SUM(bytes),0) AS bytes FROM seo_og_cache')['bytes'];
        $cutoff = (int) ($this->module->clock)() - 90 * 86400;
        $deleted = 0;
        $cursorRow = Support::one($this->module->db, "SELECT value FROM seo_settings WHERE key='gc_cursor'");
        $cursor = Support::decode($cursorRow['value'] ?? null) + ['time' => -1, 'target' => '', 'locale' => ''];
        $statement = Support::query($this->module->db, 'SELECT * FROM seo_og_cache WHERE (last_used_at,target_id,locale)>(?,?,?) ORDER BY last_used_at,target_id,locale LIMIT 500', [$cursor['time'], $cursor['target'], $cursor['locale']]);
        $scanned = 0;
        while ($row = $statement->fetch(PDO::FETCH_ASSOC)) {
            if (microtime(true) >= $deadline) {
                break;
            }
            $scanned++;
            $cursor = ['time' => (int) $row['last_used_at'], 'target' => $row['target_id'], 'locale' => $row['locale']];
            if ($total <= $quota && ($row['last_bot_at'] ?? $row['generated_at']) >= $cutoff) {
                continue;
            }
            $this->module->files->locked('og:' . $row['target_id'] . ':' . $row['locale'], function () use ($row, &$total, &$deleted): void {
                $current = Support::one($this->module->db, 'SELECT * FROM seo_og_cache WHERE target_id=? AND locale=?', [$row['target_id'], $row['locale']]);
                if (!$current || $current['render_hash'] !== $row['render_hash']) {
                    return;
                }
                if (is_file($this->module->files->path($current['file']))) {
                    unlink($this->module->files->path($current['file']));
                }
                Support::query($this->module->db, 'DELETE FROM seo_og_cache WHERE target_id=? AND locale=? AND render_hash=?', [$current['target_id'], $current['locale'], $current['render_hash']]);
                $total -= (int) $current['bytes'];
                $deleted++;
            });
        }
        if ($scanned < 500 && microtime(true) < $deadline) {
            $cursor = ['time' => -1, 'target' => '', 'locale' => ''];
        }
        Support::query($this->module->db, "INSERT INTO seo_settings(key,value,revision,updated_at) VALUES ('gc_cursor',?,1,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value,updated_at=excluded.updated_at", [Support::json($cursor), Support::timestamp(($this->module->clock)())]);
        $this->cleanDirectory('cache/og', $deadline, static fn ($file) => $file->getMTime() < time() - 3600);
        return ['deleted' => $deleted, 'bytes' => $total];
    }

    private function cleanDirectory(string $relative, float $deadline, callable $eligible): void
    {
        $directory = $this->module->files->directory($relative);
        $key = 'file_gc_' . hash('sha256', $relative);
        $row = Support::one($this->module->db, 'SELECT value FROM seo_settings WHERE key=?', [$key]);
        $cursor = (int) ($row['value'] ?? 0);
        $iterator = new \DirectoryIterator($directory);
        try {
            $iterator->seek($cursor);
        } catch (\OutOfBoundsException) {
            $iterator->rewind();
        }
        $scanned = 0;
        while ($iterator->valid() && microtime(true) < $deadline && $scanned < 100) {
            $file = new \SplFileInfo($iterator->getPathname());
            $iterator->next();
            $scanned++;
            if (!$file->isFile() || !$eligible($file)) {
                continue;
            }
            $known = Support::one($this->module->db, 'SELECT 1 FROM seo_og_cache WHERE file=?', [$relative . '/' . $file->getFilename()]);
            if (!$known) {
                unlink($file->getPathname());
            }
        }
        $cursor = $iterator->valid() ? (int) $iterator->key() : 0;
        Support::query($this->module->db, 'INSERT INTO seo_settings(key,value,revision,updated_at) VALUES (?,?,1,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value,updated_at=excluded.updated_at', [$key, (string) $cursor, Support::timestamp(($this->module->clock)())]);
    }
}
