<?php
/**
 * NOMAD CMS — deterministic 1200×630 GD layer renderer.
 * TrueType measurements drive Unicode wrapping, shrinking and ellipsis; source images are bounded.
 * Resource resolution is separate from GD work so cache hits never decode images or create canvases.
 * @package NomadCMS\Services\Seo
 */
declare(strict_types=1);

namespace NomadCMS\Services\Seo;

/** Code-free OG template renderer with explicit font and image dependencies. */
class OgRenderer
{
    public function __construct(private readonly Assets $assets, private readonly Templates $templates)
    {
    }

    public function resources(array $document, array $context, ?string $defaultFont): array
    {
        $resolved = [];
        foreach ($document['layers'] as $layer) {
            if ($layer['type'] === 'text') {
                $id = $layer['fontId'] ?? $defaultFont;
                if (!$id) {
                    throw new SeoException('font_required');
                }
                $path = $this->assets->fontPath($id);
                $resolved[$layer['id']] = ['path' => $path, 'hash' => $this->assets->get('font', $id)['hash']];
            } elseif ($layer['type'] === 'image') {
                $id = isset($layer['fieldPath']) ? ($context['field:' . $layer['fieldPath']] ?? null) : ($layer['assetId'] ?? ($context[$layer['binding'] ?? 'cover'] ?? null));
                if ($id === null || $id === '') {
                    continue;
                }
                if (!is_string($id)) {
                    throw new SeoException('cover_requires_imported_asset');
                }
                $asset = $this->assets->get('asset', $id);
                $resolved[$layer['id']] = ['path' => $this->assets->imagePath($id), 'hash' => $asset['hash']];
            }
        }
        return $resolved;
    }

    public function render(array $document, array $context, array $resources): string
    {
        if (!extension_loaded('gd')) {
            throw new SeoException('gd_required', 503);
        }
        // Immutable active versions remain renderable after a schema field is removed.
        $this->templates->validate($document, false);
        $canvas = imagecreatetruecolor(1200, 630);
        try {
            $background = $document['background'] ?? [];
            imagefill($canvas, 0, 0, $this->color($canvas, $background['color'] ?? '#ffffff'));
            if (isset($background['gradient'])) {
                $this->gradient($canvas, $background['gradient']);
            }
            foreach ($document['layers'] as $layer) {
                $width = (int) $layer['width'];
                $height = (int) $layer['height'];
                $surface = imagecreatetruecolor($width, $height);
                try {
                    imagealphablending($surface, false);
                    imagesavealpha($surface, true);
                    imagefill($surface, 0, 0, imagecolorallocatealpha($surface, 0, 0, 0, 127));
                    imagealphablending($surface, true);
                    if ($layer['type'] === 'text') {
                        $text = isset($layer['fieldPath']) ? ($context['field:' . $layer['fieldPath']] ?? '') : (isset($layer['binding']) ? ($context[$layer['binding']] ?? '') : ($layer['text'] ?? ''));
                        $this->text($surface, $layer, is_scalar($text) ? (string) $text : '', $resources[$layer['id']]['path']);
                    } elseif ($layer['type'] === 'image') {
                        if (isset($resources[$layer['id']])) {
                            $this->image($surface, $layer, $resources[$layer['id']]['path']);
                        }
                    } elseif ($layer['type'] === 'ellipse') {
                        imagefilledellipse($surface, (int) ($width / 2), (int) ($height / 2), $width, $height, $this->color($surface, $layer['color'] ?? '#000000'));
                    } else {
                        imagefilledrectangle($surface, 0, 0, $width - 1, $height - 1, $this->color($surface, $layer['color'] ?? '#000000'));
                    }
                    $radius = in_array($layer['type'], ['roundedRectangle', 'image'], true) ? (int) ($layer['radius'] ?? 0) : 0;
                    $this->mask($surface, min($radius, (int) ($width / 2), (int) ($height / 2)), (float) ($layer['opacity'] ?? 1));
                    imagecopy($canvas, $surface, (int) $layer['x'], (int) $layer['y'], 0, 0, $width, $height);
                } finally {
                    imagedestroy($surface);
                }
            }
            ob_start();
            imagepng($canvas, null, 6);
            return ob_get_clean();
        } finally {
            imagedestroy($canvas);
        }
    }

    public function layout(string $text, string $font, array $layer): array
    {
        $text = self::transformText($text, $layer['textTransform'] ?? 'none');
        $maximum = (int) ($layer['fontSize'] ?? 48);
        $minimum = (int) ($layer['minFontSize'] ?? 24);
        $maxLines = (int) ($layer['maxLines'] ?? 3);
        $lines = $this->wrap($text, $font, $maximum, (int) $layer['width']);
        $lineHeight = $maximum * (float) ($layer['lineHeight'] ?? 1.2);
        if (count($lines) <= $maxLines && count($lines) * $lineHeight <= (int) $layer['height']) {
            return ['size' => $maximum, 'lines' => $lines, 'lineHeight' => $lineHeight, 'truncated' => false];
        }
        $low = $minimum;
        $high = $maximum - 1;
        $best = null;
        while ($low <= $high) {
            $size = (int) floor(($low + $high) / 2);
            $lines = $this->wrap($text, $font, $size, (int) $layer['width']);
            $lineHeight = $size * (float) ($layer['lineHeight'] ?? 1.2);
            if (count($lines) <= $maxLines && count($lines) * $lineHeight <= (int) $layer['height']) {
                $best = ['size' => $size, 'lines' => $lines, 'lineHeight' => $lineHeight, 'truncated' => false];
                $low = $size + 1;
            } else {
                $high = $size - 1;
            }
        }
        if ($best !== null) {
            return $best;
        }
        $size = $minimum;
        $lineHeight = $size * (float) ($layer['lineHeight'] ?? 1.2);
        $capacity = max(1, min($maxLines, (int) floor($layer['height'] / $lineHeight)));
        $lines = array_slice($this->wrap($text, $font, $size, (int) $layer['width']), 0, $capacity);
        $last = count($lines) - 1;
        if ($last >= 0) {
            while ($lines[$last] !== '' && $this->measure($lines[$last] . '…', $font, $size)['width'] > $layer['width']) {
                $lines[$last] = mb_substr($lines[$last], 0, -1);
            }
            $lines[$last] .= '…';
        }
        return ['size' => $size, 'lines' => $lines, 'lineHeight' => $lineHeight, 'truncated' => true];
    }

    /** Apply display-only Unicode casing before measuring and wrapping the text. */
    public static function transformText(string $text, string $transform): string
    {
        return match ($transform) {
            'none' => $text,
            'uppercase' => mb_strtoupper($text, 'UTF-8'),
            'lowercase' => mb_strtolower($text, 'UTF-8'),
            'capitalize' => preg_replace_callback('/(^|[^\p{L}\p{N}])([\p{L}\p{N}])/u', static fn ($match) => $match[1] . mb_strtoupper($match[2], 'UTF-8'), $text),
            default => throw new SeoException('invalid_text_transform'),
        };
    }

    private function measure(string $text, string $font, int $size): array
    {
        $box = imagettfbbox($size * 0.75, 0, $font, $text === '' ? ' ' : $text);
        if ($box === false) {
            throw new SeoException('font_render_failed');
        }
        return ['width' => max($box[0], $box[2], $box[4], $box[6]) - min($box[0], $box[2], $box[4], $box[6]), 'left' => min($box[0], $box[2], $box[4], $box[6]), 'top' => min($box[1], $box[3], $box[5], $box[7])];
    }

    private function wrap(string $text, string $font, int $size, int $width): array
    {
        $lines = [];
        foreach (explode("\n", str_replace(["\r\n", "\r"], "\n", $text)) as $paragraph) {
            $line = '';
            foreach (preg_split('/\s+/u', trim($paragraph), -1, PREG_SPLIT_NO_EMPTY) as $word) {
                $candidate = $line === '' ? $word : $line . ' ' . $word;
                if ($this->measure($candidate, $font, $size)['width'] <= $width) {
                    $line = $candidate;
                    continue;
                }
                if ($line !== '') {
                    $lines[] = $line;
                    $line = '';
                }
                foreach (mb_str_split($word) as $character) {
                    if ($line !== '' && $this->measure($line . $character, $font, $size)['width'] > $width) {
                        $lines[] = $line;
                        $line = '';
                    }
                    $line .= $character;
                }
            }
            $lines[] = $line;
        }
        return $lines;
    }

    private function text(\GdImage $surface, array $layer, string $text, string $font): void
    {
        if ($text === '') {
            return;
        }
        $layout = $this->layout($text, $font, $layer);
        $color = $this->color($surface, $layer['color'] ?? '#000000');
        foreach ($layout['lines'] as $index => $line) {
            $metrics = $this->measure($line, $font, $layout['size']);
            $x = match ($layer['align'] ?? 'left') {
                'center' => ($layer['width'] - $metrics['width']) / 2,
                'right' => $layer['width'] - $metrics['width'], default => 0,
            };
            $y = $index * $layout['lineHeight'] - $this->measure('Ág', $font, $layout['size'])['top'];
            imagettftext($surface, $layout['size'] * 0.75, 0, (int) ($x - $metrics['left']), (int) $y, $color, $font, $line);
        }
    }

    private function image(\GdImage $surface, array $layer, string $path): void
    {
        $source = Assets::normalizedFile($path);
        try {
            $info = [imagesx($source), imagesy($source)];
            $width = imagesx($surface);
            $height = imagesy($surface);
            $ratio = ($layer['fit'] ?? 'cover') === 'cover' ? max($width / $info[0], $height / $info[1]) : min($width / $info[0], $height / $info[1]);
            $destinationWidth = (int) round($info[0] * $ratio);
            $destinationHeight = (int) round($info[1] * $ratio);
            [$focusX, $focusY] = $layer['focus'] ?? [0.5, 0.5];
            $x = (int) round(($width - $destinationWidth) * $focusX);
            $y = (int) round(($height - $destinationHeight) * $focusY);
            imagecopyresampled($surface, $source, $x, $y, 0, 0, $destinationWidth, $destinationHeight, $info[0], $info[1]);
        } finally {
            imagedestroy($source);
        }
    }

    private function color(\GdImage $image, string $hex): int
    {
        Templates::color($hex);
        return imagecolorallocate($image, hexdec(substr($hex, 1, 2)), hexdec(substr($hex, 3, 2)), hexdec(substr($hex, 5, 2)));
    }

    private function gradient(\GdImage $image, array $gradient): void
    {
        $vertical = ($gradient['direction'] ?? 'horizontal') === 'vertical';
        $steps = $vertical ? 630 : 1200;
        $from = array_map('hexdec', str_split(substr($gradient['from'], 1), 2));
        $to = array_map('hexdec', str_split(substr($gradient['to'], 1), 2));
        for ($step = 0; $step < $steps; $step++) {
            $ratio = $step / ($steps - 1);
            $rgb = [];
            for ($channel = 0; $channel < 3; $channel++) {
                $rgb[] = (int) round($from[$channel] + ($to[$channel] - $from[$channel]) * $ratio);
            }
            $color = imagecolorallocate($image, ...$rgb);
            imageline($image, $vertical ? 0 : $step, $vertical ? $step : 0, $vertical ? 1199 : $step, $vertical ? $step : 629, $color);
        }
    }

    private function mask(\GdImage $image, int $radius, float $opacity): void
    {
        if ($radius === 0 && $opacity === 1.0) {
            return;
        }
        imagealphablending($image, false);
        $width = imagesx($image);
        $height = imagesy($image);
        for ($y = 0; $y < $height; $y++) {
            for ($x = 0; $x < $width; $x++) {
                $color = imagecolorat($image, $x, $y);
                $alpha = ($color >> 24) & 127;
                $cornerX = $x < $radius ? $radius - $x : ($x >= $width - $radius ? $x - ($width - $radius - 1) : 0);
                $cornerY = $y < $radius ? $radius - $y : ($y >= $height - $radius ? $y - ($height - $radius - 1) : 0);
                $alpha = $cornerX * $cornerY > 0 && $cornerX * $cornerX + $cornerY * $cornerY > $radius * $radius ? 127 : (int) round(127 - (127 - $alpha) * $opacity);
                imagesetpixel($image, $x, $y, ($alpha << 24) | ($color & 0xffffff));
            }
        }
    }
}
