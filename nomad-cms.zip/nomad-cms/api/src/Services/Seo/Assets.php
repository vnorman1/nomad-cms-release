<?php
/**
 * NOMAD CMS — uploaded fonts, opt-in Google fonts and bounded graphic resources.
 * No bundled/downloaded default font. Binary validation precedes FreeType and image decoding.
 * Fonts and standalone graphics live in private storage; CMS images reference live uploads.
 * Referenced resources cannot be deleted and original CMS media is never copied or modified.
 * Studio image choices are canonical live media links; legacy standalone IDs remain readable.
 * @package NomadCMS\Services\Seo
 */
declare(strict_types=1);

namespace NomadCMS\Services\Seo;

use PDO;

/** Resource repository and bounded import pipeline for the OG editor. */
final class Assets
{
    public const GOOGLE_RECOMMENDATIONS = ['Roboto', 'Open Sans', 'Montserrat', 'Lato', 'Source Sans 3'];

    public function __construct(
        private readonly PDO $db,
        private readonly FileStore $files,
        private readonly \Closure $clock,
        private readonly HttpClient $google,
        private readonly ?string $mediaDirectory = null,
    ) {
    }

    public function list(string $type, string $cursor = '', int $limit = 50, string $query = ''): array
    {
        $table = $this->table($type);
        $condition = $type === 'asset'
            ? "r.media_id IS NOT NULL AND r.media_id<>'' AND r.id=(SELECT MIN(link.id) FROM seo_assets link WHERE link.media_id=r.media_id)"
            : '';
        $page = ResourceSearch::page($this->db, $table, 'r.*', $cursor, $limit, $query, $condition);
        $page['items'] = array_map($this->publicResource(...), $page['items']);
        return $page;
    }

    public function get(string $type, string $id): array
    {
        $row = Support::one($this->db, 'SELECT * FROM ' . $this->table($type) . ' WHERE id=?', [$id]) ?? throw new SeoException('resource_not_found', 404);
        return $type === 'asset' ? $this->liveResource($row) : $row;
    }

    public function publicResource(array $row): array
    {
        if (isset($row['width'], $row['height'], $row['file'])) {
            $row = $this->liveResource($row);
            $row['mime'] ??= self::imageMime($row['file']);
            $row['width'] = (int) $row['width'];
            $row['height'] = (int) $row['height'];
        }
        unset($row['file'], $row['source_hash']);
        if (isset($row['data'])) {
            $row['data'] = Support::decode($row['data']);
        }
        $row['revision'] = (int) $row['revision'];
        return $row;
    }

    public function uploadFont(string $name, string $bytes): array
    {
        self::validateFont($bytes);
        $id = Support::id();
        $file = 'fonts/' . $id . '.ttf';
        $this->files->write($file, $bytes);
        try {
            self::probeFont($this->files->path($file));
            Support::query($this->db, 'INSERT INTO seo_fonts(id,name,source,data,file,hash,revision,updated_at) VALUES (?,?,\'upload\',\'{}\',?,?,1,?)', [$id, Support::text($name, 200), $file, hash('sha256', $bytes), Support::timestamp(($this->clock)())]);
        } catch (\Throwable $error) {
            unlink($this->files->path($file));
            throw $error;
        }
        return $this->publicResource($this->get('font', $id));
    }

    public function googleFont(string $family, int $weight = 700, bool $italic = false): array
    {
        if (!preg_match('/^[A-Za-z][A-Za-z0-9 ]{0,79}$/D', $family) || strcasecmp(trim($family), 'Inter') === 0 || $weight < 100 || $weight > 900 || $weight % 100 !== 0) {
            throw new SeoException('invalid_google_font');
        }
        $id = Support::id();
        $data = ['family' => $family, 'weight' => $weight, 'italic' => $italic, 'license' => 'https://fonts.google.com/specimen/' . rawurlencode($family) . '/license', 'status' => 'pending'];
        Support::query($this->db, 'INSERT INTO seo_fonts(id,name,source,data,revision,updated_at) VALUES (?, ?,\'google\',?,1,?)', [$id, $family . ' ' . $weight . ($italic ? ' italic' : ''), Support::json($data), Support::timestamp(($this->clock)())]);
        // Registration is cheap and offline. The first preview/activation/render imports this selected font.
        return $this->publicResource($this->get('font', $id));
    }

    public function fontPath(string $id): string
    {
        $row = $this->get('font', $id);
        if ($row['file'] && is_file($this->files->path($row['file']))) {
            return $this->files->path($row['file']);
        }
        if ($row['source'] !== 'google') {
            throw new SeoException('font_file_missing', 503);
        }
        return $this->files->locked('google-font:' . $id, function () use ($id): string {
            $row = $this->get('font', $id);
            if ($row['file'] && is_file($this->files->path($row['file']))) {
                return $this->files->path($row['file']);
            }
            $data = Support::decode($row['data']);
            $family = $data['family'] . ':' . $data['weight'] . ($data['italic'] ? 'italic' : '');
            $css = $this->google->get('https://fonts.googleapis.com/css?family=' . rawurlencode($family) . '&subset=latin-ext', 65536, 5, 1, ['User-Agent' => 'NomadCMS-OG/1.0']);
            if ($css['status'] !== 200 || !preg_match('~url\(\s*[\x22\x27]?(https://fonts\.gstatic\.com/[^\s\x22\x27)]+\.ttf(?:\?[^\s\x22\x27)]*)?)[\x22\x27]?\s*\)~i', $css['body'], $match)) {
                throw new SeoException('google_truetype_unavailable', 503, ['alternative' => 'upload_static_ttf']);
            }
            $response = $this->google->get($match[1], 2097152, 8, 1);
            if ($response['status'] !== 200) {
                throw new SeoException('google_font_unavailable', 503);
            }
            self::validateFont($response['body']);
            $file = 'fonts/' . $id . '.ttf';
            $this->files->write($file, $response['body']);
            self::probeFont($this->files->path($file));
            $data['status'] = 'ready';
            Support::query($this->db, 'UPDATE seo_fonts SET file=?,hash=?,data=?,revision=revision+1,updated_at=? WHERE id=?', [$file, hash('sha256', $response['body']), Support::json($data), Support::timestamp(($this->clock)()), $id]);
            return $this->files->path($file);
        });
    }

    public static function validateFont(string $bytes): void
    {
        $length = strlen($bytes);
        if ($length < 64 || $length > 2097152 || substr($bytes, 0, 4) !== "\x00\x01\x00\x00") {
            throw new SeoException('invalid_static_ttf');
        }
        $count = unpack('n', substr($bytes, 4, 2))[1];
        if ($count < 5 || $count > 128 || 12 + 16 * $count > $length) {
            throw new SeoException('invalid_font_directory');
        }
        $tables = [];
        $ranges = [];
        for ($index = 0; $index < $count; $index++) {
            $offset = 12 + 16 * $index;
            $tag = substr($bytes, $offset, 4);
            $record = unpack('Noffset/Nlength', substr($bytes, $offset + 8, 8));
            if (isset($tables[$tag]) || $record['offset'] < 12 + 16 * $count || $record['offset'] > $length || $record['length'] > $length - $record['offset']) {
                throw new SeoException('invalid_font_table');
            }
            if ($record['length'] > 0) {
                foreach ($ranges as [$start, $end]) {
                    if ($record['offset'] < $end && $record['offset'] + $record['length'] > $start) {
                        throw new SeoException('overlapping_font_tables');
                    }
                }
                $ranges[] = [$record['offset'], $record['offset'] + $record['length']];
            }
            $tables[$tag] = $record;
        }
        foreach (['cmap', 'head', 'hhea', 'hmtx', 'maxp', 'loca', 'glyf'] as $tag) {
            if (empty($tables[$tag]['length'])) {
                throw new SeoException('missing_font_table');
            }
        }
        if (isset($tables['fvar'])) {
            throw new SeoException('variable_font_unsupported', 422, ['alternative' => 'upload_static_ttf']);
        }
    }

    private static function probeFont(string $path): void
    {
        if (!function_exists('imagettfbbox')) {
            throw new SeoException('gd_freetype_required', 503);
        }
        if (@imagettfbbox(20, 0, $path, 'Árvíztűrő tükörfúrógép') === false) {
            throw new SeoException('font_render_failed');
        }
    }

    public function uploadImage(string $name, string $bytes, ?string $mediaId = null): array
    {
        if ($mediaId !== null) {
            return $this->importLocal($mediaId);
        }
        $name = Support::text($name, 200);
        $info = self::imageInfo($bytes);
        $image = self::normalizedImage($bytes);
        $info[0] = imagesx($image);
        $info[1] = imagesy($image);
        $id = Support::id();
        $extension = match ($info['mime']) {
            'image/jpeg' => 'jpg',
            'image/webp' => function_exists('imagewebp') ? 'webp' : 'png',
            default => 'png',
        };
        $file = 'assets/' . $id . '.' . $extension;
        try {
            imagesavealpha($image, true);
            ob_start();
            try {
                // Photo derivatives retain efficient encodings; transparent PNGs stay lossless.
                $encoded = match ($extension) {
                    'jpg' => imagejpeg($image, null, 85),
                    'webp' => imagewebp($image, null, 85),
                    default => imagepng($image, null, 9),
                };
                $normalized = ob_get_contents();
                if (!$encoded || !is_string($normalized) || $normalized === '') {
                    throw new SeoException('asset_encode_failed', 503);
                }
            } finally {
                ob_end_clean();
            }
        } finally {
            imagedestroy($image);
        }
        $this->files->write($file, $normalized);
        try {
            Support::query($this->db, 'INSERT INTO seo_assets(id,name,media_id,file,hash,width,height,revision,updated_at) VALUES (?,?,?,?,?,?,?,1,?)', [$id, $name, null, $file, hash('sha256', $normalized), $info[0], $info[1], Support::timestamp(($this->clock)())]);
        } catch (\Throwable $error) {
            unlink($this->files->path($file));
            throw $error;
        }
        return $this->publicResource($this->get('asset', $id));
    }

    /** Inspect bounded raster headers without invoking GD, including on cache hits. */
    private static function imageInfo(string $bytes): array
    {
        if (strlen($bytes) > 52428800) {
            throw new SeoException('asset_size_limit');
        }
        return self::validateImageInfo(@getimagesizefromstring($bytes));
    }

    /** Accept ordinary high-resolution media without materializing its encoded bytes in PHP. */
    private static function fileImageInfo(string $path): array
    {
        $size = filesize($path);
        if ($size === false || $size > 52428800) {
            throw new SeoException('asset_size_limit');
        }
        return self::validateImageInfo(@getimagesize($path));
    }

    private static function validateImageInfo(array|false $info): array
    {
        if (!$info || !in_array($info['mime'], ['image/jpeg', 'image/png', 'image/webp'], true) || $info[0] * $info[1] > 50000000 || $info[0] < 1 || $info[1] < 1) {
            throw new SeoException('invalid_asset_image');
        }
        return $info;
    }

    /** Decode one live file without retaining a second, potentially 50 MiB encoded allocation. */
    public static function normalizedFile(string $path): \GdImage
    {
        $info = self::fileImageInfo($path);
        if (!extension_loaded('gd')) {
            throw new SeoException('gd_required', 503);
        }
        $image = match ($info['mime']) {
            'image/jpeg' => @imagecreatefromjpeg($path),
            'image/webp' => @imagecreatefromwebp($path),
            default => @imagecreatefrompng($path),
        };
        if (!$image) {
            throw new SeoException('asset_decode_failed');
        }
        $orientation = $info['mime'] === 'image/jpeg' ? self::jpegFileOrientation($path) : 1;
        return self::normalizeRaster($image, $info, $orientation);
    }

    /** Decode and orient a bounded source, resizing only in memory for OG rendering. */
    public static function normalizedImage(string $bytes): \GdImage
    {
        $info = self::imageInfo($bytes);
        if (!extension_loaded('gd')) {
            throw new SeoException('gd_required', 503);
        }
        $image = @imagecreatefromstring($bytes);
        if (!$image) {
            throw new SeoException('asset_decode_failed');
        }
        $orientation = $info['mime'] === 'image/jpeg' ? self::jpegOrientation($bytes) : 1;
        return self::normalizeRaster($image, $info, $orientation);
    }

    private static function normalizeRaster(\GdImage $image, array $info, int $orientation): \GdImage
    {
        // Standalone uploads normalize once; dynamic CMS sources normalize only on cache misses.
        // The retained raster is limited to 640k pixels/1200px; original uploads stay untouched.
        $ratio = min(1, 1200 / $info[0], 1200 / $info[1], sqrt(640000 / ($info[0] * $info[1])));
        if ($ratio < 1) {
            $width = max(1, (int) floor($info[0] * $ratio));
            $height = max(1, (int) floor($info[1] * $ratio));
            $normalizedImage = imagecreatetruecolor($width, $height);
            imagealphablending($normalizedImage, false);
            imagesavealpha($normalizedImage, true);
            imagefill($normalizedImage, 0, 0, imagecolorallocatealpha($normalizedImage, 0, 0, 0, 127));
            imagecopyresampled($normalizedImage, $image, 0, 0, 0, 0, $width, $height, $info[0], $info[1]);
            unset($image);
            $image = $normalizedImage;
            $info[0] = $width;
            $info[1] = $height;
        }
        // Rotate only the bounded raster so EXIF correction never retains two full source canvases.
        if ($info['mime'] === 'image/jpeg') {
            $image = self::orientJpeg($image, $orientation);
        }
        return $image;
    }

    public function imagePath(string $id): string
    {
        $asset = $this->get('asset', $id);
        if ($asset['media_id']) {
            try {
                return $this->mediaInfo($asset['media_id'])['path'];
            } catch (SeoException $error) {
                throw new SeoException('asset_file_missing', 503, [
                    'assetId' => $id,
                    'mediaId' => $asset['media_id'],
                    'recovery' => 'restore_upload_or_relink',
                    'cause' => $error->getMessage(),
                ]);
            }
        }
        $path = $this->files->path($asset['file']);
        if (!is_file($path)) {
            return $this->files->locked('asset-recovery:' . $id, function () use ($id): string {
                $asset = $this->get('asset', $id);
                $path = $this->files->path($asset['file']);
                if (is_file($path)) {
                    return $path;
                }
                // Legacy imports can retain an older resource ID after its duplicate file was lost.
                // Restore only identical bytes so immutable template/history references keep their hash.
                $copies = Support::query($this->db, 'SELECT file FROM seo_assets WHERE hash=? AND id<>? LIMIT 32', [$asset['hash'], $id])->fetchAll(PDO::FETCH_COLUMN);
                foreach ($copies as $file) {
                    $copy = $this->files->path($file);
                    if (is_file($copy) && hash_file('sha256', $copy) === $asset['hash']) {
                        $this->files->copy($copy, $asset['file']);
                        return $path;
                    }
                }
                throw new SeoException('asset_file_missing', 503, [
                    'assetId' => $id,
                    'mediaId' => $asset['media_id'],
                    'recovery' => $asset['media_id'] ? 'import_source_and_relink' : 'upload_and_relink',
                ]);
            });
        }
        return $path;
    }

    /** Inspect real files by their headers; persisted private markers fall back to their encoding. */
    public static function imageMime(string $file): string
    {
        if (is_file($file)) {
            $info = @getimagesize($file);
            if (isset($info['mime']) && in_array($info['mime'], ['image/jpeg', 'image/png', 'image/webp'], true)) {
                return $info['mime'];
            }
        }
        return match (strtolower(pathinfo($file, PATHINFO_EXTENSION))) {
            'jpg', 'jpeg' => 'image/jpeg',
            'webp' => 'image/webp',
            default => 'image/png',
        };
    }

    /** Read only the bounded IFD0 orientation tag, without requiring the optional EXIF extension. */
    private static function jpegOrientation(string $bytes): int
    {
        $length = strlen($bytes);
        for ($offset = 2; $offset + 4 <= $length;) {
            if (ord($bytes[$offset]) !== 0xff) {
                break;
            }
            $marker = ord($bytes[$offset + 1]);
            if ($marker === 0xff) {
                $offset++;
                continue;
            }
            if ($marker === 0xda || $marker === 0xd9) {
                break;
            }
            if ($marker === 0x01 || ($marker >= 0xd0 && $marker <= 0xd8)) {
                $offset += 2;
                continue;
            }
            $segmentLength = unpack('n', substr($bytes, $offset + 2, 2))[1];
            if ($segmentLength < 2 || $offset + 2 + $segmentLength > $length) {
                break;
            }
            if ($marker !== 0xe1 || $segmentLength < 16 || substr($bytes, $offset + 4, 6) !== "Exif\0\0") {
                $offset += 2 + $segmentLength;
                continue;
            }
            $tiff = substr($bytes, $offset + 10, $segmentLength - 8);
            $endian = substr($tiff, 0, 2);
            if (!in_array($endian, ['II', 'MM'], true)) {
                return 1;
            }
            $read = static function (int $position, int $size) use ($tiff, $endian): ?int {
                if ($position < 0 || $position + $size > strlen($tiff)) {
                    return null;
                }
                $format = $size === 2 ? ($endian === 'II' ? 'v' : 'n') : ($endian === 'II' ? 'V' : 'N');
                return unpack($format, substr($tiff, $position, $size))[1];
            };
            $directory = $read(4, 4);
            if ($read(2, 2) !== 42 || $directory === null || $directory < 8) {
                return 1;
            }
            $count = $read($directory, 2);
            if ($count === null || $count > 128 || $directory + 2 + $count * 12 > strlen($tiff)) {
                return 1;
            }
            for ($index = 0; $index < $count; $index++) {
                $entry = $directory + 2 + $index * 12;
                if ($read($entry, 2) === 0x0112 && $read($entry + 2, 2) === 3 && $read($entry + 4, 4) === 1) {
                    $orientation = $read($entry + 8, 2);
                    return $orientation !== null && $orientation >= 1 && $orientation <= 8 ? $orientation : 1;
                }
            }
            return 1;
        }
        return 1;
    }

    /** Read only JPEG metadata segments; large image payloads never enter the PHP heap. */
    private static function jpegFileOrientation(string $path): int
    {
        $stream = @fopen($path, 'rb');
        if ($stream === false) {
            return 1;
        }
        try {
            if (fread($stream, 2) !== "\xff\xd8") {
                return 1;
            }
            // Each metadata segment has a 16-bit length; cap traversal of malformed headers.
            for ($segment = 0; $segment < 128; $segment++) {
                $marker = fread($stream, 2);
                if (strlen($marker) !== 2 || ord($marker[0]) !== 0xff) {
                    return 1;
                }
                $code = ord($marker[1]);
                if ($code === 0xff) {
                    fseek($stream, -1, SEEK_CUR);
                    continue;
                }
                if ($code === 0xda || $code === 0xd9) {
                    return 1;
                }
                if ($code === 0x01 || ($code >= 0xd0 && $code <= 0xd8)) {
                    continue;
                }
                $lengthBytes = fread($stream, 2);
                if (strlen($lengthBytes) !== 2) {
                    return 1;
                }
                $length = unpack('n', $lengthBytes)[1];
                if ($length < 2) {
                    return 1;
                }
                if ($length === 2) {
                    continue;
                }
                if ($code === 0xe1) {
                    $metadata = fread($stream, $length - 2);
                    if (str_starts_with($metadata, "Exif\0\0")) {
                        return self::jpegOrientation("\xff\xd8" . $marker . $lengthBytes . $metadata);
                    }
                } elseif (fseek($stream, $length - 2, SEEK_CUR) !== 0) {
                    return 1;
                }
            }
            return 1;
        } finally {
            fclose($stream);
        }
    }

    /** Bake browser-visible JPEG orientation into derivative pixels before stripping metadata. */
    private static function orientJpeg(\GdImage $image, int $orientation): \GdImage
    {
        if (in_array($orientation, [2, 5, 7], true)) {
            imageflip($image, IMG_FLIP_HORIZONTAL);
        } elseif ($orientation === 4) {
            imageflip($image, IMG_FLIP_VERTICAL);
        }
        $angle = match ($orientation) {
            3 => 180,
            5, 8 => 90,
            6, 7 => -90,
            default => 0,
        };
        if ($angle === 0) {
            return $image;
        }
        $rotated = imagerotate($image, $angle, 0);
        if (!$rotated) {
            imagedestroy($image);
            throw new SeoException('asset_orientation_failed', 503);
        }
        imagedestroy($image);
        return $rotated;
    }

    /** Recognize local CMS media only; arbitrary remote covers require explicit import. */
    public static function mediaName(mixed $value, string $apiBase): ?string
    {
        if (is_array($value)) {
            $value = $value['filename'] ?? $value['url'] ?? $value['src'] ?? null;
        }
        if (!is_string($value) || $value === '') {
            return null;
        }
        if (preg_match('/[\x00-\x20\x7f\\\\]/', $value)) {
            return null;
        }
        $reference = parse_url($value);
        $base = parse_url($apiBase);
        if ($reference === false || isset($reference['user']) || isset($reference['pass'])) {
            return null;
        }
        $absolute = isset($reference['scheme']) || isset($reference['host']);
        if ($absolute) {
            $scheme = strtolower($reference['scheme'] ?? '');
            $baseScheme = strtolower($base['scheme'] ?? '');
            $port = $reference['port'] ?? ($scheme === 'https' ? 443 : 80);
            $basePort = $base['port'] ?? ($baseScheme === 'https' ? 443 : 80);
            if (!in_array($scheme, ['http', 'https'], true) || $scheme !== $baseScheme || strcasecmp($reference['host'] ?? '', $base['host'] ?? '') !== 0 || $port !== $basePort) {
                return null;
            }
        }
        // MediaLibrary emits ?t= cache-busting URLs. Only the pathname identifies the source.
        $path = $reference['path'] ?? '';
        if (!$absolute && !str_contains($path, '/')) {
            $filename = rawurldecode($path);
            return self::validMediaName($filename) ? $filename : null;
        }
        $basePath = !empty($base['path']) && $base['path'] !== '/' ? $base['path'] : '/api';
        $prefix = rtrim($basePath, '/') . '/uploads/';
        if ($absolute) {
            $candidates = [$prefix];
        } else {
            $candidates = array_values(array_unique([$prefix, '/api/uploads/', '/uploads/']));
        }
        foreach ($candidates as $candidate) {
            if (str_starts_with($path, $candidate)) {
                $filename = rawurldecode(substr($path, strlen($candidate)));
                return self::validMediaName($filename) ? $filename : null;
            }
        }
        return null;
    }

    public static function cover(PDO $db, mixed $value, string $apiBase, ?self $assets = null): ?array
    {
        $asset = null;
        if (is_string($value)) {
            $asset = Support::one($db, 'SELECT id,hash FROM seo_assets WHERE id=?', [$value]);
        }
        if (!$asset) {
            $filename = self::mediaName($value, $apiBase);
            $asset = $filename === null ? null : Support::one($db, 'SELECT id,hash FROM seo_assets WHERE media_id=? ORDER BY id LIMIT 1', [$filename]);
        }
        if ($asset && $assets) {
            $asset['hash'] = $assets->resourceFingerprint($asset['id']);
        }
        return $asset;
    }

    public function importLocal(string $filename): array
    {
        $existing = Support::one($this->db, 'SELECT * FROM seo_assets WHERE media_id=? ORDER BY id LIMIT 1', [$filename]);
        if ($existing) {
            // Existing references need no write or lock, including simultaneous context/PNG previews.
            $this->mediaInfo($filename);
            return $this->publicResource($existing);
        }
        return $this->files->locked('local-media:' . $filename, function () use ($filename): array {
            $source = $this->mediaInfo($filename);
            $existing = Support::one($this->db, 'SELECT * FROM seo_assets WHERE media_id=? ORDER BY id LIMIT 1', [$filename]);
            if ($existing) {
                return $this->publicResource($existing);
            }
            $id = Support::id();
            // A metadata reference only: this marker never points to an uploads copy in FileStore.
            // Existing media_id rows retain their historical file/hash values without migration.
            Support::query($this->db, 'INSERT INTO seo_assets(id,name,media_id,file,hash,width,height,revision,updated_at) VALUES (?,?,?,?,?,?,?,1,?)', [$id, $filename, $filename, 'media/' . $filename, $source['hash'], $source['width'], $source['height'], Support::timestamp(($this->clock)())]);
            return $this->publicResource($this->get('asset', $id));
        });
    }

    /** Resolve live source attributes without mutating resource revisions or historical rows. */
    private function liveResource(array $row): array
    {
        if (isset($row['source'], $row['availability'])) {
            return $row;
        }
        $row['source'] = empty($row['media_id']) ? 'upload' : 'media';
        $row['availability'] = 'ready';
        if ($row['source'] === 'media') {
            try {
                $source = $this->mediaInfo($row['media_id']);
                foreach (['hash', 'width', 'height', 'mime'] as $field) {
                    $row[$field] = $source[$field];
                }
            } catch (SeoException) {
                $row['availability'] = 'missing';
                $row['hash'] = null;
            }
        } elseif (!is_file($this->files->path($row['file']))) {
            $row['availability'] = 'missing';
        }
        return $row;
    }

    /** Headers, orientation and digest of the current uploads bytes; never decodes an image. */
    private function mediaInfo(string $filename): array
    {
        $path = $this->localPath($filename);
        $info = self::fileImageInfo($path);
        $width = $info[0];
        $height = $info[1];
        if ($info['mime'] === 'image/jpeg' && self::jpegFileOrientation($path) >= 5) {
            [$width, $height] = [$height, $width];
        }
        $hash = hash_file('sha256', $path);
        if ($hash === false) {
            throw new SeoException('invalid_local_media');
        }
        return ['path' => $path, 'hash' => $hash, 'width' => $width, 'height' => $height, 'mime' => $info['mime']];
    }

    /** Resource dependencies follow live uploads even for legacy media-backed asset IDs. */
    public function resourceFingerprint(string $id): ?string
    {
        $row = Support::one($this->db, 'SELECT * FROM seo_assets WHERE id=?', [$id]);
        return $row ? $this->liveResource($row)['hash'] : null;
    }

    /** Fingerprint local inputs without decoding them or fetching remote URLs. */
    public function sourceFingerprint(mixed $value, string $apiBase): ?string
    {
        $filename = self::mediaName($value, $apiBase);
        if ($filename === null) {
            return null;
        }
        try {
            return hash_file('sha256', $this->localPath($filename)) ?: null;
        } catch (SeoException) {
            return null;
        }
    }

    private function localPath(string $filename): string
    {
        $filename = \NomadCMS\Services\MediaAliasService::resolve($filename, $this->db);
        if (!self::validMediaName($filename)) {
            throw new SeoException('invalid_local_media');
        }
        $root = realpath($this->mediaDirectory ?? (defined('UPLOAD_DIR') ? UPLOAD_DIR : dirname(__DIR__, 3) . '/uploads'));
        $path = $root ? realpath($root . '/' . $filename) : false;
        if ($path) {
            clearstatcache(true, $path);
        }
        if (!$root || !$path || !str_starts_with($path, $root . '/') || !is_file($path) || filesize($path) > 52428800) {
            throw new SeoException('invalid_local_media');
        }
        return $path;
    }

    private static function validMediaName(string $filename): bool
    {
        return preg_match('/^[a-zA-Z0-9_.-]{1,255}$/D', $filename) === 1
            && $filename !== '.'
            && !str_contains($filename, '..');
    }

    public function rename(string $type, string $id, array $input): array
    {
        return Support::transaction($this->db, function () use ($type, $id, $input): array {
            $row = $this->get($type, $id);
            Support::version($row, $input);
            Support::query($this->db, 'UPDATE ' . $this->table($type) . ' SET name=?,revision=revision+1,updated_at=? WHERE id=?', [Support::text($input['name'] ?? '', 200), Support::timestamp(($this->clock)()), $id]);
            return $this->publicResource($this->get($type, $id));
        });
    }

    public function usages(string $type, string $id): array
    {
        return Support::query($this->db, 'SELECT owner_type,owner_id FROM seo_asset_usages WHERE type=? AND resource_id=? LIMIT 100', [$type, $id])->fetchAll(PDO::FETCH_ASSOC);
    }

    public function delete(string $type, string $id, array $input): void
    {
        Support::transaction($this->db, function () use ($type, $id, $input): void {
            $row = $this->get($type, $id);
            Support::version($row, $input);
            $usages = $this->usages($type, $id);
            if ($usages) {
                throw new SeoException('resource_in_use', 409, ['usages' => $usages]);
            }
            Support::query($this->db, 'DELETE FROM ' . $this->table($type) . ' WHERE id=?', [$id]);
            if ($row['file'] && !($type === 'asset' && $row['media_id'])) {
                Support::query($this->db, "INSERT OR IGNORE INTO seo_jobs(kind,job_key,payload) VALUES ('delete_resource',?,?)", [$type . ':' . $id, Support::json(['file' => $row['file']])]);
            }
        });
    }

    private function table(string $type): string
    {
        return match ($type) {
            'font' => 'seo_fonts', 'asset' => 'seo_assets', default => throw new SeoException('invalid_resource_type'),
        };
    }
}
