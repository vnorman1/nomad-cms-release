<?php
/**
 * NOMAD CMS — byte-preserving SEO head replacement for SPA builds.
 * Token edits avoid DOM serialization of scripts, CSP, asset URLs or the body.
 * Raw script/style/title content is consumed as one token; managed duplicate tags are removed.
 * @package NomadCMS\Services\Seo
 */
declare(strict_types=1);

namespace NomadCMS\Services\Seo;

/** Shared standalone HTML adapter; does not depend on the CMS database. */
final class HtmlHeadInjector
{
    public static function inject(string $html, array $metadata): string
    {
        $fragment = Metadata::head(self::validate($metadata));
        $tokenPattern = '~<!--.*?-->|<(script|style|title)\b(?:[^>\x22\x27]|\x22[^\x22]*\x22|\x27[^\x27]*\x27)*>.*?</\1\s*>|</?[a-zA-Z][a-zA-Z0-9:-]*\b(?:[^>\x22\x27]|\x22[^\x22]*\x22|\x27[^\x27]*\x27)*>~is';
        $offset = 0;
        $start = null;
        $end = null;
        $insert = null;
        $removals = [];
        while (preg_match($tokenPattern, $html, $match, PREG_OFFSET_CAPTURE, $offset)) {
            $token = $match[0][0];
            $position = $match[0][1];
            $offset = $position + strlen($token);
            if ($start === null) {
                if (preg_match('/^<head\b/i', $token)) {
                    $start = $offset;
                    $insert = $start;
                }
                continue;
            }
            if (preg_match('/^<\/head\s*>/i', $token)) {
                $end = $position;
                break;
            }
            if (preg_match('/^<(script|style)\b/i', $token) || str_starts_with($token, '<!--')) {
                continue;
            }
            if (preg_match('/^<title\b/i', $token)) {
                $removals[] = [$position, strlen($token)];
                continue;
            }
            $attributes = self::attributes($token);
            if (preg_match('/^<meta\b/i', $token)) {
                if (isset($attributes['charset'])) {
                    $insert = $offset;
                }
                $key = strtolower($attributes['name'] ?? $attributes['property'] ?? '');
                if (in_array($key, ['description', 'robots'], true) || str_starts_with($key, 'og:') || str_starts_with($key, 'twitter:')) {
                    $removals[] = [$position, strlen($token)];
                }
            } elseif (preg_match('/^<link\b/i', $token)) {
                $relations = preg_split('/\s+/', strtolower($attributes['rel'] ?? ''));
                if (in_array('canonical', $relations, true) || (in_array('alternate', $relations, true) && isset($attributes['hreflang']))) {
                    $removals[] = [$position, strlen($token)];
                }
            }
        }
        if ($start === null) {
            if (preg_match('/<body\b/i', $html, $body, PREG_OFFSET_CAPTURE)) {
                $position = $body[0][1];
            } else {
                $position = preg_match('/^\s*<!doctype[^>]*>/i', $html, $doctype) ? strlen($doctype[0]) : 0;
            }
            return substr($html, 0, $position) . '<head>' . $fragment . '</head>' . substr($html, $position);
        }
        if ($end === null) {
            throw new SeoException('invalid_build_head', 503);
        }
        $edits = array_map(static fn ($range) => [$range[0], $range[1], ''], $removals);
        $edits[] = [$insert, 0, "\n" . $fragment . "\n"];
        usort($edits, static fn ($left, $right) => $right[0] <=> $left[0]);
        foreach ($edits as [$position, $length, $replacement]) {
            $html = substr_replace($html, $replacement, $position, $length);
        }
        return $html;
    }

    private static function attributes(string $token): array
    {
        preg_match_all('/([a-zA-Z_:][a-zA-Z0-9_.:-]*)\s*=\s*(?:\x22([^\x22]*)\x22|\x27([^\x27]*)\x27|([^\s>]+))/', $token, $matches, PREG_SET_ORDER);
        $attributes = [];
        foreach ($matches as $match) {
            $value = $match[2] !== '' ? $match[2] : (($match[3] ?? '') !== '' ? $match[3] : ($match[4] ?? ''));
            $attributes[strtolower($match[1])] = html_entity_decode($value, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        }
        return $attributes;
    }

    public static function validate(array $metadata): array
    {
        foreach (['title', 'description', 'canonical'] as $field) {
            $metadata[$field] = Support::text($metadata[$field] ?? '', $field === 'canonical' ? 4096 : 2000);
        }
        if (!is_array($metadata['og'] ?? null) || !is_array($metadata['robots'] ?? null) || !is_bool($metadata['robots']['index'] ?? null) || !is_bool($metadata['robots']['follow'] ?? null) || !is_array($metadata['hreflang'] ?? null) || count($metadata['hreflang']) > 30) {
            throw new SeoException('invalid_metadata_response', 503);
        }
        foreach (['title', 'description', 'url', 'image', 'siteName', 'type', 'locale'] as $field) {
            if (isset($metadata['og'][$field])) {
                $metadata['og'][$field] = Support::text($metadata['og'][$field], 4096);
            }
        }
        if (!isset($metadata['og']['title'], $metadata['og']['description'], $metadata['og']['image'])) {
            throw new SeoException('invalid_metadata_response', 503);
        }
        $metadata['twitter'] = ['card' => 'summary_large_image'];
        Metadata::head($metadata);
        return $metadata;
    }
}
