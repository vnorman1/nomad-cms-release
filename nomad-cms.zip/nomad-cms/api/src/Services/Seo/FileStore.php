<?php
/**
 * NOMAD CMS — private SEO file storage.
 * Atomic writes and advisory locks; identifiers cannot escape the configured root.
 * Lock stripes bound inode usage independently of the number of targets and media files.
 * @package NomadCMS\Services\Seo
 */
declare(strict_types=1);

namespace NomadCMS\Services\Seo;

/** Private filesystem adapter injectable for temporary test stores. */
class FileStore
{
    private const LOCK_STRIPES = 32;
    private const FIXED_LOCKS = [
        'og-quota',
        'gateway-quota',
        'gateway-package',
        'sitemap-build',
        'social-spool',
        'global-render:0',
        'global-render:1',
        'global-audit:0',
        'global-audit:1',
    ];
    private const LOCK_DOMAINS = [
        'og',
        'google-font',
        'local-media',
        'asset-recovery',
        'audit-target',
        'job',
        'gateway',
        'social-batch',
    ];

    public function __construct(public readonly string $root)
    {
    }

    public function path(string $relative): string
    {
        if (!preg_match('/^[a-zA-Z0-9_\/.-]+$/D', $relative) || str_contains($relative, '..') || $relative[0] === '/') {
            throw new SeoException('invalid_storage_path');
        }
        return rtrim($this->root, '/') . '/' . $relative;
    }

    public function directory(string $relative): string
    {
        $path = $this->path($relative);
        if (!is_dir($path) && !mkdir($path, 0700, true) && !is_dir($path)) {
            throw new SeoException('storage_unavailable', 503);
        }
        return $path;
    }

    public function write(string $relative, string $bytes): string
    {
        $this->directory(dirname($relative) === '.' ? 'cache' : dirname($relative));
        $path = $this->path($relative);
        $temporary = tempnam(dirname($path), '.seo-');
        try {
            if ($temporary === false || file_put_contents($temporary, $bytes, LOCK_EX) !== strlen($bytes) || !chmod($temporary, 0600) || !rename($temporary, $path)) {
                throw new SeoException('storage_unavailable', 503);
            }
        } finally {
            if ($temporary && is_file($temporary)) {
                unlink($temporary);
            }
        }
        return $path;
    }

    public function locked(string $key, callable $operation, bool $wait = true): mixed
    {
        $this->directory('cache/locks');
        $stream = fopen($this->path('cache/locks/' . $this->lockName($key) . '.lock'), 'c');
        if (!$stream || !flock($stream, LOCK_EX | ($wait ? 0 : LOCK_NB))) {
            if ($stream) {
                fclose($stream);
            }
            throw new SeoException('render_busy', 503, ['retry_after' => 1]);
        }
        try {
            return $operation();
        } finally {
            flock($stream, LOCK_UN);
            fclose($stream);
        }
    }

    /** Keep nested lock domains separate and never unlink an inode with potential waiters. */
    private function lockName(string $key): string
    {
        if (in_array($key, self::FIXED_LOCKS, true)) {
            return 'fixed-' . str_replace(':', '-', $key);
        }
        $domain = explode(':', $key, 2)[0];
        if (!in_array($domain, self::LOCK_DOMAINS, true)) {
            $domain = 'other';
        }
        // Independent domains prevent a target render from waiting on its own media/font stripe.
        $stripe = hexdec(substr(hash('sha256', $key), 0, 2)) % self::LOCK_STRIPES;
        return $domain . '-' . str_pad(dechex($stripe), 2, '0', STR_PAD_LEFT);
    }

    /** Copy a potentially large sitemap without loading it into PHP memory. */
    public function copy(string $source, string $relative): void
    {
        $destination = $this->path($relative);
        $this->directory(dirname($relative));
        $temporary = tempnam(dirname($destination), '.seo-');
        $input = fopen($source, 'rb');
        $output = fopen($temporary, 'wb');
        try {
            if (!$input || !$output || stream_copy_to_stream($input, $output) === false) {
                throw new SeoException('storage_copy_failed', 503);
            }
        } finally {
            if ($input) {
                fclose($input);
            }
            if ($output) {
                fclose($output);
            }
        }
        chmod($temporary, 0600);
        if (!rename($temporary, $destination)) {
            unlink($temporary);
            throw new SeoException('storage_copy_failed', 503);
        }
    }
}
