<?php
/**
 * NOMAD CMS — independently installable SPA adapter packaging and deployment checks.
 * Archives only public adapter sources, never CMS secrets, fonts or private storage.
 * Deployment verification fetches only configured public URLs through the secure HTTP client.
 * @package NomadCMS\Services\Seo
 */
declare(strict_types=1);

namespace NomadCMS\Services\Seo;

/** Administrative package builder and site wiring diagnostic. */
final class GatewayPackage
{
    public function __construct(private readonly SeoModule $module)
    {
    }

    public function build(): string
    {
        if (!class_exists(\ZipArchive::class)) {
            throw new SeoException('zip_required', 503);
        }
        return $this->module->files->locked('gateway-package', function (): string {
            $directory = $this->module->files->directory('cache/packages');
            $temporary = tempnam($directory, 'package-');
            $zip = new \ZipArchive();
            if ($zip->open($temporary, \ZipArchive::OVERWRITE) !== true) {
                throw new SeoException('package_build_failed', 503);
            }
            $source = dirname(__DIR__, 3) . '/integrations/spa-gateway';
            foreach (['index.php', 'config.example.php', 'README.md'] as $name) {
                if ($name === 'config.example.php') {
                    $configuration = file_get_contents($source . '/' . $name);
                    $configuration = str_replace("'https://cms.example.com/api/seo/meta'", var_export($this->module->settings->get()['data']['apiBaseUrl'] . '/seo/meta', true), $configuration);
                    $configuration = str_replace("'basePath' => ''", "'basePath' => " . var_export(parse_url($this->module->settings->get()['data']['publicSiteUrl'], PHP_URL_PATH) ?? '', true), $configuration);
                    $zip->addFromString($name, $configuration);
                } else {
                    $zip->addFile($source . '/' . $name, $name);
                }
            }
            foreach (['SeoException', 'Support', 'FileStore', 'Metadata', 'DnsResolver', 'HttpClient', 'HtmlHeadInjector', 'SpaGateway'] as $class) {
                $zip->addFile(__DIR__ . '/' . $class . '.php', 'lib/' . $class . '.php');
            }
            $zip->close();
            $path = $directory . '/nomad-spa-gateway.zip';
            rename($temporary, $path);
            return $path;
        });
    }

    public function check(): array
    {
        $paths = Support::query($this->module->db, 'SELECT p.* FROM seo_target_paths p JOIN seo_targets t ON t.id=p.target_id WHERE p.active=1 AND t.public=1 ORDER BY p.path LIMIT 1')->fetchAll(\PDO::FETCH_ASSOC);
        if (!$paths) {
            throw new SeoException('public_route_required');
        }
        $path = $paths[0];
        $meta = $this->module->metadata->effective($path['target_id'], $path['locale']);
        $normal = $this->module->http->get($meta['canonical'], 2097152, 8, 3, ['User-Agent' => 'Mozilla/5.0 NomadCMS-SEO-Check']);
        $social = $this->module->http->get($meta['canonical'], 2097152, 8, 3, ['User-Agent' => 'facebookexternalhit/1.1']);
        $origin = $this->module->settings->get()['data']['publicSiteUrl'];
        $rootRobots = $this->module->http->get($origin . '/robots.txt', 65536);
        $rootSitemap = $this->module->http->head($origin . '/sitemap.xml');
        $normalAudit = $this->module->audit->html($normal['body'], $meta, $normal);
        $socialAudit = $this->module->audit->html($social['body'], $meta, $social);
        return ['enabled' => $this->module->settings->get()['data']['spaGatewayEnabled'], 'normal' => $normalAudit, 'social' => $socialAudit, 'same_seo_head' => $normalAudit['server_metadata'] && $socialAudit['server_metadata'], 'same_initial_html' => hash('sha256', $normal['body']) === hash('sha256', $social['body']), 'robots' => ['status' => $rootRobots['status'], 'matches_config' => trim($rootRobots['body']) === trim($this->module->site->robots())], 'sitemap' => ['status' => $rootSitemap['status'], 'probe' => 'HEAD', 'content_type' => $rootSitemap['headers']['content-type'] ?? null]];
    }
}
