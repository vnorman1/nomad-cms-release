<?php
/**
 * NOMAD CMS - Authenticated Content Search Service
 * Streams legacy slots and indexed collection candidates into the command palette's
 * existing field/item/block result contract, with slot and ownership restrictions.
 * Only matching collection items are hydrated; result memory stays page-sized.
 */
declare(strict_types=1);

namespace NomadCMS\Services;

use NomadCMS\Database\CollectionDatabase;
use NomadCMS\Database\ContentDatabase;
use NomadCMS\Middleware\AuthMiddleware;
use PDO;

final class ContentSearchService
{
    /**
     * Search authenticated content across both collection storage generations.
     *
     * @return array Query results, capped total and result-based pagination metadata.
     */
    public static function search(string $query, int $limit = 20, int $offset = 0, ?string $slotKey = null): array
    {
        $limit = max(1, min(100, $limit));
        $offset = max(0, $offset);
        $user = AuthMiddleware::getCurrentUser();
        $ownOnly = !AuthMiddleware::hasGrantedScope('content:read:*') && AuthMiddleware::hasGrantedScope('content:read:own');
        $owner = $ownOnly ? ($user->uuid ?? '') : null;
        $results = [];
        $total = 0;
        if ($user === null || (!AuthMiddleware::hasGrantedScope('content:read:*') && !$ownOnly) || mb_strlen($query) < 2 || $owner === '') {
            return self::response($query, $results, $total, $limit, $offset);
        }
        $db = ContentDatabase::getInstance();

        // Register Unicode lowercase function for case-insensitive accented search (á, é, ő, ű, etc.)
        $db->sqliteCreateFunction('mb_lower', 'mb_strtolower', 1);
        $db->sqliteCreateFunction('nomad_search_slot_access', static fn(string $key): int =>
            !empty($user->is_admin) || RBACService::canAccessSlot($user, $key) ? 1 : 0, 1);
        $lowerQuery = mb_strtolower($query);
        $collections = (bool) $db->query("SELECT 1 FROM sqlite_master WHERE type='table' AND name='collection_items'")->fetchColumn();

        // Build SQL query
        $whereClauses = ['INSTR(mb_lower(s.data), ?) > 0', 'nomad_search_slot_access(s.key)=1'];
        $queryParams = [$lowerQuery];
        if ($collections) $whereClauses[] = 'NOT EXISTS(SELECT 1 FROM collection_slots c WHERE c.slot_key=s.key)';

        // ABAC filter: restrict to caller's own slots if only content:read:own is granted
        if ($owner !== null) {
            $whereClauses[] = 'EXISTS(SELECT 1 FROM slot_ownership o WHERE o.slot_key=s.key AND o.owner_uuid=?)';
            $queryParams[] = $owner;
        }
        // Optional slot key filter
        if ($slotKey !== null) {
            $whereClauses[] = 's.key=?';
            $queryParams[] = $slotKey;
        }
        $sql = 'SELECT s.key AS slot_key,NULL AS item_uid,s.updated_at,NULL AS row_id FROM slots s WHERE ' . implode(' AND ', $whereClauses);
        preg_match_all('/[\p{L}\p{N}]+/u', $query, $words);
        if ($collections && $words[0]) {
            $terms = implode(' AND ', array_map(static fn(string $word): string => '"' . $word . '"*', array_slice($words[0], 0, 20)));
            $where = ['collection_fts MATCH ?', 'nomad_search_slot_access(i.slot_key)=1'];
            $params = [$terms];
            if ($owner !== null) { $where[] = 'i.owner_uuid=?'; $params[] = $owner; }
            if ($slotKey !== null) { $where[] = 'i.slot_key=?'; $params[] = $slotKey; }
            $sql .= ' UNION ALL SELECT i.slot_key,i.item_uid,i.updated_at,i.row_id FROM collection_fts
                JOIN collection_items i ON i.row_id=collection_fts.rowid WHERE ' . implode(' AND ', $where);
            array_push($queryParams, ...$params);
        }

        // Query matching slots with pagination
        // Pagination is applied to emitted field matches rather than candidate slots/items.
        $stmt = $db->prepare($sql . ' ORDER BY updated_at DESC,row_id DESC,slot_key');
        $stmt->execute($queryParams);
        // Fast capped count subquery (stops at 101 to prevent full table scanning on huge DBs)
        // The combined result stream now supplies that capped count, also covering deeper offsets.
        $cap = max(101, $offset + $limit + 1);

        // Stream rows cursor-style without memory spikes
        while ($candidate = $stmt->fetch(PDO::FETCH_ASSOC)) {
            if ($candidate['item_uid'] !== null) {
                $item = CollectionDatabase::getItem($candidate['slot_key'], $candidate['item_uid'], true);
                if (!$item) continue;
                $matches = self::searchInDataStructure($item, $query, $lowerQuery, $candidate['slot_key'], '',
                    $candidate['item_uid'], self::resolveItemTitle($item));
            } else {
                $slot = $db->prepare('SELECT data FROM slots WHERE key=?');
                $slot->execute([$candidate['slot_key']]);
                $data = json_decode((string) $slot->fetchColumn(), true);
                $matches = self::searchInDataStructure($data, $query, $lowerQuery, $candidate['slot_key'], owner: $owner);
            }
            foreach ($matches as $match) {
                if ($total >= $offset && count($results) < $limit) {
                    $results[] = ['slot' => $candidate['slot_key'], 'updated_at' => $candidate['updated_at']] + $match;
                }
                if (++$total >= $cap) break 2;
            }
        }
        $stmt->closeCursor();
        return self::response($query, $results, $total, $limit, $offset);
    }

    private static function response(string $query, array $results, int $total, int $limit, int $offset): array
    {
        return ['success' => true, 'query' => $query, 'results' => $results, 'total' => $total,
            'limit' => $limit, 'offset' => $offset, 'hasMore' => $total > $offset + count($results)];
    }

    private static function fold(string $text): string
    {
        $text = mb_strtolower($text);
        return strtr($text, ['á'=>'a','é'=>'e','í'=>'i','ó'=>'o','ö'=>'o','ő'=>'o','ú'=>'u','ü'=>'u','ű'=>'u',
            'à'=>'a','â'=>'a','ä'=>'a','ã'=>'a','å'=>'a','è'=>'e','ê'=>'e','ë'=>'e','ì'=>'i','î'=>'i','ï'=>'i',
            'ò'=>'o','ô'=>'o','õ'=>'o','ù'=>'u','û'=>'u','ñ'=>'n','ç'=>'c']);
    }

    /**
     * Recursively search in arbitrary data structures (objects, collections, localized sections, blocks)
     */
    private static function searchInDataStructure(
        mixed $data,
        string $query,
        string $lowerQuery,
        string $slotKey,
        string $path = '',
        ?string $itemId = null,
        ?string $itemTitle = null,
        ?string $blockId = null,
        ?string $blockType = null,
        ?string $lang = null,
        ?string $owner = null
    ): \Generator {
        if (is_string($data)) {
            $match = self::evaluateTextMatch($data, $query, $lowerQuery);
            if ($match !== null) {
                $deepLink = "/nomad/edit/" . rawurlencode($slotKey);
                if ($itemId !== null && $blockId !== null && $itemId !== $blockId) {
                    $deepLink .= "/" . rawurlencode($itemId) . "/" . rawurlencode($blockId);
                } elseif ($itemId !== null) {
                    $deepLink .= "/" . rawurlencode($itemId);
                } elseif ($blockId !== null) {
                    $deepLink .= "/" . rawurlencode($blockId);
                }

                yield [
                    'type' => $itemId !== null ? 'collection_item' : 'field',
                    'path' => $path,
                    'field' => basename(str_replace('.', '/', $path)),
                    'value' => mb_substr($data, 0, 100),
                    'match' => $match['match'],
                    'context' => $match['context'],
                    'score' => $match['score'],
                    'itemId' => $itemId,
                    'itemTitle' => $itemTitle,
                    'blockId' => $blockId,
                    'blockType' => $blockType,
                    'lang' => $lang,
                    'deepLink' => $deepLink
                ];
            }
        } elseif (is_array($data)) {
            $isIndexedList = array_is_list($data);
            if ($owner !== null && $path === '' && !$isIndexedList && ContentDatabase::getOwner($slotKey) !== $owner) {
                return;
            }

            foreach ($data as $key => $value) {
                $currentPath = ($path !== '') ? "{$path}.{$key}" : (string)$key;
                $nextItemId = $itemId;
                $nextItemTitle = $itemTitle;
                $nextBlockId = $blockId;
                $nextBlockType = $blockType;
                $nextLang = $lang;

                // Detect collection item at root or top-level list
                if ($path === '' && $itemId === null && is_array($value)) {
                    if ($isIndexedList) {
                        $identity = $value['_dndId'] ?? $value['id'] ?? $value['slug'] ?? $key;
                        $nextItemId = is_scalar($identity) ? (string) $identity : (string) $key;
                        if ($owner !== null && ContentDatabase::getOwner($slotKey, $nextItemId) !== $owner) continue;
                        $nextItemTitle = self::resolveItemTitle($value);
                    } elseif (isset($value['slug']) || (isset($value['id']) && is_scalar($value['id']) && !str_starts_with((string)$value['id'], 'block_'))) {
                        $identity = $value['_dndId'] ?? $value['id'] ?? $value['slug'];
                        $nextItemId = is_scalar($identity) ? (string) $identity : null;
                        $nextItemTitle = self::resolveItemTitle($value);
                    }
                }

                // Detect block object
                if (is_array($value) && isset($value['id']) && is_scalar($value['id']) && (isset($value['type']) || str_starts_with((string)$value['id'], 'block_'))) {
                    $nextBlockId = (string)$value['id'];
                    $nextBlockType = is_string($value['type'] ?? null) ? $value['type'] : 'block';
                }

                // Detect language section container
                if ($lang === null && is_string($key) && $key !== 'id' && preg_match('/^[a-z]{2}(-[A-Z]{2})?$/', $key)) {
                    $nextLang = $key;
                }

                yield from self::searchInDataStructure(
                    $value,
                    $query,
                    $lowerQuery,
                    $slotKey,
                    $currentPath,
                    $nextItemId,
                    $nextItemTitle,
                    $nextBlockId,
                    $nextBlockType,
                    $nextLang,
                    $owner
                );
            }
        }
    }

    /**
     * Evaluate whether text matches query and calculate score + context snippet
     */
    private static function evaluateTextMatch(string $haystack, string $query, string $lowerQuery): ?array
    {
        // Strip HTML tags for clean text search
        $cleanText = html_entity_decode(strip_tags($haystack), ENT_QUOTES | ENT_HTML5, 'UTF-8');
        $lowerText = self::fold($cleanText);
        $lowerQuery = self::fold($lowerQuery);
        $pos = mb_strpos($lowerText, $lowerQuery);

        if ($pos === false) {
            return null;
        }

        // Relevance scoring
        $score = 100;
        if ($lowerText === $lowerQuery) {
            $score = 200; // Exact match
        } elseif ($pos === 0) {
            $score = 150; // Match at start
        } elseif ($pos > 0 && preg_match('/[\s\-_.,;:]/u', mb_substr($lowerText, $pos - 1, 1))) {
            $score = 130; // Word boundary match
        }

        // Context snippet with ellipsis
        $queryLen = mb_strlen($query);
        $start = max(0, $pos - 35);
        $length = min(120, mb_strlen($cleanText) - $start);
        $snippet = mb_substr($cleanText, $start, $length);

        if ($start > 0) {
            $snippet = '...' . $snippet;
        }
        if (($start + $length) < mb_strlen($cleanText)) {
            $snippet .= '...';
        }

        return [
            'match' => mb_substr($cleanText, $pos, $queryLen),
            'context' => $snippet,
            'score' => $score
        ];
    }

    /**
     * Resolve human-readable title for collection items (handles localized arrays)
     */
    private static function resolveItemTitle(array $item, ?string $preferredLang = null): ?string
    {
        $fields = ['title', 'name', 'heading', 'label', 'subject'];
        foreach ($fields as $f) {
            if (!isset($item[$f])) {
                continue;
            }

            if (is_string($item[$f]) && trim($item[$f]) !== '') {
                return trim($item[$f]);
            }

            if (is_array($item[$f])) {
                if ($preferredLang !== null && !empty($item[$f][$preferredLang]) && is_string($item[$f][$preferredLang])) {
                    return trim($item[$f][$preferredLang]);
                }
                foreach (['hu', 'en', 'de'] as $fallback) {
                    if (!empty($item[$f][$fallback]) && is_string($item[$f][$fallback])) {
                        return trim($item[$f][$fallback]);
                    }
                }
                $first = reset($item[$f]);
                if (is_string($first) && trim($first) !== '') {
                    return trim($first);
                }
            }
        }

        return null;
    }
}
