<?php
/**
 * NOMAD CMS - Captcha Verifier
 *
 * Server-side siteverify call for Cloudflare Turnstile and Google reCAPTCHA
 * v2/v3. Both providers share the same POST-and-get-JSON-back contract
 * (secret, response, remoteip -> {success, ...}), so one implementation
 * serves all three provider ids.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * INJECTABLE TRANSPORT
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * The actual HTTP call is delegated to a callable so unit tests never touch
 * the network: `verify()` accepts an optional `$transport` argument, and only
 * falls back to a real cURL request when the caller does not supply one.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * FAIL-OPEN ON NETWORK FAILURE
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * A timeout or connection failure returns state='unreachable', never
 * 'verified'. It is the CALLER's job (see endpoints/public/forms.php) to turn
 * 'unreachable' into a spam-flagged-but-saved submission - this class never
 * decides that policy, it only reports what happened talking to the provider.
 *
 * @package NomadCMS\Services\Forms
 */

declare(strict_types=1);

namespace NomadCMS\Services\Forms;

final class CaptchaVerifier
{
    public const STATE_VERIFIED = 'verified';
    public const STATE_FAILED = 'failed';
    public const STATE_UNREACHABLE = 'unreachable';

    private const CONNECT_TIMEOUT_SECONDS = 3;
    private const TOTAL_TIMEOUT_SECONDS = 5;

    /**
     * Verify a token against the given provider's siteverify endpoint.
     *
     * @param callable|null $transport Optional override with signature
     *        (string $url, array $postFields): array{ok:bool, body:?string}
     *        Used exclusively by tests to avoid real network calls.
     * @return array{state:string, score:?float, error_codes:array<int,string>}
     */
    public static function verify(
        string $provider,
        string $token,
        string $secretKey,
        string $remoteIp,
        ?callable $transport = null
    ): array {
        $verifyUrl = CaptchaProviderRegistry::verifyUrl($provider);
        if ($verifyUrl === null || $secretKey === '' || $token === '') {
            return ['state' => self::STATE_FAILED, 'score' => null, 'error_codes' => ['invalid-input']];
        }

        $postFields = [
            'secret' => $secretKey,
            'response' => $token,
            'remoteip' => $remoteIp,
        ];

        $transport ??= [self::class, 'curlTransport'];

        try {
            $result = $transport($verifyUrl, $postFields);
        } catch (\Throwable $e) {
            // Never let the secret leak into a log line via an exception message.
            error_log('[Forms][CaptchaVerifier] Transport hiba (' . $provider . '): ' . self::sanitizeExceptionMessage($e));

            return ['state' => self::STATE_UNREACHABLE, 'score' => null, 'error_codes' => ['transport-error']];
        }

        if (!is_array($result) || ($result['ok'] ?? false) !== true || !is_string($result['body'] ?? null)) {
            return ['state' => self::STATE_UNREACHABLE, 'score' => null, 'error_codes' => ['unreachable']];
        }

        $decoded = json_decode($result['body'], true);
        if (!is_array($decoded)) {
            return ['state' => self::STATE_UNREACHABLE, 'score' => null, 'error_codes' => ['invalid-response']];
        }

        $success = ($decoded['success'] ?? false) === true;
        $errorCodes = self::normalizeErrorCodes($decoded['error-codes'] ?? $decoded['error_codes'] ?? []);

        if (!$success) {
            return ['state' => self::STATE_FAILED, 'score' => null, 'error_codes' => $errorCodes];
        }

        // reCAPTCHA v3 additionally reports a 0.0-1.0 score; anything below the
        // registry's configured threshold is treated as a failed verification
        // even though the provider itself reported success:true.
        $score = isset($decoded['score']) && is_numeric($decoded['score']) ? (float) $decoded['score'] : null;
        $minScore = CaptchaProviderRegistry::minScore($provider);

        if ($minScore !== null && $score !== null && $score < $minScore) {
            return ['state' => self::STATE_FAILED, 'score' => $score, 'error_codes' => ['score-too-low']];
        }

        return ['state' => self::STATE_VERIFIED, 'score' => $score, 'error_codes' => []];
    }

    /**
     * Default transport: a real cURL POST with tight timeouts.
     *
     * @param array<string, string> $postFields
     * @return array{ok:bool, body:?string}
     */
    private static function curlTransport(string $url, array $postFields): array
    {
        $ch = curl_init($url);
        if ($ch === false) {
            return ['ok' => false, 'body' => null];
        }

        curl_setopt_array($ch, [
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => http_build_query($postFields),
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_CONNECTTIMEOUT => self::CONNECT_TIMEOUT_SECONDS,
            CURLOPT_TIMEOUT => self::TOTAL_TIMEOUT_SECONDS,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
            CURLOPT_FOLLOWLOCATION => false,
            CURLOPT_HTTPHEADER => ['Content-Type: application/x-www-form-urlencoded'],
        ]);

        $body = curl_exec($ch);
        $errorNumber = curl_errno($ch);
        $httpCode = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($body === false || $errorNumber !== 0 || $httpCode < 200 || $httpCode >= 300) {
            return ['ok' => false, 'body' => null];
        }

        return ['ok' => true, 'body' => (string) $body];
    }

    /**
     * @param mixed $raw
     * @return array<int, string>
     */
    private static function normalizeErrorCodes(mixed $raw): array
    {
        if (!is_array($raw)) {
            return [];
        }

        return array_values(array_map('strval', array_filter($raw, 'is_scalar')));
    }

    /**
     * Strip anything resembling a secret out of an exception message before it
     * ever reaches a log line. Defensive: neither cURL nor json_decode() puts
     * the secret into their own exception text today, but a future PHP/cURL
     * version changing that must not become a leak.
     */
    private static function sanitizeExceptionMessage(\Throwable $e): string
    {
        return preg_replace('/secret=[^&\s]+/i', 'secret=[redacted]', $e->getMessage()) ?? '[unloggable]';
    }
}
