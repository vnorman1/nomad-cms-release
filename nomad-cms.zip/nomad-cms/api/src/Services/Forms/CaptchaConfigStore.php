<?php
/**
 * NOMAD CMS - Captcha Config Store
 *
 * Reads and writes the form_captcha_providers / form_captcha_forms tables in
 * system.sqlite: the ONLY place captcha secret keys live. Never .env, never
 * the form definition's `settings` JSON, never returned raw to a client.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * STORAGE MODEL
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * form_captcha_providers (one row per real provider, keyed by provider name):
 *   provider TEXT PRIMARY KEY   -- turnstile|recaptcha_v2|recaptcha_v3
 *   site_key TEXT
 *   secret_key_enc TEXT         -- Defuse-encrypted
 *
 * form_captcha_forms (one row per form THAT HAS AN OVERRIDE; provider=none
 * is represented by the absence of a row, same as the old file's map):
 *   slug TEXT PRIMARY KEY
 *   provider TEXT               -- turnstile|recaptcha_v2|recaptcha_v3
 *   use_custom_keys INTEGER
 *   site_key TEXT               -- only meaningful when use_custom_keys
 *   secret_key_enc TEXT         -- only meaningful when use_custom_keys
 *
 * Why not inside the form definition (massive_form_definitions)? Because
 * GET /endpoints/admin/forms.php returns the WHOLE definition, secrets and
 * all, to anyone holding forms:read:*. Keeping the secret in dedicated
 * tables that CaptchaConfigStore is the only reader/writer of - and that are
 * never joined into a "return the whole form" query - is what makes "never
 * returned raw" actually true rather than aspirational.
 *
 * Previously this lived in a flat file (api/external/captcha.json). Moved
 * into system.sqlite for write concurrency: SQLite's WAL mode + busy_timeout
 * (see AuthDatabase::initializeSchema()) handles concurrent reads/writes far
 * more safely than a lock-file-less read-modify-write JSON file did.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * FAIL-CLOSED ENCRYPTION
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * A secret key is only ever written through EncryptionService::encrypt(). If
 * ENCRYPTION_KEY is not configured, saving a secret is refused outright
 * (CaptchaException::encryptionUnavailable) - never falls back to plaintext.
 * This mirrors FormService::normalizeSettings()'s fail-closed rule for
 * form-level GDPR encryption.
 *
 * @package NomadCMS\Services\Forms
 */

declare(strict_types=1);

namespace NomadCMS\Services\Forms;

use NomadCMS\Database\AuthDatabase;
use NomadCMS\Security\EncryptionService;
use PDO;

final class CaptchaConfigStore
{
    private const VALID_PROVIDERS = ['none', 'turnstile', 'recaptcha_v2', 'recaptcha_v3'];

    /**
     * In-process cache so a single request only queries the tables once.
     *
     * @var array{providers: array<string, array<string, mixed>>, forms: array<string, array<string, mixed>>}|null
     */
    private static ?array $cache = null;

    // =========================================================================
    // READ
    // =========================================================================

    private static function db(): PDO
    {
        return AuthDatabase::getInstance();
    }

    /**
     * @return array{providers: array<string, array<string, mixed>>, forms: array<string, array<string, mixed>>}
     */
    private static function load(): array
    {
        if (self::$cache !== null) {
            return self::$cache;
        }

        $providers = [];
        foreach (self::db()->query('SELECT provider, site_key, secret_key_enc FROM form_captcha_providers') as $row) {
            $providers[$row['provider']] = [
                'site_key' => $row['site_key'],
                'secret_key_enc' => $row['secret_key_enc'],
            ];
        }

        $forms = [];
        foreach (self::db()->query('SELECT slug, provider, use_custom_keys, site_key, secret_key_enc FROM form_captcha_forms') as $row) {
            $forms[$row['slug']] = [
                'provider' => $row['provider'],
                'use_custom_keys' => (bool) $row['use_custom_keys'],
                'site_key' => $row['site_key'],
                'secret_key_enc' => $row['secret_key_enc'],
            ];
        }

        self::$cache = ['providers' => $providers, 'forms' => $forms];

        return self::$cache;
    }

    /**
     * Global provider entry (site_key + encrypted secret), or null when never
     * configured.
     *
     * @return array{site_key: ?string, secret_key_enc: ?string}|null
     */
    public static function globalProvider(string $provider): ?array
    {
        $entry = self::load()['providers'][$provider] ?? null;

        return is_array($entry) ? self::normalizeEntry($entry) : null;
    }

    /**
     * Per-form override entry, or null when the form has no override (i.e. it
     * uses provider=none / has never been configured).
     *
     * @return array{provider: string, use_custom_keys: bool, site_key: ?string, secret_key_enc: ?string}|null
     */
    public static function formConfig(string $slug): ?array
    {
        $entry = self::load()['forms'][$slug] ?? null;
        if (!is_array($entry)) {
            return null;
        }

        $provider = is_string($entry['provider'] ?? null) ? $entry['provider'] : 'none';
        if (!in_array($provider, self::VALID_PROVIDERS, true)) {
            $provider = 'none';
        }

        return array_merge(
            self::normalizeEntry($entry),
            [
                'provider' => $provider,
                'use_custom_keys' => (bool) ($entry['use_custom_keys'] ?? false),
            ]
        );
    }

    /**
     * @param array<string, mixed> $entry
     * @return array{site_key: ?string, secret_key_enc: ?string}
     */
    private static function normalizeEntry(array $entry): array
    {
        return [
            'site_key' => is_string($entry['site_key'] ?? null) && $entry['site_key'] !== '' ? $entry['site_key'] : null,
            'secret_key_enc' => is_string($entry['secret_key_enc'] ?? null) && $entry['secret_key_enc'] !== ''
                ? $entry['secret_key_enc']
                : null,
        ];
    }

    // =========================================================================
    // RESOLUTION (server-side use only - carries the DECRYPTED secret)
    // =========================================================================

    /**
     * Resolve the EFFECTIVE captcha configuration for a form: which provider
     * (if any) is active, and the site/secret key pair to use - taking the
     * per-form override and the use_custom_keys flag into account.
     *
     * The returned secret_key is PLAINTEXT (decrypted) and must never be
     * serialized into an HTTP response. Callers that only need to render a
     * widget (no secret required) should use the public projection instead
     * (see FormService::publicSchema()).
     *
     * @param array<string, mixed> $form Hydrated form definition (['data'=>['slug'=>...]])
     * @return array{provider: string, site_key: ?string, secret_key: ?string}
     */
    public static function resolveForForm(array $form): array
    {
        $slug = (string) ($form['data']['slug'] ?? '');
        $override = $slug !== '' ? self::formConfig($slug) : null;

        $provider = $override['provider'] ?? 'none';
        if ($provider === 'none' || !CaptchaProviderRegistry::isValidProvider($provider)) {
            return ['provider' => 'none', 'site_key' => null, 'secret_key' => null];
        }

        $useCustom = (bool) ($override['use_custom_keys'] ?? false);

        if ($useCustom) {
            $siteKey = $override['site_key'] ?? null;
            $secretEnc = $override['secret_key_enc'] ?? null;
        } else {
            $global = self::globalProvider($provider);
            $siteKey = $global['site_key'] ?? null;
            $secretEnc = $global['secret_key_enc'] ?? null;
        }

        $secretKey = null;
        if (is_string($secretEnc) && $secretEnc !== '') {
            try {
                $secretKey = EncryptionService::decrypt($secretEnc);
            } catch (\Throwable $e) {
                error_log('[Forms][CaptchaConfigStore] Secret dekódolása sikertelen (' . $provider . '): ' . $e->getMessage());
                $secretKey = null;
            }
        }

        // No usable key pair -> behave as if captcha were off rather than
        // silently exposing a widget that can never be verified server-side.
        if ($siteKey === null || $secretKey === null) {
            return ['provider' => 'none', 'site_key' => null, 'secret_key' => null];
        }

        return ['provider' => $provider, 'site_key' => $siteKey, 'secret_key' => $secretKey];
    }

    // =========================================================================
    // MASKED PROJECTIONS (safe for API responses)
    // =========================================================================

    /**
     * @return array{site_key: ?string, secret_key_set: bool, secret_key_last4: ?string}
     */
    public static function maskedProvider(string $provider): array
    {
        return self::maskEntry(self::globalProvider($provider));
    }

    /**
     * @return array{provider: string, use_custom_keys: bool, site_key: ?string, secret_key_set: bool, secret_key_last4: ?string}
     */
    public static function maskedFormConfig(string $slug): array
    {
        $config = self::formConfig($slug);

        return array_merge(
            self::maskEntry($config),
            [
                'provider' => $config['provider'] ?? 'none',
                'use_custom_keys' => (bool) ($config['use_custom_keys'] ?? false),
            ]
        );
    }

    /**
     * @param array{site_key: ?string, secret_key_enc: ?string}|null $entry
     * @return array{site_key: ?string, secret_key_set: bool, secret_key_last4: ?string}
     */
    private static function maskEntry(?array $entry): array
    {
        if ($entry === null) {
            return ['site_key' => null, 'secret_key_set' => false, 'secret_key_last4' => null];
        }

        $secretEnc = $entry['secret_key_enc'] ?? null;
        $last4 = null;

        if (is_string($secretEnc) && $secretEnc !== '') {
            try {
                $plain = EncryptionService::decrypt($secretEnc);
                $last4 = strlen($plain) >= 4 ? substr($plain, -4) : $plain;
            } catch (\Throwable) {
                // Corrupt/undecryptable - still report "set" so the admin knows
                // something is stored, just cannot show the tail.
                $last4 = null;
            }
        }

        return [
            'site_key' => $entry['site_key'] ?? null,
            'secret_key_set' => is_string($secretEnc) && $secretEnc !== '',
            'secret_key_last4' => $last4,
        ];
    }

    // =========================================================================
    // WRITE
    // =========================================================================

    /**
     * Set the global key pair for one provider.
     *
     * @param string|null $secretKey Plaintext secret. Null = leave the existing
     *                                secret unchanged. Empty string is treated
     *                                the same as null (never blanks silently -
     *                                use clearSecret for that).
     */
    public static function setGlobalProvider(
        string $provider,
        ?string $siteKey,
        ?string $secretKey,
        bool $clearSecret = false
    ): void {
        self::assertValidRealProvider($provider);

        $existing = self::globalProvider($provider);
        $existingEnc = $existing['secret_key_enc'] ?? null;

        $newSiteKey = $siteKey !== null ? $siteKey : ($existing['site_key'] ?? null);
        $newSecretEnc = self::resolveSecretEnc($existingEnc, $secretKey, $clearSecret);

        $db = self::db();
        $stmt = $db->prepare('
            INSERT INTO form_captcha_providers (provider, site_key, secret_key_enc, updated_at)
            VALUES (:provider, :site_key, :secret_key_enc, CURRENT_TIMESTAMP)
            ON CONFLICT(provider) DO UPDATE SET
                site_key = :site_key,
                secret_key_enc = :secret_key_enc,
                updated_at = CURRENT_TIMESTAMP
        ');
        $stmt->execute([
            'provider' => $provider,
            'site_key' => $newSiteKey,
            'secret_key_enc' => $newSecretEnc,
        ]);

        self::$cache = null;
    }

    /**
     * Set (or clear) the per-form override.
     *
     * @param string|null $secretKey Plaintext custom secret. Null = leave
     *                                unchanged (only relevant when
     *                                use_custom_keys stays true).
     */
    public static function setFormConfig(
        string $slug,
        string $provider,
        bool $useCustomKeys,
        ?string $siteKey = null,
        ?string $secretKey = null,
        bool $clearSecret = false
    ): void {
        if (!in_array($provider, self::VALID_PROVIDERS, true)) {
            throw new CaptchaException('Érvénytelen captcha szolgáltató: ' . $provider, 400, 'INVALID_PROVIDER');
        }

        if ($provider === 'none') {
            $stmt = self::db()->prepare('DELETE FROM form_captcha_forms WHERE slug = :slug');
            $stmt->execute(['slug' => $slug]);
            self::$cache = null;

            return;
        }

        $existing = self::formConfig($slug);

        $newSiteKey = null;
        $newSecretEnc = null;

        if ($useCustomKeys) {
            $existingSiteKey = $existing['site_key'] ?? null;
            $existingEnc = $existing['secret_key_enc'] ?? null;

            $newSiteKey = $siteKey !== null ? $siteKey : $existingSiteKey;
            $newSecretEnc = self::resolveSecretEnc($existingEnc, $secretKey, $clearSecret);
        }
        // Custom keys switched off: the stale custom key pair must not linger
        // in the table pretending to be in use - leave site_key/secret_key_enc
        // as NULL.

        $db = self::db();
        $stmt = $db->prepare('
            INSERT INTO form_captcha_forms (slug, provider, use_custom_keys, site_key, secret_key_enc, updated_at)
            VALUES (:slug, :provider, :use_custom_keys, :site_key, :secret_key_enc, CURRENT_TIMESTAMP)
            ON CONFLICT(slug) DO UPDATE SET
                provider = :provider,
                use_custom_keys = :use_custom_keys,
                site_key = :site_key,
                secret_key_enc = :secret_key_enc,
                updated_at = CURRENT_TIMESTAMP
        ');
        $stmt->execute([
            'slug' => $slug,
            'provider' => $provider,
            'use_custom_keys' => $useCustomKeys ? 1 : 0,
            'site_key' => $newSiteKey,
            'secret_key_enc' => $newSecretEnc,
        ]);

        self::$cache = null;
    }

    /**
     * Encrypt a new secret, keep the existing one, or clear it - the shared
     * decision every setter above needs.
     */
    private static function resolveSecretEnc(?string $existingEnc, ?string $newPlain, bool $clear): ?string
    {
        if ($clear) {
            return null;
        }

        if ($newPlain === null || $newPlain === '') {
            return $existingEnc;
        }

        if (!EncryptionService::isConfigured()) {
            throw CaptchaException::encryptionUnavailable();
        }

        return EncryptionService::encrypt($newPlain);
    }

    private static function assertValidRealProvider(string $provider): void
    {
        if (!in_array($provider, CaptchaProviderRegistry::PROVIDERS, true)) {
            throw new CaptchaException('Érvénytelen captcha szolgáltató: ' . $provider, 400, 'INVALID_PROVIDER');
        }
    }

    // =========================================================================
    // LIFECYCLE HOOKS (rename / delete cascade)
    // =========================================================================

    /**
     * Move a form's captcha override from one slug to another. Called from
     * FormService::update()'s slug-rename cascade - without this, a renamed
     * form would silently lose (or worse, another form would silently gain) a
     * stale captcha configuration.
     */
    public static function renameForm(string $oldSlug, string $newSlug): void
    {
        $db = self::db();
        $db->beginTransaction();
        try {
            $select = $db->prepare('SELECT provider, use_custom_keys, site_key, secret_key_enc FROM form_captcha_forms WHERE slug = :slug');
            $select->execute(['slug' => $oldSlug]);
            $row = $select->fetch();

            if ($row === false) {
                $db->commit();

                return;
            }

            $delete = $db->prepare('DELETE FROM form_captcha_forms WHERE slug = :slug');
            $delete->execute(['slug' => $oldSlug]);

            $upsert = $db->prepare('
                INSERT INTO form_captcha_forms (slug, provider, use_custom_keys, site_key, secret_key_enc, updated_at)
                VALUES (:slug, :provider, :use_custom_keys, :site_key, :secret_key_enc, CURRENT_TIMESTAMP)
                ON CONFLICT(slug) DO UPDATE SET
                    provider = :provider,
                    use_custom_keys = :use_custom_keys,
                    site_key = :site_key,
                    secret_key_enc = :secret_key_enc,
                    updated_at = CURRENT_TIMESTAMP
            ');
            $upsert->execute([
                'slug' => $newSlug,
                'provider' => $row['provider'],
                'use_custom_keys' => $row['use_custom_keys'],
                'site_key' => $row['site_key'],
                'secret_key_enc' => $row['secret_key_enc'],
            ]);

            $db->commit();
        } catch (\Throwable $e) {
            $db->rollBack();
            throw $e;
        }

        self::$cache = null;
    }

    /**
     * Remove a form's captcha override entirely. Called from
     * FormService::delete()'s cascade.
     */
    public static function deleteForm(string $slug): void
    {
        $stmt = self::db()->prepare('DELETE FROM form_captcha_forms WHERE slug = :slug');
        $stmt->execute(['slug' => $slug]);

        self::$cache = null;
    }

    // =========================================================================
    // TEST SUPPORT
    // =========================================================================

    /**
     * Drop the in-process cache. Test-only: a normal request loads the tables
     * at most once.
     */
    public static function clearCache(): void
    {
        self::$cache = null;
    }
}
