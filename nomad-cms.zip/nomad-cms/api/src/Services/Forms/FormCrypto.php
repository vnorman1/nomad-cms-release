<?php
/**
 * NOMAD CMS - Form Crypto
 *
 * Envelope encryption + blind indexing for form submissions.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * WHAT IS ENCRYPTED, WHAT IS NOT
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * Encrypted (authenticated AES via Defuse, `def…` ciphertext):
 *   - the entire `values` map of a submission (every value the visitor typed)
 *
 * Left plaintext on purpose (non-personal, needed for querying):
 *   - type, form_slug, status, created_at, enc_version
 *   - field_names (field NAMES are schema, not personal data - needed to build
 *     the table header and CSV columns without decrypting anything)
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * BLIND INDEX (SEARCH)
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * Encrypted submissions cannot be searched with the plaintext FTS index - that
 * index would BE the leak. Instead, fields explicitly marked `searchable` in
 * the form editor get a deterministic HMAC token (BlindIndexService, separate
 * BLIND_INDEX_KEY, field name as context so tokens cannot match across
 * fields). Those tokens - and nothing else - go into the FTS row.
 *
 * Consequences the UI must communicate honestly:
 * - EXACT match only (case-insensitive). Searching "gab" never finds
 *   "gabor@example.com"; the full value is required.
 * - Low-entropy fields (yes/no, a 3-item select) are guessable: an attacker who
 *   can read the FTS table can hash the few candidate values and learn which
 *   row holds which answer. Only mark high-entropy fields searchable.
 *
 * @package NomadCMS\Services\Forms
 */

declare(strict_types=1);

namespace NomadCMS\Services\Forms;

use NomadCMS\Database\MassiveEncryption;
use NomadCMS\Security\BlindIndexService;
use NomadCMS\Security\EncryptionService;
use NomadCMS\Security\IpHashService;
use NomadCMS\Services\LoggerService;
use Throwable;

final class FormCrypto
{
    /** Guard so a missing IP_HASH_SECRET is logged once per request, not per submission */
    private static bool $ipSecretWarningLogged = false;

    // =========================================================================
    // ENCRYPTION
    // =========================================================================

    /**
     * True when the server can actually encrypt (key present).
     */
    public static function isAvailable(): bool
    {
        return EncryptionService::isConfigured();
    }

    /**
     * True when blind indexing is possible (BLIND_INDEX_KEY or ENCRYPTION_KEY).
     */
    public static function isBlindIndexAvailable(): bool
    {
        return BlindIndexService::isConfigured();
    }

    /**
     * Encrypt a submission's values map into a single ciphertext string.
     *
     * @param array<string, mixed> $values
     * @throws FormCryptoException When no key is configured, or encryption fails.
     *                             Never returns plaintext as a fallback.
     */
    public static function sealValues(array $values): string
    {
        if (!self::isAvailable()) {
            throw new FormCryptoException(
                'A titkosítás nem elérhető (nincs ENCRYPTION_KEY). A beküldés elutasítva, '
                . 'hogy a személyes adat ne kerüljön titkosítatlanul tárolásra.'
            );
        }

        try {
            return MassiveEncryption::encryptData($values);
        } catch (Throwable $e) {
            throw new FormCryptoException('A beküldés titkosítása nem sikerült: ' . $e->getMessage(), 0, $e);
        }
    }

    /**
     * Decrypt a submission's values map.
     *
     * @return array<string, mixed>
     * @throws FormCryptoException When the ciphertext cannot be authenticated
     *                             (wrong/rotated key, or tampering). This is
     *                             loud on purpose - a silent empty array would
     *                             look like "the visitor submitted nothing".
     */
    public static function openValues(string $ciphertext): array
    {
        if ($ciphertext === '') {
            return [];
        }

        if (!self::isAvailable()) {
            throw new FormCryptoException('A visszafejtés nem elérhető (nincs ENCRYPTION_KEY).');
        }

        try {
            return MassiveEncryption::decryptData($ciphertext);
        } catch (Throwable $e) {
            throw new FormCryptoException(
                'A beküldés visszafejtése nem sikerült. Ez általában megváltozott ENCRYPTION_KEY-re '
                . 'vagy sérült adatra utal.',
                0,
                $e
            );
        }
    }

    /**
     * Whether a stored string looks like our ciphertext.
     */
    public static function looksEncrypted(string $data): bool
    {
        return EncryptionService::isEncrypted($data);
    }

    // =========================================================================
    // BLIND INDEX
    // =========================================================================

    /**
     * Build the FTS content for an encrypted submission: blind index tokens for
     * the searchable fields only. Returns '' when there is nothing to index -
     * in which case NO row should be written to the FTS table at all.
     *
     * @param array<string, mixed> $values Plaintext values (pre-encryption)
     * @param array<int, string> $searchableFields
     */
    public static function buildTokens(array $values, array $searchableFields): string
    {
        if (empty($searchableFields) || !self::isBlindIndexAvailable()) {
            return '';
        }

        // Only pass through the fields that are actually opted in. Anything
        // else must never reach the token builder.
        $subset = [];
        foreach ($searchableFields as $field) {
            if (array_key_exists($field, $values)) {
                $subset[$field] = $values[$field];
            }
        }

        if (empty($subset)) {
            return '';
        }

        return MassiveEncryption::generateBlindIndex($subset, $searchableFields);
    }

    /**
     * Turn a user's search query into an FTS MATCH expression of blind tokens.
     *
     * Returns null when blind search is impossible (no searchable fields, no
     * key). Callers must then return an empty result set rather than falling
     * back to a plaintext search that would find nothing anyway.
     *
     * @param array<int, string> $searchableFields
     */
    public static function buildSearchQuery(string $query, array $searchableFields): ?string
    {
        $query = trim($query);
        if ($query === '' || empty($searchableFields) || !self::isBlindIndexAvailable()) {
            return null;
        }

        return MassiveEncryption::buildBlindSearchQuery($query, $searchableFields);
    }

    /**
     * Single token for one field (used by tests and targeted lookups).
     */
    public static function token(string $value, string $fieldName): string
    {
        return BlindIndexService::createToken($value, $fieldName);
    }

    // =========================================================================
    // IP HANDLING
    // =========================================================================

    /**
     * Hash an IP address for storage.
     *
     * IpHashService::hash() THROWS when IP_HASH_SECRET is absent. On a public
     * submit endpoint that would turn a missing optional env var into a 500 for
     * every visitor, so we degrade to storing nothing instead - and we never
     * fall back to the raw IP, which is exactly the personal data we are trying
     * not to keep in the clear.
     */
    public static function hashIp(?string $ip): ?string
    {
        if ($ip === null || $ip === '') {
            return null;
        }

        try {
            return IpHashService::hash($ip);
        } catch (Throwable $e) {
            if (!self::$ipSecretWarningLogged) {
                self::$ipSecretWarningLogged = true;
                try {
                    LoggerService::warning('[Forms] IP_HASH_SECRET nincs beállítva - a beküldések IP nélkül tárolódnak.', [
                        'component' => 'forms',
                    ]);
                } catch (Throwable) {
                    // Logging must never break a submission
                }
            }

            return null;
        }
    }

    /**
     * Keyed hash used for rate-limit buckets.
     *
     * Independent of hashIp(): rate limiting must keep working even without
     * IP_HASH_SECRET, otherwise a missing optional env var would silently
     * disable the abuse protection on a public endpoint. Falls back through
     * BLIND_INDEX_KEY -> ENCRYPTION_KEY, and only as a last resort to an
     * unkeyed hash (still not the raw IP).
     */
    public static function rateLimitKey(string $ip): string
    {
        $secret = $_ENV['IP_HASH_SECRET']
            ?? $_ENV['BLIND_INDEX_KEY']
            ?? $_ENV['ENCRYPTION_KEY']
            ?? null;

        if (is_string($secret) && $secret !== '') {
            return hash_hmac('sha256', $ip, $secret);
        }

        return hash('sha256', 'nomad-forms-rl:' . $ip);
    }
}
