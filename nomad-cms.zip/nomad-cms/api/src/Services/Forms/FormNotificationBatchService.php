<?php
/**
 * NOMAD CMS - Form Notification Batch Service
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * WHY THIS EXISTS
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * Without batching, a burst of submissions to the same form (a re-shared link,
 * a bot spike that clears the spam filter, a client mass-testing their embed)
 * means one MailService::send() call PER submission - one SMTP round trip
 * each. On shared hosting that is both slow (SMTP handshakes are not free) and
 * risky: many hosts throttle or temporarily block an account that opens too
 * many outbound connections in a short window, and even a "legitimate" 50-item
 * burst could trip that.
 *
 * This service collects submissions for a form into a single PENDING ROW while
 * a window is open, and lets the caller (FormNotifier) turn that row into
 * exactly one e-mail once the window has elapsed. The admin still gets
 * notified of every single submission - just as one aggregated message
 * ("37 new submissions") instead of 37 separate ones.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * THE ADAPTIVE WINDOW
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * The FIRST submission in an idle period opens a window of MIN_WINDOW_SECONDS
 * (5 minutes) - short enough that a single visitor's submission is not
 * noticeably delayed for an admin who only gets occasional submissions.
 *
 * Every ADDITIONAL submission that lands while the window is still open
 * extends it by EXTEND_SECONDS_PER_SUBMISSION (30s), capped at
 * MAX_WINDOW_SECONDS (30 minutes) total. This is what makes the window
 * "adaptive": a single trickle of submissions (one every few minutes) never
 * grows the window past the 5-minute minimum, because each one arrives after
 * the previous window already flushed - but a sustained burst (many
 * submissions per minute) keeps pushing flush_after out, up to the 30-minute
 * ceiling, which bounds the worst case: even an uninterrupted flood of
 * submissions is guaranteed a notification at least every 30 minutes, and
 * every submission still increments the SAME row rather than opening a new
 * SMTP send.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * TWO FLUSH PATHS, NEITHER ONE ALONE ENOUGH
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *   1. IMMEDIATE (FormNotifier::sendEmail(), called from the submit endpoint):
 *      after recording this submission, check whether THIS form's own batch
 *      just became due and flush it right there. This is what makes a form
 *      that receives a steady trickle of submissions notify promptly - it does
 *      not have to wait for unrelated traffic elsewhere on the site.
 *
 *   2. SAFETY NET (bootstrap.php's piggyback shutdown handler, sampled): sweep
 *      every form's due batch, not just the one that was just submitted to.
 *      This is what guarantees delivery even for a form that gets exactly ONE
 *      submission and then goes quiet - path 1 above never fires again for
 *      that form, so without a sweep the batch would sit flushable-but-
 *      unflushed until someone happened to submit that SAME form again.
 *
 * @package NomadCMS\Services\Forms
 */

declare(strict_types=1);

namespace NomadCMS\Services\Forms;

use NomadCMS\Services\Mail\MailException;
use NomadCMS\Services\Mail\MailProfileStore;
use NomadCMS\Services\Mail\MailSchema;
use NomadCMS\Services\Mail\MailService;
use NomadCMS\Services\Mail\MailTemplates;
use PDO;
use Throwable;

final class FormNotificationBatchService
{
    public const TABLE = 'massive_form_notification_batches';

    /** Every idle-started window opens at this length. */
    private const MIN_WINDOW_SECONDS = 300; // 5 minutes

    /** Each additional submission during an open window adds this much. */
    private const EXTEND_SECONDS_PER_SUBMISSION = 30;

    /** No window may be extended past this total length. */
    private const MAX_WINDOW_SECONDS = 1800; // 30 minutes

    private static bool $tableReady = false;

    /**
     * Create the pending-batch table on demand.
     *
     * Real columns and a UNIQUE constraint, not a MassiveDatabase JSON slot -
     * mirrors FormRateLimiter::ensureTable() for the same reason: an atomic
     * "increment and read" needs both.
     */
    public static function ensureTable(): void
    {
        if (self::$tableReady) {
            return;
        }

        $db = FormsSchema::db();
        $db->exec('
            CREATE TABLE IF NOT EXISTS ' . self::TABLE . ' (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                form_slug TEXT NOT NULL UNIQUE,
                submission_count INTEGER NOT NULL DEFAULT 0,
                window_started_at INTEGER NOT NULL,
                flush_after INTEGER NOT NULL,
                last_submission_uuid TEXT
            )
        ');
        $db->exec(
            'CREATE INDEX IF NOT EXISTS idx_' . self::TABLE . '_flush_after ON ' . self::TABLE . '(flush_after)'
        );

        self::$tableReady = true;
    }

    /**
     * Record one submission against a form's pending batch, opening a new
     * window if none is currently open.
     *
     * Never sends anything itself - see flushIfDue()/flushAllDue(). Every call
     * is a single atomic UPSERT, so concurrent submissions to the same form
     * cannot both read "no window open" and both start one.
     *
     * @param string|null $submissionUuid Null when the caller could not resolve
     *                    one (see FormNotifier::submissionUuid()) - the batch
     *                    still records the submission, it just has nothing to
     *                    deep-link to for this particular one. A null here
     *                    never overwrites an existing non-null value from an
     *                    earlier submission in the same window (see the
     *                    COALESCE below) - losing a previously known uuid would
     *                    only make the eventual notification link worse for no
     *                    reason.
     * @return int The batch's CURRENT submission_count after this call
     */
    public static function record(string $formSlug, ?string $submissionUuid): int
    {
        self::ensureTable();

        $now = time();
        $db = FormsSchema::db();

        // INSERT path (no window open): a fresh window starting now, length
        // MIN_WINDOW_SECONDS, count = 1.
        //
        // UPDATE path (window already open, i.e. flush_after has not yet been
        // consumed by a flush): increment the count and extend flush_after by
        // EXTEND_SECONDS_PER_SUBMISSION, clamped so the window's total length
        // never exceeds MAX_WINDOW_SECONDS measured from window_started_at.
        $stmt = $db->prepare('
            INSERT INTO ' . self::TABLE . '
                (form_slug, submission_count, window_started_at, flush_after, last_submission_uuid)
            VALUES (?, 1, ?, ?, ?)
            ON CONFLICT(form_slug) DO UPDATE SET
                submission_count = submission_count + 1,
                flush_after = MIN(
                    window_started_at + ' . self::MAX_WINDOW_SECONDS . ',
                    flush_after + ' . self::EXTEND_SECONDS_PER_SUBMISSION . '
                ),
                last_submission_uuid = COALESCE(excluded.last_submission_uuid, last_submission_uuid)
        ');
        $stmt->execute([$formSlug, $now, $now + self::MIN_WINDOW_SECONDS, $submissionUuid]);

        $row = self::findRow($formSlug);

        return $row === null ? 1 : (int) $row['submission_count'];
    }

    /**
     * Flush ONE specific form's batch immediately, if (and only if) it is
     * currently due. No-op otherwise - this is the "did my own submission
     * just make the window due" check the submit endpoint makes through
     * FormNotifier, not an unconditional send.
     *
     * @param array<string, mixed> $form Hydrated form definition (for the
     *                              e-mail content - recipients/profile are
     *                              read fresh from it, not from the batch row)
     */
    public static function flushIfDue(array $form, string $formSlug): void
    {
        self::ensureTable();

        $row = self::findRow($formSlug);
        if ($row === null || (int) $row['flush_after'] > time()) {
            return;
        }

        self::flushRow($form, $row);
    }

    /**
     * Sweep every form with a due batch. Used by the piggyback safety net,
     * which has no single form in mind - it just clears whatever has gone
     * stale since nobody's own submission happened to trigger flushIfDue().
     *
     * @param int $maxForms Hard cap so one request cannot be made to send an
     *                       unbounded number of e-mails
     * @return int Number of batches flushed
     */
    public static function flushAllDue(int $maxForms = 20): int
    {
        self::ensureTable();

        $db = FormsSchema::db();
        $stmt = $db->prepare(
            'SELECT * FROM ' . self::TABLE . ' WHERE flush_after <= ? ORDER BY flush_after ASC LIMIT ?'
        );
        $stmt->execute([time(), max(1, $maxForms)]);
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $flushed = 0;
        foreach ($rows as $row) {
            $slug = (string) ($row['form_slug'] ?? '');
            if ($slug === '') {
                continue;
            }

            try {
                $form = FormService::findBySlug($slug);
            } catch (Throwable) {
                $form = null;
            }

            if ($form === null) {
                // The form was deleted after submissions queued against it -
                // nothing left to notify about. Drop the orphaned row rather
                // than leaving it to be retried forever.
                self::deleteRow($slug);
                continue;
            }

            self::flushRow($form, $row);
            $flushed++;
        }

        return $flushed;
    }

    /**
     * Turn one due batch row into exactly one e-mail (or zero, if the form's
     * notification settings resolve to no usable recipient/profile), then
     * clear the row regardless of send outcome - a batch is a delivery
     * mechanism, not a durable retry queue, and the same
     * "never block/retry the visitor over a broken SMTP config" rule
     * FormNotifier already documents applies here too.
     *
     * @param array<string, mixed> $form
     * @param array<string, mixed> $row
     */
    private static function flushRow(array $form, array $row): void
    {
        $formSlug = (string) ($row['form_slug'] ?? '');
        $count = (int) ($row['submission_count'] ?? 1);
        $lastUuid = isset($row['last_submission_uuid']) && is_string($row['last_submission_uuid'])
            ? $row['last_submission_uuid']
            : null;

        // Cleared FIRST, not after sending: if the SMTP send throws or hangs,
        // the row must not be left behind to be picked up again (and resent)
        // by the next sweep - that would turn a transient mail failure into a
        // duplicate notification once the profile is fixed.
        self::deleteRow($formSlug);

        try {
            FormNotifier::sendBatchEmail($form, $count, $count === 1 ? $lastUuid : null);
        } catch (Throwable $e) {
            // Mirrors FormNotifier::sendEmail()'s own contract: a notification
            // failure must never propagate anywhere a visitor or an unrelated
            // request could observe it.
            error_log('[Forms] Batched notification flush failed for "' . $formSlug . '": ' . $e->getMessage());
        }
    }

    /**
     * @return array<string, mixed>|null
     */
    private static function findRow(string $formSlug): ?array
    {
        $stmt = FormsSchema::db()->prepare('SELECT * FROM ' . self::TABLE . ' WHERE form_slug = ?');
        $stmt->execute([$formSlug]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);

        return is_array($row) ? $row : null;
    }

    private static function deleteRow(string $formSlug): void
    {
        $stmt = FormsSchema::db()->prepare('DELETE FROM ' . self::TABLE . ' WHERE form_slug = ?');
        $stmt->execute([$formSlug]);
    }

    /**
     * Row count (diagnostics / tests).
     */
    public static function pendingCount(): int
    {
        self::ensureTable();

        return (int) FormsSchema::db()->query('SELECT COUNT(*) FROM ' . self::TABLE)->fetchColumn(0);
    }

    /**
     * Test seam: pull an existing window's flush_after into the past so a
     * flush can be exercised without waiting MIN_WINDOW_SECONDS in real time.
     */
    public static function forceDueForTesting(string $formSlug): void
    {
        self::ensureTable();

        $stmt = FormsSchema::db()->prepare(
            'UPDATE ' . self::TABLE . ' SET flush_after = ? WHERE form_slug = ?'
        );
        $stmt->execute([time() - 1, $formSlug]);
    }
}
