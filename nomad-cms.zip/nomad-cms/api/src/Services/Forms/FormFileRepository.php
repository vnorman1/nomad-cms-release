<?php
/**
 * NOMAD CMS - Form File Repository
 *
 * Persistence for submission attachments.
 *
 * WHY A REAL TABLE AND NOT A MASSIVE JSON SLOT:
 * The rest of the Forms module stores rows as JSON in massive_* tables, but
 * attachments need three things JSON rows are bad at:
 *
 *   1. SUM(size_bytes) per form, on every upload, to enforce the storage quota.
 *      Over JSON that is a scan with a json_extract per row.
 *   2. A UNIQUE constraint on uuid - the download endpoint looks files up by it,
 *      and a duplicate would make the lookup ambiguous.
 *   3. Cheap "all files of this submission" and "all files of this form" reads
 *      for the cascade deletes and the library.
 *
 * FormRateLimiter set the same precedent for the same reason.
 *
 * The row is metadata only: the bytes live on disk (FormFileStorage), and for an
 * encrypted form they are ciphertext there. Nothing in this table is secret, so
 * it stays readable for filtering and counting even when the submission itself is
 * encrypted - exactly the same envelope trade-off the submissions table makes.
 *
 * @package NomadCMS\Services\Forms
 */

declare(strict_types=1);

namespace NomadCMS\Services\Forms;

require_once __DIR__ . '/FormsSchema.php';
require_once __DIR__ . '/FormFileStorage.php';

use PDO;

final class FormFileRepository
{
    /** Default and maximum page sizes for the library listing */
    public const DEFAULT_PAGE_SIZE = 40;
    public const MAX_PAGE_SIZE = 200;

    private static bool $tableReady = false;

    /**
     * Create the attachments table on demand.
     */
    public static function ensureTable(): void
    {
        if (self::$tableReady) {
            return;
        }

        $db = FormsSchema::db();
        $table = FormsSchema::TABLE_FILES;

        $db->exec("
            CREATE TABLE IF NOT EXISTS {$table} (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                uuid TEXT NOT NULL UNIQUE,
                submission_id INTEGER NOT NULL,
                form_slug TEXT NOT NULL,
                original_name TEXT NOT NULL,
                extension TEXT NOT NULL,
                mime_type TEXT NOT NULL,
                size_bytes INTEGER NOT NULL,
                encrypted INTEGER NOT NULL DEFAULT 0,
                disk_path TEXT NOT NULL,
                checksum TEXT,
                field_name TEXT,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
        ");

        // submission_id: cascade delete + "attachments of this submission"
        $db->exec("CREATE INDEX IF NOT EXISTS idx_{$table}_submission ON {$table}(submission_id)");
        // form_slug + created_at: library listing (newest first) and quota sums
        $db->exec("CREATE INDEX IF NOT EXISTS idx_{$table}_form_created ON {$table}(form_slug, created_at DESC)");
        // created_at alone: the "all storage" view
        $db->exec("CREATE INDEX IF NOT EXISTS idx_{$table}_created ON {$table}(created_at DESC)");

        self::$tableReady = true;
    }

    // =========================================================================
    // WRITE
    // =========================================================================

    /**
     * Insert an attachment row.
     *
     * @param array{
     *     uuid:string, submission_id:int, form_slug:string, original_name:string,
     *     extension:string, mime_type:string, size_bytes:int, encrypted:bool,
     *     disk_path:string, checksum?:string|null, field_name?:string|null
     * } $file
     * @return int Row id
     */
    public static function insert(array $file): int
    {
        self::ensureTable();

        $stmt = FormsSchema::db()->prepare(
            'INSERT INTO ' . FormsSchema::TABLE_FILES . '
                (uuid, submission_id, form_slug, original_name, extension, mime_type,
                 size_bytes, encrypted, disk_path, checksum, field_name, created_at)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
        );

        $stmt->execute([
            $file['uuid'],
            $file['submission_id'],
            $file['form_slug'],
            $file['original_name'],
            strtolower($file['extension']),
            $file['mime_type'],
            $file['size_bytes'],
            $file['encrypted'] ? 1 : 0,
            $file['disk_path'],
            $file['checksum'] ?? null,
            $file['field_name'] ?? null,
            gmdate('Y-m-d H:i:s'),
        ]);

        return (int) FormsSchema::db()->lastInsertId();
    }

    /**
     * Re-point rows at a submission once its id is known.
     *
     * Files are validated and written to disk BEFORE the submission row exists
     * (the submission envelope has to list its attachments), so they are inserted
     * with submission_id = 0 and adopted here. Anything left at 0 is an orphan
     * from a failed submission and is swept up.
     */
    public static function attachToSubmission(array $uuids, int $submissionId): int
    {
        if (empty($uuids)) {
            return 0;
        }

        self::ensureTable();

        $placeholders = implode(',', array_fill(0, count($uuids), '?'));
        $stmt = FormsSchema::db()->prepare(
            'UPDATE ' . FormsSchema::TABLE_FILES . "
             SET submission_id = ?
             WHERE uuid IN ($placeholders)"
        );
        $stmt->execute([$submissionId, ...$uuids]);

        return $stmt->rowCount();
    }

    // =========================================================================
    // READ
    // =========================================================================

    /**
     * @return array<string, mixed>|null
     */
    public static function findByUuid(string $uuid): ?array
    {
        self::ensureTable();

        if (!FormFileStorage::isUuid($uuid)) {
            return null;
        }

        $stmt = FormsSchema::db()->prepare(
            'SELECT * FROM ' . FormsSchema::TABLE_FILES . ' WHERE uuid = ? LIMIT 1'
        );
        $stmt->execute([$uuid]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);

        return $row === false ? null : self::hydrate($row);
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    public static function listBySubmission(int $submissionId): array
    {
        self::ensureTable();

        $stmt = FormsSchema::db()->prepare(
            'SELECT * FROM ' . FormsSchema::TABLE_FILES . '
             WHERE submission_id = ? ORDER BY id ASC'
        );
        $stmt->execute([$submissionId]);

        return array_map([self::class, 'hydrate'], $stmt->fetchAll(PDO::FETCH_ASSOC));
    }

    /**
     * Attachments for many submissions at once.
     *
     * Used by the inbox listing so rendering 25 submissions costs one query
     * instead of 25.
     *
     * @param array<int, int> $submissionIds
     * @return array<int, array<int, array<string, mixed>>> submission_id => files
     */
    public static function listBySubmissionIds(array $submissionIds): array
    {
        if (empty($submissionIds)) {
            return [];
        }

        self::ensureTable();

        $ids = array_values(array_unique(array_map('intval', $submissionIds)));
        $placeholders = implode(',', array_fill(0, count($ids), '?'));

        $stmt = FormsSchema::db()->prepare(
            'SELECT * FROM ' . FormsSchema::TABLE_FILES . "
             WHERE submission_id IN ($placeholders)
             ORDER BY submission_id ASC, id ASC"
        );
        $stmt->execute($ids);

        $grouped = [];
        foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
            $file = self::hydrate($row);
            $grouped[(int) $row['submission_id']][] = $file;
        }

        return $grouped;
    }

    /**
     * Paginated library listing.
     *
     * @param array{form_slug?:string|null, group?:string|null, search?:string|null, page?:int, pageSize?:int} $criteria
     * @return array{items:array<int,array<string,mixed>>, total:int, page:int, pageSize:int, totalPages:int}
     */
    public static function listPaginated(array $criteria): array
    {
        self::ensureTable();

        [$where, $params] = self::buildWhere($criteria);
        $whereSql = $where === '' ? '' : "WHERE $where";

        $page = max(1, (int) ($criteria['page'] ?? 1));
        $pageSize = (int) ($criteria['pageSize'] ?? self::DEFAULT_PAGE_SIZE);
        $pageSize = max(1, min(self::MAX_PAGE_SIZE, $pageSize));

        $db = FormsSchema::db();

        $countStmt = $db->prepare('SELECT COUNT(*) FROM ' . FormsSchema::TABLE_FILES . " $whereSql");
        $countStmt->execute($params);
        $total = (int) $countStmt->fetchColumn(0);

        $offset = ($page - 1) * $pageSize;
        $listStmt = $db->prepare(
            'SELECT * FROM ' . FormsSchema::TABLE_FILES . "
             $whereSql
             ORDER BY created_at DESC, id DESC
             LIMIT $pageSize OFFSET $offset"
        );
        $listStmt->execute($params);

        return [
            'items' => array_map([self::class, 'hydrate'], $listStmt->fetchAll(PDO::FETCH_ASSOC)),
            'total' => $total,
            'page' => $page,
            'pageSize' => $pageSize,
            'totalPages' => (int) ceil($total / $pageSize),
        ];
    }

    /**
     * Bytes currently stored for one form - the quota input.
     */
    public static function sumSizeByForm(string $formSlug): int
    {
        self::ensureTable();

        $stmt = FormsSchema::db()->prepare(
            'SELECT COALESCE(SUM(size_bytes), 0) FROM ' . FormsSchema::TABLE_FILES . ' WHERE form_slug = ?'
        );
        $stmt->execute([$formSlug]);

        return (int) $stmt->fetchColumn(0);
    }

    /**
     * Bytes stored across every form.
     */
    public static function sumSizeTotal(): int
    {
        self::ensureTable();

        return (int) FormsSchema::db()
            ->query('SELECT COALESCE(SUM(size_bytes), 0) FROM ' . FormsSchema::TABLE_FILES)
            ->fetchColumn(0);
    }

    /**
     * File counts and sizes grouped by form, for the library overview.
     *
     * @return array<string, array{files:int, bytes:int}>
     */
    public static function statsByForm(): array
    {
        self::ensureTable();

        $rows = FormsSchema::db()->query(
            'SELECT form_slug, COUNT(*) AS files, COALESCE(SUM(size_bytes), 0) AS bytes
             FROM ' . FormsSchema::TABLE_FILES . '
             GROUP BY form_slug'
        )->fetchAll(PDO::FETCH_ASSOC);

        $stats = [];
        foreach ($rows as $row) {
            $stats[(string) $row['form_slug']] = [
                'files' => (int) $row['files'],
                'bytes' => (int) $row['bytes'],
            ];
        }

        return $stats;
    }

    public static function countAll(): int
    {
        self::ensureTable();

        return (int) FormsSchema::db()
            ->query('SELECT COUNT(*) FROM ' . FormsSchema::TABLE_FILES . ' WHERE submission_id > 0')
            ->fetchColumn(0);
    }

    /**
     * Attachment count for one form (excluding orphans).
     */
    public static function countByForm(string $formSlug): int
    {
        self::ensureTable();

        $stmt = FormsSchema::db()->prepare(
            'SELECT COUNT(*) FROM ' . FormsSchema::TABLE_FILES . '
             WHERE form_slug = ? AND submission_id > 0'
        );
        $stmt->execute([$formSlug]);

        return (int) $stmt->fetchColumn(0);
    }

    // =========================================================================
    // DELETE
    // =========================================================================

    /**
     * Delete one row AND its file on disk.
     *
     * Disk first, row second: a leftover row pointing at a missing file is
     * visible and fixable, whereas a deleted row pointing at a file nobody knows
     * about is personal data that can never be found again - the worse failure
     * under GDPR.
     */
    public static function deleteByUuid(string $uuid): bool
    {
        $file = self::findByUuid($uuid);
        if ($file === null) {
            return false;
        }

        FormFileStorage::delete((string) $file['disk_path']);

        $stmt = FormsSchema::db()->prepare(
            'DELETE FROM ' . FormsSchema::TABLE_FILES . ' WHERE uuid = ?'
        );
        $stmt->execute([$uuid]);

        return $stmt->rowCount() > 0;
    }

    /**
     * Delete every attachment of a submission.
     *
     * @return array{deleted:int, bytes:int}
     */
    public static function deleteBySubmission(int $submissionId): array
    {
        $files = self::listBySubmission($submissionId);

        $bytes = 0;
        foreach ($files as $file) {
            FormFileStorage::delete((string) $file['disk_path']);
            $bytes += (int) $file['size_bytes'];
        }

        $stmt = FormsSchema::db()->prepare(
            'DELETE FROM ' . FormsSchema::TABLE_FILES . ' WHERE submission_id = ?'
        );
        $stmt->execute([$submissionId]);

        return ['deleted' => count($files), 'bytes' => $bytes];
    }

    /**
     * Delete every attachment of several submissions (bulk delete / retention).
     *
     * @param array<int, int> $submissionIds
     * @return array{deleted:int, bytes:int}
     */
    public static function deleteBySubmissionIds(array $submissionIds): array
    {
        if (empty($submissionIds)) {
            return ['deleted' => 0, 'bytes' => 0];
        }

        self::ensureTable();

        $ids = array_values(array_unique(array_map('intval', $submissionIds)));
        $placeholders = implode(',', array_fill(0, count($ids), '?'));

        $stmt = FormsSchema::db()->prepare(
            'SELECT uuid, disk_path, size_bytes FROM ' . FormsSchema::TABLE_FILES . "
             WHERE submission_id IN ($placeholders)"
        );
        $stmt->execute($ids);
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $bytes = 0;
        foreach ($rows as $row) {
            FormFileStorage::delete((string) $row['disk_path']);
            $bytes += (int) $row['size_bytes'];
        }

        $del = FormsSchema::db()->prepare(
            'DELETE FROM ' . FormsSchema::TABLE_FILES . " WHERE submission_id IN ($placeholders)"
        );
        $del->execute($ids);

        return ['deleted' => count($rows), 'bytes' => $bytes];
    }

    /**
     * Delete every attachment of a form (form deletion).
     *
     * @return array{deleted:int, bytes:int}
     */
    public static function deleteByForm(string $formSlug): array
    {
        self::ensureTable();

        $stmt = FormsSchema::db()->prepare(
            'SELECT disk_path, size_bytes FROM ' . FormsSchema::TABLE_FILES . ' WHERE form_slug = ?'
        );
        $stmt->execute([$formSlug]);
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $bytes = 0;
        foreach ($rows as $row) {
            FormFileStorage::delete((string) $row['disk_path']);
            $bytes += (int) $row['size_bytes'];
        }

        $del = FormsSchema::db()->prepare(
            'DELETE FROM ' . FormsSchema::TABLE_FILES . ' WHERE form_slug = ?'
        );
        $del->execute([$formSlug]);

        FormFileStorage::pruneEmptyBuckets();

        return ['deleted' => count($rows), 'bytes' => $bytes];
    }

    /**
     * Rename the form reference after a slug change, so the library keeps
     * showing the files under the form they belong to.
     */
    public static function renameForm(string $oldSlug, string $newSlug): int
    {
        self::ensureTable();

        $stmt = FormsSchema::db()->prepare(
            'UPDATE ' . FormsSchema::TABLE_FILES . ' SET form_slug = ? WHERE form_slug = ?'
        );
        $stmt->execute([$newSlug, $oldSlug]);

        return $stmt->rowCount();
    }

    /**
     * Remove attachments that were written to disk but never adopted by a
     * submission (the request failed between the two steps).
     *
     * @param int $olderThanSeconds Only touch rows older than this, so a
     *        concurrent in-flight submission is never swept out from under itself
     * @return array{deleted:int, bytes:int}
     */
    public static function purgeOrphans(int $olderThanSeconds = 3600): array
    {
        self::ensureTable();

        $cutoff = gmdate('Y-m-d H:i:s', time() - max(60, $olderThanSeconds));

        $stmt = FormsSchema::db()->prepare(
            'SELECT uuid, disk_path, size_bytes FROM ' . FormsSchema::TABLE_FILES . '
             WHERE submission_id = 0 AND created_at < ?'
        );
        $stmt->execute([$cutoff]);
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $bytes = 0;
        foreach ($rows as $row) {
            FormFileStorage::delete((string) $row['disk_path']);
            $bytes += (int) $row['size_bytes'];
        }

        if (!empty($rows)) {
            $del = FormsSchema::db()->prepare(
                'DELETE FROM ' . FormsSchema::TABLE_FILES . ' WHERE submission_id = 0 AND created_at < ?'
            );
            $del->execute([$cutoff]);
        }

        return ['deleted' => count($rows), 'bytes' => $bytes];
    }

    // =========================================================================
    // HELPERS
    // =========================================================================

    /**
     * @param array<string, mixed> $criteria
     * @return array{0:string, 1:array<int, mixed>}
     */
    private static function buildWhere(array $criteria): array
    {
        $conditions = [];
        $params = [];

        // Orphans are never shown in the library: they belong to submissions that
        // do not exist, so there is nothing an admin could do with them.
        $conditions[] = 'submission_id > 0';

        $formSlug = $criteria['form_slug'] ?? null;
        if (is_string($formSlug) && $formSlug !== '') {
            $conditions[] = 'form_slug = ?';
            $params[] = $formSlug;
        }

        $group = $criteria['group'] ?? null;
        if (is_string($group) && isset(FormsSchema::UPLOAD_TYPE_GROUPS[$group])) {
            $extensions = FormsSchema::UPLOAD_TYPE_GROUPS[$group];
            $placeholders = implode(',', array_fill(0, count($extensions), '?'));
            $conditions[] = "extension IN ($placeholders)";
            foreach ($extensions as $ext) {
                $params[] = $ext;
            }
        }

        $search = $criteria['search'] ?? null;
        if (is_string($search) && trim($search) !== '') {
            // LIKE on the original filename. Not FTS: filenames are short, the
            // table is small next to submissions, and an index on a LIKE prefix
            // would not help a "contains" search anyway.
            $conditions[] = 'original_name LIKE ?';
            $params[] = '%' . str_replace(['%', '_'], ['\%', '\_'], trim($search)) . '%';
        }

        return [implode(' AND ', $conditions), $params];
    }

    /**
     * Normalise a DB row into the shape the API returns.
     *
     * @param array<string, mixed> $row
     * @return array<string, mixed>
     */
    private static function hydrate(array $row): array
    {
        $extension = (string) ($row['extension'] ?? '');

        return [
            'id' => (int) ($row['id'] ?? 0),
            'uuid' => (string) ($row['uuid'] ?? ''),
            'submission_id' => (int) ($row['submission_id'] ?? 0),
            'form_slug' => (string) ($row['form_slug'] ?? ''),
            'original_name' => (string) ($row['original_name'] ?? ''),
            'extension' => $extension,
            'mime_type' => (string) ($row['mime_type'] ?? ''),
            'size_bytes' => (int) ($row['size_bytes'] ?? 0),
            'encrypted' => (bool) ($row['encrypted'] ?? false),
            'disk_path' => (string) ($row['disk_path'] ?? ''),
            'checksum' => $row['checksum'] !== null ? (string) $row['checksum'] : null,
            'field_name' => $row['field_name'] !== null ? (string) $row['field_name'] : null,
            'created_at' => (string) ($row['created_at'] ?? ''),
            'group' => FormsSchema::typeGroup($extension),
            // Whether the bytes are still there. The library shows a "missing"
            // badge instead of offering a download that would 404.
            'missing' => !FormFileStorage::exists((string) ($row['disk_path'] ?? '')),
        ];
    }

    /**
     * Test seam.
     */
    public static function resetForTests(): void
    {
        self::$tableReady = false;
    }
}
