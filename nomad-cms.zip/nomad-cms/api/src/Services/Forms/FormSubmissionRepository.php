<?php
/**
 * NOMAD CMS - Form Submission Repository
 *
 * All SQL for the `massive_form_submissions` table lives here.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * WHY A DEDICATED QUERY PATH INSTEAD OF MassiveDatabase::getPaginated()
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * getPaginated() supports either json_extract filters (plaintext rows) or blind
 * index search (encrypted rows) - never both, because of its
 * `if (!$encrypted)` guard around the filter block. The inbox needs exactly
 * that combination: "unread submissions of form X matching this search".
 *
 * This repository therefore issues its own narrow SQL against the SAME table
 * and the SAME FTS companion, using the same conventions and the same crypto
 * helpers. Everything else (table creation, ownership column, FTS schema) still
 * comes from MassiveDatabase.
 *
 * The FTS row content is written explicitly here rather than letting
 * MassiveDatabase flatten the record, for two reasons:
 * - encrypted submissions must contain ONLY blind index tokens (the plaintext
 *   flattening would be the leak we are preventing)
 * - plaintext submissions should index the submitted VALUES, not the envelope
 *   metadata; otherwise searching for "read" would match every read submission.
 *
 * @package NomadCMS\Services\Forms
 */

declare(strict_types=1);

namespace NomadCMS\Services\Forms;

use PDO;

final class FormSubmissionRepository
{
    /** Hard cap on rows returned by an unpaginated export */
    public const EXPORT_MAX_ROWS = 50000;

    /**
     * Rows held in memory per streamed export batch.
     *
     * 500 keeps peak memory in the low single-digit MB even for the widest
     * forms, while still amortising query overhead across the export.
     */
    public const EXPORT_BATCH_SIZE = 500;

    /** Default and maximum page sizes */
    public const DEFAULT_PAGE_SIZE = 25;
    public const MAX_PAGE_SIZE = 200;

    /** Sentinel MATCH expression that can never match a row */
    private const NEVER_MATCH = '"__nomad_no_match__"';

    // =========================================================================
    // WRITE
    // =========================================================================

    /**
     * Insert a submission envelope.
     *
     * @param array<string, mixed> $envelope Full JSON envelope (already sealed if encrypted)
     * @param string $ftsContent FTS row content: submitted values (plaintext form)
     *                           or blind index tokens (encrypted form). Empty
     *                           string means "do not index this row at all".
     */
    public static function insert(array $envelope, string $ftsContent): int
    {
        FormsSchema::ensureTables();

        $db = FormsSchema::db();
        $stmt = $db->prepare(
            'INSERT INTO ' . FormsSchema::TABLE_SUBMISSIONS . ' (data, owner_uuid) VALUES (?, NULL)'
        );
        $stmt->execute([json_encode($envelope, JSON_UNESCAPED_UNICODE)]);

        $id = (int) $db->lastInsertId();

        self::writeIndexRow($id, $ftsContent);

        return $id;
    }

    /**
     * Replace the FTS row for a submission.
     *
     * Passing an empty string removes the row entirely, which is the correct
     * state for an encrypted submission with no searchable fields: no tokens
     * exist, so there is nothing that could be matched or attacked.
     */
    public static function writeIndexRow(int $id, string $content): void
    {
        FormsSchema::ensureTables();

        $db = FormsSchema::db();

        $delete = $db->prepare('DELETE FROM ' . FormsSchema::FTS_SUBMISSIONS . ' WHERE rowid = ?');
        $delete->execute([$id]);

        if ($content === '') {
            return;
        }

        $insert = $db->prepare(
            'INSERT INTO ' . FormsSchema::FTS_SUBMISSIONS . '(rowid, content) VALUES (?, ?)'
        );
        $insert->execute([$id, $content]);
    }

    /**
     * Overwrite the stored envelope of an existing submission.
     *
     * @param array<string, mixed> $envelope
     */
    public static function updateEnvelope(int $id, array $envelope): bool
    {
        FormsSchema::ensureTables();

        $stmt = FormsSchema::db()->prepare('
            UPDATE ' . FormsSchema::TABLE_SUBMISSIONS . '
            SET data = ?, updated_at = CURRENT_TIMESTAMP
            WHERE id = ?
        ');
        $stmt->execute([json_encode($envelope, JSON_UNESCAPED_UNICODE), $id]);

        return $stmt->rowCount() > 0;
    }

    /**
     * Delete one submission, its index row and its attachments.
     */
    public static function delete(int $id): bool
    {
        FormsSchema::ensureTables();

        // Attachments first: they are the only part living outside the database.
        // If the row went first and this failed, the files would be unreachable
        // personal data - impossible to find, impossible to erase on request.
        FormFileRepository::deleteBySubmission($id);

        $db = FormsSchema::db();
        $db->prepare('DELETE FROM ' . FormsSchema::FTS_SUBMISSIONS . ' WHERE rowid = ?')->execute([$id]);

        $stmt = $db->prepare('DELETE FROM ' . FormsSchema::TABLE_SUBMISSIONS . ' WHERE id = ?');
        $stmt->execute([$id]);

        return $stmt->rowCount() > 0;
    }

    /**
     * Delete many submissions, their index rows and their attachments.
     *
     * @param array<int, int> $ids
     */
    public static function bulkDelete(array $ids): int
    {
        $ids = array_values(array_unique(array_map('intval', $ids)));
        if (empty($ids)) {
            return 0;
        }

        FormsSchema::ensureTables();

        // One pass over the attachment table rather than one per submission.
        FormFileRepository::deleteBySubmissionIds($ids);

        $db = FormsSchema::db();
        $placeholders = implode(',', array_fill(0, count($ids), '?'));

        $db->prepare('DELETE FROM ' . FormsSchema::FTS_SUBMISSIONS . " WHERE rowid IN ($placeholders)")
            ->execute($ids);

        $stmt = $db->prepare('DELETE FROM ' . FormsSchema::TABLE_SUBMISSIONS . " WHERE id IN ($placeholders)");
        $stmt->execute($ids);

        return $stmt->rowCount();
    }

    /**
     * Delete every submission of a form (used when the form itself is deleted).
     */
    public static function deleteByFormSlug(string $formSlug): int
    {
        FormsSchema::ensureTables();

        $db = FormsSchema::db();

        $ids = self::idsForFormSlug($formSlug);
        if (empty($ids)) {
            return 0;
        }

        return self::bulkDelete($ids);
    }

    /**
     * Row ids belonging to a form slug.
     *
     * @return array<int, int>
     */
    public static function idsForFormSlug(string $formSlug): array
    {
        FormsSchema::ensureTables();

        $stmt = FormsSchema::db()->prepare(
            'SELECT id FROM ' . FormsSchema::TABLE_SUBMISSIONS . "
             WHERE json_extract(data, '$.form_slug') = ?"
        );
        $stmt->execute([$formSlug]);

        return array_map('intval', $stmt->fetchAll(PDO::FETCH_COLUMN, 0));
    }

    /**
     * Get all row IDs matching the given criteria (form_slug, status, search match).
     * Used for filter-based bulk operations.
     *
     * @param array<string, mixed> $criteria Same shape as buildWhere()
     * @return array<int, int>
     */
    public static function getMatchingIds(array $criteria): array
    {
        FormsSchema::ensureTables();

        [$where, $params] = self::buildWhere($criteria);
        $whereSql = $where === '' ? '' : "WHERE $where";

        $stmt = FormsSchema::db()->prepare(
            'SELECT id FROM ' . FormsSchema::TABLE_SUBMISSIONS . "
             $whereSql
             ORDER BY id DESC"
        );
        $stmt->execute($params);

        return array_map('intval', $stmt->fetchAll(PDO::FETCH_COLUMN, 0));
    }

    /**
     * Row ids of a form's submissions filtered by their encryption state.
     *
     * Used by the encryption migrator to walk only the rows that still need
     * work, which is what makes an interrupted migration safe to re-run.
     *
     * @return array<int, int>
     */
    public static function idsForFormSlugByEncryption(string $formSlug, bool $encrypted, int $limit): array
    {
        FormsSchema::ensureTables();

        // json_extract returns 1/0 for JSON booleans. The flag and the limit are
        // interpolated as integers rather than bound: PDO with
        // ATTR_EMULATE_PREPARES=false binds parameters as TEXT, and SQLite's
        // comparisons are type-sensitive, so `json_extract(...) = '0'` would
        // never match the integer 0. Both values are locally derived (bool and
        // int), so there is nothing user-controlled being interpolated.
        $flag = $encrypted ? 1 : 0;
        $limit = max(1, $limit);

        $stmt = FormsSchema::db()->prepare(
            'SELECT id FROM ' . FormsSchema::TABLE_SUBMISSIONS . "
             WHERE json_extract(data, '\$.form_slug') = ?
               AND COALESCE(json_extract(data, '\$.encrypted'), 0) = {$flag}
             ORDER BY id ASC
             LIMIT {$limit}"
        );
        $stmt->execute([$formSlug]);

        return array_map('intval', $stmt->fetchAll(PDO::FETCH_COLUMN, 0));
    }

    /**
     * Ids of submissions of a form older than the given retention window.
     *
     * Uses the indexed `created_at` COLUMN (not the JSON copy) so the sweep
     * stays cheap on a large table.
     *
     * @return array<int, int>
     */
    public static function expiredIds(string $formSlug, int $retentionDays, int $limit): array
    {
        FormsSchema::ensureTables();

        $stmt = FormsSchema::db()->prepare(
            'SELECT id FROM ' . FormsSchema::TABLE_SUBMISSIONS . "
             WHERE json_extract(data, '\$.form_slug') = ?
               AND created_at < datetime('now', ?)
             ORDER BY id ASC
             LIMIT ?"
        );
        $stmt->execute([$formSlug, sprintf('-%d days', max(1, $retentionDays)), max(1, $limit)]);

        return array_map('intval', $stmt->fetchAll(PDO::FETCH_COLUMN, 0));
    }

    // =========================================================================
    // READ
    // =========================================================================

    /**
     * Fetch one raw submission row.
     *
     * @return array{id:int, data:array<string,mixed>, created_at:string, updated_at:string}|null
     */
    public static function findById(int $id): ?array
    {
        FormsSchema::ensureTables();

        $stmt = FormsSchema::db()->prepare(
            'SELECT id, data, created_at, updated_at
             FROM ' . FormsSchema::TABLE_SUBMISSIONS . '
             WHERE id = ? LIMIT 1'
        );
        $stmt->execute([$id]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);

        return $row ? self::hydrate($row) : null;
    }

    /**
     * Paginated query with status/form filters and (optional) search.
     *
     * @param array{
     *     form_slug?: string|null,
     *     status?: string|null,
     *     match?: string|null,
     *     page?: int,
     *     pageSize?: int,
     *     dir?: string
     * } $criteria
     * @return array{items:array<int,array<string,mixed>>, total:int, page:int, pageSize:int, totalPages:int}
     */
    public static function query(array $criteria): array
    {
        FormsSchema::ensureTables();

        $page = max(1, (int) ($criteria['page'] ?? 1));
        $pageSize = (int) ($criteria['pageSize'] ?? self::DEFAULT_PAGE_SIZE);
        $pageSize = max(1, min(self::MAX_PAGE_SIZE, $pageSize));
        $offset = ($page - 1) * $pageSize;
        $dir = strtolower((string) ($criteria['dir'] ?? 'desc')) === 'asc' ? 'ASC' : 'DESC';

        [$where, $params] = self::buildWhere($criteria);
        $whereSql = $where === '' ? '' : "WHERE $where";

        $db = FormsSchema::db();

        $countStmt = $db->prepare('SELECT COUNT(*) FROM ' . FormsSchema::TABLE_SUBMISSIONS . " $whereSql");
        $countStmt->execute($params);
        $total = (int) $countStmt->fetchColumn(0);

        $listStmt = $db->prepare(
            'SELECT id, data, created_at, updated_at
             FROM ' . FormsSchema::TABLE_SUBMISSIONS . "
             $whereSql
             ORDER BY id $dir
             LIMIT ? OFFSET ?"
        );
        $listStmt->execute([...$params, $pageSize, $offset]);

        $items = [];
        foreach ($listStmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
            $items[] = self::hydrate($row);
        }

        return [
            'items' => $items,
            'total' => $total,
            'page' => $page,
            'pageSize' => $pageSize,
            // $pageSize is clamped to >= 1 above, so the division is always safe
            'totalPages' => (int) ceil($total / $pageSize),
        ];
    }

    /**
     * Unpaginated fetch for export, hard-capped.
     *
     * @param array<string, mixed> $criteria Same shape as query()
     * @return array<int, array<string, mixed>>
     */
    public static function fetchAllForExport(array $criteria): array
    {
        FormsSchema::ensureTables();

        [$where, $params] = self::buildWhere($criteria);
        $whereSql = $where === '' ? '' : "WHERE $where";

        $stmt = FormsSchema::db()->prepare(
            'SELECT id, data, created_at, updated_at
             FROM ' . FormsSchema::TABLE_SUBMISSIONS . "
             $whereSql
             ORDER BY id DESC
             LIMIT ?"
        );
        $stmt->execute([...$params, self::EXPORT_MAX_ROWS]);

        $items = [];
        foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
            $items[] = self::hydrate($row);
        }

        return $items;
    }

    /**
     * Stream export rows in batches, so a large export never materialises the
     * whole result set in PHP memory.
     *
     * WHY THIS EXISTS: fetchAllForExport() holds every row, its hydrated copy
     * and (in the caller) its presented copy simultaneously. Measured at the
     * 50 000-row cap that peaked at 150 MB for the fetch alone and 215 MB for a
     * full CSV build - fatal on the 128 MB memory_limit typical of shared
     * hosting. At 10 000 submissions/day a form crosses that line in about
     * three days, so the export has to stream.
     *
     * Uses KEYSET pagination (id < lastId) rather than LIMIT/OFFSET: OFFSET
     * makes SQLite walk and discard all skipped rows, so the last batch of a
     * 50 000-row export would re-scan 50 000 rows. Keyset stays O(batch).
     *
     * @param array<string, mixed> $criteria Same shape as buildWhere()
     * @param int $batchSize Rows held in memory at once
     * @param int $maxRows Hard cap across all batches
     * @return \Generator<int, array<string, mixed>> Hydrated rows
     */
    public static function streamForExport(
        array $criteria,
        int $batchSize = self::EXPORT_BATCH_SIZE,
        int $maxRows = self::EXPORT_MAX_ROWS
    ): \Generator {
        FormsSchema::ensureTables();

        $batchSize = max(50, min(2000, $batchSize));
        [$where, $params] = self::buildWhere($criteria);

        $db = FormsSchema::db();
        $emitted = 0;
        $lastId = PHP_INT_MAX;

        while ($emitted < $maxRows) {
            $conditions = $where === '' ? 'id < ?' : "$where AND id < ?";
            $limit = min($batchSize, $maxRows - $emitted);

            $stmt = $db->prepare(
                'SELECT id, data, created_at, updated_at
                 FROM ' . FormsSchema::TABLE_SUBMISSIONS . "
                 WHERE $conditions
                 ORDER BY id DESC
                 LIMIT $limit"
            );
            $stmt->execute([...$params, $lastId]);

            $batch = $stmt->fetchAll(PDO::FETCH_ASSOC);
            if (empty($batch)) {
                return;
            }

            foreach ($batch as $row) {
                $lastId = (int) $row['id'];
                $emitted++;
                yield self::hydrate($row);
            }

            // A short batch means the result set is exhausted.
            if (count($batch) < $limit) {
                return;
            }
        }
    }

    /**
     * Batch lookup by id, for enriching a page of attachments with their
     * parent submission's uuid/identity without one query per row.
     *
     * @param array<int, int> $ids
     * @return array<int, array<string,mixed>> Keyed by id
     */
    public static function findByIds(array $ids): array
    {
        FormsSchema::ensureTables();

        $ids = array_values(array_unique(array_filter(array_map('intval', $ids), static fn(int $id) => $id > 0)));
        if (empty($ids)) {
            return [];
        }

        $placeholders = implode(',', array_fill(0, count($ids), '?'));
        $stmt = FormsSchema::db()->prepare(
            'SELECT id, data, created_at, updated_at
             FROM ' . FormsSchema::TABLE_SUBMISSIONS . '
             WHERE id IN (' . $placeholders . ')'
        );
        $stmt->execute($ids);

        $byId = [];
        foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
            $hydrated = self::hydrate($row);
            $byId[$hydrated['id']] = $hydrated;
        }

        return $byId;
    }

    /**
     * Find a submission by its own UUID (deep link resolution).
     *
     * Uses an expression index (see FormsSchema::ensureIndexes), so this stays a
     * lookup rather than a scan as the table grows.
     *
     * @return array{id:int, data:array<string,mixed>, created_at:string, updated_at:string}|null
     */
    public static function findByUuid(string $uuid): ?array
    {
        FormsSchema::ensureTables();

        // Validate the shape before querying: the value comes straight from a URL.
        if (!FormFileStorage::isUuid($uuid)) {
            return null;
        }

        $stmt = FormsSchema::db()->prepare(
            'SELECT id, data, created_at, updated_at
             FROM ' . FormsSchema::TABLE_SUBMISSIONS . "
             WHERE json_extract(data, '\$.uuid') = ?
             LIMIT 1"
        );
        $stmt->execute([$uuid]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);

        return $row === false ? null : self::hydrate($row);
    }

    /**
     * Move every submission of one form slug to another.     *
     * Called when a form's slug changes. Without this, earlier submissions stay
     * bound to the old slug: invisible in the form's inbox, and missed by the
     * form's delete cascade - orphaned personal data nobody can reach or erase.
     *
     * json_set rewrites the field inside the envelope. Note this is safe for
     * ENCRYPTED submissions too, because form_slug lives in the plaintext part of
     * the envelope by design (that is what makes filtering possible at all).
     *
     * @return int Rows moved
     */
    public static function renameFormSlug(string $oldSlug, string $newSlug): int
    {
        FormsSchema::ensureTables();

        $stmt = FormsSchema::db()->prepare(
            'UPDATE ' . FormsSchema::TABLE_SUBMISSIONS . "
             SET data = json_set(data, '\$.form_slug', ?),
                 updated_at = ?
             WHERE json_extract(data, '\$.form_slug') = ?"
        );
        $stmt->execute([$newSlug, gmdate('Y-m-d H:i:s'), $oldSlug]);

        return $stmt->rowCount();
    }

    /**
     * Count rows matching the given criteria.
     *
     * @param array<string, mixed> $criteria Same shape as buildWhere()
     */
    public static function countMatching(array $criteria): int
    {        FormsSchema::ensureTables();

        [$where, $params] = self::buildWhere($criteria);
        $whereSql = $where === '' ? '' : "WHERE $where";

        $stmt = FormsSchema::db()->prepare(
            'SELECT COUNT(*) FROM ' . FormsSchema::TABLE_SUBMISSIONS . " $whereSql"
        );
        $stmt->execute($params);

        return (int) $stmt->fetchColumn(0);
    }

    /**
     * Collect the union of submitted field names for an export header, WITHOUT
     * loading any row payloads.
     *
     * The CSV header must be the union of every key that ever appeared (a form's
     * schema changes over time, and lax-schema forms accept arbitrary extras).
     * Discovering that by hydrating all rows is exactly what made the export
     * blow up, so it is done here in SQL over the stored field_names array.
     *
     * @param array<string, mixed> $criteria Same shape as buildWhere()
     * @return array<int, string> Field names in first-seen order
     */
    public static function exportFieldNames(array $criteria, int $maxRows = self::EXPORT_MAX_ROWS): array
    {
        FormsSchema::ensureTables();

        [$where, $params] = self::buildWhere($criteria);
        $whereSql = $where === '' ? '' : "WHERE $where";

        // json_each expands the field_names array server-side; only the distinct
        // names cross into PHP.
        $sql = 'SELECT DISTINCT fields.value AS field_name
                FROM (
                    SELECT data FROM ' . FormsSchema::TABLE_SUBMISSIONS . "
                    $whereSql
                    ORDER BY id DESC
                    LIMIT ?
                ) AS scoped
                JOIN json_each(json_extract(scoped.data, '\$.field_names')) AS fields";

        try {
            $stmt = FormsSchema::db()->prepare($sql);
            $stmt->execute([...$params, $maxRows]);

            $names = [];
            foreach ($stmt->fetchAll(PDO::FETCH_COLUMN, 0) as $name) {
                if (is_string($name) && $name !== '') {
                    $names[] = $name;
                }
            }

            return $names;
        } catch (\PDOException $e) {
            // json_each is a JSON1 extension function. If a host's SQLite lacks
            // it, fall back to an empty header set - the caller then derives
            // columns from the form definition instead of failing the export.
            //
            // NOTE the leading backslash: this class lives in a namespace, so an
            // unqualified `PDOException` would resolve to
            // NomadCMS\Services\Forms\PDOException, which does not exist - the
            // catch would never fire and the export would hard-fail on exactly
            // the hosts this fallback exists for.
            error_log('[Forms] exportFieldNames fallback: ' . $e->getMessage());
            return [];
        }
    }

    /**
     * Status counters, optionally scoped to one form.
     *
     * @return array<string, int> status => count, plus 'total'
     */
    public static function statusCounts(?string $formSlug = null): array
    {
        FormsSchema::ensureTables();

        $sql = "SELECT json_extract(data, '\$.status') AS status, COUNT(*) AS cnt
                FROM " . FormsSchema::TABLE_SUBMISSIONS;
        $params = [];

        if ($formSlug !== null && $formSlug !== '') {
            $sql .= " WHERE json_extract(data, '\$.form_slug') = ?";
            $params[] = $formSlug;
        }
        $sql .= ' GROUP BY status';

        $stmt = FormsSchema::db()->prepare($sql);
        $stmt->execute($params);

        $counts = [
            FormsSchema::STATUS_UNREAD => 0,
            FormsSchema::STATUS_READ => 0,
            FormsSchema::STATUS_ARCHIVED => 0,
            FormsSchema::STATUS_SPAM => 0,
            'total' => 0,
        ];

        foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
            $status = (string) ($row['status'] ?? '');
            $count = (int) $row['cnt'];
            if (array_key_exists($status, $counts)) {
                $counts[$status] += $count;
            }
            $counts['total'] += $count;
        }

        return $counts;
    }

    // =========================================================================
    // DIAGNOSTICS (used by the encryption leak test suite)
    // =========================================================================

    /**
     * The raw, undecoded `data` column of a row - what an attacker with the
     * database file would see.
     */
    public static function rawDataColumn(int $id): ?string
    {
        FormsSchema::ensureTables();

        $stmt = FormsSchema::db()->prepare(
            'SELECT data FROM ' . FormsSchema::TABLE_SUBMISSIONS . ' WHERE id = ?'
        );
        $stmt->execute([$id]);
        $value = $stmt->fetchColumn(0);

        return $value === false || $value === null ? null : (string) $value;
    }

    /**
     * The raw FTS content of a row - the other place plaintext could leak.
     */
    public static function rawIndexContent(int $id): ?string
    {
        FormsSchema::ensureTables();

        $stmt = FormsSchema::db()->prepare(
            'SELECT content FROM ' . FormsSchema::FTS_SUBMISSIONS . ' WHERE rowid = ?'
        );
        $stmt->execute([$id]);
        $value = $stmt->fetchColumn(0);

        return $value === false || $value === null ? null : (string) $value;
    }

    // =========================================================================
    // QUERY BUILDING
    // =========================================================================

    /**
     * @param array<string, mixed> $criteria
     * @return array{0:string, 1:array<int, mixed>}
     */
    private static function buildWhere(array $criteria): array
    {
        $conditions = [];
        $params = [];

        $formSlug = $criteria['form_slug'] ?? null;
        if (is_string($formSlug) && $formSlug !== '') {
            $conditions[] = "json_extract(data, '\$.form_slug') = ?";
            $params[] = $formSlug;
        }

        $status = $criteria['status'] ?? null;
        if (is_string($status) && $status !== '' && in_array($status, FormsSchema::STATUSES, true)) {
            $conditions[] = "json_extract(data, '\$.status') = ?";
            $params[] = $status;
        }

        $match = $criteria['match'] ?? null;
        if (is_string($match) && $match !== '') {
            $conditions[] = 'id IN (SELECT rowid FROM ' . FormsSchema::FTS_SUBMISSIONS
                . ' WHERE ' . FormsSchema::FTS_SUBMISSIONS . ' MATCH ?)';
            $params[] = $match;
        }

        return [implode(' AND ', $conditions), $params];
    }

    /**
     * FTS5 MATCH expression that matches nothing (used when a search cannot
     * possibly be satisfied, e.g. blind search without a key).
     */
    public static function neverMatchExpression(): string
    {
        return self::NEVER_MATCH;
    }

    /**
     * @param array<string, mixed> $row
     * @return array{id:int, data:array<string,mixed>, created_at:string, updated_at:string}
     */
    private static function hydrate(array $row): array
    {
        $data = json_decode((string) $row['data'], true);

        return [
            'id' => (int) $row['id'],
            'data' => is_array($data) ? $data : [],
            'created_at' => (string) ($row['created_at'] ?? ''),
            'updated_at' => (string) ($row['updated_at'] ?? ''),
        ];
    }
}
