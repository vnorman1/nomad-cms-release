<?php
/**
 * NOMAD CMS — Internal form definition persistence.
 * Writes validated Forms module metadata independently of user content schemas.
 * Keeps definition rows and FTS atomic; never grants generic slot write exemptions.
 */
declare(strict_types=1);

namespace NomadCMS\Services\Forms;

use PDO;

/** Stores Forms-owned plaintext definitions; submission encryption is managed separately. */
final class FormDefinitionRepository
{
    /** Persist a validated definition and its searchable representation. */
    public static function insert(array $data, ?string $ownerUuid): int
    {
        return self::transaction(static function (PDO $db) use ($data, $ownerUuid): int {
            $query = $db->prepare('INSERT INTO massive_form_definitions(data, owner_uuid, storage_mode) VALUES (?, ?, ?)');
            $query->execute([json_encode($data, JSON_THROW_ON_ERROR | JSON_UNESCAPED_UNICODE), $ownerUuid, 'plain']);
            $id = (int) $db->lastInsertId();
            self::index($db, $id, $data);
            return $id;
        });
    }

    /** Replace a validated definition without modifying its owner or creation timestamp. */
    public static function update(int $id, array $data): bool
    {
        return self::transaction(static function (PDO $db) use ($id, $data): bool {
            $query = $db->prepare('UPDATE massive_form_definitions SET data=?, storage_mode=?, updated_at=CURRENT_TIMESTAMP WHERE id=?');
            $query->execute([json_encode($data, JSON_THROW_ON_ERROR | JSON_UNESCAPED_UNICODE), 'plain', $id]);
            if ($query->rowCount() === 0) {
                return false;
            }
            self::index($db, $id, $data);
            return true;
        });
    }

    /** Delete the internal definition and FTS entry together. */
    public static function delete(int $id): bool
    {
        return self::transaction(static function (PDO $db) use ($id): bool {
            $db->prepare('DELETE FROM massive_form_definitions_fts WHERE rowid=?')->execute([$id]);
            $query = $db->prepare('DELETE FROM massive_form_definitions WHERE id=?');
            $query->execute([$id]);
            return $query->rowCount() > 0;
        });
    }

    /** Preserve the existing recursive plaintext search representation. */
    private static function flatten(array $data): string
    {
        $parts = [];
        foreach ($data as $value) {
            if (is_array($value)) {
                $parts[] = self::flatten($value);
            } elseif (is_string($value) || is_numeric($value)) {
                $parts[] = (string) $value;
            }
        }
        return implode(' ', $parts);
    }

    private static function index(PDO $db, int $id, array $data): void
    {
        $db->prepare('DELETE FROM massive_form_definitions_fts WHERE rowid=?')->execute([$id]);
        $db->prepare('INSERT INTO massive_form_definitions_fts(rowid,content) VALUES (?,?)')->execute([$id, self::flatten($data)]);
        $db->prepare('UPDATE massive_schema_modes SET has_plain=1 WHERE slot_key=?')->execute([FormsSchema::SLOT_DEFINITIONS]);
    }

    private static function transaction(callable $operation): mixed
    {
        FormsSchema::ensureTables();
        $db = FormsSchema::db();
        $nested = $db->inTransaction();
        $db->exec($nested ? 'SAVEPOINT forms_definition_write' : 'BEGIN IMMEDIATE');
        try {
            $result = $operation($db);
            $db->exec($nested ? 'RELEASE SAVEPOINT forms_definition_write' : 'COMMIT');
            return $result;
        } catch (\Throwable $exception) {
            if ($nested) {
                $db->exec('ROLLBACK TO SAVEPOINT forms_definition_write');
                $db->exec('RELEASE SAVEPOINT forms_definition_write');
            } elseif ($db->inTransaction()) {
                $db->rollBack();
            }
            throw $exception;
        }
    }
}
