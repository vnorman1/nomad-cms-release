<?php
/**
 * NOMAD CMS - Forms Schema
 *
 * Central definition of the storage layout used by the native Form Builder &
 * Submissions module.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * STORAGE MODEL
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * The module persists into massive.sqlite through the existing
 * {@see \NomadCMS\Database\MassiveDatabase}, using two dedicated logical
 * slots. It does NOT require a `massive` type slot to be defined in the CMS
 * schema - the tables are created on demand by ensureTables().
 *
 *   massive_form_definitions  - one row per form definition
 *   massive_form_submissions  - one row per submission
 *   massive_form_rate_limits  - IP rate limit buckets (own schema, see
 *                               FormRateLimiter - it needs real columns, not
 *                               a JSON blob, for atomic UPSERT counting)
 *
 * Each massive table has the standard shape (id, data JSON, owner_uuid,
 * created_at, updated_at) plus an FTS5 companion table `{table}_fts`.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * ENVELOPE ENCRYPTION (GDPR)
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * Submissions of an encrypted form use ENVELOPE encryption rather than
 * whole-row encryption:
 *
 *   - the outer `data` JSON stays plaintext, but carries only NON-personal
 *     metadata (type, form_slug, status, created_at, enc_version, field_names)
 *   - the personal payload lives exclusively in `values_encrypted`, an
 *     authenticated Defuse ciphertext (see FormCrypto)
 *
 * Why not MassiveDatabase's own `$encrypted = true` whole-row mode? Because
 * MassiveDatabase::getPaginated() deliberately skips json_extract filters for
 * encrypted rows (`if (!$encrypted)`), which would make status filtering,
 * unread counters and per-form scoping impossible. The envelope keeps every
 * massive query capability intact while still leaving zero personal data
 * readable in the database file or in a backup.
 *
 * SECURITY: the encryption flag is read from the STORED form definition,
 * never from request headers. The massive slots take their `encrypted` flag
 * from frontend-signed headers (SlotConfigSigning), where the signing key is
 * the caller's JWT - unusable on a public, unauthenticated submit endpoint,
 * where the documented fallback would be "unencrypted". That fallback would
 * silently store plaintext personal data, so this module never consults
 * SlotConfigSigning.
 *
 * @package NomadCMS\Services\Forms
 */

declare(strict_types=1);

namespace NomadCMS\Services\Forms;

use NomadCMS\Database\MassiveDatabase;
use PDO;

final class FormsSchema
{
    /** Logical massive slot key holding form definitions */
    public const SLOT_DEFINITIONS = 'form_definitions';

    /** Logical massive slot key holding submissions */
    public const SLOT_SUBMISSIONS = 'form_submissions';

    /** Physical table names (mirrors MassiveDatabase::getTableName()) */
    public const TABLE_DEFINITIONS = 'massive_form_definitions';
    public const TABLE_SUBMISSIONS = 'massive_form_submissions';

    /** FTS companion tables */
    public const FTS_DEFINITIONS = 'massive_form_definitions_fts';
    public const FTS_SUBMISSIONS = 'massive_form_submissions_fts';

    /** JSON `type` discriminators (kept for spec compatibility / forensics) */
    public const TYPE_DEFINITION = 'form_definition';
    public const TYPE_SUBMISSION = 'form_submission';

    /** Submission lifecycle states */
    public const STATUS_UNREAD = 'unread';
    public const STATUS_READ = 'read';
    public const STATUS_ARCHIVED = 'archived';
    public const STATUS_SPAM = 'spam';

    /** @var array<int, string> All valid submission statuses */
    public const STATUSES = [
        self::STATUS_UNREAD,
        self::STATUS_READ,
        self::STATUS_ARCHIVED,
        self::STATUS_SPAM,
    ];

    /** Current envelope encryption version (bumped only on format changes) */
    public const ENC_VERSION = 1;

    /** Default honeypot field name when the form does not specify one */
    public const DEFAULT_HONEYPOT = 'website_url_hp';

    /** Default per-IP submissions allowed per minute */
    public const DEFAULT_RATE_LIMIT = 10;

    /** Hard bounds for the configurable per-form rate limit */
    public const MIN_RATE_LIMIT = 1;
    public const MAX_RATE_LIMIT = 120;

    /** Payload ceilings enforced on the public endpoint */
    public const MAX_BODY_BYTES = 262144;      // 256 KB
    public const MAX_FIELDS = 100;
    public const MAX_KEY_LENGTH = 64;
    public const MAX_VALUE_LENGTH = 20000;

    /** Retention bounds (days). null = keep forever. */
    public const MIN_RETENTION_DAYS = 1;
    public const MAX_RETENTION_DAYS = 3650;

    // =========================================================================
    // ATTACHMENTS
    // =========================================================================

    /** Physical table holding submission attachments */
    public const TABLE_FILES = 'massive_form_files';

    /**
     * Total attachment bytes allowed per SUBMISSION.
     *
     * Not per file: a visitor uploading 5 x 5 MB would otherwise sail past any
     * per-file limit. 5 MB is the agreed budget for the whole submission.
     */
    public const MAX_UPLOAD_TOTAL_BYTES = 5242880; // 5 MB

    /** Files allowed per submission */
    public const DEFAULT_MAX_FILES = 5;
    public const MAX_MAX_FILES = 10;

    /** Default per-form storage quota, and its hard ceiling */
    public const DEFAULT_FORM_QUOTA_BYTES = 524288000;  // 500 MB
    public const MAX_FORM_QUOTA_BYTES = 10737418240;    // 10 GB

    /** Longest original filename we keep (display only; disk names are UUIDs) */
    public const MAX_FILENAME_LENGTH = 255;

    /**
     * HARD backend whitelist of accepted upload types.
     *
     * A form may narrow this (settings.uploads.allowed_types) but can never
     * widen it - the per-form list is intersected with this map, so a
     * compromised or hand-crafted form definition cannot introduce a dangerous
     * type.
     *
     * Keyed by extension => list of MIME types finfo may legitimately report for
     * it. The pair must MATCH: a ".pdf" that sniffs as text/html is rejected,
     * which is what stops "rename the payload" attacks.
     *
     * Deliberately ABSENT:
     * - svg: XML that can carry <script>; harmless only if never rendered, and
     *   that is too easy to get wrong downstream.
     * - html/htm/xhtml: stored XSS the moment anything serves them inline.
     * - php/phtml/js and every other executable extension.
     *
     * @var array<string, array<int, string>>
     */
    public const UPLOAD_TYPE_WHITELIST = [
        // Images
        'jpg'  => ['image/jpeg'],
        'jpeg' => ['image/jpeg'],
        'png'  => ['image/png'],
        'gif'  => ['image/gif'],
        'webp' => ['image/webp'],
        // Documents
        'pdf'  => ['application/pdf'],
        'txt'  => ['text/plain'],
        'csv'  => ['text/csv', 'text/plain', 'application/csv'],
        'doc'  => ['application/msword', 'application/vnd.ms-office', 'application/x-ole-storage'],
        'docx' => [
            'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
            'application/zip',
        ],
        'xls'  => ['application/vnd.ms-excel', 'application/vnd.ms-office', 'application/x-ole-storage'],
        'xlsx' => [
            'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            'application/zip',
        ],
        'ppt'  => ['application/vnd.ms-powerpoint', 'application/vnd.ms-office', 'application/x-ole-storage'],
        'pptx' => [
            'application/vnd.openxmlformats-officedocument.presentationml.presentation',
            'application/zip',
        ],
        'zip'  => ['application/zip', 'application/x-zip-compressed'],
        // Media
        'mp4'  => ['video/mp4'],
        'webm' => ['video/webm', 'audio/webm'],
        'mp3'  => ['audio/mpeg', 'audio/mp3'],
    ];

    /**
     * Types a form gets when uploads are switched on without an explicit list.
     *
     * Images + documents only. Video/audio stay opt-in: within a 5 MB budget
     * they are barely usable, and every extra accepted type is extra surface.
     *
     * @var array<int, string>
     */
    public const DEFAULT_UPLOAD_TYPES = [
        'jpg', 'jpeg', 'png', 'gif', 'webp',
        'pdf', 'txt', 'csv',
        'doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx',
        'zip',
    ];

    /**
     * Coarse grouping for the admin library filter.
     *
     * @var array<string, array<int, string>>
     */
    public const UPLOAD_TYPE_GROUPS = [
        'image' => ['jpg', 'jpeg', 'png', 'gif', 'webp'],
        'document' => ['pdf', 'txt', 'csv', 'doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx'],
        'archive' => ['zip'],
        'media' => ['mp4', 'webm', 'mp3'],
    ];

    /**
     * Default upload settings for a form.
     *
     * enabled=false so every EXISTING form keeps rejecting uploads after this
     * feature ships - turning a public endpoint into a file sink must be an
     * explicit decision, never a side effect of an upgrade.
     *
     * @return array<string, mixed>
     */
    public static function defaultUploadSettings(): array
    {
        return [
            'enabled' => false,
            'allowed_types' => self::DEFAULT_UPLOAD_TYPES,
            'max_files' => self::DEFAULT_MAX_FILES,
            'max_total_bytes' => self::MAX_UPLOAD_TOTAL_BYTES,
            'quota_bytes' => self::DEFAULT_FORM_QUOTA_BYTES,
        ];
    }

    /**
     * Which library group an extension belongs to.
     */
    public static function typeGroup(string $extension): string
    {
        $extension = strtolower($extension);

        foreach (self::UPLOAD_TYPE_GROUPS as $group => $extensions) {
            if (in_array($extension, $extensions, true)) {
                return $group;
            }
        }

        return 'other';
    }

    /**
     * Guard so the (idempotent but not free) schema check runs once per process
     * instead of once per repository call.
     *
     * MassiveDatabase::ensureTable() has no memoisation of its own: each call
     * issues a sqlite_master lookup AND a PRAGMA table_info (the owner_uuid
     * migration probe). ensureTables() is called at the top of ~22 methods, so a
     * single inbox page load was paying dozens of redundant round trips. On
     * shared hosting - where massive.sqlite often lives on network-backed
     * storage - those round trips are the expensive kind.
     */
    private static bool $tablesReady = false;

    /** Guard for the one-time index migration */
    private static bool $indexesReady = false;

    /**
     * Ensure both massive tables (and their FTS companions) exist.
     *
     * Idempotent, and now memoised for the lifetime of the request.
     */
    public static function ensureTables(): void
    {
        if (self::$tablesReady) {
            return;
        }

        MassiveDatabase::ensureTable(self::SLOT_DEFINITIONS);
        MassiveDatabase::ensureTable(self::SLOT_SUBMISSIONS);

        self::$tablesReady = true;

        self::ensureIndexes();
    }

    /**
     * Create the expression indexes the inbox depends on.
     *
     * WHY THIS IS NOT OPTIONAL AT SCALE:
     * Submissions are JSON rows, and every inbox query filters on
     * json_extract(data,'$.form_slug') / '$.status'. MassiveDatabase only
     * indexes created_at/updated_at/owner_uuid, so without these the filters
     * degrade to a full table scan that evaluates json_extract per row.
     * Measured on 365k rows (= one year at 10k submissions/day):
     *
     *   query                        no index      with index
     *   dashboard stats (GROUP BY)     1.55 s        26 ms
     *   inbox COUNT (pagination)        606 ms       0.3 ms
     *   statusCounts (one form)         352 ms         3 ms
     *   retention sweep candidates       57 ms       2.5 ms
     *
     * Index choice: two COMPOUND indexes, not three single-column ones. A
     * standalone index on '$.status' alone made the *global* inbox slower
     * (0.2 ms -> 81 ms), because the planner preferred it over created_at and
     * then had to sort the matches; folding created_at into the index instead
     * lets one index satisfy both the filter and the ORDER BY.
     *
     * Write cost of the two indexes, measured: 0.06 ms/row (~16 800 rows/sec) -
     * irrelevant next to the read savings.
     *
     * Expression indexes require SQLite >= 3.9 (2015). On anything older this
     * silently does nothing: the module keeps working exactly as before, just
     * without the speedup, rather than fataling on an ancient shared host.
     */
    public static function ensureIndexes(): void
    {
        if (self::$indexesReady) {
            return;
        }
        self::$indexesReady = true;

        $db = self::db();

        if (!self::supportsExpressionIndexes($db)) {
            return;
        }

        $table = self::TABLE_SUBMISSIONS;

        try {
            // Serves: per-form inbox listing, its COUNT, statusCounts, and the
            // dashboard GROUP BY (scanned in index order, no table access).
            $db->exec(
                "CREATE INDEX IF NOT EXISTS idx_{$table}_slug_status_created
                 ON {$table}(
                     json_extract(data, '\$.form_slug'),
                     json_extract(data, '\$.status'),
                     created_at DESC
                 )"
            );

            // Serves the GLOBAL inbox (status filter across every form) while
            // still satisfying ORDER BY created_at DESC.
            $db->exec(
                "CREATE INDEX IF NOT EXISTS idx_{$table}_status_created
                 ON {$table}(
                     json_extract(data, '\$.status'),
                     created_at DESC
                 )"
            );

            // Deep link resolution: /forms/{slug}/submissions/{uuid}
            $db->exec(
                "CREATE INDEX IF NOT EXISTS idx_{$table}_uuid
                 ON {$table}(json_extract(data, '\$.uuid'))"
            );

            // Definition lookups by slug happen on EVERY public submission.
            $definitions = self::TABLE_DEFINITIONS;
            $db->exec(
                "CREATE INDEX IF NOT EXISTS idx_{$definitions}_slug
                 ON {$definitions}(json_extract(data, '\$.slug'))"
            );
        } catch (\PDOException $e) {
            // A failed index build must never break a submission - the queries
            // still work, just slower. Log and continue.
            error_log('[Forms] Index migration skipped: ' . $e->getMessage());
        }
    }

    /**
     * Expression indexes (CREATE INDEX ... ON t(expr)) need SQLite 3.9.0+.
     */
    private static function supportsExpressionIndexes(PDO $db): bool
    {
        $version = (string) $db->query('SELECT sqlite_version()')->fetchColumn();

        return version_compare($version, '3.9.0', '>=');
    }

    /**
     * Shared PDO handle for massive.sqlite.
     */
    public static function db(): PDO
    {
        return MassiveDatabase::getInstance();
    }
}
