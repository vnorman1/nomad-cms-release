<?php
/**
 * NOMAD CMS - Form Crypto Exception
 *
 * Encryption or decryption could not be performed.
 *
 * Raised when:
 * - the encryption key is unavailable while the form requires encryption
 *   (fail-closed: we must NEVER silently fall back to storing plaintext
 *   personal data), or
 * - stored ciphertext cannot be authenticated, which means the key changed or
 *   the row was tampered with.
 *
 * Both cases must be loud. A silent empty array would look like "the user
 * submitted nothing" and would quietly destroy data on the next write.
 *
 * @package NomadCMS\Services\Forms
 */

declare(strict_types=1);

namespace NomadCMS\Services\Forms;

use RuntimeException;

class FormCryptoException extends RuntimeException
{
}
