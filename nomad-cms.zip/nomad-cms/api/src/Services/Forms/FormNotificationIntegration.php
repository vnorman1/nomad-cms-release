<?php

/**
 * NOMAD CMS - Forms central notification integration.
 * Publishes metadata-only submission events in the source transaction.
 * Rechecks current Forms permissions and resolves Inbox links from existing definitions.
 */

declare(strict_types=1);

namespace NomadCMS\Services\Forms;

use NomadCMS\Database\MassiveDatabase;
use NomadCMS\Services\NotificationService\Contracts\DomainEvent;
use NomadCMS\Services\NotificationService\Events\EventDefinition;
use NomadCMS\Services\NotificationService\Events\EventRegistry;
use NomadCMS\Services\NotificationService\Events\SourcePublisher;
use NomadCMS\Services\NotificationService\NotificationException;
use NomadCMS\Services\NotificationService\NotificationModule;
use NomadCMS\Services\NotificationService\Support;
use PDO;

/** In-app-only integration; SMTP settings never affect this channel. */
final class FormNotificationIntegration
{
    public const EVENT_TYPE = 'forms.submission.created';
    public const TARGET_KIND = 'forms.inbox';

    public function __construct(private ?NotificationModule $central = null, private ?PDO $source = null)
    {
    }

    public function register(): void
    {
        if ($this->central === null) {
            throw new \LogicException('Central notification module required');
        }
        $this->central->events->register($this->definition());
        $this->central->targets->register(self::TARGET_KIND, function (array $target, string $user): string {
            if (!$this->canRead($target['id'], $user)) {
                throw new NotificationException('target_unavailable', 404);
            }
            $form = $this->form($target['id']);
            return '/forms/' . rawurlencode($form['slug']);
        });
    }

    private function definition(): EventDefinition
    {
        return new EventDefinition(
            self::EVENT_TYPE,
            'forms',
            function (array $event): array {
                $id = (string) ($event['data']['form_id'] ?? '');
                $form = $this->form($id);
                $name = mb_substr((string) ($form['name'] ?? 'Űrlap'), 0, 200);
                return [
                    'title' => 'Új űrlapbeküldés',
                    'message' => 'Új beküldés érkezett: ' . $name,
                    'target' => ['kind' => self::TARGET_KIND, 'id' => $id],
                    'language' => 'hu',
                    'presentation' => ['key' => 'formSubmission', 'params' => ['form' => $name]],
                ];
            },
            fn(array $event, string $user): bool => $this->canRead((string) ($event['data']['form_id'] ?? ''), $user),
            false,
            120,
            false,
            false,
            [],
            ['in_app'],
            'formSubmission',
            ['form']
        );
    }

    private function form(string $id): ?array
    {
        $db = $this->source ??= MassiveDatabase::getInstance(true);
        $row = Support::one($db, 'SELECT data FROM ' . FormsSchema::TABLE_DEFINITIONS . ' WHERE id=?', [$id]);
        return $row === null ? null : json_decode($row['data'], true, 512, JSON_THROW_ON_ERROR);
    }

    private function canRead(string $id, string $user): bool
    {
        return $this->central !== null
            && ($this->central->access->has($user, 'forms:read:*') || $this->central->access->has($user, 'forms:list:*'))
            && $this->form($id) !== null;
    }

    /** Called only inside the same transaction that inserts the submission and its FTS row. */
    public static function record(PDO $db, array $form, string $uuid, string $status): void
    {
        if (($form['data']['settings']['notification']['in_app'] ?? false) !== true || $status === FormsSchema::STATUS_SPAM) {
            return;
        }
        $registry = new EventRegistry();
        $registry->register((new self())->definition());
        (new SourcePublisher($registry, static fn(): int => time()))->record($db, new DomainEvent([
            'source' => 'forms',
            'type' => self::EVENT_TYPE,
            'occurrence_key' => $uuid,
            'subject' => ['kind' => 'forms.form', 'id' => (string) $form['id']],
            'audience' => ['kind' => 'all_users'],
            'data' => ['form_id' => (string) $form['id']],
        ]));
    }
}
