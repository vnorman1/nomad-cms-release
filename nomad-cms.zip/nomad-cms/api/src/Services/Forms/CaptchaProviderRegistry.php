<?php
/**
 * NOMAD CMS - Captcha Provider Registry
 *
 * Loads the hand-maintained provider URL map from
 * api/external/providers/providers.php and exposes it through a small,
 * validated API.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * WHY A FALLBACK, NOT A HARD FAILURE
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * providers.php is deliberately hand-edited (see its own header comment). A
 * typo there - a missing key, a malformed URL - must not take every
 * captcha-protected form on the site offline. So a missing file, a missing
 * provider entry, or an invalid URL silently falls back to the built-in
 * default for THAT provider only, and logs a warning. The rest of the
 * registry keeps working.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * WHY THIS FILE IS NEVER WRITTEN BY CODE
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * providers.php is require()'d as executable PHP. If any endpoint could write
 * to it, that endpoint would effectively have arbitrary code execution on the
 * next request. Nothing in this codebase writes to it - only an operator with
 * filesystem access does.
 *
 * @package NomadCMS\Services\Forms
 */

declare(strict_types=1);

namespace NomadCMS\Services\Forms;

final class CaptchaProviderRegistry
{
    public const PROVIDER_NONE = 'none';
    public const PROVIDER_TURNSTILE = 'turnstile';
    public const PROVIDER_RECAPTCHA_V2 = 'recaptcha_v2';
    public const PROVIDER_RECAPTCHA_V3 = 'recaptcha_v3';

    /** @var array<int, string> Every real (non-"none") provider key */
    public const PROVIDERS = [
        self::PROVIDER_TURNSTILE,
        self::PROVIDER_RECAPTCHA_V2,
        self::PROVIDER_RECAPTCHA_V3,
    ];

    /** Literal placeholder substituted with the form's site key in script_url */
    private const SITE_KEY_PLACEHOLDER = '{SITE_KEY}';

    /** @var array<string, array<string, mixed>>|null */
    private static ?array $cache = null;

    /**
     * Built-in fallback, used whenever providers.php is missing or an entry in
     * it is malformed. Kept identical in shape to the shipped providers.php so
     * a fallback and a hand-edited entry are indistinguishable to callers.
     *
     * @return array<string, array<string, mixed>>
     */
    private static function defaults(): array
    {
        return [
            self::PROVIDER_TURNSTILE => [
                'label' => 'Cloudflare Turnstile',
                'verify_url' => 'https://challenges.cloudflare.com/turnstile/v0/siteverify',
                'script_url' => 'https://challenges.cloudflare.com/turnstile/v0/api.js',
                'widget_class' => 'cf-turnstile',
                'token_field' => 'cf-turnstile-response',
                'min_score' => null,
            ],
            self::PROVIDER_RECAPTCHA_V2 => [
                'label' => 'Google reCAPTCHA v2',
                'verify_url' => 'https://www.google.com/recaptcha/api/siteverify',
                'script_url' => 'https://www.google.com/recaptcha/api.js',
                'widget_class' => 'g-recaptcha',
                'token_field' => 'g-recaptcha-response',
                'min_score' => null,
            ],
            self::PROVIDER_RECAPTCHA_V3 => [
                'label' => 'Google reCAPTCHA v3',
                'verify_url' => 'https://www.google.com/recaptcha/api/siteverify',
                'script_url' => 'https://www.google.com/recaptcha/api.js?render={SITE_KEY}',
                'widget_class' => null,
                'token_field' => 'g-recaptcha-response',
                'min_score' => 0.5,
            ],
        ];
    }

    /**
     * Path to the hand-maintained registry file.
     */
    private static function filePath(): string
    {
        return dirname(__DIR__, 3) . '/external/providers/providers.php';
    }

    /**
     * Load, validate and cache the full registry (defaults merged with any
     * valid overrides from providers.php).
     *
     * @return array<string, array<string, mixed>>
     */
    private static function load(): array
    {
        if (self::$cache !== null) {
            return self::$cache;
        }

        $defaults = self::defaults();
        $path = self::filePath();

        if (!is_file($path) || !is_readable($path)) {
            self::warn('providers.php hiányzik vagy nem olvasható, beépített alapértékek használva.');
            self::$cache = $defaults;

            return self::$cache;
        }

        try {
            $raw = require $path;
        } catch (\Throwable $e) {
            self::warn('providers.php betöltése hibát okozott: ' . $e->getMessage());
            self::$cache = $defaults;

            return self::$cache;
        }

        if (!is_array($raw)) {
            self::warn('providers.php nem egy tömböt ad vissza, beépített alapértékek használva.');
            self::$cache = $defaults;

            return self::$cache;
        }

        $resolved = $defaults;
        foreach ($defaults as $provider => $defaultEntry) {
            $candidate = $raw[$provider] ?? null;
            if (!is_array($candidate)) {
                continue;
            }

            $merged = array_merge($defaultEntry, $candidate);

            if (!self::isValidEntry($merged)) {
                self::warn(sprintf(
                    'providers.php: érvénytelen bejegyzés a "%s" providerhez, beépített alapérték marad.',
                    $provider
                ));
                continue;
            }

            $resolved[$provider] = $merged;
        }

        self::$cache = $resolved;

        return self::$cache;
    }

    /**
     * A registry entry is valid when its two URLs are well-formed https:// URLs.
     * The site-key placeholder is allowed inside script_url and is not itself a
     * validity requirement.
     *
     * @param array<string, mixed> $entry
     */
    private static function isValidEntry(array $entry): bool
    {
        foreach (['verify_url', 'script_url'] as $key) {
            $value = $entry[$key] ?? null;
            if (!is_string($value) || $value === '') {
                return false;
            }

            $withoutPlaceholder = str_replace(self::SITE_KEY_PLACEHOLDER, 'x', $value);
            if (filter_var($withoutPlaceholder, FILTER_VALIDATE_URL) === false) {
                return false;
            }
            if (!preg_match('#^https://#i', $withoutPlaceholder)) {
                return false;
            }
        }

        return true;
    }

    /**
     * Full entry for one provider, or null for an unknown/`none` provider.
     *
     * @return array<string, mixed>|null
     */
    public static function get(string $provider): ?array
    {
        $registry = self::load();

        return $registry[$provider] ?? null;
    }

    /**
     * Every provider entry, keyed by provider id.
     *
     * @return array<string, array<string, mixed>>
     */
    public static function all(): array
    {
        return self::load();
    }

    /**
     * The verify_url a secret key is POSTed to for this provider.
     */
    public static function verifyUrl(string $provider): ?string
    {
        return self::stringField($provider, 'verify_url');
    }

    /**
     * The public script URL, with {SITE_KEY} substituted when a site key is
     * given (only recaptcha_v3's URL currently contains the placeholder).
     */
    public static function scriptUrl(string $provider, ?string $siteKey = null): ?string
    {
        $url = self::stringField($provider, 'script_url');
        if ($url === null) {
            return null;
        }

        if ($siteKey !== null && $siteKey !== '') {
            $url = str_replace(self::SITE_KEY_PLACEHOLDER, rawurlencode($siteKey), $url);
        }

        return $url;
    }

    public static function widgetClass(string $provider): ?string
    {
        return self::stringField($provider, 'widget_class');
    }

    public static function tokenField(string $provider): ?string
    {
        return self::stringField($provider, 'token_field');
    }

    public static function label(string $provider): ?string
    {
        return self::stringField($provider, 'label');
    }

    /**
     * Read one string-typed field off a provider entry, or null when absent
     * or not actually a string (defensive - every value here ultimately comes
     * from either the built-in defaults or a hand-edited providers.php entry
     * that already passed isValidEntry(), but a field like `label` is never
     * validated there).
     */
    private static function stringField(string $provider, string $field): ?string
    {
        $value = self::get($provider)[$field] ?? null;

        return is_string($value) && $value !== '' ? $value : null;
    }

    /**
     * Minimum acceptable score (recaptcha_v3 only). Null for providers that
     * do not score (turnstile, recaptcha_v2 are pass/fail).
     */
    public static function minScore(string $provider): ?float
    {
        $value = self::get($provider)['min_score'] ?? null;

        return is_numeric($value) ? (float) $value : null;
    }

    public static function isValidProvider(string $provider): bool
    {
        return $provider === self::PROVIDER_NONE || in_array($provider, self::PROVIDERS, true);
    }

    /**
     * Drop the cached registry. Test-only: providers.php is not expected to
     * change during a normal request lifecycle.
     */
    public static function clearCache(): void
    {
        self::$cache = null;
    }

    private static function warn(string $message): void
    {
        error_log('[Forms][CaptchaProviderRegistry] ' . $message);
    }
}
