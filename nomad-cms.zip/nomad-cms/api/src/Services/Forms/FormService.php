<?php
/**
 * NOMAD CMS - Form Service
 *
 * CRUD for form DEFINITIONS, stored in the `massive_form_definitions` table
 * through the existing MassiveDatabase (see FormsSchema for the storage model).
 * Definition writes use FormDefinitionRepository so user schema migrations cannot archive module metadata.
 *
 * Responsibilities:
 * - slug generation / normalization / uniqueness
 * - settings normalization with hard bounds (rate limit, retention, origins)
 * - field schema validation (delegated to FormValidator)
 * - fail-closed encryption gate: a form can only be marked encrypted while an
 *   encryption key is actually configured
 * - the reduced, PUBLIC projection of a definition (no settings secrets)
 *
 * @package NomadCMS\Services\Forms
 */

declare(strict_types=1);

namespace NomadCMS\Services\Forms;

use NomadCMS\Security\EncryptionService;
use NomadCMS\Security\InputSanitizer;
use PDO;

final class FormService
{
    /** Minimum/maximum slug length */
    private const SLUG_MIN = 3;
    private const SLUG_MAX = 64;

    /** Max number of allowed origins per form */
    private const MAX_ORIGINS = 50;

    /**
     * Max number of notification recipients per form.
     *
     * A hard cap, not a UX suggestion: FormNotifier::sendEmail() sends one
     * MailService::send() call per recipient (no BCC batching), so this also
     * bounds how many SMTP round trips a single submission can trigger.
     */
    private const MAX_NOTIFICATION_EMAILS = 10;

    /**
     * Slugs the admin UI uses as literal route segments.
     *
     * @var array<int, string>
     */
    private const RESERVED_SLUGS = ['storage', 'inbox', 'new', 'edit', 'security'];

    // =========================================================================
    // READ
    // =========================================================================

    /**
     * Find a form definition by slug.
     *
     * @return array{id:int, data:array<string,mixed>, created_at:string, updated_at:string}|null
     */
    public static function findBySlug(string $slug): ?array
    {
        FormsSchema::ensureTables();

        $slug = self::normalizeSlug($slug);
        if ($slug === null) {
            return null;
        }

        $db = FormsSchema::db();
        $stmt = $db->prepare(
            'SELECT id, data, created_at, updated_at
             FROM ' . FormsSchema::TABLE_DEFINITIONS . "
             WHERE json_extract(data, '$.slug') = ?
             LIMIT 1"
        );
        $stmt->execute([$slug]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);

        return $row ? self::hydrate($row) : null;
    }

    /**
     * Find a form definition by its massive row id.
     *
     * @return array{id:int, data:array<string,mixed>, created_at:string, updated_at:string}|null
     */
    public static function findById(int $id): ?array
    {
        FormsSchema::ensureTables();

        $db = FormsSchema::db();
        $stmt = $db->prepare(
            'SELECT id, data, created_at, updated_at
             FROM ' . FormsSchema::TABLE_DEFINITIONS . '
             WHERE id = ? LIMIT 1'
        );
        $stmt->execute([$id]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);

        return $row ? self::hydrate($row) : null;
    }

    /**
     * Same as findBySlug() but throws instead of returning null.
     *
     * @return array{id:int, data:array<string,mixed>, created_at:string, updated_at:string}
     * @throws FormNotFoundException
     */
    public static function requireBySlug(string $slug): array
    {
        $form = self::findBySlug($slug);
        if ($form === null) {
            throw new FormNotFoundException(sprintf('Nincs ilyen űrlap: "%s".', $slug));
        }

        return $form;
    }

    /**
     * List every form definition with submission statistics.
     *
     * @return array<int, array<string, mixed>>
     */
    public static function listAll(): array
    {
        FormsSchema::ensureTables();

        $db = FormsSchema::db();
        $rows = $db->query(
            'SELECT id, data, created_at, updated_at
             FROM ' . FormsSchema::TABLE_DEFINITIONS . '
             ORDER BY id DESC'
        )->fetchAll(PDO::FETCH_ASSOC);

        $stats = self::submissionStats();

        $forms = [];
        foreach ($rows as $row) {
            $form = self::hydrate($row);
            $slug = (string) ($form['data']['slug'] ?? '');
            $form['stats'] = $stats[$slug] ?? self::emptyStats();
            $forms[] = $form;
        }

        return $forms;
    }

    /**
     * Submission counters per form slug, keyed by slug.
     *
     * Works on encrypted forms too: the envelope keeps `form_slug` and `status`
     * in the plaintext part of the JSON precisely so counters and filters stay
     * available without touching any personal data.
     *
     * @return array<string, array<string, int>>
     */
    public static function submissionStats(): array
    {
        FormsSchema::ensureTables();

        $db = FormsSchema::db();
        $rows = $db->query(
            "SELECT json_extract(data, '\$.form_slug') AS slug,
                    json_extract(data, '\$.status')    AS status,
                    COUNT(*) AS cnt
             FROM " . FormsSchema::TABLE_SUBMISSIONS . '
             GROUP BY slug, status'
        )->fetchAll(PDO::FETCH_ASSOC);

        $stats = [];
        foreach ($rows as $row) {
            $slug = (string) ($row['slug'] ?? '');
            $status = (string) ($row['status'] ?? FormsSchema::STATUS_UNREAD);
            $count = (int) $row['cnt'];

            if (!isset($stats[$slug])) {
                $stats[$slug] = self::emptyStats();
            }

            if (array_key_exists($status, $stats[$slug])) {
                $stats[$slug][$status] += $count;
            }
            $stats[$slug]['total'] += $count;
        }

        return $stats;
    }

    // =========================================================================
    // WRITE
    // =========================================================================

    /**
     * Create a new form definition.
     *
     * @param array<string, mixed> $input
     * @return array{id:int, data:array<string,mixed>, created_at:string, updated_at:string}
     * @throws FormValidationException
     */
    public static function create(array $input, ?string $ownerUuid = null): array
    {
        FormsSchema::ensureTables();

        $errors = [];

        $name = FormValidator::sanitizeText($input['name'] ?? null, 200);
        if ($name === null || $name === '') {
            $errors['name'] = 'Az űrlap neve kötelező.';
        }

        $slug = self::normalizeSlug($input['slug'] ?? null);

        // A RESERVED word is reported, not quietly replaced. The fallback below
        // exists for a malformed slug ("Kapcsolat!" -> "kapcsolat"), but silently
        // handing back a different identifier than the admin typed would be a bad
        // surprise: the slug becomes part of the URL embedded in someone else's
        // page.
        if ($slug === null && self::isReservedSlug($input['slug'] ?? null)) {
            $errors['slug'] = sprintf(
                'Ez az azonosító foglalt (az admin felület használja): %s. Válassz mást.',
                implode(', ', self::RESERVED_SLUGS)
            );
        }

        if ($slug === null && $name !== null && $name !== '') {
            $slug = self::normalizeSlug($name);
        }
        if ($slug === null) {
            $errors['slug'] = sprintf(
                'Az azonosító (slug) kötelező: %d-%d karakter, csak kisbetű, szám és kötőjel.',
                self::SLUG_MIN,
                self::SLUG_MAX
            );
        } elseif (self::findBySlug($slug) !== null) {
            $errors['slug'] = sprintf('Ez az azonosító már használatban van: "%s".', $slug);
        }

        if (!empty($errors)) {
            throw new FormValidationException($errors);
        }

        $fields = FormValidator::validateFieldDefinitions($input['fields'] ?? []);
        $settings = self::normalizeSettings($input['settings'] ?? [], null, $fields);

        $now = gmdate('Y-m-d H:i:s');
        $data = [
            'type' => FormsSchema::TYPE_DEFINITION,
            'name' => $name,
            'slug' => $slug,
            'description' => FormValidator::sanitizeText($input['description'] ?? null, 1000),
            'fields' => $fields,
            'settings' => $settings,
            'is_active' => FormValidator::toBool($input['is_active'] ?? true),
            'created_at' => $now,
            'updated_at' => $now,
        ];

        $id = FormDefinitionRepository::insert($data, $ownerUuid);

        return [
            'id' => $id,
            'data' => $data,
            'created_at' => $now,
            'updated_at' => $now,
        ];
    }

    /**
     * Update an existing form definition.
     *
     * The slug may be changed, but callers should warn the user first: the slug
     * is part of the public endpoint URL that is already embedded in third
     * party pages, so changing it silently breaks every live form.
     *
     * @param array<string, mixed> $input
     * @return array{id:int, data:array<string,mixed>, created_at:string, updated_at:string}
     * @throws FormNotFoundException|FormValidationException
     */
    public static function update(string $slug, array $input): array
    {
        $existing = self::requireBySlug($slug);
        $data = $existing['data'];
        $errors = [];

        // The slug the form had on entry, and the new one if it changes. The
        // rename cascade at the end of this method needs both.
        $originalSlug = (string) $existing['data']['slug'];
        $slugChangedTo = null;

        if (array_key_exists('name', $input)) {
            $name = FormValidator::sanitizeText($input['name'], 200);
            if ($name === null || $name === '') {
                $errors['name'] = 'Az űrlap neve kötelező.';
            } else {
                $data['name'] = $name;
            }
        }

        if (array_key_exists('slug', $input)) {
            $newSlug = self::normalizeSlug($input['slug']);
            if ($newSlug === null) {
                // Same distinction as in create(): a reserved word gets its own
                // message, so renaming cannot quietly bypass the restriction
                // either.
                $errors['slug'] = self::isReservedSlug($input['slug'])
                    ? sprintf(
                        'Ez az azonosító foglalt (az admin felület használja): %s. Válassz mást.',
                        implode(', ', self::RESERVED_SLUGS)
                    )
                    : sprintf(
                        'Az azonosító (slug) érvénytelen: %d-%d karakter, csak kisbetű, szám és kötőjel.',
                        self::SLUG_MIN,
                        self::SLUG_MAX
                    );
            } elseif ($newSlug !== $data['slug']) {
                $clash = self::findBySlug($newSlug);
                if ($clash !== null) {
                    $errors['slug'] = sprintf('Ez az azonosító már használatban van: "%s".', $newSlug);
                } else {
                    $data['slug'] = $newSlug;
                    // Remembered so the cascade below can move submissions and
                    // attachments off the old slug after the definition is saved.
                    $slugChangedTo = $newSlug;
                }
            }
        }

        if (array_key_exists('description', $input)) {
            $data['description'] = FormValidator::sanitizeText($input['description'], 1000);
        }

        if (array_key_exists('is_active', $input)) {
            $data['is_active'] = FormValidator::toBool($input['is_active']);
        }

        if (!empty($errors)) {
            throw new FormValidationException($errors);
        }

        if (array_key_exists('fields', $input)) {
            $data['fields'] = FormValidator::validateFieldDefinitions($input['fields']);
        }

        if (array_key_exists('settings', $input)) {
            $data['settings'] = self::normalizeSettings(
                $input['settings'],
                $data['settings'] ?? [],
                $data['fields'] ?? []
            );
        }

        $data['updated_at'] = gmdate('Y-m-d H:i:s');

        FormDefinitionRepository::update($existing['id'], $data);

        // ── Slug rename cascade ─────────────────────────────────────────────
        // Submissions and attachments reference their form by SLUG, so a rename
        // has to move those references too.
        //
        // Verified before this existed: renaming a form left every earlier
        // submission stranded under the old slug - invisible in the form's inbox
        // AND missed by the form's delete cascade, i.e. orphaned personal data
        // that no screen could reach and nobody could erase on request. That is
        // exactly the outcome the delete cascade was written to prevent.
        $renamedSubmissions = 0;
        $renamedFiles = 0;

        if ($slugChangedTo !== null) {
            $renamedSubmissions = FormSubmissionRepository::renameFormSlug($originalSlug, $slugChangedTo);
            $renamedFiles = FormFileRepository::renameForm($originalSlug, $slugChangedTo);

            // The captcha override (if any) lives in api/external/captcha.json,
            // keyed by slug - without this it would be silently orphaned under
            // the old slug (or, worse, appear to protect whatever OTHER form
            // later takes that old slug).
            try {
                CaptchaConfigStore::renameForm($originalSlug, $slugChangedTo);
            } catch (\Throwable $e) {
                error_log('[Forms] Captcha config rename cascade failed for "' . $originalSlug . '" -> "' . $slugChangedTo . '": ' . $e->getMessage());
            }
        }

        return [
            'id' => $existing['id'],
            'data' => $data,
            'created_at' => $existing['created_at'],
            'updated_at' => $data['updated_at'],
            'renamed_submissions' => $renamedSubmissions,
            'renamed_files' => $renamedFiles,
        ];
    }

    /**
     * Delete a form definition AND every submission belonging to it.
     *
     * Deleting the definition but keeping the submissions would leave orphaned
     * personal data that no admin screen can reach (and therefore nobody can
     * erase on request) - the worse outcome under GDPR. Callers must confirm
     * this with the user.
     *
     * @return array{deleted:bool, submissions_deleted:int}
     * @throws FormNotFoundException
     */
    public static function delete(string $slug): array
    {
        $existing = self::requireBySlug($slug);
        $formSlug = (string) $existing['data']['slug'];

        // Attachments first: they are the only part that also lives outside the
        // database. If the definition were removed first and this failed, the
        // files would be unreachable personal data with nothing pointing at them.
        $filesDeleted = FormFileRepository::deleteByForm($formSlug);

        $submissionsDeleted = FormSubmissionRepository::deleteByFormSlug($formSlug);
        $deleted = FormDefinitionRepository::delete($existing['id']);

        // Same GDPR-driven rationale as the submissions/files cascade above:
        // a captcha override left behind under a deleted form's slug is an
        // orphaned config entry no admin screen can reach.
        try {
            CaptchaConfigStore::deleteForm($formSlug);
        } catch (\Throwable $e) {
            error_log('[Forms] Captcha config delete cascade failed for "' . $formSlug . '": ' . $e->getMessage());
        }

        return [
            'deleted' => $deleted,
            'submissions_deleted' => $submissionsDeleted,
            'files_deleted' => $filesDeleted['deleted'],
            'bytes_freed' => $filesDeleted['bytes'],
        ];
    }

    // =========================================================================
    // SETTINGS
    // =========================================================================

    /**
     * Normalize and bound-check a settings payload.
     *
     * @param mixed $input Raw settings from the request
     * @param array<string, mixed>|null $current Existing settings (partial update merge base)
     * @param array<int, array<string, mixed>> $fields Normalized field definitions
     * @return array<string, mixed>
     * @throws FormValidationException
     */
    public static function normalizeSettings(mixed $input, ?array $current = null, array $fields = []): array
    {
        $current = $current ?? [];
        $input = is_array($input) ? $input : [];
        $errors = [];

        $merged = array_merge($current, $input);

        // ── Honeypot ─────────────────────────────────────────────────────────
        $honeypot = FormValidator::normalizeFieldName($merged['honeypot_field_name'] ?? null)
            ?? FormsSchema::DEFAULT_HONEYPOT;

        // A honeypot colliding with a real field would make the form
        // permanently unsubmittable - every legitimate visitor would fill it.
        foreach ($fields as $field) {
            if (($field['name'] ?? null) === $honeypot) {
                $errors['settings.honeypot_field_name'] =
                    'A honeypot mező neve nem egyezhet meg egy valódi mező nevével.';
                break;
            }
        }

        // Default true so every EXISTING form (created before this switch
        // existed) keeps its honeypot active after an upgrade - turning a
        // spam control off must be an explicit decision, never a side effect.
        $honeypotEnabled = FormValidator::toBool($merged['honeypot_enabled'] ?? true);

        // ── Rate limit ───────────────────────────────────────────────────────
        $rateLimit = $merged['rate_limit_per_minute'] ?? FormsSchema::DEFAULT_RATE_LIMIT;
        $rateLimit = is_numeric($rateLimit) ? (int) $rateLimit : FormsSchema::DEFAULT_RATE_LIMIT;
        $rateLimit = max(FormsSchema::MIN_RATE_LIMIT, min(FormsSchema::MAX_RATE_LIMIT, $rateLimit));

        // ── Redirect URL ─────────────────────────────────────────────────────
        $redirectUrl = null;
        $rawRedirect = $merged['redirect_url'] ?? null;
        if (is_string($rawRedirect) && trim($rawRedirect) !== '') {
            $candidate = trim($rawRedirect);
            if (filter_var($candidate, FILTER_VALIDATE_URL) === false || !preg_match('#^https?://#i', $candidate)) {
                $errors['settings.redirect_url'] = 'Az átirányítási URL csak érvényes http/https cím lehet.';
            } elseif (strlen($candidate) > 2000) {
                $errors['settings.redirect_url'] = 'Az átirányítási URL túl hosszú.';
            } else {
                $redirectUrl = $candidate;
            }
        }

        // ── Notification (recipients + optional SMTP profile) ──────────────────
        $notification = self::normalizeNotificationSettings($merged['notification'] ?? null, $errors);

        // ── Allowed origins ──────────────────────────────────────────────────
        $allowedOrigins = [];
        $rawOrigins = $merged['allowed_origins'] ?? [];
        if (is_string($rawOrigins)) {
            $rawOrigins = array_map('trim', explode(',', $rawOrigins));
        }
        if (is_array($rawOrigins)) {
            foreach ($rawOrigins as $origin) {
                if (!is_string($origin)) {
                    continue;
                }
                $origin = trim($origin);
                if ($origin === '') {
                    continue;
                }
                $normalizedOrigin = self::normalizeOrigin($origin);
                if ($normalizedOrigin === null) {
                    $errors['settings.allowed_origins'] =
                        sprintf('Érvénytelen origin: "%s". Elvárt formátum: https://example.com', $origin);
                    break;
                }
                if (!in_array($normalizedOrigin, $allowedOrigins, true)) {
                    $allowedOrigins[] = $normalizedOrigin;
                }
            }
            if (count($allowedOrigins) > self::MAX_ORIGINS) {
                $errors['settings.allowed_origins'] = sprintf('Legfeljebb %d origin adható meg.', self::MAX_ORIGINS);
            }
        }

        // ── Retention ────────────────────────────────────────────────────────
        $retentionDays = null;
        $rawRetention = $merged['retention_days'] ?? null;
        if ($rawRetention !== null && $rawRetention !== '') {
            if (!is_numeric($rawRetention)) {
                $errors['settings.retention_days'] = 'A megőrzési idő csak szám lehet (nap).';
            } else {
                $retentionDays = (int) $rawRetention;
                if ($retentionDays < FormsSchema::MIN_RETENTION_DAYS || $retentionDays > FormsSchema::MAX_RETENTION_DAYS) {
                    $errors['settings.retention_days'] = sprintf(
                        'A megőrzési idő %d és %d nap között lehet (vagy üres a korlátlan megőrzéshez).',
                        FormsSchema::MIN_RETENTION_DAYS,
                        FormsSchema::MAX_RETENTION_DAYS
                    );
                }
            }
        }

        // ── Encryption (fail-closed) ─────────────────────────────────────────
        $rawEncryption = $merged['encryption'] ?? [];
        if (is_bool($rawEncryption)) {
            $rawEncryption = ['enabled' => $rawEncryption];
        }
        $rawEncryption = is_array($rawEncryption) ? $rawEncryption : [];
        $encryptionEnabled = FormValidator::toBool($rawEncryption['enabled'] ?? false);

        if ($encryptionEnabled && !EncryptionService::isConfigured()) {
            // Refuse rather than accept a setting we cannot honour: accepting it
            // would mean the next submission is either lost (503) or, far worse,
            // silently stored as plaintext.
            $errors['settings.encryption'] =
                'A titkosítás nem kapcsolható be: nincs beállítva ENCRYPTION_KEY a szerveren.';
        }

        // ── Uploads ──────────────────────────────────────────────────────────
        $uploads = self::normalizeUploadSettings(
            $merged['uploads'] ?? null,
            $encryptionEnabled,
            $errors
        );

        // A file field with uploads switched off is a contradiction the visitor
        // would discover the hard way: the form renders a file input and the
        // endpoint then rejects the upload with 415. Reported here instead.
        $fileFields = FormValidator::fileFieldNames($fields);
        if (!empty($fileFields) && ($uploads['enabled'] ?? false) !== true) {
            $errors['settings.uploads'] = sprintf(
                'Az űrlapon fájl típusú mező van (%s), ezért a fájlfeltöltést be kell kapcsolni.',
                implode(', ', $fileFields)
            );
        }

        // ── Proof-of-Work (stateless time-bucket) ───────────────────────────
        // Default true so every form (new or pre-dating this feature) gets this
        // zero-dependency layer unless an admin explicitly turns it off - the
        // same "secure by default" stance the honeypot switch above takes.
        $rawPow = $merged['pow'] ?? [];
        $rawPow = is_array($rawPow) ? $rawPow : [];
        $powEnabled = FormValidator::toBool($rawPow['enabled'] ?? true);

        $powDifficulty = $rawPow['difficulty'] ?? FormPowGuard::DEFAULT_DIFFICULTY;
        $powDifficulty = is_string($powDifficulty) ? $powDifficulty : FormPowGuard::DEFAULT_DIFFICULTY;
        if (!FormPowGuard::isValidDifficulty($powDifficulty)) {
            $errors['settings.pow.difficulty'] = sprintf(
                'Érvénytelen nehézségi szint. Elfogadott értékek: %s.',
                implode(', ', FormPowGuard::difficultyLevels())
            );
            $powDifficulty = FormPowGuard::DEFAULT_DIFFICULTY;
        }

        if (!empty($errors)) {
            throw new FormValidationException($errors, 'Az űrlap beállításai érvénytelenek.');
        }

        return [
            'honeypot_field_name' => $honeypot,
            'honeypot_enabled' => $honeypotEnabled,
            'rate_limit_per_minute' => $rateLimit,
            'redirect_url' => $redirectUrl,
            'notification' => $notification,
            'allowed_origins' => $allowedOrigins,
            'strict_schema' => FormValidator::toBool($merged['strict_schema'] ?? false),
            'retention_days' => $retentionDays,
            'encryption' => [
                'enabled' => $encryptionEnabled,
                'version' => FormsSchema::ENC_VERSION,
            ],
            'uploads' => $uploads,
            'pow' => [
                'enabled' => $powEnabled,
                'difficulty' => $powDifficulty,
            ],
        ];
    }

    /**
     * Validate and normalise settings.notification.
     *
     * Replaces the old single `notification_email` string with a recipient
     * LIST plus an optional SMTP profile choice - this is the surface
     * FormNotifier::sendEmail() reads at submission time.
     *
     * `mail_profile_uuid` is only shape-checked here (a UUID-looking string, or
     * null). Whether that profile still exists and is still `verified` is
     * deliberately re-checked at SEND time, not here: a profile that was
     * verified when the form was saved can be edited, disabled or deleted
     * afterwards, and the form definition must not need re-saving just because
     * the mail subsystem's state moved on.
     *
     * @param mixed $input Raw settings.notification block from the request
     * @param array<string, string> $errors Collected by reference, same as the caller
     * @return array{emails: array<int, string>, mail_profile_uuid: string|null, in_app: bool}
     */
    private static function normalizeNotificationSettings(mixed $input, array &$errors): array
    {
        if (is_bool($input)) {
            // Tolerate legacy/hand-crafted payloads that pass a bare boolean;
            // there is nothing sensible to do with it except treat it as
            // "no notification configured".
            $input = [];
        }
        $input = is_array($input) ? $input : [];

        $inApp = $input['in_app'] ?? false;
        if (!is_bool($inApp)) {
            $errors['settings.notification.in_app'] = 'A belső értesítés beállítása logikai érték kell legyen.';
            $inApp = false;
        }

        // ---- emails ---------------------------------------------------------
        $rawEmails = $input['emails'] ?? [];
        if (is_string($rawEmails)) {
            // Accept a comma-separated string too - the tag input posts an
            // array, but a hand-crafted API call may not.
            $rawEmails = array_map('trim', explode(',', $rawEmails));
        }

        $emails = [];
        if (is_array($rawEmails)) {
            foreach ($rawEmails as $rawEmail) {
                if (!is_string($rawEmail)) {
                    continue;
                }
                $rawEmail = trim($rawEmail);
                if ($rawEmail === '') {
                    continue;
                }

                $clean = InputSanitizer::email($rawEmail);
                if ($clean === null) {
                    $errors['settings.notification.emails'] =
                        sprintf('Érvénytelen e-mail cím: "%s".', $rawEmail);
                    break;
                }

                if (!in_array($clean, $emails, true)) {
                    $emails[] = $clean;
                }
            }
        } else {
            $errors['settings.notification.emails'] = 'Az értesítési e-mail címek listája érvénytelen formátumú.';
        }

        if (count($emails) > self::MAX_NOTIFICATION_EMAILS) {
            $errors['settings.notification.emails'] = sprintf(
                'Legfeljebb %d értesítési e-mail cím adható meg.',
                self::MAX_NOTIFICATION_EMAILS
            );
        }

        // ---- mail_profile_uuid ------------------------------------------------
        $mailProfileUuid = null;
        $rawUuid = $input['mail_profile_uuid'] ?? null;
        if (is_string($rawUuid) && trim($rawUuid) !== '') {
            $candidate = trim($rawUuid);
            if (preg_match('/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i', $candidate) !== 1) {
                $errors['settings.notification.mail_profile_uuid'] = 'A levelezési profil azonosítója érvénytelen.';
            } else {
                $mailProfileUuid = strtolower($candidate);
            }
        }

        return [
            'in_app' => $inApp,
            'emails' => $emails,
            'mail_profile_uuid' => $mailProfileUuid,
        ];
    }

    /**
     * Validate and normalise settings.uploads.
     *
     * Turning a public endpoint into a place strangers can put files on your disk
     * is the single riskiest switch in this module, so every value is clamped and
     * the type list is intersected with the backend whitelist rather than trusted.
     *
     * @param mixed $input Raw uploads settings from the request
     * @param bool $encryptionEnabled Whether the form encrypts its data
     * @param array<string, string> $errors Collected by reference, same as the caller
     * @return array<string, mixed>
     */
    private static function normalizeUploadSettings(
        mixed $input,
        bool $encryptionEnabled,
        array &$errors
    ): array {
        $defaults = FormsSchema::defaultUploadSettings();

        // Absent block = keep uploads off. Every form that existed before this
        // feature shipped must stay closed until someone opts in explicitly.
        if ($input === null) {
            return $defaults;
        }

        // Allow `uploads: true` as shorthand for "on with defaults".
        if (is_bool($input)) {
            $input = ['enabled' => $input];
        }

        if (!is_array($input)) {
            $errors['settings.uploads'] = 'A feltöltési beállítások formátuma érvénytelen.';
            return $defaults;
        }

        $enabled = FormValidator::toBool($input['enabled'] ?? false);

        // An encrypted form encrypts its attachments too, so uploads cannot be
        // enabled without a key - the same fail-closed rule as the values.
        if ($enabled && $encryptionEnabled && !EncryptionService::isConfigured()) {
            $errors['settings.uploads'] =
                'Titkosított űrlapon a fájlfeltöltés nem kapcsolható be ENCRYPTION_KEY nélkül.';
        }

        // ── Allowed types ────────────────────────────────────────────────────
        $rawTypes = $input['allowed_types'] ?? null;
        $allowedTypes = $defaults['allowed_types'];

        if ($rawTypes !== null) {
            if (!is_array($rawTypes)) {
                $errors['settings.uploads.allowed_types'] = 'Az engedélyezett típusok listája tömb kell legyen.';
            } else {
                $accepted = [];
                $unknown = [];

                foreach ($rawTypes as $type) {
                    if (!is_string($type)) {
                        continue;
                    }
                    $normalised = strtolower(ltrim(trim($type), '.'));
                    if ($normalised === '') {
                        continue;
                    }

                    if (isset(FormsSchema::UPLOAD_TYPE_WHITELIST[$normalised])) {
                        $accepted[$normalised] = true;
                    } else {
                        $unknown[] = $normalised;
                    }
                }

                // Reject loudly instead of silently dropping: an admin who typed
                // "svg" needs to learn it is not permitted, not to discover later
                // that uploads mysteriously bounce.
                if (!empty($unknown)) {
                    $errors['settings.uploads.allowed_types'] = sprintf(
                        'Nem engedélyezett fájltípus(ok): %s. Választható: %s',
                        implode(', ', array_unique($unknown)),
                        implode(', ', array_keys(FormsSchema::UPLOAD_TYPE_WHITELIST))
                    );
                } elseif (empty($accepted) && $enabled) {
                    $errors['settings.uploads.allowed_types'] =
                        'Legalább egy fájltípust engedélyezni kell, ha a feltöltés be van kapcsolva.';
                } else {
                    $allowedTypes = array_keys($accepted);
                }
            }
        }

        // ── Numeric ceilings ────────────────────────────────────────────────
        $maxFiles = self::clampSetting(
            $input['max_files'] ?? null,
            $defaults['max_files'],
            1,
            FormsSchema::MAX_MAX_FILES,
            'settings.uploads.max_files',
            sprintf('A fájlok száma 1 és %d között lehet.', FormsSchema::MAX_MAX_FILES),
            $errors
        );

        $maxTotalBytes = self::clampSetting(
            $input['max_total_bytes'] ?? null,
            $defaults['max_total_bytes'],
            1024,
            FormsSchema::MAX_UPLOAD_TOTAL_BYTES,
            'settings.uploads.max_total_bytes',
            sprintf(
                'A beküldésenkénti összméret legfeljebb %s lehet.',
                FormFileValidator::formatBytes(FormsSchema::MAX_UPLOAD_TOTAL_BYTES)
            ),
            $errors
        );

        $quotaBytes = self::clampSetting(
            $input['quota_bytes'] ?? null,
            $defaults['quota_bytes'],
            $maxTotalBytes,
            FormsSchema::MAX_FORM_QUOTA_BYTES,
            'settings.uploads.quota_bytes',
            sprintf(
                'Az űrlap tárhelye a beküldésenkénti összméret (%s) és %s között lehet.',
                FormFileValidator::formatBytes($maxTotalBytes),
                FormFileValidator::formatBytes(FormsSchema::MAX_FORM_QUOTA_BYTES)
            ),
            $errors
        );

        return [
            'enabled' => $enabled,
            'allowed_types' => $allowedTypes,
            'max_files' => $maxFiles,
            'max_total_bytes' => $maxTotalBytes,
            'quota_bytes' => $quotaBytes,
        ];
    }

    /**
     * Validate one numeric setting, recording an error when it is out of range.
     *
     * Out-of-range values are REJECTED, not silently clamped: an admin who typed
     * 500 MB per submission should be told it is not allowed, rather than having
     * it quietly become 5 MB and wondering why large uploads fail.
     *
     * @param array<string, string> $errors
     */
    private static function clampSetting(
        mixed $value,
        int $default,
        int $min,
        int $max,
        string $errorKey,
        string $errorMessage,
        array &$errors
    ): int {
        if ($value === null || $value === '') {
            return $default;
        }

        if (!is_numeric($value)) {
            $errors[$errorKey] = $errorMessage;
            return $default;
        }

        $int = (int) $value;

        if ($int < $min || $int > $max) {
            $errors[$errorKey] = $errorMessage;
            return $default;
        }

        return $int;
    }

    // =========================================================================
    // PROJECTIONS & ACCESSORS
    // =========================================================================

    /**
     * Reduced projection safe to expose on the PUBLIC endpoint.
     *
     * Deliberately omits: notification (recipients + mail profile), allowed_origins, retention_days,
     * rate limit, the encryption block and the per-field `searchable`/`pii`
     * flags. None of those are needed to render a form, and each of them tells
     * an attacker something about the deployment.
     *
     * @param array<string, mixed> $form Hydrated definition (['id'=>..,'data'=>..])
     * @return array<string, mixed>
     */
    public static function publicSchema(array $form): array
    {
        $data = $form['data'] ?? [];
        $fields = is_array($data['fields'] ?? null) ? $data['fields'] : [];

        $publicFields = [];
        foreach ($fields as $field) {
            $publicFields[] = [
                'name' => $field['name'] ?? '',
                'label' => $field['label'] ?? ($field['name'] ?? ''),
                'type' => $field['type'] ?? 'text',
                'required' => (bool) ($field['required'] ?? false),
                'placeholder' => $field['placeholder'] ?? null,
                'help_text' => $field['help_text'] ?? null,
                'min_length' => $field['min_length'] ?? null,
                'max_length' => $field['max_length'] ?? null,
                'min' => $field['min'] ?? null,
                'max' => $field['max'] ?? null,
                'pattern' => $field['pattern'] ?? null,
                'options' => $field['options'] ?? null,
            ];
        }

        return [
            'name' => $data['name'] ?? '',
            'slug' => $data['slug'] ?? '',
            'description' => $data['description'] ?? null,
            'fields' => $publicFields,
            'honeypot_field' => self::honeypotField($form),
            'strict_schema' => (bool) ($data['settings']['strict_schema'] ?? false),
            // Uploads: a client building the form dynamically needs to know
            // whether to render a file input, which types to accept and the size
            // budget, so it can validate before wasting a round trip.
            // The QUOTA is deliberately not exposed - how full our disk is, is
            // nobody else's business.
            'uploads' => self::publicUploadSchema($form),
            // Captcha: a dynamically-built client needs to know which widget
            // (if any) to render and where its script comes from. NEVER
            // includes a secret - resolveForForm() returns one, but it is
            // deliberately not touched here.
            'captcha' => self::publicCaptchaSchema($form),
            // Proof-of-Work: a client-side solver needs the difficulty (to know
            // how many leading zero bits to search for) and the bucket window
            // size (to derive its own bucket index from its own clock) - see
            // FormPowGuard and SDK/nomad.tsx's solveFormPow(). Never a secret:
            // there IS no server secret in this scheme, the challenge's cost is
            // purely computational.
            'pow' => self::publicPowSchema($form),
        ];
    }

    /**
     * Proof-of-Work parameters safe (and necessary) to expose publicly: whether
     * the check is active, how many leading zero bits are required, and the
     * bucket window size in seconds. None of this is a secret - the scheme's
     * strength comes from CPU cost, not from withholding these numbers.
     *
     * Also exposes the Tier 2 (GPU-resistant memory-hard scratchpad) parameters
     * for this difficulty - memory size, walk steps and bit threshold - so the
     * client-side adaptive solver (SDK/nomad.tsx) never has to hardcode values
     * that must stay in lockstep with FormPowGuard's server-side constants.
     * Exposing the memory size is not a security concern: the scheme's
     * strength is the mandatory scratchpad walk itself, not secrecy about its
     * size (identical rationale to Tier 1's bit count already being public).
     *
     * @param array<string, mixed> $form
     * @return array<string, mixed>
     */
    public static function publicPowSchema(array $form): array
    {
        if (!self::powEnabled($form)) {
            return ['enabled' => false];
        }

        $difficulty = self::powDifficulty($form);

        return [
            'enabled' => true,
            'difficulty' => $difficulty,
            'bucket_seconds' => FormPowGuard::BUCKET_SECONDS,
            'tier2' => [
                'memory_bytes' => FormPowGuard::tier2MemoryBytes($difficulty),
                'bits' => FormPowGuard::tier2DifficultyBits($difficulty),
                'walk_steps' => FormPowGuard::tier2WalkSteps(),
            ],
        ];
    }

    /**
     * Captcha widget info safe to expose publicly: which provider (if any),
     * its site key (public by design), and the markup/script details needed
     * to render the widget without hardcoding provider URLs client-side.
     *
     * Deliberately excludes the secret key - CaptchaConfigStore::resolveForForm()
     * returns one for server-side verification, but it never crosses this
     * boundary.
     *
     * @param array<string, mixed> $form
     * @return array<string, mixed>
     */
    public static function publicCaptchaSchema(array $form): array
    {
        $resolved = CaptchaConfigStore::resolveForForm($form);
        $provider = $resolved['provider'];

        if ($provider === 'none' || $resolved['site_key'] === null) {
            return ['provider' => 'none'];
        }

        return [
            'provider' => $provider,
            'site_key' => $resolved['site_key'],
            'script_url' => CaptchaProviderRegistry::scriptUrl($provider, $resolved['site_key']),
            'widget_class' => CaptchaProviderRegistry::widgetClass($provider),
            'token_field' => CaptchaProviderRegistry::tokenField($provider),
        ];
    }

    /**
     * Upload capabilities as advertised to an anonymous client.
     *
     * @param array<string, mixed> $form
     * @return array<string, mixed>
     */
    public static function publicUploadSchema(array $form): array
    {
        $uploads = self::uploadSettings($form);

        if (($uploads['enabled'] ?? false) !== true) {
            return ['enabled' => false];
        }

        $allowed = FormFileValidator::resolveAllowedTypes($uploads);

        return [
            'enabled' => true,
            'allowed_types' => $allowed,
            // Ready to drop straight into an <input accept="...">
            'accept' => implode(',', array_map(static fn(string $ext) => '.' . $ext, $allowed)),
            'max_files' => (int) ($uploads['max_files'] ?? FormsSchema::DEFAULT_MAX_FILES),
            'max_total_bytes' => (int) ($uploads['max_total_bytes'] ?? FormsSchema::MAX_UPLOAD_TOTAL_BYTES),
            // A file field forces multipart; a JSON POST cannot carry files.
            'encoding' => 'multipart/form-data',
        ];
    }

    /**
     * Resolved upload settings for a form, with defaults filled in.
     *
     * Forms created before this feature existed have no uploads block; they get
     * the defaults, which have enabled=false.
     *
     * @param array<string, mixed> $form
     * @return array<string, mixed>
     */
    public static function uploadSettings(array $form): array
    {
        $raw = $form['data']['settings']['uploads'] ?? null;

        if (!is_array($raw)) {
            return FormsSchema::defaultUploadSettings();
        }

        return array_merge(FormsSchema::defaultUploadSettings(), $raw);
    }

    /**
     * Whether this form accepts file uploads at all.
     *
     * @param array<string, mixed> $form
     */
    public static function acceptsUploads(array $form): bool
    {
        return (self::uploadSettings($form)['enabled'] ?? false) === true;
    }

    /**
     * @param array<string, mixed> $form
     */
    public static function isEncrypted(array $form): bool
    {
        return (bool) ($form['data']['settings']['encryption']['enabled'] ?? false);
    }

    /**
     * Whether this form rejects submissions containing keys outside its own
     * field definitions.
     *
     * Used beyond validation itself: FormNotifier::buildWebhookPayload() only
     * ever includes submitted VALUES in a webhook payload when this is true
     * (and the form is not encrypted) - a non-strict form accepts arbitrary
     * extra keys from the visitor, so its "schema" is not something an admin
     * can review and knowingly expose to a third-party endpoint.
     *
     * @param array<string, mixed> $form
     */
    public static function isStrictSchema(array $form): bool
    {
        return (bool) ($form['data']['settings']['strict_schema'] ?? false);
    }

    /**
     * @param array<string, mixed> $form
     */
    public static function isActive(array $form): bool
    {
        return (bool) ($form['data']['is_active'] ?? true);
    }

    /**
     * @param array<string, mixed> $form
     */
    public static function honeypotField(array $form): string
    {
        $name = $form['data']['settings']['honeypot_field_name'] ?? null;

        return is_string($name) && $name !== '' ? $name : FormsSchema::DEFAULT_HONEYPOT;
    }

    /**
     * Whether the honeypot check itself is active for this form. Independent
     * of the field NAME (honeypotField() above) so a form can keep its trap
     * field configured while temporarily disabling the check.
     *
     * @param array<string, mixed> $form
     */
    public static function honeypotEnabled(array $form): bool
    {
        return (bool) ($form['data']['settings']['honeypot_enabled'] ?? true);
    }

    /**
     * Whether the stateless time-bucket Proof-of-Work check is active for this
     * form. Defaults to true so every form (new, or pre-dating this feature)
     * gets the zero-dependency layer unless an admin explicitly disables it.
     *
     * @param array<string, mixed> $form
     */
    public static function powEnabled(array $form): bool
    {
        return (bool) ($form['data']['settings']['pow']['enabled'] ?? true);
    }

    /**
     * Configured PoW difficulty label ('low'|'medium'|'high'). Falls back to
     * the default for a form saved before this setting existed, or for a
     * stored value that somehow became invalid (defensive - normalizeSettings()
     * already rejects invalid values at save time).
     *
     * @param array<string, mixed> $form
     */
    public static function powDifficulty(array $form): string
    {
        $difficulty = $form['data']['settings']['pow']['difficulty'] ?? FormPowGuard::DEFAULT_DIFFICULTY;

        return is_string($difficulty) && FormPowGuard::isValidDifficulty($difficulty)
            ? $difficulty
            : FormPowGuard::DEFAULT_DIFFICULTY;
    }

    /**
     * @param array<string, mixed> $form
     */
    public static function rateLimitPerMinute(array $form): int
    {
        $limit = $form['data']['settings']['rate_limit_per_minute'] ?? FormsSchema::DEFAULT_RATE_LIMIT;

        return is_numeric($limit) ? (int) $limit : FormsSchema::DEFAULT_RATE_LIMIT;
    }

    /**
     * @param array<string, mixed> $form
     * @return array<int, string>
     */
    public static function allowedOrigins(array $form): array
    {
        $origins = $form['data']['settings']['allowed_origins'] ?? [];

        return is_array($origins) ? array_values(array_filter($origins, 'is_string')) : [];
    }

    /**
     * @param array<string, mixed> $form
     */
    public static function retentionDays(array $form): ?int
    {
        $days = $form['data']['settings']['retention_days'] ?? null;

        return is_numeric($days) ? (int) $days : null;
    }

    /**
     * Field names opted into blind indexing.
     *
     * @param array<string, mixed> $form
     * @return array<int, string>
     */
    public static function searchableFields(array $form): array
    {
        $fields = $form['data']['fields'] ?? [];
        if (!is_array($fields)) {
            return [];
        }

        $names = [];
        foreach ($fields as $field) {
            if (!empty($field['searchable']) && !empty($field['name'])) {
                $names[] = (string) $field['name'];
            }
        }

        return $names;
    }

    /**
     * Declared field names, in schema order.
     *
     * @param array<string, mixed> $form
     * @return array<int, string>
     */
    public static function fieldNames(array $form): array
    {
        $fields = $form['data']['fields'] ?? [];
        if (!is_array($fields)) {
            return [];
        }

        $names = [];
        foreach ($fields as $field) {
            if (!empty($field['name'])) {
                $names[] = (string) $field['name'];
            }
        }

        return $names;
    }

    /**
     * @param array<string, mixed> $form
     * @return array<int, array<string, mixed>>
     */
    public static function fields(array $form): array
    {
        $fields = $form['data']['fields'] ?? [];

        return is_array($fields) ? $fields : [];
    }

    // =========================================================================
    // HELPERS
    // =========================================================================

    /**
     * Normalize a slug, or null when it cannot be made valid.
     */
    public static function normalizeSlug(mixed $slug): ?string
    {
        if (!is_string($slug)) {
            return null;
        }

        $clean = InputSanitizer::slug($slug, self::SLUG_MAX);
        if ($clean === null || strlen($clean) < self::SLUG_MIN) {
            return null;
        }

        // Must start with an alphanumeric so it never looks like a flag/param
        if (!preg_match('/^[a-z0-9][a-z0-9\-]*$/', $clean)) {
            return null;
        }

        // Reserved words used as literal segments by the admin UI routes
        // (/forms/storage, /forms/inbox). React Router matches a static segment
        // before a dynamic one, so a form actually named "storage" would be
        // unreachable by its own deep link - a confusing failure that is much
        // easier to prevent here than to diagnose later.
        if (in_array($clean, self::RESERVED_SLUGS, true)) {
            return null;
        }

        return $clean;
    }

    /**
     * Whether the requested slug is a reserved word.
     *
     * Separate from normalizeSlug() so callers can tell "reserved" apart from
     * "malformed" and report the former instead of silently substituting.
     */
    public static function isReservedSlug(mixed $slug): bool
    {
        if (!is_string($slug)) {
            return false;
        }

        $clean = InputSanitizer::slug($slug, self::SLUG_MAX);

        return $clean !== null && in_array($clean, self::RESERVED_SLUGS, true);
    }

    /**
     * Normalize an origin to scheme://host[:port], or null when invalid.
     */
    public static function normalizeOrigin(string $origin): ?string
    {
        $origin = trim($origin);
        if ($origin === '' || strlen($origin) > 255) {
            return null;
        }

        $parts = parse_url($origin);
        if ($parts === false || empty($parts['scheme']) || empty($parts['host'])) {
            return null;
        }

        $scheme = strtolower($parts['scheme']);
        if (!in_array($scheme, ['http', 'https'], true)) {
            return null;
        }

        $normalized = $scheme . '://' . strtolower($parts['host']);
        if (!empty($parts['port'])) {
            $normalized .= ':' . $parts['port'];
        }

        return $normalized;
    }

    /**
     * @param array<string, mixed> $row
     * @return array{id:int, data:array<string,mixed>, created_at:string, updated_at:string}
     */
    private static function hydrate(array $row): array
    {
        $data = json_decode((string) $row['data'], true);

        return [
            'id' => (int) $row['id'],
            'data' => is_array($data) ? $data : [],
            'created_at' => (string) ($row['created_at'] ?? ''),
            'updated_at' => (string) ($row['updated_at'] ?? ''),
        ];
    }

    /**
     * @return array<string, int>
     */
    private static function emptyStats(): array
    {
        return [
            FormsSchema::STATUS_UNREAD => 0,
            FormsSchema::STATUS_READ => 0,
            FormsSchema::STATUS_ARCHIVED => 0,
            FormsSchema::STATUS_SPAM => 0,
            'total' => 0,
        ];
    }
}
