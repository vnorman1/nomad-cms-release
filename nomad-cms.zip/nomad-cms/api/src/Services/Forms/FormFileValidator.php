<?php
/**
 * NOMAD CMS - Form File Validator
 *
 * Decides whether a file an ANONYMOUS visitor pushed at a public endpoint is
 * allowed to land on our disk. Everything here treats its input as hostile.
 *
 * THE RULES, AND WHY EACH ONE EXISTS:
 *
 * 1. The per-form allowlist is INTERSECTED with FormsSchema::UPLOAD_TYPE_WHITELIST,
 *    never trusted on its own. A form definition is data; if it were ever edited
 *    by someone who should not have, or hand-crafted, it must still not be able
 *    to widen what the server accepts.
 *
 * 2. The extension AND the sniffed MIME must agree. $_FILES['type'] is supplied
 *    by the client and is ignored entirely - it is a hint, not evidence. finfo
 *    reads the actual bytes. A "cv.pdf" whose content sniffs as text/html is the
 *    classic stored-XSS delivery and is rejected here.
 *
 * 3. Size is capped for the SUBMISSION, not per file. A per-file limit alone
 *    lets five 5 MB files through.
 *
 * 4. Filenames are only ever used for display and download. The stored name is a
 *    UUID (see FormFileStorage), so a hostile filename cannot influence any
 *    path. It is still sanitised, because it ends up in a Content-Disposition
 *    header and in the admin UI.
 *
 * 5. No image is opened, resized or re-encoded. Handing attacker-controlled
 *    bytes to GD/ImageMagick is a well-trodden RCE path, and a thumbnail is not
 *    worth it.
 *
 * @package NomadCMS\Services\Forms
 */

declare(strict_types=1);

namespace NomadCMS\Services\Forms;

require_once __DIR__ . '/FormsSchema.php';
require_once __DIR__ . '/FormFileException.php';

final class FormFileValidator
{
    /**
     * Characters that never belong in a stored display name.
     *
     * Control characters, path separators and the Windows-reserved set. A
     * filename like "..\\..\\boot.ini" cannot reach the filesystem (UUID names),
     * but it can still confuse an admin reading the library.
     */
    private const UNSAFE_NAME_CHARS = '/[\x00-\x1f\x7f\/\\\\:\*\?"<>\|]/';

    /**
     * Normalise PHP's $_FILES into a flat list, whatever shape it arrived in.
     *
     * A form can send `attachment` (single), `attachment[]` (array) or several
     * differently named inputs; PHP represents each differently. Everything
     * downstream expects one flat list.
     *
     * @param array<string, mixed> $files Raw $_FILES
     * @return array<int, array{field:string, name:string, tmp_name:string, size:int, error:int}>
     */
    public static function flatten(array $files): array
    {
        $flat = [];

        foreach ($files as $field => $entry) {
            if (!is_array($entry) || !isset($entry['name'])) {
                continue;
            }

            if (is_array($entry['name'])) {
                // attachment[] style
                foreach (array_keys($entry['name']) as $index) {
                    $flat[] = [
                        'field' => (string) $field,
                        'name' => (string) ($entry['name'][$index] ?? ''),
                        'tmp_name' => (string) ($entry['tmp_name'][$index] ?? ''),
                        'size' => (int) ($entry['size'][$index] ?? 0),
                        'error' => (int) ($entry['error'][$index] ?? UPLOAD_ERR_NO_FILE),
                    ];
                }
                continue;
            }

            $flat[] = [
                'field' => (string) $field,
                'name' => (string) $entry['name'],
                'tmp_name' => (string) ($entry['tmp_name'] ?? ''),
                'size' => (int) ($entry['size'] ?? 0),
                'error' => (int) ($entry['error'] ?? UPLOAD_ERR_NO_FILE),
            ];
        }

        // UPLOAD_ERR_NO_FILE means the input was present but left empty - an
        // empty optional file field is not an error, so drop those silently.
        return array_values(array_filter(
            $flat,
            static fn(array $f) => $f['error'] !== UPLOAD_ERR_NO_FILE || $f['name'] !== ''
        ));
    }

    /**
     * Validate every uploaded file against a form's settings.
     *
     * @param array<int, array{field:string, name:string, tmp_name:string, size:int, error:int}> $files
     * @param array<string, mixed> $uploadSettings Resolved settings.uploads
     * @param int $alreadyUsedBytes Bytes the form already stores (quota input)
     * @return array<int, array{
     *     field:string, original_name:string, extension:string, mime_type:string,
     *     size:int, tmp_name:string
     * }>
     * @throws FormFileException
     */
    public static function validate(
        array $files,
        array $uploadSettings,
        int $alreadyUsedBytes = 0
    ): array {
        if (empty($files)) {
            return [];
        }

        if (($uploadSettings['enabled'] ?? false) !== true) {
            throw FormFileException::uploadsDisabled();
        }

        $maxFiles = self::intSetting($uploadSettings, 'max_files', FormsSchema::DEFAULT_MAX_FILES);
        $maxTotal = self::intSetting($uploadSettings, 'max_total_bytes', FormsSchema::MAX_UPLOAD_TOTAL_BYTES);
        $quota = self::intSetting($uploadSettings, 'quota_bytes', FormsSchema::DEFAULT_FORM_QUOTA_BYTES);
        $allowed = self::resolveAllowedTypes($uploadSettings);

        if (count($files) > $maxFiles) {
            throw FormFileException::rejected(
                sprintf('Legfeljebb %d fájl csatolható (%d érkezett).', $maxFiles, count($files)),
                ['files' => sprintf('Legfeljebb %d fájl csatolható.', $maxFiles)]
            );
        }

        $validated = [];
        $totalBytes = 0;
        $errors = [];

        foreach ($files as $index => $file) {
            $label = $file['name'] !== '' ? $file['name'] : ('#' . ($index + 1));

            // ── PHP-level upload errors first ────────────────────────────────
            if ($file['error'] !== UPLOAD_ERR_OK) {
                $message = self::describeUploadError($file['error']);

                // A file bigger than upload_max_filesize never reaches us intact,
                // so this is a size problem, not a validation one: report 413 so
                // the visitor is told the truth.
                if (in_array($file['error'], [UPLOAD_ERR_INI_SIZE, UPLOAD_ERR_FORM_SIZE], true)) {
                    throw FormFileException::tooLarge(
                        sprintf('A(z) "%s" fájl túl nagy: %s', $label, $message),
                        [$file['field'] => $message]
                    );
                }

                $errors[$file['field']] = $message;
                continue;
            }

            if ($file['tmp_name'] === '' || !is_file($file['tmp_name'])) {
                $errors[$file['field']] = 'A feltöltött fájl nem található a szerveren.';
                continue;
            }

            // ── Size ─────────────────────────────────────────────────────────
            // filesize() on the temp file, not the reported size: the reported
            // value comes from the request.
            $realSize = (int) (@filesize($file['tmp_name']) ?: 0);

            if ($realSize <= 0) {
                $errors[$file['field']] = sprintf('A(z) "%s" fájl üres.', $label);
                continue;
            }

            $totalBytes += $realSize;

            if ($totalBytes > $maxTotal) {
                throw FormFileException::tooLarge(
                    sprintf(
                        'A csatolmányok összmérete legfeljebb %s lehet.',
                        self::formatBytes($maxTotal)
                    ),
                    ['files' => sprintf('Összesen legfeljebb %s csatolható.', self::formatBytes($maxTotal))]
                );
            }

            // ── Extension ────────────────────────────────────────────────────
            $extension = self::extensionOf($file['name']);

            if ($extension === null) {
                $errors[$file['field']] = sprintf('A(z) "%s" fájlnak nincs kiterjesztése.', $label);
                continue;
            }

            if (!in_array($extension, $allowed, true)) {
                $errors[$file['field']] = sprintf(
                    'A(z) ".%s" típus nem engedélyezett. Engedélyezett: %s',
                    $extension,
                    implode(', ', $allowed)
                );
                continue;
            }

            // ── Real MIME (the actual defence) ───────────────────────────────
            $sniffed = self::sniffMime($file['tmp_name']);

            if ($sniffed === null) {
                $errors[$file['field']] = 'A fájl típusa nem megállapítható.';
                continue;
            }

            if (!self::mimeMatchesExtension($extension, $sniffed)) {
                // Deliberately vague to the visitor, precise in the log: telling
                // an attacker exactly which sniffed type we saw helps them iterate.
                error_log(sprintf(
                    '[Forms] Csatolmany elutasitva: kiterjesztes=.%s, valodi MIME=%s, nev=%s',
                    $extension,
                    $sniffed,
                    self::sanitiseName($file['name'])
                ));

                $errors[$file['field']] = sprintf(
                    'A(z) "%s" fájl tartalma nem egyezik a kiterjesztésével.',
                    $label
                );
                continue;
            }

            $validated[] = [
                'field' => $file['field'],
                'original_name' => self::sanitiseName($file['name']),
                'extension' => $extension,
                'mime_type' => $sniffed,
                'size' => $realSize,
                'tmp_name' => $file['tmp_name'],
            ];
        }

        if (!empty($errors)) {
            throw FormFileException::rejected('A csatolmány nem fogadható el.', $errors);
        }

        // ── Per-form storage quota ──────────────────────────────────────────
        // Checked last, on the total that actually passed validation, so a
        // rejected file never counts against the quota.
        if ($quota > 0 && ($alreadyUsedBytes + $totalBytes) > $quota) {
            throw FormFileException::tooLarge(
                'Az űrlap tárhelye megtelt, a fájlfeltöltés jelenleg nem lehetséges.',
                ['files' => 'Az űrlap tárhelye megtelt.']
            );
        }

        return $validated;
    }

    /**
     * Resolve the effective allowlist: the form's list INTERSECTED with the hard
     * backend whitelist.
     *
     * @param array<string, mixed> $uploadSettings
     * @return array<int, string>
     */
    public static function resolveAllowedTypes(array $uploadSettings): array
    {
        $requested = $uploadSettings['allowed_types'] ?? null;

        if (!is_array($requested) || empty($requested)) {
            $requested = FormsSchema::DEFAULT_UPLOAD_TYPES;
        }

        $normalised = [];
        foreach ($requested as $type) {
            if (!is_string($type)) {
                continue;
            }
            $type = strtolower(ltrim(trim($type), '.'));

            // The intersection: unknown or dangerous types silently drop out
            // instead of failing, so one bad entry cannot disable the whole form.
            if (isset(FormsSchema::UPLOAD_TYPE_WHITELIST[$type])) {
                $normalised[$type] = true;
            }
        }

        // Empty after filtering means the form only listed rejected types.
        // Falling back to the defaults would ACCEPT MORE than configured, so fail
        // closed with an empty list: nothing is allowed.
        return array_keys($normalised);
    }

    /**
     * Extension of a filename, lowercased, or null when absent.
     *
     * Uses the LAST dot segment. "shell.php.pdf" therefore reads as "pdf" - and
     * that is fine, because the MIME check then has to agree and the file is
     * stored as {uuid}.bin regardless.
     */
    public static function extensionOf(string $filename): ?string
    {
        $clean = self::sanitiseName($filename);
        $extension = strtolower((string) pathinfo($clean, PATHINFO_EXTENSION));

        if ($extension === '' || !preg_match('/^[a-z0-9]{1,10}$/', $extension)) {
            return null;
        }

        return $extension;
    }

    /**
     * Read the real MIME type from the file's bytes.
     */
    public static function sniffMime(string $path): ?string
    {
        if (!is_file($path)) {
            return null;
        }

        if (class_exists(\finfo::class)) {
            $finfo = new \finfo(FILEINFO_MIME_TYPE);
            $mime = @$finfo->file($path);
            if (is_string($mime) && $mime !== '') {
                return strtolower($mime);
            }
        }

        if (function_exists('mime_content_type')) {
            $mime = @mime_content_type($path);
            if (is_string($mime) && $mime !== '') {
                return strtolower($mime);
            }
        }

        // No sniffing available: refuse rather than trust the client's claim.
        return null;
    }

    /**
     * Whether a sniffed MIME is legitimate for the given extension.
     */
    public static function mimeMatchesExtension(string $extension, string $mime): bool
    {
        $extension = strtolower($extension);
        $mime = strtolower(trim($mime));

        $expected = FormsSchema::UPLOAD_TYPE_WHITELIST[$extension] ?? null;
        if ($expected === null) {
            return false;
        }

        if (in_array($mime, $expected, true)) {
            return true;
        }

        // Office files are ZIP containers; some finfo builds report the generic
        // archive type. Accepted only where the whitelist already lists
        // application/zip for that extension, so this cannot widen anything.
        return false;
    }

    /**
     * Strip a filename down to something safe to display and to put in a
     * Content-Disposition header.
     */
    public static function sanitiseName(string $filename): string
    {
        // Take the basename twice: once for POSIX, once for Windows separators,
        // so "..\\..\\x.pdf" cannot survive as a relative path.
        $name = str_replace('\\', '/', $filename);
        $name = basename($name);

        $name = (string) preg_replace(self::UNSAFE_NAME_CHARS, '', $name);
        $name = trim($name);

        // Leading dots would create hidden files if the name were ever used on
        // disk, and read oddly in the UI.
        $name = ltrim($name, '.');

        if ($name === '') {
            $name = 'csatolmany';
        }

        if (mb_strlen($name, 'UTF-8') > FormsSchema::MAX_FILENAME_LENGTH) {
            $extension = pathinfo($name, PATHINFO_EXTENSION);
            $base = mb_substr(
                pathinfo($name, PATHINFO_FILENAME),
                0,
                FormsSchema::MAX_FILENAME_LENGTH - mb_strlen($extension, 'UTF-8') - 1,
                'UTF-8'
            );
            $name = $extension === '' ? $base : $base . '.' . $extension;
        }

        return $name;
    }

    /**
     * Human-readable message for a PHP upload error code.
     */
    public static function describeUploadError(int $code): string
    {
        return match ($code) {
            UPLOAD_ERR_INI_SIZE => 'A fájl nagyobb, mint amit a szerver engedélyez (upload_max_filesize).',
            UPLOAD_ERR_FORM_SIZE => 'A fájl nagyobb, mint az űrlapon megadott korlát.',
            UPLOAD_ERR_PARTIAL => 'A fájl csak részben töltődött fel, próbáld újra.',
            UPLOAD_ERR_NO_FILE => 'Nem érkezett fájl.',
            UPLOAD_ERR_NO_TMP_DIR => 'A szerveren nincs ideiglenes könyvtár a feltöltéshez.',
            UPLOAD_ERR_CANT_WRITE => 'A szerver nem tudta lemezre írni a fájlt.',
            UPLOAD_ERR_EXTENSION => 'A feltöltést egy szerver oldali kiterjesztés leállította.',
            default => 'A fájl feltöltése nem sikerült.',
        };
    }

    /**
     * Whether the request looks like it carried files at all.
     *
     * @param array<string, mixed> $files Raw $_FILES
     */
    public static function hasFiles(array $files): bool
    {
        return !empty(self::flatten($files));
    }

    /**
     * The server's own ceiling, so the UI can warn when it is below the form's
     * configured limit.
     *
     * A form set to 5 MB on a host with upload_max_filesize=2M silently truncates
     * every larger upload; surfacing the real limit turns a mystery into a
     * configuration note.
     */
    public static function serverUploadLimitBytes(): int
    {
        $candidates = [
            self::parseIniSize((string) ini_get('upload_max_filesize')),
            self::parseIniSize((string) ini_get('post_max_size')),
        ];

        $candidates = array_filter($candidates, static fn(int $v) => $v > 0);

        return empty($candidates) ? 0 : (int) min($candidates);
    }

    /**
     * Parse a php.ini shorthand size ("2M", "8M", "512K") into bytes.
     */
    public static function parseIniSize(string $value): int
    {
        $value = trim($value);
        if ($value === '') {
            return 0;
        }

        $unit = strtolower($value[strlen($value) - 1]);
        $number = (int) $value;

        return match ($unit) {
            'g' => $number * 1024 * 1024 * 1024,
            'm' => $number * 1024 * 1024,
            'k' => $number * 1024,
            default => $number,
        };
    }

    public static function formatBytes(int $bytes): string
    {
        if ($bytes >= 1048576) {
            return round($bytes / 1048576, 1) . ' MB';
        }
        if ($bytes >= 1024) {
            return round($bytes / 1024) . ' KB';
        }

        return $bytes . ' byte';
    }

    /**
     * @param array<string, mixed> $settings
     */
    private static function intSetting(array $settings, string $key, int $default): int
    {
        $value = $settings[$key] ?? null;

        return is_int($value) || (is_string($value) && ctype_digit($value)) ? (int) $value : $default;
    }
}
