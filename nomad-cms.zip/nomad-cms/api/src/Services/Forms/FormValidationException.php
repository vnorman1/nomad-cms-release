<?php
/**
 * NOMAD CMS - Form Validation Exception
 *
 * Input did not pass validation. Carries per-field error messages so both the
 * public endpoint (JSON error list) and the admin UI can render field-level
 * feedback instead of one opaque message.
 *
 * @package NomadCMS\Services\Forms
 */

declare(strict_types=1);

namespace NomadCMS\Services\Forms;

use RuntimeException;

class FormValidationException extends RuntimeException
{
    /** @var array<string, string> field name => human readable (Hungarian) message */
    private array $errors;

    /**
     * @param array<string, string> $errors
     */
    public function __construct(array $errors, string $message = 'Érvénytelen adatok.')
    {
        parent::__construct($message);
        $this->errors = $errors;
    }

    /**
     * @return array<string, string>
     */
    public function getErrors(): array
    {
        return $this->errors;
    }
}
