<?php
/**
 * NOMAD CMS - Form Rate Limiter
 *
 * SQLite-backed, per-form + per-IP rate limiting for the PUBLIC submit
 * endpoint.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * WHY NOT RateLimitMiddleware
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * The existing RateLimitMiddleware is file-based (one JSON file per key under
 * sys_get_temp_dir()). Two reasons that does not fit here:
 *
 * 1. The limit is CONFIGURABLE PER FORM (`rate_limit_per_minute`), so buckets
 *    must be keyed by form as well as IP, and the limit is data, not config.
 * 2. Submissions are the one place where losing the counter matters: temp dirs
 *    get cleared, and on shared hosting they are often per-process. A row in
 *    massive.sqlite - the database this module already owns - survives that and
 *    gives us an atomic UPSERT counter.
 *
 * The bucket key is a KEYED HASH of the IP (never the raw IP), and it keeps
 * working even without IP_HASH_SECRET - see FormCrypto::rateLimitKey().
 *
 * @package NomadCMS\Services\Forms
 */

declare(strict_types=1);

namespace NomadCMS\Services\Forms;

use PDO;
use Throwable;

final class FormRateLimiter
{
    public const TABLE = 'massive_form_rate_limits';

    /** Window length in seconds (fixed one-minute buckets) */
    private const WINDOW_SECONDS = 60;

    /** How many expired rows a single opportunistic cleanup removes */
    private const CLEANUP_BATCH = 500;

    private static bool $tableReady = false;

    /**
     * Create the bucket table on demand.
     *
     * Deliberately NOT a MassiveDatabase JSON slot: an atomic
     * "increment and read" needs real columns and a UNIQUE constraint.
     */
    public static function ensureTable(): void
    {
        if (self::$tableReady) {
            return;
        }

        $db = FormsSchema::db();
        $db->exec('
            CREATE TABLE IF NOT EXISTS ' . self::TABLE . ' (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                form_slug TEXT NOT NULL,
                ip_hash TEXT NOT NULL,
                window_start INTEGER NOT NULL,
                count INTEGER NOT NULL DEFAULT 0,
                UNIQUE (form_slug, ip_hash, window_start)
            )
        ');
        $db->exec('CREATE INDEX IF NOT EXISTS idx_' . self::TABLE . '_window ON ' . self::TABLE . '(window_start)');

        self::$tableReady = true;
    }

    /**
     * Register one attempt and report whether it is allowed.
     *
     * @param string $formSlug Form being submitted
     * @param string $ip Raw client IP (hashed before it touches storage)
     * @param int $limit Allowed submissions per minute
     * @return array{allowed:bool, limit:int, count:int, remaining:int, retry_after:int}
     */
    public static function hit(string $formSlug, string $ip, int $limit): array
    {
        $limit = max(FormsSchema::MIN_RATE_LIMIT, min(FormsSchema::MAX_RATE_LIMIT, $limit));

        self::ensureTable();

        $window = self::currentWindow();
        $ipHash = FormCrypto::rateLimitKey($ip);
        $db = FormsSchema::db();

        // Atomic increment. SQLite performs the UPSERT as a single statement, so
        // concurrent submissions cannot both read "0" and both write "1".
        $stmt = $db->prepare('
            INSERT INTO ' . self::TABLE . ' (form_slug, ip_hash, window_start, count)
            VALUES (?, ?, ?, 1)
            ON CONFLICT(form_slug, ip_hash, window_start)
            DO UPDATE SET count = count + 1
        ');
        $stmt->execute([$formSlug, $ipHash, $window]);

        $count = self::readCount($formSlug, $ipHash, $window);

        // Opportunistic housekeeping: ~2% of hits sweep old buckets, so the
        // table never needs a cron job.
        if (random_int(1, 100) <= 2) {
            self::cleanup();
        }

        $retryAfter = ($window + self::WINDOW_SECONDS) - time();

        return [
            'allowed' => $count <= $limit,
            'limit' => $limit,
            'count' => $count,
            'remaining' => max(0, $limit - $count),
            'retry_after' => max(1, $retryAfter),
        ];
    }

    /**
     * Read the current counter WITHOUT incrementing it.
     *
     * @return array{limit:int, count:int, remaining:int, retry_after:int}
     */
    public static function peek(string $formSlug, string $ip, int $limit): array
    {
        self::ensureTable();

        $window = self::currentWindow();
        $count = self::readCount($formSlug, FormCrypto::rateLimitKey($ip), $window);

        return [
            'limit' => $limit,
            'count' => $count,
            'remaining' => max(0, $limit - $count),
            'retry_after' => max(1, ($window + self::WINDOW_SECONDS) - time()),
        ];
    }

    /**
     * Clear the bucket for one form+IP (used after a legitimate flow, and by tests).
     */
    public static function reset(string $formSlug, string $ip): void
    {
        self::ensureTable();

        $stmt = FormsSchema::db()->prepare(
            'DELETE FROM ' . self::TABLE . ' WHERE form_slug = ? AND ip_hash = ?'
        );
        $stmt->execute([$formSlug, FormCrypto::rateLimitKey($ip)]);
    }

    /**
     * Remove buckets older than the current window.
     *
     * @return int Number of rows removed
     */
    public static function cleanup(): int
    {
        self::ensureTable();

        try {
            $stmt = FormsSchema::db()->prepare('
                DELETE FROM ' . self::TABLE . '
                WHERE id IN (
                    SELECT id FROM ' . self::TABLE . '
                    WHERE window_start < ?
                    LIMIT ' . self::CLEANUP_BATCH . '
                )
            ');
            $stmt->execute([self::currentWindow()]);

            return $stmt->rowCount();
        } catch (Throwable) {
            // Housekeeping must never break a submission
            return 0;
        }
    }

    /**
     * Start timestamp of the current fixed window.
     */
    public static function currentWindow(): int
    {
        return intdiv(time(), self::WINDOW_SECONDS) * self::WINDOW_SECONDS;
    }

    /**
     * Test seam: shift an existing bucket into the past so window rollover can
     * be exercised without sleeping for a minute.
     */
    public static function shiftWindowForTesting(string $formSlug, string $ip, int $seconds): void
    {
        self::ensureTable();

        $stmt = FormsSchema::db()->prepare('
            UPDATE ' . self::TABLE . '
            SET window_start = window_start - ?
            WHERE form_slug = ? AND ip_hash = ?
        ');
        $stmt->execute([$seconds, $formSlug, FormCrypto::rateLimitKey($ip)]);
    }

    private static function readCount(string $formSlug, string $ipHash, int $window): int
    {
        $stmt = FormsSchema::db()->prepare('
            SELECT count FROM ' . self::TABLE . '
            WHERE form_slug = ? AND ip_hash = ? AND window_start = ?
        ');
        $stmt->execute([$formSlug, $ipHash, $window]);
        $value = $stmt->fetchColumn(0);

        return $value === false || $value === null ? 0 : (int) $value;
    }

    /**
     * Row count (diagnostics / tests).
     */
    public static function bucketCount(): int
    {
        self::ensureTable();

        return (int) FormsSchema::db()->query('SELECT COUNT(*) FROM ' . self::TABLE)->fetchColumn(0);
    }
}
