<?php
/**
 * NOMAD CMS - Form Submission Service
 *
 * Builds, reads and presents submissions. The envelope layout is defined here.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * ENVELOPE
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * Plaintext form:
 *   { type, form_slug, status, encrypted:false, values:{...}, field_names:[...],
 *     ip_hash, user_agent, created_at, meta:{...} }
 *
 * Encrypted form:
 *   { type, form_slug, status, encrypted:true, enc_version, values_encrypted:"def…",
 *     field_names:[...], ip_hash, user_agent, created_at, meta:{...} }
 *
 * An encrypted envelope NEVER contains a `values` key - enforced by the test
 * suite, because a single accidental write of both would leave plaintext
 * personal data in the database while the UI happily shows a padlock.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * MASKING
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * Reading submissions requires `forms:read:*`. Reading the VALUES of an
 * encrypted submission additionally requires `forms:decrypt:*` - callers pass
 * that decision in as $canDecrypt. Without it, the service returns the field
 * NAMES and a masked marker, never the ciphertext (handing out ciphertext would
 * make the permission pointless the moment the key leaks elsewhere).
 *
 * Masking only applies to encrypted forms. For a plaintext form the values are
 * not protected at rest anyway, so pretending otherwise in the UI would be
 * security theatre - the honest answer is "enable encryption".
 *
 * @package NomadCMS\Services\Forms
 */

declare(strict_types=1);

namespace NomadCMS\Services\Forms;

use NomadCMS\Services\NotificationService\Support;

final class FormSubmissionService
{
    /** Placeholder shown instead of a value the caller may not decrypt */
    public const MASK = '•••';

    // =========================================================================
    // CREATE
    // =========================================================================

    /**
     * Store a submission for the given form.
     *
     * @param array<string, mixed> $form Hydrated form definition
     * @param array<string, mixed> $values Already validated + sanitized values
     * @param array{
     *     status?: string,
     *     ip?: string|null,
     *     user_agent?: string|null,
     *     origin?: string|null,
     *     content_type?: string|null,
     *     spam_reason?: string|null,
     *     attachments?: array<int, array<string, mixed>>
     * } $context
     * @return array{id:int, uuid:string, status:string, encrypted:bool}
     * @throws FormCryptoException When the form requires encryption but it is unavailable
     */
    public static function create(array $form, array $values, array $context = []): array
    {
        $formSlug = (string) ($form['data']['slug'] ?? '');
        $encrypted = FormService::isEncrypted($form);
        $status = $context['status'] ?? FormsSchema::STATUS_UNREAD;
        if (!in_array($status, FormsSchema::STATUSES, true)) {
            $status = FormsSchema::STATUS_UNREAD;
        }

        // Field names are schema, not personal data: keeping them in the clear
        // lets the inbox build its columns and the CSV its header without
        // decrypting a single row.
        $fieldNames = self::collectFieldNames($form, $values);

        $envelope = [
            'type' => FormsSchema::TYPE_SUBMISSION,
            'form_slug' => $formSlug,
            'status' => $status,
            'encrypted' => $encrypted,
            'field_names' => $fieldNames,
            'ip_hash' => FormCrypto::hashIp($context['ip'] ?? null),
            'user_agent' => FormValidator::sanitizeText($context['user_agent'] ?? null, 512),
            'created_at' => gmdate('Y-m-d H:i:s'),
            'meta' => [
                'origin' => FormValidator::sanitizeText($context['origin'] ?? null, 255),
                'content_type' => FormValidator::sanitizeText($context['content_type'] ?? null, 100),
                'spam_reason' => $context['spam_reason'] ?? null,
            ],
        ];

        // Own identity, for deep links like /forms/{slug}/submissions/{uuid}.
        // The integer id is a database detail; a UUID is what belongs in a URL
        // that gets pasted into a chat message, and it is unguessable, so a link
        // cannot be used to enumerate other people's submissions.
        //
        // Also returned to the caller below (not just stored in the envelope):
        // FormNotifier needs it to build a deep link straight to THIS
        // submission rather than just the form's inbox.
        $uuid = FormFileStorage::uuid();
        $envelope['uuid'] = $uuid;

        // Attachment references live in the PLAINTEXT part on purpose: the inbox
        // must be able to show "2 attachments" and the delete cascade must find
        // them without a key. Only uuid/size/extension are here - the revealing
        // part (the filename) stays in the metadata table and, for encrypted
        // forms, inside the encrypted file itself.
        $attachments = $context['attachments'] ?? [];
        if (is_array($attachments) && !empty($attachments)) {
            $envelope['attachments'] = array_values($attachments);
        }

        if ($encrypted) {
            $envelope['enc_version'] = FormsSchema::ENC_VERSION;
            // sealValues() throws when no key is configured - we must never
            // fall through to storing $values in the clear.
            $envelope['values_encrypted'] = FormCrypto::sealValues($values);
        } else {
            $envelope['values'] = $values;
        }

        $ftsContent = self::buildIndexContent($form, $values, $encrypted);

        FormsSchema::ensureTables();
        $db = FormsSchema::db();
        $id = Support::transaction($db, static function () use ($db, $form, $envelope, $ftsContent, $uuid, $status): int {
            $id = FormSubmissionRepository::insert($envelope, $ftsContent);
            FormNotificationIntegration::record($db, $form, $uuid, $status);
            return $id;
        });

        return ['id' => $id, 'uuid' => $uuid, 'status' => $status, 'encrypted' => $encrypted];
    }

    /**
     * Build the FTS row content for a submission.
     *
     * Encrypted: blind index tokens for the searchable fields only.
     * Plaintext: the submitted values.
     *
     * Shared with FormEncryptionMigrator so switching a form's encryption mode
     * cannot end up writing a differently-shaped index than a fresh submission
     * would.
     *
     * @param array<string, mixed> $form
     * @param array<string, mixed> $values
     */
    public static function buildIndexContent(array $form, array $values, bool $encrypted): string
    {
        return $encrypted
            ? FormCrypto::buildTokens($values, FormService::searchableFields($form))
            : self::flattenValuesForIndex($values);
    }

    // =========================================================================
    // READ
    // =========================================================================

    /**
     * Paginated inbox listing.
     *
     * The criteria array comes straight from request parameters, so every entry
     * is `mixed` and is type-checked here rather than trusted.
     *
     * @param array<string, mixed> $criteria Keys: form_slug, status, search, page, pageSize, dir
     * @param bool $canDecrypt Caller holds forms:decrypt:*
     * @return array{
     *     items:array<int,array<string,mixed>>,
     *     total:int, page:int, pageSize:int, totalPages:int,
     *     search_mode:string
     * }
     */
    public static function list(array $criteria, bool $canDecrypt): array
    {
        $formSlug = isset($criteria['form_slug']) && is_string($criteria['form_slug']) && $criteria['form_slug'] !== ''
            ? $criteria['form_slug']
            : null;

        $form = $formSlug !== null ? FormService::findBySlug($formSlug) : null;

        $search = isset($criteria['search']) && is_string($criteria['search']) ? trim($criteria['search']) : '';
        $matchInfo = self::buildMatch($search, $form);

        $result = FormSubmissionRepository::query([
            'form_slug' => $formSlug,
            'status' => $criteria['status'] ?? null,
            'match' => $matchInfo['expression'],
            'page' => $criteria['page'] ?? 1,
            'pageSize' => $criteria['pageSize'] ?? FormSubmissionRepository::DEFAULT_PAGE_SIZE,
            'dir' => $criteria['dir'] ?? 'desc',
        ]);

        $items = [];
        foreach ($result['items'] as $row) {
            $items[] = self::present($row, $canDecrypt);
        }
        $result['items'] = $items;
        $result['search_mode'] = $matchInfo['mode'];

        return $result;
    }

    /**
     * Single submission, masked unless $canDecrypt.
     *
     * @return array<string, mixed>|null
     */
    public static function getById(int $id, bool $canDecrypt): ?array
    {
        $row = FormSubmissionRepository::findById($id);

        return $row === null ? null : self::present($row, $canDecrypt);
    }

    /**
     * Single submission by its own UUID (deep link resolution).
     *
     * Separate from getById() because a deep link must keep working regardless of
     * which page the row currently sits on, and the integer id is not something
     * that belongs in a shareable URL.
     *
     * @return array<string, mixed>|null
     */
    public static function getByUuid(string $uuid, bool $canDecrypt): ?array
    {
        $row = FormSubmissionRepository::findByUuid($uuid);

        return $row === null ? null : self::present($row, $canDecrypt);
    }

    /**
     * Turn a stored row into its API representation.
     *
     * @param array{id:int, data:array<string,mixed>, created_at:string, updated_at:string} $row
     * @return array<string, mixed>
     */
    public static function present(array $row, bool $canDecrypt): array
    {
        $data = $row['data'];
        $encrypted = (bool) ($data['encrypted'] ?? false);
        $fieldNames = is_array($data['field_names'] ?? null) ? array_values($data['field_names']) : [];

        $presented = [
            'id' => $row['id'],
            // Present even when absent, so the frontend can decide whether a
            // shareable deep link exists for this row. Submissions created before
            // this feature have no uuid, and get null rather than a fake one.
            'uuid' => isset($data['uuid']) && is_string($data['uuid']) ? $data['uuid'] : null,
            'form_slug' => (string) ($data['form_slug'] ?? ''),
            'status' => (string) ($data['status'] ?? FormsSchema::STATUS_UNREAD),
            'encrypted' => $encrypted,
            'created_at' => (string) ($data['created_at'] ?? $row['created_at']),
            'updated_at' => $row['updated_at'],
            'field_names' => $fieldNames,
            'ip_hash' => $data['ip_hash'] ?? null,
            'user_agent' => $data['user_agent'] ?? null,
            'meta' => is_array($data['meta'] ?? null) ? $data['meta'] : [],
            // Attachment count from the envelope. The full metadata (filenames,
            // sizes) is fetched separately from the attachments table, because it
            // is not personal data that needs the encryption envelope.
            'attachment_count' => is_array($data['attachments'] ?? null) ? count($data['attachments']) : 0,
            'decrypt_error' => null,
        ];

        if (!$encrypted) {
            $presented['masked'] = false;
            $presented['values'] = is_array($data['values'] ?? null) ? $data['values'] : [];

            return $presented;
        }

        if (!$canDecrypt) {
            $presented['masked'] = true;
            $presented['values'] = null;

            return $presented;
        }

        try {
            $values = FormCrypto::openValues((string) ($data['values_encrypted'] ?? ''));
            $presented['masked'] = false;
            $presented['values'] = $values;
        } catch (FormCryptoException $e) {
            // Surface the failure instead of showing an empty submission: an
            // empty map is indistinguishable from "the visitor sent nothing".
            $presented['masked'] = true;
            $presented['values'] = null;
            $presented['decrypt_error'] = $e->getMessage();
        }

        return $presented;
    }

    /**
     * Unread counter, optionally scoped to a form.
     */
    public static function unreadCount(?string $formSlug = null): int
    {
        return FormSubmissionRepository::statusCounts($formSlug)[FormsSchema::STATUS_UNREAD] ?? 0;
    }

    /**
     * @return array<string, int>
     */
    public static function statusCounts(?string $formSlug = null): array
    {
        return FormSubmissionRepository::statusCounts($formSlug);
    }

    // =========================================================================
    // MUTATE
    // =========================================================================

    /**
     * Change a submission's status.
     *
     * INTENTIONALLY DOES NOT TOUCH WEBHOOKS: the only outbound event this
     * module fires is `form.submitted` (FormNotifier::dispatchWebhook()),
     * dispatched exactly once, from the PUBLIC submit endpoint, right after
     * FormSubmissionService::create(). An admin marking a submission
     * read/archived/spam - single or bulk - is a status mutation on data that
     * already exists, not a new inbound submission, and must never be able to
     * re-trigger or duplicate that event. Do not add a webhook/notification
     * call here or in bulkSetStatus() below.
     *
     * @throws FormValidationException On an unknown status
     * @throws FormNotFoundException
     */
    public static function setStatus(int $id, string $status): bool
    {
        self::assertStatus($status);

        $row = FormSubmissionRepository::findById($id);
        if ($row === null) {
            throw new FormNotFoundException('Nincs ilyen beküldés.');
        }

        $data = $row['data'];
        if (($data['status'] ?? null) === $status) {
            return true;
        }

        $data['status'] = $status;

        // The FTS row is untouched on purpose: it holds submitted values (or
        // blind tokens), never the status, so a status change cannot invalidate
        // the index.
        return FormSubmissionRepository::updateEnvelope($id, $data);
    }

    /**
     * @param array<int, int> $ids
     * @throws FormValidationException
     */
    public static function bulkSetStatus(array $ids, string $status): int
    {
        self::assertStatus($status);

        $changed = 0;
        foreach (array_unique(array_map('intval', $ids)) as $id) {
            try {
                if (self::setStatus($id, $status)) {
                    $changed++;
                }
            } catch (FormNotFoundException) {
                // Skip ids that vanished between selection and action
            }
        }

        return $changed;
    }

    /**
     * Permanently delete a submission (the "right to erasure" action).
     */
    public static function erase(int $id): bool
    {
        return FormSubmissionRepository::delete($id);
    }

    /**
     * @param array<int, int> $ids
     */
    public static function bulkErase(array $ids): int
    {
        return FormSubmissionRepository::bulkDelete($ids);
    }

    // =========================================================================
    // EXPORT
    // =========================================================================

    /**
     * Build a CSV export.
     *
     * SECURITY: for an encrypted form this writes PLAINTEXT personal data into
     * a file that leaves the system. Callers must require BOTH forms:export:*
     * and forms:decrypt:*, and must write an audit entry.
     *
     * @param array<string, mixed> $criteria Same shape as list()
     * @param bool $canDecrypt
     * @return array{csv:string, rows:int, decrypt_failures:int}
     */
    public static function exportCsv(array $criteria, bool $canDecrypt): array
    {
        $formSlug = isset($criteria['form_slug']) && is_string($criteria['form_slug']) && $criteria['form_slug'] !== ''
            ? $criteria['form_slug']
            : null;
        $form = $formSlug !== null ? FormService::findBySlug($formSlug) : null;

        $search = isset($criteria['search']) && is_string($criteria['search']) ? trim($criteria['search']) : '';
        $matchInfo = self::buildMatch($search, $form);

        $rows = FormSubmissionRepository::fetchAllForExport([
            'form_slug' => $formSlug,
            'status' => $criteria['status'] ?? null,
            'match' => $matchInfo['expression'],
        ]);

        $presented = [];
        $valueKeys = [];
        $decryptFailures = 0;

        foreach ($rows as $row) {
            $item = self::present($row, $canDecrypt);
            if ($item['decrypt_error'] !== null) {
                $decryptFailures++;
            }
            $presented[] = $item;

            // Header is the UNION of every key seen, so a form whose schema
            // changed over time still exports every historical answer.
            $keys = is_array($item['values']) ? array_keys($item['values']) : $item['field_names'];
            foreach ($keys as $key) {
                if (!in_array($key, $valueKeys, true)) {
                    $valueKeys[] = (string) $key;
                }
            }
        }

        $header = array_merge(
            ['id', 'created_at', 'form_slug', 'status', 'ip_hash', 'user_agent'],
            $valueKeys
        );

        $lines = [self::csvLine($header)];
        foreach ($presented as $item) {
            $line = [
                (string) $item['id'],
                (string) $item['created_at'],
                (string) $item['form_slug'],
                (string) $item['status'],
                (string) ($item['ip_hash'] ?? ''),
                (string) ($item['user_agent'] ?? ''),
            ];

            foreach ($valueKeys as $key) {
                if ($item['masked']) {
                    $line[] = self::MASK;
                    continue;
                }
                $value = is_array($item['values']) ? ($item['values'][$key] ?? null) : null;
                $line[] = self::stringifyValue($value);
            }

            $lines[] = self::csvLine($line);
        }

        // UTF-8 BOM so Excel opens accented characters correctly
        $csv = "\xEF\xBB\xBF" . implode("\r\n", $lines) . "\r\n";

        return ['csv' => $csv, 'rows' => count($presented), 'decrypt_failures' => $decryptFailures];
    }

    /**
     * Row count an export would produce, capped the same way the export is.
     *
     * Needed because streamCsv() can only report its count after the response
     * body has started, by which time headers are unchangeable.
     *
     * @param array<string, mixed> $criteria Same shape as list()
     */
    public static function countForExport(array $criteria): int
    {
        $formSlug = isset($criteria['form_slug']) && is_string($criteria['form_slug']) && $criteria['form_slug'] !== ''
            ? $criteria['form_slug']
            : null;
        $form = $formSlug !== null ? FormService::findBySlug($formSlug) : null;

        $search = isset($criteria['search']) && is_string($criteria['search']) ? trim($criteria['search']) : '';
        $matchInfo = self::buildMatch($search, $form);

        $total = FormSubmissionRepository::countMatching([
            'form_slug' => $formSlug,
            'status' => $criteria['status'] ?? null,
            'match' => $matchInfo['expression'],
        ]);

        return min($total, FormSubmissionRepository::EXPORT_MAX_ROWS);
    }

    /**
     * Stream the CSV export straight to the output buffer.
     *
     * Preferred over exportCsv() for anything user-facing. exportCsv() builds
     * the whole file in memory, which was measured at 215 MB peak for a
     * 50 000-row export - fatal under the 128 MB memory_limit typical of shared
     * hosting, and reachable within days at 10 000 submissions/day.
     *
     * This version keeps only one batch of rows plus one CSV line in memory, so
     * peak stays flat regardless of export size. The header is resolved up front
     * from stored field_names (a SQL DISTINCT, no row payloads), because a CSV
     * header cannot be revised after the first byte is sent.
     *
     * The caller MUST have sent its headers already; nothing here can fail in a
     * way that lets it switch to a JSON error response afterwards, which is why
     * the row count is returned for the audit log rather than a header.
     *
     * @param array<string, mixed> $criteria Same shape as list()
     * @param bool $canDecrypt Caller holds forms:decrypt:*
     * @param resource|null $stream Defaults to php://output
     * @return array{rows:int, decrypt_failures:int}
     */
    public static function streamCsv(array $criteria, bool $canDecrypt, $stream = null): array
    {
        $formSlug = isset($criteria['form_slug']) && is_string($criteria['form_slug']) && $criteria['form_slug'] !== ''
            ? $criteria['form_slug']
            : null;
        $form = $formSlug !== null ? FormService::findBySlug($formSlug) : null;

        $search = isset($criteria['search']) && is_string($criteria['search']) ? trim($criteria['search']) : '';
        $matchInfo = self::buildMatch($search, $form);

        $repoCriteria = [
            'form_slug' => $formSlug,
            'status' => $criteria['status'] ?? null,
            'match' => $matchInfo['expression'],
        ];

        // Header first: union of every field name in scope, resolved in SQL.
        $valueKeys = FormSubmissionRepository::exportFieldNames($repoCriteria);

        // Fallback for hosts whose SQLite lacks json_each: use the form's own
        // schema. Better a schema-ordered header than a failed download.
        if (empty($valueKeys) && $form !== null) {
            foreach (FormService::fields($form) as $field) {
                if (isset($field['name']) && is_string($field['name'])) {
                    $valueKeys[] = $field['name'];
                }
            }
        }

        $out = $stream ?? fopen('php://output', 'wb');
        $shouldClose = $stream === null;

        // UTF-8 BOM so Excel opens accented characters correctly
        fwrite($out, "\xEF\xBB\xBF");
        fwrite($out, self::csvLine(array_merge(
            ['id', 'created_at', 'form_slug', 'status', 'ip_hash', 'user_agent'],
            $valueKeys
        )) . "\r\n");

        $rows = 0;
        $decryptFailures = 0;

        foreach (FormSubmissionRepository::streamForExport($repoCriteria) as $row) {
            $item = self::present($row, $canDecrypt);
            if ($item['decrypt_error'] !== null) {
                $decryptFailures++;
            }

            $line = [
                (string) $item['id'],
                (string) $item['created_at'],
                (string) $item['form_slug'],
                (string) $item['status'],
                (string) ($item['ip_hash'] ?? ''),
                (string) ($item['user_agent'] ?? ''),
            ];

            foreach ($valueKeys as $key) {
                if ($item['masked']) {
                    $line[] = self::MASK;
                    continue;
                }
                $value = is_array($item['values']) ? ($item['values'][$key] ?? null) : null;
                $line[] = self::stringifyValue($value);
            }

            fwrite($out, self::csvLine($line) . "\r\n");
            $rows++;

            // Push bytes to the client periodically so a long export does not
            // sit in PHP's buffer looking like a hung request.
            if ($rows % 500 === 0) {
                flush();
            }
        }

        if ($shouldClose) {
            fclose($out);
        }

        return ['rows' => $rows, 'decrypt_failures' => $decryptFailures];
    }

    // =========================================================================
    // SEARCH MODE RESOLUTION
    // =========================================================================

    /**
     * Decide how a search string should be matched.
     *
     * - no search              -> mode 'none', no MATCH clause
     * - plaintext form         -> mode 'text', prefix FTS query
     * - encrypted form         -> mode 'blind', exact-match tokens
     * - encrypted, no tokens   -> mode 'unavailable', a MATCH that never hits
     *   (returning everything would be a silent, misleading "search")
     * - global (no form filter)-> mode 'mixed', plaintext query OR the blind
     *   tokens of every encrypted form
     *
     * @param array<string, mixed>|null $form
     * @return array{expression:string|null, mode:string}
     */
    public static function buildMatch(string $search, ?array $form): array
    {
        if ($search === '') {
            return ['expression' => null, 'mode' => 'none'];
        }

        if ($form !== null) {
            if (!FormService::isEncrypted($form)) {
                $expr = self::plainFtsExpression($search);

                return $expr === null
                    ? ['expression' => FormSubmissionRepository::neverMatchExpression(), 'mode' => 'unavailable']
                    : ['expression' => $expr, 'mode' => 'text'];
            }

            $tokens = FormCrypto::buildSearchQuery($search, FormService::searchableFields($form));

            return $tokens === null
                ? ['expression' => FormSubmissionRepository::neverMatchExpression(), 'mode' => 'unavailable']
                : ['expression' => $tokens, 'mode' => 'blind'];
        }

        // Global search: plaintext submissions match textually, encrypted ones
        // only via their own blind tokens.
        $parts = [];
        $plain = self::plainFtsExpression($search);
        if ($plain !== null) {
            $parts[] = $plain;
        }

        foreach (FormService::listAll() as $candidate) {
            if (!FormService::isEncrypted($candidate)) {
                continue;
            }
            $tokens = FormCrypto::buildSearchQuery($search, FormService::searchableFields($candidate));
            if ($tokens !== null && !in_array($tokens, $parts, true)) {
                $parts[] = $tokens;
            }
        }

        if (empty($parts)) {
            return ['expression' => FormSubmissionRepository::neverMatchExpression(), 'mode' => 'unavailable'];
        }

        return ['expression' => implode(' OR ', $parts), 'mode' => 'mixed'];
    }

    /**
     * Build a prefix FTS5 expression from a free-text query.
     *
     * Mirrors MassiveDatabase::buildFtsQuery(): separators become spaces and
     * every token gets a trailing '*', so "james.jo" becomes "james* jo*".
     * Returns null when nothing indexable remains.
     */
    public static function plainFtsExpression(string $search): ?string
    {
        $clean = preg_replace('/[^\p{L}\p{N}_]+/u', ' ', $search) ?? '';
        $words = array_values(array_filter(explode(' ', $clean), static fn($w) => $w !== ''));

        if (empty($words)) {
            return null;
        }

        // Cap the number of terms so a pathological query cannot blow up FTS
        $words = array_slice($words, 0, 10);

        return implode('* ', $words) . '*';
    }

    // =========================================================================
    // HELPERS
    // =========================================================================

    /**
     * @throws FormValidationException
     */
    private static function assertStatus(string $status): void
    {
        if (!in_array($status, FormsSchema::STATUSES, true)) {
            throw new FormValidationException([
                'status' => 'Érvénytelen státusz. Lehetséges értékek: ' . implode(', ', FormsSchema::STATUSES),
            ]);
        }
    }

    /**
     * Field names to record on the envelope: the schema order first, then any
     * extra keys the visitor actually sent (lax mode).
     *
     * @param array<string, mixed> $form
     * @param array<string, mixed> $values
     * @return array<int, string>
     */
    private static function collectFieldNames(array $form, array $values): array
    {
        $names = FormService::fieldNames($form);
        foreach (array_keys($values) as $key) {
            $key = (string) $key;
            if (!in_array($key, $names, true)) {
                $names[] = $key;
            }
        }

        return $names;
    }

    /**
     * FTS content for a PLAINTEXT submission: the submitted values only.
     *
     * Envelope metadata is deliberately excluded - indexing it would make a
     * search for "read" or for a form slug match every row.
     *
     * @param array<string, mixed> $values
     */
    private static function flattenValuesForIndex(array $values): string
    {
        $parts = [];
        foreach ($values as $value) {
            if (is_bool($value)) {
                continue;
            }
            if (is_scalar($value)) {
                $parts[] = (string) $value;
            } elseif (is_array($value)) {
                $parts[] = self::flattenValuesForIndex($value);
            }
        }

        return trim(implode(' ', $parts));
    }

    /**
     * @param array<int, string> $fields
     */
    private static function csvLine(array $fields): string
    {
        $escaped = array_map([self::class, 'csvCell'], $fields);

        return implode(',', $escaped);
    }

    /**
     * Quote a CSV cell and neutralise spreadsheet formula injection.
     *
     * A value starting with = + - @ (or a tab/CR) is executed as a formula by
     * Excel/Sheets when the exported file is opened, so it gets a leading
     * apostrophe. This is the standard mitigation and keeps the value visible.
     */
    private static function csvCell(string $value): string
    {
        if ($value !== '' && preg_match('/^[=+\-@\t\r]/', $value) === 1) {
            $value = "'" . $value;
        }

        return '"' . str_replace('"', '""', $value) . '"';
    }

    private static function stringifyValue(mixed $value): string
    {
        if ($value === null) {
            return '';
        }
        if (is_bool($value)) {
            return $value ? 'igen' : 'nem';
        }
        if (is_array($value)) {
            return implode(', ', array_map([self::class, 'stringifyValue'], $value));
        }
        if (is_scalar($value)) {
            return (string) $value;
        }

        return '';
    }
}
