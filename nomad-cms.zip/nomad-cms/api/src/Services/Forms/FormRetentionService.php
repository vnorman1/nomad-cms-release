<?php
/**
 * NOMAD CMS - Form Retention Service
 *
 * Deletes submissions past their form's retention window ("storage limitation"
 * under GDPR: personal data must not be kept longer than necessary).
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * HOW IT RUNS WITHOUT CRON
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * The project already processes background work by piggybacking on regular HTTP
 * requests (bootstrap.php::registerPiggybackProcessing(), after
 * fastcgi_finish_request() so the visitor never waits). The retention sweep
 * hooks into the same place with a low sampling probability and a hard per-run
 * cap, so it costs almost nothing per request and cannot stall one.
 *
 * A manual trigger also exists on the admin endpoint for deployments that DO
 * have cron, or when an admin wants the space back immediately.
 *
 * Only forms with an explicit `retention_days` are touched. No implicit default:
 * silently deleting someone's leads because a setting defaulted to 30 days would
 * be worse than keeping them.
 *
 * @package NomadCMS\Services\Forms
 */

declare(strict_types=1);

namespace NomadCMS\Services\Forms;

use Throwable;

final class FormRetentionService
{
    /** Submissions removed per sweep, per form */
    public const DEFAULT_MAX_PER_RUN = 200;

    /** Hard cap for a manually triggered sweep */
    public const MAX_PER_RUN = 5000;

    /** Percentage of requests that trigger a piggyback sweep */
    private const PIGGYBACK_SAMPLE_PERCENT = 2;

    /**
     * Run a retention sweep across every form that has a retention window.
     *
     * @param int $maxPerForm Maximum submissions deleted per form in this run
     * @return array{
     *     forms_scanned:int,
     *     deleted:int,
     *     per_form:array<string,int>,
     *     more_pending:bool
     * }
     */
    public static function sweep(int $maxPerForm = self::DEFAULT_MAX_PER_RUN): array
    {
        $maxPerForm = max(1, min(self::MAX_PER_RUN, $maxPerForm));

        $deleted = 0;
        $scanned = 0;
        $perForm = [];
        $morePending = false;

        foreach (FormService::listAll() as $form) {
            $retentionDays = FormService::retentionDays($form);
            if ($retentionDays === null) {
                continue; // Keep forever - explicit admin choice
            }

            $slug = (string) ($form['data']['slug'] ?? '');
            if ($slug === '') {
                continue;
            }

            $scanned++;

            $ids = FormSubmissionRepository::expiredIds($slug, $retentionDays, $maxPerForm);
            if (empty($ids)) {
                continue;
            }

            $removed = FormSubmissionRepository::bulkDelete($ids);
            if ($removed > 0) {
                $deleted += $removed;
                $perForm[$slug] = $removed;
            }

            // If we filled the batch there is probably more to do next time
            if (count($ids) >= $maxPerForm) {
                $morePending = true;
            }
        }

        $summary = [
            'forms_scanned' => $scanned,
            'deleted' => $deleted,
            'per_form' => $perForm,
            'more_pending' => $morePending,
        ];

        if ($deleted > 0) {
            FormAuditLog::retention($summary);
        }

        return $summary;
    }

    /**
     * Sweep candidates for one form without deleting anything.
     *
     * @return array{slug:string, retention_days:int|null, expired:int}
     * @throws FormNotFoundException
     */
    public static function preview(string $slug): array
    {
        $form = FormService::requireBySlug($slug);
        $retentionDays = FormService::retentionDays($form);

        return [
            'slug' => $slug,
            'retention_days' => $retentionDays,
            'expired' => $retentionDays === null
                ? 0
                : count(FormSubmissionRepository::expiredIds($slug, $retentionDays, self::MAX_PER_RUN)),
        ];
    }

    /**
     * Entry point for the piggyback shutdown handler.
     *
     * Sampled and fully guarded: this runs AFTER the response has been flushed,
     * so an exception here would be invisible to the user but could still fill
     * the error log or abort other queued work.
     */
    public static function piggyback(): void
    {
        try {
            if (random_int(1, 100) > self::PIGGYBACK_SAMPLE_PERCENT) {
                return;
            }

            // Nothing to do if the module was never used on this installation.
            if (!self::hasAnyRetentionPolicy()) {
                return;
            }

            self::sweep(50);
            FormRateLimiter::cleanup();
        } catch (Throwable $e) {
            error_log('[Forms] Retention piggyback error: ' . $e->getMessage());
        }
    }

    /**
     * True when at least one form defines a retention window.
     */
    public static function hasAnyRetentionPolicy(): bool
    {
        foreach (FormService::listAll() as $form) {
            if (FormService::retentionDays($form) !== null) {
                return true;
            }
        }

        return false;
    }
}
