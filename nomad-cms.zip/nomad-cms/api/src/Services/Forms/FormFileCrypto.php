<?php
/**
 * NOMAD CMS - Form File Crypto
 *
 * At-rest encryption for submission attachments. The attachment follows the
 * FORM's encryption setting: if a form encrypts its submitted values, its
 * attachments are encrypted too.
 *
 * WHY THAT COUPLING MATTERS:
 * Encrypting a contact form's "message" field while the CV attached to it sits
 * readable on disk is not a partial protection, it is a false one - the
 * attachment usually holds far more personal data than the fields do. So the two
 * are one decision, not two.
 *
 * IMPLEMENTATION: this is a thin adapter over EncryptionService's existing
 * streaming .nomad format rather than a second encryption scheme. That format
 * already gives us what attachments need:
 *
 *   - chunked streaming, so a 5 MB file does not become 15 MB of PHP memory
 *   - the original filename and MIME encrypted INSIDE the payload, so the disk
 *     leaks nothing at all (the DB row holds them for listing, but the file
 *     itself is opaque)
 *   - a versioned header, so the format can change without orphaning old files
 *
 * Writing a parallel Defuse\Crypto\File implementation would mean two crypto
 * paths to audit and keep correct, for no gain.
 *
 * FAIL CLOSED: with no key available, encryption REFUSES rather than storing the
 * file in the clear. A visitor gets a 503 and no file is kept - the alternative
 * is an attachment the UI labels as encrypted while it is not.
 *
 * @package NomadCMS\Services\Forms
 */

declare(strict_types=1);

namespace NomadCMS\Services\Forms;

require_once dirname(__DIR__, 2) . '/Security/EncryptionService.php';
require_once __DIR__ . '/FormFileException.php';
require_once __DIR__ . '/FormFileStorage.php';

use NomadCMS\Security\EncryptionService;

final class FormFileCrypto
{
    /**
     * .nomad type marker for form attachments.
     *
     * Distinct from NOMAD_TYPE_SECURE_FILE (the media library's) so the two
     * stores stay distinguishable in forensics and in any future bulk tooling -
     * they have different trust levels and different retention rules.
     */
    public const NOMAD_TYPE = 'form_attachment';

    /**
     * Whether at-rest encryption is possible right now.
     */
    public static function isAvailable(): bool
    {
        return EncryptionService::isConfigured();
    }

    /**
     * Encrypt an uploaded file into the store.
     *
     * @param string $sourcePath Plaintext source (the PHP upload temp file)
     * @param string $destAbsolute Target path inside the store
     * @param array{originalName?:string, mimeType?:string, originalSize?:int} $metadata
     * @throws FormFileException When no key is configured or encryption fails
     */
    public static function encryptToStore(string $sourcePath, string $destAbsolute, array $metadata): void
    {
        if (!self::isAvailable()) {
            throw FormFileException::encryptionUnavailable();
        }

        try {
            EncryptionService::encryptFileStreaming($sourcePath, $destAbsolute, $metadata, self::NOMAD_TYPE);
        } catch (\Throwable $e) {
            // Never leave a half-written file that looks like a valid attachment.
            if (is_file($destAbsolute)) {
                @unlink($destAbsolute);
            }

            error_log('[Forms] Csatolmany titkositas sikertelen: ' . $e->getMessage());

            throw new FormFileException(
                'A csatolmány titkosítása nem sikerült.',
                500,
                'ENCRYPTION_FAILED'
            );
        }
    }

    /**
     * Decrypt a stored attachment to a temporary file.
     *
     * The caller owns the returned path and MUST unlink it once streamed -
     * a decrypted attachment left in the temp directory would undo the point of
     * encrypting it.
     *
     * @param string $relativePath Stored disk_path
     * @return array{path:string, metadata:array<string, mixed>}
     * @throws FormFileException
     */
    public static function decryptToTemp(string $relativePath): array
    {
        if (!self::isAvailable()) {
            throw new FormFileException(
                'A csatolmány visszafejtése nem lehetséges (nincs titkosítási kulcs).',
                503,
                'ENCRYPTION_UNAVAILABLE'
            );
        }

        $source = FormFileStorage::resolve($relativePath);

        if (!is_file($source)) {
            throw new FormFileException('A csatolmány fájlja nem található.', 404, 'FILE_MISSING');
        }

        $temp = tempnam(sys_get_temp_dir(), 'nomad_att_');
        if ($temp === false) {
            throw new FormFileException('Nem sikerült ideiglenes fájlt létrehozni.', 500, 'TEMP_FAILED');
        }

        try {
            $metadata = EncryptionService::decryptFileStreaming($source, $temp);
        } catch (\Throwable $e) {
            @unlink($temp);

            error_log('[Forms] Csatolmany visszafejtes sikertelen: ' . $e->getMessage());

            throw new FormFileException(
                'A csatolmány visszafejtése nem sikerült. Ez általában megváltozott ENCRYPTION_KEY-re utal.',
                500,
                'DECRYPTION_FAILED'
            );
        }

        // decryptFileStreaming() is declared as returning array, so no runtime
        // type check is needed here.
        return ['path' => $temp, 'metadata' => $metadata];
    }

    /**
     * Stream a stored attachment to an output handle, decrypting when needed.
     *
     * Handles both cases so callers do not branch: an unencrypted attachment is
     * streamed straight from the store, an encrypted one is decrypted to a temp
     * file, streamed, and the temp file removed - guaranteed, even on failure.
     *
     * @param resource $out Destination stream (usually php://output)
     * @return int Bytes written
     * @throws FormFileException
     */
    public static function streamToOutput(string $relativePath, bool $encrypted, $out): int
    {
        if (!$encrypted) {
            $source = FormFileStorage::resolve($relativePath);

            if (!is_file($source)) {
                throw new FormFileException('A csatolmány fájlja nem található.', 404, 'FILE_MISSING');
            }

            return self::pipe($source, $out);
        }

        $decrypted = self::decryptToTemp($relativePath);

        try {
            return self::pipe($decrypted['path'], $out);
        } finally {
            // The decrypted copy must not outlive the response.
            @unlink($decrypted['path']);
        }
    }

    /**
     * Copy a file to a stream in chunks.
     *
     * 64 KB chunks rather than readfile(): readfile() on a 5 MB attachment is
     * fine, but this keeps memory flat regardless of any future size increase and
     * lets the bytes start flowing immediately.
     *
     * @param resource $out
     */
    private static function pipe(string $path, $out): int
    {
        $in = @fopen($path, 'rb');
        if ($in === false) {
            throw new FormFileException('A csatolmány nem olvasható.', 500, 'READ_FAILED');
        }

        $written = 0;

        try {
            while (!feof($in)) {
                $chunk = fread($in, 65536);
                if ($chunk === false) {
                    break;
                }
                $written += (int) fwrite($out, $chunk);
            }
        } finally {
            fclose($in);
        }

        return $written;
    }

    /**
     * Size of the decrypted content, for the Content-Length header.
     *
     * The ciphertext on disk is larger than the plaintext (header, IV, MAC), so
     * filesize() would be wrong for an encrypted attachment. The true size is in
     * the DB row (size_bytes, recorded at upload time), which is why this only
     * needs to cover the unencrypted case.
     */
    public static function plaintextSizeOnDisk(string $relativePath): ?int
    {
        return FormFileStorage::size($relativePath);
    }
}
