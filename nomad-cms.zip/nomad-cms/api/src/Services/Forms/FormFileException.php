<?php
/**
 * NOMAD CMS - Form File Exception
 *
 * Raised for attachment storage and validation failures.
 *
 * Carries an HTTP status and a machine code so the public endpoint can map a
 * failure to the right response without inspecting messages: a rejected type is
 * a 400 the visitor can fix, an exhausted quota is a 413 they cannot.
 *
 * @package NomadCMS\Services\Forms
 */

declare(strict_types=1);

namespace NomadCMS\Services\Forms;

class FormFileException extends \RuntimeException
{
    /** @var array<string, string> field name => error message */
    private array $errors;

    private int $statusCode;

    private string $errorCode;

    /**
     * @param array<string, string> $errors
     */
    public function __construct(
        string $message,
        int $statusCode = 400,
        string $errorCode = 'FILE_REJECTED',
        array $errors = []
    ) {
        parent::__construct($message);

        $this->statusCode = $statusCode;
        $this->errorCode = $errorCode;
        $this->errors = $errors;
    }

    public function getStatusCode(): int
    {
        return $this->statusCode;
    }

    public function getErrorCode(): string
    {
        return $this->errorCode;
    }

    /**
     * @return array<string, string>
     */
    public function getErrors(): array
    {
        return $this->errors;
    }

    /**
     * Payload too large: the submission's attachments exceed the per-submission
     * budget or the form's storage quota.
     *
     * @param array<string, string> $errors
     */
    public static function tooLarge(string $message, array $errors = []): self
    {
        return new self($message, 413, 'PAYLOAD_TOO_LARGE', $errors);
    }

    /**
     * The form does not accept uploads at all.
     */
    public static function uploadsDisabled(): self
    {
        return new self(
            'Ez az űrlap nem fogad fájlfeltöltést.',
            415,
            'FILE_UPLOAD_UNSUPPORTED'
        );
    }

    /**
     * A file failed validation (type, MIME mismatch, name, count).
     *
     * @param array<string, string> $errors
     */
    public static function rejected(string $message, array $errors = []): self
    {
        return new self($message, 400, 'FILE_REJECTED', $errors);
    }

    /**
     * The form is encrypted but no key is available, so the attachment cannot be
     * sealed. Fail closed - never fall back to storing it in the clear.
     */
    public static function encryptionUnavailable(): self
    {
        return new self(
            'Az űrlap titkosított, de a szerveren nincs beállítva titkosítási kulcs.',
            503,
            'ENCRYPTION_UNAVAILABLE'
        );
    }
}
