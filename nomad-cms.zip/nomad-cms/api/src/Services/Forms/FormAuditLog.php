<?php
/**
 * NOMAD CMS - Form Audit Log
 *
 * Structured audit trail for the privacy-sensitive operations of the Forms
 * module, written through the existing LoggerService so entries show up in the
 * admin /logs viewer alongside everything else.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * WHAT IS DELIBERATELY *NOT* LOGGED
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * Never the decrypted values, and never any submitted field content. An audit
 * trail that quotes the data it is protecting just moves the personal data into
 * a plaintext log file - defeating the encryption it is auditing.
 *
 * Logged instead: who (user id + role), what action, which form, which
 * submission ids, how many rows, and a hashed IP. That is enough to answer
 * "who accessed this person's data and when" without duplicating the data.
 *
 * The actor's email is intentionally omitted too; the user id resolves to it
 * when an investigation actually needs it.
 *
 * @package NomadCMS\Services\Forms
 */

declare(strict_types=1);

namespace NomadCMS\Services\Forms;

use NomadCMS\Services\LoggerService;
use Throwable;

final class FormAuditLog
{
    public const ACTION_DECRYPT = 'forms.decrypt';
    public const ACTION_EXPORT = 'forms.export';
    public const ACTION_ERASE = 'forms.erase';
    public const ACTION_ENCRYPTION_ENABLED = 'forms.encryption_enabled';
    public const ACTION_ENCRYPTION_DISABLED = 'forms.encryption_disabled';
    public const ACTION_REINDEX = 'forms.reindex';
    public const ACTION_RETENTION = 'forms.retention_sweep';
    public const ACTION_FORM_DELETED = 'forms.form_deleted';
    public const ACTION_FILE_DOWNLOAD = 'forms.file_download';
    public const ACTION_FILE_DELETED = 'forms.file_deleted';
    public const ACTION_CAPTCHA_CHANGED = 'forms.captcha_changed';

    /**
     * A caller viewed decrypted submission values.
     *
     * @param object|array<string,mixed>|null $user
     * @param array<int, int> $submissionIds
     */
    public static function decrypt(object|array|null $user, ?string $formSlug, array $submissionIds): void
    {
        self::write(self::ACTION_DECRYPT, $user, [
            'form_slug' => $formSlug,
            'submission_ids' => array_slice(array_map('intval', $submissionIds), 0, 100),
            'count' => count($submissionIds),
        ]);
    }

    /**
     * A caller exported submissions to CSV.
     *
     * @param object|array<string,mixed>|null $user
     */
    public static function export(object|array|null $user, ?string $formSlug, int $rows, bool $decrypted): void
    {
        self::write(self::ACTION_EXPORT, $user, [
            'form_slug' => $formSlug,
            'rows' => $rows,
            // Whether the exported FILE contains personal data in the clear -
            // the single most important fact about an export.
            'decrypted' => $decrypted,
        ]);
    }

    /**
     * Submissions were permanently deleted (right to erasure).
     *
     * @param object|array<string,mixed>|null $user
     * @param array<int, int> $submissionIds
     */
    public static function erase(object|array|null $user, ?string $formSlug, array $submissionIds): void
    {
        self::write(self::ACTION_ERASE, $user, [
            'form_slug' => $formSlug,
            'submission_ids' => array_slice(array_map('intval', $submissionIds), 0, 100),
            'count' => count($submissionIds),
        ]);
    }

    /**
     * A form's encryption mode was switched.
     *
     * @param object|array<string,mixed>|null $user
     * @param array<string, mixed> $summary Migration summary (counts only)
     */
    public static function encryptionChanged(object|array|null $user, string $formSlug, bool $enabled, array $summary): void
    {
        self::write(
            $enabled ? self::ACTION_ENCRYPTION_ENABLED : self::ACTION_ENCRYPTION_DISABLED,
            $user,
            [
                'form_slug' => $formSlug,
                'converted' => (int) ($summary['converted'] ?? 0),
                'failed' => (int) ($summary['failed'] ?? 0),
                'remaining' => (int) ($summary['remaining'] ?? 0),
                'done' => (bool) ($summary['done'] ?? false),
            ]
        );
    }

    /**
     * Blind index rebuild after a searchable-field change.
     *
     * @param object|array<string,mixed>|null $user
     * @param array<string, mixed> $summary
     */
    public static function reindex(object|array|null $user, string $formSlug, array $summary): void
    {
        self::write(self::ACTION_REINDEX, $user, [
            'form_slug' => $formSlug,
            'reindexed' => (int) ($summary['reindexed'] ?? 0),
            'failed' => (int) ($summary['failed'] ?? 0),
        ]);
    }

    /**
     * A whole form (and therefore all of its submissions) was deleted.
     *
     * @param object|array<string,mixed>|null $user
     */
    /**
     * A caller downloaded an attachment.
     *
     * Recorded for EVERY download, encrypted or not: the file is personal data a
     * stranger uploaded, and knowing who fetched it is the point of the audit
     * trail. The filename is included because it is what identifies the file to a
     * human reading the log; the CONTENT never is.
     */
    public static function fileDownload(
        object|array|null $user,
        string $fileUuid,
        string $formSlug,
        string $filename,
        bool $encrypted
    ): void {
        self::write(self::ACTION_FILE_DOWNLOAD, $user, [
            'file_uuid' => $fileUuid,
            'form_slug' => $formSlug,
            'filename' => $filename,
            // Whether this download required (and used) forms:decrypt.
            'encrypted' => $encrypted,
        ]);
    }

    /**
     * An attachment was permanently deleted from the library.
     */
    public static function fileDeleted(
        object|array|null $user,
        string $fileUuid,
        string $formSlug,
        string $filename,
        int $sizeBytes
    ): void {
        self::write(self::ACTION_FILE_DELETED, $user, [
            'file_uuid' => $fileUuid,
            'form_slug' => $formSlug,
            'filename' => $filename,
            'size_bytes' => $sizeBytes,
        ]);
    }

    public static function formDeleted(object|array|null $user, string $formSlug, int $submissionsDeleted): void    {
        self::write(self::ACTION_FORM_DELETED, $user, [
            'form_slug' => $formSlug,
            'submissions_deleted' => $submissionsDeleted,
        ]);
    }

    /**
     * A form's captcha provider/key configuration was saved, and/or a global
     * provider's shared key pair was updated.
     *
     * Deliberately never logs the key value(s) themselves - only which
     * provider was chosen, whether custom keys are in use, and which (if any)
     * global provider's shared key pair was touched in the same request.
     *
     * $formSlug is null for a request that only touches a GLOBAL provider's
     * key pair (the standalone "Biztonság" page has no form to scope to).
     *
     * @param object|array<string,mixed>|null $user
     */
    public static function captchaChanged(
        object|array|null $user,
        ?string $formSlug,
        string $provider,
        bool $useCustomKeys,
        ?string $globalProviderChanged
    ): void {
        self::write(self::ACTION_CAPTCHA_CHANGED, $user, [
            'form_slug' => $formSlug,
            'provider' => $provider,
            'use_custom_keys' => $useCustomKeys,
            'global_provider_changed' => $globalProviderChanged,
        ]);
    }

    /**
     * Automatic retention sweep result. No actor - this runs unattended.
     *
     * @param array<string, mixed> $summary
     */
    public static function retention(array $summary): void
    {
        self::write(self::ACTION_RETENTION, null, [
            'deleted' => (int) ($summary['deleted'] ?? 0),
            'forms_scanned' => (int) ($summary['forms_scanned'] ?? 0),
            'per_form' => $summary['per_form'] ?? [],
        ]);
    }

    // =========================================================================
    // INTERNALS
    // =========================================================================

    /**
     * @param object|array<string,mixed>|null $user
     * @param array<string, mixed> $details
     */
    private static function write(string $action, object|array|null $user, array $details): void
    {
        $context = array_merge([
            'component' => 'forms',
            'audit' => true,
            'action' => $action,
            'user_id' => self::userId($user),
            'role_slug' => self::roleSlug($user),
            'ip_hash' => FormCrypto::hashIp($_SERVER['REMOTE_ADDR'] ?? null),
            'at' => gmdate('c'),
        ], $details);

        try {
            LoggerService::info('[FormsAudit] ' . $action, $context);
        } catch (Throwable $e) {
            // An audit write must never break the operation it audits, but it
            // must not vanish silently either.
            error_log('[FormsAudit] Failed to write audit entry for ' . $action . ': ' . $e->getMessage());
        }
    }

    /**
     * @param object|array<string,mixed>|null $user
     */
    private static function userId(object|array|null $user): ?int
    {
        if ($user === null) {
            return null;
        }

        $id = is_array($user) ? ($user['id'] ?? null) : ($user->id ?? null);

        return is_numeric($id) ? (int) $id : null;
    }

    /**
     * @param object|array<string,mixed>|null $user
     */
    private static function roleSlug(object|array|null $user): ?string
    {
        if ($user === null) {
            return null;
        }

        $role = is_array($user)
            ? ($user['role_slug'] ?? $user['role'] ?? null)
            : ($user->role_slug ?? $user->role ?? null);

        return is_string($role) && $role !== '' ? $role : null;
    }
}
