<?php
/**
 * NOMAD CMS - Form Validator
 *
 * Two independent responsibilities, deliberately kept in one class because
 * they must agree on the exact same rule set:
 *
 *  1. validateFieldDefinitions() - validates the field SCHEMA an admin builds
 *     in the form editor (types, bounds, options, regex safety).
 *  2. validateValues()           - validates a SUBMISSION against that schema,
 *     returning per-field error messages.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * WHY NOT InputSanitizer::string() FOR VALUES
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * InputSanitizer::string() HTML-escapes its input (htmlspecialchars). That is
 * correct for values echoed into HTML, but wrong for storage here: the admin
 * inbox and the CSV export render submitted values as TEXT (never as HTML), so
 * escaping at write time would permanently store "&amp;" and "&quot;" instead
 * of what the visitor actually typed. We therefore sanitize conservatively -
 * strip null bytes and control characters, enforce valid UTF-8, trim, cap
 * length - and rely on the consumers rendering as text.
 *
 * @package NomadCMS\Services\Forms
 */

declare(strict_types=1);

namespace NomadCMS\Services\Forms;

use NomadCMS\Security\InputSanitizer;

final class FormValidator
{
    /** Supported field types */
    public const TYPES = [
        'text',
        'textarea',
        'email',
        'tel',
        'url',
        'number',
        'date',
        'select',
        'radio',
        'checkbox',
        'hidden',
        'file',
    ];

    /** Types whose value comes from a fixed option list */
    private const OPTION_TYPES = ['select', 'radio'];

    /**
     * Types whose value does NOT arrive in the request body.
     *
     * A file lands in $_FILES, not $_POST, so the value validator must skip it
     * entirely - otherwise a required file field would fail on every submission
     * for the simple reason that its "value" is never in the values array.
     * Whether the file actually arrived is checked separately, against the
     * attachments (see assertRequiredFilesPresent).
     */
    public const NON_VALUE_TYPES = ['file'];

    /** Max number of options on a select/radio field */
    private const MAX_OPTIONS = 200;

    /** Max length of a single option value */
    private const MAX_OPTION_LENGTH = 200;

    /** Max length of an admin-authored regex pattern */
    private const MAX_PATTERN_LENGTH = 200;

    /** Regex delimiter used when applying admin patterns */
    private const PATTERN_DELIMITER = '~';

    // =========================================================================
    // FIELD DEFINITION VALIDATION (admin side)
    // =========================================================================

    /**
     * Validate and normalize an admin-authored field definition list.
     *
     * @param mixed $fields Raw value from the request (expected: list of objects)
     * @return array<int, array<string, mixed>> Normalized field definitions
     * @throws FormValidationException
     */
    public static function validateFieldDefinitions(mixed $fields): array
    {
        if ($fields === null || $fields === '') {
            return [];
        }

        if (!is_array($fields)) {
            throw new FormValidationException(['fields' => 'A mezőlistának tömbnek kell lennie.']);
        }

        if (count($fields) > FormsSchema::MAX_FIELDS) {
            throw new FormValidationException([
                'fields' => sprintf('Legfeljebb %d mező adható meg.', FormsSchema::MAX_FIELDS),
            ]);
        }

        $errors = [];
        $normalized = [];
        $seenNames = [];

        foreach (array_values($fields) as $index => $raw) {
            $prefix = "fields.$index";

            if (!is_array($raw)) {
                $errors[$prefix] = 'A meződefiníciónak objektumnak kell lennie.';
                continue;
            }

            $name = self::normalizeFieldName($raw['name'] ?? null);
            if ($name === null) {
                $errors["$prefix.name"] = 'A mező neve kötelező, és csak betűt, számot, kötőjelet vagy alulvonást tartalmazhat (max. 64 karakter).';
                continue;
            }

            if (isset($seenNames[$name])) {
                $errors["$prefix.name"] = sprintf('A "%s" mezőnév többször szerepel.', $name);
                continue;
            }
            $seenNames[$name] = true;

            $type = is_string($raw['type'] ?? null) ? strtolower(trim($raw['type'])) : 'text';
            if (!in_array($type, self::TYPES, true)) {
                $errors["$prefix.type"] = sprintf('Ismeretlen mezőtípus: "%s".', $type);
                continue;
            }

            $field = [
                'name' => $name,
                'label' => self::sanitizeText($raw['label'] ?? null, 200) ?? $name,
                'type' => $type,
                'required' => self::toBool($raw['required'] ?? false),
                'placeholder' => self::sanitizeText($raw['placeholder'] ?? null, 200),
                'help_text' => self::sanitizeText($raw['help_text'] ?? null, 500),
                'min_length' => null,
                'max_length' => null,
                'min' => null,
                'max' => null,
                'pattern' => null,
                'options' => null,
                // Blind index opt-in. Only meaningful when the form is encrypted.
                'searchable' => self::toBool($raw['searchable'] ?? false),
                // Marks the field as personal data - drives UI warnings and the
                // "values omitted" notification/webhook payloads.
                'pii' => self::toBool($raw['pii'] ?? false),
            ];

            // ── Length bounds (string-ish types) ─────────────────────────────
            $minLength = self::toNullableInt($raw['min_length'] ?? null);
            $maxLength = self::toNullableInt($raw['max_length'] ?? null);

            if ($minLength !== null && $minLength < 0) {
                $errors["$prefix.min_length"] = 'A minimum hossz nem lehet negatív.';
            }
            if ($maxLength !== null && $maxLength < 1) {
                $errors["$prefix.max_length"] = 'A maximum hossz legalább 1 legyen.';
            }
            if ($maxLength !== null && $maxLength > FormsSchema::MAX_VALUE_LENGTH) {
                $errors["$prefix.max_length"] = sprintf(
                    'A maximum hossz nem lehet nagyobb, mint %d.',
                    FormsSchema::MAX_VALUE_LENGTH
                );
            }
            if ($minLength !== null && $maxLength !== null && $minLength > $maxLength) {
                $errors["$prefix.min_length"] = 'A minimum hossz nem lehet nagyobb a maximumnál.';
            }
            $field['min_length'] = $minLength;
            $field['max_length'] = $maxLength;

            // ── Numeric bounds ───────────────────────────────────────────────
            $min = self::toNullableFloat($raw['min'] ?? null);
            $max = self::toNullableFloat($raw['max'] ?? null);
            if ($min !== null && $max !== null && $min > $max) {
                $errors["$prefix.min"] = 'A minimum érték nem lehet nagyobb a maximumnál.';
            }
            $field['min'] = $min;
            $field['max'] = $max;

            // ── Pattern ──────────────────────────────────────────────────────
            $pattern = is_string($raw['pattern'] ?? null) ? trim($raw['pattern']) : '';
            if ($pattern !== '') {
                $patternError = self::validatePattern($pattern);
                if ($patternError !== null) {
                    $errors["$prefix.pattern"] = $patternError;
                } else {
                    $field['pattern'] = $pattern;
                }
            }

            // ── Options ──────────────────────────────────────────────────────
            if (in_array($type, self::OPTION_TYPES, true)) {
                $options = self::normalizeOptions($raw['options'] ?? null);
                if ($options === null || count($options) === 0) {
                    $errors["$prefix.options"] = 'A választható értékek listája kötelező ennél a mezőtípusnál.';
                } elseif (count($options) > self::MAX_OPTIONS) {
                    $errors["$prefix.options"] = sprintf('Legfeljebb %d opció adható meg.', self::MAX_OPTIONS);
                } else {
                    $field['options'] = $options;
                }
            }

            // A checkbox is a boolean - length/numeric bounds make no sense
            if ($type === 'checkbox') {
                $field['min_length'] = null;
                $field['max_length'] = null;
                $field['min'] = null;
                $field['max'] = null;
                $field['pattern'] = null;
            }

            $normalized[] = $field;
        }

        if (!empty($errors)) {
            throw new FormValidationException($errors, 'A mezőséma érvénytelen.');
        }

        return $normalized;
    }

    /**
     * Validate an admin-authored regex pattern.
     *
     * Returns an error message, or null when the pattern is acceptable.
     *
     * Guards:
     * - length cap (an enormous pattern is a red flag on its own)
     * - must not contain the delimiter we wrap it with, so it cannot break out
     *   and inject modifiers (notably it can never smuggle in /e)
     * - must compile under PCRE
     * - heuristic rejection of nested quantifiers such as (a+)+ or ([a-z]*)* ,
     *   the classic catastrophic-backtracking (ReDoS) shape
     */
    public static function validatePattern(string $pattern): ?string
    {
        if (strlen($pattern) > self::MAX_PATTERN_LENGTH) {
            return sprintf('A minta túl hosszú (max. %d karakter).', self::MAX_PATTERN_LENGTH);
        }

        if (str_contains($pattern, self::PATTERN_DELIMITER)) {
            return 'A minta nem tartalmazhat "' . self::PATTERN_DELIMITER . '" karaktert.';
        }

        // Nested quantifier heuristic: a quantified group that is itself quantified.
        if (preg_match('/\([^()]*[*+][^()]*\)\s*[*+{]/', $pattern) === 1) {
            return 'A minta egymásba ágyazott ismétlést tartalmaz, ami végtelen futáshoz vezethet (ReDoS).';
        }

        $compiled = @preg_match(self::wrapPattern($pattern), '');
        if ($compiled === false) {
            return 'A minta nem érvényes reguláris kifejezés.';
        }

        return null;
    }

    // =========================================================================
    // SUBMISSION VALUE VALIDATION (public side)
    // =========================================================================

    /**
     * Validate submitted values against a form's field definitions.
     *
     * @param array<string, mixed> $values Raw submitted key/value pairs
     * @param array<int, array<string, mixed>> $fields Normalized field definitions
     * @param bool $strictSchema When true, unknown keys are rejected. When false
     *                           (Formspree-like default) any extra field is kept.
     * @return array<string, string|int|float|bool|null> Normalized values
     * @throws FormValidationException
     */
    /**
     * Verify that every REQUIRED file field actually received a file.
     *
     * Kept out of validateValues() because the two look at different places: the
     * values come from the request body, the files from $_FILES via the
     * attachment service. Running this after the attachments are stored means a
     * missing required file fails the submission (and the caller rolls the stored
     * files back), rather than producing a submission with a silently absent CV.
     *
     * @param array<int, array<string, mixed>> $fields Form field definitions
     * @param array<int, array<string, mixed>> $storedAttachments Descriptors from FormAttachmentService::intake()
     * @throws FormValidationException When a required file field has no file
     */
    public static function assertRequiredFilesPresent(array $fields, array $storedAttachments): void
    {
        $errors = [];

        // Which field each uploaded file arrived in. An <input name="cv"> and an
        // <input name="cv[]"> both report "cv".
        $fieldsWithFiles = [];
        foreach ($storedAttachments as $file) {
            $fieldName = $file['field_name'] ?? null;
            if (is_string($fieldName) && $fieldName !== '') {
                $fieldsWithFiles[$fieldName] = true;
            }
        }

        foreach ($fields as $field) {
            if (($field['type'] ?? '') !== 'file' || !($field['required'] ?? false)) {
                continue;
            }

            $name = (string) ($field['name'] ?? '');
            if ($name === '' || isset($fieldsWithFiles[$name])) {
                continue;
            }

            // Tolerate the generic input name too: an embed that was hand-edited
            // to use name="attachment" still satisfies a single required file
            // field, rather than rejecting a submission whose file plainly arrived.
            if (isset($fieldsWithFiles['attachment'])) {
                continue;
            }

            $errors[$name] = self::requiredMessage($field);
        }

        if (!empty($errors)) {
            throw new FormValidationException($errors, 'Kötelező fájl nincs csatolva.');
        }
    }

    /**
     * Field names of type `file` in a definition.
     *
     * @param array<int, array<string, mixed>> $fields
     * @return array<int, string>
     */
    public static function fileFieldNames(array $fields): array
    {
        $names = [];

        foreach ($fields as $field) {
            if (($field['type'] ?? '') === 'file' && is_string($field['name'] ?? null)) {
                $names[] = (string) $field['name'];
            }
        }

        return $names;
    }

    public static function validateValues(array $values, array $fields, bool $strictSchema = false): array
    {
        $errors = [];
        $result = [];

        $definedNames = [];
        foreach ($fields as $field) {
            $definedNames[$field['name']] = $field;
        }

        // ── Defined fields ───────────────────────────────────────────────────
        foreach ($definedNames as $name => $field) {
            // A file field has no value in the request body; its presence is
            // verified against the uploaded attachments instead.
            if (in_array($field['type'], self::NON_VALUE_TYPES, true)) {
                continue;
            }

            $present = array_key_exists($name, $values);
            $raw = $present ? $values[$name] : null;

            if ($field['type'] === 'checkbox') {
                $checked = self::toBool($raw);
                if ($field['required'] && !$checked) {
                    $errors[$name] = self::requiredMessage($field);
                    continue;
                }
                $result[$name] = $checked;
                continue;
            }

            $scalar = self::toScalarString($raw);

            if ($scalar === null || $scalar === '') {
                if ($field['required']) {
                    $errors[$name] = self::requiredMessage($field);
                } else {
                    $result[$name] = null;
                }
                continue;
            }

            $error = self::validateSingleValue($scalar, $field);
            if ($error !== null) {
                $errors[$name] = $error;
                continue;
            }

            $result[$name] = self::castValue($scalar, $field);
        }

        // ── Undefined (extra) fields ─────────────────────────────────────────
        foreach ($values as $key => $raw) {
            if (isset($definedNames[$key])) {
                continue;
            }

            $normalizedKey = self::normalizeFieldName($key);
            if ($normalizedKey === null) {
                // A key we cannot even safely represent is always rejected,
                // regardless of strict mode.
                $errors[(string) $key] = 'Érvénytelen mezőnév.';
                continue;
            }

            if ($strictSchema) {
                $errors[$normalizedKey] = 'Ismeretlen mező.';
                continue;
            }

            if (is_array($raw)) {
                // Multi-value inputs (e.g. name="tags[]") are flattened to a
                // comma separated string so the inbox and CSV stay flat.
                $parts = [];
                foreach ($raw as $item) {
                    $s = self::toScalarString($item);
                    if ($s !== null && $s !== '') {
                        $parts[] = $s;
                    }
                }
                $result[$normalizedKey] = self::sanitizeText(implode(', ', $parts), FormsSchema::MAX_VALUE_LENGTH);
                continue;
            }

            $scalar = self::toScalarString($raw);
            $result[$normalizedKey] = $scalar === null
                ? null
                : self::sanitizeText($scalar, FormsSchema::MAX_VALUE_LENGTH);
        }

        if (count($result) > FormsSchema::MAX_FIELDS) {
            throw new FormValidationException([
                '_form' => sprintf('Túl sok mező a beküldésben (max. %d).', FormsSchema::MAX_FIELDS),
            ]);
        }

        if (!empty($errors)) {
            throw new FormValidationException($errors);
        }

        return $result;
    }

    /**
     * Type/bounds check for a single non-empty scalar value.
     * Returns an error message or null when valid.
     *
     * @param array<string, mixed> $field
     */
    private static function validateSingleValue(string $value, array $field): ?string
    {
        $label = (string) ($field['label'] ?? $field['name']);

        switch ($field['type']) {
            case 'email':
                if (InputSanitizer::email($value) === null) {
                    return sprintf('A(z) "%s" mező nem érvényes e-mail cím.', $label);
                }
                break;

            case 'url':
                $url = filter_var($value, FILTER_VALIDATE_URL);
                if ($url === false || !preg_match('#^https?://#i', $value)) {
                    return sprintf('A(z) "%s" mező nem érvényes URL (http/https).', $label);
                }
                break;

            case 'tel':
                if (!preg_match('/^[0-9+()\-.\s]{4,32}$/', $value)) {
                    return sprintf('A(z) "%s" mező nem érvényes telefonszám.', $label);
                }
                break;

            case 'number':
                if (!is_numeric($value)) {
                    return sprintf('A(z) "%s" mező csak számot tartalmazhat.', $label);
                }
                $num = (float) $value;
                if ($field['min'] !== null && $num < (float) $field['min']) {
                    return sprintf('A(z) "%s" mező legalább %s legyen.', $label, self::formatNumber((float) $field['min']));
                }
                if ($field['max'] !== null && $num > (float) $field['max']) {
                    return sprintf('A(z) "%s" mező legfeljebb %s legyen.', $label, self::formatNumber((float) $field['max']));
                }
                break;

            case 'date':
                if (!self::isValidDate($value)) {
                    return sprintf('A(z) "%s" mező nem érvényes dátum (ÉÉÉÉ-HH-NN).', $label);
                }
                break;

            case 'select':
            case 'radio':
                $options = is_array($field['options']) ? $field['options'] : [];
                if (!in_array($value, $options, true)) {
                    return sprintf('A(z) "%s" mezőben nem választható érték szerepel.', $label);
                }
                break;

            default:
                // text / textarea / hidden - only generic checks below
                break;
        }

        // Generic length bounds (mb-aware so accented characters count as one)
        $length = mb_strlen($value, 'UTF-8');
        if ($field['min_length'] !== null && $length < (int) $field['min_length']) {
            return sprintf('A(z) "%s" mező legalább %d karakter legyen.', $label, (int) $field['min_length']);
        }
        $maxLength = $field['max_length'] !== null
            ? (int) $field['max_length']
            : FormsSchema::MAX_VALUE_LENGTH;
        if ($length > $maxLength) {
            return sprintf('A(z) "%s" mező legfeljebb %d karakter lehet.', $label, $maxLength);
        }

        // Admin-authored pattern
        if (!empty($field['pattern'])) {
            $matched = @preg_match(self::wrapPattern((string) $field['pattern']), $value);
            if ($matched !== 1) {
                return sprintf('A(z) "%s" mező nem felel meg az elvárt formátumnak.', $label);
            }
        }

        return null;
    }

    /**
     * Cast a validated value to its storage representation.
     *
     * Never returns bool: checkbox fields are handled earlier in
     * validateValues() and never reach this method.
     *
     * @param array<string, mixed> $field
     * @return string|int|float|null
     */
    private static function castValue(string $value, array $field): string|int|float|null
    {
        if ($field['type'] === 'number') {
            // Keep integers as int so CSV/JSON do not show "5.0"
            return str_contains($value, '.') || str_contains($value, ',')
                ? (float) str_replace(',', '.', $value)
                : (int) $value;
        }

        if ($field['type'] === 'email') {
            return InputSanitizer::email($value) ?? $value;
        }

        $max = $field['max_length'] !== null
            ? (int) $field['max_length']
            : FormsSchema::MAX_VALUE_LENGTH;

        return self::sanitizeText($value, $max);
    }

    // =========================================================================
    // PAYLOAD CEILINGS
    // =========================================================================

    /**
     * Enforce hard payload ceilings BEFORE any per-field work.
     *
     * These are unconditional, independent of the form definition: an
     * unauthenticated endpoint must bound its own work.
     *
     * @param array<string, mixed> $values
     * @throws FormValidationException
     */
    public static function enforceCeilings(array $values): void
    {
        if (count($values) > FormsSchema::MAX_FIELDS) {
            throw new FormValidationException([
                '_form' => sprintf('Túl sok mező a beküldésben (max. %d).', FormsSchema::MAX_FIELDS),
            ]);
        }

        foreach ($values as $key => $value) {
            if (strlen((string) $key) > FormsSchema::MAX_KEY_LENGTH) {
                throw new FormValidationException([
                    '_form' => sprintf('Túl hosszú mezőnév (max. %d karakter).', FormsSchema::MAX_KEY_LENGTH),
                ]);
            }

            $flat = is_array($value) ? implode('', array_map(fn($v) => (string) (is_scalar($v) ? $v : ''), $value)) : (string) (is_scalar($value) || $value === null ? $value : '');
            if (mb_strlen($flat, 'UTF-8') > FormsSchema::MAX_VALUE_LENGTH) {
                throw new FormValidationException([
                    (string) $key => sprintf('Túl hosszú érték (max. %d karakter).', FormsSchema::MAX_VALUE_LENGTH),
                ]);
            }
        }
    }

    // =========================================================================
    // HELPERS
    // =========================================================================

    /**
     * Wrap an admin pattern into a full PCRE expression.
     * Only the /u modifier is added - never /e (removed in PHP 7 anyway) and
     * never /x, so whitespace in the pattern keeps its literal meaning.
     */
    private static function wrapPattern(string $pattern): string
    {
        return self::PATTERN_DELIMITER . $pattern . self::PATTERN_DELIMITER . 'u';
    }

    /**
     * Normalize a field name to a safe key, or null when unusable.
     */
    public static function normalizeFieldName(mixed $name): ?string
    {
        if (!is_string($name)) {
            return null;
        }

        $name = trim($name);
        // HTML array notation is common in hand-written forms ("tags[]")
        $name = preg_replace('/\[\]$/', '', $name) ?? $name;

        if ($name === '' || strlen($name) > FormsSchema::MAX_KEY_LENGTH) {
            return null;
        }

        if (!preg_match('/^[A-Za-z0-9_\-]+$/', $name)) {
            return null;
        }

        return $name;
    }

    /**
     * Conservative text sanitization for stored values.
     * Strips null bytes and control characters (keeping newlines and tabs),
     * enforces valid UTF-8, trims, and caps the length.
     */
    public static function sanitizeText(mixed $value, int $maxLength): ?string
    {
        if ($value === null) {
            return null;
        }
        if (!is_scalar($value)) {
            return null;
        }

        $text = (string) $value;

        // Drop invalid UTF-8 sequences rather than storing broken bytes
        if (!mb_check_encoding($text, 'UTF-8')) {
            $text = mb_convert_encoding($text, 'UTF-8', 'UTF-8');
        }

        $text = str_replace("\0", '', $text);
        // Remove control chars except tab (09), LF (0A) and CR (0D)
        $text = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/u', '', $text) ?? '';
        // Normalize line endings
        $text = str_replace(["\r\n", "\r"], "\n", $text);
        $text = trim($text);

        if ($text === '') {
            return '';
        }

        return mb_substr($text, 0, $maxLength, 'UTF-8');
    }

    /**
     * @param array<string, mixed> $field
     */
    private static function requiredMessage(array $field): string
    {
        return sprintf('A(z) "%s" mező kitöltése kötelező.', (string) ($field['label'] ?? $field['name']));
    }

    private static function toScalarString(mixed $value): ?string
    {
        if ($value === null) {
            return null;
        }
        if (is_bool($value)) {
            return $value ? '1' : '';
        }
        if (is_array($value)) {
            // Only the first scalar is considered for a DEFINED field; extra
            // fields get the flattened treatment in validateValues().
            foreach ($value as $item) {
                if (is_scalar($item)) {
                    return trim((string) $item);
                }
            }
            return null;
        }
        if (!is_scalar($value)) {
            return null;
        }

        return trim((string) $value);
    }

    public static function toBool(mixed $value): bool
    {
        if (is_bool($value)) {
            return $value;
        }
        if (is_string($value)) {
            return in_array(strtolower(trim($value)), ['1', 'true', 'on', 'yes', 'igen'], true);
        }
        if (is_numeric($value)) {
            return (float) $value !== 0.0;
        }

        return false;
    }

    private static function toNullableInt(mixed $value): ?int
    {
        if ($value === null || $value === '') {
            return null;
        }
        if (!is_numeric($value)) {
            return null;
        }

        return (int) $value;
    }

    private static function toNullableFloat(mixed $value): ?float
    {
        if ($value === null || $value === '') {
            return null;
        }
        if (!is_numeric($value)) {
            return null;
        }

        return (float) $value;
    }

    /**
     * @return array<int, string>|null
     */
    private static function normalizeOptions(mixed $options): ?array
    {
        if (!is_array($options)) {
            return null;
        }

        $result = [];
        foreach ($options as $option) {
            // Accept both ["a","b"] and [{value:"a"},{value:"b"}]
            if (is_array($option)) {
                $option = $option['value'] ?? $option['label'] ?? null;
            }
            if (!is_scalar($option)) {
                continue;
            }
            $clean = self::sanitizeText($option, self::MAX_OPTION_LENGTH);
            if ($clean !== null && $clean !== '' && !in_array($clean, $result, true)) {
                $result[] = $clean;
            }
        }

        return $result;
    }

    private static function isValidDate(string $value): bool
    {
        // Accept date (Y-m-d) and datetime-local (Y-m-d\TH:i[:s])
        $formats = ['Y-m-d', 'Y-m-d\TH:i', 'Y-m-d\TH:i:s'];
        foreach ($formats as $format) {
            $dt = \DateTimeImmutable::createFromFormat($format, $value);
            if ($dt !== false && $dt->format($format) === $value) {
                return true;
            }
        }

        return false;
    }

    private static function formatNumber(float $number): string
    {
        return $number === floor($number)
            ? (string) (int) $number
            : rtrim(rtrim(number_format($number, 4, '.', ''), '0'), '.');
    }
}
