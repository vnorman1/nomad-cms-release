<?php
/**
 * NOMAD CMS - Captcha Exception
 *
 * Raised by the captcha config store and verifier for failures that must map
 * to a specific HTTP status/code on the public and admin endpoints, mirroring
 * the pattern used by FormFileException/FormValidationException elsewhere in
 * this module.
 *
 * @package NomadCMS\Services\Forms
 */

declare(strict_types=1);

namespace NomadCMS\Services\Forms;

class CaptchaException extends \RuntimeException
{
    private int $statusCode;

    private string $errorCode;

    public function __construct(string $message, int $statusCode = 400, string $errorCode = 'CAPTCHA_ERROR')
    {
        parent::__construct($message);

        $this->statusCode = $statusCode;
        $this->errorCode = $errorCode;
    }

    public function getStatusCode(): int
    {
        return $this->statusCode;
    }

    public function getErrorCode(): string
    {
        return $this->errorCode;
    }

    /** The visitor submitted no captcha token at all. */
    public static function required(): self
    {
        return new self('Kérjük, igazold, hogy nem vagy robot!', 400, 'CAPTCHA_REQUIRED');
    }

    /** The provider rejected the token (success !== true, or score too low). */
    public static function failed(): self
    {
        return new self('Sikertelen captcha ellenőrzés.', 400, 'CAPTCHA_FAILED');
    }

    /** Enabling/configuring captcha was attempted without ENCRYPTION_KEY. */
    public static function encryptionUnavailable(): self
    {
        return new self(
            'A captcha titkos kulcs nem menthető: nincs beállítva ENCRYPTION_KEY a szerveren.',
            503,
            'ENCRYPTION_UNAVAILABLE'
        );
    }

    /** The captcha config store (system.sqlite) is unreadable/unwritable. */
    public static function storeError(string $message): self
    {
        return new self($message, 500, 'CAPTCHA_STORE_ERROR');
    }
}
