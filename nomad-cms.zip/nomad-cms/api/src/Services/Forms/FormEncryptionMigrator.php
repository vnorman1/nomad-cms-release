<?php
/**
 * NOMAD CMS - Form Encryption Migrator
 *
 * Switches an EXISTING form between plaintext and encrypted storage, migrating
 * every submission already on disk.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * WHY THIS IS NOT JUST A SETTINGS FLIP
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * Flipping `settings.encryption.enabled` only affects FUTURE submissions. Every
 * lead collected before the flip would stay readable in the database while the
 * admin UI shows a padlock - the worst kind of security claim: a false one.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * SAFETY PROPERTIES
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * - IDEMPOTENT: rows are selected by their current `encrypted` flag, so rows
 *   already in the target state are never touched. An interrupted run can
 *   simply be started again.
 * - BATCHED: work is capped per call, so a form with 100k submissions cannot
 *   time out a request. The caller loops until `remaining` reaches 0.
 * - PER-ROW TRANSACTION: the envelope and its search index row are updated
 *   together, so a crash cannot leave a row whose index still holds plaintext
 *   while the values are encrypted.
 * - FAIL-CLOSED: encryption requires a working key up front; a row that cannot
 *   be processed is counted as failed and left untouched rather than rewritten
 *   into an unknown state.
 *
 * DECRYPTION (the reverse direction) turns personal data back into readable
 * plaintext on disk. Callers must require BOTH forms:decrypt:* and
 * forms:update:*, confirm with the user, and write an audit entry.
 *
 * @package NomadCMS\Services\Forms
 */

declare(strict_types=1);

namespace NomadCMS\Services\Forms;

use Throwable;

final class FormEncryptionMigrator
{
    /** Default number of submissions processed per call */
    public const DEFAULT_BATCH = 200;

    /** Hard cap so a caller cannot request unbounded work */
    public const MAX_BATCH = 2000;

    /**
     * Turn encryption ON for a form and encrypt its existing submissions.
     *
     * @return array{
     *     slug:string, direction:string, processed:int, converted:int,
     *     failed:int, remaining:int, done:bool, errors:array<int,string>
     * }
     * @throws FormNotFoundException|FormValidationException|FormCryptoException
     */
    public static function enable(string $slug, int $batchSize = self::DEFAULT_BATCH): array
    {
        if (!FormCrypto::isAvailable()) {
            throw new FormCryptoException(
                'A titkosítás nem kapcsolható be: nincs beállítva ENCRYPTION_KEY a szerveren.'
            );
        }

        $form = FormService::requireBySlug($slug);

        // Update the definition FIRST: from this moment new submissions arrive
        // encrypted, so the migration cannot race with incoming traffic and
        // leave freshly written plaintext rows behind.
        if (!FormService::isEncrypted($form)) {
            FormService::update($slug, ['settings' => ['encryption' => ['enabled' => true]]]);
            $form = FormService::requireBySlug($slug);
        }

        return self::migrate($form, true, $batchSize);
    }

    /**
     * Turn encryption OFF for a form and decrypt its existing submissions.
     *
     * @return array{
     *     slug:string, direction:string, processed:int, converted:int,
     *     failed:int, remaining:int, done:bool, errors:array<int,string>
     * }
     * @throws FormNotFoundException|FormValidationException
     */
    public static function disable(string $slug, int $batchSize = self::DEFAULT_BATCH): array
    {
        $form = FormService::requireBySlug($slug);

        // Decrypt the rows BEFORE flipping the flag off: if the process dies
        // half way, the remaining rows are still encrypted AND the definition
        // still says encrypted, which is a consistent state.
        $result = self::migrate($form, false, $batchSize);

        if ($result['done'] && FormService::isEncrypted($form)) {
            FormService::update($slug, ['settings' => ['encryption' => ['enabled' => false]]]);
        }

        return $result;
    }

    /**
     * Re-index an encrypted form after its `searchable` field selection changed.
     *
     * Blind index tokens are derived from the field selection, so adding or
     * removing a searchable field leaves the existing index stale (old rows
     * would not be findable, or would stay findable by a field the admin just
     * un-marked). This rebuilds the FTS rows without touching the ciphertext.
     *
     * @return array{slug:string, reindexed:int, failed:int, errors:array<int,string>}
     * @throws FormNotFoundException
     */
    public static function reindex(string $slug, int $batchSize = self::DEFAULT_BATCH): array
    {
        $form = FormService::requireBySlug($slug);
        $batchSize = max(1, min(self::MAX_BATCH, $batchSize));
        $encrypted = FormService::isEncrypted($form);

        $ids = FormSubmissionRepository::idsForFormSlugByEncryption($slug, $encrypted, $batchSize);

        $reindexed = 0;
        $failed = 0;
        $errors = [];

        foreach ($ids as $id) {
            try {
                $row = FormSubmissionRepository::findById($id);
                if ($row === null) {
                    continue;
                }

                $values = self::readValues($row['data']);
                $content = FormSubmissionService::buildIndexContent($form, $values, $encrypted);
                FormSubmissionRepository::writeIndexRow($id, $content);
                $reindexed++;
            } catch (Throwable $e) {
                $failed++;
                $errors[] = sprintf('#%d: %s', $id, $e->getMessage());
            }
        }

        return ['slug' => $slug, 'reindexed' => $reindexed, 'failed' => $failed, 'errors' => $errors];
    }

    /**
     * Report how much work a switch would involve, without doing any.
     *
     * @return array{slug:string, encrypted:bool, plaintext_rows:int, encrypted_rows:int}
     * @throws FormNotFoundException
     */
    public static function status(string $slug): array
    {
        $form = FormService::requireBySlug($slug);

        return [
            'slug' => $slug,
            'encrypted' => FormService::isEncrypted($form),
            'plaintext_rows' => count(FormSubmissionRepository::idsForFormSlugByEncryption($slug, false, self::MAX_BATCH)),
            'encrypted_rows' => count(FormSubmissionRepository::idsForFormSlugByEncryption($slug, true, self::MAX_BATCH)),
        ];
    }

    // =========================================================================
    // INTERNALS
    // =========================================================================

    /**
     * Convert one batch of submissions into the target state.
     *
     * @param array<string, mixed> $form
     * @return array{
     *     slug:string, direction:string, processed:int, converted:int,
     *     failed:int, remaining:int, done:bool, errors:array<int,string>
     * }
     */
    private static function migrate(array $form, bool $toEncrypted, int $batchSize): array
    {
        $slug = (string) ($form['data']['slug'] ?? '');
        $batchSize = max(1, min(self::MAX_BATCH, $batchSize));

        // Select rows still in the SOURCE state - this is what makes the whole
        // operation idempotent and restartable.
        $ids = FormSubmissionRepository::idsForFormSlugByEncryption($slug, !$toEncrypted, $batchSize);

        $converted = 0;
        $failed = 0;
        $errors = [];

        foreach ($ids as $id) {
            try {
                self::convertRow($form, $id, $toEncrypted);
                $converted++;
            } catch (Throwable $e) {
                $failed++;
                $errors[] = sprintf('#%d: %s', $id, $e->getMessage());
            }
        }

        $remaining = count(
            FormSubmissionRepository::idsForFormSlugByEncryption($slug, !$toEncrypted, self::MAX_BATCH)
        );

        return [
            'slug' => $slug,
            'direction' => $toEncrypted ? 'encrypt' : 'decrypt',
            'processed' => count($ids),
            'converted' => $converted,
            'failed' => $failed,
            'remaining' => $remaining,
            // Rows that keep failing would otherwise make `done` never true and
            // spin the caller's loop forever, so failures also end the run.
            'done' => $remaining === 0 || ($converted === 0 && $failed > 0),
            'errors' => $errors,
        ];
    }

    /**
     * Convert a single submission row, envelope + index together.
     *
     * @param array<string, mixed> $form
     * @throws FormCryptoException
     */
    private static function convertRow(array $form, int $id, bool $toEncrypted): void
    {
        $row = FormSubmissionRepository::findById($id);
        if ($row === null) {
            return;
        }

        $envelope = $row['data'];
        $alreadyEncrypted = (bool) ($envelope['encrypted'] ?? false);
        if ($alreadyEncrypted === $toEncrypted) {
            return; // Nothing to do - keeps re-runs cheap
        }

        $values = self::readValues($envelope);

        $db = FormsSchema::db();
        $ownsTransaction = !$db->inTransaction();
        if ($ownsTransaction) {
            $db->beginTransaction();
        }

        try {
            if ($toEncrypted) {
                $envelope['encrypted'] = true;
                $envelope['enc_version'] = FormsSchema::ENC_VERSION;
                $envelope['values_encrypted'] = FormCrypto::sealValues($values);
                // The plaintext copy MUST go, otherwise the row would still be
                // readable while claiming to be encrypted.
                unset($envelope['values']);
            } else {
                $envelope['encrypted'] = false;
                $envelope['values'] = $values;
                unset($envelope['values_encrypted'], $envelope['enc_version']);
            }

            FormSubmissionRepository::updateEnvelope($id, $envelope);
            FormSubmissionRepository::writeIndexRow(
                $id,
                FormSubmissionService::buildIndexContent($form, $values, $toEncrypted)
            );

            if ($ownsTransaction) {
                $db->commit();
            }
        } catch (Throwable $e) {
            if ($ownsTransaction && $db->inTransaction()) {
                $db->rollBack();
            }
            throw $e;
        }
    }

    /**
     * Read a submission's values regardless of its current storage mode.
     *
     * @param array<string, mixed> $envelope
     * @return array<string, mixed>
     * @throws FormCryptoException
     */
    private static function readValues(array $envelope): array
    {
        if (!empty($envelope['encrypted'])) {
            return FormCrypto::openValues((string) ($envelope['values_encrypted'] ?? ''));
        }

        return is_array($envelope['values'] ?? null) ? $envelope['values'] : [];
    }
}
