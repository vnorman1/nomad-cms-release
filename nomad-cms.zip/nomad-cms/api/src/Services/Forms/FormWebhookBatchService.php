<?php
/**
 * NOMAD CMS - Form Webhook Batch Service
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * WHY THIS EXISTS
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * Without batching, a burst of submissions to the same form (a re-shared
 * embed link, a mass-test, a bot spike) means one webhook HTTP delivery PER
 * submission. Each delivery is already non-blocking (dispatchEventAsync()
 * only inserts a row; the actual cURL call happens in the piggyback shutdown
 * hook - see WebhookQueueService), so a burst does not stall the visitor's
 * own request. What it DOES do is hammer the destination with N separate
 * calls carrying the same event, which is exactly the "many small deliveries"
 * problem FormNotificationBatchService already solves for e-mail.
 *
 * This mirrors that service's adaptive-window idea, but for a fundamentally
 * different payload shape: the e-mail batch only ever needed a COUNT (the
 * message never includes values). A webhook subscriber that opted into
 * batching wants the actual submissions - so this service collects full
 * payloads into a JSON array per batch row, not just a counter.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * THE ADAPTIVE WINDOW
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * The FIRST submission against an idle batch key opens a window of
 * MIN_WINDOW_SECONDS (30s). Every ADDITIONAL submission that lands while the
 * window is open extends it by EXTEND_SECONDS_PER_SUBMISSION (5s), capped at
 * MAX_WINDOW_SECONDS (300s / 5 minutes) measured from when the window opened.
 * A single occasional submission is delivered within 30 seconds; a sustained
 * burst is bounded to one delivery at least every 5 minutes, no matter how
 * long the burst continues.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * HARD CAP: WHY A BATCH CANNOT GROW WITHOUT BOUND
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * WebhookService::MAX_PAYLOAD_SIZE caps any outgoing body at 1MB. An
 * uninterrupted flood (thousands of submissions inside one open window) would
 * eventually produce a batch payload that either exceeds that limit outright
 * (delivery refused) or is technically under it but absurdly large for a
 * single HTTP call. MAX_BATCH_SUBMISSIONS (200) is a hard cap independent of
 * the time window: the moment a batch reaches this many queued submissions,
 * it is flushed immediately and a fresh window opens for whatever arrives
 * next - trading "one batch might arrive slightly early" for "a batch can
 * never spike the payload size or memory footprint unboundedly".
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * GLOBAL VS PER-FORM BATCHING
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * A webhook subscribed to form.submitted chooses (WebhookService::
 * FORMS_BATCH_MODES) whether its batches are:
 *   - 'per_form': one independent window PER form slug, so a burst on form A
 *     never delays or mixes into form B's batch for the SAME webhook.
 *   - 'global':   one shared window covering every form, for a webhook that
 *     just wants "how many submissions arrived across everything" without
 *     caring about per-form boundaries.
 * This is a property of the WEBHOOK, not the form - two webhooks can watch
 * the same form and batch it differently. The batch row is therefore keyed on
 * (webhook_id, batch_key), where batch_key is either the form slug
 * (per_form) or the literal string GLOBAL_BATCH_KEY (global).
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * VALUES ARE GATED THE SAME WAY AS THE NON-BATCHED PATH
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * Each submission recorded here already went through
 * FormNotifier::buildWebhookPayload(), which withholds `values`/`field_names`
 * unless the form is both unencrypted AND strict_schema. A batch of such
 * "metadata only" payloads would still name every field key if collected
 * naively - so the flushed body distinguishes the two cases explicitly:
 * either an array of full per-submission payloads, or (when NONE of the
 * batch's submissions were allowed to expose values) a bare
 * {count, form_slug|batch_key} summary with no per-submission detail at all.
 * A batch is never a mix of the two: which shape it takes is decided once,
 * from the first submission recorded into a fresh window, and every
 * following submission in that window must have come from the same
 * strict/non-encrypted form (per_form mode) - or, in global mode, the
 * MINIMUM permission across every form that fed the batch, since one
 * unreviewed form must not upgrade another form's summary-only submissions
 * into detailed ones just by sharing a batch window.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * TWO FLUSH PATHS, NEITHER ALONE ENOUGH
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *   1. IMMEDIATE (FormNotifier::dispatchWebhook(), called from the submit
 *      endpoint): after recording this submission, flush this exact
 *      (webhook_id, batch_key) row if it just became due. Keeps a steadily
 *      (but not rapidly) submitted form's webhook prompt.
 *   2. SAFETY NET (bootstrap.php's piggyback shutdown handler): sweep every
 *      due batch across all webhooks/keys. Guarantees delivery for a batch
 *      that received exactly one submission and then went quiet - nothing
 *      will call flushIfDue() for that exact key again.
 *
 * @package NomadCMS\Services\Forms
 */

declare(strict_types=1);

namespace NomadCMS\Services\Forms;

use NomadCMS\Database\AuthDatabase;
use NomadCMS\Security\WebhookService;
use PDO;
use Throwable;

final class FormWebhookBatchService
{
    public const TABLE = 'webhook_form_batches';

    /** Batch key used for FORMS_BATCH_GLOBAL mode (not a valid form slug). */
    public const GLOBAL_BATCH_KEY = '__global__';

    /** Every idle-started window opens at this length. */
    private const MIN_WINDOW_SECONDS = 30;

    /** Each additional submission during an open window adds this much. */
    private const EXTEND_SECONDS_PER_SUBMISSION = 5;

    /** No window may be extended past this total length. */
    private const MAX_WINDOW_SECONDS = 300; // 5 minutes

    /**
     * Hard cap: a batch is flushed immediately once it reaches this many
     * submissions, regardless of how much time is left in its window. Keeps
     * an uninterrupted flood from producing one unbounded payload.
     */
    private const MAX_BATCH_SUBMISSIONS = 200;

    private static bool $tableReady = false;

    /**
     * Create the pending-batch table on demand.
     */
    public static function ensureTable(): void
    {
        if (self::$tableReady) {
            return;
        }

        $db = AuthDatabase::getInstance();
        $db->exec('
            CREATE TABLE IF NOT EXISTS ' . self::TABLE . ' (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                webhook_id INTEGER NOT NULL,
                batch_key TEXT NOT NULL,
                submission_count INTEGER NOT NULL DEFAULT 0,
                can_expose_values INTEGER NOT NULL DEFAULT 1,
                submissions_json TEXT NOT NULL DEFAULT \'[]\',
                form_slugs_json TEXT NOT NULL DEFAULT \'[]\',
                window_started_at INTEGER NOT NULL,
                flush_after INTEGER NOT NULL,
                UNIQUE(webhook_id, batch_key)
            )
        ');
        $db->exec(
            'CREATE INDEX IF NOT EXISTS idx_' . self::TABLE . '_flush_after ON ' . self::TABLE . '(flush_after)'
        );

        self::$tableReady = true;
    }

    /**
     * Record one submission's webhook payload against a (webhook, batch_key)
     * batch, opening a new window if none is currently open.
     *
     * Never sends anything itself - see flushIfDue()/flushAllDue().
     *
     * @param int $webhookId
     * @param string $batchKey Form slug (per_form mode) or GLOBAL_BATCH_KEY (global mode)
     * @param string $formSlug The submitting form's own slug, recorded even
     *                          in global mode (so the eventual summary/detail
     *                          body can list which forms contributed)
     * @param array<string, mixed> $payload The already-built, already-gated
     *                          payload from FormNotifier::buildWebhookPayload()
     * @return int The batch's current submission_count after this call
     */
    public static function record(int $webhookId, string $batchKey, string $formSlug, array $payload): int
    {
        self::ensureTable();

        $db = AuthDatabase::getInstance();
        $now = time();

        // Whether THIS submission was allowed to carry values/field_names -
        // used below to downgrade an entire batch to summary-only the moment
        // any single contributing submission was not allowed to expose data.
        $thisCanExposeValues = array_key_exists('values', $payload) ? 1 : 0;

        $row = self::findRow($db, $webhookId, $batchKey);

        if ($row === null) {
            $stmt = $db->prepare('
                INSERT INTO ' . self::TABLE . '
                    (webhook_id, batch_key, submission_count, can_expose_values, submissions_json, form_slugs_json, window_started_at, flush_after)
                VALUES (?, ?, 1, ?, ?, ?, ?, ?)
            ');
            $stmt->execute([
                $webhookId,
                $batchKey,
                $thisCanExposeValues,
                json_encode([$payload], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
                json_encode([$formSlug], JSON_UNESCAPED_UNICODE),
                $now,
                $now + self::MIN_WINDOW_SECONDS,
            ]);

            return 1;
        }

        // Downgrade-only: once any submission in this window could not expose
        // values, the whole batch can't either - a later strict/unencrypted
        // submission must not retroactively "unlock" detail for submissions
        // that were already recorded as summary-only.
        $canExposeValues = ((int) $row['can_expose_values'] === 1) && ($thisCanExposeValues === 1);

        $submissions = self::decodeArray($row['submissions_json']);
        // Only accumulate full payloads while the batch is still in "detailed"
        // territory - once downgraded, keep the array empty rather than
        // growing an object nobody will read (flushRow() ignores it anyway
        // once can_expose_values is false), which also keeps the row small
        // during a summary-only flood.
        if ($canExposeValues) {
            $submissions[] = $payload;
        }

        $formSlugs = self::decodeArray($row['form_slugs_json']);
        if (!in_array($formSlug, $formSlugs, true)) {
            $formSlugs[] = $formSlug;
        }

        $newCount = (int) $row['submission_count'] + 1;
        $windowStartedAt = (int) $row['window_started_at'];
        $currentFlushAfter = (int) $row['flush_after'];
        $newFlushAfter = min(
            $windowStartedAt + self::MAX_WINDOW_SECONDS,
            $currentFlushAfter + self::EXTEND_SECONDS_PER_SUBMISSION
        );

        $stmt = $db->prepare('
            UPDATE ' . self::TABLE . '
            SET submission_count = ?,
                can_expose_values = ?,
                submissions_json = ?,
                form_slugs_json = ?,
                flush_after = ?
            WHERE id = ?
        ');
        $stmt->execute([
            $newCount,
            $canExposeValues ? 1 : 0,
            json_encode($submissions, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
            json_encode($formSlugs, JSON_UNESCAPED_UNICODE),
            $newFlushAfter,
            $row['id'],
        ]);

        // Hard cap: flush immediately regardless of the window, rather than
        // letting an uninterrupted flood grow one payload without bound.
        if ($newCount >= self::MAX_BATCH_SUBMISSIONS) {
            $freshRow = self::findRow($db, $webhookId, $batchKey);
            if ($freshRow !== null) {
                self::flushRow($db, $freshRow);
            }
        }

        return $newCount;
    }

    /**
     * Flush one specific (webhook, batch_key) batch immediately, if it is
     * currently due. No-op otherwise.
     */
    public static function flushIfDue(int $webhookId, string $batchKey): void
    {
        self::ensureTable();

        $db = AuthDatabase::getInstance();
        $row = self::findRow($db, $webhookId, $batchKey);
        if ($row === null || (int) $row['flush_after'] > time()) {
            return;
        }

        self::flushRow($db, $row);
    }

    /**
     * Sweep every due batch across all webhooks/keys. Used by the piggyback
     * safety net.
     *
     * @param int $maxBatches Hard cap so one request cannot be made to queue
     *                         an unbounded number of deliveries
     * @return int Number of batches flushed
     */
    public static function flushAllDue(int $maxBatches = 20): int
    {
        self::ensureTable();

        $db = AuthDatabase::getInstance();
        $stmt = $db->prepare(
            'SELECT * FROM ' . self::TABLE . ' WHERE flush_after <= ? ORDER BY flush_after ASC LIMIT ?'
        );
        $stmt->execute([time(), max(1, $maxBatches)]);
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $flushed = 0;
        foreach ($rows as $row) {
            self::flushRow($db, $row);
            $flushed++;
        }

        return $flushed;
    }

    /**
     * Turn one due batch row into exactly one queued webhook delivery, then
     * delete the row regardless of outcome - a batch is a delivery
     * mechanism, not a durable retry queue (mirrors
     * FormNotificationBatchService::flushRow()'s same reasoning).
     *
     * @param array<string, mixed> $row
     */
    private static function flushRow(PDO $db, array $row): void
    {
        $webhookId = (int) $row['webhook_id'];
        $batchKey = (string) $row['batch_key'];
        $count = (int) $row['submission_count'];
        $canExposeValues = (int) $row['can_expose_values'] === 1;
        $formSlugs = self::decodeArray($row['form_slugs_json']);

        // Cleared FIRST: if queuing throws, the row must not be replayed by
        // the next sweep (that would turn a transient failure into a
        // duplicate delivery once whatever broke is fixed).
        self::deleteRow($db, (int) $row['id']);

        try {
            $isGlobal = $batchKey === self::GLOBAL_BATCH_KEY;

            $body = [
                'event' => FormNotifier::EVENT_SUBMITTED,
                'batch' => true,
                'batch_mode' => $isGlobal ? WebhookService::FORMS_BATCH_GLOBAL : WebhookService::FORMS_BATCH_PER_FORM,
                'count' => $count,
                'form_slug' => $isGlobal ? null : $batchKey,
                'form_slugs' => $formSlugs,
                'timestamp' => date('c'),
            ];

            if ($canExposeValues) {
                $body['submissions'] = self::decodeArray($row['submissions_json']);
            }

            $service = new WebhookService();
            $service->queueWebhookDirect(
                $webhookId,
                FormNotifier::EVENT_SUBMITTED,
                $body,
                $isGlobal ? null : $batchKey,
                'forms'
            );
        } catch (Throwable $e) {
            error_log('[Forms] Webhook batch flush failed for webhook ' . $webhookId . ' / key "' . $batchKey . '": ' . $e->getMessage());
        }
    }

    /**
     * @return array<string, mixed>|null
     */
    private static function findRow(PDO $db, int $webhookId, string $batchKey): ?array
    {
        $stmt = $db->prepare('SELECT * FROM ' . self::TABLE . ' WHERE webhook_id = ? AND batch_key = ?');
        $stmt->execute([$webhookId, $batchKey]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);

        return is_array($row) ? $row : null;
    }

    private static function deleteRow(PDO $db, int $id): void
    {
        $stmt = $db->prepare('DELETE FROM ' . self::TABLE . ' WHERE id = ?');
        $stmt->execute([$id]);
    }

    /**
     * @return array<int, mixed>
     */
    private static function decodeArray(mixed $json): array
    {
        if (!is_string($json) || $json === '') {
            return [];
        }
        $decoded = json_decode($json, true);
        return is_array($decoded) ? $decoded : [];
    }

    /**
     * Row count (diagnostics / tests).
     */
    public static function pendingCount(): int
    {
        self::ensureTable();

        return (int) AuthDatabase::getInstance()->query('SELECT COUNT(*) FROM ' . self::TABLE)->fetchColumn(0);
    }

    /**
     * Test seam: pull an existing window's flush_after into the past so a
     * flush can be exercised without waiting MIN_WINDOW_SECONDS in real time.
     */
    public static function forceDueForTesting(int $webhookId, string $batchKey): void
    {
        self::ensureTable();

        $stmt = AuthDatabase::getInstance()->prepare(
            'UPDATE ' . self::TABLE . ' SET flush_after = ? WHERE webhook_id = ? AND batch_key = ?'
        );
        $stmt->execute([time() - 1, $webhookId, $batchKey]);
    }
}
