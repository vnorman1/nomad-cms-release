<?php
/**
 * NOMAD CMS - Form Notifier
 *
 * Optional outbound notifications when a submission arrives: an e-mail through
 * the central mail subsystem, and the existing webhook pipeline.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * SENDING IS GATED ON A VERIFIED SMTP PROFILE
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * This used to call PHP's mail() and was therefore kept behind an opt-in
 * FORMS_MAIL_ENABLED=true flag: mail() has no working MTA on a dev machine or
 * most shared hosting, and a silently, permanently failing notification is worse
 * than none at all.
 *
 * That flag is no longer the gate. MailService::isEnabled() is - and it requires
 * a default SMTP profile that has been PROVEN to work, by an admin opening the
 * confirmation link that was delivered through it (see docs/mail.md). Proof of
 * delivery is strictly better evidence than an env flag, and it means e-mail
 * switches itself on the moment the configuration is confirmed.
 *
 * FORMS_MAIL_ENABLED survives as an explicit kill switch: set it to 'false' to
 * force notifications off regardless of configuration. FORMS_MAIL_FROM is now
 * ignored - the sender identity comes from the SMTP profile, because a From:
 * address the SMTP account is not authorised to use is one of the most common
 * ways a send gets rejected.
 *
 * The addresses are still stored and validated regardless of whether sending is
 * currently possible.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * PER-FORM PROFILE CHOICE, RE-CHECKED AT SEND TIME
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * settings.notification.mail_profile_uuid lets a form pin a specific SMTP
 * profile instead of always using the system default. That choice is only
 * shape-validated when the form is saved (FormService::normalizeSettings()) -
 * whether the profile is STILL verified is re-checked here, on every
 * submission, because a profile that was verified when the form was saved can
 * be edited, disabled or deleted afterwards without the form being touched.
 *
 * If the chosen profile is no longer usable, this DOES NOT fall back to the
 * default profile. Silently sending from a different SMTP identity than the
 * admin explicitly chose - different envelope sender, different reputation,
 * possibly a different organisation - is worse than a visible gap the admin
 * can find in the log and fix by re-picking a profile. A warning is logged and
 * nothing is sent for that submission's notification.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * MULTIPLE RECIPIENTS, ONE SEND CALL EACH
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * settings.notification.emails is a list (see FormService::MAX_NOTIFICATION_EMAILS
 * for the hard cap). Each recipient gets its own MailService::send() call rather
 * than a single message with multiple To:/Bcc: recipients, so that one rejected
 * address (typo, full mailbox) cannot prevent delivery to the others - every
 * recipient's outcome is independent and independently logged.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * ENCRYPTED FORMS SEND NO VALUES - AND NEITHER DO UNENCRYPTED ONES
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * E-mail is plaintext in transit and then sits in a mailbox forever. The
 * notification (see MailTemplates::formSubmission()) never includes submitted
 * field values for ANY form, encrypted or not - it only says THAT a submission
 * arrived, and points at the admin UI. This keeps the message shape identical
 * regardless of the form's encryption setting, so the e-mail itself never
 * reveals whether encryption is on. The same values-are-never-leaked rule
 * applies to the webhook payload, which DOES include values for unencrypted
 * forms (a webhook is a deliberate, admin-configured integration - not a
 * mailbox with an indefinite retention).
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * NOTIFICATIONS ARE BATCHED, NOT SENT PER SUBMISSION
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * sendEmail() does not call MailService::send() directly - it hands the
 * submission to FormNotificationBatchService, which collects submissions for
 * a form into a single pending row while an adaptive window is open, and
 * flushes that row into exactly ONE e-mail once it elapses. A burst of 50
 * submissions therefore produces one "50 new submissions" e-mail, not 50 SMTP
 * round trips - see that class's docblock for the window mechanics. The
 * per-submission code path here still resolves recipients/profile and STOPS
 * (log + return false) on a missing/unsendable configuration before ever
 * queuing anything, exactly as it did when sending was direct.
 *
 * sendBatchEmail() is the one method that actually calls MailService::send();
 * it is called only by FormNotificationBatchService when a batch is due, never
 * directly from the submit endpoint.
 *
 * @package NomadCMS\Services\Forms
 */

declare(strict_types=1);

namespace NomadCMS\Services\Forms;

use NomadCMS\Security\WebhookService;
use NomadCMS\Services\LoggerService;
use NomadCMS\Services\Mail\MailException;
use NomadCMS\Services\Mail\MailProfileStore;
use NomadCMS\Services\Mail\MailSchema;
use NomadCMS\Services\Mail\MailService;
use NomadCMS\Services\Mail\MailTemplates;
use NomadCMS\Services\Mail\MailUrlResolver;
use Throwable;

final class FormNotifier
{
    /** Webhook event name */
    public const EVENT_SUBMITTED = 'form.submitted';

    /**
     * Record a submission for notification, sending it either immediately (as
     * part of a just-flushed batch) or queuing it into the form's pending
     * batch for a later flush - see FormNotificationBatchService for the
     * adaptive-window logic that decides which.
     *
     * Never throws: a submission must succeed for the visitor even when our own
     * SMTP is broken. Every failure path returns false and leaves a log entry.
     *
     * @param array<string, mixed> $form Hydrated form definition
     * @param array<string, mixed> $values Submitted values (never sent - see class docblock)
     * @return bool True when this call caused at least one e-mail to actually be
     *              sent (a batch flush). False also covers the common,
     *              expected case where the submission was merely queued into a
     *              still-open batch - that is not a failure, it means the
     *              notification WILL go out, just aggregated with others.
     */
    public static function sendEmail(array $form, int $submissionId, array $values): bool
    {
        $recipients = self::notificationEmails($form);
        if ($recipients === []) {
            return false;
        }

        if (!MailService::isEnabled()) {
            // Not an error: this is the normal state until an admin configures
            // and confirms a profile. Logged at info so the reason a
            // notification did not arrive is discoverable.
            self::logInfo('Űrlap értesítés kihagyva: nincs hitelesített levelezési profil', [
                'form' => self::formSlug($form),
                'submission_id' => $submissionId,
            ]);

            return false;
        }

        // A form may pin a specific profile (settings.notification.mail_profile_uuid).
        // Re-checked here, on every submission, rather than trusting the shape
        // validation done at save time - see the class docblock for why a stale
        // choice must fail LOUD (log + skip) instead of silently falling back to
        // a different SMTP identity. Checked before queuing, not just before
        // sending: no point opening/extending a batch window for a profile that
        // cannot send anyway.
        $profileUuid = self::notificationMailProfile($form);
        if ($profileUuid !== null && !self::isProfileSendable($profileUuid)) {
            self::logWarning('Űrlap értesítés kihagyva: a kiválasztott levelezési profil nem elérhető', [
                'form' => self::formSlug($form),
                'submission_id' => $submissionId,
                'mail_profile_uuid' => $profileUuid,
            ]);

            return false;
        }

        $slug = self::formSlug($form);
        if ($slug === '') {
            return false;
        }

        try {
            FormNotificationBatchService::record($slug, self::submissionUuid($form, $submissionId));
            // Immediate-flush path: if THIS submission is what just made the
            // form's own window due (e.g. the form gets one submission every
            // six minutes, so every single one flushes on arrival), send right
            // now rather than waiting for the piggyback safety net to notice.
            FormNotificationBatchService::flushIfDue($form, $slug);
        } catch (Throwable $e) {
            self::logWarning('Űrlap értesítés batch-elése sikertelen', [
                'form' => $slug,
                'submission_id' => $submissionId,
                'error' => $e->getMessage(),
            ]);

            return false;
        }

        return false;
    }

    /**
     * Send exactly one e-mail representing $count queued submissions.
     *
     * Called only by FormNotificationBatchService when a batch's window has
     * elapsed - never directly from the submit endpoint. Re-resolves
     * recipients/profile from the CURRENT form settings (not from anything
     * cached in the batch row), so an admin who changes the notification
     * config while a batch is open gets the up-to-date choice, not whatever
     * was true when the first queued submission arrived.
     *
     * @param array<string, mixed> $form
     * @param string|null $submissionUuid Only meaningful (and only passed by
     *                     the caller) when $count === 1 - a batch of several
     *                     submissions has no single one to deep-link to, so
     *                     the notification falls back to the form's inbox.
     * @return bool True when at least one recipient's message was accepted
     */
    public static function sendBatchEmail(array $form, int $count, ?string $submissionUuid): bool
    {
        $recipients = self::notificationEmails($form);
        if ($recipients === [] || !MailService::isEnabled()) {
            return false;
        }

        $profileUuid = self::notificationMailProfile($form);
        if ($profileUuid !== null && !self::isProfileSendable($profileUuid)) {
            self::logWarning('Összesített értesítés kihagyva: a kiválasztott levelezési profil nem elérhető', [
                'form' => self::formSlug($form),
                'count' => $count,
                'mail_profile_uuid' => $profileUuid,
            ]);

            return false;
        }

        $adminUrl = $count === 1 ? self::adminUrl($form, $submissionUuid) : self::adminUrl($form);
        $template = MailTemplates::formSubmission(self::formName($form), $adminUrl, $count);

        $sentAny = false;
        foreach ($recipients as $to) {
            try {
                MailService::send($to, $template['subject'], $template['text'], $template['html'], $profileUuid);
                $sentAny = true;
            } catch (MailException $e) {
                self::logWarning('E-mail értesítés küldése nem sikerült', [
                    'form' => self::formSlug($form),
                    'count' => $count,
                    'to' => $to,
                    'code' => $e->getErrorCode(),
                ]);
            } catch (Throwable $e) {
                self::logWarning('E-mail értesítés küldése nem sikerült', [
                    'form' => self::formSlug($form),
                    'count' => $count,
                    'to' => $to,
                    'error' => $e->getMessage(),
                ]);
            }
        }

        return $sentAny;
    }

    /**
     * The current submission's own uuid, for the single-submission deep link.
     *
     * FormNotifier only receives the integer submissionId (a database detail),
     * so this re-reads the row it was just given by FormSubmissionRepository
     * to recover the uuid that belongs in a URL. Falls back to null (the link
     * degrades to the form's inbox instead of a dead link) rather than
     * throwing - a lookup failure here must never affect whether the
     * notification itself goes out.
     */
    private static function submissionUuid(array $form, int $submissionId): ?string
    {
        try {
            $row = FormSubmissionRepository::findById($submissionId);
        } catch (Throwable) {
            return null;
        }

        if ($row === null) {
            return null;
        }

        $data = $row['data'] ?? null;
        $uuid = is_array($data) ? ($data['uuid'] ?? null) : null;

        return is_string($uuid) && $uuid !== '' ? $uuid : null;
    }

    /**
     * Note: there used to be a `buildEmailBody()` helper here that rendered
     * submitted values into the notification for unencrypted forms. It was
     * removed rather than adapted, because the new rule is that NO form's
     * notification ever includes values (see the class docblock) - the
     * message body now comes entirely from MailTemplates::formSubmission(),
     * which takes only the form's admin-authored name and the admin link.
     */

    /**
     * Dispatch the `form.submitted` webhook event.
     *
     * Follows the same lazy pattern as endpoints/massive.php: skip entirely when
     * no webhooks are configured, and never let a webhook failure affect the
     * visitor's response.
     *
     * ═══════════════════════════════════════════════════════════════════════
     * PER-WEBHOOK BATCH MODE
     * ═══════════════════════════════════════════════════════════════════════
     *
     * forms_batch_mode is a property of the WEBHOOK (WebhookService::
     * FORMS_BATCH_MODES), not of the form, so each subscribed webhook is
     * handled independently here: a webhook left at 'off' gets today's
     * behaviour (immediate delivery, one call per submission), while a
     * webhook set to 'global' or 'per_form' has this submission recorded into
     * FormWebhookBatchService instead of dispatched immediately - see that
     * class for the adaptive window, the hard cap, and how it eventually
     * turns the batch into exactly one queued delivery.
     *
     * getWebhooksForEvent() (the same lookup dispatchEventAsync() would have
     * done internally) is called explicitly here, once, so each webhook's
     * forms_batch_mode can be read before deciding whether that webhook gets
     * an immediate dispatch or a batch record - dispatchEventAsync() itself
     * has no notion of batching and would always deliver immediately.
     *
     * @param array<string, mixed> $form
     * @param array<string, mixed> $values
     * @param array<string, mixed> $submission Result of FormSubmissionService::create()
     */
    public static function dispatchWebhook(array $form, array $submission, array $values): void
    {
        try {
            $service = new WebhookService();
            if (!$service->hasActiveWebhooks()) {
                return;
            }

            $formSlug = self::formSlug($form);
            $payload = self::buildWebhookPayload($form, $submission, $values);

            $webhooks = $service->getWebhooksForEvent(self::EVENT_SUBMITTED, $formSlug, 'forms');
            if ($webhooks === []) {
                return;
            }

            foreach ($webhooks as $webhook) {
                $webhookId = (int) $webhook['id'];
                $batchMode = $webhook['forms_batch_mode'] ?? WebhookService::FORMS_BATCH_OFF;

                if ($batchMode === WebhookService::FORMS_BATCH_OFF) {
                    // Immediate delivery, unchanged: queue this ONE webhook
                    // directly rather than calling dispatchEventAsync() again
                    // (which would re-run getWebhooksForEvent() and match every
                    // subscribed webhook, not just this one).
                    $service->queueWebhookDirect($webhookId, self::EVENT_SUBMITTED, $payload, $formSlug, 'forms');
                    continue;
                }

                $batchKey = $batchMode === WebhookService::FORMS_BATCH_GLOBAL
                    ? FormWebhookBatchService::GLOBAL_BATCH_KEY
                    : $formSlug;

                FormWebhookBatchService::record($webhookId, $batchKey, $formSlug, $payload);
                FormWebhookBatchService::flushIfDue($webhookId, $batchKey);
            }
        } catch (Throwable $e) {
            error_log('[Forms] Webhook dispatch failed for form.submitted: ' . $e->getMessage());
        }
    }

    /**
     * Build the `form.submitted` webhook payload.
     *
     * Extracted (and public) so the leak test suite can assert that an encrypted
     * form never pushes personal data to a third-party endpoint.
     *
     * ═══════════════════════════════════════════════════════════════════════
     * VALUES REQUIRE BOTH "NOT ENCRYPTED" AND "STRICT SCHEMA"
     * ═══════════════════════════════════════════════════════════════════════
     *
     * Encryption alone used to be the gate (an encrypted form must not push
     * personal data to a third party in the clear). strict_schema is a SECOND,
     * independent gate: a non-strict form (the Formspree-like default) accepts
     * any extra key the visitor's request happens to send, so there is no
     * reviewable, admin-authored field list an admin is knowingly exposing to
     * the destination - "whatever a random request contained" is not a schema.
     * A non-strict OR encrypted form therefore gets the same minimal shape:
     * count/id, form_slug, status, timestamp - never `values`, never
     * `field_names` derived from unreviewed keys either.
     *
     * @param array<string, mixed> $form
     * @param array<string, mixed> $submission
     * @param array<string, mixed> $values
     * @return array<string, mixed>
     */
    public static function buildWebhookPayload(array $form, array $submission, array $values): array
    {
        $encrypted = FormService::isEncrypted($form);
        $canExposeValues = !$encrypted && FormService::isStrictSchema($form);

        $payload = [
            'id' => $submission['id'] ?? null,
            'form_slug' => self::formSlug($form),
            'form_name' => self::formName($form),
            'status' => $submission['status'] ?? FormsSchema::STATUS_UNREAD,
            'encrypted' => $encrypted,
            'strict_schema' => FormService::isStrictSchema($form),
            'created_at' => gmdate('c'),
        ];

        // Same rule as e-mail, now extended: a non-strict-schema form is
        // treated the same as an encrypted one - no values, and no field name
        // list either, since a non-strict form's "fields" are not a reviewed
        // schema.
        if ($canExposeValues) {
            $payload['field_names'] = array_map('strval', array_keys($values));
            $payload['values'] = $values;
        }

        return $payload;
    }

    // =========================================================================
    // HELPERS
    // =========================================================================

    /**
     * The form definition's `data` block, narrowed to a string-keyed array.
     *
     * Every accessor below goes through this instead of reaching into
     * $form['data'][...] directly: the definition arrives from a JSON column, so
     * every level of it is `mixed` and a malformed row would otherwise produce a
     * TypeError deep inside a notification - i.e. during someone else's form
     * submission.
     *
     * @param array<string, mixed> $form
     * @return array<string, mixed>
     */
    private static function formData(array $form): array
    {
        $data = $form['data'] ?? null;
        if (!is_array($data)) {
            return [];
        }

        $out = [];
        foreach ($data as $key => $value) {
            $out[(string) $key] = $value;
        }

        return $out;
    }

    /**
     * @param array<string, mixed> $form
     */
    private static function formName(array $form): string
    {
        $name = self::formData($form)['name'] ?? null;

        return is_string($name) && $name !== '' ? $name : 'Űrlap';
    }

    /**
     * @param array<string, mixed> $form
     */
    private static function formSlug(array $form): string
    {
        $slug = self::formData($form)['slug'] ?? null;

        return is_string($slug) ? $slug : '';
    }

    /**
     * The configured notification recipients, deduplicated, empty when none
     * are set or valid.
     *
     * Re-validated here as well as at save time: the definition may predate
     * the validation rule, or have been edited by hand.
     *
     * @param array<string, mixed> $form
     * @return array<int, string>
     */
    private static function notificationEmails(array $form): array
    {
        $settings = self::formData($form)['settings'] ?? null;
        if (!is_array($settings)) {
            return [];
        }

        $notification = $settings['notification'] ?? null;
        if (!is_array($notification)) {
            return [];
        }

        $rawEmails = $notification['emails'] ?? [];
        if (!is_array($rawEmails)) {
            return [];
        }

        $emails = [];
        foreach ($rawEmails as $email) {
            if (!is_string($email) || $email === '') {
                continue;
            }
            if (filter_var($email, FILTER_VALIDATE_EMAIL) === false) {
                continue;
            }
            if (!in_array($email, $emails, true)) {
                $emails[] = $email;
            }
        }

        return $emails;
    }

    /**
     * The form's pinned SMTP profile uuid, or null to use the system default.
     *
     * Only shape-checked (looks like a uuid) - whether it is still usable is
     * verified separately by isProfileSendable(), at send time.
     *
     * @param array<string, mixed> $form
     */
    private static function notificationMailProfile(array $form): ?string
    {
        $settings = self::formData($form)['settings'] ?? null;
        if (!is_array($settings)) {
            return null;
        }

        $notification = $settings['notification'] ?? null;
        if (!is_array($notification)) {
            return null;
        }

        $uuid = $notification['mail_profile_uuid'] ?? null;

        return is_string($uuid) && $uuid !== '' ? $uuid : null;
    }

    /**
     * Whether a specific (non-default) profile is verified and enabled right
     * now. See the class docblock: a stale choice must fail loudly, not fall
     * back to the default profile.
     */
    private static function isProfileSendable(string $profileUuid): bool
    {
        $masked = MailProfileStore::masked($profileUuid);
        if ($masked === null) {
            return false;
        }

        return $masked['status'] === MailSchema::STATUS_VERIFIED
            && $masked['driver'] !== MailSchema::DRIVER_DISABLED;
    }

    /**
     * Deep link to the admin frontend: straight to one submission when a uuid
     * is given (the single-submission notification case), otherwise to the
     * form's inbox (the batched-notification case, where there is no single
     * submission to point at - see FormNotificationBatchService). Null when no
     * usable admin base URL is configured.
     *
     * Unlike the mail-verification link, this notification originates from a
     * PUBLIC, unauthenticated submit request - there is no admin session to
     * read a `frontend_origin` from (see MailUrlResolver::resolveFrontendOrigin(),
     * which requires exactly that). Only the operator-configured ADMIN_URL /
     * SITE_URL (MailUrlResolver::adminBaseUrl()) is trustworthy here.
     *
     * @param array<string, mixed> $form
     */
    private static function adminUrl(array $form, ?string $submissionUuid = null): ?string
    {
        $base = MailUrlResolver::adminBaseUrl();
        if ($base === null) {
            return null;
        }

        $slug = self::formSlug($form);
        if ($slug === '') {
            return $base . '/forms';
        }

        $formUrl = $base . '/forms/' . rawurlencode($slug);

        return $submissionUuid === null
            ? $formUrl
            : $formUrl . '/submissions/' . rawurlencode($submissionUuid);
    }

    /**
     * @param array<string, mixed> $context
     */
    private static function logWarning(string $message, array $context = []): void
    {
        try {
            LoggerService::warning('[Forms] ' . $message, array_merge(['component' => 'forms'], $context));
        } catch (Throwable) {
            // Notification logging must never break a submission
        }
    }

    /**
     * @param array<string, mixed> $context
     */
    private static function logInfo(string $message, array $context = []): void
    {
        try {
            LoggerService::info('[Forms] ' . $message, array_merge(['component' => 'forms'], $context));
        } catch (Throwable) {
            // Notification logging must never break a submission
        }
    }
}
