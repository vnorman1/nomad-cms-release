<?php
/**
 * NOMAD CMS - Form File Storage
 *
 * Physical storage for form submission attachments, deliberately SEPARATE from
 * the CMS media library.
 *
 * WHY A SEPARATE STORE:
 * The media library holds files an authenticated admin chose to upload - trusted
 * input. This store holds files ANONYMOUS visitors pushed through a public
 * endpoint. Mixing the two would let untrusted uploads inherit the media
 * library's assumptions (direct web serving, image processing, public URLs).
 *
 * THREE LAYERS KEEP THESE FILES FROM LEAKING:
 *
 * 1. A .htaccess that denies all direct access, written on bootstrap. This is
 *    not belt-and-braces - it is load-bearing. api/.htaccess contains:
 *
 *        RewriteCond %{REQUEST_FILENAME} -f
 *        RewriteRule ^ - [L]
 *
 *    which serves ANY existing file before the router sees the request. Without
 *    a deny rule here, /api/files/forms/<name> would be a public download of
 *    someone's CV.
 *
 * 2. Unguessable names. Files are stored as {uuid}.nomad, so knowing a form exists
 *    tells an attacker nothing about the paths inside it.
 *
 * 3. A neutral .nomad extension for EVERY file, with the real name and MIME kept
 *    in the database. A misconfigured server (or a future nginx block that
 *    forgets the deny rule) then cannot execute .php or render .html - it just
 *    sees opaque bytes.
 *
 * Layout: files/forms/{YYYY}/{MM}/{uuid}.nomad
 * Date buckets rather than per-form directories, because a form's slug can be
 * renamed (paths would break) and because tens of thousands of entries in one
 * directory degrade badly on the shared hosting this targets.
 *
 * @package NomadCMS\Services\Forms
 */

declare(strict_types=1);

namespace NomadCMS\Services\Forms;

require_once __DIR__ . '/FormsSchema.php';

final class FormFileStorage
{
    /** Storage root, relative to the api/ directory */
    private const BASE_DIR = 'files/forms';

    /** Every stored file uses this extension regardless of its real type */
    public const DISK_EXTENSION = 'nomad';

    /** Guard so bootstrap work happens once per process */
    private static bool $ready = false;

    /**
     * Absolute path of the storage root.
     */
    public static function baseDir(): string
    {
        // src/Services/Forms -> api/
        return dirname(__DIR__, 3) . '/' . self::BASE_DIR;
    }

    /**
     * Create the storage root and write the access-denial rules.
     *
     * Idempotent. Safe to call on every request.
     */
    public static function bootstrap(): void
    {
        if (self::$ready) {
            return;
        }
        self::$ready = true;

        $base = self::baseDir();

        if (!is_dir($base)) {
            // 0750: the web server user needs to traverse it, nobody else does.
            if (!@mkdir($base, 0750, true) && !is_dir($base)) {
                error_log('[Forms] Nem sikerult letrehozni a csatolmany-tarat: ' . $base);
                return;
            }
        }

        self::writeDenyFile($base);
    }

    /**
     * Write (or repair) the .htaccess that blocks direct HTTP access.
     *
     * Rewritten whenever the content differs, so a truncated or tampered file
     * heals itself on the next request instead of silently exposing the store.
     */
    private static function writeDenyFile(string $base): void
    {
        $path = $base . '/.htaccess';
        $expected = self::denyFileContents();

        $current = is_file($path) ? @file_get_contents($path) : false;
        if ($current === $expected) {
            return;
        }

        if (@file_put_contents($path, $expected) === false) {
            error_log('[Forms] FIGYELEM: a csatolmany-tar .htaccess-e nem irhato: ' . $path);
            return;
        }

        @chmod($path, 0644);
    }

    /**
     * Deny rules covering both Apache 2.2 and 2.4.
     *
     * Both syntaxes are present because shared hosts run either, and guessing
     * wrong means the directory stays world-readable. Each is wrapped in
     * IfModule/IfVersion so the unsupported one is ignored rather than causing a
     * 500 (which would take the whole API down).
     */
    public static function denyFileContents(): string
    {
        return <<<'HTACCESS'
# ═══════════════════════════════════════════════════════════════════════════
# NOMAD CMS - Form attachment store: NO DIRECT WEB ACCESS
# ═══════════════════════════════════════════════════════════════════════════
#
# Generated automatically by FormFileStorage. Do not edit - it is rewritten
# whenever it differs from the expected contents.
#
# These files were uploaded by ANONYMOUS visitors through a public form and may
# contain personal data. They must only ever be served by
# endpoints/admin/form-files.php, which checks authentication, RBAC and (for
# encrypted forms) the forms:decrypt permission, and writes an audit entry.
#
# The parent api/.htaccess serves any existing file before the router runs, so
# without the rules below this directory would be publicly downloadable.

# Apache 2.4+
<IfModule mod_authz_core.c>
    Require all denied
</IfModule>

# Apache 2.2
<IfModule !mod_authz_core.c>
    Order allow,deny
    Deny from all
</IfModule>

# Never hand these to a handler, even if a rule above is missing.
<IfModule mod_php.c>
    php_flag engine off
</IfModule>
<IfModule mod_php7.c>
    php_flag engine off
</IfModule>
<IfModule mod_php8.c>
    php_flag engine off
</IfModule>

# Strip any inherited rewrite that might expose the directory.
<IfModule mod_rewrite.c>
    RewriteEngine On
    RewriteRule ^ - [F,L]
</IfModule>

HTACCESS;
    }

    /**
     * Allocate a storage path for a new file.
     *
     * @param string $uuid Attachment UUID (also the disk basename)
     * @return array{absolute:string, relative:string} relative is what the DB stores
     */
    public static function allocate(string $uuid): array
    {
        self::bootstrap();
        self::assertSafeUuid($uuid);

        $bucket = gmdate('Y') . '/' . gmdate('m');
        $dir = self::baseDir() . '/' . $bucket;

        if (!is_dir($dir) && !@mkdir($dir, 0750, true) && !is_dir($dir)) {
            throw new FormFileException('A csatolmány tárolási könyvtára nem létrehozható.');
        }

        $relative = $bucket . '/' . $uuid . '.' . self::DISK_EXTENSION;

        return [
            'absolute' => self::baseDir() . '/' . $relative,
            'relative' => $relative,
        ];
    }

    /**
     * Resolve a stored relative path to an absolute one.
     *
     * Rejects anything that escapes the storage root. The stored value comes
     * from our own database, but a path from a database is still a path: if a
     * row were ever tampered with, "../../.env" must not become readable through
     * the download endpoint.
     */
    public static function resolve(string $relativePath): string
    {
        $base = self::baseDir();

        if ($relativePath === '' || str_contains($relativePath, "\0")) {
            throw new FormFileException('Érvénytelen fájl útvonal.');
        }

        // Reject traversal before touching the filesystem.
        if (str_contains($relativePath, '..') || str_starts_with($relativePath, '/') || preg_match('~^[a-zA-Z]:~', $relativePath) === 1) {
            throw new FormFileException('Érvénytelen fájl útvonal.');
        }

        $candidate = $base . '/' . $relativePath;

        // realpath() collapses symlinks too, so a symlink planted inside the
        // store cannot point outward.
        $real = realpath($candidate);
        $realBase = realpath($base);

        if ($real === false || $realBase === false) {
            // Missing file: still verify the *intended* path stays inside.
            if (!str_starts_with(self::normalise($candidate), self::normalise($base) . '/')) {
                throw new FormFileException('Érvénytelen fájl útvonal.');
            }

            return $candidate;
        }

        if ($real !== $realBase && !str_starts_with($real, $realBase . '/')) {
            throw new FormFileException('Érvénytelen fájl útvonal.');
        }

        return $real;
    }

    /**
     * Move an uploaded temp file into the store.
     *
     * Uses move_uploaded_file(), which additionally verifies the source really
     * is an upload PHP handled - a plain rename() would happily move any path
     * the caller names.
     */
    public static function storeUploaded(string $tmpPath, string $absoluteTarget): void
    {
        if (!is_uploaded_file($tmpPath)) {
            throw new FormFileException('A megadott fájl nem HTTP feltöltésből származik.');
        }

        if (!@move_uploaded_file($tmpPath, $absoluteTarget)) {
            throw new FormFileException('A feltöltött fájl mentése nem sikerült.');
        }

        @chmod($absoluteTarget, 0640);
    }

    /**
     * Write raw bytes into the store atomically (used by tests and by the
     * encryption step, which produces a new file rather than moving one).
     */
    public static function writeFile(string $absoluteTarget, string $contents): void
    {
        $tmp = $absoluteTarget . '.tmp';

        if (@file_put_contents($tmp, $contents) === false) {
            throw new FormFileException('A fájl írása nem sikerült.');
        }

        if (!@rename($tmp, $absoluteTarget)) {
            @unlink($tmp);
            throw new FormFileException('A fájl véglegesítése nem sikerült.');
        }

        @chmod($absoluteTarget, 0640);
    }

    /**
     * Delete a stored file. Missing files are not an error - the caller's goal
     * is "this file must not exist", and a already-gone file satisfies that.
     */
    public static function delete(string $relativePath): bool
    {
        try {
            $absolute = self::resolve($relativePath);
        } catch (FormFileException $e) {
            error_log('[Forms] Nem torolheto csatolmany utvonal: ' . $e->getMessage());
            return false;
        }

        if (!is_file($absolute)) {
            return true;
        }

        return @unlink($absolute);
    }

    /**
     * Size on disk, or null when the file is gone.
     */
    public static function size(string $relativePath): ?int
    {
        try {
            $absolute = self::resolve($relativePath);
        } catch (FormFileException) {
            return null;
        }

        if (!is_file($absolute)) {
            return null;
        }

        $size = @filesize($absolute);

        return $size === false ? null : $size;
    }

    public static function exists(string $relativePath): bool
    {
        try {
            return is_file(self::resolve($relativePath));
        } catch (FormFileException) {
            return false;
        }
    }

    /**
     * Generate a v4 UUID.
     *
     * random_bytes() rather than uniqid()/mt_rand(): these UUIDs are part of the
     * defence (unguessable disk names and deep-link identifiers), so they need a
     * CSPRNG.
     */
    public static function uuid(): string
    {
        $bytes = random_bytes(16);
        $bytes[6] = chr((ord($bytes[6]) & 0x0f) | 0x40); // version 4
        $bytes[8] = chr((ord($bytes[8]) & 0x3f) | 0x80); // variant 1

        return vsprintf('%s%s-%s-%s-%s-%s%s%s', str_split(bin2hex($bytes), 4));
    }

    /**
     * Accept only canonical lowercase UUIDs as disk basenames.
     */
    public static function isUuid(string $value): bool
    {
        return preg_match('/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/', $value) === 1;
    }

    private static function assertSafeUuid(string $uuid): void
    {
        if (!self::isUuid($uuid)) {
            throw new FormFileException('Érvénytelen csatolmány azonosító.');
        }
    }

    /**
     * Collapse "." and ".." segments without needing the path to exist.
     */
    private static function normalise(string $path): string
    {
        $parts = [];

        foreach (explode('/', str_replace('\\', '/', $path)) as $segment) {
            if ($segment === '' || $segment === '.') {
                continue;
            }
            if ($segment === '..') {
                array_pop($parts);
                continue;
            }
            $parts[] = $segment;
        }

        return '/' . implode('/', $parts);
    }

    /**
     * Total bytes currently on disk under the store (library "all storage" view).
     */
    public static function totalBytesOnDisk(): int
    {
        $base = self::baseDir();
        if (!is_dir($base)) {
            return 0;
        }

        $total = 0;
        $iterator = new \RecursiveIteratorIterator(
            new \RecursiveDirectoryIterator($base, \FilesystemIterator::SKIP_DOTS)
        );

        /** @var \SplFileInfo $file */
        foreach ($iterator as $file) {
            if ($file->isFile() && $file->getExtension() === self::DISK_EXTENSION) {
                $total += $file->getSize();
            }
        }

        return $total;
    }

    /**
     * Remove empty date-bucket directories left behind by deletions.
     *
     * Cosmetic, but on a long-lived install the store would otherwise accumulate
     * an empty directory per month forever.
     */
    public static function pruneEmptyBuckets(): int
    {
        $base = self::baseDir();
        if (!is_dir($base)) {
            return 0;
        }

        $removed = 0;

        foreach (glob($base . '/*/*', GLOB_ONLYDIR) ?: [] as $monthDir) {
            if (self::isEmptyDir($monthDir) && @rmdir($monthDir)) {
                $removed++;
            }
        }

        foreach (glob($base . '/*', GLOB_ONLYDIR) ?: [] as $yearDir) {
            if (self::isEmptyDir($yearDir) && @rmdir($yearDir)) {
                $removed++;
            }
        }

        return $removed;
    }

    private static function isEmptyDir(string $dir): bool
    {
        $entries = @scandir($dir);
        if ($entries === false) {
            return false;
        }

        return count(array_diff($entries, ['.', '..'])) === 0;
    }

    /**
     * Test seam: forget the bootstrap guard.
     */
    public static function resetForTests(): void
    {
        self::$ready = false;
    }
}
