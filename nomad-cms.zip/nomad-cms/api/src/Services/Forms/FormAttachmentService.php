<?php
/**
 * NOMAD CMS - Form Attachment Service
 *
 * Orchestrates one submission's attachments: validate, store, encrypt, register.
 *
 * ATOMICITY IS THE WHOLE POINT.
 * A submission and its files must both exist or neither must. Two failure modes
 * are unacceptable:
 *
 *   - files on disk with no submission -> personal data nobody can see or erase
 *   - a submission claiming attachments that are not there -> an admin reading a
 *     job application with a missing CV and no idea why
 *
 * Files have to be written BEFORE the submission row, because the submission
 * envelope lists them. So they are written with submission_id = 0, adopted once
 * the row exists, and rolled back completely if anything in between fails.
 * Anything still at 0 after an hour is swept up by purgeOrphans().
 *
 * @package NomadCMS\Services\Forms
 */

declare(strict_types=1);

namespace NomadCMS\Services\Forms;

require_once __DIR__ . '/FormsSchema.php';
require_once __DIR__ . '/FormFileStorage.php';
require_once __DIR__ . '/FormFileRepository.php';
require_once __DIR__ . '/FormFileValidator.php';
require_once __DIR__ . '/FormFileCrypto.php';
require_once __DIR__ . '/FormFileException.php';

final class FormAttachmentService
{
    /**
     * Validate and store the files of one incoming submission.
     *
     * @param array<string, mixed> $form Hydrated form definition
     * @param array<string, mixed> $rawFiles Raw $_FILES
     * @return array<int, array<string, mixed>> Stored attachment descriptors
     * @throws FormFileException On any validation or storage failure (nothing kept)
     */
    public static function intake(array $form, array $rawFiles): array
    {
        $flat = FormFileValidator::flatten($rawFiles);

        if (empty($flat)) {
            return [];
        }

        $formSlug = (string) ($form['data']['slug'] ?? '');
        $uploadSettings = FormService::uploadSettings($form);

        if (($uploadSettings['enabled'] ?? false) !== true) {
            throw FormFileException::uploadsDisabled();
        }

        $encrypt = FormService::isEncrypted($form);

        // An encrypted form must not accept an attachment it cannot seal. Checked
        // before anything touches the disk.
        if ($encrypt && !FormFileCrypto::isAvailable()) {
            throw FormFileException::encryptionUnavailable();
        }

        // Quota is measured now, so a form already at its limit rejects before we
        // spend I/O on files we would then delete.
        $alreadyUsed = FormFileRepository::sumSizeByForm($formSlug);

        $validated = FormFileValidator::validate($flat, $uploadSettings, $alreadyUsed);

        if (empty($validated)) {
            return [];
        }

        $stored = [];

        try {
            foreach ($validated as $file) {
                $stored[] = self::storeOne($file, $formSlug, $encrypt);
            }
        } catch (\Throwable $e) {
            // Roll back every file written so far: a partial attachment set is
            // worse than none, because the visitor cannot tell what arrived.
            self::rollback($stored);

            if ($e instanceof FormFileException) {
                throw $e;
            }

            error_log('[Forms] Csatolmany tarolas sikertelen: ' . $e->getMessage());

            throw new FormFileException(
                'A csatolmány mentése nem sikerült.',
                500,
                'FILE_STORAGE_FAILED'
            );
        }

        return $stored;
    }

    /**
     * Store a single validated file and register its metadata row.
     *
     * @param array{field:string, original_name:string, extension:string, mime_type:string, size:int, tmp_name:string} $file
     * @return array<string, mixed>
     * @throws FormFileException
     */
    private static function storeOne(array $file, string $formSlug, bool $encrypt): array
    {
        $uuid = FormFileStorage::uuid();
        $allocated = FormFileStorage::allocate($uuid);

        // Checksum of the PLAINTEXT, taken before any encryption, so it stays a
        // meaningful integrity check on the original content.
        $checksum = @hash_file('sha256', $file['tmp_name']) ?: null;

        if ($encrypt) {
            FormFileCrypto::encryptToStore($file['tmp_name'], $allocated['absolute'], [
                'originalName' => $file['original_name'],
                'mimeType' => $file['mime_type'],
                'originalSize' => $file['size'],
            ]);

            // encryptFileStreaming reads the temp file rather than consuming it,
            // so PHP's own cleanup would eventually remove it - but a plaintext
            // copy of an encrypted attachment must not linger for even one
            // request longer than necessary.
            @unlink($file['tmp_name']);
        } else {
            FormFileStorage::storeUploaded($file['tmp_name'], $allocated['absolute']);
        }

        // submission_id = 0: adopted by attach() once the submission row exists.
        FormFileRepository::insert([
            'uuid' => $uuid,
            'submission_id' => 0,
            'form_slug' => $formSlug,
            'original_name' => $file['original_name'],
            'extension' => $file['extension'],
            'mime_type' => $file['mime_type'],
            // The ORIGINAL size, not the size on disk: for an encrypted file the
            // ciphertext is larger, and this value drives Content-Length and the
            // quota accounting.
            'size_bytes' => $file['size'],
            'encrypted' => $encrypt,
            'disk_path' => $allocated['relative'],
            'checksum' => $checksum,
            'field_name' => $file['field'],
        ]);

        return [
            'uuid' => $uuid,
            'original_name' => $file['original_name'],
            'extension' => $file['extension'],
            'mime_type' => $file['mime_type'],
            'size_bytes' => $file['size'],
            'encrypted' => $encrypt,
            'disk_path' => $allocated['relative'],
            'field_name' => $file['field'],
        ];
    }

    /**
     * Bind stored files to the submission that now exists.
     *
     * @param array<int, array<string, mixed>> $stored Descriptors from intake()
     */
    public static function attach(array $stored, int $submissionId): int
    {
        if (empty($stored)) {
            return 0;
        }

        $uuids = array_map(static fn(array $f) => (string) $f['uuid'], $stored);

        return FormFileRepository::attachToSubmission($uuids, $submissionId);
    }

    /**
     * Delete files written during a failed request.
     *
     * @param array<int, array<string, mixed>> $stored
     */
    public static function rollback(array $stored): void
    {
        foreach ($stored as $file) {
            $uuid = (string) ($file['uuid'] ?? '');

            if ($uuid !== '' && FormFileRepository::findByUuid($uuid) !== null) {
                FormFileRepository::deleteByUuid($uuid);
                continue;
            }

            // The row may not exist yet if insert() was what failed.
            $path = (string) ($file['disk_path'] ?? '');
            if ($path !== '') {
                FormFileStorage::delete($path);
            }
        }
    }

    /**
     * Compact attachment summary for the submission envelope.
     *
     * Stored in the PLAINTEXT part of the envelope on purpose: the inbox needs to
     * show "2 attachments" and the delete cascade needs to find them without
     * decrypting anything. The revealing part - the filename - is NOT included
     * here for encrypted forms; it lives in the metadata table for listing, and
     * inside the encrypted file itself.
     *
     * @param array<int, array<string, mixed>> $stored
     * @return array<int, array<string, mixed>>
     */
    public static function envelopeSummary(array $stored): array
    {
        return array_map(
            static fn(array $f) => [
                'uuid' => $f['uuid'],
                'size_bytes' => $f['size_bytes'],
                'extension' => $f['extension'],
            ],
            $stored
        );
    }

    /**
     * Quota report for one form, for the admin UI.
     *
     * @param array<string, mixed> $form
     * @return array{used:int, limit:int, percent:float, files:int, enabled:bool}
     */
    public static function quota(array $form): array
    {
        $slug = (string) ($form['data']['slug'] ?? '');
        $settings = FormService::uploadSettings($form);

        $used = FormFileRepository::sumSizeByForm($slug);
        $limit = (int) ($settings['quota_bytes'] ?? FormsSchema::DEFAULT_FORM_QUOTA_BYTES);

        return [
            'used' => $used,
            'limit' => $limit,
            'percent' => $limit > 0 ? round($used / $limit * 100, 2) : 0.0,
            'files' => FormFileRepository::countByForm($slug),
            'enabled' => ($settings['enabled'] ?? false) === true,
        ];
    }
}
