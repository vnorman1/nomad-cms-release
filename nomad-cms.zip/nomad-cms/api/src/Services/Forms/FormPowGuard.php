<?php
/**
 * NOMAD CMS - Form Proof-of-Work Guard
 *
 * Stateless, zero-server-call-on-load, zero-PII bot defence: the browser must
 * spend a small, deliberate amount of CPU time (roughly 10ms at the "low"
 * setting up to a few hundred ms at "medium", see difficultyBits() and the
 * SDK's solveFormPow() docblock for measured figures) computing a SHA-256
 * nonce before a submission is accepted. A spammer's throughput is capped by
 * raw CPU cost instead of by any secret the server has to hand out or store.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * WHY THIS IS STATELESS
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * There is NO server round-trip to fetch a challenge, and NO server-side
 * secret baked into the challenge itself. The "bucket" is a 5-minute UTC time
 * window the CLIENT derives from its own clock
 * (`floor(unix_time / BUCKET_SECONDS)`), and the server independently derives
 * its own bucket from ITS clock at verification time, accepting a small drift
 * window (see MAX_BUCKET_DRIFT) instead of trusting the client's bucket value
 * blindly.
 *
 * The "strength" of the scheme is therefore NOT secrecy (there is no secret),
 * it is the CPU cost of finding a nonce whose hash has the required number of
 * leading zero bits - identical in spirit to Hashcash / Bitcoin's PoW, just
 * with a much lower, form-spam-appropriate difficulty.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * REPLAY PROTECTION VIA payload_hash
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * Without binding the challenge to the submitted content, a bot could solve
 * ONE nonce per bucket and replay it against arbitrarily many different
 * submissions until the bucket rolls over. Binding the challenge string to a
 * canonical hash of the actual field values means a solved nonce is valid for
 * exactly the one payload it was computed for - changing so much as one
 * character invalidates it.
 *
 *   challenge = slug + ":" + bucket + ":" + payload_hash + ":" + nonce
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * CANONICALIZATION (must match the JS side exactly - see SDK/nomad.tsx)
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * 1. Drop every control field: anything starting with `_pow_` or `_nomad_`,
 *    plus the form's configured honeypot field name.
 *2. Cast every remaining value to a string (arrays are already rejected by
 *    this point in the request pipeline for scalar fields; a stray array is
 *    flattened defensively so hashing never throws).
 * 3. Trim, then normalize to Unicode NFC (matches JS `.normalize('NFC')`).
 * 4. Sort remaining keys alphabetically (byte-order, matches JS default
 *    `Array.prototype.sort()` on ASCII field names).
 * 5. Join as `key=value` lines separated by `\n`, SHA-256 the result (hex).
 *
 * Deliberately NOT canonical JSON: JSON serialization has enough
 * implementation-defined edge cases (number formatting, unicode escaping,
 * key ordering strategy) between JS and PHP that a delimited plain string is
 * safer to keep byte-for-byte identical on both sides.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * FAIL-SOFT, NOT FAIL-CLOSED
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * A missing/invalid PoW does NOT reject the request outright - the caller
 * (endpoints/public/forms.php) treats a failed verify() the same way it
 * treats an unreachable captcha provider or a tripped honeypot: the
 * submission is stored with status=spam, and the response still looks
 * successful. This protects real leads from an old cached embed snippet
 * (predating this feature), a broken/blocked script, or a JS-disabled
 * visitor - none of those are actually bots, and none of them should lose
 * their submission silently.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * TIER 2: GPU-RESISTANT MEMORY-HARD SCRATCHPAD ("NOMAD Proof")
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * Tier 1 (above) is deliberately pure SHA-256: cheap, well-understood, and
 * plenty for the vast majority of legitimate submissions. Its weakness is
 * also well-understood - SHA-256 needs zero memory, so a GPU with thousands
 * of cores can brute-force leading-zero-bit nonces at a rate no CPU-bound
 * defence can economically outpace.
 *
 * Tier 2 adds a memory-hard step BEFORE the final SHA-256 check: filling a
 * difficulty-sized scratchpad buffer (8/16/32 MB) with a deterministic
 * keystream (AES-128-CTR, seeded from the challenge - see fillScratchpad()'s
 * docblock for why a native cipher primitive is used here instead of a
 * hand-rolled PRNG loop), then walking it with a DATA-DEPENDENT read+write
 * pattern (the byte just read decides the next address to visit). That
 * data-dependency is the whole point - it cannot be precomputed or
 * parallelized the way independent SHA-256 attempts can, because each step
 * depends on the previous one's result. A GPU thread doing this still needs
 * its own full-size scratchpad and cannot share the memory-bandwidth-bound
 * walk across thousands of cores the way it shares stateless hashing - the
 * defence's cost is VRAM bandwidth, not raw ALU throughput.
 *
 * Tier 2 is NOT a bot-detection heuristic and never tries to be one (a
 * sufficiently motivated headless browser can always fake mouse events). Its
 * only job is to make GPU-parallelized brute-forcing of a triggered
 * submission economically unattractive. The trigger itself (see
 * contextImpliesTier2()) is informational: it tells the caller whether the
 * SUBMISSION's own timing/interaction context implied Tier 2 should have run,
 * so a submission that skipped it when it should not have can be flagged -
 * without the server ever needing a round-trip to decide which tier to hand
 * out up front (the client decides that locally, for zero added latency on
 * the common, non-suspicious path).
 *
 * Because every Tier 2 attempt costs a full scratchpad walk, the required
 * leading-zero-bits are deliberately much lower than Tier 1 (see
 * TIER2_DIFFICULTY_BITS) - the cost now lives in the memory walk, not in
 * needing many attempts. Calibrated total solve time is roughly 25-250ms
 * depending on difficulty - imperceptible after a form submit click, but
 * backed by real memory-bandwidth cost that does not get cheaper on a GPU
 * the way spinning SHA-256 attempts does.
 *
 * The server verifies a submitted Tier 2 nonce with exactly ONE deterministic
 * replay of the same walk (never a search) - see verify()'s $tier2 branch.
 *
 * @package NomadCMS\Services\Forms
 */

declare(strict_types=1);

namespace NomadCMS\Services\Forms;

final class FormPowGuard
{
    /** Client-supplied bucket index field (server re-derives its own and compares) */
    public const BUCKET_FIELD = '_pow_bucket';

    /** Client-supplied solved nonce field */
    public const NONCE_FIELD = '_pow_nonce';

    /** Bucket window size in seconds - kept in sync with the public schema's `pow.bucket_seconds` */
    public const BUCKET_SECONDS = 300;

    /**
     * How many buckets of drift (in either direction) are tolerated between
     * the client-derived bucket and the server's own bucket at verification
     * time. ±1 bucket at a 300s window means up to ~5-10 minutes of client
     * clock skew or slow-typing is tolerated without penalizing a real visitor,
     * mirroring common clock-skew tolerances (e.g. Stripe's 5-minute webhook
     * timestamp tolerance).
     */
    private const MAX_BUCKET_DRIFT = 1;

    public const REASON_POW_INVALID = 'pow_invalid';
    public const REASON_POW_MISSING = 'pow_missing';

    /**
     * A submission's own timing/interaction context implied Tier 2 was
     * required (fast submit and/or zero interaction), but the submitted
     * proof was only a valid Tier 1 solution (or no tier field at all).
     */
    public const REASON_TIER2_REQUIRED_BUT_MISSING = 'tier2_required_but_missing';

    /**
     * The client attempted Tier 2 (declared via _pow_tier=2) but the
     * server-side deterministic replay of the scratchpad walk did not match
     * the submitted hash/bits - e.g. the client's memory-constrained device
     * timed out and fell back to a Tier 1 solve while still (incorrectly)
     * labelling it as Tier 2, or the walk parameters diverged. This is
     * distinct from REASON_POW_INVALID so the admin UI can tell "no PoW logic
     * ran at all" apart from "the client tried the expensive path and it
     * still did not check out".
     */
    public const REASON_TIER2_FALLBACK_TIMEOUT = 'tier2_fallback_timeout';

    /** Enum accepted for settings.pow.difficulty, mapped to required leading zero BITS of the SHA-256 hash */
    private const DIFFICULTY_BITS = [
        'low' => 12,
        'medium' => 16,
        'high' => 20,
    ];

    /**
     * Tier 2 leading-zero-bits per difficulty. Deliberately much lower than
     * Tier 1: the cost now lives in the mandatory scratchpad walk that
     * precedes every hash attempt, not in needing many attempts - a
     * legitimate browser should find a solution in a handful of tries.
     * Calibrated (see FormPowGuardTest's benchmark) against the combined
     * AES-CTR-fill + walk + fingerprint-hash cost per attempt so the total
     * solve time lands in the ~50-250ms range on typical hardware - the
     * `high` level's larger scratchpad (32 MB) already adds meaningful
     * per-attempt cost on its own, so it does not need as many bits as a
     * naive 12/16/20-style progression would suggest.
     */
    private const TIER2_DIFFICULTY_BITS = [
        'low' => 3,
        'medium' => 4,
        'high' => 4,
    ];

    /** Tier 2 scratchpad size in bytes per difficulty (8/16/32 MB) */
    private const TIER2_MEMORY_BYTES = [
        'low' => 8 * 1024 * 1024,
        'medium' => 16 * 1024 * 1024,
        'high' => 32 * 1024 * 1024,
    ];

    /**
     * Data-dependent walk steps performed over the scratchpad per Tier 2
     * attempt. Kept small deliberately - the memory-BANDWIDTH cost of
     * repeatedly touching a large, cold buffer is what matters, not the
     * iteration count (see class docblock).
     */
    private const TIER2_WALK_STEPS = 4096;

    /** Client-supplied proof tier: '1' (default/omitted) or '2' */
    public const TIER_FIELD = '_pow_tier';

    /** Client-supplied flag: at least one mousemove/touch/keydown before submit */
    public const INTERACTED_FIELD = '_nomad_interacted';

    /**
     * A submission arriving faster than this many seconds after
     * FormSpamGuard::TIMESTAMP_FIELD implies Tier 2 should have run - mirrors
     * the brainstorm's "Time-Trap" heuristic. Intentionally the SAME window
     * FormSpamGuard already uses for its own (advisory) timing check, so the
     * two heuristics agree on what "too fast" means.
     */
    private const TIER2_TRIGGER_MAX_SECONDS = 2;

    public const DEFAULT_DIFFICULTY = 'medium';

    /**
     * Prefixes that mark a field as protocol/control data rather than
     * submitted content - excluded from the canonical payload hash on BOTH
     * sides. Kept as prefixes (not a fixed list) so a future `_pow_*` field
     * never has to be added here AND in the JS SDK in lockstep.
     *
     * @var array<int, string>
     */
    private const CONTROL_FIELD_PREFIXES = ['_pow_', '_nomad_'];

    /**
     * Verify a submission's proof-of-work against its own content.
     *
     * Tier-aware: reads $rawValues[TIER_FIELD] ('1'/absent = Tier 1, '2' =
     * Tier 2). Tier 2 additionally re-runs the deterministic scratchpad walk
     * (ONE pass, never a search - see class docblock) before checking the
     * (lower) Tier 2 bit threshold.
     *
     * Also cross-checks the submission's OWN timing/interaction context
     * (`_nomad_ts` / `_nomad_interacted`) against what tier it actually
     * submitted: a fast/non-interacted submission that only carries a valid
     * Tier 1 proof is flagged with REASON_TIER2_REQUIRED_BUT_MISSING even
     * though the Tier 1 hash itself checks out - the context implied Tier 2
     * was required. This is the "server independently re-derives, never
     * trusts the client's tier claim at face value" half of the adaptive
     * scheme (the client makes the zero-round-trip DECISION; the server
     * makes the final judgement).
     *
     * @param array<string, mixed> $rawValues Submitted values BEFORE guard fields are stripped
     * @param string $slug Form slug (part of the challenge string)
     * @param string $honeypotField Configured honeypot field name (excluded from the payload hash)
     * @param string $difficulty One of 'low'|'medium'|'high' (unknown values fall back to 'medium')
     * @param int|null $serverBucket Override for the server's own current bucket. Exists solely for
     *        deterministic tests (both unit tests and live-HTTP integration tests) - production callers
     *        never pass this, so verify() always compares against currentBucket() (the real clock).
     * @return array{ok:bool, reason:?string}
     */
    public static function verify(
        array $rawValues,
        string $slug,
        string $honeypotField,
        string $difficulty = self::DEFAULT_DIFFICULTY,
        ?int $serverBucket = null
    ): array {
        $bucketRaw = $rawValues[self::BUCKET_FIELD] ?? null;
        $nonceRaw = $rawValues[self::NONCE_FIELD] ?? null;

        if (!is_numeric($bucketRaw) || !is_numeric($nonceRaw)) {
            return ['ok' => false, 'reason' => self::REASON_POW_MISSING];
        }

        $clientBucket = (int) $bucketRaw;
        $nonce = (string) $nonceRaw;

        if ($nonce === '' || strlen($nonce) > 32) {
            // A legitimate solver never needs more than a handful of decimal
            // digits; reject absurd input early instead of hashing it.
            return ['ok' => false, 'reason' => self::REASON_POW_INVALID];
        }

        $serverBucket = $serverBucket ?? self::currentBucket();
        if (abs($serverBucket - $clientBucket) > self::MAX_BUCKET_DRIFT) {
            return ['ok' => false, 'reason' => self::REASON_POW_INVALID];
        }

        $payloadHash = self::canonicalPayloadHash($rawValues, $honeypotField);
        $challenge = $slug . ':' . $clientBucket . ':' . $payloadHash . ':' . $nonce;

        $tier = self::submittedTier($rawValues);

        if ($tier === 2) {
            $requiredBits = self::TIER2_DIFFICULTY_BITS[$difficulty] ?? self::TIER2_DIFFICULTY_BITS[self::DEFAULT_DIFFICULTY];
            $memoryBytes = self::TIER2_MEMORY_BYTES[$difficulty] ?? self::TIER2_MEMORY_BYTES[self::DEFAULT_DIFFICULTY];

            $digest = self::tier2Digest($challenge, $memoryBytes);
            if ($digest === null || !self::hasLeadingZeroBits($digest, $requiredBits)) {
                // The client declared Tier 2 but the deterministic replay does
                // not check out - distinct from "no PoW logic ran at all"
                // (REASON_POW_INVALID) so the admin UI can tell them apart.
                return ['ok' => false, 'reason' => self::REASON_TIER2_FALLBACK_TIMEOUT];
            }
        } else {
            $requiredBits = self::DIFFICULTY_BITS[$difficulty] ?? self::DIFFICULTY_BITS[self::DEFAULT_DIFFICULTY];
            $digest = hash('sha256', $challenge);

            if (!self::hasLeadingZeroBits($digest, $requiredBits)) {
                return ['ok' => false, 'reason' => self::REASON_POW_INVALID];
            }

            // Tier 1 hash is valid on its own terms, but the submission's own
            // timing/interaction context implied Tier 2 should have run.
            if (self::contextImpliesTier2($rawValues)) {
                return ['ok' => false, 'reason' => self::REASON_TIER2_REQUIRED_BUT_MISSING];
            }
        }

        return ['ok' => true, 'reason' => null];
    }

    /**
     * Whether a submission's own timing/interaction context implies Tier 2
     * should have been used, mirroring the client-side decision (see
     * SDK/nomad.tsx) so the server can independently reach the same verdict
     * instead of trusting a client-supplied tier flag at face value.
     *
     * Two independent triggers, either one is sufficient (matches the
     * client-side "Time-Trap" / "Interaction Entropy" heuristics):
     *   - the submission arrived less than TIER2_TRIGGER_MAX_SECONDS after
     *     FormSpamGuard::TIMESTAMP_FIELD ("_nomad_ts");
     *   - INTERACTED_FIELD ("_nomad_interacted") is present and falsy, i.e.
     *     the client explicitly reported zero mousemove/touch/keydown before
     *     submit.
     *
     * Absence of either field is NOT itself a trigger - an old embed snippet
     * predating this feature (or a hand-written integration) simply will not
     * send them, and that must stay fully backward compatible (fail-soft,
     * same as the rest of this class).
     *
     * @param array<string, mixed> $rawValues
     */
    public static function contextImpliesTier2(array $rawValues): bool
    {
        $timestampRaw = $rawValues[FormSpamGuard::TIMESTAMP_FIELD] ?? null;
        if (is_numeric($timestampRaw)) {
            $elapsed = time() - (int) $timestampRaw;
            if ($elapsed >= 0 && $elapsed < self::TIER2_TRIGGER_MAX_SECONDS) {
                return true;
            }
        }

        if (array_key_exists(self::INTERACTED_FIELD, $rawValues)) {
            $interacted = $rawValues[self::INTERACTED_FIELD];
            if (!self::truthy($interacted)) {
                return true;
            }
        }

        return false;
    }

    /**
     * Parse the client-declared proof tier. Anything other than a literal
     * '2' (string or int) is treated as Tier 1 - fail-soft: a missing or
     * malformed tier field never breaks the existing Tier 1 verification
     * path that predates this feature.
     *
     * @param array<string, mixed> $rawValues
     */
    public static function submittedTier(array $rawValues): int
    {
        $raw = $rawValues[self::TIER_FIELD] ?? null;

        if (is_numeric($raw) && (int) $raw === 2) {
            return 2;
        }

        return 1;
    }

    private static function truthy(mixed $value): bool
    {
        if (is_bool($value)) {
            return $value;
        }
        if (is_numeric($value)) {
            return (float) $value !== 0.0;
        }
        if (is_string($value)) {
            return !in_array(strtolower(trim($value)), ['', '0', 'false'], true);
        }

        return (bool) $value;
    }

    /**
     * Final Tier 2 digest for a challenge string: fill a deterministic
     * scratchpad from the challenge, walk it with a data-dependent
     * read+write pattern, then SHA-256 the resulting buffer.
     *
     * Guarded with a memory/time budget so a maliciously large $memoryBytes
     * (never client-controlled in production - see verify(), which only ever
     * passes a server-resolved difficulty value) cannot exhaust the request's
     * memory_limit or run past a reasonable execution budget. Returns null if
     * the guard trips instead of throwing, so a misconfigured environment
     * fails the PoW check (fail-soft: stored as spam, not a hard error).
     *
     * @return string|null Lowercase hex SHA-256 digest, or null if the memory/time budget was exceeded
     */
    private static function tier2Digest(string $challenge, int $memoryBytes): ?string
    {
        $memoryLimitBytes = self::phpMemoryLimitBytes();
        if ($memoryLimitBytes !== -1 && $memoryBytes * 2 > $memoryLimitBytes) {
            // The scratchpad plus PHP's own working copy overhead should
            // comfortably fit within half the configured memory_limit; if it
            // would not, refuse rather than risk a fatal that kills the whole
            // request (including the rest of the submission pipeline).
            return null;
        }

        $startedAt = microtime(true);
        $scratchpad = self::fillScratchpad($challenge, $memoryBytes);
        if ($scratchpad === null) {
            return null;
        }

        // Deterministic data-dependent walk: the byte just read decides both
        // the value written back and the next address visited. This
        // dependency chain is what makes the walk impossible to precompute or
        // split across parallel GPU threads without each thread paying for
        // its own full-size scratchpad - a GPU thread still has to hold and
        // repeatedly touch the ENTIRE scratchpad to follow the chain, even
        // though only a few thousand bytes of it end up hashed below.
        //
        // The final digest is taken over a small FINGERPRINT accumulated
        // DURING the walk (the byte written at each step), not over the whole
        // scratchpad: hashing the full 8-32 MB buffer was benchmarked at
        // ~45-170ms on its own (PHP) - once per verification, on every
        // suspicious submission, that is a meaningful DoS surface for
        // something that adds no security here. The memory-hardness property
        // comes entirely from the walk touching the full-size buffer at
        // data-dependent addresses, not from the hash input's size.
        $size = strlen($scratchpad);
        $seedHash = hash('sha256', $challenge, true);
        $pos = self::bytesToUint32($seedHash, 0) % $size;
        $fingerprint = '';

        for ($i = 0; $i < self::TIER2_WALK_STEPS; $i++) {
            $byte = ord($scratchpad[$pos]);
            $mixed = ($byte ^ ($i & 0xFF)) & 0xFF;
            $scratchpad[$pos] = chr($mixed);
            $fingerprint .= chr($mixed);

            // Next address derived from the byte just read (before the
            // write), mixed with the step counter for extra diffusion -
            // matches SDK/nomad.tsx's walk step-for-step.
            $pos = (($byte * 2654435761 + $i) % $size + $size) % $size;

            // Cheap, coarse execution-time guard - checked every 512 steps to
            // avoid making microtime() calls the dominant cost of the loop.
            if (($i & 0x1FF) === 0 && (microtime(true) - $startedAt) > 0.5) {
                return null;
            }
        }

        return hash('sha256', $fingerprint);
    }

    /**
     * Deterministically fill a $sizeBytes buffer from $challenge.
     *
     * Uses AES-128-CTR (via the `openssl` extension) as a fast, deterministic
     * keystream generator, seeded entirely from SHA-256($challenge) - NOT for
     * its confidentiality properties (there is nothing secret being
     * encrypted, the "plaintext" is a zero buffer), but because it is the only
     * primitive available in both PHP and every browser (`crypto.subtle`,
     * see SDK/nomad.tsx's `fillScratchpad()`) that is BOTH hardware-accelerated
     * (AES-NI) and fast enough to fill 8-32 MB in single-digit-to-low-double-digit
     * milliseconds. A hand-rolled PRNG loop (e.g. a SHA-256 stream, or even a
     * tight xorshift loop) was benchmarked at 150-600ms in PHP for the same
     * sizes - the PHP function-call/loop overhead dominates long before the
     * cipher's own cost would - which would make Tier 2 server-side
     * verification itself slow enough to become its own minor DoS surface on
     * every suspicious submission. This is a native language/runtime API, not
     * a third-party library or a build step - the same category as the
     * `hash()` calls the rest of this class already uses.
     *
     * The actual GPU-resistance property of Tier 2 comes from the
     * DATA-DEPENDENT WALK in tier2Digest(), not from this fill step - the fill
     * only needs to be a fast, deterministic, hard-to-shortcut way to get
     * "some pseudo-random bytes both sides agree on" into the buffer before
     * the walk begins.
     *
     * @return string|null The filled buffer, or null if the openssl extension is unavailable (fail-soft)
     */
    private static function fillScratchpad(string $challenge, int $sizeBytes): ?string
    {
        if (!function_exists('openssl_encrypt')) {
            // No native AES available in this PHP build - fail soft rather
            // than fall back to the ~40x slower hand-rolled path, which would
            // turn a misconfigured environment into a request-time DoS risk.
            return null;
        }

        $seed = hash('sha256', $challenge, true); // 32 raw bytes
        $key = substr($seed, 0, 16);
        $iv = substr($seed, 16, 16);

        $zeros = str_repeat("\0", $sizeBytes);
        $filled = openssl_encrypt($zeros, 'aes-128-ctr', $key, OPENSSL_RAW_DATA, $iv);

        return $filled === false ? null : $filled;
    }

    /**
     * Big-endian uint32 read from a raw byte string at $offset.
     */
    private static function bytesToUint32(string $bytes, int $offset): int
    {
        return (ord($bytes[$offset]) << 24)
            | (ord($bytes[$offset + 1]) << 16)
            | (ord($bytes[$offset + 2]) << 8)
            | ord($bytes[$offset + 3]);
    }

    /**
     * The configured memory_limit in bytes, or -1 if unlimited.
     */
    private static function phpMemoryLimitBytes(): int
    {
        $raw = trim((string) ini_get('memory_limit'));
        if ($raw === '' || $raw === '-1') {
            return -1;
        }

        $unit = strtolower(substr($raw, -1));
        $value = (int) $raw;

        return match ($unit) {
            'g' => $value * 1024 * 1024 * 1024,
            'm' => $value * 1024 * 1024,
            'k' => $value * 1024,
            default => (int) $raw,
        };
    }

    /**
     * The server's own current bucket index, from its own clock.
     */
    public static function currentBucket(): int
    {
        return intdiv(time(), self::BUCKET_SECONDS);
    }

    /**
     * Canonical SHA-256 hash of the actual submitted content, excluding every
     * control field. MUST match the JS implementation byte-for-byte - see
     * SDK/nomad.tsx `canonicalFormHash()`.
     *
     * @param array<string, mixed> $rawValues
     */
    public static function canonicalPayloadHash(array $rawValues, string $honeypotField): string
    {
        $lines = [];

        foreach ($rawValues as $key => $value) {
            if (!is_string($key) || self::isControlField($key, $honeypotField)) {
                continue;
            }

            $stringValue = self::stringifyValue($value);
            $normalized = self::normalize($stringValue);

            $lines[$key] = $key . '=' . $normalized;
        }

        ksort($lines, SORT_STRING);

        return hash('sha256', implode("\n", $lines));
    }

    /**
     * Whether a difficulty label is one of the recognised enum values.
     */
    public static function isValidDifficulty(string $difficulty): bool
    {
        return array_key_exists($difficulty, self::DIFFICULTY_BITS);
    }

    /**
     * @return array<int, string>
     */
    public static function difficultyLevels(): array
    {
        return array_keys(self::DIFFICULTY_BITS);
    }

    public static function difficultyBits(string $difficulty): int
    {
        return self::DIFFICULTY_BITS[$difficulty] ?? self::DIFFICULTY_BITS[self::DEFAULT_DIFFICULTY];
    }

    /**
     * Tier 2 leading-zero-bits for a difficulty level - exposed so the public
     * schema (FormService::publicPowSchema()) and the JS SDK can agree on the
     * exact same threshold the server will verify against.
     */
    public static function tier2DifficultyBits(string $difficulty): int
    {
        return self::TIER2_DIFFICULTY_BITS[$difficulty] ?? self::TIER2_DIFFICULTY_BITS[self::DEFAULT_DIFFICULTY];
    }

    /**
     * Tier 2 scratchpad size in bytes for a difficulty level.
     */
    public static function tier2MemoryBytes(string $difficulty): int
    {
        return self::TIER2_MEMORY_BYTES[$difficulty] ?? self::TIER2_MEMORY_BYTES[self::DEFAULT_DIFFICULTY];
    }

    /**
     * Number of data-dependent walk steps performed per Tier 2 attempt -
     * exposed for the same cross-language-agreement reason as the two
     * getters above.
     */
    public static function tier2WalkSteps(): int
    {
        return self::TIER2_WALK_STEPS;
    }

    /**
     * Human readable (Hungarian) label for a PoW failure reason, for the admin UI.
     */
    public static function reasonLabel(?string $reason): ?string
    {
        return match ($reason) {
            self::REASON_POW_INVALID => 'Proof-of-Work ellenőrzés sikertelen (bot vagy elavult beágyazás)',
            self::REASON_POW_MISSING => 'Proof-of-Work adatok hiányoznak (bot vagy JS nélküli kliens)',
            self::REASON_TIER2_REQUIRED_BUT_MISSING => 'Gyanús időzítés/interakció, de nincs érvényes GPU-rezisztens (Tier 2) igazolás',
            self::REASON_TIER2_FALLBACK_TIMEOUT => 'GPU-rezisztens (Tier 2) igazolás megkezdve, de az ellenőrzés sikertelen (időtúllépés vagy eltérő számítás)',
            null => null,
            default => $reason,
        };
    }

    private static function isControlField(string $key, string $honeypotField): bool
    {
        if ($honeypotField !== '' && $key === $honeypotField) {
            return true;
        }

        foreach (self::CONTROL_FIELD_PREFIXES as $prefix) {
            if (str_starts_with($key, $prefix)) {
                return true;
            }
        }

        return false;
    }

    private static function stringifyValue(mixed $value): string
    {
        if (is_array($value)) {
            // Defensive only: scalar-typed form fields never reach this point
            // as arrays in the normal request flow. Flattening (rather than
            // throwing) means canonicalPayloadHash() never crashes the request
            // on unexpected shape - it just produces a hash that will not
            // match the client's, which safely fails the PoW check.
            return implode(',', array_map(
                static fn(mixed $item): string => is_scalar($item) ? (string) $item : '',
                $value
            ));
        }

        if ($value === null) {
            return '';
        }

        if (is_bool($value)) {
            return $value ? 'true' : 'false';
        }

        return (string) $value;
    }

    private static function normalize(string $value): string
    {
        $trimmed = trim($value);

        if (class_exists(\Normalizer::class)) {
            $normalized = \Normalizer::normalize($trimmed, \Normalizer::FORM_C);
            if ($normalized !== false) {
                return $normalized;
            }
        }

        return $trimmed;
    }

    /**
     * Whether a hex SHA-256 digest has at least $bits leading zero bits.
     */
    private static function hasLeadingZeroBits(string $hexDigest, int $bits): bool
    {
        $fullNibbles = intdiv($bits, 4);
        $remainderBits = $bits % 4;

        if (strlen($hexDigest) < $fullNibbles + ($remainderBits > 0 ? 1 : 0)) {
            return false;
        }

        for ($i = 0; $i < $fullNibbles; $i++) {
            if ($hexDigest[$i] !== '0') {
                return false;
            }
        }

        if ($remainderBits === 0) {
            return true;
        }

        // Check the top $remainderBits bits of the next nibble are zero.
        $nibbleValue = hexdec($hexDigest[$fullNibbles]);
        $mask = 0xF & ~((1 << (4 - $remainderBits)) - 1);

        return ($nibbleValue & $mask) === 0;
    }
}
