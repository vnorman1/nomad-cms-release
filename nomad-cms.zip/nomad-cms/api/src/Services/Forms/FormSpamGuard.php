<?php
/**
 * NOMAD CMS - Form Spam Guard
 *
 * Zero-dependency spam heuristics for the public submit endpoint, plus the
 * token-extraction/stripping glue for the optional captcha layer (see
 * CaptchaVerifier / CaptchaConfigStore).
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * HONEYPOT
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * The embed snippet renders a field (default `website_url_hp`) that is hidden
 * from humans but present in the DOM. Bots that fill every input give
 * themselves away.
 *
 * A hit is NOT silently dropped: the submission is stored with
 * status = 'spam'. Silent dropping means a false positive (a password manager
 * or an aggressive autofill filling the trap) becomes an invisible lost lead.
 * Stored-as-spam keeps it recoverable, and lets the admin see whether the trap
 * is working at all.
 *
 * The response to a honeypot hit still LOOKS successful, so a bot gets no
 * signal about which field betrayed it.
 *
 * A form may turn the honeypot off entirely via `honeypot_enabled=false`
 * (see FormService::honeypotEnabled()) while keeping the field name
 * configured - inspect() then skips the honeypot check but still applies the
 * timing heuristic.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * TIMING (OPTIONAL)
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * If the embed includes `_nomad_ts` (a unix timestamp written when the form was
 * rendered), a submission that arrives implausibly fast is flagged. This is
 * advisory only - the value is client-controlled, so it can only ever catch
 * lazy bots, never be relied upon.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * CAPTCHA TOKEN FIELDS
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * Whichever provider is active, its widget writes a token into a POST field
 * (e.g. `cf-turnstile-response`, `g-recaptcha-response`). This class knows the
 * full set of possible token field names - sourced from
 * CaptchaProviderRegistry plus a couple of documented convenience aliases
 * (`turnstile_token`, `recaptcha_token`) - so:
 *
 *   - extractToken() can pull the right value regardless of which markup the
 *     embed used;
 *   - stripGuardFields() removes ALL of them unconditionally, so switching a
 *     form from one provider to another (or off) never leaves a stale ~1-2KB
 *     token stored as if it were a submitted field value.
 *
 * @package NomadCMS\Services\Forms
 */

declare(strict_types=1);

namespace NomadCMS\Services\Forms;

final class FormSpamGuard
{
    /** Optional timestamp field the embed snippet may include */
    public const TIMESTAMP_FIELD = '_nomad_ts';

    /** Minimum plausible fill time in seconds */
    private const MIN_FILL_SECONDS = 2;

    /** Reject timestamps further in the past than this (stale/replayed page) */
    private const MAX_AGE_SECONDS = 86400;

    public const REASON_HONEYPOT = 'honeypot';
    public const REASON_TOO_FAST = 'too_fast';
    public const REASON_CAPTCHA_UNVERIFIED = 'captcha_unverified';

    /**
     * Convenience aliases accepted in addition to each provider's own widget
     * field name - a hand-written integration may use these instead of the
     * provider's literal DOM field name.
     *
     * @var array<int, string>
     */
    private const TOKEN_FIELD_ALIASES = ['turnstile_token', 'recaptcha_token'];

    /**
     * Inspect a raw submission for spam signals.
     *
     * @param array<string, mixed> $rawValues Submitted values, BEFORE guard fields are stripped
     * @param string $honeypotField Configured honeypot field name
     * @param bool $checkTiming Whether to apply the optional timing heuristic
     * @param bool $honeypotEnabled Whether the honeypot check itself is active
     * @return array{is_spam:bool, reason:string|null}
     */
    public static function inspect(
        array $rawValues,
        string $honeypotField,
        bool $checkTiming = true,
        bool $honeypotEnabled = true
    ): array {
        // ── Honeypot ─────────────────────────────────────────────────────────
        if ($honeypotEnabled && $honeypotField !== '' && array_key_exists($honeypotField, $rawValues)) {
            $value = $rawValues[$honeypotField];
            if (self::isFilled($value)) {
                return ['is_spam' => true, 'reason' => self::REASON_HONEYPOT];
            }
        }

        // ── Timing (advisory) ────────────────────────────────────────────────
        if ($checkTiming && array_key_exists(self::TIMESTAMP_FIELD, $rawValues)) {
            $raw = $rawValues[self::TIMESTAMP_FIELD];
            if (is_numeric($raw)) {
                $rendered = (int) $raw;
                $now = time();
                $elapsed = $now - $rendered;

                // Only a plausible, recent timestamp is actionable. A future or
                // ancient value means the page was cached or the field was
                // tampered with - not evidence of spam either way.
                if ($elapsed >= 0 && $elapsed < self::MIN_FILL_SECONDS) {
                    return ['is_spam' => true, 'reason' => self::REASON_TOO_FAST];
                }
                if ($elapsed > self::MAX_AGE_SECONDS) {
                    return ['is_spam' => false, 'reason' => null];
                }
            }
        }

        return ['is_spam' => false, 'reason' => null];
    }

    /**
     * Every POST field name that could carry a captcha token, across every
     * provider plus the documented aliases. Used by stripGuardFields() so a
     * stale token from a previously-configured provider is never stored.
     *
     * @return array<int, string>
     */
    public static function allTokenFieldNames(): array
    {
        $fields = [];
        foreach (CaptchaProviderRegistry::PROVIDERS as $provider) {
            $field = CaptchaProviderRegistry::tokenField($provider);
            if ($field !== null) {
                $fields[] = $field;
            }
        }

        return array_values(array_unique(array_merge($fields, self::TOKEN_FIELD_ALIASES)));
    }

    /**
     * Extract the captcha token for the given provider from raw submitted
     * values, trying the provider's own field name first, then the aliases.
     *
     * @param array<string, mixed> $rawValues
     */
    public static function extractToken(array $rawValues, string $provider): ?string
    {
        $candidates = [];

        $providerField = CaptchaProviderRegistry::tokenField($provider);
        if ($providerField !== null) {
            $candidates[] = $providerField;
        }
        $candidates = array_merge($candidates, self::TOKEN_FIELD_ALIASES);

        foreach ($candidates as $field) {
            if (array_key_exists($field, $rawValues)) {
                $value = $rawValues[$field];
                if (is_string($value) && trim($value) !== '') {
                    return trim($value);
                }
            }
        }

        return null;
    }

    /**
     * Remove guard fields so they never end up stored as submission values.
     *
     * @param array<string, mixed> $values
     * @param string $honeypotField
     * @return array<string, mixed>
     */
    public static function stripGuardFields(array $values, string $honeypotField): array
    {
        unset($values[self::TIMESTAMP_FIELD]);
        unset($values[FormPowGuard::BUCKET_FIELD], $values[FormPowGuard::NONCE_FIELD]);
        unset($values[FormPowGuard::TIER_FIELD], $values[FormPowGuard::INTERACTED_FIELD]);

        if ($honeypotField !== '') {
            unset($values[$honeypotField]);
        }

        // Every known captcha token field, regardless of which provider (if
        // any) is currently active - switching providers must never leave a
        // stale token stored as a submitted value.
        foreach (self::allTokenFieldNames() as $tokenField) {
            unset($values[$tokenField]);
        }

        // Reserved keys used by the redirect flow, never user data
        unset($values['_nomad_redirect'], $values['nomad_form']);

        return $values;
    }

    /**
     * Human readable (Hungarian) label for a spam reason, for the admin UI.
     */
    public static function reasonLabel(?string $reason): ?string
    {
        return match ($reason) {
            self::REASON_HONEYPOT => 'Honeypot mező kitöltve (bot)',
            self::REASON_TOO_FAST => 'Túl gyors beküldés (bot)',
            self::REASON_CAPTCHA_UNVERIFIED => 'Captcha ellenőrzés nem volt elérhető (a szolgáltatás elérhetetlen volt)',
            null => null,
            default => $reason,
        };
    }

    /**
     * Thin wrapper kept for the documented spec wording
     * (`FormSpamGuard::verifyTurnstile($token, $secretKey, $remoteIp)`),
     * delegating to the provider-agnostic CaptchaVerifier.
     *
     * @return array{state:string, score:?float, error_codes:array<int,string>}
     */
    public static function verifyTurnstile(string $token, string $secretKey, string $remoteIp): array
    {
        return CaptchaVerifier::verify(CaptchaProviderRegistry::PROVIDER_TURNSTILE, $token, $secretKey, $remoteIp);
    }

    private static function isFilled(mixed $value): bool
    {
        if (is_array($value)) {
            foreach ($value as $item) {
                if (self::isFilled($item)) {
                    return true;
                }
            }

            return false;
        }

        if ($value === null || is_bool($value)) {
            return $value === true;
        }

        return trim((string) $value) !== '';
    }
}
