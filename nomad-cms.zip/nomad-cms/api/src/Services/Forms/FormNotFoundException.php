<?php
/**
 * NOMAD CMS - Form Not Found Exception
 *
 * Requested form or submission does not exist, or the form exists but is
 * inactive (the public endpoint treats both identically so an inactive form
 * cannot be distinguished from a non-existent one by an outside caller).
 *
 * @package NomadCMS\Services\Forms
 */

declare(strict_types=1);

namespace NomadCMS\Services\Forms;

use RuntimeException;

class FormNotFoundException extends RuntimeException
{
}
