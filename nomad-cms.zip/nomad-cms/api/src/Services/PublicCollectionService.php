<?php
/**
 * NOMAD CMS - Public Collection Service
 * High-speed public delivery service for headless frontend consumption
 *
 * Features:
 * - Public API item projection stripping sensitive, internal, and unpublished fields
 * - Fast single item lookup by slug, business ID, or UID
 * - Chunked collection listing delivery for large static frontends
 * - Integration with StaticCacheService for ultra-fast CDN/cache hits
 * - Multi-language and draft preview support
 *
 * Endpoints: Integrated via /api/endpoints/data.php (public mode)
 */

declare(strict_types=1);
namespace NomadCMS\Services;
use NomadCMS\Database\CollectionDatabase;

final class PublicCollectionService
{
    /** SQL selects only matching published rows; hydration is bounded by page size. */
    public static function readRelated(string $key, array $query): array
    {
        $db = CollectionDatabase::getInstance();
        $nested = $db->inTransaction();
        if (!$nested) {
            $db->beginTransaction();
        }
        try {
            // One read snapshot keeps publication, target visibility, count and
            // hydrated page coherent even while an editor changes a relation.
            $result = self::readRelatedSnapshot($key, $query);
            if (!$nested) {
                $db->commit();
            }
            return $result;
        } catch (\Throwable $error) {
            if (!$nested && $db->inTransaction()) {
                $db->rollBack();
            }
            throw $error;
        }
    }

    private static function readRelatedSnapshot(string $key, array $query): array
    {
        \NomadCMS\Services\Schema\SchemaProvider::lease($key);
        $schema = RelationService::loadSchema();
        $definition = $schema['slots'][$key] ?? [];
        if (($definition['type'] ?? '') !== 'collection') {
            throw new \InvalidArgumentException('Relation filtering requires a collection.');
        }
        foreach (['relation_field', 'relation_uid'] as $parameter) {
            if (!is_string($query[$parameter] ?? null) || trim($query[$parameter]) === '') {
                throw new \InvalidArgumentException('Both relation_field and relation_uid are required.');
            }
        }
        foreach (['item', 'slug', 'chunk', 'collection_page', 'admin', 'with_version', 'draft', 'preview', 'draftkey'] as $parameter) {
            if (isset($query[$parameter])) {
                throw new \InvalidArgumentException('Relation filtering cannot be combined with item, chunk, admin or preview requests.');
            }
        }
        $limit = self::pageInteger($query['limit'] ?? 20, 1, 100);
        $offset = self::pageInteger($query['offset'] ?? 0, 0, PHP_INT_MAX);
        $lang = $query['lang'] ?? null;
        if ($lang !== null && !is_string($lang)) {
            throw new \InvalidArgumentException('Invalid language.');
        }
        $field = array_column(RelationService::getRelationFields($definition['fields'] ?? []), null, 'id')[$query['relation_field']] ?? null;
        if (!$field) {
            throw new \InvalidArgumentException('Unknown relation field.');
        }
        // Validates direct visibility and publication of the target without
        // disclosing whether an inaccessible list or item exists.
        PublicListService::read($field['target'], $query['relation_uid'], $lang);
        $params = [$key, $query['relation_field'], $field['target'], $query['relation_uid']];
        $from = ' FROM slot_relations r JOIN collection_items c ON c.slot_key=r.source_key AND c.item_uid=r.source_uid'
            . ' WHERE r.source_key=? AND r.field_id=? AND r.target_key=? AND r.target_uid=? AND c.published=1';
        $db = CollectionDatabase::getInstance();
        $s = $db->prepare('SELECT COUNT(DISTINCT c.row_id)' . $from);
        $s->execute($params);
        $total = (int) $s->fetchColumn();
        $s = $db->prepare('SELECT DISTINCT c.item_uid,c.position,c.row_id' . $from
            . ' ORDER BY c.position,c.row_id LIMIT ? OFFSET ?');
        foreach ([...$params, $limit, $offset] as $index => $value) {
            $s->bindValue($index + 1, $value, is_int($value) ? \PDO::PARAM_INT : \PDO::PARAM_STR);
        }
        $s->execute();
        $items = [];
        $fallbackIdentifiers = [];
        while ($row = $s->fetch()) {
            $item = CollectionDatabase::getItem($key, $row['item_uid'], false);
            if ($item !== null) {
                $items[] = $item;
                $fallbackIdentifiers[] = (int) $row['row_id'];
            }
        }
        $entries = [];
        foreach (RelationService::projectForPublic($key, $items, $schema, false) as $index => $item) {
            $id = StaticCacheService::getItemIdentifier($item, StaticCacheService::detectItemIdentifier($definition, $item), $fallbackIdentifiers[$index]);
            $parts = PublicPayloadService::split($key, $item);
            if ($parts['locales'] !== null) {
                $parts['locales'] = PublicPayloadService::narrowLocales($parts['locales'], $lang);
            }
            $entries[] = StaticCacheService::buildListEntry($id, $parts['root'], $parts['locales'], StaticCacheService::getExcludedManifestFields($definition));
        }
        return ['success' => true, 'exists' => true, 'slot' => $key, 'data' => [
            'slot' => $key, 'type' => 'collection', 'generated_at' => gmdate('c'),
            'itemCount' => $total, 'identifierField' => 'slug', 'index' => $entries,
            'total' => $total, 'limit' => $limit, 'offset' => $offset,
            'hasMore' => $offset < $total && $limit < $total - $offset,
        ] + PublicPayloadService::envelopeLanguageMeta()];
    }

    private static function pageInteger(mixed $value, int $minimum, int $maximum): int
    {
        if ((!is_string($value) && !is_int($value)) || !preg_match('/^(0|[1-9][0-9]*)$/D', (string) $value)) {
            throw new \InvalidArgumentException('Invalid pagination parameter.');
        }
        $number = filter_var($value, FILTER_VALIDATE_INT);
        if ($number === false || $number < $minimum || $number > $maximum) {
            throw new \InvalidArgumentException('Pagination parameter outside allowed range.');
        }
        return $number;
    }

    public static function read(
        string $key,
        ?string $identifier,
        ?string $lang = null,
        bool $drafts = false
    ): array {
        \NomadCMS\Services\Schema\SchemaProvider::lease($key);
        if (\NomadCMS\Services\Schema\SchemaProvider::initialized() && !\NomadCMS\Services\Schema\SchemaProvider::slot($key)) {
            throw new \OutOfBoundsException('Content not found');
        }
        $definition = RelationService::loadSchema()["slots"][$key] ?? [];
        $chunkSize = StaticCacheService::getChunkSize();
        if (
            $identifier !== null &&
            !preg_match('/^chunk_([0-9]+)$/', $identifier, $chunk)
        ) {
            $item = CollectionDatabase::findByIdentifier($key, $identifier);
            if (
                !$item ||
                (!$drafts &&
                    !PublicPayloadService::isItemPublished($definition, $item))
            ) {
                throw new \OutOfBoundsException("Content not found");
            }
            $data = StaticCacheService::buildSingleItemPayload(
                $key,
                RelationService::projectForPublic($key, $item),
                $identifier,
                $lang
            );
        } else {
            $db = CollectionDatabase::getInstance();
            $where = "slot_key=?" . ($drafts ? "" : " AND published=1");
            $s = $db->prepare(
                "SELECT COUNT(*) FROM collection_items WHERE " . $where
            );
            $s->execute([$key]);
            $count = (int) $s->fetchColumn();
            $data = [
                "slot" => $key,
                "type" => "collection",
                "generated_at" => gmdate("c"),
            ] +
                PublicPayloadService::envelopeLanguageMeta() + [
                    "itemCount" => $count,
                    "identifierField" => "slug",
                ];
            if ($identifier === null && $count >= $chunkSize) {
                $s = $db->prepare(
                    "SELECT CAST(position / " .
                        1024 * $chunkSize .
                        " AS INTEGER) AS chunk_id,COUNT(*) AS n FROM collection_items WHERE " .
                        $where .
                        " GROUP BY chunk_id ORDER BY chunk_id"
                );
                $s->execute([$key]);
                $chunks = [];
                while ($row = $s->fetch()) {
                    $chunks[] = [
                        "index" => (int) $row["chunk_id"],
                        "path" => "chunk_" . $row["chunk_id"] . ".json",
                        "count" => (int) $row["n"],
                    ];
                }
                $data += [
                    "hasChunks" => true,
                    "chunkSize" => $chunkSize,
                    "chunks" => $chunks,
                ];
            } else {
                $params = [$key];
                $range = "";
                if ($identifier !== null) {
                    $start = (int) $chunk[1] * 1024 * $chunkSize;
                    $range = " AND position>=? AND position<?";
                    $params[] = $start;
                    $params[] = $start + 1024 * $chunkSize;
                }
                $s = $db->prepare(
                    "SELECT item_uid FROM collection_items WHERE " .
                        $where .
                        $range .
                        " ORDER BY position,row_id LIMIT " .
                        $chunkSize
                );
                $s->execute($params);
                $items = [];
                foreach ($s->fetchAll(\PDO::FETCH_COLUMN) as $uid) {
                    $items[] = CollectionDatabase::getItem($key, $uid, false);
                }
                $items = RelationService::projectForPublic(
                    $key,
                    $items,
                    null,
                    false
                );
                $entries = [];
                foreach ($items as $i => $item) {
                    $id = StaticCacheService::getItemIdentifier(
                        $item,
                        StaticCacheService::detectItemIdentifier(
                            $definition,
                            $item
                        ),
                        $i
                    );
                    $parts = PublicPayloadService::split($key, $item);
                    $entries[] = StaticCacheService::buildListEntry(
                        $id,
                        $parts["root"],
                        $parts["locales"],
                        StaticCacheService::getExcludedManifestFields(
                            $definition
                        )
                    );
                }
                if ($identifier === null) {
                    $data["index"] = $entries;
                } else {
                    $data["chunk"] = (int) $chunk[1];
                    $data["items"] = $entries;
                }
            }
        }
        return [
            "success" => true,
            "exists" => true,
            "slot" => $key,
            "data" => $data,
        ];
    }
}
