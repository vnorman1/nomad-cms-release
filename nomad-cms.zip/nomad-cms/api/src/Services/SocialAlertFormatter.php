<?php

/**
 * NOMAD CMS - Ready-made social notification messages.
 * Projects selected content into bounded Discord embeds, Slack blocks and
 * Telegram text. No JSON dumps, extra storage, HTTP calls or content hydration.
 * Provider destinations are checked before saving and again at delivery.
 */

declare(strict_types=1);

namespace NomadCMS\Services;

final class SocialAlertFormatter
{
    public const SHAPES = ['social_discord', 'social_slack', 'social_telegram'];

    public static function normalizeConfig(mixed $config): array
    {
        if ($config !== null && !is_array($config)) {
            throw new \InvalidArgumentException('Social alert settings must be an object');
        }
        $config ??= [];
        $result = [
            'title_field' => 'title', 'text_field' => 'excerpt',
            'image_field' => 'cover', 'link_field' => 'url',
            'show_image' => true, 'show_text' => true, 'show_link' => true,
            'message_template' => '',
        ];
        foreach ($result as $key => $default) {
            if (!array_key_exists($key, $config)) {
                continue;
            }
            $value = $config[$key];
            if (is_bool($default)) {
                if (!is_bool($value)) {
                    throw new \InvalidArgumentException('Social alert toggles must be boolean');
                }
            } elseif (!is_string($value)) {
                throw new \InvalidArgumentException('Social alert fields must be strings');
            } elseif ($key === 'message_template') {
                if (mb_strlen($value) > 2000) {
                    throw new \InvalidArgumentException('Social alert template exceeds 2000 characters');
                }
            } elseif (strlen($value) > 120 || !preg_match('/^[\p{L}\p{N}_-]+(?:\.[\p{L}\p{N}_-]+){0,2}$/uD', $value)) {
                throw new \InvalidArgumentException('Invalid social alert field path');
            }
            $result[$key] = $value;
        }
        return $result;
    }

    private static function field(array $data, string $path, string $locale): string
    {
        $value = $data;
        foreach (explode('.', $path) as $key) {
            if (!is_array($value) || !array_key_exists($key, $value)) {
                return '';
            }
            $value = $value[$key];
        }
        return self::text($value, 0, $locale);
    }

    private static function template(string $template, array $data, string $event, string $title, string $locale): string
    {
        return trim(preg_replace_callback('/\{\{\s*([\p{L}\p{N}_.-]+)\s*\}\}/u',
            static fn(array $match): string => match ($match[1]) {
                'event' => $event, 'title' => $title,
                default => self::field($data, $match[1], $locale),
            }, strip_tags($template)) ?? '');
    }

    public static function validateDestination(string $url, string $shape): void
    {
        if (!in_array($shape, self::SHAPES, true)) {
            return;
        }
        $parts = parse_url($url);
        $host = strtolower($parts['host'] ?? '');
        $path = $parts['path'] ?? '';
        $valid = ($parts['scheme'] ?? '') === 'https' && !isset($parts['user']) && !isset($parts['pass'])
            && !isset($parts['fragment']) && (!isset($parts['port']) || $parts['port'] === 443);
        $valid = $valid && match ($shape) {
            'social_discord' => in_array($host, ['discord.com', 'discordapp.com', 'canary.discord.com', 'ptb.discord.com'], true)
                && (bool) preg_match('~^/api/(?:v[0-9]+/)?webhooks/[0-9]+/[^/]+/?$~D', $path),
            'social_slack' => in_array($host, ['hooks.slack.com', 'hooks.slack-gov.com'], true)
                && (bool) preg_match('~^/services/[^/]+/[^/]+/[^/]+$~D', $path),
            'social_telegram' => $host === 'api.telegram.org'
                && (bool) preg_match('~^/bot[0-9]+:[A-Za-z0-9_-]+/sendMessage$~D', $path),
        };
        if (!$valid) {
            throw new \InvalidArgumentException('A Social alert célja nem megfelelő szolgáltatói webhook-cím.');
        }
        if ($shape === 'social_telegram') {
            parse_str($parts['query'] ?? '', $query);
            $chat = $query['chat_id'] ?? null;
            if (!is_string($chat) || !preg_match('/^(?:-?[0-9]+|@[A-Za-z0-9_]{5,})$/D', $chat)) {
                throw new \InvalidArgumentException('Telegramhoz chat_id vagy @csatorna szükséges.');
            }
            if (array_diff(array_keys($query), ['chat_id', 'message_thread_id']) !== []) {
                throw new \InvalidArgumentException('A Telegram-link csak chat_id és opcionális message_thread_id paramétert tartalmazhat.');
            }
            if (isset($query['message_thread_id']) && (!is_string($query['message_thread_id']) || !ctype_digit($query['message_thread_id']))) {
                throw new \InvalidArgumentException('Érvénytelen Telegram-témaazonosító.');
            }
        }
    }

    public static function format(array $envelope, string $shape, string $url, string $locale = 'hu', ?array $config = null): array
    {
        if (!in_array($shape, self::SHAPES, true)) {
            throw new \InvalidArgumentException('Unsupported social alert format');
        }
        self::validateDestination($url, $shape);
        $config = self::normalizeConfig($config);
        $locale = $locale === 'en' ? 'en' : 'hu';
        $data = is_array($envelope['data'] ?? null) ? $envelope['data'] : [];
        $event = (string) ($envelope['event'] ?? 'webhook.test');
        $label = match ($event) {
            'content.created' => 'Új tartalom',
            'content.updated' => 'Tartalom frissítve',
            'content.published' => 'Tartalom publikálva',
            'content.unpublished' => 'Publikálás visszavonva',
            'content.deleted' => 'Tartalom törölve',
            'form.submitted' => 'Új űrlapbeküldés',
            'media.uploaded' => 'Kép feltöltve',
            'media.video_uploaded' => 'Videó feltöltve',
            'media.audio_uploaded' => 'Hang feltöltve',
            'media.deleted' => 'Média törölve',
            'user.created' => 'Felhasználó létrehozva',
            'user.updated' => 'Felhasználó módosítva',
            'user.deleted' => 'Felhasználó törölve',
            'user.login' => 'Felhasználó bejelentkezett',
            'user.invited' => 'Felhasználó meghívva',
            'user.onboarded' => 'Regisztráció befejezve',
            'role.created' => 'Szerepkör létrehozva',
            'role.updated' => 'Szerepkör módosítva',
            'role.deleted' => 'Szerepkör törölve',
            'role.assigned' => 'Szerepkör kiosztva',
            'backup.created' => 'Biztonsági mentés elkészült',
            'system.panic_enabled' => 'Vészmód bekapcsolva',
            'system.panic_disabled' => 'Vészmód kikapcsolva',
            'webhook.forwarded' => 'Webhook továbbítva',
            'webhook.test' => 'Próbaértesítés',
            default => str_replace(['.', '_'], ' ', $event),
        };
        if ($locale === 'en') {
            $label = match ($event) {
                'content.created' => 'New content',
                'content.updated' => 'Content updated',
                'content.published' => 'Content published',
                'content.unpublished' => 'Content unpublished',
                'content.deleted' => 'Content deleted',
                'form.submitted' => 'New form submission',
                'media.uploaded' => 'Image uploaded',
                'media.video_uploaded' => 'Video uploaded',
                'media.audio_uploaded' => 'Audio uploaded',
                'media.deleted' => 'Media deleted',
                'user.created' => 'User created',
                'user.updated' => 'User updated',
                'user.deleted' => 'User deleted',
                'user.login' => 'User signed in',
                'user.invited' => 'User invited',
                'user.onboarded' => 'Registration completed',
                'role.created' => 'Role created',
                'role.updated' => 'Role updated',
                'role.deleted' => 'Role deleted',
                'role.assigned' => 'Role assigned',
                'backup.created' => 'Backup created',
                'system.panic_enabled' => 'Panic mode enabled',
                'system.panic_disabled' => 'Panic mode disabled',
                'webhook.forwarded' => 'Webhook forwarded',
                'webhook.test' => 'Test notification',
                default => str_replace(['.', '_'], ' ', $event),
            };
        }
        $title = ($config['title_field'] === 'title'
            ? self::first($data, ['title', 'name', 'filename', 'slug', 'id'], $locale)
            : self::field($data, $config['title_field'], $locale)) ?: 'Nomad CMS';
        $excerpt = $config['text_field'] === 'excerpt'
            ? self::first($data, ['excerpt', 'description', 'message', 'summary'], $locale)
            : self::field($data, $config['text_field'], $locale);
        if ($config['message_template'] !== '') {
            $excerpt = self::template($config['message_template'], $data, $label, $title, $locale);
        }
        if (!$config['show_text']) {
            $excerpt = '';
        }
        $slot = self::first($data, ['slot', 'form_name', 'form_slug'], $locale);
        $link = $config['show_link'] ? self::mediaUrl($config['link_field'] === 'url'
            ? self::first($data, ['url', 'permalink'], $locale)
            : self::field($data, $config['link_field'], $locale)) : '';
        $image = '';
        if ($config['show_image']) {
            $imageFields = $config['image_field'] === 'cover'
                ? ['cover', 'featured_image', 'image', 'thumbnail'] : [$config['image_field']];
            foreach ($imageFields as $field) {
                $image = self::publicImageUrl(self::field($data, $field, $locale));
                if ($image !== '') {
                    break;
                }
            }
        }
        $context = 'Nomad CMS' . ($slot !== '' ? ' · ' . $slot : '');
        $excerpt = mb_substr($excerpt, 0, $config['message_template'] !== '' ? 2000 : 600);
        if ($shape === 'social_discord') {
            $embed = [
                'author' => ['name' => mb_substr($label, 0, 256)],
                'title' => mb_substr($title, 0, 256),
                'color' => match ($event) {
                    'content.published' => 0x10B981,
                    'content.deleted', 'content.unpublished' => 0xF59E0B,
                    default => 0x6366F1,
                },
                'footer' => ['text' => mb_substr($context, 0, 200)],
                'timestamp' => gmdate('c', (int) ($envelope['timestamp'] ?? time())),
            ];
            if ($excerpt !== '') {
                $embed['description'] = $excerpt;
            }
            if ($image !== '') {
                $embed['image'] = ['url' => $image];
            }
            if ($link !== '') {
                $embed['url'] = $link;
            }
            return ['username' => 'Nomad CMS', 'allowed_mentions' => ['parse' => []], 'embeds' => [$embed]];
        }
        if ($shape === 'social_slack') {
            $blocks = [
                ['type' => 'header', 'text' => ['type' => 'plain_text', 'text' => mb_substr($label, 0, 150)]],
                ['type' => 'section', 'text' => ['type' => 'plain_text', 'text' => mb_substr($title . ($excerpt !== '' ? "\n" . $excerpt : ''), 0, 2800)]],
            ];
            if ($image !== '') {
                $blocks[] = ['type' => 'image', 'image_url' => $image, 'alt_text' => mb_substr($title, 0, 120)];
            }
            if ($link !== '') {
                $blocks[] = ['type' => 'actions', 'elements' => [[
                    'type' => 'button', 'text' => ['type' => 'plain_text', 'text' => $locale === 'en' ? 'Open' : 'Megnyitás'], 'url' => $link,
                ]]];
            }
            $blocks[] = ['type' => 'context', 'elements' => [['type' => 'plain_text', 'text' => mb_substr($context, 0, 200)]]];
            return ['text' => strtr(mb_substr($label . ' — ' . $title, 0, 600), ['&' => '&amp;', '<' => '&lt;', '>' => '&gt;']), 'blocks' => $blocks, 'unfurl_links' => false, 'unfurl_media' => false];
        }
        parse_str((string) parse_url($url, PHP_URL_QUERY), $query);
        $text = $label . "\n" . $title;
        if ($excerpt !== '') {
            $text .= "\n\n" . $excerpt;
        }
        $text .= "\n\n" . $context;
        if ($link !== '' || $image !== '') {
            $text .= "\n" . ($link ?: $image);
        }
        $body = ['chat_id' => $query['chat_id'], 'text' => mb_substr($text, 0, 3500),
            'link_preview_options' => ['is_disabled' => !$config['show_image']]];
        if ($config['show_image'] && ($image !== '' || $link !== '')) {
            $body['link_preview_options']['url'] = $image ?: $link;
            $body['link_preview_options']['prefer_large_media'] = true;
        }
        if (isset($query['message_thread_id'])) {
            $body['message_thread_id'] = (int) $query['message_thread_id'];
        }
        return $body;
    }

    private static function first(array $data, array $fields, string $locale): string
    {
        foreach ($fields as $field) {
            $value = self::text($data[$field] ?? $data['content'][$field] ?? null, 0, $locale);
            if ($value !== '') {
                return $value;
            }
        }
        return '';
    }

    private static function text(mixed $value, int $depth = 0, string $locale = 'hu'): string
    {
        if ($depth > 3) {
            return '';
        }
        if (is_array($value)) {
            foreach (['src', 'url', $locale, $locale === 'hu' ? 'en' : 'hu'] as $key) {
                if (isset($value[$key])) {
                    $text = self::text($value[$key], $depth + 1, $locale);
                    if ($text !== '') {
                        return $text;
                    }
                }
            }
            foreach (array_slice($value, 0, 5) as $child) {
                $text = self::text($child, $depth + 1, $locale);
                if ($text !== '') {
                    return $text;
                }
            }
            return '';
        }
        if (!is_scalar($value)) {
            return '';
        }
        return trim(preg_replace('/\s+/u', ' ', html_entity_decode(strip_tags(mb_substr(is_bool($value) ? ($value ? 'true' : 'false') : (string) $value, 0, 3000)), ENT_QUOTES | ENT_HTML5, 'UTF-8')) ?? '');
    }

    /** Reject clearly private origins without fetching media or introducing DNS/SSRF work. */
    private static function publicImageUrl(string $url): string
    {
        $url = self::mediaUrl($url);
        $host = strtolower(trim((string) parse_url($url, PHP_URL_HOST), '[]'));
        if ($host === 'localhost' || str_ends_with($host, '.localhost') || str_ends_with($host, '.local')
            || (filter_var($host, FILTER_VALIDATE_IP) && !filter_var($host, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE))) {
            return '';
        }
        return $url;
    }

    private static function mediaUrl(string $url): string
    {
        return filter_var($url, FILTER_VALIDATE_URL) && in_array(strtolower((string) parse_url($url, PHP_URL_SCHEME)), ['http', 'https'], true)
            ? $url : '';
    }
}
