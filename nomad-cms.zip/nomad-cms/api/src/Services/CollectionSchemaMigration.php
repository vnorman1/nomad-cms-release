<?php
/**
 * NOMAD CMS - Collection Schema Migration Engine
 * Validated structural transformation service for collection schemas and fields
 *
 * Features:
 * - Safe field renames, type conversions, and field removals
 * - Two-phase migration: dry-run inspection report and atomic application
 * - Temporary spool staging avoiding memory limits during large migrations
 * - Integrity validation checking schema hashes and target definitions
 * - Backward-compatible archival to collection_migration_archives for rollbacks
 *
 * Storage: collection_slots, collection_schema_versions, collection_migration_archives
 */

declare(strict_types=1);
namespace NomadCMS\Services;

use NomadCMS\Database\CollectionDatabase as C;
use InvalidArgumentException;

final class CollectionSchemaMigration
{
    public static function apply(
        string $key,
        array $mapping,
        bool $dryRun = true
    ): array {
        $state = C::state($key);
        if (!$state) {
            throw new InvalidArgumentException(
                "Migrate collection storage first"
            );
        }
        if (
            ($mapping["expected_schema_revision"] ?? "") !==
            $state["schema_hash"]
        ) {
            throw new InvalidArgumentException("Schema revision mismatch");
        }
        $definition = $mapping["definition"] ?? null;
        if (
            !is_array($definition) ||
            ($definition["type"] ?? "") !== "collection"
        ) {
            throw new InvalidArgumentException(
                "Collection definition required"
            );
        }
        $old = array_column(
            json_decode($state["schema_json"], true)["fields"] ?? [],
            null,
            "id"
        );
        $fields = array_column($definition["fields"] ?? [], null, "id");
        if (count($fields) !== count($definition["fields"] ?? [])) {
            throw new InvalidArgumentException("Duplicate field identifiers");
        }
        $renames = $mapping["field_mapping"] ?? [];
        foreach ($renames as $from => $to) {
            if (!isset($old[$from], $fields[$to])) {
                throw new InvalidArgumentException("Invalid field mapping");
            }
        }
        $overrides = $mapping["items"] ?? [];
        $spool = tmpfile();
        if (!$spool) {
            throw new \RuntimeException("Cannot stage schema migration");
        }
        try {
            return C::transaction(function () use (
                $key,
                $state,
                $old,
                $fields,
                $renames,
                $overrides,
                $definition,
                $dryRun,
                $spool
            ) {
                if (
                    (int) C::state($key)["revision"] !==
                    (int) $state["revision"]
                ) {
                    throw new \RuntimeException(
                        "Collection changed during schema migration"
                    );
                }
                $count = 0;
                foreach (C::iterate($key, true) as $item) {
                    $uid = $item["_dndId"];
                    $patch = $overrides["uid:" . $uid] ?? [];
                    foreach ($renames as $from => $to) {
                        if (array_key_exists($from, $item)) {
                            if (
                                array_key_exists($to, $item) &&
                                $item[$to] !== $item[$from] &&
                                !array_key_exists($to, $patch)
                            ) {
                                throw new InvalidArgumentException(
                                    "Ambiguous rename $key.$from -> $to ($uid)"
                                );
                            }
                            if (!array_key_exists($to, $item)) {
                                $item[$to] = $item[$from];
                            }
                        }
                    }
                    foreach ($fields as $id => $field) {
                        if (
                            !isset($old[$id]) ||
                            !array_key_exists($id, $item)
                        ) {
                            continue;
                        }
                        foreach (["type", "localized", "target"] as $property) {
                            $default = $property === "localized" ? false : null;
                            if (
                                ($old[$id][$property] ?? $default) !==
                                    ($field[$property] ?? $default) &&
                                !array_key_exists($id, $patch)
                            ) {
                                throw new InvalidArgumentException(
                                    "Explicit value required for $key.$id ($uid)"
                                );
                            }
                        }
                    }
                    $item = array_replace($item, $patch);
                    if (($item["_dndId"] ?? null) !== $uid) {
                        throw new InvalidArgumentException(
                            "Schema migration cannot replace identities"
                        );
                    }
                    self::validate($item, $definition);
                    fwrite(
                        $spool,
                        json_encode(
                            $item,
                            JSON_THROW_ON_ERROR |
                                JSON_UNESCAPED_UNICODE |
                                JSON_UNESCAPED_SLASHES
                        ) . "\n"
                    );
                    $count++;
                }
                if (!$dryRun) {
                    C::syncSchema($key, $definition, true);
                    rewind($spool);
                    while (($line = fgets($spool)) !== false) {
                        $item = json_decode(
                            $line,
                            true,
                            512,
                            JSON_THROW_ON_ERROR
                        );
                        C::writeItem($key, $item["_dndId"], $item, "update", [
                            "replace" => true,
                            "reindex" => true,
                            "changed_by" => "schema-migration",
                        ]);
                    }
                }
                return [
                    "slot" => $key,
                    "status" => $dryRun ? "schema_dry_run" : "schema_migrated",
                    "validated_items" => $count,
                ];
            });
        } finally {
            fclose($spool);
        }
    }

    public static function validate(array $item, array $definition): void
    {
        foreach ($definition["fields"] ?? [] as $field) {
            $id = $field["id"] ?? null;
            if (!$id || !is_string($id)) {
                throw new InvalidArgumentException("Invalid schema field");
            }
            if (!array_key_exists($id, $item)) {
                continue;
            } // New fields remain absent.
            $values = !empty($field["localized"])
                ? $item[$id]
                : ["" => $item[$id]];
            if (
                !is_array($values) ||
                (!empty($field["localized"]) &&
                    array_is_list($values) &&
                    $values !== [])
            ) {
                throw new InvalidArgumentException(
                    "Localized map required for $id"
                );
            }
            foreach ($values as $value) {
                if ($value === null) {
                    continue;
                }
                $type = $field["type"] ?? "text";
                $valid = match ($type) {
                    "number" => is_int($value) || is_float($value),
                    "boolean" => is_bool($value),
                    "text",
                    "textarea",
                    "richtext",
                    "slug",
                    "date",
                    "time",
                    "datetime",
                    "email",
                    "url"
                        => is_string($value),
                    "blocks", "gutenberg" => is_array($value) &&
                        array_is_list($value),
                    "relation" => is_string($value),
                    "relation_many" => is_array($value) &&
                        array_is_list($value) &&
                        count(array_filter($value, "is_string")) ===
                            count($value),
                    default => true,
                };
                if (!$valid) {
                    throw new InvalidArgumentException(
                        "Invalid $type value for $id"
                    );
                }
                if (($type === 'time' || isset($field['granularity']) || isset($field['extraGranularity'])) && $value !== ''
                    && \NomadCMS\Services\Schema\TemporalField::isTemporal($field)
                    && !\NomadCMS\Services\Schema\TemporalField::validValue($value, $field)) {
                    throw new InvalidArgumentException("Invalid temporal value for $id");
                }
                if (in_array($type, ["relation", "relation_many"], true)) {
                    foreach (is_array($value) ? $value : [$value] as $uid) {
                        if ($uid === "") {
                            continue;
                        }
                        $target = $field["target"] ?? "";
                        if (
                            C::isRegistered($target) &&
                            !C::row($target, $uid)
                        ) {
                            throw new InvalidArgumentException(
                                "Unresolved new relation target $target#$uid"
                            );
                        }
                    };
                }
            }
        }
    }
}
