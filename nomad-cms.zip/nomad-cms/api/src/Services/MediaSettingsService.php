<?php
/**
 * NOMAD CMS - Media Settings Service
 * Database-backed settings for media processing configuration
 */

declare(strict_types=1);

namespace NomadCMS\Services;

use NomadCMS\Database\Database;
use PDO;

final class MediaSettingsService
{
    /**
     * Configuration keys
     */
    private const CONFIG_WEBP_ENABLED_KEY = 'media.webpConversionEnabled';
    private const CONFIG_WEBP_QUALITY_KEY = 'media.webpQuality';
    
    /**
     * Default values
     */
    private const DEFAULT_WEBP_ENABLED = 'true';
    private const DEFAULT_WEBP_QUALITY = '90';
    
    /**
     * Singleton instance
     */
    private static ?self $instance = null;
    
    /**
     * Database instance
     */
    private PDO $db;
    
    /**
     * Settings cache
     */
    private ?array $settingsCache = null;
    
    /**
     * Private constructor for singleton
     */
    private function __construct()
    {
        $this->db = Database::getSystemConnection();
        $this->initializeSchema();
    }
    
    /**
     * Get singleton instance
     */
    public static function getInstance(): self
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * Initialize media settings schema
     */
    private function initializeSchema(): void
    {
        // Create media_settings table
        $this->db->exec("
            CREATE TABLE IF NOT EXISTS media_settings (
                key TEXT PRIMARY KEY,
                value TEXT NOT NULL,
                updated_at TEXT DEFAULT (datetime('now'))
            )
        ");
        
        // Insert default settings if not exists
        $this->initializeDefaultSettings();
    }
    
    /**
     * Initialize default media settings
     */
    private function initializeDefaultSettings(): void
    {
        $defaults = [
            self::CONFIG_WEBP_ENABLED_KEY => self::DEFAULT_WEBP_ENABLED,
            self::CONFIG_WEBP_QUALITY_KEY => self::DEFAULT_WEBP_QUALITY,
        ];
        
        $stmt = $this->db->prepare("
            INSERT OR IGNORE INTO media_settings (key, value) VALUES (?, ?)
        ");
        
        foreach ($defaults as $key => $value) {
            $stmt->execute([$key, $value]);
        }
    }
    
    /**
     * Check if WebP conversion is enabled
     * Priority: DB setting > .env > default true
     */
    public function isWebpConversionEnabled(): bool
    {
        $dbSetting = $this->getSetting(self::CONFIG_WEBP_ENABLED_KEY);
        
        if ($dbSetting !== null) {
            return $dbSetting === 'true';
        }
        
        return true;
    }
    
    /**
     * Get WebP quality (0-100)
     */
    public function getWebpQuality(): int
    {
        $dbSetting = $this->getSetting(self::CONFIG_WEBP_QUALITY_KEY);
        
        if ($dbSetting !== null) {
            return (int) $dbSetting;
        }
        
        // Fallback to .env
        return (int) ($_ENV['WEBP_QUALITY'] ?? self::DEFAULT_WEBP_QUALITY);
    }
    
    /**
     * Get a setting value
     */
    public function getSetting(string $key): ?string
    {
        if ($this->settingsCache === null) {
            $this->loadSettingsCache();
        }
        return $this->settingsCache[$key] ?? null;
    }
    
    /**
     * Set a setting value
     */
    public function setSetting(string $key, string $value): bool
    {
        $stmt = $this->db->prepare("
            INSERT OR REPLACE INTO media_settings (key, value, updated_at)
            VALUES (?, ?, datetime('now'))
        ");
        $result = $stmt->execute([$key, $value]);
        
        // Invalidate cache
        $this->settingsCache = null;
        
        return $result;
    }
    
    /**
     * Get all settings
     */
    public function getAllSettings(): array
    {
        if ($this->settingsCache === null) {
            $this->loadSettingsCache();
        }
        return $this->settingsCache;
    }
    
    /**
     * Load settings into cache
     */
    private function loadSettingsCache(): void
    {
        $stmt = $this->db->query("SELECT key, value FROM media_settings");
        $this->settingsCache = [];
        while ($row = $stmt->fetch()) {
            $this->settingsCache[$row['key']] = $row['value'];
        }
    }
    
    /**
     * Reset singleton (for testing)
     */
    public static function resetInstance(): void
    {
        self::$instance = null;
    }
}
