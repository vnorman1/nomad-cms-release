<?php

/**
 * NOMAD CMS - Mail URL Resolver
 *
 * Builds the two absolute URLs the verification flow needs, and does so
 * defensively - both of them end up either inside an e-mail or in a Location
 * header, which are the two worst places to get a URL wrong.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * 1. THE CONFIRMATION LINK (verifyUrl)
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * Points at the frontend's own /mails page whenever a usable base URL is
 * available (ADMIN_URL/SITE_URL, or - same as the magic-link e-mail - the
 * caller-supplied frontend base URL from the request that triggered the
 * confirmation send). The token travels in the URL FRAGMENT
 * (`/mails?verification#t=...`), never the query string, for the same reason
 * the magic-link token does: fragments never leave the browser, so they
 * cannot end up in access logs, proxy logs or a Referer header. The frontend
 * reads the fragment client-side and calls the JSON verify endpoint itself -
 * there is no backend redirect in this path at all, which is also why the
 * link no longer ends in `.php`.
 *
 * Falls back to the physical backend endpoint
 * (`.../endpoints/admin/mail-verify.php?token=...`) only when no frontend
 * base URL is known at all - an e-mail link cannot be retried with a
 * different shape, so degrading to "still works, just uglier" beats
 * "produces a dead link".
 *
 * Why the physical sibling path and not the pretty /api/admin/mail/verify
 * route for that fallback? Because the pretty route only exists where
 * rewrites are active. The dev server strips the /api prefix, a subdirectory
 * install adds one, and plenty of shared hosts have no rewrite module at all.
 * The physical path is correct in every deployment.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * 2. THE POST-VERIFICATION REDIRECT (adminUrl)
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * Used only by the legacy backend-redirect fallback path in mail-verify.php
 * (i.e. when the link itself had to fall back to the physical endpoint - see
 * (1)). Only ADMIN_URL, or SITE_URL when it is demonstrably not the API's own
 * origin, is accepted. APP_URL is deliberately NOT in the chain: the
 * installer writes APP_URL and SITE_URL as the API base, so redirecting there
 * would send the admin to a JSON 404 instead of the /mails page. When no
 * usable base exists, the verify endpoint renders its own confirmation page
 * instead of guessing.
 *
 * Every candidate is validated (absolute, http/https, host present) before use.
 * An unvalidated value here would be an open redirect reachable by anyone
 * holding a verification token.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * 3. LINKS EMBEDDED FOR AN ALREADY-AUTHENTICATED ADMIN ACTION (resolveFrontendOrigin)
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * Some links (the confirmation e-mail's link, and the magic-link "email this
 * to the user" action) are built while handling an authenticated admin
 * request that already knows exactly which frontend it came from - the
 * browser sends its own base URL (origin + SPA mount path) in the request
 * body. There is no open-redirect risk here the way there is for (2): nothing
 * is put in a Location header, the value only ends up inside an e-mail body
 * the backend itself sends, and the caller must already hold an authenticated
 * admin session to reach this code path. No CORS_ALLOWED_ORIGINS check and no
 * ADMIN_URL are needed for this to work out of the box.
 *
 * @package NomadCMS\Services\Mail
 */

declare(strict_types=1);

namespace NomadCMS\Services\Mail;

final class MailUrlResolver
{
    /**
     * The confirmation link embedded in the SMTP verification e-mail.
     *
     * Points at /mail-verify, a route deliberately OUTSIDE the SPA's
     * ProtectedRoute (mirrors the magic-link /welcome page): the token is what
     * proves the request is legitimate, not a session, so this must keep
     * working when opened on a device/browser with no admin logged in. That
     * page redeems the token, then hands off to /mails - which is itself
     * protected and will send an unauthenticated visitor to /login first,
     * returning them to /mails once they sign in.
     *
     * @param string|null $frontendBaseUrl The calling browser's own base URL
     *                     (origin + SPA mount path), as sent in the request
     *                     that triggered this e-mail. See resolveFrontendOrigin().
     */
    public static function verifyUrl(string $token, ?string $frontendBaseUrl = null): string
    {
        $frontend = self::resolveFrontendOrigin($frontendBaseUrl);
        if ($frontend !== null) {
            return $frontend . '/mail-verify#t=' . rawurlencode($token);
        }

        // No usable frontend base at all: degrade to the physical backend
        // endpoint rather than produce a dead link. mail-verify.php still
        // handles this shape (GET ?token=...) and redirects/renders as before.
        return self::apiOrigin() . self::endpointDir() . '/mail-verify.php?token=' . urlencode($token);
    }

    /**
     * Where to send the browser after a verification attempt.
     *
     * @param bool        $success  Verification outcome
     * @param string|null $reason   Machine reason on failure (expired|invalid)
     * @param string|null $profile  Uuid of the profile that was verified
     * @return string|null Null when no trustworthy admin base URL is configured
     */
    public static function adminResultUrl(bool $success, ?string $reason = null, ?string $profile = null): ?string
    {
        $base = self::adminBaseUrl();
        if ($base === null) {
            return null;
        }

        $query = ['verified' => $success ? '1' : '0'];
        if (!$success && $reason !== null) {
            $query['reason'] = $reason;
        }
        if ($success && $profile !== null && $profile !== '') {
            $query['profile'] = $profile;
        }

        return $base . '/mails?' . http_build_query($query);
    }

    /**
     * The admin SPA's origin, or null when nothing trustworthy is configured.
     *
     * Resolution order:
     *   1. ADMIN_URL - explicit override, always wins when set.
     *   2. SITE_URL - accepted only when it differs from the API's own origin
     *      (see class docblock: on a default install the installer sets both
     *      URLs equal, and redirecting there would 404).
     *
     * Deliberately does NOT fall back to Origin/Referer: this value can end up
     * in a Location header (adminResultUrl), so it must only ever be something
     * the operator configured, never something the current request claims.
     */
    public static function adminBaseUrl(): ?string
    {
        $explicit = self::normalizeBase($_ENV['ADMIN_URL'] ?? null);
        if ($explicit !== null) {
            return $explicit;
        }

        // SITE_URL is only usable when it is NOT this API's own origin. On a
        // default install the installer sets them equal, and redirecting the
        // admin to the API root would hand them a JSON 404.
        $site = self::normalizeBase($_ENV['SITE_URL'] ?? null);
        if ($site !== null && $site !== self::apiOrigin()) {
            return $site;
        }

        return null;
    }

    /**
     * Resolve the frontend base URL to embed a link for, during an
     * ALREADY-AUTHENTICATED admin action (never for a redirect).
     *
     * Order:
     *   1. ADMIN_URL / usable SITE_URL - an explicit operator setting always
     *      wins, when present.
     *   2. $requestBaseUrl - the calling browser's own base URL (origin plus
     *      the SPA's mount path, e.g. `https://host:3000/nomad`), sent by the
     *      frontend in the request body. Accepted as-is once syntactically
     *      validated (absolute http/https, host present) - no extra .env
     *      entry is required for this to work, and the mount path travels
     *      with it so a build served under a subpath (base: '/nomad/') still
     *      produces a link that resolves.
     *
     * This is safe to accept without a CORS whitelist check: the value is
     * NEVER put in a redirect/Location header (see adminResultUrl for the one
     * that is, which stays operator-configured only), it only ever ends up
     * inside the body of an e-mail the backend itself sends to the target
     * user - and the caller must already hold an authenticated admin session
     * with users:update:* to reach this code path at all.
     *
     * @param string|null $requestBaseUrl Caller-supplied base URL, e.g. from
     *                                     the request body's `frontend_origin`
     *                                     field (origin + SPA base path)
     */
    public static function resolveFrontendOrigin(?string $requestBaseUrl = null): ?string
    {
        $configured = self::adminBaseUrl();
        if ($configured !== null) {
            return $configured;
        }

        return self::normalizeBase($requestBaseUrl);
    }

    /**
     * Scheme + host (+ port) the API is reachable on.
     *
     * Prefers the configured APP_URL over the request headers: behind a reverse
     * proxy, HTTP_HOST can be an internal name that is useless in an e-mail.
     */
    private static function apiOrigin(): string
    {
        $configured = self::normalizeBase($_ENV['APP_URL'] ?? null);
        if ($configured !== null) {
            return $configured;
        }

        $scheme = self::requestIsHttps() ? 'https' : 'http';
        $host = $_SERVER['HTTP_HOST'] ?? $_SERVER['SERVER_NAME'] ?? 'localhost';
        $host = is_string($host) ? $host : 'localhost';

        // HTTP_HOST is attacker-controlled; strip anything that could break out
        // of the authority component (CR/LF header injection, path/query
        // smuggling) before it is concatenated into a URL.
        $host = preg_replace('/[^A-Za-z0-9\.\-:\[\]]/', '', $host) ?? 'localhost';

        return $scheme . '://' . ($host === '' ? 'localhost' : $host);
    }

    /**
     * Directory of the currently executing endpoint, without a trailing slash.
     */
    private static function endpointDir(): string
    {
        $script = $_SERVER['SCRIPT_NAME'] ?? '';
        $script = is_string($script) ? $script : '';

        if ($script === '') {
            // Nothing to derive from (CLI, or an exotic SAPI). The canonical
            // physical path is the best remaining guess.
            return '/endpoints/admin';
        }

        $dir = str_replace('\\', '/', dirname($script));

        return $dir === '/' || $dir === '.' ? '' : rtrim($dir, '/');
    }

    private static function requestIsHttps(): bool
    {
        if (($_SERVER['HTTPS'] ?? '') !== '' && ($_SERVER['HTTPS'] ?? 'off') !== 'off') {
            return true;
        }

        return ($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https';
    }

    /**
     * Validate and canonicalise a configured base URL.
     *
     * Returns scheme://host[:port][/path] with no trailing slash, or null when
     * the value is absent, relative, or uses a scheme a browser must never be
     * redirected to (javascript:, data:, file: ...).
     */
    public static function normalizeBase(mixed $value): ?string
    {
        if (!is_string($value)) {
            return null;
        }

        $value = trim($value);
        if ($value === '') {
            return null;
        }

        $parts = parse_url($value);
        if ($parts === false || empty($parts['scheme']) || empty($parts['host'])) {
            return null;
        }

        $scheme = strtolower($parts['scheme']);
        if ($scheme !== 'http' && $scheme !== 'https') {
            return null;
        }

        $host = $parts['host'];
        $checkHost = trim($host, '[]');
        
        $isIp = filter_var($checkHost, FILTER_VALIDATE_IP) !== false;
        $isLocalhost = strtolower($host) === 'localhost';
        $isDomain = filter_var($host, FILTER_VALIDATE_DOMAIN, FILTER_FLAG_HOSTNAME) !== false && str_contains($host, '.');

        if (!$isIp && !$isLocalhost && !$isDomain) {
            return null;
        }

        // Check path for directory traversal, null bytes, or illegal sequences
        $rawPath = $parts['path'] ?? '';
        $path = rtrim($rawPath, '/');
        if ($path !== '') {
            if (str_contains($path, '..') || str_contains($path, '//') || str_contains($path, "\0") || preg_match('/[\x00-\x1F\x7F]/', $path)) {
                return null;
            }
        }

        $port = isset($parts['port']) ? ':' . $parts['port'] : '';

        return $scheme . '://' . $host . $port . $path;
    }
}
