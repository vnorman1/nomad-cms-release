<?php

/**
 * NOMAD CMS - Deadline-aware SMTP conversation.
 * Shares one wall-clock deadline across connect, TLS, writes and reply reads.
 * Extends the installed SMTP transport only; existing MailService callers retain their behavior.
 */

declare(strict_types=1);

namespace NomadCMS\Services\Mail;

use PHPMailer\PHPMailer\SMTP;
use NomadCMS\Security\DeadlineDns;

/** Prevents a worker timeout budget being restarted for each SMTP command. */
final class DeadlineSmtp extends SMTP
{
    public function __construct(private float $deadline)
    {
    }

    private function budget(): float
    {
        $remaining = $this->deadline - microtime(true);
        if ($remaining <= 0) {
            $this->setError('SMTP conversation timed out');
            return 0;
        }
        if (is_resource($this->smtp_conn)) {
            $seconds = (int) $remaining;
            stream_set_timeout($this->smtp_conn, $seconds, (int) (($remaining - $seconds) * 1000000));
        }
        return $remaining;
    }

    public function connect($host, $port = null, $timeout = 30, $options = [])
    {
        if ($this->budget() <= 0) {
            return false;
        }
        $secure = str_starts_with($host, 'ssl://');
        $hostname = $secure ? substr($host, 6) : $host;
        try {
            $ip = DeadlineDns::resolve($hostname, $this->deadline);
        } catch (\RuntimeException) {
            $this->setError('SMTP DNS resolution timed out or failed');
            return false;
        }
        // Connecting to a numeric address must preserve the original TLS certificate identity/SNI.
        $options['ssl']['peer_name'] = trim($hostname, '[]');
        $address = str_contains($ip, ':') ? '[' . $ip . ']' : $ip;
        $remaining = $this->budget();
        return $remaining > 0 && parent::connect(($secure ? 'ssl://' : '') . $address, $port, min($timeout, $remaining), $options);
    }

    public function startTLS()
    {
        return $this->budget() > 0 && parent::startTLS();
    }

    // phpcs:ignore PSR1.Methods.CamelCapsMethodName.NotCamelCaps -- PHPMailer override.
    public function client_send($data, $command = '')
    {
        return $this->budget() > 0 ? parent::client_send($data, $command) : false;
    }

    // phpcs:ignore PSR1.Methods.CamelCapsMethodName.NotCamelCaps -- PHPMailer override.
    protected function get_lines()
    {
        $data = '';
        while (is_resource($this->smtp_conn) && !feof($this->smtp_conn)) {
            $remaining = $this->budget();
            if ($remaining <= 0 || strlen($data) > 16384) {
                break;
            }
            $read = [$this->smtp_conn];
            $write = null;
            $except = null;
            $seconds = (int) $remaining;
            if (@stream_select($read, $write, $except, $seconds, (int) (($remaining - $seconds) * 1000000)) !== 1) {
                $this->setError('SMTP reply timed out');
                break;
            }
            if ($this->budget() <= 0) {
                break;
            }
            $line = @fgets($this->smtp_conn, self::MAX_REPLY_LENGTH);
            if ($line === false) {
                break;
            }
            $data .= $line;
            if (!isset($line[3]) || in_array($line[3], [' ', "\r", "\n"], true)) {
                break;
            }
        }
        return $data;
    }
}
