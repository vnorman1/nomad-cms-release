<?php

/**
 * NOMAD CMS - Mail Service
 *
 * The single outbound e-mail path of the CMS, built on PHPMailer 7.1.1.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * WRAPPER, NOT A SUBCLASS
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * This class composes PHPMailer, it does not extend it - on purpose. PHPMailer
 * 7.0.0's only BC break was making `lang()`, `setLanguage()` and `$language`
 * static, which breaks child classes and nothing else. Staying a wrapper means
 * PHPMailer major upgrades are a composer bump plus a test run.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * TWO SEND PATHS, AND WHY BOTH EXIST
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *   sendWithConfig()  Sends using a configuration handed in directly, WITHOUT
 *                     consulting the verified/default gate. This is the only way
 *                     the confirmation e-mail can go out - at that moment the
 *                     profile is by definition still `unverified`. It is not
 *                     reachable from anything but the admin endpoint.
 *
 *   send()            The gated path everything else uses. Requires a verified
 *                     default profile (or an explicitly named verified profile)
 *                     and throws MailException::sendingDisabled() otherwise.
 *                     There is no way to bypass the gate through this method.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * ERRORS ARE CLASSIFIED, NOT FORWARDED
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * PHPMailer's ErrorInfo is a free-form English string that names hosts and
 * quotes the SMTP conversation. classify() turns it into one of a small set of
 * stable machine codes with a Hungarian, actionable message; the raw text goes
 * to the log, and only reaches the response when APP_DEBUG=true.
 *
 * @package NomadCMS\Services\Mail
 */

declare(strict_types=1);

namespace NomadCMS\Services\Mail;

use NomadCMS\Services\LoggerService;
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use Throwable;

/**
 * @phpstan-import-type MailResolved from MailProfileStore
 */
final class MailService
{
    /**
     * Factory for the underlying transport.
     *
     * Overridable so the test suite can assert the config -> PHPMailer property
     * mapping (and the error classification) without a network, an SMTP server,
     * or a 15 second timeout per assertion.
     *
     * @var (callable(): PHPMailer)|null
     */
    private static $mailerFactory = null;

    /**
     * @param (callable(): PHPMailer)|null $factory Null restores the default
     */
    public static function setMailerFactory(?callable $factory): void
    {
        self::$mailerFactory = $factory;
    }

    private static function makeMailer(): PHPMailer
    {
        if (self::$mailerFactory !== null) {
            return (self::$mailerFactory)();
        }

        // true = throw PHPMailerException instead of returning false, so a
        // failure can never be mistaken for a successful send.
        return new PHPMailer(true);
    }

    // =========================================================================
    // GATE
    // =========================================================================

    /**
     * Whether the CMS may send e-mail right now.
     *
     * Three conditions, all required:
     *   1. A default profile exists, is `verified`, and is not driver=disabled.
     *   2. FORMS_MAIL_ENABLED is not explicitly 'false'.
     *
     * On (2): before this module existed, form notifications required
     * FORMS_MAIL_ENABLED=true because mail() silently failed on most hosts. That
     * opt-in is now redundant - a verified profile is proof of delivery, which is
     * strictly better evidence than an env flag - so the flag has been demoted to
     * a kill switch: set it to 'false' to force all sending off regardless of
     * configuration. Absent or 'true' both mean "respect the profile".
     */
    public static function isEnabled(): bool
    {
        if (($_ENV['FORMS_MAIL_ENABLED'] ?? 'true') === 'false') {
            return false;
        }

        return MailProfileStore::isSendable();
    }

    /**
     * Coarse status for the admin UI header badge.
     *
     * @return 'not_configured'|'no_default'|'unverified'|'disabled'|'active'
     */
    public static function status(): string
    {
        if (!MailProfileStore::hasProfiles()) {
            return 'not_configured';
        }

        $default = MailProfileStore::defaultProfile();
        if ($default === null) {
            return 'no_default';
        }

        if (
            $default['driver'] === MailSchema::DRIVER_DISABLED
            || $default['status'] === MailSchema::STATUS_DISABLED
        ) {
            return 'disabled';
        }

        if ($default['status'] !== MailSchema::STATUS_VERIFIED) {
            return 'unverified';
        }

        return 'active';
    }

    // =========================================================================
    // SENDING
    // =========================================================================

    /**
     * Gated send through a verified profile.
     *
     * @param string      $to          Recipient address
     * @param string|null $profileUuid Null = the default profile
     * @throws MailException when sending is not enabled, or the transport fails
     */
    public static function send(
        string $to,
        string $subject,
        string $textBody,
        ?string $htmlBody = null,
        ?string $profileUuid = null,
        ?int $timeoutSeconds = null,
        ?string $messageId = null
    ): void {
        if (($_ENV['FORMS_MAIL_ENABLED'] ?? 'true') === 'false') {
            throw MailException::sendingDisabled();
        }

        $config = MailProfileStore::resolve($profileUuid);
        if ($config === null) {
            throw MailException::sendingDisabled();
        }

        if ($config['driver'] === MailSchema::DRIVER_DISABLED) {
            throw MailException::driverDisabled();
        }

        if ($config['status'] !== MailSchema::STATUS_VERIFIED) {
            throw MailException::sendingDisabled();
        }

        // A named profile that is verified but not the default is allowed: the
        // caller asked for it explicitly. Only the implicit (null) path is
        // restricted to the default, which resolve() already handled.
        self::sendWithConfig($config, $to, $subject, $textBody, $htmlBody, $timeoutSeconds, $messageId);
    }

    /**
     * Send using an explicitly supplied, already-resolved configuration.
     *
     * @param MailResolved $config Output of MailProfileStore::resolve()
     * @throws MailException classified transport failure
     */
    public static function sendWithConfig(
        array $config,
        string $to,
        string $subject,
        string $textBody,
        ?string $htmlBody = null,
        ?int $timeoutSeconds = null,
        ?string $messageId = null
    ): void {
        $uuid = $config['uuid'] !== '' ? $config['uuid'] : null;

        if ($config['driver'] === MailSchema::DRIVER_DISABLED) {
            throw MailException::driverDisabled();
        }

        if (filter_var($to, FILTER_VALIDATE_EMAIL) === false) {
            throw MailException::recipientRejected();
        }

        $mailer = self::makeMailer();

        try {
            // Queue workers can bound the entire SMTP conversation without changing profile settings.
            if ($timeoutSeconds !== null) {
                $timeoutSeconds = max(1, min(30, $timeoutSeconds));
                $config['advanced']['timeout'] = min($config['advanced']['timeout'], $timeoutSeconds);
                $mailer->setSMTPInstance(new DeadlineSmtp(microtime(true) + $timeoutSeconds));
            }
            self::configure($mailer, $config);
            if ($messageId !== null && preg_match('/^<[a-zA-Z0-9._@-]+>$/D', $messageId)) {
                $mailer->MessageID = $messageId;
            }

            $mailer->setFrom($config['from_email'], $config['from_name']);
            $mailer->addAddress($to);

            $replyTo = $config['advanced']['reply_to'];
            if ($replyTo !== null && $replyTo !== '') {
                $mailer->addReplyTo($replyTo);
            }

            $mailer->Subject = $subject;

            if ($htmlBody !== null && $htmlBody !== '') {
                $mailer->isHTML(true);
                $mailer->Body = $htmlBody;
                $mailer->AltBody = $textBody;
            } else {
                $mailer->isHTML(false);
                $mailer->Body = $textBody;
            }

            $mailer->send();

            if ($uuid !== null) {
                MailProfileStore::recordAttempt($uuid, true);
            }

            self::log('info', 'E-mail elküldve', [
                'profile' => $config['name'],
                'driver' => $config['driver'],
                'host' => $config['host'],
                'port' => $config['port'],
            ]);
        } catch (Throwable $e) {
            // PHPMailer is constructed with exceptions enabled, so a transport
            // failure arrives as PHPMailerException; anything else (a stream
            // warning promoted to an error, a bad address) is treated the same
            // way rather than escaping as an unhandled 500.
            if ($e instanceof MailException) {
                throw $e;
            }

            $errorInfo = $mailer->ErrorInfo !== '' ? $mailer->ErrorInfo : $e->getMessage();
            $failure = self::classify($errorInfo);

            if ($uuid !== null) {
                MailProfileStore::recordAttempt($uuid, false, $failure->getErrorCode());
            }

            // The raw transport text lands here and ONLY here. It can contain
            // internal hostnames and the SMTP dialogue, so it is log material -
            // MailException::suffix() decides whether any of it reaches the
            // response, and only when APP_DEBUG is on.
            self::log('error', 'E-mail küldés sikertelen', [
                'profile' => $config['name'],
                'code' => $failure->getErrorCode(),
                'host' => $config['host'],
                'port' => $config['port'],
                'detail' => self::redact($errorInfo, $config),
            ]);

            throw $failure;
        }
    }

    // =========================================================================
    // TRANSPORT CONFIGURATION
    // =========================================================================

    /**
     * Map a stored profile onto PHPMailer properties.
     *
     * @param MailResolved $config
     */
    private static function configure(PHPMailer $mailer, array $config): void
    {
        $advanced = $config['advanced'];

        $mailer->CharSet = PHPMailer::CHARSET_UTF8;
        $mailer->Encoding = PHPMailer::ENCODING_BASE64;
        // Suppress the default "X-Mailer: PHPMailer x.y.z" header: there is no
        // reason to advertise the exact library version of an internet-facing
        // system to every recipient and every relay in between.
        $mailer->XMailer = 'NOMAD CMS';

        if ($config['driver'] === MailSchema::DRIVER_MAIL) {
            $mailer->isMail();

            return;
        }

        $mailer->isSMTP();
        $mailer->Host = $config['host'];
        $mailer->Port = $config['port'];
        $mailer->Timeout = $advanced['timeout'];
        $mailer->SMTPAutoTLS = $advanced['auto_tls'];

        $mailer->SMTPSecure = match ($config['encryption']) {
            MailSchema::ENCRYPTION_SSL => PHPMailer::ENCRYPTION_SMTPS,
            MailSchema::ENCRYPTION_NONE => '',
            default => PHPMailer::ENCRYPTION_STARTTLS,
        };

        // "none" means the admin asked for a cleartext session; leaving
        // SMTPAutoTLS on would silently upgrade it anyway, which makes the
        // setting a lie and hides misconfiguration.
        if ($config['encryption'] === MailSchema::ENCRYPTION_NONE) {
            $mailer->SMTPAutoTLS = false;
        }

        $username = $config['username'];

        // Auth is driven by the presence of a username: a relay that accepts
        // unauthenticated submission from this host is a legitimate (if rare)
        // setup, and forcing AUTH would break it.
        if ($username !== '') {
            $mailer->SMTPAuth = true;
            $mailer->Username = $username;
            $mailer->Password = $config['password'];

            if ($advanced['auth_type'] !== '') {
                // Empty = negotiate from the EHLO response, which lands on LOGIN
                // or PLAIN on virtually every server. Only set it when the admin
                // deliberately pinned a mechanism.
                $mailer->AuthType = $advanced['auth_type'];
            }
        } else {
            $mailer->SMTPAuth = false;
        }

        $helo = $advanced['helo_domain'];
        if ($helo !== null && $helo !== '') {
            $mailer->Helo = $helo;
        }

        if ($advanced['allow_self_signed']) {
            // Documented, deliberate downgrade for internal relays with
            // self-signed certificates. The traffic stays encrypted but is no
            // longer protected against an active man in the middle, which is why
            // the default is false and the UI spells the trade-off out.
            $mailer->SMTPOptions = [
                'ssl' => [
                    'verify_peer' => false,
                    'verify_peer_name' => false,
                    'allow_self_signed' => true,
                ],
            ];
        }

        self::attachDebugLogging($mailer);
    }

    /**
     * Route PHPMailer's SMTP dialogue into the application log when debugging.
     *
     * Never into the HTTP response: the dialogue includes the AUTH exchange.
     * The credentials are base64 in that exchange, i.e. trivially reversible, so
     * the callback redacts anything that looks like an AUTH payload before it is
     * written anywhere.
     */
    private static function attachDebugLogging(PHPMailer $mailer): void
    {
        if (($_ENV['APP_DEBUG'] ?? 'false') !== 'true') {
            return;
        }

        $mailer->SMTPDebug = SMTP::DEBUG_CONNECTION;
        $mailer->Debugoutput = static function (string $message, int $level): void {
            if (preg_match('/\bAUTH\b|\bPASS\b/i', $message) === 1) {
                $message = '[redacted AUTH exchange]';
            }
            self::log('info', 'SMTP debug', ['level' => $level, 'line' => trim($message)]);
        };
    }

    // =========================================================================
    // ERROR CLASSIFICATION
    // =========================================================================

    /**
     * Turn PHPMailer's free-form error text into a stable, actionable failure.
     *
     * Order matters: certificate problems also mention TLS, and auth failures
     * also mention SMTP, so the most specific patterns are tested first.
     */
    public static function classify(string $errorInfo): MailException
    {
        $haystack = mb_strtolower($errorInfo);

        $matches = static fn(string ...$needles): bool => array_reduce(
            $needles,
            static fn(bool $carry, string $needle): bool => $carry || str_contains($haystack, $needle),
            false
        );

        if ($matches('certificate verify failed', 'self signed', 'self-signed', 'certificate has expired')) {
            return MailException::certVerifyFailed($errorInfo);
        }

        if (
            $matches(
                'smtp connect() failed',
                'could not connect',
                'connection refused',
                'network is unreachable',
                'name or service not known',
                'getaddrinfo',
                'no such host'
            )
        ) {
            return MailException::connectFailed($errorInfo);
        }

        if ($matches('timed out', 'timeout')) {
            return MailException::timeout($errorInfo);
        }

        if (
            $matches(
                'starttls',
                'must issue a starttls',
                'ssl operation failed',
                'wrong version number',
                'unable to connect to ssl',
                'tls'
            )
        ) {
            return MailException::tlsFailed($errorInfo);
        }

        if ($matches('could not authenticate', 'authentication failed', 'auth', '535', '534')) {
            return MailException::authFailed($errorInfo);
        }

        if ($matches('from address', 'sender address', 'mail from', 'not owned by user', '553', '550 5.7.1')) {
            return MailException::fromRejected($errorInfo);
        }

        if ($matches('recipient', 'rcpt to', 'invalid address', '554')) {
            return MailException::recipientRejected($errorInfo);
        }

        return MailException::unknown($errorInfo);
    }

    // =========================================================================
    // LOGGING
    // =========================================================================

    /**
     * Remove the credential from anything about to be logged.
     *
     * PHPMailer does not put the password in ErrorInfo today, but "today" is not
     * a security property - a future version, or a verbose server reply quoting
     * the AUTH line, could. Stripping it at the boundary costs nothing.
     *
     * @param MailResolved $config
     */
    private static function redact(string $text, array $config): string
    {
        $password = $config['password'];
        if ($password !== '') {
            $text = str_replace([$password, base64_encode($password)], '***', $text);
        }

        return mb_substr($text, 0, 2000);
    }

    /**
     * @param array<string, mixed> $context
     */
    private static function log(string $level, string $message, array $context = []): void
    {
        try {
            $context = array_merge(['component' => 'mail'], $context);

            match ($level) {
                'error' => LoggerService::error('[Mail] ' . $message, $context),
                'warning' => LoggerService::warning('[Mail] ' . $message, $context),
                default => LoggerService::info('[Mail] ' . $message, $context),
            };
        } catch (Throwable) {
            // Logging must never be the reason a send fails.
        }
    }
}
