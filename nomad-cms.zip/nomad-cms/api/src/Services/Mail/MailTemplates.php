<?php

/**
 * NOMAD CMS - Mail Templates
 *
 * Every message the CMS itself originates. Each template returns a
 * {subject, text, html} triple: text/plain is always present (some clients and
 * every screen reader prefer it, and it is what ends up in logs), HTML is the
 * pretty version.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * NO USER-SUPPLIED HTML, EVER
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * Every interpolated value goes through htmlspecialchars() for the HTML part.
 * The values here are admin-authored (profile name) or system-generated (links),
 * but a confirmation e-mail that could be talked into rendering markup would be
 * a phishing kit with our From: header on it.
 *
 * The inline CSS is deliberate: e-mail clients strip <style> blocks and have no
 * external stylesheet support worth relying on.
 *
 * @package NomadCMS\Services\Mail
 */

declare(strict_types=1);

namespace NomadCMS\Services\Mail;

final class MailTemplates
{
    /**
     * The confirmation e-mail sent with the freshly entered SMTP credentials.
     *
     * @return array{subject: string, text: string, html: string}
     */
    public static function verification(string $profileName, string $verifyUrl, int $ttlMinutes): array
    {
        $subject = 'NOMAD CMS – Confirm Email Configuration';

        $text = implode("\r\n", [
            'Confirm Email Configuration',
            '',
            'Profile: ' . $profileName,
            'Expires in: ' . $ttlMinutes . ' minutes',
            '',
            'Open the following link:',
            $verifyUrl,
            '',
            'Until confirmed, the system will not send emails.',
        ]) . "\r\n";

        $body = '<p style="margin:0 0 16px;font-size:14px;line-height:1.6;color:#33312E;">'
            . 'This email was generated using the mail profile <strong style="font-weight:700;color:#0A0A0A;">' . self::esc($profileName)
            . '</strong>. If you are seeing this message, the SMTP connection has been successfully established.'
            . '</p>'
            . self::specTable([
                'PROFILE' => self::esc($profileName),
                'STATUS' => 'Pending verification',
                'EXPIRES IN' => $ttlMinutes . ' minutes',
            ])
            . '<p style="margin:20px 0 12px;font-size:13px;line-height:1.6;color:#55534E;">'
            . 'To activate this profile and enable automated system emails, click the confirmation button below:'
            . '</p>'
            . self::button($verifyUrl, 'Confirm Configuration')
            . self::fallbackLink($verifyUrl);

        $html = self::wrap('Confirm Email Configuration', $body, 'VERIFICATION');

        return ['subject' => $subject, 'text' => $text, 'html' => $html];
    }

    /**
     * The "does it still work" test message, sent on demand from the /mails page.
     *
     * @return array{subject: string, text: string, html: string}
     */
    public static function test(string $profileName): array
    {
        $sentAt = gmdate('Y-m-d H:i:s') . ' UTC';

        $text = implode("\r\n", [
            'Test email',
            '',
            'Profile: ' . $profileName,
            'Sent: ' . $sentAt,
            '',
            'If you received this message, the SMTP configuration is working properly.',
        ]) . "\r\n";

        $body = '<p style="margin:0 0 16px;font-size:14px;line-height:1.6;color:#33312E;">'
            . 'The test email was delivered successfully. The SMTP delivery channel and authentication are active.'
            . '</p>'
            . self::specTable([
                'PROFILE' => self::esc($profileName),
                'TIMESTAMP' => self::esc($sentAt),
                'STATUS' => '✓ Operational / Active',
            ]);

        $html = self::wrap('Test Email Successful', $body, 'DIAGNOSTICS');

        return ['subject' => 'NOMAD CMS – Test Email', 'text' => $text, 'html' => $html];
    }

    /**
     * Password reset message.
     *
     * @return array{subject: string, text: string, html: string}
     */
    public static function passwordReset(string $resetUrl, ?string $userName, int $ttlMinutes = 60): array
    {
        $greeting = $userName !== null && trim($userName) !== ''
            ? 'Hello ' . trim($userName) . ','
            : 'Hello,';

        $text = implode("\r\n", [
            $greeting,
            '',
            'We received a password reset request for your account.',
            'To set a new password, open the following link:',
            $resetUrl,
            '',
            'Expires in: ' . $ttlMinutes . ' minutes (single use)',
            'Your current password remains valid until you set a new one.',
            '',
            'If you did not request this, no action is required.',
        ]) . "\r\n";

        $body = '<p style="margin:0 0 12px;font-size:15px;font-weight:700;line-height:1.5;color:#0A0A0A;">'
            . self::esc($greeting)
            . '</p>'
            . '<p style="margin:0 0 16px;font-size:14px;line-height:1.6;color:#33312E;">'
            . 'We received a password reset request for your account. Click the button below to set a new password:'
            . '</p>'
            . self::specTable([
                'REQUEST' => 'Password reset',
                'VALIDITY' => $ttlMinutes . ' minutes',
                'SECURITY' => 'Single-use link',
            ])
            . self::button($resetUrl, 'Set New Password')
            . self::fallbackLink($resetUrl);

        $html = self::wrap('Reset Your Password', $body, 'SECURITY');

        return ['subject' => 'NOMAD CMS – Reset Your Password', 'text' => $text, 'html' => $html];
    }

    /**
     * New-account invitation message (magic-link onboarding).
     *
     * @return array{subject: string, text: string, html: string}
     */
    public static function invitation(string $inviteUrl, ?string $userName, int $ttlMinutes = 60): array
    {
        $greeting = $userName !== null && trim($userName) !== ''
            ? 'Hello ' . trim($userName) . ','
            : 'Hello,';

        $text = implode("\r\n", [
            $greeting,
            '',
            'An account has been created for you in NOMAD CMS.',
            'To sign in and set your password, open the following link:',
            $inviteUrl,
            '',
            'Expires in: ' . $ttlMinutes . ' minutes (single use)',
            '',
            'If you were not expecting this invitation, no action is required.',
        ]) . "\r\n";

        $body = '<p style="margin:0 0 12px;font-size:15px;font-weight:700;line-height:1.5;color:#0A0A0A;">'
            . self::esc($greeting)
            . '</p>'
            . '<p style="margin:0 0 16px;font-size:14px;line-height:1.6;color:#33312E;">'
            . 'An account has been created for you in NOMAD CMS. '
            . 'Activate your account to complete registration and set your password:'
            . '</p>'
            . self::specTable([
                'TYPE' => 'Account invitation',
                'VALIDITY' => $ttlMinutes . ' minutes',
                'ACCESS' => 'Single-use activation link',
            ])
            . self::button($inviteUrl, 'Activate Account')
            . self::fallbackLink($inviteUrl);

        $html = self::wrap('Invitation to NOMAD CMS', $body, 'INVITATION');

        return ['subject' => 'NOMAD CMS – Invitation', 'text' => $text, 'html' => $html];
    }

    /**
     * Form submission notification.
     *
     * @return array{subject: string, text: string, html: string}
     */
    public static function formSubmission(string $formName, ?string $adminUrl, int $count = 1): array
    {
        $count = max(1, $count);
        $isBatch = $count > 1;

        $headline = $isBatch
            ? sprintf('%d new submissions received', $count)
            : 'New submission received';

        $subject = $isBatch
            ? sprintf('NOMAD CMS – %d new submissions: %s', $count, self::sanitizeHeaderValue($formName))
            : 'NOMAD CMS – New submission: ' . self::sanitizeHeaderValue($formName);

        $textLines = [
            $headline . ' for form: ' . $formName,
            '',
        ];
        if ($adminUrl !== null) {
            $textLines[] = 'Open in admin panel:';
            $textLines[] = $adminUrl;
        } else {
            $textLines[] = 'To view details, log in to the admin panel and open the Forms section.';
        }
        $text = implode("\r\n", $textLines) . "\r\n";

        $introText = $isBatch
            ? sprintf('A total of %d new submissions were received within the configured time window for the following form.', $count)
            : 'A new form submission has been received through the following channel.';

        $body = '<p style="margin:0 0 16px;font-size:14px;line-height:1.6;color:#33312E;">'
            . self::esc($introText)
            . '</p>'
            . self::specTable(
                $isBatch
                    ? ['FORM' => self::esc($formName), 'COUNT' => (string) $count, 'DATA PRIVACY' => 'End-to-end encrypted']
                    : ['FORM' => self::esc($formName), 'DATA PRIVACY' => 'End-to-end encrypted']
            );

        if ($adminUrl !== null) {
            $body .= self::button($adminUrl, 'Open in Inbox')
                . self::fallbackLink($adminUrl);
        } else {
            $body .= '<p style="margin:20px 0 0;font-size:13px;line-height:1.6;color:#55534E;">'
                . 'To view the encrypted submission content, log in to the administration panel and navigate to the '
                . '<strong style="font-weight:700;color:#0A0A0A;">Forms</strong> module.'
                . '</p>';
        }

        $html = self::wrap($headline, $body, 'FORMS');

        return ['subject' => $subject, 'text' => $text, 'html' => $html];
    }

    // =========================================================================
    // LAYOUT HELPERS
    // =========================================================================

    /**
     * Wrap message content in the NOMAD architectural email layout.
     * Theme: hsl(40, 10%, 96.5%) -> hsla(36, 33%, 97%, 1.00) warm background canvas with high-contrast sharp aesthetics.
     */
    private static function wrap(string $heading, string $body, string $badge = 'SYSTEM'): string
    {
        $year = gmdate('Y');

        return '<!DOCTYPE html>'
            . '<html lang="en" xmlns="http://www.w3.org/1999/xhtml">'
            . '<head>'
            . '<meta charset="utf-8">'
            . '<meta name="viewport" content="width=device-width,initial-scale=1.0">'
            . '<meta http-equiv="X-UA-Compatible" content="IE=edge">'
            . '<meta name="color-scheme" content="light">'
            . '<meta name="supported-color-schemes" content="light">'
            . '<title>' . self::esc($heading) . '</title>'
            . '<style>'
            . 'body { margin:0; padding:0; -webkit-text-size-adjust:100%; -ms-text-size-adjust:100%; background-color:#FAF8F5; }'
            . 'img { border:0; height:auto; line-height:100%; outline:none; text-decoration:none; }'
            . 'table { border-collapse:collapse !important; }'
            . 'a { color:#0A0A0A; text-decoration:underline; }'
            . '@media only screen and (max-width:620px) {'
            . '  .email-container { width:100% !important; max-width:100% !important; margin:0 !important; }'
            . '  .email-inner { padding:24px 16px !important; }'
            . '}'
            . '</style>'
            . '</head>'
            . '<body style="margin:0;padding:32px 12px;background-color:#FAF8F5;font-family:-apple-system,BlinkMacSystemFont,\'Segoe UI\',Roboto,\'Helvetica Neue\',Arial,sans-serif;color:#1A1917;-webkit-font-smoothing:antialiased;">'
            . '<div style="max-width:540px;margin:0 auto;" class="email-container">'
            
            // Header Bar
            . '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" style="margin-bottom:12px;">'
            . '<tr>'
            . '<td style="vertical-align:middle;text-align:left;">'
            . '<span style="font-size:20px;font-weight:900;letter-spacing:-0.05em;color:#0A0A0A;line-height:1;text-transform:uppercase;">NOMAD</span>'
            . '</td>'
            . '<td style="vertical-align:middle;text-align:right;">'
            . '<span style="display:inline-block;padding:4px 8px;background:#EFECE6;border:1px solid #E2DED6;font-family:\'SF Mono\',Monaco,Consolas,\'Liberation Mono\',monospace;font-size:9px;font-weight:700;letter-spacing:0.12em;text-transform:uppercase;color:#44413C;">'
            . '# ' . self::esc($badge)
            . '</span>'
            . '</td>'
            . '</tr>'
            . '</table>'

            // Main Content Card
            . '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" style="background-color:#FFFFFF;border:1px solid #E8E5E0;box-shadow:0 1px 3px rgba(0,0,0,0.02);">'
            . '<tr>'
            . '<td class="email-inner" style="padding:32px 28px;">'
            . '<h1 style="margin:0 0 16px;font-size:21px;font-weight:800;line-height:1.25;letter-spacing:-0.03em;color:#0A0A0A;">'
            . self::esc($heading)
            . '</h1>'
            . '<div style="font-size:14px;line-height:1.6;color:#33312E;">'
            . $body
            . '</div>'
            . '</td>'
            . '</tr>'
            
            // Card Footer / Metadata
            . '<tr>'
            . '<td style="padding:14px 28px;border-top:1px solid #F0EDE8;background-color:#FAF8F5;">'
            . '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0">'
            . '<tr>'
            . '<td style="font-family:\'SF Mono\',Monaco,Consolas,monospace;font-size:10px;letter-spacing:0.08em;text-transform:uppercase;color:#8C887F;">'
            . 'NOMAD CMS · ' . $year
            . '</td>'
            . '<td style="text-align:right;font-family:\'SF Mono\',Monaco,Consolas,monospace;font-size:10px;letter-spacing:0.08em;text-transform:uppercase;color:#8C887F;">'
            . '</td>'
            . '</tr>'
            . '</table>'
            . '</td>'
            . '</tr>'
            . '</table>'

            // Sub-footer
            . '<div style="text-align:center;margin-top:16px;">'
            . '<p style="margin:0;font-family:\'SF Mono\',Monaco,Consolas,monospace;font-size:10px;color:#A8A49C;letter-spacing:0.04em;">'
            . 'This automated system notification was generated by the NOMAD CMS mailer.'
            . '</p>'
            . '</div>'

            . '</div>'
            . '</body>'
            . '</html>';
    }

    /**
     * Technical spec / key-value table — high precision monospace grid.
     *
     * @param array<string, string> $specs Key-value pairs
     */
    private static function specTable(array $specs): string
    {
        $rows = '';
        foreach ($specs as $key => $val) {
            $rows .= '<tr>'
                . '<td style="padding:10px 14px;font-family:\'SF Mono\',Monaco,Consolas,monospace;font-size:10px;font-weight:600;letter-spacing:0.1em;text-transform:uppercase;color:#6E6B65;background-color:#FAF8F5;border-bottom:1px solid #E8E5E0;border-right:1px solid #E8E5E0;width:34%;vertical-align:middle;">'
                . self::esc((string) $key)
                . '</td>'
                . '<td style="padding:10px 14px;font-size:13px;line-height:1.4;color:#0A0A0A;background-color:#FFFFFF;border-bottom:1px solid #E8E5E0;vertical-align:middle;font-weight:600;">'
                . $val
                . '</td>'
                . '</tr>';
        }

        return '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" style="border-collapse:collapse;border:1px solid #E8E5E0;margin:20px 0;"><tbody>' . $rows . '</tbody></table>';
    }

    /**
     * Solid black geometric CTA button.
     */
    private static function button(string $url, string $label): string
    {
        return '<div style="margin:24px 0 16px;text-align:left;">'
            . '<table role="presentation" cellpadding="0" cellspacing="0" border="0" style="margin:0;">'
            . '<tr>'
            . '<td style="background-color:#0A0A0A;border:1px solid #0A0A0A;text-align:center;">'
            . '<a href="' . self::esc($url) . '" style="display:inline-block;padding:12px 24px;background-color:#0A0A0A;color:#FFFFFF;text-decoration:none;font-family:\'SF Mono\',Monaco,Consolas,monospace;font-size:11px;font-weight:700;letter-spacing:0.12em;text-transform:uppercase;border-radius:0;">'
            . self::esc($label) . ' &rarr;'
            . '</a>'
            . '</td>'
            . '</tr>'
            . '</table>'
            . '</div>';
    }

    /**
     * Monospaced code-block fallback container.
     */
    private static function fallbackLink(string $url): string
    {
        return '<div style="margin:20px 0 0;padding:12px;background-color:#FAF8F5;border:1px solid #E8E5E0;">'
            . '<p style="margin:0 0 6px;font-family:\'SF Mono\',Monaco,Consolas,monospace;font-size:9px;font-weight:700;letter-spacing:0.1em;text-transform:uppercase;color:#8C887F;">'
            . 'DIRECT LINK (IF BUTTON DOES NOT WORK):'
            . '</p>'
            . '<p style="margin:0;font-family:\'SF Mono\',Monaco,Consolas,monospace;font-size:11px;word-break:break-all;line-height:1.5;color:#0A0A0A;">'
            . '<a href="' . self::esc($url) . '" style="color:#0A0A0A;text-decoration:underline;word-break:break-all;">' . self::esc($url) . '</a>'
            . '</p>'
            . '</div>';
    }

    private static function esc(string $value): string
    {
        return htmlspecialchars($value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
    }

    /**
     * Strip CR/LF/NUL from a value about to be interpolated into a mail header.
     */
    private static function sanitizeHeaderValue(string $value): string
    {
        return trim(str_replace(["\r", "\n", "\0"], '', $value));
    }
}