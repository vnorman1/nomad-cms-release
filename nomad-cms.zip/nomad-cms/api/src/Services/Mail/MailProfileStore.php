<?php

/**
 * NOMAD CMS - Mail Profile Store
 *
 * The only reader/writer of system_mail_profiles: SMTP profile CRUD, the
 * single-default invariant, Defuse encryption of the password, and the
 * verification token lifecycle.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * TWO PROJECTIONS, AND WHY THEY MUST STAY SEPARATE
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *   masked() / list()   -> safe for any HTTP response. Carries `password_set`
 *                          (a bool) and never the password in any form.
 *   resolve()           -> server-side only. Carries the DECRYPTED password and
 *                          must never be serialized into a response.
 *
 * Unlike CaptchaConfigStore, the masked projection deliberately does NOT expose
 * a "last 4 characters" hint. For a captcha secret that is a harmless
 * recognition aid; for an SMTP password it is a real leak that measurably
 * shrinks a brute force. "Is a password stored: yes/no" is all the UI needs.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * THE DEFAULT PROFILE RULES
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * 1. Only a VERIFIED profile can be made default (MailException::notVerified).
 * 2. The first profile to reach `verified` becomes default automatically when no
 *    default exists - so the ordinary single-account setup needs no extra click.
 * 3. Editing a profile's configuration resets it to `unverified` but KEEPS the
 *    is_default flag. Sending then stops until it is re-verified. This is
 *    deliberate: silently failing over to a different SMTP identity - different
 *    envelope sender, different reputation, possibly a different organisation -
 *    is worse than a visible outage the admin can see and fix.
 * 4. Deleting the default profile is allowed but never auto-promotes a
 *    replacement, for the same reason. The endpoint returns an explicit warning.
 *
 * @package NomadCMS\Services\Mail
 */

declare(strict_types=1);

namespace NomadCMS\Services\Mail;

use NomadCMS\Security\EncryptionService;
use PDO;
use Ramsey\Uuid\Uuid;
use Throwable;

/**
 * @phpstan-type MailAdvanced array{
 *     timeout: int,
 *     auth_type: string,
 *     helo_domain: string|null,
 *     reply_to: string|null,
 *     allow_self_signed: bool,
 *     auto_tls: bool
 * }
 * @phpstan-type MailConfig array{
 *     driver: string,
 *     host: string,
 *     port: int,
 *     encryption: string,
 *     username: string,
 *     password_enc: string,
 *     from_email: string,
 *     from_name: string,
 *     status: string,
 *     verified_at: string|null,
 *     advanced: MailAdvanced
 * }
 * @phpstan-type MailResolved array{
 *     uuid: string,
 *     name: string,
 *     is_default: bool,
 *     driver: string,
 *     host: string,
 *     port: int,
 *     encryption: string,
 *     username: string,
 *     password: string,
 *     from_email: string,
 *     from_name: string,
 *     status: string,
 *     advanced: MailAdvanced
 * }
 */
final class MailProfileStore
{
    /**
     * In-process cache of the raw table rows, keyed by uuid.
     *
     * A single request may consult the mail configuration several times (gate
     * check, then resolve, then log), and every one of those would otherwise be
     * a query plus a Defuse decryption.
     *
     * @var array<string, array<string, mixed>>|null
     */
    private static ?array $cache = null;

    // =========================================================================
    // READ
    // =========================================================================

    private static function db(): PDO
    {
        MailSchema::ensure();

        return MailSchema::db();
    }

    /**
     * Load every row, default first, then alphabetically.
     *
     * @return array<string, array<string, mixed>> uuid => row
     */
    private static function rows(): array
    {
        if (self::$cache !== null) {
            return self::$cache;
        }

        $stmt = self::db()->query(
            'SELECT * FROM ' . MailSchema::TABLE . ' ORDER BY is_default DESC, name COLLATE NOCASE ASC'
        );
        $fetched = $stmt === false ? [] : $stmt->fetchAll();

        $rows = [];
        foreach ($fetched as $raw) {
            $row = self::asRow($raw);
            $uuid = self::asString($row['uuid'] ?? null);
            if ($uuid !== '') {
                $rows[$uuid] = $row;
            }
        }

        self::$cache = $rows;

        return $rows;
    }

    /**
     * Decode a row's `data` JSON into a normalized config array.
     *
     * Tolerates a corrupt/legacy blob by falling back to defaults rather than
     * throwing: a single unreadable profile must not make the whole /mails page
     * unopenable, which is precisely when an admin needs it most.
     *
     * @param array<string, mixed> $row
     * @return MailConfig
     */
    private static function decodeConfig(array $row): array
    {
        $decoded = json_decode(self::asString($row['data'] ?? null), true);
        $config = self::asRow($decoded);

        return [
            'driver' => self::enumOr($config['driver'] ?? null, MailSchema::DRIVERS, MailSchema::DRIVER_SMTP),
            'host' => self::asString($config['host'] ?? null),
            'port' => self::asInt($config['port'] ?? null, MailSchema::DEFAULT_PORTS[MailSchema::ENCRYPTION_TLS]),
            'encryption' => self::enumOr(
                $config['encryption'] ?? null,
                MailSchema::ENCRYPTIONS,
                MailSchema::ENCRYPTION_TLS
            ),
            'username' => self::asString($config['username'] ?? null),
            'password_enc' => self::asString($config['password_enc'] ?? null),
            'from_email' => self::asString($config['from_email'] ?? null),
            'from_name' => self::asString($config['from_name'] ?? null),
            'status' => self::enumOr($config['status'] ?? null, MailSchema::STATUSES, MailSchema::STATUS_UNVERIFIED),
            'verified_at' => self::asNullableString($config['verified_at'] ?? null),
            'advanced' => self::normalizeAdvanced($config['advanced'] ?? null),
        ];
    }

    /**
     * @return MailAdvanced
     */
    private static function normalizeAdvanced(mixed $value): array
    {
        $defaults = MailSchema::defaultAdvanced();
        $input = self::asRow($value);

        return [
            'timeout' => self::asInt($input['timeout'] ?? null, $defaults['timeout']),
            'auth_type' => self::enumOr($input['auth_type'] ?? null, MailSchema::AUTH_TYPES, ''),
            'helo_domain' => self::asNullableString($input['helo_domain'] ?? null),
            'reply_to' => self::asNullableString($input['reply_to'] ?? null),
            'allow_self_signed' => (bool) ($input['allow_self_signed'] ?? $defaults['allow_self_signed']),
            'auto_tls' => (bool) ($input['auto_tls'] ?? $defaults['auto_tls']),
        ];
    }

    /**
     * Every profile, masked for API output.
     *
     * @return array<int, array<string, mixed>>
     */
    public static function list(): array
    {
        $out = [];
        foreach (self::rows() as $row) {
            $out[] = self::maskRow($row);
        }

        return $out;
    }

    /**
     * One profile, masked for API output. Null when unknown.
     *
     * @return array<string, mixed>|null
     */
    public static function masked(string $uuid): ?array
    {
        $row = self::rows()[$uuid] ?? null;

        return $row === null ? null : self::maskRow($row);
    }

    /**
     * Same as masked(), but 404s instead of returning null.
     *
     * @return array<string, mixed>
     */
    public static function requireMasked(string $uuid): array
    {
        $masked = self::masked($uuid);
        if ($masked === null) {
            throw MailException::profileNotFound();
        }

        return $masked;
    }

    /**
     * Build the response-safe projection of one row.
     *
     * @param array<string, mixed> $row
     * @return array<string, mixed>
     */
    private static function maskRow(array $row): array
    {
        $config = self::decodeConfig($row);

        return [
            'uuid' => self::asString($row['uuid'] ?? null),
            'name' => self::asString($row['name'] ?? null),
            'driver' => $config['driver'],
            'host' => $config['host'],
            'port' => $config['port'],
            'encryption' => $config['encryption'],
            'username' => $config['username'],
            // The password itself never leaves this class. Only its presence.
            'password_set' => $config['password_enc'] !== '',
            'from_email' => $config['from_email'],
            'from_name' => $config['from_name'],
            'status' => $config['status'],
            'verified_at' => $config['verified_at'],
            'is_default' => self::asInt($row['is_default'] ?? null) === 1,
            'advanced' => $config['advanced'],
            'verification' => self::verificationProjection($row),
            'diagnostics' => [
                'last_success_at' => self::toIso($row['last_success_at'] ?? null),
                'last_error_at' => self::toIso($row['last_error_at'] ?? null),
                'last_error_code' => self::asNullableString($row['last_error_code'] ?? null),
            ],
            'created_at' => self::toIso($row['created_at'] ?? null),
            'updated_at' => self::toIso($row['updated_at'] ?? null),
        ];
    }

    /**
     * Pending-verification state for the UI countdown. Never the token itself.
     *
     * @param array<string, mixed> $row
     * @return array{pending: bool, expires_at: string|null, email: string|null}
     */
    private static function verificationProjection(array $row): array
    {
        $hash = self::asString($row['verification_token_hash'] ?? null);
        $expires = self::asNullableString($row['verification_expires_at'] ?? null);

        $pending = $hash !== '' && !self::isExpired($expires);

        return [
            'pending' => $pending,
            'expires_at' => $pending ? self::toIso($expires) : null,
            'email' => $pending ? self::asNullableString($row['verification_email'] ?? null) : null,
        ];
    }

    /**
     * Server-side resolution: the profile plus its DECRYPTED password.
     *
     * @param string|null $uuid Null resolves the default profile.
     * @return MailResolved|null Null when there is no such (or no default) profile
     */
    public static function resolve(?string $uuid = null): ?array
    {
        $row = $uuid === null ? self::defaultRow() : (self::rows()[$uuid] ?? null);
        if ($row === null) {
            return null;
        }

        $config = self::decodeConfig($row);

        $password = '';
        if ($config['password_enc'] !== '') {
            try {
                $password = EncryptionService::decrypt($config['password_enc']);
            } catch (Throwable $e) {
                // A profile whose password cannot be decrypted (key rotated, row
                // copied between installs) must not silently attempt an
                // unauthenticated send - that would either hand the message to an
                // open relay or fail confusingly. Treat it as no credentials and
                // let AUTH fail loudly with a classified error.
                error_log(
                    '[Mail] SMTP jelszó dekódolása sikertelen ('
                    . self::asString($row['uuid'] ?? null) . '): ' . $e->getMessage()
                );
                $password = '';
            }
        }

        return [
            'uuid' => self::asString($row['uuid'] ?? null),
            'name' => self::asString($row['name'] ?? null),
            'is_default' => self::asInt($row['is_default'] ?? null) === 1,
            'driver' => $config['driver'],
            'host' => $config['host'],
            'port' => $config['port'],
            'encryption' => $config['encryption'],
            'username' => $config['username'],
            'password' => $password,
            'from_email' => $config['from_email'],
            'from_name' => $config['from_name'],
            'status' => $config['status'],
            'advanced' => $config['advanced'],
        ];
    }

    /**
     * @return array<string, mixed>|null
     */
    private static function defaultRow(): ?array
    {
        foreach (self::rows() as $row) {
            if (self::asInt($row['is_default'] ?? null) === 1) {
                return $row;
            }
        }

        return null;
    }

    /**
     * The default profile, masked. Null when none is flagged.
     *
     * @return array<string, mixed>|null
     */
    public static function defaultProfile(): ?array
    {
        $row = self::defaultRow();

        return $row === null ? null : self::maskRow($row);
    }

    /** Whether any profile exists at all. */
    public static function hasProfiles(): bool
    {
        return self::rows() !== [];
    }

    /**
     * Whether sending is actually possible right now.
     *
     * Requires a default profile that is verified and not driver=disabled. This
     * is the single gate every caller (FormNotifier today, password reset
     * tomorrow) consults - see MailService::isEnabled(), which also honours the
     * FORMS_MAIL_ENABLED kill switch.
     */
    public static function isSendable(): bool
    {
        $row = self::defaultRow();
        if ($row === null) {
            return false;
        }

        $config = self::decodeConfig($row);

        return $config['status'] === MailSchema::STATUS_VERIFIED
            && $config['driver'] !== MailSchema::DRIVER_DISABLED;
    }

    // =========================================================================
    // WRITE
    // =========================================================================

    /**
     * Create a profile. Always lands in `unverified`.
     *
     * @param array<string, mixed> $input Raw request payload
     * @return string The new profile's uuid
     */
    public static function create(array $input): string
    {
        $name = self::validateName($input['name'] ?? null, null);
        $config = self::validateConfig($input, null);

        $uuid = Uuid::uuid4()->toString();

        $stmt = self::db()->prepare(
            'INSERT INTO ' . MailSchema::TABLE . ' (uuid, name, data, is_default, created_at, updated_at)
             VALUES (:uuid, :name, :data, 0, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)'
        );
        $stmt->execute([
            'uuid' => $uuid,
            'name' => $name,
            'data' => self::encodeConfig($config),
        ]);

        self::$cache = null;

        return $uuid;
    }

    /**
     * Update a profile.
     *
     * Any change to the configuration drops it back to `unverified` and
     * invalidates the outstanding verification token, while KEEPING is_default
     * (see rule 3 in the class docblock).
     *
     * @param array<string, mixed> $input
     */
    public static function update(string $uuid, array $input): void
    {
        $row = self::rows()[$uuid] ?? null;
        if ($row === null) {
            throw MailException::profileNotFound();
        }

        $existing = self::decodeConfig($row);

        $name = array_key_exists('name', $input)
            ? self::validateName($input['name'], $uuid)
            : self::asString($row['name'] ?? null);

        $config = self::validateConfig($input, $existing);

        $stmt = self::db()->prepare(
            'UPDATE ' . MailSchema::TABLE . '
                SET name = :name,
                    data = :data,
                    verification_token_hash = NULL,
                    verification_expires_at = NULL,
                    verification_email = NULL,
                    updated_at = CURRENT_TIMESTAMP
              WHERE uuid = :uuid'
        );
        $stmt->execute([
            'uuid' => $uuid,
            'name' => $name,
            'data' => self::encodeConfig($config),
        ]);

        self::$cache = null;
    }

    /**
     * Delete a profile.
     *
     * @return bool True when the deleted profile was the default one, i.e. mail
     *              sending has just stopped and the caller must say so.
     */
    public static function delete(string $uuid): bool
    {
        $row = self::rows()[$uuid] ?? null;
        if ($row === null) {
            throw MailException::profileNotFound();
        }

        $wasDefault = self::asInt($row['is_default'] ?? null) === 1;

        $stmt = self::db()->prepare('DELETE FROM ' . MailSchema::TABLE . ' WHERE uuid = :uuid');
        $stmt->execute(['uuid' => $uuid]);

        self::$cache = null;

        return $wasDefault;
    }

    /**
     * Make a profile the default one.
     *
     * Runs in a transaction because it is a two-statement invariant: clearing the
     * old default and setting the new one must not be observable (or
     * interruptible) in between, or the partial unique index would reject the
     * second statement and leave the system with no default at all.
     */
    public static function setDefault(string $uuid): void
    {
        $row = self::rows()[$uuid] ?? null;
        if ($row === null) {
            throw MailException::profileNotFound();
        }

        $config = self::decodeConfig($row);
        if ($config['driver'] === MailSchema::DRIVER_DISABLED) {
            throw MailException::driverDisabled();
        }
        if ($config['status'] !== MailSchema::STATUS_VERIFIED) {
            throw MailException::notVerified();
        }

        $db = self::db();
        $db->beginTransaction();
        try {
            $db->exec('UPDATE ' . MailSchema::TABLE . ' SET is_default = 0 WHERE is_default = 1');

            $stmt = $db->prepare(
                'UPDATE ' . MailSchema::TABLE . '
                    SET is_default = 1, updated_at = CURRENT_TIMESTAMP
                  WHERE uuid = :uuid'
            );
            $stmt->execute(['uuid' => $uuid]);

            $db->commit();
        } catch (Throwable $e) {
            $db->rollBack();
            throw $e;
        }

        self::$cache = null;
    }

    /**
     * Switch a profile off: driver AND status both become `disabled`, and it
     * gives up the default flag.
     *
     * Dropping the default flag here (unlike on a plain edit) is safe and
     * desirable: the admin has explicitly said "do not send from this", so
     * leaving it flagged as default would record an intent that can never be
     * honoured.
     *
     * The previous driver is remembered under `driver_before_disable` so that
     * enable() is lossless. Without it, re-enabling a `mail` driver profile would
     * silently turn it into an SMTP one (or force the admin to re-pick), because
     * `driver` itself has been overwritten with the sentinel value.
     */
    public static function disable(string $uuid): void
    {
        $row = self::rows()[$uuid] ?? null;
        if ($row === null) {
            throw MailException::profileNotFound();
        }

        $config = self::decodeConfig($row);
        $previousDriver = $config['driver'] === MailSchema::DRIVER_DISABLED
            ? self::previousDriver($row)
            : $config['driver'];

        $config['driver'] = MailSchema::DRIVER_DISABLED;
        $config['status'] = MailSchema::STATUS_DISABLED;

        $stmt = self::db()->prepare(
            'UPDATE ' . MailSchema::TABLE . '
                SET data = :data,
                    is_default = 0,
                    verification_token_hash = NULL,
                    verification_expires_at = NULL,
                    verification_email = NULL,
                    updated_at = CURRENT_TIMESTAMP
              WHERE uuid = :uuid'
        );
        $stmt->execute([
            'uuid' => $uuid,
            'data' => self::encodeConfig($config, $previousDriver),
        ]);

        self::$cache = null;
    }

    /**
     * Switch a disabled profile back on.
     *
     * Restores the driver it had before being disabled and lands in
     * `unverified` - never straight back to `verified`. Re-verification is
     * required because the profile may have been off for months: the credentials
     * could have been rotated, the host retired, the sender domain moved. The
     * caller is expected to send a fresh confirmation immediately (see the
     * `enable` action in admin/mail-settings.php).
     *
     * It does NOT regain the default flag either - disable() gave it up
     * deliberately, and re-acquiring it silently would start routing mail through
     * a profile the admin has not re-confirmed.
     */
    public static function enable(string $uuid): void
    {
        $row = self::rows()[$uuid] ?? null;
        if ($row === null) {
            throw MailException::profileNotFound();
        }

        $config = self::decodeConfig($row);
        $config['driver'] = self::previousDriver($row);
        $config['status'] = MailSchema::STATUS_UNVERIFIED;
        $config['verified_at'] = null;

        $stmt = self::db()->prepare(
            'UPDATE ' . MailSchema::TABLE . '
                SET data = :data,
                    verification_token_hash = NULL,
                    verification_expires_at = NULL,
                    verification_email = NULL,
                    updated_at = CURRENT_TIMESTAMP
              WHERE uuid = :uuid'
        );
        $stmt->execute([
            'uuid' => $uuid,
            'data' => self::encodeConfig($config),
        ]);

        self::$cache = null;
    }

    /**
     * The driver a profile had before it was disabled.
     *
     * Falls back to SMTP: that is the only driver that can be meaningfully
     * configured, and a row written before this bookkeeping existed has no
     * record of its original value.
     *
     * @param array<string, mixed> $row
     */
    private static function previousDriver(array $row): string
    {
        $decoded = json_decode(self::asString($row['data'] ?? null), true);
        $config = self::asRow($decoded);

        return self::enumOr(
            $config['driver_before_disable'] ?? null,
            [MailSchema::DRIVER_SMTP, MailSchema::DRIVER_MAIL],
            MailSchema::DRIVER_SMTP
        );
    }

    /**
     * Record the outcome of a send attempt on the profile row.
     *
     * Operational state only - it never touches `data`, so a failed send cannot
     * corrupt the configuration, and a config rewrite cannot erase the
     * diagnostic history the admin is using to debug.
     *
     * A SUCCESS clears last_error_code: the code is a "current problem" marker,
     * not an append-only log, and leaving a stale one behind after the profile
     * has demonstrably worked again is actively misleading (the admin sees
     * "Címzett elutasítva" on a profile that is now happily sending). last_error_at
     * is kept as a historical timestamp - only the actionable code is reset.
     */
    public static function recordAttempt(string $uuid, bool $success, ?string $errorCode = null): void
    {
        try {
            if ($success) {
                $stmt = self::db()->prepare(
                    'UPDATE ' . MailSchema::TABLE . '
                        SET last_success_at = CURRENT_TIMESTAMP,
                            last_error_code = NULL
                      WHERE uuid = :uuid'
                );
                $stmt->execute(['uuid' => $uuid]);
            } else {
                $stmt = self::db()->prepare(
                    'UPDATE ' . MailSchema::TABLE . '
                        SET last_error_at = CURRENT_TIMESTAMP,
                            last_error_code = :code
                      WHERE uuid = :uuid'
                );
                $stmt->execute(['uuid' => $uuid, 'code' => $errorCode ?? 'UNKNOWN']);
            }

            self::$cache = null;
        } catch (Throwable $e) {
            // Bookkeeping must never turn a send failure into a fatal error.
            error_log('[Mail] Diagnosztika mentése sikertelen: ' . $e->getMessage());
        }
    }

    // =========================================================================
    // VERIFICATION TOKEN LIFECYCLE
    // =========================================================================

    /**
     * Issue a fresh verification token for a profile and return the RAW token.
     *
     * The raw value is returned exactly once, to be embedded in the confirmation
     * e-mail; only its SHA-256 hash is stored. Issuing a new token invalidates
     * any previous one for that profile, because there is a single hash column.
     *
     * @param string $email Where the confirmation is being sent. Stored so
     *                      verification can never be talked into trusting an
     *                      address supplied later in the link.
     */
    public static function issueVerificationToken(string $uuid, string $email): string
    {
        if (!isset(self::rows()[$uuid])) {
            throw MailException::profileNotFound();
        }

        $token = bin2hex(random_bytes(MailSchema::VERIFICATION_TOKEN_BYTES));

        $stmt = self::db()->prepare(
            'UPDATE ' . MailSchema::TABLE . '
                SET verification_token_hash = :hash,
                    verification_expires_at = :expires,
                    verification_email = :email,
                    updated_at = CURRENT_TIMESTAMP
              WHERE uuid = :uuid'
        );
        $stmt->execute([
            'uuid' => $uuid,
            'hash' => hash('sha256', $token),
            // Stored as UTC, like every other timestamp in this codebase. PHP
            // runs in Europe/Budapest while SQLite's CURRENT_TIMESTAMP is UTC,
            // so writing a local-time string here would shift the deadline by the
            // UTC offset - see MagicLinkService for the same trap.
            'expires' => gmdate('Y-m-d H:i:s', time() + MailSchema::VERIFICATION_TTL),
            'email' => $email,
        ]);

        self::$cache = null;

        return $token;
    }

    /**
     * Redeem a verification token.
     *
     * Looks the hash up across every profile (indexed), then confirms with
     * hash_equals. Single use: success clears the token columns. When no profile
     * is currently the default, the freshly verified one is promoted - so the
     * common single-account setup needs no extra step.
     *
     * @return array<string, mixed> The masked profile that was verified
     * @throws MailException on a malformed, unknown or expired token
     */
    public static function consumeVerificationToken(string $token): array
    {
        // Cheap shape check first: the token is always 64 hex chars, so anything
        // else is rejected without touching the database at all.
        if (preg_match('/^[a-f0-9]{64}$/', $token) !== 1) {
            throw MailException::invalidToken();
        }

        $hash = hash('sha256', $token);

        $stmt = self::db()->prepare(
            'SELECT * FROM ' . MailSchema::TABLE . ' WHERE verification_token_hash = :hash LIMIT 1'
        );
        $stmt->execute(['hash' => $hash]);
        $fetched = $stmt->fetch();

        if (!is_array($fetched)) {
            throw MailException::invalidToken();
        }

        $row = self::asRow($fetched);

        // Belt and braces after an equality lookup: keeps the comparison
        // constant-time even if the lookup is ever loosened.
        if (!hash_equals(self::asString($row['verification_token_hash'] ?? null), $hash)) {
            throw MailException::invalidToken();
        }

        if (self::isExpired(self::asNullableString($row['verification_expires_at'] ?? null))) {
            throw MailException::expiredToken();
        }

        $uuid = self::asString($row['uuid'] ?? null);
        $config = self::decodeConfig($row);
        $config['status'] = MailSchema::STATUS_VERIFIED;
        $config['verified_at'] = gmdate('Y-m-d\TH:i:s\Z');

        $promote = self::defaultRow() === null;

        $db = self::db();
        $db->beginTransaction();
        try {
            $update = $db->prepare(
                'UPDATE ' . MailSchema::TABLE . '
                    SET data = :data,
                        verification_token_hash = NULL,
                        verification_expires_at = NULL,
                        verification_email = NULL,
                        last_error_code = NULL,
                        updated_at = CURRENT_TIMESTAMP
                  WHERE uuid = :uuid'
            );
            $update->execute([
                'uuid' => $uuid,
                'data' => self::encodeConfig($config),
            ]);

            if ($promote) {
                $flag = $db->prepare('UPDATE ' . MailSchema::TABLE . ' SET is_default = 1 WHERE uuid = :uuid');
                $flag->execute(['uuid' => $uuid]);
            }

            $db->commit();
        } catch (Throwable $e) {
            $db->rollBack();
            throw $e;
        }

        self::$cache = null;

        return self::requireMasked($uuid);
    }

    /**
     * The address a pending verification was sent to, if any.
     */
    public static function pendingVerificationEmail(string $uuid): ?string
    {
        $row = self::rows()[$uuid] ?? null;
        if ($row === null) {
            return null;
        }

        $projection = self::verificationProjection($row);

        return $projection['pending'] ? $projection['email'] : null;
    }

    // =========================================================================
    // VALIDATION
    // =========================================================================

    /**
     * @param array<string, mixed> $input
     * @param MailConfig|null $existing Decoded current config on update
     * @return MailConfig Normalized config ready for encodeConfig()
     */
    private static function validateConfig(array $input, ?array $existing): array
    {
        $errors = [];
        $base = $existing ?? [
            'driver' => MailSchema::DRIVER_SMTP,
            'host' => '',
            'port' => MailSchema::DEFAULT_PORTS[MailSchema::ENCRYPTION_TLS],
            'encryption' => MailSchema::ENCRYPTION_TLS,
            'username' => '',
            'password_enc' => '',
            'from_email' => '',
            'from_name' => '',
            'status' => MailSchema::STATUS_UNVERIFIED,
            'verified_at' => null,
            'advanced' => MailSchema::defaultAdvanced(),
        ];

        // ---- driver -------------------------------------------------------
        $driver = self::asString(self::pick($input, 'driver', $base['driver']));
        if (!in_array($driver, MailSchema::DRIVERS, true)) {
            $errors['driver'] = 'Érvénytelen küldési mód.';
            $driver = MailSchema::DRIVER_SMTP;
        }

        // ---- encryption ---------------------------------------------------
        $encryption = self::asString(self::pick($input, 'encryption', $base['encryption']));
        if (!in_array($encryption, MailSchema::ENCRYPTIONS, true)) {
            $errors['encryption'] = 'Érvénytelen titkosítási mód.';
            $encryption = MailSchema::ENCRYPTION_TLS;
        }

        // ---- host / port --------------------------------------------------
        $host = trim(self::asString(self::pick($input, 'host', $base['host'])));
        $port = self::asInt(self::pick($input, 'port', $base['port']), $base['port']);

        if ($driver === MailSchema::DRIVER_SMTP) {
            if ($host === '') {
                $errors['host'] = 'Az SMTP kiszolgáló megadása kötelező.';
            } elseif (!self::isValidHost($host)) {
                $errors['host'] = 'Az SMTP kiszolgáló neve érvénytelen.';
            } elseif (!self::isAllowedHost($host)) {
                $errors['host'] = 'Helyi/belső cím nem engedélyezett. '
                    . 'Fejlesztéshez állítsd be a MAIL_ALLOW_LOCAL=true értéket.';
            }

            if (!in_array($port, MailSchema::ALLOWED_PORTS, true)) {
                $errors['port'] = 'Csak a következő portok engedélyezettek: '
                    . implode(', ', MailSchema::ALLOWED_PORTS) . '.';
            }
        }

        // ---- identity -----------------------------------------------------
        $fromEmail = trim(self::asString(self::pick($input, 'from_email', $base['from_email'])));
        if ($fromEmail === '') {
            $errors['from_email'] = 'A feladó e-mail cím megadása kötelező.';
        } elseif (filter_var($fromEmail, FILTER_VALIDATE_EMAIL) === false) {
            $errors['from_email'] = 'A feladó e-mail cím érvénytelen.';
        }

        $fromName = self::sanitizeHeader(self::asString(self::pick($input, 'from_name', $base['from_name'])));
        if (mb_strlen($fromName) > 128) {
            $errors['from_name'] = 'A feladó neve legfeljebb 128 karakter lehet.';
        }

        // ---- credentials --------------------------------------------------
        $username = trim(self::asString(self::pick($input, 'username', $base['username'])));
        if (mb_strlen($username) > 190) {
            $errors['username'] = 'A felhasználónév túl hosszú.';
        }

        $passwordEnc = self::resolvePasswordEnc(
            $base['password_enc'],
            isset($input['password']) && is_string($input['password']) ? $input['password'] : null,
            (bool) ($input['clear_password'] ?? false)
        );

        // ---- advanced -----------------------------------------------------
        $advanced = self::validateAdvanced(
            self::asRow($input['advanced'] ?? null),
            $base['advanced'],
            $errors
        );

        if ($errors !== []) {
            throw new MailValidationException($errors);
        }

        return [
            'driver' => $driver,
            'host' => $host,
            'port' => $port,
            'encryption' => $encryption,
            'username' => $username,
            'password_enc' => $passwordEnc,
            'from_email' => $fromEmail,
            'from_name' => $fromName,
            // Every configuration write lands unverified. There is no code path
            // that lets a caller assert `verified` - only
            // consumeVerificationToken() can grant it.
            'status' => $driver === MailSchema::DRIVER_DISABLED
                ? MailSchema::STATUS_DISABLED
                : MailSchema::STATUS_UNVERIFIED,
            'verified_at' => null,
            'advanced' => $advanced,
        ];
    }

    /**
     * @param array<string, mixed> $input
     * @param MailAdvanced $base
     * @param array<string, string> $errors
     * @return MailAdvanced
     */
    private static function validateAdvanced(array $input, array $base, array &$errors): array
    {
        $timeout = self::asInt(self::pick($input, 'timeout', $base['timeout']), $base['timeout']);
        if ($timeout < MailSchema::TIMEOUT_MIN || $timeout > MailSchema::TIMEOUT_MAX) {
            $errors['advanced.timeout'] = sprintf(
                'Az időtúllépés %d és %d másodperc között lehet.',
                MailSchema::TIMEOUT_MIN,
                MailSchema::TIMEOUT_MAX
            );
            $timeout = MailSchema::TIMEOUT_DEFAULT;
        }

        $authType = self::asString(self::pick($input, 'auth_type', $base['auth_type']));
        if (!in_array($authType, MailSchema::AUTH_TYPES, true)) {
            $errors['advanced.auth_type'] = 'Érvénytelen hitelesítési mód.';
            $authType = '';
        }

        $helo = trim(self::asString(self::pick($input, 'helo_domain', $base['helo_domain'])));
        if ($helo !== '' && !self::isValidHost($helo)) {
            $errors['advanced.helo_domain'] = 'A HELO/EHLO domain érvénytelen.';
        }

        $replyTo = trim(self::asString(self::pick($input, 'reply_to', $base['reply_to'])));
        if ($replyTo !== '' && filter_var($replyTo, FILTER_VALIDATE_EMAIL) === false) {
            $errors['advanced.reply_to'] = 'A válaszcím érvénytelen.';
        }

        return [
            'timeout' => $timeout,
            'auth_type' => $authType,
            'helo_domain' => $helo === '' ? null : $helo,
            'reply_to' => $replyTo === '' ? null : $replyTo,
            'allow_self_signed' => (bool) self::pick($input, 'allow_self_signed', $base['allow_self_signed']),
            'auto_tls' => (bool) self::pick($input, 'auto_tls', $base['auto_tls']),
        ];
    }

    /**
     * Validate the admin-facing name and enforce uniqueness.
     *
     * @param string|null $selfUuid Uuid to exclude from the uniqueness check (update)
     */
    private static function validateName(mixed $value, ?string $selfUuid): string
    {
        $name = self::sanitizeHeader(self::asString($value));

        if ($name === '') {
            throw new MailValidationException(['name' => 'A profil nevének megadása kötelező.']);
        }
        if (mb_strlen($name) > MailSchema::NAME_MAX_LENGTH) {
            throw new MailValidationException([
                'name' => 'A profil neve legfeljebb ' . MailSchema::NAME_MAX_LENGTH . ' karakter lehet.',
            ]);
        }

        foreach (self::rows() as $row) {
            if ($selfUuid !== null && self::asString($row['uuid'] ?? null) === $selfUuid) {
                continue;
            }
            if (mb_strtolower(self::asString($row['name'] ?? null)) === mb_strtolower($name)) {
                throw MailException::nameTaken($name);
            }
        }

        return $name;
    }

    /**
     * Encrypt a new password, keep the existing ciphertext, or clear it.
     *
     * Mirrors CaptchaConfigStore::resolveSecretEnc(): an absent/empty password
     * field means "leave it alone" so the admin can edit the host without
     * retyping the credential, and blanking it requires the explicit
     * clear_password flag.
     */
    private static function resolvePasswordEnc(string $existingEnc, ?string $newPlain, bool $clear): string
    {
        if ($clear) {
            return '';
        }

        if ($newPlain === null || $newPlain === '') {
            return $existingEnc;
        }

        if (!EncryptionService::isConfigured()) {
            throw MailException::encryptionUnavailable();
        }

        return EncryptionService::encrypt($newPlain);
    }

    // =========================================================================
    // TYPE NARROWING HELPERS
    // =========================================================================

    /**
     * @param array<string, mixed> $input
     */
    private static function pick(array $input, string $key, mixed $fallback): mixed
    {
        return array_key_exists($key, $input) && $input[$key] !== null ? $input[$key] : $fallback;
    }

    /**
     * Narrow an arbitrary decoded value to a string-keyed array.
     *
     * Everything entering this class comes from either PDO (mixed rows) or
     * json_decode (mixed), and the whole file is written to be provably safe at
     * PHPStan level max rather than casting `mixed` and hoping.
     *
     * @return array<string, mixed>
     */
    private static function asRow(mixed $value): array
    {
        if (!is_array($value)) {
            return [];
        }

        $out = [];
        foreach ($value as $key => $item) {
            $out[(string) $key] = $item;
        }

        return $out;
    }

    private static function asString(mixed $value, string $default = ''): string
    {
        if (is_string($value)) {
            return $value;
        }
        if (is_int($value) || is_float($value)) {
            return (string) $value;
        }

        return $default;
    }

    private static function asNullableString(mixed $value): ?string
    {
        $string = self::asString($value);

        return $string === '' ? null : $string;
    }

    private static function asInt(mixed $value, int $default = 0): int
    {
        if (is_int($value)) {
            return $value;
        }
        if (is_float($value)) {
            return (int) $value;
        }
        if (is_string($value) && preg_match('/^-?\d+$/', $value) === 1) {
            return (int) $value;
        }

        return $default;
    }

    /**
     * @param array<int, string> $allowed
     */
    private static function enumOr(mixed $value, array $allowed, string $fallback): string
    {
        $string = self::asString($value);

        return in_array($string, $allowed, true) ? $string : $fallback;
    }

    /**
     * Strip CR/LF/NUL from anything that may end up in a mail header.
     *
     * PHPMailer validates headers itself, but the profile name and sender name
     * are also written to logs and rendered in the UI, so they get scrubbed at
     * the boundary rather than relying on every downstream consumer.
     */
    private static function sanitizeHeader(string $value): string
    {
        return trim(str_replace(["\r", "\n", "\0"], '', $value));
    }

    /**
     * Hostname or IP literal, syntactically.
     */
    private static function isValidHost(string $host): bool
    {
        if (filter_var($host, FILTER_VALIDATE_IP) !== false) {
            return true;
        }

        return preg_match('/^(?=.{1,253}$)([a-z0-9]([a-z0-9\-]{0,61}[a-z0-9])?\.)*[a-z]{2,63}$/i', $host) === 1;
    }

    /**
     * Reject loopback / link-local / reserved targets.
     *
     * Saving a profile makes the server dial an admin-supplied host:port and
     * report a distinguishable error per outcome. Combined with the port
     * whitelist, blocking the reserved ranges is what stops this from being a
     * probe against services bound to the CMS host itself (or a cloud metadata
     * endpoint). MAIL_ALLOW_LOCAL exists for MailHog/Mailpit style local
     * development.
     *
     * Other private ranges (10/8, 192.168/16) stay allowed on purpose: an
     * on-premise mail relay on the LAN is a completely legitimate setup.
     */
    private static function isAllowedHost(string $host): bool
    {
        if (($_ENV['MAIL_ALLOW_LOCAL'] ?? 'false') === 'true') {
            return true;
        }

        $lower = mb_strtolower($host);
        if ($lower === 'localhost' || str_ends_with($lower, '.localhost') || $lower === 'localhost.localdomain') {
            return false;
        }

        if (filter_var($host, FILTER_VALIDATE_IP) !== false) {
            return filter_var($host, FILTER_VALIDATE_IP, FILTER_FLAG_NO_RES_RANGE) !== false;
        }

        return true;
    }

    /**
     * @param MailConfig $config
     * @param string|null $driverBeforeDisable Remembered so enable() is lossless
     */
    private static function encodeConfig(array $config, ?string $driverBeforeDisable = null): string
    {
        $payload = $config;
        if ($driverBeforeDisable !== null) {
            $payload['driver_before_disable'] = $driverBeforeDisable;
        }

        $json = json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

        return $json === false ? '{}' : $json;
    }

    // =========================================================================
    // TIME HELPERS
    // =========================================================================

    /**
     * SQLite stores UTC; PHP runs in local time. Every timestamp handed to a
     * client is ISO-8601 with an explicit Z so neither side can misread it.
     */
    private static function toIso(mixed $utcSqlTimestamp): ?string
    {
        $value = self::asString($utcSqlTimestamp);
        if ($value === '') {
            return null;
        }

        // Already ISO-8601 (verified_at is written that way).
        if (str_ends_with($value, 'Z')) {
            return $value;
        }

        $ts = strtotime($value . ' UTC');

        return $ts === false ? null : gmdate('Y-m-d\TH:i:s\Z', $ts);
    }

    private static function isExpired(?string $utcSqlTimestamp): bool
    {
        if ($utcSqlTimestamp === null || $utcSqlTimestamp === '') {
            return true;
        }

        $ts = strtotime($utcSqlTimestamp . ' UTC');

        return $ts === false || $ts <= time();
    }

    // =========================================================================
    // TEST SUPPORT
    // =========================================================================

    /**
     * Drop the in-process row cache. Test-only; a normal request reads the table
     * at most once.
     */
    public static function clearCache(): void
    {
        self::$cache = null;
    }
}
