<?php

/**
 * NOMAD CMS - Mail Exception
 *
 * Every failure mode of the e-mail subsystem, each carrying an HTTP status and
 * a stable machine code. The message text is Hungarian and written for the
 * admin who is staring at the SMTP form wondering why nothing arrives - it
 * should say what went wrong AND what to try next.
 *
 * The machine codes are part of the API contract: the frontend maps them to
 * inline hints, and the profile row records the last one in
 * `last_error_code`. Renaming one is a breaking change.
 *
 * @package NomadCMS\Services\Mail
 */

declare(strict_types=1);

namespace NomadCMS\Services\Mail;

class MailException extends \RuntimeException
{
    private int $statusCode;

    private string $errorCode;

    public function __construct(string $message, int $statusCode = 400, string $errorCode = 'MAIL_ERROR')
    {
        parent::__construct($message);

        $this->statusCode = $statusCode;
        $this->errorCode = $errorCode;
    }

    public function getStatusCode(): int
    {
        return $this->statusCode;
    }

    public function getErrorCode(): string
    {
        return $this->errorCode;
    }

    // =========================================================================
    // CONFIGURATION / STORE
    // =========================================================================

    /**
     * A password was submitted while ENCRYPTION_KEY is missing.
     *
     * Fail-closed on purpose: storing an SMTP password in plaintext because the
     * key happens to be absent would be a silent downgrade of exactly the thing
     * the admin is trusting us with.
     */
    public static function encryptionUnavailable(): self
    {
        return new self(
            'Az SMTP jelszó nem menthető: nincs beállítva ENCRYPTION_KEY a szerveren.',
            503,
            'ENCRYPTION_UNAVAILABLE'
        );
    }

    /** No profile exists with the given uuid. */
    public static function profileNotFound(): self
    {
        return new self('A megadott levelezési profil nem található.', 404, 'MAIL_PROFILE_NOT_FOUND');
    }

    /** Profile name collides with an existing one. */
    public static function nameTaken(string $name): self
    {
        return new self('Már létezik "' . $name . '" nevű levelezési profil.', 422, 'MAIL_PROFILE_NAME_TAKEN');
    }

    /**
     * Someone tried to make an unverified profile the default.
     *
     * The whole point of the verification flow is that the default profile is
     * one we have proof works; allowing this would make the proof optional.
     */
    public static function notVerified(): self
    {
        return new self(
            'Csak hitelesített profil lehet alapértelmezett. Először erősítsd meg a megerősítő levéllel.',
            422,
            'MAIL_PROFILE_NOT_VERIFIED'
        );
    }

    /** No default profile, or the default is not verified / is disabled. */
    public static function sendingDisabled(): self
    {
        return new self(
            'Az e-mail küldés nincs aktiválva: nincs hitelesített, alapértelmezett levelezési profil.',
            503,
            'MAIL_NOT_VERIFIED'
        );
    }

    /** driver = disabled, i.e. the profile exists but must never send. */
    public static function driverDisabled(): self
    {
        return new self('Ez a levelezési profil ki van kapcsolva.', 503, 'MAIL_DRIVER_DISABLED');
    }

    // =========================================================================
    // VALIDATION
    // =========================================================================

    /**
     * @param array<string, string> $errors Field path => Hungarian message
     */
    public static function validation(array $errors): MailValidationException
    {
        return new MailValidationException($errors);
    }

    // =========================================================================
    // VERIFICATION
    // =========================================================================

    /** Token missing, malformed, or matches no profile. */
    public static function invalidToken(): self
    {
        return new self('A megerősítő hivatkozás érvénytelen.', 400, 'MAIL_TOKEN_INVALID');
    }

    /** Token matched but its 15 minute window has closed. */
    public static function expiredToken(): self
    {
        return new self(
            'A megerősítő hivatkozás lejárt. Kérj újat a Levelezés oldalon.',
            410,
            'MAIL_TOKEN_EXPIRED'
        );
    }

    // =========================================================================
    // TRANSPORT (mapped from PHPMailer failures - see MailService::classify())
    // =========================================================================

    public static function connectFailed(string $detail = ''): self
    {
        return new self(
            'Nem sikerült kapcsolódni az SMTP szerverhez. Ellenőrizd a kiszolgáló nevét és a portot.'
                . self::suffix($detail),
            502,
            'SMTP_CONNECT_FAILED'
        );
    }

    public static function tlsFailed(string $detail = ''): self
    {
        return new self(
            'A titkosított kapcsolat (STARTTLS/SSL) felépítése nem sikerült. '
                . 'Próbáld a másik titkosítási módot: 587 → TLS, 465 → SSL.'
                . self::suffix($detail),
            502,
            'TLS_FAILED'
        );
    }

    public static function certVerifyFailed(string $detail = ''): self
    {
        return new self(
            'Az SMTP szerver tanúsítványa nem ellenőrizhető. Ha saját, önaláírt tanúsítványt használ, '
                . 'engedélyezd a haladó beállításokban - de tudd, hogy ezzel a kapcsolat '
                . 'közbeékelődéses támadással szemben nem védett.'
                . self::suffix($detail),
            502,
            'CERT_VERIFY_FAILED'
        );
    }

    public static function authFailed(string $detail = ''): self
    {
        return new self(
            'Az SMTP hitelesítés nem sikerült. Ellenőrizd a felhasználónevet és a jelszót - '
                . 'sok szolgáltatónál külön alkalmazásjelszót kell generálni.'
                . self::suffix($detail),
            502,
            'AUTH_FAILED'
        );
    }

    public static function fromRejected(string $detail = ''): self
    {
        return new self(
            'A szerver elutasította a feladó címet. A "Feladó e-mail" jellemzően csak olyan cím lehet, '
                . 'amelyhez az SMTP fiók jogosult.'
                . self::suffix($detail),
            502,
            'FROM_REJECTED'
        );
    }

    public static function recipientRejected(string $detail = ''): self
    {
        return new self(
            'A szerver elutasította a címzettet. Ellenőrizd a megadott e-mail címet.'
                . self::suffix($detail),
            502,
            'RECIPIENT_REJECTED'
        );
    }

    public static function timeout(string $detail = ''): self
    {
        return new self(
            'Az SMTP szerver nem válaszolt időben. Növeld az időtúllépést, vagy ellenőrizd, '
                . 'hogy a kimenő port nincs-e tűzfallal zárva.'
                . self::suffix($detail),
            504,
            'TIMEOUT'
        );
    }

    public static function unknown(string $detail = ''): self
    {
        return new self(
            'A levél küldése nem sikerült.' . self::suffix($detail),
            502,
            'UNKNOWN'
        );
    }

    /**
     * Append the transport's own words, but only when debugging is on.
     *
     * In production the raw SMTP reply is log material, not response material:
     * it can name internal hosts and echo back parts of the conversation.
     */
    private static function suffix(string $detail): string
    {
        if ($detail === '' || ($_ENV['APP_DEBUG'] ?? 'false') !== 'true') {
            return '';
        }

        return ' (' . trim($detail) . ')';
    }
}
