<?php

/**
 * NOMAD CMS - Mail Validation Exception
 *
 * Per-field validation failures for an SMTP profile, so the /mails form can put
 * the message under the offending input instead of showing one opaque banner.
 * Mirrors FormValidationException.
 *
 * Extends MailException so a single catch block in the endpoint can handle
 * "anything the mail subsystem refused", while still exposing the field map.
 *
 * @package NomadCMS\Services\Mail
 */

declare(strict_types=1);

namespace NomadCMS\Services\Mail;

final class MailValidationException extends MailException
{
    /** @var array<string, string> field path => human readable (Hungarian) message */
    private array $errors;

    /**
     * @param array<string, string> $errors
     */
    public function __construct(array $errors, string $message = 'Érvénytelen levelezési beállítások.')
    {
        parent::__construct($message, 422, 'MAIL_VALIDATION_ERROR');

        $this->errors = $errors;
    }

    /**
     * @return array<string, string>
     */
    public function getErrors(): array
    {
        return $this->errors;
    }
}
