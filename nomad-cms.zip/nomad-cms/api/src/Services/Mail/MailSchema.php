<?php

/**
 * NOMAD CMS - Mail Schema
 *
 * Table definition and the whole vocabulary (drivers, encryptions, statuses,
 * auth types, allowed ports) of the e-mail subsystem. Every other class in this
 * namespace validates against the constants declared here, so there is exactly
 * one place where "what is a legal SMTP profile" is defined.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * STORAGE MODEL - system.sqlite, one row per SMTP profile
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * system_mail_profiles
 *   id                      INTEGER PK
 *   uuid                    TEXT UNIQUE   -- public identifier used by the API
 *   name                    TEXT UNIQUE   -- admin-facing label ("Tranzakciós")
 *   data                    TEXT          -- JSON config, see CONFIG SHAPE below
 *   is_default              INTEGER       -- at most one row may be 1
 *   verification_token_hash TEXT          -- SHA-256 of the raw token
 *   verification_expires_at TEXT          -- UTC 'Y-m-d H:i:s'
 *   verification_email      TEXT          -- who the confirmation was sent to
 *   last_success_at         TEXT          -- operational state, NOT config
 *   last_error_at           TEXT
 *   last_error_code         TEXT
 *   created_at / updated_at TEXT
 *
 * WHY system.sqlite AND NOT massive.sqlite: the row carries a Defuse-encrypted
 * SMTP password, and every other secret in this codebase (captcha secrets, API
 * keys, refresh tokens, WebAuthn credentials) lives in system.sqlite. The
 * recommended backup retention also differs - system.sqlite is backed up daily
 * with 30 day retention, massive.sqlite weekly with 90 - and a stale 90-day-old
 * copy of an SMTP credential is exactly the kind of thing you do not want lying
 * around.
 *
 * WHY THE TOKEN AND THE last_* COLUMNS ARE NOT IN THE JSON: `data` is the blob
 * that gets decoded, projected and handed to the admin UI. Keeping the
 * verification token out of it means a future "just return the whole config"
 * mistake cannot leak a live token, and keeping the operational state out of it
 * means recording a send failure never has to rewrite (and risk corrupting) the
 * configuration itself.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * CONFIG SHAPE (the `data` JSON)
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *   {
 *     "driver": "smtp",             smtp | mail | disabled
 *     "host": "smtp.example.com",
 *     "port": 587,                  one of ALLOWED_PORTS
 *     "encryption": "tls",          tls (STARTTLS) | ssl (SMTPS) | none
 *     "username": "user@example.com",
 *     "password_enc": "def5020...", Defuse ciphertext - NEVER plaintext
 *     "from_email": "noreply@example.com",
 *     "from_name": "NOMAD CMS",
 *     "status": "unverified",       unverified | verified | disabled
 *     "verified_at": null,          ISO-8601 UTC once verified
 *     "advanced": {
 *       "timeout": 15,              seconds, TIMEOUT_MIN..TIMEOUT_MAX
 *       "auth_type": "",            "" = let the server decide, else AUTH_TYPES
 *       "helo_domain": null,        EHLO/HELO name to announce
 *       "reply_to": null,
 *       "allow_self_signed": false, relaxes TLS peer verification
 *       "auto_tls": true            PHPMailer SMTPAutoTLS
 *     }
 *   }
 *
 * The key is `password_enc`, not `password`, deliberately: the name states that
 * the value is ciphertext, so no future reader can mistake it for something
 * safe to echo. The plaintext password exists only in memory, for the duration
 * of one send.
 *
 * @package NomadCMS\Services\Mail
 */

declare(strict_types=1);

namespace NomadCMS\Services\Mail;

use NomadCMS\Database\AuthDatabase;
use PDO;

final class MailSchema
{
    /** Physical table name in system.sqlite */
    public const TABLE = 'system_mail_profiles';

    // =========================================================================
    // VOCABULARY
    // =========================================================================

    /** Real SMTP delivery */
    public const DRIVER_SMTP = 'smtp';

    /** PHP's native mail() - only useful where a local MTA actually exists */
    public const DRIVER_MAIL = 'mail';

    /** Profile exists but must never send */
    public const DRIVER_DISABLED = 'disabled';

    /** @var array<int, string> */
    public const DRIVERS = [self::DRIVER_SMTP, self::DRIVER_MAIL, self::DRIVER_DISABLED];

    /** STARTTLS on a plaintext port (the 587 case) */
    public const ENCRYPTION_TLS = 'tls';

    /** Implicit TLS / SMTPS (the 465 case) */
    public const ENCRYPTION_SSL = 'ssl';

    /** No transport encryption at all */
    public const ENCRYPTION_NONE = 'none';

    /** @var array<int, string> */
    public const ENCRYPTIONS = [self::ENCRYPTION_TLS, self::ENCRYPTION_SSL, self::ENCRYPTION_NONE];

    /** Saved, but the confirmation link has not been opened yet */
    public const STATUS_UNVERIFIED = 'unverified';

    /** Confirmation link opened - this profile is allowed to send */
    public const STATUS_VERIFIED = 'verified';

    /** Explicitly switched off by an admin */
    public const STATUS_DISABLED = 'disabled';

    /** @var array<int, string> */
    public const STATUSES = [self::STATUS_UNVERIFIED, self::STATUS_VERIFIED, self::STATUS_DISABLED];

    /**
     * SMTP AUTH mechanisms an admin may force.
     *
     * An empty string (the default) means "let PHPMailer negotiate from the
     * server's EHLO response", which resolves to LOGIN or PLAIN on virtually
     * every real-world server. The explicit choices exist for the servers that
     * advertise a mechanism they cannot actually complete.
     *
     * @var array<int, string>
     */
    public const AUTH_TYPES = ['', 'LOGIN', 'PLAIN', 'CRAM-MD5', 'XOAUTH2'];

    /**
     * Ports an admin may connect out to.
     *
     * This is a whitelist rather than "any port 1-65535" on purpose. Saving a
     * profile makes the server open an outbound TCP connection to an
     * admin-supplied host:port and reports back a distinguishable error per
     * failure mode - i.e. an unrestricted version of this feature is a port
     * scanner with a nice UI. Restricting it to the four ports that actually
     * carry SMTP removes that capability without costing any legitimate setup.
     *
     * @var array<int, int>
     */
    public const ALLOWED_PORTS = [25, 465, 587, 2525];

    /** Conventional port for each encryption mode, used for UI defaults */
    public const DEFAULT_PORTS = [
        self::ENCRYPTION_TLS => 587,
        self::ENCRYPTION_SSL => 465,
        self::ENCRYPTION_NONE => 25,
    ];

    /** SMTP conversation timeout bounds, in seconds */
    public const TIMEOUT_MIN = 5;
    public const TIMEOUT_MAX = 60;
    public const TIMEOUT_DEFAULT = 15;

    /** Verification link lifetime, in seconds */
    public const VERIFICATION_TTL = 900; // 15 minutes

    /** Length of the raw verification token, in bytes (hex-encoded = 64 chars) */
    public const VERIFICATION_TOKEN_BYTES = 32;

    /** Bounds for the admin-facing profile name */
    public const NAME_MAX_LENGTH = 64;

    // =========================================================================
    // SCHEMA
    // =========================================================================

    /** Guard so the idempotent DDL runs at most once per process */
    private static bool $ready = false;

    /**
     * Create the table and its indexes if they do not exist yet.
     *
     * Idempotent and memoised. Also invoked from
     * AuthDatabase::initializeSchema() so a freshly installed instance has the
     * table before anything touches this namespace.
     */
    public static function ensure(): void
    {
        if (self::$ready) {
            return;
        }

        $db = self::db();

        $db->exec(
            'CREATE TABLE IF NOT EXISTS ' . self::TABLE . ' (
                id                      INTEGER PRIMARY KEY AUTOINCREMENT,
                uuid                    TEXT NOT NULL UNIQUE,
                name                    TEXT NOT NULL UNIQUE,
                data                    TEXT NOT NULL,
                is_default              INTEGER NOT NULL DEFAULT 0,
                verification_token_hash TEXT DEFAULT NULL,
                verification_expires_at TEXT DEFAULT NULL,
                verification_email      TEXT DEFAULT NULL,
                last_success_at         TEXT DEFAULT NULL,
                last_error_at           TEXT DEFAULT NULL,
                last_error_code         TEXT DEFAULT NULL,
                created_at              TEXT DEFAULT CURRENT_TIMESTAMP,
                updated_at              TEXT DEFAULT CURRENT_TIMESTAMP
            )'
        );

        // "At most one default profile" as a DATABASE invariant, not an
        // application-level hope. Without this a concurrent double-save could
        // leave two rows flagged default, and every later read would silently
        // pick whichever the planner returned first - i.e. mail would go out
        // from an SMTP identity nobody chose. A partial unique index makes that
        // state unrepresentable.
        if (self::supportsPartialIndexes($db)) {
            $db->exec(
                'CREATE UNIQUE INDEX IF NOT EXISTS idx_mail_profiles_default
                 ON ' . self::TABLE . '(is_default) WHERE is_default = 1'
            );
        }

        // Verification looks a token hash up across every profile.
        $db->exec(
            'CREATE INDEX IF NOT EXISTS idx_mail_profiles_token
             ON ' . self::TABLE . '(verification_token_hash)'
        );

        self::$ready = true;
    }

    /**
     * Partial indexes (CREATE INDEX ... WHERE) need SQLite >= 3.8.0 (2013).
     *
     * On anything older the table still works and MailProfileStore still
     * enforces the single-default rule inside a transaction - we simply lose the
     * belt-and-braces database guarantee rather than failing to install.
     */
    private static function supportsPartialIndexes(PDO $db): bool
    {
        $stmt = $db->query('SELECT sqlite_version()');
        $raw = $stmt === false ? null : $stmt->fetchColumn();
        $version = is_string($raw) ? $raw : '0';

        return version_compare($version, '3.8.0', '>=');
    }

    /**
     * Shared PDO handle for system.sqlite.
     */
    public static function db(): PDO
    {
        return AuthDatabase::getInstance();
    }

    /**
     * Forget the memoised DDL guard.
     *
     * Test-only: a suite that swaps the underlying SQLite file mid-run needs the
     * next ensure() to actually execute against the new handle.
     */
    public static function resetReadyFlag(): void
    {
        self::$ready = false;
    }

    // =========================================================================
    // CONFIG DEFAULTS
    // =========================================================================

    /**
     * The advanced option block as it looks when an admin touches nothing.
     *
     * @return array{
     *     timeout: int,
     *     auth_type: string,
     *     helo_domain: null,
     *     reply_to: null,
     *     allow_self_signed: bool,
     *     auto_tls: bool
     * }
     */
    public static function defaultAdvanced(): array
    {
        return [
            'timeout' => self::TIMEOUT_DEFAULT,
            'auth_type' => '',
            'helo_domain' => null,
            'reply_to' => null,
            // Default false: relaxing peer verification turns an encrypted
            // channel into one that cannot detect a man in the middle. It is a
            // legitimate escape hatch for internal SMTP with a self-signed cert,
            // but it must be a deliberate, visible choice.
            'allow_self_signed' => false,
            'auto_tls' => true,
        ];
    }
}
