<?php
/**
 * NOMAD CMS - Merkle & Content Hash Service
 *
 * Provides cryptographic/non-cryptographic Merkle Tree calculation,
 * per-item content hashing, and diff calculation for incremental static cache generation.
 *
 * Architecture:
 * - Leaf Node: hash of individual item payload (xxh3)
 * - Chunk Node: hash of concatenated item hashes in that chunk
 * - Slot Root Node: hash of all chunk hashes + manifest metadata
 * - State tracking: stored in {slotDir}/.merkle.json
 *
 * @package NomadCMS\Services
 */

declare(strict_types=1);

namespace NomadCMS\Services;

final class MerkleService
{
    private const HASH_ALGO = 'xxh3';
    private const FALLBACK_ALGO = 'sha256';

    /**
     * Get preferred fast hashing algorithm
     */
    public static function getAlgo(): string
    {
        static $algo = null;
        if ($algo === null) {
            $algo = in_array(self::HASH_ALGO, hash_algos(), true) ? self::HASH_ALGO : self::FALLBACK_ALGO;
        }
        return $algo;
    }

    /**
     * Compute content hash of an item payload
     */
    public static function hashPayload(mixed $payload): string
    {
        $json = json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        return hash(self::getAlgo(), (string)$json);
    }

    /**
     * Compute hash of a chunk based on its items' hashes
     *
     * @param array<string, string> $itemHashes Map of [slug => hash]
     */
    public static function hashChunk(array $itemHashes): string
    {
        $combined = '';
        foreach ($itemHashes as $slug => $h) {
            $combined .= $slug . ':' . $h . '|';
        }
        return hash(self::getAlgo(), $combined);
    }

    /**
     * Compute Merkle root hash for a slot
     *
     * @param array<string, string> $chunkHashes Map of [chunkName => hash]
     * @param array                 $manifestMeta Key metadata from manifest (itemCount, etc.)
     */
    public static function hashSlotRoot(string $slotKey, array $chunkHashes, array $manifestMeta): string
    {
        $payload = [
            'slot' => $slotKey,
            'chunks' => $chunkHashes,
            'meta' => $manifestMeta,
        ];
        return self::hashPayload($payload);
    }

    /**
     * Load existing Merkle state for a slot from {slotDir}/.merkle.json
     *
     * @return array{root: string, items: array<string, string>, chunks: array<string, string>, manifest: string}|null
     */
    public static function loadSlotMerkleState(string $slotDir): ?array
    {
        $stateFile = rtrim($slotDir, '/\\') . '/.merkle.json';
        if (!is_file($stateFile)) {
            return null;
        }

        $raw = @file_get_contents($stateFile);
        if ($raw === false || $raw === '') {
            return null;
        }

        $data = json_decode($raw, true);
        if (!is_array($data) || !isset($data['items']) || !is_array($data['items'])) {
            return null;
        }

        return [
            'root' => (string)($data['root'] ?? ''),
            'items' => $data['items'],
            'chunks' => is_array($data['chunks'] ?? null) ? $data['chunks'] : [],
            'chunk_map' => is_array($data['chunk_map'] ?? null) ? $data['chunk_map'] : [],
            'manifest' => (string)($data['manifest'] ?? ''),
        ];
    }

    /**
     * Save Merkle state atomically for a slot into {slotDir}/.merkle.json
     *
     * @param array{root: string, items: array<string, string>, chunks: array<string, string>, manifest?: string} $state
     */
    public static function saveSlotMerkleState(string $slotDir, array $state): bool
    {
        $stateFile = rtrim($slotDir, '/\\') . '/.merkle.json';
        $json = json_encode($state, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
        if ($json === false) {
            return false;
        }

        $tempPath = $stateFile . '.tmp.' . uniqid();
        if (@file_put_contents($tempPath, $json) === false) {
            return false;
        }

        @chmod($tempPath, 0644);
        if (!@rename($tempPath, $stateFile)) {
            @unlink($tempPath);
            return false;
        }

        return true;
    }

    /**
     * Compute differences between new item hashes and previous item hashes
     *
     * @param array<string, string> $newItemHashes [identifier => hash]
     * @param array<string, string> $oldItemHashes [identifier => hash]
     * @return array{
     *   created: array<string>,
     *   modified: array<string>,
     *   deleted: array<string>,
     *   unchanged: array<string>,
     *   has_changes: bool
     * }
     */
    public static function diffItemHashes(array $newItemHashes, array $oldItemHashes): array
    {
        $created = [];
        $modified = [];
        $deleted = [];
        $unchanged = [];

        foreach ($newItemHashes as $slug => $newHash) {
            if (!array_key_exists($slug, $oldItemHashes)) {
                $created[] = $slug;
            } elseif ($oldItemHashes[$slug] !== $newHash) {
                $modified[] = $slug;
            } else {
                $unchanged[] = $slug;
            }
        }

        foreach ($oldItemHashes as $oldSlug => $oldHash) {
            if (!array_key_exists($oldSlug, $newItemHashes)) {
                $deleted[] = $oldSlug;
            }
        }

        $hasChanges = !empty($created) || !empty($modified) || !empty($deleted);

        return [
            'created' => $created,
            'modified' => $modified,
            'deleted' => $deleted,
            'unchanged' => $unchanged,
            'has_changes' => $hasChanges,
        ];
    }
}
