<?php
/**
 * NOMAD CMS - Slot Backup Service
 * 
 * Granular slot-level export and import service for single JSON portable backups.
 * Supports all slot types: object, list, collection, and massive.
 * 
 * Export format: nomad-slot-export/v1
 */

declare(strict_types=1);

namespace NomadCMS\Services;

use NomadCMS\Database\ContentDatabase;
use NomadCMS\Database\MassiveDatabase;
use NomadCMS\Security\InputSanitizer;
use NomadCMS\Security\WebhookService;
use NomadCMS\Services\RelationService;
use NomadCMS\Services\StaticCacheService;
use RuntimeException;
use InvalidArgumentException;

final class SlotBackupService
{
    private string $schemaPath;

    public function __construct()
    {
        $this->schemaPath = dirname(__DIR__, 2) . '/data/nomad.schema.json';
    }

    /**
     * Get list of all exportable slots from schema and database
     * 
     * @return array<int, array{key: string, label: string, type: string, icon: string, description: string, item_count: int, has_schema: bool, in_db: bool}>
     */
    public function getExportableSlots(): array
    {
        $schema = RelationService::loadSchema();
        $slotsConfig = $schema['slots'] ?? [];
        $result = [];
        $seenKeys = [];

        // 1. Process all slots configured in nomad.schema.json
        foreach ($slotsConfig as $key => $config) {
            $slotKey = (string)$key;
            $seenKeys[$slotKey] = true;
            $type = (string)($config['type'] ?? 'object');
            $itemCount = $this->getSlotItemCount($slotKey, $type);

            $result[] = [
                'key' => $slotKey,
                'label' => (string)($config['label'] ?? $slotKey),
                'type' => $type,
                'icon' => (string)($config['icon'] ?? 'File'),
                'description' => (string)($config['description'] ?? ''),
                'item_count' => $itemCount,
                'has_schema' => true,
                'in_db' => $itemCount > 0 || \NomadCMS\Database\CollectionDatabase::isRegistered($slotKey),
            ];
        }

        // 2. Discover extra slots in ContentDatabase not in schema
        try {
            $db = ContentDatabase::getInstance();
            $stmt = $db->query("SELECT key, data FROM slots");
            $rows = $stmt->fetchAll();
            foreach ($rows as $row) {
                $slotKey = (string)$row['key'];
                if (isset($seenKeys[$slotKey])) {
                    continue;
                }
                $seenKeys[$slotKey] = true;
                $decoded = json_decode((string)$row['data'], true);
                $isList = is_array($decoded) && array_is_list($decoded);
                $type = $isList ? 'list' : 'object';
                $itemCount = is_array($decoded) ? ($isList ? count($decoded) : 1) : ($decoded !== null ? 1 : 0);
                if ($state=\NomadCMS\Database\CollectionDatabase::state($slotKey)) { $type='collection'; $itemCount=(int)$state['item_count']; }

                $result[] = [
                    'key' => $slotKey,
                    'label' => $slotKey,
                    'type' => $type,
                    'icon' => 'Database',
                    'description' => 'Unconfigured database slot',
                    'item_count' => $itemCount,
                    'has_schema' => false,
                    'in_db' => true,
                ];
            }
        } catch (\Throwable $e) {
            error_log("[SlotBackupService] Error discovering database slots: " . $e->getMessage());
        }

        // Sort: schema slots first, then alphabetically by label/key
        usort($result, function ($a, $b) {
            if ($a['has_schema'] !== $b['has_schema']) {
                return $a['has_schema'] ? -1 : 1;
            }
            return strcasecmp($a['label'], $b['label']);
        });

        return $result;
    }

    /**
     * Export a single slot into nomad-slot-export/v1 format
     * 
     * @param string $rawSlotKey Slot identifier
     * @return array Export package
     * @throws InvalidArgumentException
     * @throws RuntimeException
     */
    public function exportSlot(string $rawSlotKey): array
    {
        $slotKey = InputSanitizer::slotKey($rawSlotKey);
        if ($slotKey === null) {
            throw new InvalidArgumentException("Érvénytelen slot kulcs: '$rawSlotKey'");
        }

        $schema = RelationService::loadSchema();
        $slotConfig = $schema['slots'][$slotKey] ?? null;
        if ($slotConfig === null && !\NomadCMS\Services\Schema\SchemaProvider::initialized()) {
            $state = \NomadCMS\Database\CollectionDatabase::state($slotKey);
            if ($state !== null) {
                $slotConfig = json_decode($state['schema_json'], true, 512, JSON_THROW_ON_ERROR);
            }
        }
        $type = (string)($slotConfig['type'] ?? 'object');

        if ($type === 'massive') {
            $data = MassiveDatabase::exportAll($slotKey);
            $itemCount = count($data);
        } else {
            $data = ContentDatabase::getSlot($slotKey);
            if ($data === null) {
                $itemCount = 0;
            } elseif (is_array($data) && array_is_list($data)) {
                $itemCount = count($data);
            } else {
                $itemCount = ($data !== null ? 1 : 0);
            }
        }

        $jsonCanonical = json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        $checksum = hash('sha256', $jsonCanonical !== false ? $jsonCanonical : '');

        return [
            '_format' => 'nomad-slot-export/v1',
            'exported_at' => date('c'),
            'cms' => BackupCompatibility::metadata(),
            'slot' => [
                'key' => $slotKey,
                'type' => $type,
                'label' => (string)($slotConfig['label'] ?? $slotKey),
                'item_count' => $itemCount,
                'checksum_sha256' => $checksum,
            ],
            'schema' => $slotConfig,
            'data' => $data,
        ];
    }

    /**
     * Inspect and validate an uploaded slot export package
     * 
     * @param array $package Export package to inspect
     * @return array Inspection report
     */
    public function inspectSlotPackage(array $package, ?string $targetSlot = null): array
    {
        $format = (string)($package['_format'] ?? '');
        if ($format !== 'nomad-slot-export/v1') {
            return [
                'valid' => false,
                'error' => "Nem támogatott formátum: '$format'. Várt formátum: 'nomad-slot-export/v1'",
            ];
        }

        $sourceSlotKey = (string)($package['slot']['key'] ?? '');
        if (empty($sourceSlotKey)) {
            return [
                'valid' => false,
                'error' => 'Hiányzó slot kulcs az exportált csomagban.',
            ];
        }

        $sourceType = (string)($package['slot']['type'] ?? ($package['schema']['type'] ?? 'object'));
        $data = $package['data'] ?? null;
        $schemaDef = $package['schema'] ?? null;

        $compatibility = BackupCompatibility::inspect($package['cms'] ?? null);

        // Checksum verification
        $providedChecksum = (string)($package['slot']['checksum_sha256'] ?? '');
        $checksumValid = true;
        if (!empty($providedChecksum)) {
            $jsonCanonical = json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            $calculatedChecksum = hash('sha256', $jsonCanonical !== false ? $jsonCanonical : '');
            $checksumValid = hash_equals($providedChecksum, $calculatedChecksum);
        }

        // Target system status
        $currentSchema = RelationService::loadSchema();
        $targetSlot = $targetSlot ?? $sourceSlotKey;
        $targetSchemaExists = isset($currentSchema['slots'][$targetSlot]);
        $targetCurrentType = (string)($currentSchema['slots'][$targetSlot]['type'] ?? $sourceType);
        $targetCurrentItemCount = $this->getSlotItemCount($targetSlot, $targetCurrentType);

        return [
            'valid' => $checksumValid && $compatibility['compatible'],
            'compatibility' => $compatibility,
            'error' => !$checksumValid ? 'Backup checksum mismatch' : ($compatibility['compatible'] ? null : $compatibility['message']),
            'format' => $format,
            'exported_at' => $package['exported_at'] ?? null,
            'source_slot' => [
                'key' => $sourceSlotKey,
                'type' => $sourceType,
                'label' => (string)($package['slot']['label'] ?? ($schemaDef['label'] ?? $sourceSlotKey)),
                'item_count' => (int)($package['slot']['item_count'] ?? (is_array($data) ? count($data) : ($data !== null ? 1 : 0))),
                'has_schema' => !empty($schemaDef),
                'fields_count' => is_array($schemaDef['fields'] ?? null) ? count($schemaDef['fields']) : 0,
            ],
            'target_status' => [
                'key' => $targetSlot,
                'schema_exists' => $targetSchemaExists,
                'data_exists' => $targetCurrentItemCount > 0,
                'current_item_count' => $targetCurrentItemCount,
                'current_type' => $targetCurrentType,
            ],
            'checksum_valid' => $checksumValid,
        ];
    }

    /**
     * Import a slot package into the target slot with conflict resolution options
     * 
     * @param array $package Export package
     * @param array{target_slot?: string, mode?: string, sync_schema?: bool, overwrite_schema?: bool} $options
     * @param string|null $changedBy User identifier for audit log
     * @return array Result stats
     * @throws InvalidArgumentException
     * @throws RuntimeException
     */
    public function importSlot(array $package, array $options = [], ?string $changedBy = 'system'): array
    {
        $inspect = $this->inspectSlotPackage($package, $options['target_slot'] ?? null);
        if (!$inspect['valid']) {
            throw new InvalidArgumentException($inspect['error'] ?? 'Érvénytelen export csomag');
        }

        $rawTarget = (string)($options['target_slot'] ?? $package['slot']['key'] ?? '');
        $targetSlot = InputSanitizer::slotKey($rawTarget);
        if ($targetSlot === null) {
            throw new InvalidArgumentException("Érvénytelen cél slot kulcs: '$rawTarget'");
        }

        $mode = ($options['mode'] ?? 'overwrite') === 'merge' ? 'merge' : 'overwrite';
        $syncSchema = !empty($options['sync_schema']);
        $overwriteSchema = !empty($options['overwrite_schema']);

        $slotType = (string)($options['slot_type'] ?? $package['slot']['type'] ?? ($package['schema']['type'] ?? 'object'));
        $schemaDef = $package['schema'] ?? null;
        $data = $package['data'] ?? null;

        $registered = \NomadCMS\Database\CollectionDatabase::isRegistered($targetSlot);
        $actualType = RelationService::loadSchema()['slots'][$targetSlot]['type'] ?? ($registered ? 'collection' : null);
        if ($actualType !== null && $actualType !== $slotType) throw new InvalidArgumentException('Backup target slot type mismatch');
        if ($slotType === 'collection' && !is_array($data)) throw new InvalidArgumentException('Collection data must be an array');
        if ($slotType === 'collection') return $this->importCollection($targetSlot, $data, $schemaDef, $options, $changedBy);

        $schemaSynced = false;

        // 1. Synchronize / Inject schema definition if requested
        if ($syncSchema && is_array($schemaDef)) {
            $schemaSynced = $this->syncSlotSchema($targetSlot, $schemaDef, $overwriteSchema);
        }

        // 2. Perform Data Import
        $itemsCount = 0;

        if ($slotType === 'massive') {
            MassiveDatabase::ensureTable($targetSlot);
            $items = is_array($data) ? $data : [];

            if ($mode === 'overwrite') {
                // Clear existing table and bulk insert
                $db = MassiveDatabase::getInstance();
                $tableName = 'massive_' . preg_replace('/[^a-zA-Z0-9_]/', '_', $targetSlot);
                $db->exec("DELETE FROM \"$tableName\"");
                if (!empty($items)) {
                    MassiveDatabase::bulkInsert($targetSlot, $items, true);
                }
                $itemsCount = count($items);
            } else {
                // Merge / Append
                if (!empty($items)) {
                    MassiveDatabase::bulkInsert($targetSlot, $items, true);
                }
                $itemsCount = count($items);
            }
        } else {
            // Standard slot: object, list, collection
            if ($mode === 'merge' && is_array($data) && array_is_list($data)) {
                $existing = ContentDatabase::getSlot($targetSlot);
                if (!is_array($existing) || !array_is_list($existing)) {
                    $existing = [];
                }

                $merged = $this->mergeListItems($existing, $data);
                $data = $merged;
                ContentDatabase::saveSlot($targetSlot, $merged, [
                    'force_version' => true,
                    'changed_by' => $changedBy ?? 'system',
                    'slot_type' => $slotType,
                ]);
                $itemsCount = count($data);
            } else {
                // Overwrite (default) or object slot
                ContentDatabase::saveSlot($targetSlot, $data, [
                    'force_version' => true,
                    'changed_by' => $changedBy ?? 'system',
                    'slot_type' => $slotType,
                ]);
                $itemsCount = is_array($data) ? (array_is_list($data) ? count($data) : 1) : ($data !== null ? 1 : 0);
            }
        }

        // 3. Cache Invalidation & Static Generation
        try {
            StaticCacheService::invalidateSlot($targetSlot);
            StaticCacheService::generateForSlot($targetSlot, $data, $slotType);
        } catch (\Throwable $e) {
            error_log("[SlotBackupService] Cache generation notice: " . $e->getMessage());
        }

        // 4. Trigger Webhook Event (Async)
        try {
            $webhookService = new WebhookService();
            $webhookService->dispatchEventAsync('content.updated', [
                'slot' => $targetSlot,
                'action' => 'import',
                'type' => $slotType,
                'mode' => $mode,
                'items_count' => $itemsCount,
                'schema_synced' => $schemaSynced,
                'author' => $changedBy,
                'timestamp' => date('c'),
            ]);
        } catch (\Throwable $e) {
            error_log("[SlotBackupService] Webhook dispatch notice: " . $e->getMessage());
        }

        return [
            'success' => true,
            'slot_key' => $targetSlot,
            'slot_type' => $slotType,
            'mode' => $mode,
            'items_imported' => $itemsCount,
            'schema_synced' => $schemaSynced,
            'message' => "Slot '$targetSlot' successfully imported ($itemsCount items).",
        ];
    }

    /**
     * Helper to get current item count for a slot
     */
    private function importCollection(string $key, iterable $data, ?array $definition, array $options, ?string $actor, ?int $incomingCount = null): array
    {
        if (is_array($data) && !array_is_list($data)) throw new InvalidArgumentException('Collection backup data must be an array');
        $mode = ($options['mode'] ?? 'overwrite') === 'merge' ? 'merge' : 'overwrite';
        if (!empty($options['sync_schema']) && $definition) {
            $this->syncSlotSchema($key, $definition, !empty($options['overwrite_schema']));
        }
        $previousSchema = false;
        $schemaSynced = false;
        try {
            \NomadCMS\Database\CollectionDatabase::transaction(function () use ($key,$data,$definition,$options,$actor,$mode,&$schemaSynced) {
                $db = ContentDatabase::getInstance();
                $targetDef = RelationService::loadSchema()['slots'][$key] ?? $definition ?? ['type'=>'collection','fields'=>[]];
                if (!empty($options['sync_schema']) && (!isset(RelationService::loadSchema()['slots'][$key]) || !empty($options['overwrite_schema'])) && $definition) $targetDef = $definition;
                if (($targetDef['type'] ?? '') !== 'collection') throw new InvalidArgumentException('Collection schema required');
                \NomadCMS\Database\CollectionDatabase::syncSchema($key, $targetDef);
                if ($mode === 'overwrite') {
                    \NomadCMS\Database\CollectionDatabase::replaceIterable($key,$data,['owner_uuid'=>$actor,'changed_by'=>$actor??'system']);
                } else {
                    foreach ($data as $item) {
                        if (!is_array($item)) throw new InvalidArgumentException('Collection item must be an object');
                        $duplicate = false;
                        foreach (['_dndId'=>'item_uid','id'=>'business_id','slug'=>'slug'] as $field=>$column) {
                            if (!isset($item[$field]) || !is_scalar($item[$field])) continue;
                            $s=$db->prepare("SELECT 1 FROM collection_items WHERE slot_key=? AND $column=? LIMIT 1");
                            $s->execute([$key,(string)$item[$field]]);
                            if ($s->fetchColumn()) { $duplicate=true; break; }
                        }
                        if (!$duplicate) \NomadCMS\Database\CollectionDatabase::writeItem($key,RelationService::uidOf($item),$item,'create',['owner_uuid'=>$actor,'changed_by'=>$actor??'system']);
                    }
                }
                if (!empty($options['sync_schema']) && $definition) {
                    $schemaSynced=$this->syncSlotSchema($key,$definition,!empty($options['overwrite_schema']));
                    if (!$schemaSynced && !isset(RelationService::loadSchema()['slots'][$key])) throw new RuntimeException('Cannot synchronize backup schema');
                }
            });
        } catch (\Throwable $e) {
            if ($schemaSynced && $previousSchema !== false) {
                $tmp=$this->schemaPath.'.rollback.'.bin2hex(random_bytes(6));
                file_put_contents($tmp,$previousSchema,LOCK_EX); rename($tmp,$this->schemaPath);
                RelationService::clearCache(); PublicPayloadService::clearCaches();
            }
            throw $e;
        }
        StaticCacheService::markCollectionDirty($key);
        \NomadCMS\Database\CollectionDatabase::enqueue($key);
        SitemapService::markDirty();
        return ['success'=>true,'slot_key'=>$key,'slot_type'=>'collection','mode'=>$mode,'items_imported'=>$incomingCount??count($data),'schema_synced'=>$schemaSynced,'message'=>"Slot '$key' successfully imported"];
    }

    public function inspectCollectionFile(SlotPackageStream $stream, ?string $targetSlot = null): array
    {
        $package=$stream->package;
        // The stream has already checked the checksum of the full data array.
        unset($package['slot']['checksum_sha256']);
        $package['data']=[];
        $package['slot']['item_count']=$stream->count;
        return $this->inspectSlotPackage($package,$targetSlot);
    }

    public function importCollectionFile(SlotPackageStream $stream, array $options, ?string $actor): array
    {
        BackupCompatibility::requireCompatible($stream->package['cms'] ?? null);
        $key=InputSanitizer::slotKey((string)($options['target_slot']??$stream->package['slot']['key']??''));
        if ($key===null) throw new InvalidArgumentException('Invalid target slot');
        $actual=RelationService::loadSchema()['slots'][$key]['type']??null;
        if ($actual!==null&&$actual!=='collection') throw new InvalidArgumentException('Backup target slot type mismatch');
        return $this->importCollection($key,$stream->items(),$stream->package['schema']??null,$options,$actor,$stream->count);
    }

    /** v1 JSON export with bounded memory and the exact legacy data-only checksum. */
    public function streamCollectionExport(string $key, $output): void
    {
        $db=ContentDatabase::getInstance(); $own=!$db->inTransaction();
        if ($own) $db->beginTransaction();
        $tmp=tmpfile();
        if ($tmp===false) throw new RuntimeException('Cannot spool collection export');
        try {
            $hash=hash_init('sha256'); $count=0;
            fwrite($tmp,'['); hash_update($hash,'[');
            foreach (\NomadCMS\Database\CollectionDatabase::iterate($key,true) as $item) {
                $json=json_encode($item,JSON_THROW_ON_ERROR|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
                $part=($count++?',':'').$json; fwrite($tmp,$part); hash_update($hash,$part);
            }
            fwrite($tmp,']'); hash_update($hash,']');
            $definition = \NomadCMS\Services\Schema\SchemaProvider::slot($key);
            if ($definition === null) {
                throw new RuntimeException('Active collection schema not found');
            }
            $package=['_format'=>'nomad-slot-export/v1','exported_at'=>date('c'),'cms'=>BackupCompatibility::metadata(),'slot'=>['key'=>$key,'type'=>'collection','label'=>$definition['label']??$key,'item_count'=>$count,'checksum_sha256'=>hash_final($hash)],'schema'=>$definition];
            $header=json_encode($package,JSON_THROW_ON_ERROR|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
            fwrite($output,substr($header,0,-1).',"data":'); rewind($tmp); stream_copy_to_stream($tmp,$output); fwrite($output,'}');
            if ($own) $db->commit();
        } catch (\Throwable $e) { if ($own&&$db->inTransaction()) $db->rollBack(); throw $e; }
        finally { fclose($tmp); }
    }

    private function getSlotItemCount(string $slotKey, string $type): int
    {
        if ($state = \NomadCMS\Database\CollectionDatabase::state($slotKey)) return (int)$state['item_count'];
        if ($type === 'massive') {
            try {
                $stats = MassiveDatabase::getStats($slotKey);
                return (int)($stats['total_records'] ?? 0);
            } catch (\Throwable $e) {
                return 0;
            }
        }

        try {
            $data = ContentDatabase::getSlot($slotKey);
            if ($data === null) {
                return 0;
            }
            if (is_array($data) && array_is_list($data)) {
                return count($data);
            }
            return 1;
        } catch (\Throwable $e) {
            return 0;
        }
    }

    /**
     * Sync slot definition into nomad.schema.json
     */
    private function syncSlotSchema(string $slotKey, array $slotConfig, bool $overwriteExisting): bool
    {
        $user = \NomadCMS\Services\Schema\SchemaAccess::requireManager();
        $schema = \NomadCMS\Services\Schema\SchemaProvider::schema();
        if (isset($schema['slots'][$slotKey]) && $schema['slots'][$slotKey] === $slotConfig) {
            return false;
        }
        if (isset($schema['slots'][$slotKey]) && !$overwriteExisting) {
            return false;
        }
        $schema['slots'][$slotKey] = $slotConfig;
        $engine = new \NomadCMS\Services\Schema\SchemaEngine(\NomadCMS\Services\Schema\SchemaProvider::store());
        $draft = $engine->draft($schema, (int) ($schema['_revision'] ?? 0), $user->uuid, 'Backup schema import: ' . $slotKey);
        throw new \RuntimeException('Backup schema requires migration approval. Draft: ' . $draft['id'], 409);
            // Already exists and overwrite not requested
        // Atomic write via temp file
        // Invalidate in-memory caches
    }

    /**
     * Merge list items avoiding duplicate entries by _dndId, id, or slug
     */
    private function mergeListItems(array $existing, array $incoming): array
    {
        $result = $existing;
        $knownKeys = [];

        foreach ($existing as $item) {
            if (is_array($item)) {
                if (isset($item['_dndId'])) $knownKeys['uid:' . (string)$item['_dndId']] = true;
                if (isset($item['id'])) $knownKeys['id:' . (string)$item['id']] = true;
                if (isset($item['slug'])) $knownKeys['slug:' . (string)$item['slug']] = true;
            }
        }

        foreach ($incoming as $item) {
            if (!is_array($item)) {
                $result[] = $item;
                continue;
            }

            $isDuplicate = false;
            if (isset($item['_dndId']) && isset($knownKeys['uid:' . (string)$item['_dndId']])) {
                $isDuplicate = true;
            } elseif (isset($item['id']) && isset($knownKeys['id:' . (string)$item['id']])) {
                $isDuplicate = true;
            } elseif (isset($item['slug']) && isset($knownKeys['slug:' . (string)$item['slug']])) {
                $isDuplicate = true;
            }

            if (!$isDuplicate) {
                $result[] = $item;
                if (isset($item['_dndId'])) $knownKeys['uid:' . (string)$item['_dndId']] = true;
                if (isset($item['id'])) $knownKeys['id:' . (string)$item['id']] = true;
                if (isset($item['slug'])) $knownKeys['slug:' . (string)$item['slug']] = true;
            }
        }

        return $result;
    }
}
