<?php

/**
 * NOMAD CMS - Bounded, priority-aware webhook admission and maintenance.
 * Source snapshots and subscriber jobs have independent row/byte budgets.
 * SQLite counters keep admission O(1); indexed, bounded eviction prefers
 * terminal jobs, then oldest low-priority events. In-flight jobs are protected.
 */

declare(strict_types=1);

namespace NomadCMS\Services;

use PDO;
use WeakMap;

final class WebhookQueuePolicy
{
    private const TABLES = ['webhook_queue', 'collection_webhook_outbox'];
    private static ?WeakMap $installed = null;

    public static function priority(string $event): int
    {
        if (str_starts_with($event, 'system.') || str_starts_with($event, 'role.') ||
            in_array($event, ['form.submitted', 'user.created', 'user.updated', 'user.deleted', 'user.invited', 'user.onboarded'], true)) {
            return 3;
        }
        if (in_array($event, ['content.published', 'content.unpublished', 'content.deleted', 'media.deleted'], true)) {
            return 2;
        }
        return $event === 'content.updated' ? 0 : 1;
    }

    public static function itemKey(?string $slot, array $payload, ?int $subscriber = null): ?string
    {
        $uid = $payload['content']['_dndId'] ?? $payload['_dndId'] ?? $payload['id'] ?? null;
        if ($slot === null || $slot === '' || !is_scalar($uid) || (string) $uid === '') {
            return null;
        }
        return hash('sha256', json_encode([$subscriber, $slot, (string) $uid], JSON_THROW_ON_ERROR));
    }

    /** Install/backfill once; existing deployments are upgraded without rebuilding payloads. */
    public static function ensureSchema(PDO $db, string $table): void
    {
        self::validateTable($table);
        self::$installed ??= new WeakMap();
        $known = self::$installed[$db] ?? [];
        if (isset($known[$table])) {
            return;
        }
        $budget = $table . '_budget';
        $fields = ['priority' => 'INTEGER NOT NULL DEFAULT 0', 'item_key' => 'TEXT'];
        if ($table === 'collection_webhook_outbox') {
            $fields['created_at'] = 'INTEGER NOT NULL DEFAULT 0';
        }
        $columns = $db->query("PRAGMA table_info($table)")->fetchAll(PDO::FETCH_COLUMN, 1);
        if (array_diff(array_keys($fields), $columns) !== [] ||
            !$db->query("SELECT 1 FROM sqlite_master WHERE type='table' AND name='$budget'")->fetchColumn()) {
            self::atomic($db, static function () use ($db, $table, $budget, $fields): void {
                // Serialize upgrades before reading column metadata on a WAL connection.
                $db->exec("UPDATE $table SET id=id WHERE 0");
                $columns = $db->query("PRAGMA table_info($table)")->fetchAll(PDO::FETCH_COLUMN, 1);
                foreach ($fields as $name => $type) {
                    if (!in_array($name, $columns, true)) {
                        $db->exec("ALTER TABLE $table ADD COLUMN $name $type");
                    }
                }
                $event = $table === 'webhook_queue' ? 'event' : 'value';
                $priority = "CASE
                    WHEN $event LIKE 'system.%' OR $event LIKE 'role.%' OR $event IN ('form.submitted','user.created','user.updated','user.deleted','user.invited','user.onboarded') THEN 3
                    WHEN $event IN ('content.published','content.unpublished','content.deleted','media.deleted') THEN 2
                    WHEN $event='content.updated' THEN 0 ELSE 1 END";
                if ($table === 'collection_webhook_outbox') {
                    $priority = "(SELECT MAX($priority) FROM json_each(events))";
                    $db->exec("UPDATE $table SET created_at=COALESCE(
                        CAST(strftime('%s',json_extract(payload,'$.timestamp')) AS INTEGER),
                        CAST(strftime('%s','now') AS INTEGER)) WHERE created_at=0");
                }
                $db->exec("UPDATE $table SET priority=COALESCE($priority,0)");
                $db->exec("CREATE TABLE IF NOT EXISTS $budget (
                    id INTEGER PRIMARY KEY CHECK(id=1), items INTEGER NOT NULL,
                    bytes INTEGER NOT NULL, evicted INTEGER NOT NULL DEFAULT 0,
                    rejected INTEGER NOT NULL DEFAULT 0
                );
                INSERT OR IGNORE INTO $budget(id,items,bytes)
                    SELECT 1,COUNT(*),COALESCE(SUM(length(CAST(payload AS BLOB))),0) FROM $table;
                CREATE TRIGGER IF NOT EXISTS {$table}_budget_insert AFTER INSERT ON $table BEGIN
                    UPDATE $budget SET items=items+1,bytes=bytes+length(CAST(NEW.payload AS BLOB)) WHERE id=1;
                END;
                CREATE TRIGGER IF NOT EXISTS {$table}_budget_delete AFTER DELETE ON $table BEGIN
                    UPDATE $budget SET items=items-1,bytes=bytes-length(CAST(OLD.payload AS BLOB)) WHERE id=1;
                END;
                CREATE TRIGGER IF NOT EXISTS {$table}_budget_update AFTER UPDATE OF payload ON $table BEGIN
                    UPDATE $budget SET bytes=bytes-length(CAST(OLD.payload AS BLOB))+length(CAST(NEW.payload AS BLOB)) WHERE id=1;
                END;
                CREATE INDEX IF NOT EXISTS idx_{$table}_age ON $table(created_at,id);
                CREATE INDEX IF NOT EXISTS idx_{$table}_item ON $table(item_key,id);
                CREATE INDEX IF NOT EXISTS idx_{$table}_priority ON $table(priority DESC,id);");
                if ($table === 'webhook_queue') {
                    $rank = self::terminalRank();
                    $db->exec("CREATE INDEX IF NOT EXISTS idx_webhook_queue_evict ON webhook_queue(($rank),priority,id) WHERE status<>'processing';
                        CREATE INDEX IF NOT EXISTS idx_webhook_queue_ready ON webhook_queue(priority DESC,id)
                        WHERE status IN ('pending','failed') AND attempts<max_attempts;");
                } else {
                    $db->exec('CREATE INDEX IF NOT EXISTS idx_collection_webhook_outbox_evict ON collection_webhook_outbox(priority,id)');
                }
            });
        }
        // An outer rollback can also roll back DDL. Only memoize committed installs.
        if (!$db->inTransaction()) {
            $known[$table] = true;
            self::$installed[$db] = $known;
        }
    }

    /** Admit newest state atomically; overflow is deliberately acknowledged, never retried forever. */
    public static function insert(PDO $db, string $table, array $row, bool $coalesce): bool
    {
        $allowed = $table === 'webhook_queue'
            ? ['webhook_id', 'event', 'payload', 'slot_key', 'slot_type', 'created_at', 'next_attempt_at', 'max_attempts', 'priority', 'item_key']
            : ['event_id', 'slot_key', 'events', 'payload', 'priority', 'item_key', 'created_at'];
        if (array_diff(array_keys($row), $allowed) !== []) {
            throw new \InvalidArgumentException('Unsupported webhook queue column');
        }
        self::ensureSchema($db, $table);
        return self::atomic($db, static function () use ($db, $table, $row, $coalesce): bool {
            [, $maxBytes] = self::limits();
            if (strlen($row['payload']) > $maxBytes) {
                $db->exec("UPDATE {$table}_budget SET rejected=rejected+1 WHERE id=1");
                return false;
            }
            if ($coalesce && $row['item_key'] !== null) {
                $where = $table === 'webhook_queue'
                    ? "event='content.updated' AND status='pending' AND attempts=0"
                    : "events='[\"content.updated\"]'";
                $delete = $db->prepare("DELETE FROM $table WHERE id IN (SELECT id FROM $table WHERE item_key=? AND $where LIMIT 64)");
                $delete->execute([$row['item_key']]);
                $db->exec('UPDATE ' . $table . '_budget SET evicted=evicted+' . $delete->rowCount() . ' WHERE id=1');
            }
            if (!self::makeRoom($db, $table, 1, strlen($row['payload']), $row['priority'])) {
                $db->exec("UPDATE {$table}_budget SET rejected=rejected+1 WHERE id=1");
                return false;
            }
            $names = array_keys($row);
            $statement = $db->prepare('INSERT INTO ' . $table . '(' . implode(',', $names) . ') VALUES(' . implode(',', array_fill(0, count($names), '?')) . ')');
            $statement->execute(array_values($row));
            return true;
        });
    }

    /** Heal old oversized queues in bounded slices even without new arrivals. */
    public static function maintain(PDO $db, string $table): void
    {
        self::ensureSchema($db, $table);
        [$maxItems, $maxBytes] = self::limits();
        $state = self::stats($db, $table);
        $where = 'created_at<?' . ($table === 'webhook_queue' ? " AND status<>'processing'" : '');
        $old = $db->prepare("SELECT 1 FROM $table WHERE $where LIMIT 1");
        $old->execute([self::cutoff()]);
        $hasExpired = $old->fetchColumn() !== false;
        $old->closeCursor();
        if (!$hasExpired && $state['items'] <= $maxItems && $state['bytes'] <= $maxBytes) {
            return;
        }
        self::atomic($db, static function () use ($db, $table, $where): void {
            // A normal full queue is flushed in one slice; oversized legacy stores
            // remain bounded per run. Never send an expired row while catching up.
            $expired = $db->prepare("DELETE FROM $table WHERE id IN (
                SELECT id FROM $table WHERE $where ORDER BY created_at,id LIMIT 500
            )");
            $expired->execute([self::cutoff()]);
            $db->exec("UPDATE {$table}_budget SET evicted=evicted+" . $expired->rowCount() . ' WHERE id=1');
            self::makeRoom($db, $table, 0, 0, 3);
        });
    }

    public static function cutoff(): int
    {
        return time() - max(60, min(86400, (int) ($_ENV['WEBHOOK_QUEUE_MAX_AGE_SECONDS'] ?? 900)));
    }

    public static function stats(PDO $db, string $table): array
    {
        self::ensureSchema($db, $table);
        return $db->query("SELECT items,bytes,evicted,rejected FROM {$table}_budget WHERE id=1")->fetch(PDO::FETCH_ASSOC);
    }

    private static function makeRoom(PDO $db, string $table, int $items, int $bytes, int $priority): bool
    {
        [$maxItems, $maxBytes] = self::limits();
        if ($bytes > $maxBytes) {
            return false;
        }
        $budget = $table . '_budget';
        for ($count = 0; $count <= 64; $count++) {
            $state = $db->query("SELECT items,bytes FROM $budget WHERE id=1")->fetch(PDO::FETCH_ASSOC);
            if ($state['items'] + $items <= $maxItems && $state['bytes'] + $bytes <= $maxBytes) {
                return true;
            }
            if ($count === 64) {
                return false;
            }
            if ($table === 'webhook_queue') {
                $rank = self::terminalRank();
                $sql = "SELECT id FROM webhook_queue WHERE status<>'processing'
                    AND (($rank)=0 OR priority<=?) ORDER BY ($rank),priority,id LIMIT 1";
            } else {
                $sql = 'SELECT id FROM collection_webhook_outbox WHERE priority<=? ORDER BY priority,id LIMIT 1';
            }
            $victim = $db->prepare($sql);
            $victim->execute([$priority]);
            $id = $victim->fetchColumn();
            $victim->closeCursor();
            if ($id === false) {
                return false;
            }
            $db->prepare("DELETE FROM $table WHERE id=?")->execute([$id]);
            $db->exec("UPDATE $budget SET evicted=evicted+1 WHERE id=1");
        }
        return false;
    }

    private static function terminalRank(): string
    {
        return "CASE WHEN status='completed' OR (status='failed' AND attempts>=max_attempts) THEN 0 ELSE 1 END";
    }

    private static function limits(): array
    {
        return [
            max(1, min(10000, (int) ($_ENV['WEBHOOK_QUEUE_MAX_ITEMS'] ?? 500))),
            max(1024, min(67108864, (int) ($_ENV['WEBHOOK_QUEUE_MAX_BYTES'] ?? 8388608))),
        ];
    }

    private static function validateTable(string $table): void
    {
        if (!in_array($table, self::TABLES, true)) {
            throw new \InvalidArgumentException('Unsupported webhook queue');
        }
    }

    private static function atomic(PDO $db, callable $work): mixed
    {
        $nested = $db->inTransaction();
        $point = 'webhook_admission_' . bin2hex(random_bytes(4));
        $nested ? $db->exec("SAVEPOINT $point") : $db->beginTransaction();
        try {
            $result = $work();
            $nested ? $db->exec("RELEASE SAVEPOINT $point") : $db->commit();
            return $result;
        } catch (\Throwable $e) {
            if ($nested) {
                $db->exec("ROLLBACK TO SAVEPOINT $point");
                $db->exec("RELEASE SAVEPOINT $point");
            } elseif ($db->inTransaction()) {
                $db->rollBack();
            }
            throw $e;
        }
    }
}
