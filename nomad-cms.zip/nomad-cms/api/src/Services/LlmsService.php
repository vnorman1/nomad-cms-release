<?php
/**
 * NOMAD CMS - LLMS Dynamic Markdown Service
 * 
 * Provides on-the-fly, high-performance Markdown generation for collection and
 * list items. Designed for SPA (Single Page Application) compatibility so that
 * AI models (Perplexity, ChatGPT, Claude, Cursor) receive clean, semantic Markdown
 * instead of empty client-side JavaScript HTML shells.
 */

declare(strict_types=1);

namespace NomadCMS\Services;

use NomadCMS\Database\ContentDatabase;

final class LlmsService
{
    private static ?string $cacheDir = null;

    /**
     * Resolve item from pre-generated static JSON cache if available.
     * Supports both collection item files ({slot}/{slug}.json) and list slot manifests ({slot}/manifest.json).
     * Avoids database queries and avoids creating redundant .md files on disk.
     */
    public static function resolveItemFromStaticJson(string $slotKey, string $slug, ?string $lang = null): ?array
    {
        $cleanSlot = preg_replace('/[^a-z0-9_-]/i', '', $slotKey);
        $cleanSlug = preg_replace('/[^a-z0-9_-]/i', '', $slug);

        $staticDir = dirname(__DIR__, 2) . '/static/content/' . $cleanSlot;
        $staticFile = $staticDir . '/' . $cleanSlug . '.json';
        if (\NomadCMS\Database\CollectionDatabase::isRegistered($slotKey)) {
            RelationService::loadSchema();
            $state=\NomadCMS\Database\CollectionDatabase::state($slotKey);
            $marker=is_file($staticDir.'/.collection_revision') ? json_decode(file_get_contents($staticDir.'/.collection_revision'),true) : null;
            if (!$marker || (int)($marker['revision']??-1)!==(int)$state['revision'] || ($marker['schema_revision']??'')!==$state['schema_hash']) return null;
        }

        // 1. Direct collection item file: {slot}/{slug}.json
        $rowCollection=\NomadCMS\Database\CollectionDatabase::isRegistered($slotKey);
        if (!$rowCollection && is_file($staticFile)) {
            $raw = @file_get_contents($staticFile);
            if ($raw !== false) {
                $data = json_decode($raw, true);
                if (is_array($data)) {
                    $item = self::unpackStaticItemLocales($data, $lang);
                    $item['_static_mtime'] = filemtime($staticFile);
                    $item['_static_file']  = $staticFile;
                    return $item;
                }
            }
        }

        // 2. List slot manifest file: {slot}/manifest.json (with inline items)
        $manifestFile = $staticDir . '/manifest.json';
        if (is_file($manifestFile)) {
            $raw = @file_get_contents($manifestFile);
            if ($raw !== false) {
                $manifest = json_decode($raw, true);
                if (is_array($manifest) && isset($manifest['items']) && is_array($manifest['items'])) {
                    $cleanRequested = strtolower(trim($slug));
                    foreach ($manifest['items'] as $it) {
                        if (!is_array($it)) {
                            continue;
                        }
                        $itSlug = $it['slug'] ?? $it['id'] ?? null;
                        if ($itSlug !== null && strtolower(trim((string)$itSlug)) === $cleanRequested) {
                            $item = self::unpackStaticItemLocales($it, $lang);
                            $item['_static_mtime'] = filemtime($manifestFile);
                            $item['_static_file']  = $manifestFile;
                            return $item;
                        }
                    }
                }
            }
        }

        return null;
    }

    /**
     * Unpack localized branch into root with default language fallback for empty fields
     */
    private static function unpackStaticItemLocales(array $data, ?string $lang): array
    {
        $item = $data;
        if (isset($data['locales']) && is_array($data['locales'])) {
            $defLang = $data['defaultLanguage'] ?? 'hu';
            $targetLang = $lang ?? $defLang;
            $localized = $data['locales'][$targetLang] ?? $data['locales'][$defLang] ?? reset($data['locales']) ?: [];
            $defLocalized = ($targetLang !== $defLang && isset($data['locales'][$defLang]) && is_array($data['locales'][$defLang]))
                ? $data['locales'][$defLang]
                : [];

            if (is_array($localized)) {
                if (!empty($defLocalized)) {
                    foreach ($defLocalized as $k => $v) {
                        if (!isset($localized[$k]) || $localized[$k] === '' || $localized[$k] === null) {
                            $localized[$k] = $v;
                        }
                    }
                }
                $item = array_merge($item, $localized);
            }
        }
        return $item;
    }

    /**
     * Resolve slot key from either slot key or URL pattern prefix
     */
    public static function resolveSlotKey(string $slotOrUrlPrefix, array $schema): ?string
    {
        if (!isset($schema['slots']) || !is_array($schema['slots'])) {
            return null;
        }

        // Direct key match
        if (isset($schema['slots'][$slotOrUrlPrefix])) {
            return $slotOrUrlPrefix;
        }

        // URL pattern match (e.g. urlPattern: "/work/{slug}" matching prefix "work")
        $cleanPrefix = trim($slotOrUrlPrefix, '/');
        foreach ($schema['slots'] as $key => $slot) {
            if (!empty($slot['urlPattern'])) {
                $patternPrefix = trim(explode('{slug}', (string)$slot['urlPattern'])[0] ?? '', '/');
                if ($patternPrefix === $cleanPrefix) {
                    return $key;
                }
            }
        }

        return null;
    }

    /**
     * Find item in slot by slug and verify published status
     */
    public static function resolveItem(string $slotKey, string $slug, ?string $lang, array $slotConfig): ?array
    {
        try {
            $slot = \NomadCMS\Database\CollectionDatabase::isRegistered($slotKey)
                ? array_filter([\NomadCMS\Database\CollectionDatabase::findByIdentifier($slotKey,$slug)]) : ContentDatabase::getSlot($slotKey);
        } catch (\Throwable $e) {
            return null;
        }

        if (!is_array($slot) || empty($slot)) {
            return null;
        }

        $slugField      = $slotConfig['slugField'] ?? 'slug';
        $publishedField = $slotConfig['publishedField'] ?? null;
        $cleanRequested = strtolower(trim($slug));

        foreach ($slot as $item) {
            if (!is_array($item)) {
                continue;
            }

            // Slug extraction with localization support
            $itemSlug = null;
            if (isset($item[$slugField])) {
                $raw = $item[$slugField];
                if (is_array($raw)) {
                    $itemSlug = ($lang !== null && isset($raw[$lang])) ? $raw[$lang] : (reset($raw) ?: null);
                } else {
                    $itemSlug = (string)$raw;
                }
            }

            if (empty($itemSlug) && isset($item['slug'])) {
                $raw = $item['slug'];
                $itemSlug = is_array($raw) ? (reset($raw) ?: null) : (string)$raw;
            }

            if (empty($itemSlug) && isset($item['id'])) {
                $itemSlug = (string)$item['id'];
            }

            if (empty($itemSlug) || strtolower(trim((string)$itemSlug)) !== $cleanRequested) {
                continue;
            }

            // Publication status check
            $isPublished = true;
            if ($publishedField !== null) {
                if (isset($item[$publishedField])) {
                    $val = filter_var($item[$publishedField], FILTER_VALIDATE_BOOLEAN, FILTER_NULL_ON_FAILURE);
                    $isPublished = $val !== null ? $val : !empty($item[$publishedField]);
                } else {
                    $isPublished = false;
                }
            } elseif (isset($item['status'])) {
                $allowedStatuses = ['stabil', 'mukodo', 'published', 'active'];
                $isPublished     = in_array($item['status'], $allowedStatuses, true);
            } else {
                $implicitFields = ['public', 'published', 'isPublished', 'active', 'isActive'];
                foreach ($implicitFields as $field) {
                    if (array_key_exists($field, $item)) {
                        $val = filter_var($item[$field], FILTER_VALIDATE_BOOLEAN, FILTER_NULL_ON_FAILURE);
                        $isPublished = $val !== null ? $val : !empty($item[$field]);
                        break;
                    }
                }
            }

            if (!$isPublished) {
                return null;
            }

            return $item;
        }

        return null;
    }

    /**
     * Format structured JSON field values into clean, human-readable Markdown sections
     */
    public static function formatJsonValueToMarkdown(mixed $val, string $fLabel): string
    {
        if (!is_array($val)) {
            return is_scalar($val) ? ('**' . $fLabel . '**: ' . (string)$val) : '';
        }

        // Case A: Structured content with title / body (e.g. Nomad Profile, What I Do, Off Duty)
        $subTitle = $val['title'] ?? $val['heading'] ?? null;
        $body = $val['body'] ?? $val['content'] ?? $val['text'] ?? $val['description'] ?? null;

        if ($subTitle || $body) {
            $out = [];
            $heading = $subTitle ?: $fLabel;
            $out[] = '### ' . trim((string)$heading);
            if (!empty($body)) {
                $out[] = trim((string)$body);
            }

            // Check for list fields (e.g. left, right, items, points, list)
            foreach ($val as $k => $v) {
                if (in_array($k, ['title', 'heading', 'body', 'content', 'text', 'description'], true)) {
                    continue;
                }
                if (is_array($v) && array_is_list($v)) {
                    $kLabel = ucfirst(str_replace('_', ' ', (string)$k));
                    if (!in_array(strtolower($k), ['left', 'right', 'items', 'list'], true)) {
                        $out[] = '**' . $kLabel . '**:';
                    }
                    foreach ($v as $listItem) {
                        if (is_scalar($listItem)) {
                            $out[] = '- ' . (string)$listItem;
                        }
                    }
                } elseif (is_scalar($v) && trim((string)$v) !== '') {
                    $out[] = '**' . ucfirst((string)$k) . '**: ' . (string)$v;
                }
            }
            return implode("\n\n", $out);
        }

        // Case B: Simple list of strings / numbers
        if (array_is_list($val)) {
            $allScalars = true;
            foreach ($val as $v) {
                if (!is_scalar($v)) {
                    $allScalars = false;
                    break;
                }
            }
            if ($allScalars) {
                return '**' . $fLabel . '**: ' . implode(', ', array_map('strval', $val));
            }
        }

        // Case C: Key-value dictionary where all values are scalars
        $allScalarDict = true;
        foreach ($val as $k => $v) {
            if (!is_scalar($v)) {
                $allScalarDict = false;
                break;
            }
        }
        if ($allScalarDict && !empty($val)) {
            $lines = ['### ' . $fLabel];
            foreach ($val as $k => $v) {
                $lines[] = '- **' . ucfirst(str_replace('_', ' ', (string)$k)) . '**: ' . (string)$v;
            }
            return implode("\n", $lines);
        }

        // Case D: Fallback to pretty JSON code block
        return "### {$fLabel}\n```json\n" . json_encode($val, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . "\n```";
    }

    /**
     * Generate structured, semantic Markdown for an entire Object Slot or Page
     */
    public static function generateObjectSlotMarkdown(
        string $slotKey,
        array $slotConfig,
        ?string $lang,
        array $schema
    ): ?string {
        $siteUrl   = rtrim($_ENV['SITE_URL'] ?? $_ENV['APP_URL'] ?? 'https://yourdomain.com', '/');
        $siteTitle = $schema['title'] ?? $schema['$id'] ?? 'NOMAD CMS';
        $defLang   = $schema['i18n']['defaultLanguage'] ?? 'hu';

        // 1. Try reading from static content manifest: /static/content/{slotKey}/manifest.json
        $cleanSlot = preg_replace('/[^a-z0-9_-]/i', '', $slotKey);
        $staticFile = dirname(__DIR__, 2) . '/static/content/' . $cleanSlot . '/manifest.json';
        $item = null;

        $rowCollection=\NomadCMS\Database\CollectionDatabase::isRegistered($slotKey);
        if (!$rowCollection && is_file($staticFile)) {
            $raw = @file_get_contents($staticFile);
            if ($raw !== false) {
                $data = json_decode($raw, true);
                if (is_array($data)) {
                    $item = self::unpackStaticItemLocales($data, $lang);
                }
            }
        }

        // 2. Fallback to ContentDatabase
        if ($item === null) {
            try {
                $rawSlot = \NomadCMS\Database\CollectionDatabase::isRegistered($slotKey)
                    ? [] : ContentDatabase::getSlot($slotKey);
                if (is_array($rawSlot)) {
                    $item = $rawSlot;
                }
            } catch (\Throwable $e) {
                return null;
            }
        }

        if ($item === null) {
            return null;
        }

        $knownLanguages = array_map('strtolower', $schema['i18n']['languages'] ?? ['hu', 'en', 'de', 'fr', 'es', 'it']);

        // Helper to resolve localized value
        $resolveLocalized = function(mixed $val) use ($lang, $defLang, $knownLanguages): mixed {
            if (!is_array($val)) return $val;
            if (array_is_list($val)) return $val;
            if ($lang !== null && isset($val[$lang])) return $val[$lang];
            if ($defLang !== null && isset($val[$defLang])) return $val[$defLang];
            $keys = array_keys($val);
            if (!empty($keys) && is_string($keys[0]) && in_array(strtolower($keys[0]), $knownLanguages, true)) {
                return reset($val) ?: '';
            }
            return $val;
        };

        // Find matching static page definition if exists
        $matchingPage = null;
        $patternPrefix = !empty($slotConfig['urlPattern']) ? trim(explode('{slug}', (string)$slotConfig['urlPattern'])[0] ?? '', '/') : '';
        if (!empty($schema['staticPages']) && is_array($schema['staticPages'])) {
            foreach ($schema['staticPages'] as $sp) {
                $p = trim($sp['path'] ?? '', '/');
                if ($p === $slotKey || ($patternPrefix !== '' && $p === $patternPrefix) || ($slotKey === 'home' && ($sp['path'] === '/' || $sp['path'] === ''))) {
                    $matchingPage = $sp;
                    break;
                }
            }
        }

        // Title & Summary
        $title = $matchingPage ? $resolveLocalized($matchingPage['label'] ?? null) : ($slotConfig['label'] ?? ucfirst($slotKey));
        $title = is_string($title) && trim($title) !== '' ? trim($title) : ucfirst($slotKey);

        $summary = $matchingPage ? $resolveLocalized($matchingPage['description'] ?? null) : ($slotConfig['description'] ?? '');
        $summary = is_string($summary) ? trim(strip_tags($summary)) : '';

        // Canonical URL
        $pagePath = $matchingPage ? ($matchingPage['path'] === '/' ? '' : $matchingPage['path']) : ('/' . $slotKey);
        $canonicalUrl = $siteUrl . ($lang !== null ? '/' . $lang : '') . ($pagePath ?: '');

        $lines = [];

        // YAML Frontmatter
        $lines[] = '---';
        $lines[] = 'title: ' . json_encode($title, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        $lines[] = 'slot: ' . json_encode($slotKey, JSON_UNESCAPED_UNICODE);
        $lines[] = 'type: "page"';
        if ($lang !== null) {
            $lines[] = 'language: ' . json_encode($lang, JSON_UNESCAPED_UNICODE);
        }
        $lines[] = 'canonical_url: ' . json_encode($canonicalUrl, JSON_UNESCAPED_SLASHES);
        $lines[] = 'generator: "Nomad CMS LLMS Dynamic Markdown Engine"';
        $lines[] = '---';
        $lines[] = '';

        // H1 Title & Excerpt
        $lines[] = '# ' . $title;
        $lines[] = '';
        if (!empty($summary)) {
            $lines[] = '> ' . $summary;
            $lines[] = '';
        }

        $processedFields = ['_dndId', 'id', 'slug', 'public', 'published', 'slot', 'type', 'generated_at', 'languages', 'defaultLanguage', 'locales'];

        // If it's a collection slot accessed without slug (e.g. /llms/en/work), render list of items
        if (($slotConfig['type'] ?? '') === 'collection' || ($slotConfig['type'] ?? '') === 'list') {
            $items = $rowCollection ? \NomadCMS\Database\CollectionDatabase::iterate($slotKey) : (is_array($item) ? ($item['index'] ?? $item['items'] ?? $item) : []);
            if (is_iterable($items)) {
                $lines[] = '## ' . $title;
                $lines[] = '';
                $urlPattern = $slotConfig['urlPattern'] ?? ('/' . $slotKey . '/{slug}');
                foreach ($items as $it) {
                    if (!is_array($it) || ($rowCollection && !PublicPayloadService::isItemPublished($slotConfig,$it))) continue;
                    if ($rowCollection) $it=PublicPayloadService::projectSlot($slotKey,$it);
                    $itSlug = $resolveLocalized($it['slug'] ?? $it['id'] ?? null);
                    if (!$itSlug) continue;
                    $localesTitle = ($lang !== null && isset($it['locales'][$lang]['title'])) ? $it['locales'][$lang]['title'] : null;
                    $itTitle = $localesTitle ?: $resolveLocalized($it['title'] ?? $it['name'] ?? $itSlug);
                    $path = str_replace('{slug}', (string)$itSlug, $urlPattern);
                    $itUrl = $siteUrl . '/llms' . ($lang !== null ? '/' . $lang : '') . $path;
                    $lines[] = '- [' . $itTitle . '](' . $itUrl . ')';
                }
                $lines[] = '';
            }
        } else {
            // Render object slot fields
            if (isset($slotConfig['fields']) && is_array($slotConfig['fields'])) {
                foreach ($slotConfig['fields'] as $field) {
                    $fid = $field['id'] ?? null;
                    if (!$fid || in_array($fid, $processedFields, true)) continue;
                    $processedFields[] = $fid;
                    if (!isset($item[$fid]) || $item[$fid] === '' || $item[$fid] === null) continue;

                    $fLabel = $field['label'] ?? ucfirst($fid);
                    $fType  = $field['type'] ?? 'text';
                    $val    = $resolveLocalized($item[$fid]);

                    if ($fType === 'image') {
                        $imgUrl = is_string($val) ? $val : ($val['url'] ?? $val['src'] ?? null);
                        if ($imgUrl) {
                            if (str_starts_with($imgUrl, '/')) $imgUrl = $siteUrl . $imgUrl;
                            $lines[] = '## ' . $fLabel;
                            $lines[] = '![' . htmlspecialchars($fLabel, ENT_QUOTES) . '](' . $imgUrl . ')';
                            $lines[] = '';
                        }
                    } elseif ($fType === 'gallery') {
                        $images = is_array($val) ? ($val['images'] ?? $val) : [];
                        if (is_array($images) && !empty($images)) {
                            $lines[] = '## ' . $fLabel;
                            foreach ($images as $img) {
                                $imgSrc = is_array($img) ? ($img['src'] ?? $img['url'] ?? '') : (string)$img;
                                $imgAlt = is_array($img) ? ($img['alt'] ?? '') : '';
                                if (!empty($imgSrc)) {
                                    if (str_starts_with($imgSrc, '/')) $imgSrc = $siteUrl . $imgSrc;
                                    $lines[] = '![' . htmlspecialchars($imgAlt ?: $fLabel, ENT_QUOTES) . '](' . $imgSrc . ')';
                                }
                            }
                            $lines[] = '';
                        }
                    } elseif ($fType === 'url') {
                        if (is_string($val) && !empty($val)) {
                            $lines[] = '**' . $fLabel . '**: [' . $val . '](' . $val . ')';
                            $lines[] = '';
                        }
                    } elseif ($fType === 'email') {
                        if (is_string($val) && !empty($val)) {
                            $lines[] = '**' . $fLabel . '**: [' . $val . '](mailto:' . $val . ')';
                            $lines[] = '';
                        }
                    } elseif (in_array($fType, ['text', 'textarea', 'markdown', 'richtext'], true)) {
                        if (is_string($val) && trim($val) !== '') {
                            $lines[] = '## ' . $fLabel;
                            $lines[] = self::htmlToMarkdown($val, $siteUrl);
                            $lines[] = '';
                        }
                    } elseif ($fType === 'json') {
                        $formattedJson = self::formatJsonValueToMarkdown($val, $fLabel);
                        if (!empty($formattedJson)) {
                            $lines[] = $formattedJson;
                            $lines[] = '';
                        }
                    } elseif (is_scalar($val)) {
                        $lines[] = '**' . $fLabel . '**: ' . (string)$val;
                        $lines[] = '';
                    }
                }
            }
        }

        // Canonical interactive footer
        $lines[] = '---';
        $lines[] = '*View interactive web page: [' . $canonicalUrl . '](' . $canonicalUrl . ')*';
        $lines[] = '';

        return implode("\n", $lines);
    }

    /**
     * Generate structured, semantic Markdown for a specific item
     */
    public static function generateItemMarkdown(
        string $slotKey,
        array $item,
        array $slotConfig,
        ?string $lang,
        array $schema
    ): string {
        $siteUrl    = rtrim($_ENV['SITE_URL'] ?? $_ENV['APP_URL'] ?? 'https://yourdomain.com', '/');
        $siteTitle  = $schema['title'] ?? $schema['$id'] ?? 'NOMAD CMS';
        $defLang    = $schema['i18n']['defaultLanguage'] ?? 'hu';

        $knownLanguages = array_map('strtolower', $schema['i18n']['languages'] ?? ['hu', 'en', 'de', 'fr', 'es', 'it']);

        // Helper to resolve localized value
        $resolveLocalized = function(mixed $val) use ($lang, $defLang, $knownLanguages): mixed {
            if (!is_array($val)) {
                return $val;
            }
            // If it's a numeric list (e.g. list of blocks, images, strings), return directly
            if (array_is_list($val)) {
                return $val;
            }
            if ($lang !== null && isset($val[$lang])) {
                return $val[$lang];
            }
            if ($defLang !== null && isset($val[$defLang])) {
                return $val[$defLang];
            }
            // If keys look like language codes, fallback to first entry
            $keys = array_keys($val);
            if (!empty($keys) && is_string($keys[0]) && in_array(strtolower($keys[0]), $knownLanguages, true)) {
                return reset($val) ?: '';
            }
            return $val;
        };

        // Extract title
        $titleField = $slotConfig['titleField'] ?? null;
        $title = null;
        if ($titleField && isset($item[$titleField])) {
            $title = $resolveLocalized($item[$titleField]);
        } else {
            foreach (['title', 'name', 'label', 'heading'] as $tf) {
                if (isset($item[$tf])) {
                    $title = $resolveLocalized($item[$tf]);
                    break;
                }
            }
        }
        $title = is_string($title) && trim($title) !== '' ? trim($title) : ($item['slug'] ?? $item['id'] ?? 'Untitled');

        // Extract summary / excerpt
        $summaryField = $slotConfig['summaryField'] ?? null;
        $summary = null;
        if ($summaryField && isset($item[$summaryField])) {
            $summary = $resolveLocalized($item[$summaryField]);
        } else {
            foreach (['description', 'summary', 'excerpt', 'lead'] as $sf) {
                if (isset($item[$sf])) {
                    $summary = $resolveLocalized($item[$sf]);
                    break;
                }
            }
        }
        $summary = is_string($summary) ? trim(strip_tags($summary)) : '';

        // Extract slug
        $slugField = $slotConfig['slugField'] ?? 'slug';
        $rawSlug   = $resolveLocalized($item[$slugField] ?? $item['slug'] ?? $item['id'] ?? '');
        $slug      = is_string($rawSlug) ? trim($rawSlug) : (string)$rawSlug;

        // Canonical URL
        $urlPattern = $slotConfig['urlPattern'] ?? ('/' . $slotKey . '/{slug}');
        $canonicalPath = str_replace('{slug}', $slug, $urlPattern);
        $canonicalUrl  = $siteUrl . ($lang !== null ? '/' . $lang : '') . $canonicalPath;

        $lines = [];

        // 1. YAML Frontmatter
        $lines[] = '---';
        $lines[] = 'title: ' . json_encode($title, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        $lines[] = 'slug: ' . json_encode($slug, JSON_UNESCAPED_UNICODE);
        $lines[] = 'slot: ' . json_encode($slotKey, JSON_UNESCAPED_UNICODE);
        if ($lang !== null) {
            $lines[] = 'language: ' . json_encode($lang, JSON_UNESCAPED_UNICODE);
        }
        if (isset($item['year'])) {
            $lines[] = 'year: ' . json_encode($item['year']);
        }
        if (isset($item['category'])) {
            $cat = $resolveLocalized($item['category']);
            if (!empty($cat)) {
                $lines[] = 'category: ' . json_encode($cat, JSON_UNESCAPED_UNICODE);
            }
        }
        $lines[] = 'canonical_url: ' . json_encode($canonicalUrl, JSON_UNESCAPED_SLASHES);
        $lines[] = 'generator: "Nomad CMS LLMS Dynamic Markdown Engine"';
        $lines[] = '---';
        $lines[] = '';

        // 2. Heading & Excerpt
        $lines[] = '# ' . $title;
        $lines[] = '';

        if (!empty($summary)) {
            $lines[] = '> ' . $summary;
            $lines[] = '';
        }

        // 3. Process Content Sections / Blocks Builder
        $processedFields = ['_dndId', 'id', 'slug', 'public', 'published', $slugField];
        if ($titleField) $processedFields[] = $titleField;
        if ($summaryField) $processedFields[] = $summaryField;

        // Detect any field configured as 'blocks' or fallback to 'sections'
        $blocksFieldKeys = ['sections'];
        if (isset($slotConfig['fields']) && is_array($slotConfig['fields'])) {
            foreach ($slotConfig['fields'] as $f) {
                if (($f['type'] ?? '') === 'blocks' && !empty($f['id'])) {
                    $blocksFieldKeys[] = $f['id'];
                }
            }
        }
        $blocksFieldKeys = array_unique($blocksFieldKeys);

        foreach ($blocksFieldKeys as $bfKey) {
            if (!isset($item[$bfKey]) || $item[$bfKey] === null) {
                continue;
            }
            $processedFields[] = $bfKey;
            $rawBlocks = $resolveLocalized($item[$bfKey]);

            if (is_array($rawBlocks) && !empty($rawBlocks)) {
                foreach ($rawBlocks as $block) {
                    if (!is_array($block)) {
                        continue;
                    }
                    $blockType = $block['type'] ?? 'text';
                    $blockData = $block['data'] ?? null;

                    if ($blockData === null) {
                        continue;
                    }

                    switch ($blockType) {
                        case 'text':
                        case 'textarea':
                        case 'richtext':
                            $content = self::htmlToMarkdown((string)($blockData['text'] ?? $blockData['content'] ?? (is_string($blockData) ? $blockData : '')), $siteUrl);
                            if (!empty($content)) {
                                $lines[] = $content;
                                $lines[] = '';
                            }
                            break;

                        case 'markdown':
                            $md = trim(is_string($blockData) ? $blockData : ($blockData['content'] ?? ''));
                            if (!empty($md)) {
                                $lines[] = $md;
                                $lines[] = '';
                            }
                            break;

                        case 'quote':
                            $quoteText = trim((string)($blockData['quote'] ?? $blockData['text'] ?? ''));
                            $author = trim((string)($blockData['author'] ?? ''));
                            if (!empty($quoteText)) {
                                $lines[] = '> ' . $quoteText;
                                if (!empty($author)) {
                                    $lines[] = '> — *' . $author . '*';
                                }
                                $lines[] = '';
                            }
                            break;

                        case 'code':
                            $code = (string)($blockData['code'] ?? '');
                            $codeLang = (string)($blockData['language'] ?? 'text');
                            if (!empty($code)) {
                                $lines[] = '```' . $codeLang;
                                $lines[] = $code;
                                $lines[] = '```';
                                $lines[] = '';
                            }
                            break;

                        case 'image':
                            $src = (string)($blockData['src'] ?? $blockData['url'] ?? (is_string($blockData) ? $blockData : ''));
                            $alt = (string)($blockData['alt'] ?? $blockData['caption'] ?? $title);
                            if (!empty($src)) {
                                if (str_starts_with($src, '/')) {
                                    $src = $siteUrl . $src;
                                }
                                $lines[] = '![' . htmlspecialchars($alt, ENT_QUOTES) . '](' . $src . ')';
                                $lines[] = '';
                            }
                            break;

                        case 'gallery':
                            $images = is_array($blockData) ? ($blockData['images'] ?? $blockData) : [];
                            if (is_array($images) && !empty($images)) {
                                foreach ($images as $img) {
                                    $imgSrc = is_array($img) ? ($img['src'] ?? $img['url'] ?? '') : (string)$img;
                                    $imgAlt = is_array($img) ? ($img['alt'] ?? '') : '';
                                    if (!empty($imgSrc)) {
                                        if (str_starts_with($imgSrc, '/')) {
                                            $imgSrc = $siteUrl . $imgSrc;
                                        }
                                        $lines[] = '![' . htmlspecialchars($imgAlt, ENT_QUOTES) . '](' . $imgSrc . ')';
                                    }
                                }
                                $lines[] = '';
                            }
                            break;

                        case 'video':
                            $src = (string)($blockData['src'] ?? $blockData['url'] ?? (is_string($blockData) ? $blockData : ''));
                            $caption = (string)($blockData['title'] ?? $blockData['caption'] ?? 'Video');
                            if (!empty($src)) {
                                if (str_starts_with($src, '/')) {
                                    $src = $siteUrl . $src;
                                }
                                $lines[] = '🎬 **' . htmlspecialchars($caption, ENT_QUOTES) . '**: [' . $src . '](' . $src . ')';
                                $lines[] = '';
                            }
                            break;

                        case 'audio':
                            $src = (string)($blockData['src'] ?? $blockData['url'] ?? (is_string($blockData) ? $blockData : ''));
                            $caption = (string)($blockData['title'] ?? $blockData['caption'] ?? 'Audio');
                            if (!empty($src)) {
                                if (str_starts_with($src, '/')) {
                                    $src = $siteUrl . $src;
                                }
                                $lines[] = '🎵 **' . htmlspecialchars($caption, ENT_QUOTES) . '**: [' . $src . '](' . $src . ')';
                                $lines[] = '';
                            }
                            break;

                        case 'file':
                            $src = (string)($blockData['src'] ?? $blockData['url'] ?? (is_string($blockData) ? $blockData : ''));
                            $fileName = (string)($blockData['name'] ?? $blockData['title'] ?? 'Document');
                            if (!empty($src)) {
                                if (str_starts_with($src, '/')) {
                                    $src = $siteUrl . $src;
                                }
                                $lines[] = '📎 **' . htmlspecialchars($fileName, ENT_QUOTES) . '**: [' . $src . '](' . $src . ')';
                                $lines[] = '';
                            }
                            break;

                        default:
                            if (is_string($blockData) && trim($blockData) !== '') {
                                $lines[] = self::htmlToMarkdown($blockData, $siteUrl);
                                $lines[] = '';
                            }
                            break;
                    }
                }
            }
        }

        // 4. Other fields from schema
        if (isset($slotConfig['fields']) && is_array($slotConfig['fields'])) {
            foreach ($slotConfig['fields'] as $field) {
                $fid = $field['id'] ?? null;
                if (!$fid || in_array($fid, $processedFields, true)) {
                    continue;
                }

                $processedFields[] = $fid;

                if (!isset($item[$fid]) || $item[$fid] === '' || $item[$fid] === null) {
                    continue;
                }

                $fLabel = $field['label'] ?? ucfirst($fid);
                $fType  = $field['type'] ?? 'text';
                $val    = $resolveLocalized($item[$fid]);

                if ($fType === 'image') {
                    $imgUrl = is_string($val) ? $val : ($val['url'] ?? $val['src'] ?? null);
                    if ($imgUrl) {
                        if (str_starts_with($imgUrl, '/')) {
                            $imgUrl = $siteUrl . $imgUrl;
                        }
                        $lines[] = '## ' . $fLabel;
                        $lines[] = '![' . htmlspecialchars($fLabel, ENT_QUOTES) . '](' . $imgUrl . ')';
                        $lines[] = '';
                    }
                } elseif ($fType === 'gallery') {
                    $images = is_array($val) ? ($val['images'] ?? $val) : [];
                    if (is_array($images) && !empty($images)) {
                        $lines[] = '## ' . $fLabel;
                        foreach ($images as $img) {
                            $imgSrc = is_array($img) ? ($img['src'] ?? $img['url'] ?? '') : (string)$img;
                            $imgAlt = is_array($img) ? ($img['alt'] ?? '') : '';
                            if (!empty($imgSrc)) {
                                if (str_starts_with($imgSrc, '/')) {
                                    $imgSrc = $siteUrl . $imgSrc;
                                }
                                $lines[] = '![' . htmlspecialchars($imgAlt ?: $fLabel, ENT_QUOTES) . '](' . $imgSrc . ')';
                            }
                        }
                        $lines[] = '';
                    }
                } elseif (in_array($fType, ['video', 'audio', 'file'], true)) {
                    $fileUrl = is_string($val) ? $val : ($val['url'] ?? $val['src'] ?? null);
                    $fileName = is_array($val) ? ($val['name'] ?? $val['title'] ?? $fLabel) : $fLabel;
                    if ($fileUrl) {
                        if (str_starts_with($fileUrl, '/')) {
                            $fileUrl = $siteUrl . $fileUrl;
                        }
                        $lines[] = '**' . $fLabel . '**: [' . htmlspecialchars((string)$fileName, ENT_QUOTES) . '](' . $fileUrl . ')';
                        $lines[] = '';
                    }
                } elseif ($fType === 'url') {
                    if (is_string($val) && !empty($val)) {
                        $lines[] = '**' . $fLabel . '**: [' . $val . '](' . $val . ')';
                        $lines[] = '';
                    }
                } elseif ($fType === 'email') {
                    if (is_string($val) && !empty($val)) {
                        $lines[] = '**' . $fLabel . '**: [' . $val . '](mailto:' . $val . ')';
                        $lines[] = '';
                    }
                } elseif (in_array($fType, ['text', 'textarea', 'markdown', 'richtext'], true)) {
                    if (is_string($val) && trim($val) !== '') {
                        $lines[] = '## ' . $fLabel;
                        $lines[] = self::htmlToMarkdown($val, $siteUrl);
                        $lines[] = '';
                    }
                } elseif ($fType === 'boolean') {
                    $lines[] = '**' . $fLabel . '**: ' . ($val ? 'Yes' : 'No');
                    $lines[] = '';
                } elseif ($fType === 'json' || is_array($val)) {
                    $formattedJson = self::formatJsonValueToMarkdown($val, $fLabel);
                    if (!empty($formattedJson)) {
                        $lines[] = $formattedJson;
                        $lines[] = '';
                    }
                } elseif (is_scalar($val)) {
                    $lines[] = '**' . $fLabel . '**: ' . (string)$val;
                    $lines[] = '';
                }
            }
        }

        // 5. Any extra un-schematized properties in item (excluding internal keys)
        $ignoredExtraKeys = [
            '_dndId', 'id', 'slug', 'public', 'published', 'status',
            'created_at', 'updated_at', 'deleted_at', 'password', 'token', 'hash', 'salt',
            'slot', 'generated_at', 'languages', 'defaultLanguage', 'locales'
        ];
        foreach ($item as $extraKey => $extraVal) {
            if (str_starts_with((string)$extraKey, '_') || in_array($extraKey, $processedFields, true) || in_array($extraKey, $ignoredExtraKeys, true)) {
                continue;
            }
            if ($extraVal === null || $extraVal === '') {
                continue;
            }
            $val = $resolveLocalized($extraVal);
            if (is_scalar($val)) {
                $lines[] = '**' . ucfirst(str_replace('_', ' ', $extraKey)) . '**: ' . (string)$val;
                $lines[] = '';
            }
        }

        // 5. Canonical Footer
        $lines[] = '---';
        $lines[] = '*View interactive web page: [' . $canonicalUrl . '](' . $canonicalUrl . ')*';
        $lines[] = '';

        return implode("\n", $lines);
    }

    /**
     * Convert basic HTML to clean Markdown
     */
    public static function htmlToMarkdown(string $html, string $siteUrl = ''): string
    {
        if (empty($html)) {
            return '';
        }

        // If it does not contain HTML tags, return as is
        if (!preg_match('/<[a-z][\s\S]*>/i', $html)) {
            return trim($html);
        }

        $text = $html;

        // Headings
        $text = preg_replace('/<h1[^>]*>(.*?)<\/h1>/is', "\n# $1\n", $text);
        $text = preg_replace('/<h2[^>]*>(.*?)<\/h2>/is', "\n## $1\n", $text);
        $text = preg_replace('/<h3[^>]*>(.*?)<\/h3>/is', "\n### $1\n", $text);
        $text = preg_replace('/<h4[^>]*>(.*?)<\/h4>/is', "\n#### $1\n", $text);

        // Strong, em
        $text = preg_replace('/<(strong|b)[^>]*>(.*?)<\/(strong|b)>/is', '**$2**', $text);
        $text = preg_replace('/<(em|i)[^>]*>(.*?)<\/(em|i)>/is', '*$2*', $text);

        // Images in HTML
        $text = preg_replace_callback('/<img\s+[^>]*src=["\']([^"\']*)["\'][^>]*>/i', function($m) use ($siteUrl) {
            $src = $m[1];
            $alt = '';
            if (preg_match('/alt=["\']([^"\']*)["\']/i', $m[0], $altMatch)) {
                $alt = $altMatch[1];
            }
            if ($siteUrl !== '' && str_starts_with($src, '/')) {
                $src = $siteUrl . $src;
            }
            return "\n![" . htmlspecialchars($alt, ENT_QUOTES) . "](" . $src . ")\n";
        }, $text);

        // Links
        $text = preg_replace('/<a\s+[^>]*href=["\']([^"\']*)["\'][^>]*>(.*?)<\/a>/is', '[$2]($1)', $text);

        // Code blocks & inline code
        $text = preg_replace('/<pre><code[^>]*>(.*?)<\/code><\/pre>/is', "\n```\n$1\n```\n", $text);
        $text = preg_replace('/<code[^>]*>(.*?)<\/code>/is', '`$1`', $text);

        // Blockquotes
        $text = preg_replace('/<blockquote[^>]*>(.*?)<\/blockquote>/is', "\n> $1\n", $text);

        // Horizontal rules
        $text = preg_replace('/<hr\s*\/?>/i', "\n---\n", $text);

        // Lists
        $text = preg_replace('/<li[^>]*>(.*?)<\/li>/is', "\n- $1", $text);

        // Tables
        $text = preg_replace('/<\/tr>/i', " |\n", $text);
        $text = preg_replace('/<th[^>]*>(.*?)<\/th>/is', '| **$1** ', $text);
        $text = preg_replace('/<td[^>]*>(.*?)<\/td>/is', '| $1 ', $text);

        // Paragraphs & line breaks
        $text = preg_replace('/<p[^>]*>(.*?)<\/p>/is', "\n$1\n", $text);
        $text = preg_replace('/<br\s*\/?>/i', "\n", $text);

        // Strip remaining tags
        $text = strip_tags($text);

        // Decode HTML entities
        $text = html_entity_decode($text, ENT_QUOTES | ENT_HTML5, 'UTF-8');

        // Normalize multiple blank lines
        $text = preg_replace("/\n{3,}/", "\n\n", $text);

        return trim($text);
    }

    /**
     * Send dynamic in-memory Markdown response with HTTP 304 / ETag support.
     * ZERO bytes written to disk.
     */
    public static function sendMarkdownResponse(string $markdown, ?int $lastModified = null, ?string $etag = null): void
    {
        $mtime = $lastModified ?? time();
        $etagHeader = $etag ?? '"'.hash('sha256',$markdown).'"';

        if (!headers_sent()) {
            header('Content-Type: text/markdown; charset=utf-8');
            header('Cache-Control: public, max-age=600, must-revalidate');
            header('ETag: ' . $etagHeader);
            header('Last-Modified: ' . gmdate('D, d M Y H:i:s', $mtime) . ' GMT');

            $ifNoneMatch     = isset($_SERVER['HTTP_IF_NONE_MATCH']) ? trim($_SERVER['HTTP_IF_NONE_MATCH']) : null;
            $ifModifiedSince = isset($_SERVER['HTTP_IF_MODIFIED_SINCE']) ? strtotime($_SERVER['HTTP_IF_MODIFIED_SINCE']) : false;

            if (($ifNoneMatch && $ifNoneMatch === $etagHeader) || ($ifModifiedSince && $ifModifiedSince >= $mtime)) {
                http_response_code(304);
                exit;
            }
        }

        echo $markdown;
        exit;
    }

    /**
     * Serve static Markdown file with HTTP 304 / ETag support (legacy helper)
     */
    public static function serveStaticMarkdown(string $filePath): void
    {
        $mtime = filemtime($filePath);
        $size  = filesize($filePath);
        $etag  = sprintf('"%x-%x"', $mtime, $size);

        if (!headers_sent()) {
            header('Content-Type: text/markdown; charset=utf-8');
            header('Cache-Control: public, max-age=600, must-revalidate');
            header('ETag: ' . $etag);
            header('Last-Modified: ' . gmdate('D, d M Y H:i:s', $mtime) . ' GMT');

            $ifNoneMatch     = isset($_SERVER['HTTP_IF_NONE_MATCH']) ? trim($_SERVER['HTTP_IF_NONE_MATCH']) : null;
            $ifModifiedSince = isset($_SERVER['HTTP_IF_MODIFIED_SINCE']) ? strtotime($_SERVER['HTTP_IF_MODIFIED_SINCE']) : false;

            if (($ifNoneMatch && $ifNoneMatch === $etag) || ($ifModifiedSince && $ifModifiedSince >= $mtime)) {
                http_response_code(304);
                exit;
            }
        }

        readfile($filePath);
        exit;
    }
}
