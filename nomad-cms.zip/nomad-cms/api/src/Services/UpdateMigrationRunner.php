<?php
/**
 * NOMAD CMS — explicit update migration coordinator.
 * Reuses module-native transactional ledgers and runs new migration batches with
 * their checkpoint in the same target SQLite transaction. Databases commit
 * independently; backward-compatible batches can be safely retried after failure.
 */
declare(strict_types=1);

namespace NomadCMS\Services;

use PDO;
use RuntimeException;

final class UpdateMigrationRunner
{
    public static function step(array $release, int $index, ?array $connections = null): array
    {
        $native = glob(dirname(__DIR__, 2) . '/integrations/migrations/[0-9]*.php') ?: [];
        sort($native, SORT_STRING);
        $connections ??= self::connections();
        if ($index < count($native)) {
            $migration = require $native[$index];
            if (!$migration instanceof \Closure) {
                throw new RuntimeException('Invalid native migration.');
            }
            $migration($connections);
            return ['done' => false, 'cursor' => $index + 1];
        }
        $planned = $release['migrations'] ?? [];
        $item = $planned[$index - count($native)] ?? null;
        if ($item === null) {
            return ['done' => true, 'cursor' => 0];
        }
        $root = dirname(__DIR__, 3);
        $path = $root . '/' . $item['file'];
        $db = $connections[$item['database']] ?? null;
        if (!$db instanceof PDO || ($item['backward_compatible'] ?? false) !== true
            || !str_starts_with($item['file'], 'api/integrations/update-migrations/') || !is_file($path)) {
            throw new RuntimeException('Invalid update migration target.');
        }
        return self::batch($db, $item['id'], hash_file('sha256', $path), require $path, $index, $release['version']);
    }

    /** A migration returns done/cursor; its mutations and checkpoint commit together. */
    public static function batch(PDO $db, string $id, string $checksum, mixed $migration, int $index, string $version): array
    {
        if (!$migration instanceof \Closure) {
            throw new RuntimeException('Migration must return a closure.');
        }
        $db->exec('PRAGMA busy_timeout=10000');
        $db->exec('CREATE TABLE IF NOT EXISTS system_migrations (
            id TEXT PRIMARY KEY, checksum TEXT NOT NULL, version TEXT NOT NULL,
            batch INTEGER NOT NULL, cursor_json TEXT NOT NULL DEFAULT \'[]\',
            completed INTEGER NOT NULL DEFAULT 0, applied_at TEXT, duration_ms INTEGER NOT NULL DEFAULT 0
        )');
        $started = microtime(true);
        $db->beginTransaction();
        try {
            $query = $db->prepare('SELECT * FROM system_migrations WHERE id = ?');
            $query->execute([$id]);
            $existing = $query->fetch(PDO::FETCH_ASSOC);
            if ($existing && !hash_equals($existing['checksum'], $checksum)) {
                throw new RuntimeException('An applied migration was changed: ' . $id);
            }
            if ($existing && (int) $existing['completed'] === 1) {
                $db->commit();
                return ['done' => false, 'cursor' => $index + 1];
            }
            $cursor = $existing ? json_decode($existing['cursor_json'], true, 32, JSON_THROW_ON_ERROR) : [];
            $result = $migration($db, $cursor);
            if (!is_array($result) || !is_bool($result['done'] ?? null) || !is_array($result['cursor'] ?? null)) {
                throw new RuntimeException('Migration must return a boolean done and array cursor.');
            }
            $query = $db->prepare('INSERT INTO system_migrations(id, checksum, version, batch, cursor_json, completed, applied_at, duration_ms)
                VALUES(?, ?, ?, ?, ?, ?, ?, ?) ON CONFLICT(id) DO UPDATE SET cursor_json=excluded.cursor_json,
                completed=excluded.completed, applied_at=excluded.applied_at, duration_ms=system_migrations.duration_ms+excluded.duration_ms');
            $query->execute([$id, $checksum, $version, $index, json_encode($result['cursor'], JSON_THROW_ON_ERROR),
                $result['done'] ? 1 : 0, $result['done'] ? gmdate('c') : null, (int) ((microtime(true) - $started) * 1000)]);
            $db->commit();
            return ['done' => false, 'cursor' => $result['done'] ? $index + 1 : $index];
        } catch (\Throwable $error) {
            if ($db->inTransaction()) {
                $db->rollBack();
            }
            throw $error;
        }
    }

    private static function connections(): array
    {
        $connections = [
            'content' => \NomadCMS\Database\ContentDatabase::getInstance(false),
            'massive' => \NomadCMS\Database\MassiveDatabase::getInstance(true),
            'auth' => \NomadCMS\Database\AuthDatabase::getInstance(false),
        ];
        $path = \NomadCMS\Services\Schema\SchemaStore::path();
        if (is_file($path)) {
            $connections['schema'] = new PDO('sqlite:' . $path, null, null, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
        }
        foreach ($connections as $db) {
            $db->exec('PRAGMA busy_timeout=10000');
        }
        return $connections;
    }
}
