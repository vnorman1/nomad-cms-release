<?php

/**
 * NOMAD CMS - Outgoing webhook media URL projection.
 * Expands local upload URLs using APP_URL after field selection, just before
 * shaping/signing. Stored content and external URLs remain unchanged; no DB or I/O.
 */

declare(strict_types=1);

namespace NomadCMS\Services;

final class WebhookPayloadService
{
    public static function prepare(array $payload): array
    {
        $base = rtrim(trim((string) ($_ENV['APP_URL'] ?? getenv('APP_URL') ?: '')), '/');
        if (!preg_match('~^https?://[^/]+~i', $base)) {
            return $payload;
        }
        return self::expand($payload, $base);
    }

    private static function expand(mixed $value, string $base): mixed
    {
        if (is_array($value)) {
            foreach ($value as $key => $child) {
                $value[$key] = self::expand($child, $base);
            }
        } elseif (is_string($value)) {
            if (str_starts_with($value, '/api/uploads/')) {
                return $base . $value;
            }
            // Rich text and block markup can embed images in src/srcset attributes.
            if (str_contains($value, '<') && str_contains($value, '/api/uploads/')) {
                return preg_replace_callback(
                    '~\b(src|srcset|poster|href)(\s*=\s*)([\x22\x27])(.*?)\3~is',
                    static function (array $attribute) use ($base): string {
                        $urls = preg_replace_callback(
                            '~(^|[\s,])(/api/uploads/[^\s,]+)~',
                            static fn(array $match): string => $match[1] . $base . $match[2],
                            $attribute[4]
                        );
                        return $attribute[1] . $attribute[2] . $attribute[3] . $urls . $attribute[3];
                    },
                    $value
                );
            }
        }
        return $value;
    }
}
