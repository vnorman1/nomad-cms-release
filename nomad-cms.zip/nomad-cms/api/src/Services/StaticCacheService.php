<?php
/**
 * NOMAD CMS - Static Cache Service v2
 * Per-Slot Folder Structure with Dynamic Identifier Detection
 * 
 * Generates static JSON files in a hierarchical folder structure:
 * - Each slot gets its own directory: /static/content/{slot}/
 * - Each slot has a manifest.json with metadata
 * - Collection items are stored as individual {identifier}.json files
 * 
 * Features:
 * - Atomic file writes (temp + rename)
 * - Dynamic identifier detection (slug, id, sku, name, title)
 * - Collection chunking for large datasets
 * - Automatic cleanup of orphaned files
 */

declare(strict_types=1);

namespace NomadCMS\Services;
use PDO;

use NomadCMS\Database\ContentDatabase;
use NomadCMS\Services\RelationService;

final class StaticCacheService
{
    /**
     * Cache directory path
     */
    private static ?string $cacheDir = null;
    
    /**
     * Slot types that should be cached (public content)
     * Massive types are excluded (API-only)
     */
    private const CACHEABLE_TYPES = ['object', 'list', 'collection'];
    
    /**
     * Allowed status values for published content
     */
    private const ALLOWED_STATUSES = ['stabil', 'mukodo', 'published', 'active'];
    
    /**
     * Default chunk size for large collections
     */
    private const DEFAULT_CHUNK_SIZE = 100;

    /**
     * Max collection size for synchronous cache generation during web requests.
     * Larger collections are deferred to avoid blocking editor saves.
     */
    private const MAX_SYNC_COLLECTION_ITEMS = 300;
    
    /**
     * Priority order for identifier detection
     */
    private const SLUG_FIELDS = ['slug', 'url_key', 'permalink', 'handle'];
    // No underscore-prefixed field belongs here: identifiers become public
    // filenames and manifest index values, while cleanDataForCache() strips
    // every "_" key from the data — the two would disagree.
    private const ID_FIELDS = ['id', 'uuid', 'sku', 'code', 'product_id'];
    private const NAME_FIELDS = ['name', 'title', 'label'];
    
    /**
     * Debounce tracking for meta regeneration
     */
    private static ?float $lastMetaRegenTime = null;

    /**
     * Internal flag to force synchronous generation (used by rebuildAll).
     */
    private static bool $forceSynchronousGeneration = false;
    
    // =========================================================================
    // INITIALIZATION
    // =========================================================================
    
    /**
     * Check if static cache is enabled
     */
    private static function isEnabled(): bool
    {
        return CacheSettingsService::getInstance()->isEnabled();
    }

    /**
     * Initialize cache directory
     */
    private static function init(): void
    {
        if (self::$cacheDir !== null) {
            return;
        }
        
        self::$cacheDir = dirname(__DIR__, 2) . '/static/content/';
        
        if (!is_dir(self::$cacheDir)) {
            mkdir(self::$cacheDir, 0755, true);
        }
    }
    
    /**
     * Ensure a slot directory exists
     */
    private static function ensureSlotDirectory(string $slotKey): string
    {
        self::init();
        
        $sanitized = self::sanitizeFilename($slotKey);
        
        // Double check for empty directory names
        if (empty($sanitized)) {
            throw new \InvalidArgumentException('Cannot create directory for empty slot key');
        }
        
        $slotDir = self::$cacheDir . $sanitized . '/';
        
        if (!is_dir($slotDir)) {
            mkdir($slotDir, 0755, true);
        }
        
        return $slotDir;
    }
    
    /**
     * Per-request cache of the parsed schema.
     *
     * SHARED HOSTING: loadSchema() is called from getSlotDefinition() and from
     * sanitizeForIdentifier(), and the latter runs ONCE PER ITEM. Without this
     * cache a 300-item collection re-read and re-decoded nomad.schema.json 300+
     * times (~15 ms of pure I/O + parse per rebuild, on top of the syscalls).
     */
    private static ?array $schemaCache = null;

    /**
     * Load schema definition (memoized per request)
     */
    private static function loadSchema(): ?array
    {
        return RelationService::loadSchema();
    }

    /**
     * Drop the memoized schema. Call after the schema file was rewritten.
     */
    public static function clearSchemaCache(): void
    {
        self::$schemaCache = null;
        PublicPayloadService::clearCaches();
    }
    
    /**
     * Get slot definition from schema
     */
    public static function getSlotDefinition(string $slotKey): ?array
    {
        $schema = self::loadSchema();
        return $schema['slots'][$slotKey] ?? null;
    }
    
    // =========================================================================
    // IDENTIFIER DETECTION
    // =========================================================================
    
    /**
     * Detect the best identifier field for collection items
     * 
     * Priority:
     * 1. Explicit schema setting (slugField)
     * 2. Common slug-like fields
     * 3. Unique identifier fields
     * 4. Name-based fallback
     * 5. Array index
     */
    public static function detectItemIdentifier(?array $slotSchema, array $firstItem): string
    {
        // 1. Explicit schema setting
        if (!empty($slotSchema['slugField'])) {
            return $slotSchema['slugField'];
        }
        
        // 2. Common slug-like fields
        foreach (self::SLUG_FIELDS as $field) {
            if (isset($firstItem[$field]) && !empty($firstItem[$field])) {
                return $field;
            }
        }
        
        // 3. Unique identifier fields
        foreach (self::ID_FIELDS as $field) {
            if (isset($firstItem[$field])) {
                return $field;
            }
        }
        
        // 4. Name-based fallback
        foreach (self::NAME_FIELDS as $field) {
            if (isset($firstItem[$field]) && !empty($firstItem[$field])) {
                return $field;
            }
        }
        
        // 5. Last resort: array index.
        //
        // The item UID (_dndId) is deliberately NOT used here, even though it is
        // the only per-item value guaranteed to be unique and stable. The
        // identifier becomes a public filename AND the manifest's
        // `identifierField` + index values, so choosing it would publish the
        // internal identity this CMS must never expose.
        return '_index';
    }
    
    /**
     * Get identifier value from item
     */
    public static function getItemIdentifier(array $item, string $identifierField, int $index): string
    {
        if ($identifierField === '_index') {
            return (string) $index;
        }
        
        $value = $item[$identifierField] ?? null;
        
        if ($value === null || $value === '' || $value === []) {
            // Fallback to 'slug' or 'id' if available
            if (!empty($item['slug']) && is_string($item['slug'])) {
                return self::sanitizeForIdentifier($item['slug']);
            }
            if (!empty($item['id']) && (is_string($item['id']) || is_numeric($item['id']))) {
                return self::sanitizeForIdentifier((string)$item['id']);
            }
            return (string) $index;
        }
        
        return self::sanitizeForIdentifier($value);
    }
    
    /**
     * Sanitize value for use as filename/identifier
     * Supports strings, numbers, and i18n localized arrays
     */
    public static function sanitizeForIdentifier(mixed $value): string
    {
        // Handle i18n array / localized object
        if (is_array($value)) {
            $schema = self::loadSchema();
            $defaultLang = $schema['i18n']['defaultLanguage'] ?? 'hu';
            
            if (isset($value[$defaultLang]) && (is_string($value[$defaultLang]) || is_numeric($value[$defaultLang])) && trim((string)$value[$defaultLang]) !== '') {
                $value = (string) $value[$defaultLang];
            } else {
                // Find first non-empty string in array
                $found = null;
                foreach ($value as $v) {
                    if (is_string($v) && trim($v) !== '') {
                        $found = $v;
                        break;
                    } elseif (is_numeric($v)) {
                        $found = (string) $v;
                        break;
                    }
                }
                $value = $found ?? '';
            }
        }
        
        $str = (string) $value;
        
        // Convert Hungarian/special characters
        $str = strtr($str, [
            'á' => 'a', 'é' => 'e', 'í' => 'i', 'ó' => 'o', 'ö' => 'o', 'ő' => 'o',
            'ú' => 'u', 'ü' => 'u', 'ű' => 'u',
            'Á' => 'a', 'É' => 'e', 'Í' => 'i', 'Ó' => 'o', 'Ö' => 'o', 'Ő' => 'o',
            'Ú' => 'u', 'Ü' => 'u', 'Ű' => 'u',
            'ä' => 'a', 'ë' => 'e', 'ï' => 'i', 'ô' => 'o', 'û' => 'u',
            'ñ' => 'n', 'ç' => 'c', 'ß' => 'ss',
        ]);
        
        // Lowercase and replace non-alphanumeric
        $str = strtolower($str);
        $str = preg_replace('/[^a-z0-9]+/', '-', $str);
        $str = trim($str, '-');
        
        return $str ?: 'unnamed';
    }
    
    /**
     * Sanitize slot key for use as filename/directory
     */
    private static function sanitizeFilename(string $key): string
    {
        return preg_replace('/[^a-zA-Z0-9_\-]/', '_', $key);
    }
    
    // =========================================================================
    // CONTENT FILTERING & CLEANING
    // =========================================================================
    
    /**
     * Internal fields to remove from cache output
     * These are frontend/CMS internal tracking fields
     *
     * NOTE: `_dndId` is NOT listed here because it is handled generically —
     * cleanDataForCache() drops EVERY underscore-prefixed key, with no
     * allow-list. Relation embeds are already merged onto their own field names
     * by RelationService::projectForPublic() before cleaning runs, so nothing
     * public depends on a "_" key any more.
     */
    private const INTERNAL_FIELDS = [
        '_isPending',    // Pending upload marker
        '_localId',      // Local temporary ID
        '_dirty',        // Dirty tracking flag
        '_selected',     // UI selection state
        '_expanded',     // UI expansion state
        '_temp',         // Temporary data
    ];
    
    /**
     * Clean data for static cache output
     * - Removes internal fields (_dndId, _isPending, etc.)
     * - Filters out empty/null blocks
     * - Recursively cleans nested structures
     * 
     * @param mixed $data Data to clean
     * @return mixed Cleaned data
     */
    /**
     * Cache of media metadata to avoid multiple DB queries during cache generation
     */
    private static ?array $mediaMetaCache = null;

    /**
     * Get or load all media metadata indexed by filename/url
     */
    private static function getMediaMetaMap(): array
    {
        if (self::$mediaMetaCache === null) {
            try {
                self::$mediaMetaCache = ContentDatabase::getAllMediaMeta();
            } catch (\Throwable $e) {
                self::$mediaMetaCache = [];
            }
        }
        return self::$mediaMetaCache;
    }

    /**
     * Clear media meta cache (call before slot generation batch)
     */
    public static function clearMediaMetaCache(): void
    {
        self::$mediaMetaCache = null;
    }

    /**
     * Check if a string is a media asset path or URL
     */
    private static function isMediaString(mixed $value, array $mediaMeta): bool
    {
        if (!is_string($value) || empty($value)) {
            return false;
        }
        
        if (str_starts_with($value, '/api/uploads/') || str_starts_with($value, '/uploads/')) {
            return true;
        }
        
        $filename = basename(rawurldecode(parse_url($value, PHP_URL_PATH) ?? $value));
        return isset($mediaMeta[$filename]) || isset($mediaMeta[$value]);
    }

    /**
     * Find media metadata by path or URL
     */
    private static function findMediaMeta(string $src, array $mediaMeta): ?array
    {
        $filename = basename(rawurldecode(parse_url($src, PHP_URL_PATH) ?? $src));
        if (isset($mediaMeta[$filename])) {
            return $mediaMeta[$filename];
        }
        if (isset($mediaMeta[$src])) {
            return $mediaMeta[$src];
        }
        return null;
    }

    /**
     * Enrich a media item with central ALT metadata if not already custom
     */
    private static function enrichMediaData(mixed $data): mixed
    {
        $mediaMap = self::getMediaMetaMap();
        
        // If $data is already an array with 'src': { src: "...", alt: { ... } } or { src: "..." }
        if (is_array($data) && isset($data['src']) && is_string($data['src'])) {
            $src = $data['src'];
            $meta = self::findMediaMeta($src, $mediaMap);
            $centralAlt = !empty($meta['alt']) ? $meta['alt'] : [];
            $customAlt = is_array($data['alt'] ?? null) ? $data['alt'] : [];
            $customAlt = array_filter($customAlt, fn($v) => is_string($v) && trim($v) !== '');
            $mergedAlt = array_merge($centralAlt, $customAlt);
            
            $res = ['src' => $src];
            if (!empty($mergedAlt)) {
                $res['alt'] = $mergedAlt;
            }
            return $res;
        }
        
        // If $data is a string path: "/api/uploads/..."
        if (is_string($data) && !empty($data)) {
            $meta = self::findMediaMeta($data, $mediaMap);
            $alt = !empty($meta['alt']) ? $meta['alt'] : [];
            $res = ['src' => $data];
            if (!empty($alt)) {
                $res['alt'] = $alt;
            }
            return $res;
        }
        
        return $data;
    }

    /**
     * Clean data for static cache output
     * - Removes internal fields (_dndId, _isPending, etc.)
     * - Enriches media fields and media blocks with central ALT metadata
     * - Filters out empty/null blocks
     * - Recursively cleans nested structures
     * 
     * @param mixed $data Data to clean
     * @return mixed Cleaned data
     */
    private static function cleanDataForCache(mixed $data): mixed
    {
        if (!is_array($data)) {
            return $data;
        }
        
        // Check if this is a blocks array (ContentBlock[])
        if (self::isBlocksArray($data)) {
            return self::cleanBlocksArray($data);
        }
        
        $mediaMap = self::getMediaMetaMap();
        
        // Check if sequential array (list of items / gallery)
        if (array_is_list($data)) {
            return array_map(function($item) use ($mediaMap) {
                if (is_string($item) && self::isMediaString($item, $mediaMap)) {
                    return self::enrichMediaData($item);
                }
                return self::cleanDataForCache($item);
            }, $data);
        }
        
        // Associative array - clean recursively and remove internal fields
        $cleaned = [];
        foreach ($data as $key => $value) {
            // Skip internal fields
            if (in_array($key, self::INTERNAL_FIELDS, true)) {
                continue;
            }
            
            // Underscore-prefixed keys are internal by convention (item identity,
            // relation embeds, UI state, developer flags, ...). The static cache
            // is public output, so none of them may survive — RelationService::
            // projectForPublic() has already merged the relation embeds onto
            // their own field names before this runs.
            if (is_string($key) && str_starts_with($key, '_') && strlen($key) > 1) {
                continue;
            }
            
            // If value is a media object { src: "...", alt?: ... }
            if (is_array($value) && isset($value['src']) && is_string($value['src'])) {
                $cleaned[$key] = self::enrichMediaData($value);
                continue;
            }

            // If value is a media string
            if (is_string($value) && self::isMediaString($value, $mediaMap)) {
                $cleaned[$key] = self::enrichMediaData($value);
                continue;
            }
            
            // Recursively clean value
            $cleaned[$key] = self::cleanDataForCache($value);
        }
        
        return $cleaned;
    }
    
    /**
     * Check if array is a blocks array (ContentBlock[])
     */
    private static function isBlocksArray(array $data): bool
    {
        if (empty($data) || !array_is_list($data)) {
            return false;
        }
        
        // Check first element for block structure
        $first = $data[0];
        if (!is_array($first)) {
            return false;
        }
        
        // Blocks have 'id', 'type', and 'data' keys
        return isset($first['id']) && isset($first['type']) && array_key_exists('data', $first);
    }
    
    /**
     * Clean blocks array - remove empty blocks, clean data, and enrich media blocks
     */
    private static function cleanBlocksArray(array $blocks): array
    {
        $cleaned = [];
        
        foreach ($blocks as $block) {
            if (!is_array($block)) {
                continue;
            }
            
            // Skip blocks with null/empty data (unfinished blocks)
            $blockData = $block['data'] ?? null;
            if ($blockData === null || $blockData === '' || $blockData === []) {
                continue;
            }
            
            $blockType = $block['type'] ?? '';
            
            // Media block types: enrich with central ALT
            if (in_array($blockType, ['image', 'video', 'audio', 'gif'], true)) {
                $cleanedData = self::enrichMediaData($blockData);
            } else {
                $cleanedData = self::cleanDataForCache($blockData);
            }
            
            // Clean the block.
            //
            // `id` is intentionally not carried over: it is the editor's handle
            // on a block and has no meaning for a public consumer.
            // PublicPayloadService strips it as well, so the dynamic endpoint
            // produces the same blocks — this keeps the cache path consistent
            // even before the split runs.
            $cleanedBlock = [
                'type' => $blockType,
                'data' => $cleanedData,
            ];
            
            $cleaned[] = $cleanedBlock;
        }
        
        return $cleaned;
    }

    /**
     * Filter content to only include published items
     */
    private static function filterPublishedContent(string $slotKey, mixed $data): mixed
    {
        return PublicPayloadService::filterPublished($slotKey, $data);
    }
    
    /**
     * Check if data contains large binary content
     */
    private static function containsLargeBinaryData(mixed $data, int $threshold = 50000): bool
    {
        if (!is_array($data)) {
            return false;
        }
        
        $json = json_encode($data);
        if ($json === false) {
            return false;
        }
        
        if (preg_match('/data:[^;]+;base64,[A-Za-z0-9+\/=]{' . $threshold . ',}/', $json)) {
            return true;
        }
        
        return false;
    }
    
    // =========================================================================
    // MAIN GENERATION ENTRY POINT
    // =========================================================================
    
    /**
     * Generate static cache for a slot
     * Routes to appropriate method based on slot type
     * 
     * @param string $key Slot key
     * @param mixed $data Slot data
     * @param string|null $slotType Optional slot type
     * @param bool $skipMetaRegeneration Skip global manifest regeneration
     * @return bool Success
     */
    public static function generateForSlot(string $key, mixed $data, ?string $slotType = null, bool $skipMetaRegeneration = false): bool
    {
        if (\NomadCMS\Database\CollectionDatabase::isRegistered($key)) {
            if (PHP_SAPI === 'cli' || self::$forceSynchronousGeneration) return self::rebuildRowCollection($key);
            self::markCollectionDirty($key);
            return true;
        }
        if (!self::isEnabled()) {
            return false;
        }
        
        // Skip empty keys
        if (empty(trim($key))) {
            error_log("[StaticCache] Skipping empty slot key");
            return false;
        }
        
        self::init();
        
        // Get slot type from schema if not provided
        $slotDef = self::getSlotDefinition($key);
        if ($slotType === null) {
            $slotType = $slotDef['type'] ?? 'object';
        }
        
        // Skip massive types (API-only)
        if ($slotType === 'massive') {
            error_log("[StaticCache] Skipping massive slot: {$key} (API-only)");
            return false;
        }

        // Skip list types: internal-only, used exclusively as relation targets
        // (e.g. tags/categories/authors embedded into a collection). A `list`
        // slot has no per-item identity meant for public consumption, and
        // publishing it directly would duplicate data that already reaches the
        // public payload through the collections that embed it. Any cache this
        // slot had from before this rule existed is removed so the change is
        // retroactive, not just forward-looking.
        // Opt-in public lists now publish stable UID-addressed documents.
        if ($slotType === 'list' && !RelationService::isPublicList($key)) {
            self::removeSlotCacheDirectory($key);
            error_log("[StaticCache] Skipping list slot: {$key} (internal-only, relation-target)");
            return false;
        }

        // Defer very large collection generations during normal web requests to
        // keep authoring operations responsive. Full generation remains available
        // via rebuildAll() and other explicit maintenance flows.
        if (
            !self::$forceSynchronousGeneration
            && PHP_SAPI !== 'cli'
            && $slotType === 'collection'
            && is_array($data)
            && count($data) > self::MAX_SYNC_COLLECTION_ITEMS
        ) {
            self::init();
            @touch(self::$cacheDir . '.manifest_dirty');
            error_log("[StaticCache] Deferred large collection generation for {$key} (" . count($data) . " items)");
            return false;
        }
        
        // Skip binary data
        if (self::containsLargeBinaryData($data)) {
            error_log("[StaticCache] Skipping {$key}: contains large binary data");
            return false;
        }
        
        // RELATION RESOLUTION + PUBLIC PROJECTION: embed related data before
        // caching, then reduce it to its public shape.
        // Applies to every cacheable slot type (object, list, collection) so the
        // static JSON is self-contained and the public site never has to join.
        // Resolution is depth-1, so circular relations terminate.
        //
        // projectForPublic() merges each `_<fieldId>` embed onto `<fieldId>` and
        // removes every internal key/uid — the static cache is public output, so
        // no `_dndId` and no raw relation uid may survive here.
        // Filter published content before projection can remove visibility controls.
        $data = self::filterPublishedContent($key, $data);

        if (is_array($data)) {
            try {
                $data = RelationService::projectForPublic($key, $data);
            } catch (\Throwable $e) {
                error_log("[StaticCache] Public projection failed for {$key}: " . $e->getMessage());
                if ($slotType === 'list') {
                    self::removeSlotCacheDirectory($key);
                    return false;
                }
                // Non-blocking — continue without resolved relations
            }
        }

        // Clean data for cache output (remove internal fields, empty blocks, etc.)
        $data = self::cleanDataForCache($data);
        
        // Per-slot lock to allow multiple different slots to generate concurrently
        $slotLockFile = self::$cacheDir . '.slot_' . self::sanitizeFilename($key) . '.lock';
        $slotLockHandle = @fopen($slotLockFile, 'c');
        if ($slotLockHandle !== false) {
            @flock($slotLockHandle, LOCK_EX);
        }

        try {
            // Route to appropriate method
            $result = match($slotType) {
                'object' => self::generateObjectSlot($key, $data),
                'list' => self::generateListSlot($key, $data),
                'collection' => self::generateCollectionSlot($key, $data),
                default => self::generateObjectSlot($key, $data),
            };
        } finally {
            if ($slotLockHandle !== false) {
                @flock($slotLockHandle, LOCK_UN);
                @fclose($slotLockHandle);
                @unlink($slotLockFile);
            }
        }
        
        // Regenerate global manifest
        if ($result && !$skipMetaRegeneration) {
            self::regenerateMetaFilesDebounced();
        }

        // CASCADE INVALIDATION: when a target slot changes (e.g. 'cimkek'),
        // regenerate every source slot that embeds its data (e.g. 'konyvek'),
        // otherwise those caches keep serving the old embedded copy.
        //
        // The dependent generation passes skipMetaRegeneration=true, which is also
        // the recursion guard: a cascaded run never cascades again, so circular
        // relations (A -> B -> A) settle after one hop.
        if ($result && !$skipMetaRegeneration) {
            foreach (RelationService::getDependentSlots($key) as $depKey) {
                try {
                    if (\NomadCMS\Database\CollectionDatabase::isRegistered($depKey)) {
                        self::markCollectionDirty($depKey);
                        continue;
                    }
                    $depData = ContentDatabase::getSlot($depKey);
                    if ($depData !== null) {
                        self::generateForSlot($depKey, $depData, null, true);
                        error_log("[StaticCache] Cascade-regenerated '{$depKey}' because '{$key}' changed");
                    }
                } catch (\Throwable $e) {
                    error_log("[StaticCache] Cascade regeneration failed for '{$depKey}': " . $e->getMessage());
                }
            }
        }
        
        return $result;
    }
    
    // =========================================================================
    // SLOT TYPE GENERATORS
    // =========================================================================
    
    /**
     * Generate cache for an object slot
     * Creates: {slot}/manifest.json with the payload inlined at the top level
     *
     * There is no `data` wrapper: language-independent fields sit next to the
     * envelope meta and localized content goes under `locales` (omitted when
     * there is only one language).
     */
    private static function generateObjectSlot(string $slotKey, mixed $data): bool
    {
        $slotDir = self::ensureSlotDirectory($slotKey);

        $manifest = [
            'slot' => $slotKey,
            'type' => 'object',
            'generated_at' => date('c'),
        ] + PublicPayloadService::envelopeLanguageMeta();

        if (is_array($data)) {
            $parts = PublicPayloadService::split($slotKey, $data);
            $root  = PublicPayloadService::stripReservedKeys($parts['root'], $slotKey);

            // Meta first: a content field must not shadow an envelope key.
            $manifest += $root;

            if ($parts['locales'] !== null) {
                $manifest['locales'] = $parts['locales'];
            }
        }

        $manifestHash = MerkleService::hashPayload($manifest);
        $oldMerkle = MerkleService::loadSlotMerkleState($slotDir);
        if ($oldMerkle !== null && ($oldMerkle['manifest'] ?? null) === $manifestHash && is_file($slotDir . 'manifest.json')) {
            error_log("[StaticCache] Unchanged object slot: {$slotKey} (skipped write)");
            return true;
        }

        $success = self::atomicWriteJson($slotDir . 'manifest.json', $manifest);
        
        if ($success) {
            MerkleService::saveSlotMerkleState($slotDir, [
                'root' => $manifestHash,
                'items' => [],
                'chunks' => [],
                'manifest' => $manifestHash,
            ]);
            error_log("[StaticCache] Generated object slot: {$slotKey}");
        }
        
        return $success;
    }
    
    /**
     * Generate cache for a list slot
     * Creates: {slot}/manifest.json with items inline
     */
    private static function generateListSlot(string $slotKey, mixed $data): bool
    {
        $slotDir = self::ensureSlotDirectory($slotKey);
        
        $items = is_array($data) ? array_values($data) : [];

        // Split per item so peak memory stays proportional to one item x
        // languages rather than the whole collection x languages.
        $manifest = PublicListService::payload($slotKey, $items);
        foreach ($items as $item) {
            if (!is_array($item) || !is_string($item['uid'] ?? null)) {
                continue;
            }
            // Existing canonical UIDs use this safe alphabet; never transform
            // an unsafe legacy UID into a colliding filename.
            if (!preg_match('/^[a-zA-Z0-9_-]+$/D', $item['uid']) || $item['uid'] === 'manifest') {
                self::removeSlotCacheDirectory($slotKey);
                return false;
            }
            if (!self::atomicWriteJson($slotDir . $item['uid'] . '.json', PublicListService::payload($slotKey, $item, null, true))) {
                self::removeSlotCacheDirectory($slotKey);
                return false;
            }
        }

        $manifestHash = MerkleService::hashPayload($manifest);
        $oldMerkle = MerkleService::loadSlotMerkleState($slotDir);
        if ($oldMerkle !== null && ($oldMerkle['manifest'] ?? null) === $manifestHash && is_file($slotDir . 'manifest.json')) {
            self::purgeOrphanedFiles($slotKey);
            error_log("[StaticCache] Unchanged list slot: {$slotKey} (skipped write)");
            return true;
        }
        
        $success = self::atomicWriteJson($slotDir . 'manifest.json', $manifest);
        
        if ($success) {
            self::purgeOrphanedFiles($slotKey);
            MerkleService::saveSlotMerkleState($slotDir, [
                'root' => $manifestHash,
                'items' => [],
                'chunks' => [],
                'manifest' => $manifestHash,
            ]);
            error_log("[StaticCache] Generated list slot: {$slotKey} ({$manifest['itemCount']} items)");
        } else {
            self::removeSlotCacheDirectory($slotKey);
        }
        
        return $success;
    }
    
    /**
     * Partition collection index into stable chunk buckets to avoid domino shifts.
     *
     * @param array<int, array>    $index
     * @param int                  $chunkSize
     * @param array<string, int>   $oldChunkMap Previous [slug => chunkIndex] mapping
     * @return array<int, array>   Array of chunk entries [chunkIndex => entries]
     */
    public static function partitionIntoStableChunks(array $index, int $chunkSize, array $oldChunkMap = []): array
    {
        if (empty($index)) {
            return [];
        }

        // If total items fit into a single chunk, consolidate into 1 chunk
        if (count($index) <= $chunkSize) {
            return [$index];
        }

        // If no prior chunk map, use standard linear partitioning
        if (empty($oldChunkMap)) {
            return array_chunk($index, $chunkSize);
        }

        // Group items that already had chunk assignments
        $buckets = [];
        $unassigned = [];

        foreach ($index as $entry) {
            $slug = $entry['slug'] ?? null;
            if ($slug !== null && isset($oldChunkMap[$slug])) {
                $targetChunk = (int)$oldChunkMap[$slug];
                $buckets[$targetChunk][] = $entry;
            } else {
                $unassigned[] = $entry;
            }
        }

        // Place newly created / unassigned items into buckets
        if (!empty($unassigned)) {
            ksort($buckets);
            $maxChunk = !empty($buckets) ? (int)max(array_keys($buckets)) : 0;

            foreach ($unassigned as $entry) {
                // If the last chunk has space (< chunkSize), place it there
                if (isset($buckets[$maxChunk]) && count($buckets[$maxChunk]) < $chunkSize) {
                    $buckets[$maxChunk][] = $entry;
                } else {
                    $maxChunk++;
                    $buckets[$maxChunk] = [$entry];
                }
            }
        }

        // Re-index bucket numbers continuously: 0, 1, 2...
        ksort($buckets);
        $result = [];
        $idx = 0;
        foreach ($buckets as $b) {
            if (!empty($b)) {
                $result[$idx] = array_values($b);
                $idx++;
            }
        }

        // If an intermediate bucket fell below 30% of chunkSize, rebalance with array_chunk
        $minAllowed = (int)max(10, $chunkSize * 0.3);
        $needsRebalance = false;
        if (count($result) > 1) {
            foreach ($result as $cIdx => $bEntries) {
                if ($cIdx < count($result) - 1 && count($bEntries) < $minAllowed) {
                    $needsRebalance = true;
                    break;
                }
            }
        }

        if ($needsRebalance) {
            return array_chunk($index, $chunkSize);
        }

        return $result;
    }

    /**
     * Build collection manifest payload and chunks from an array of collection items.
     *
     * @param string $slotKey
     * @param array $items
     * @param array|null $slotDef
     * @return array{manifest: array, chunks: array<int, array>, validIdentifiers: array<string>, itemHashes: array<string, string>, chunkHashes: array<string, string>, chunkMap: array<string, int>}
     */
    public static function buildCollectionManifestPayload(string $slotKey, array $items, ?array $slotDef = null): array
    {
        $slotDef ??= self::getSlotDefinition($slotKey);
        $items = array_values($items);
        $languageMeta = PublicPayloadService::envelopeLanguageMeta();
        $generatedAt = date('c');

        if (empty($items)) {
            $manifest = [
                'slot' => $slotKey,
                'type' => 'collection',
                'generated_at' => $generatedAt,
            ]
                + $languageMeta
                + [
                    'itemCount' => 0,
                    'identifierField' => null,
                    'index' => [],
                ];
            return [
                'manifest' => $manifest,
                'chunks' => [],
                'validIdentifiers' => [],
                'itemHashes' => [],
                'chunkHashes' => [],
                'chunkMap' => [],
            ];
        }

        $identifierField = self::detectItemIdentifier($slotDef, $items[0]);
        $index = [];
        $validIdentifiers = [];
        $itemHashes = [];
        $chunkSize = self::getChunkSize();
        $hasChunks = count($items) >= $chunkSize;
        $chunksMeta = [];
        $chunkDataList = [];
        $chunkHashes = [];
        $chunkMap = [];
        $excludedManifestFields = self::getExcludedManifestFields($slotDef);

        foreach ($items as $i => $item) {
            $identifier = self::getItemIdentifier($item, $identifierField, $i);
            $baseIdentifier = $identifier;
            $counter = 1;
            while (in_array($identifier, $validIdentifiers, true)) {
                if ($counter === 1 && !empty($item['slug']) && is_string($item['slug']) && !in_array($item['slug'], $validIdentifiers, true)) {
                    $identifier = self::sanitizeForIdentifier($item['slug']);
                } elseif ($counter === 1 && !empty($item['id']) && (is_string($item['id']) || is_numeric($item['id'])) && !in_array((string)$item['id'], $validIdentifiers, true)) {
                    $identifier = self::sanitizeForIdentifier((string)$item['id']);
                } else {
                    $identifier = "{$baseIdentifier}-" . ($counter + 1);
                    $counter++;
                }
            }
            $validIdentifiers[] = $identifier;

            $parts = is_array($item)
                ? PublicPayloadService::split($slotKey, $item)
                : ['root' => [], 'locales' => null];

            $root = PublicPayloadService::stripReservedKeys($parts['root'], $slotKey, $identifier);
            $listEntry = self::buildListEntry($identifier, $root, $parts['locales'], $excludedManifestFields);
            $index[] = $listEntry;

            // Compute substantive content hash for incremental caching (excluding volatile generated_at)
            $itemHashes[$identifier] = MerkleService::hashPayload([
                'slug' => $identifier,
                'root' => $root,
                'locales' => $parts['locales'],
            ]);
        }

        if ($hasChunks) {
            $slotDir = self::$cacheDir !== null ? self::$cacheDir . self::sanitizeFilename($slotKey) . '/' : null;
            $oldMerkle = ($slotDir !== null && is_dir($slotDir)) ? MerkleService::loadSlotMerkleState($slotDir) : null;
            $oldChunkMap = is_array($oldMerkle['chunk_map'] ?? null) ? $oldMerkle['chunk_map'] : [];

            $chunkedEntries = self::partitionIntoStableChunks($index, $chunkSize, $oldChunkMap);
            foreach ($chunkedEntries as $chunkIndex => $chunkEntries) {
                $chunkFilename = "chunk_{$chunkIndex}.json";
                $chunkItemsMap = [];
                foreach ($chunkEntries as $cEntry) {
                    $slug = (string)($cEntry['slug'] ?? '');
                    $chunkMap[$slug] = $chunkIndex;
                    $chunkItemsMap[$slug] = $itemHashes[$slug] ?? $slug;
                }
                $chunkHashes[$chunkFilename] = MerkleService::hashChunk($chunkItemsMap);

                $chunkDataList[$chunkIndex] = [
                    'slot' => $slotKey,
                    'chunk' => $chunkIndex,
                    'generated_at' => $generatedAt,
                ]
                    + $languageMeta
                    + [
                        'identifierField' => 'slug',
                        'items' => $chunkEntries,
                    ];
                $chunksMeta[] = [
                    'index' => $chunkIndex,
                    'path' => $chunkFilename,
                    'count' => count($chunkEntries),
                ];
            }
        }

        $manifest = [
            'slot' => $slotKey,
            'type' => 'collection',
            'generated_at' => $generatedAt,
        ]
            + $languageMeta
            + [
                'itemCount' => count($items),
                'identifierField' => 'slug',
            ];

        if ($hasChunks) {
            $manifest['hasChunks'] = true;
            $manifest['chunkSize'] = $chunkSize;
            $manifest['chunks'] = $chunksMeta;
        } else {
            $manifest['index'] = $index;
        }

        return [
            'manifest' => $manifest,
            'chunks' => $chunkDataList,
            'validIdentifiers' => $validIdentifiers,
            'itemHashes' => $itemHashes,
            'chunkHashes' => $chunkHashes,
            'chunkMap' => $chunkMap,
        ];
    }

    /**
     * Build single item public payload for a collection item.
     */
    public static function buildSingleItemPayload(string $slotKey, array $item, string $identifier, ?string $onlyLang = null): array
    {
        $languageMeta = PublicPayloadService::envelopeLanguageMeta();
        $generatedAt = date('c');

        $parts = PublicPayloadService::split($slotKey, $item);
        $root = PublicPayloadService::stripReservedKeys($parts['root'], $slotKey, $identifier);

        $itemFile = [
            'slot' => $slotKey,
            'slug' => $identifier,
            'generated_at' => $generatedAt,
        ]
            + $languageMeta
            + $root;

        if ($parts['locales'] !== null) {
            $itemFile['locales'] = PublicPayloadService::narrowLocales($parts['locales'], $onlyLang);
        }

        return $itemFile;
    }

    private static function generateCollectionSlot(string $slotKey, mixed $data): bool
    {
        $slotDir = self::ensureSlotDirectory($slotKey);
        $slotDef = self::getSlotDefinition($slotKey);
        $items = is_array($data) ? array_values($data) : [];

        $payload = self::buildCollectionManifestPayload($slotKey, $items, $slotDef);
        $manifest = $payload['manifest'];
        $chunks = $payload['chunks'];
        $validIdentifiers = $payload['validIdentifiers'];
        $itemHashes = $payload['itemHashes'] ?? [];
        $chunkHashes = $payload['chunkHashes'] ?? [];
        $chunkMap = $payload['chunkMap'] ?? [];

        // Load existing Merkle state for incremental diffing
        $oldMerkle = MerkleService::loadSlotMerkleState($slotDir);
        $oldItemHashes = $oldMerkle['items'] ?? [];
        $oldChunkHashes = $oldMerkle['chunks'] ?? [];

        $diff = MerkleService::diffItemHashes($itemHashes, $oldItemHashes);

        $languageMeta = PublicPayloadService::envelopeLanguageMeta();
        $generatedAt = $manifest['generated_at'];

        $writtenItems = 0;
        $skippedItems = 0;

        foreach ($items as $i => $item) {
            $identifier = $validIdentifiers[$i] ?? (string)$i;
            $itemFilePath = $slotDir . $identifier . '.json';

            // Incremental write decision: write if created, modified, or missing on disk
            $needsWrite = in_array($identifier, $diff['modified'], true)
                || in_array($identifier, $diff['created'], true)
                || !is_file($itemFilePath);

            if (!$needsWrite) {
                $skippedItems++;
                continue;
            }

            $parts = is_array($item)
                ? PublicPayloadService::split($slotKey, $item)
                : ['root' => [], 'locales' => null];

            $root = PublicPayloadService::stripReservedKeys($parts['root'], $slotKey, $identifier);

            $itemFile = [
                'slot' => $slotKey,
                'slug' => $identifier,
                'generated_at' => $generatedAt,
            ]
                + $languageMeta
                + $root;

            if ($parts['locales'] !== null) {
                $itemFile['locales'] = $parts['locales'];
            }

            self::atomicWriteJson($itemFilePath, $itemFile);
            $writtenItems++;
        }

        // Chunks: only write if chunk hash changed or file missing
        $writtenChunks = 0;
        $skippedChunks = 0;

        foreach ($chunks as $chunkIndex => $chunkData) {
            $chunkFilename = "chunk_{$chunkIndex}.json";
            $chunkFilePath = $slotDir . $chunkFilename;
            $newChunkHash = $chunkHashes[$chunkFilename] ?? '';
            $oldChunkHash = $oldChunkHashes[$chunkFilename] ?? null;

            if ($oldChunkHash !== null && $oldChunkHash === $newChunkHash && is_file($chunkFilePath)) {
                $skippedChunks++;
                continue;
            }

            self::atomicWriteJson($chunkFilePath, $chunkData);
            $writtenChunks++;
        }

        // Write manifest.json
        $manifestHash = MerkleService::hashPayload($manifest);
        $manifestFilePath = $slotDir . 'manifest.json';
        $success = self::atomicWriteJson($manifestFilePath, $manifest);
        if (!$success) {
            return false;
        }

        // Calculate and persist Merkle tree state
        $slotRootHash = MerkleService::hashSlotRoot($slotKey, $chunkHashes, [
            'itemCount' => count($items),
            'manifestHash' => $manifestHash,
        ]);

        MerkleService::saveSlotMerkleState($slotDir, [
            'root' => $slotRootHash,
            'items' => $itemHashes,
            'chunks' => $chunkHashes,
            'chunk_map' => $chunkMap,
            'manifest' => $manifestHash,
        ]);

        self::cleanupOrphanedItems($slotKey, $validIdentifiers, count($chunks));

        error_log("[StaticCache] Generated collection slot: {$slotKey} ({$manifest['itemCount']} items: {$writtenItems} written, {$skippedItems} skipped; chunks: {$writtenChunks} written, {$skippedChunks} skipped)");
        return true;
    }

    /**
     * Determine fields to exclude from the collection manifest index / chunk listings.
     *
     * Rules:
     * 1. Any field with type === 'blocks' is strictly excluded (heavy Gutenberg builder content).
     * 2. Any field with excludeFromManifest === true is excluded (blacklist).
     *
     * @param array|null $slotDef
     * @return array<string, bool> Map of excluded field IDs for O(1) lookup
     */
    public static function getExcludedManifestFields(?array $slotDef): array
    {
        $excluded = [];

        if ($slotDef && isset($slotDef['fields']) && is_array($slotDef['fields'])) {
            foreach ($slotDef['fields'] as $key => $field) {
                if (!is_array($field)) {
                    continue;
                }
                $id = $field['id'] ?? (is_string($key) ? $key : null);
                if (!$id) {
                    continue;
                }

                $type = $field['type'] ?? 'text';
                $isBlacklisted = ($field['excludeFromManifest'] ?? false) === true;

                // Rule 1: 'blocks' is strictly isolated to /slug.json
                // Rule 2: Explicitly blacklisted field
                if ($type === 'blocks' || $isBlacklisted) {
                    $excluded[$id] = true;
                }
            }
        } else {
            // Schemaless fallback: exclude blocks / sections
            $excluded['blocks'] = true;
            $excluded['sections'] = true;
        }

        return $excluded;
    }

    /**
     * Build a listing entry from an already-split item for manifest.json and chunk files.
     *
     * All schema-defined fields and system metadata (created_at, updated_at, etc.)
     * are treated as metadata and included, EXCEPT:
     * - Fields of type 'blocks' (strictly isolated to individual {slug}.json)
     * - Fields explicitly blacklisted via `excludeFromManifest: true`
     *
     * @param string              $identifier
     * @param array               $root
     * @param array|null          $locales
     * @param array<string, bool> $excludedFields
     */
    public static function buildListEntry(string $identifier, array $root, ?array $locales, array $excludedFields = []): array
    {
        $entry = ['slug' => $identifier];

        // 1. Root fields
        foreach ($root as $field => $value) {
            if ($field === 'slug') {
                continue;
            }
            if (isset($excludedFields[$field])) {
                continue;
            }
            // If field is excluded, also exclude its relation embed key (_field) if present
            if (str_starts_with($field, '_') && isset($excludedFields[substr($field, 1)])) {
                continue;
            }
            $entry[$field] = $value;
        }

        if ($locales === null) {
            return $entry;
        }

        // 2. Localized fields
        $entryLocales = [];
        foreach ($locales as $lang => $fields) {
            if (!is_array($fields)) {
                continue;
            }
            $picked = [];
            foreach ($fields as $field => $value) {
                if (isset($excludedFields[$field])) {
                    continue;
                }
                if (str_starts_with($field, '_') && isset($excludedFields[substr($field, 1)])) {
                    continue;
                }
                $picked[$field] = $value;
            }
            if ($picked !== []) {
                $entryLocales[$lang] = $picked;
            }
        }

        if ($entryLocales !== []) {
            $entry['locales'] = $entryLocales;
        }

        return $entry;
    }
    
    // =========================================================================
    // FILE OPERATIONS
    // =========================================================================
    
    /**
     * Atomic write JSON to file
     */
    private static function atomicWriteJson(string $filepath, array $data): bool
    {
        $json = json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
        
        if ($json === false) {
            error_log("[StaticCache] JSON encode failed for: {$filepath}");
            return false;
        }
        
        $tempPath = $filepath . '.tmp.' . uniqid();
        
        if (file_put_contents($tempPath, $json) === false) {
            error_log("[StaticCache] Failed to write temp file: {$tempPath}");
            return false;
        }
        
        chmod($tempPath, 0644);
        
        if (!rename($tempPath, $filepath)) {
            @unlink($tempPath);
            error_log("[StaticCache] Failed to rename temp file to: {$filepath}");
            return false;
        }
        
        return true;
    }
    
    /**
     * Get chunk size from settings
     */
    public static function getChunkSize(): int
    {
        // For now, use default. Later can add to CacheSettingsService
        return self::DEFAULT_CHUNK_SIZE;
    }
    
    /**
     * Cleanup orphaned item files in a collection
     */
    private static function cleanupOrphanedItems(string $slotKey, array $validIdentifiers, int $validChunkCount): int
    {
        $slotDir = self::$cacheDir . self::sanitizeFilename($slotKey) . '/';
        
        if (!is_dir($slotDir)) {
            return 0;
        }
        
        $deleted = 0;
        $files = glob($slotDir . '*.json');
        
        foreach ($files as $file) {
            $basename = basename($file, '.json');
            
            // Skip manifest
            if ($basename === 'manifest') {
                continue;
            }
            
            // Check if chunk file
            if (preg_match('/^chunk_(\d+)$/', $basename, $matches)) {
                $chunkIndex = (int) $matches[1];
                if ($chunkIndex >= $validChunkCount) {
                    @unlink($file);
                    $deleted++;
                    error_log("[StaticCache] Cleaned up orphaned chunk: {$slotKey}/{$basename}.json");
                }
                continue;
            }
            
            // Item file - check if valid
            if (!in_array($basename, $validIdentifiers)) {
                @unlink($file);
                $deleted++;
                error_log("[StaticCache] Cleaned up orphaned item: {$slotKey}/{$basename}.json");
            }
        }
        
        return $deleted;
    }

    /**
     * Manifest-driven orphan sweep — a safety net independent of any generation
     * run.
     *
     * DELIBERATELY reads only `manifest.json`, never the database:
     *
     *   - No extra DB query, however many items the slot holds. A rebuild
     *     already reads the database once per slot to regenerate content; this
     *     runs alongside that for free by trusting the manifest it just wrote.
     *   - It also works when the manifest is trusted but a PAST run's cleanup
     *     was skipped (e.g. a rebuild that silently no-opped under lock
     *     contention, see rebuildAll()) — this is exactly the case that left a
     *     manually-unpublished item's JSON file on disk while the manifest had
     *     already stopped listing it.
     *
     * Safe to call while another generation is in progress: it only reads a
     * manifest and deletes files that are not referenced by it, it never writes
     * cache content itself, so it needs none of rebuildAll()'s locking.
     *
     * @param  string|null $onlySlot Limit the sweep to one slot; null = all
     *                               slot directories currently on disk.
     * @return array{deleted: int, scanned_slots: int, deleted_files: string[]}
     */
    public static function purgeOrphanedFiles(?string $onlySlot = null): array
    {
        self::init();

        $slotDirs = $onlySlot !== null
            ? [self::$cacheDir . self::sanitizeFilename($onlySlot) . '/']
            : glob(self::$cacheDir . '*', GLOB_ONLYDIR);

        $deleted = 0;
        $deletedFiles = [];
        $scanned = 0;

        foreach ($slotDirs as $slotDir) {
            $slotDir = rtrim((string) $slotDir, '/') . '/';
            $slotKey = basename($slotDir);
            $manifestPath = $slotDir . 'manifest.json';

            if (!is_file($manifestPath)) {
                // No manifest to trust: leave the directory alone rather than
                // guessing. An empty/never-generated slot is not an orphan case.
                continue;
            }

            $manifest = json_decode((string) file_get_contents($manifestPath), true);
            if (!is_array($manifest)) {
                continue;
            }

            $scanned++;

            // Valid item identifiers, per slot TYPE:
            //   collection -> manifest.index[].slug (the public identifier,
            //                 always named 'slug' since the envelope rewrite)
            //   object/list -> content lives inside manifest.json itself, so
            //                 no sibling item files are ever valid
            $validIdentifiers = [];
            if (($manifest['type'] ?? null) === 'list') {
                $validIdentifiers = array_column($manifest['items'] ?? [], 'uid');
            }
            if (($manifest['type'] ?? null) === 'collection') {
                if (!empty($manifest['hasChunks']) && !empty($manifest['chunks'])) {
                    // Chunked collection: manifest omits index to prevent duplication.
                    // Resolve valid identifiers from slot Merkle state or chunk files.
                    $merkleState = MerkleService::loadSlotMerkleState($slotDir);
                    if ($merkleState !== null && !empty($merkleState['items'])) {
                        $validIdentifiers = array_keys($merkleState['items']);
                    } else {
                        $chunkFilesList = [];
                        foreach ((array) ($manifest['chunks'] ?? []) as $chunk) {
                            if (is_array($chunk) && isset($chunk['path']) && is_string($chunk['path'])) {
                                $chunkFilesList[] = $chunk['path'];
                            }
                        }
                        foreach ($chunkFilesList as $chunkFile) {
                            $chunkFilePath = $slotDir . $chunkFile;
                            if (is_file($chunkFilePath)) {
                                $cJson = json_decode((string)file_get_contents($chunkFilePath), true);
                                if (is_array($cJson) && isset($cJson['items']) && is_array($cJson['items'])) {
                                    foreach ($cJson['items'] as $cEntry) {
                                        if (is_array($cEntry) && isset($cEntry['slug']) && is_string($cEntry['slug'])) {
                                            $validIdentifiers[] = $cEntry['slug'];
                                        }
                                    }
                                }
                            }
                        }
                    }
                } else {
                    foreach ((array) ($manifest['index'] ?? []) as $entry) {
                        if (is_array($entry) && isset($entry['slug']) && is_string($entry['slug'])) {
                            $validIdentifiers[] = $entry['slug'];
                        }
                    }
                }
            }

            $validChunkFiles = [];
            foreach ((array) ($manifest['chunks'] ?? []) as $chunk) {
                if (is_array($chunk) && isset($chunk['path']) && is_string($chunk['path'])) {
                    $validChunkFiles[] = $chunk['path'];
                }
            }

            foreach (glob($slotDir . '*.json') ?: [] as $file) {
                $basename = basename($file);

                if ($basename === 'manifest.json') {
                    continue;
                }
                if (in_array($basename, $validChunkFiles, true)) {
                    continue;
                }
                if (in_array(basename($file, '.json'), $validIdentifiers, true)) {
                    continue;
                }

                if (@unlink($file)) {
                    $deleted++;
                    $deletedFiles[] = "{$slotKey}/{$basename}";
                    error_log("[StaticCache] Purged orphaned file (manifest-driven): {$slotKey}/{$basename}");
                }
            }
        }

        return [
            'deleted' => $deleted,
            'scanned_slots' => $scanned,
            'deleted_files' => $deletedFiles,
        ];
    }
    
    // =========================================================================
    // GLOBAL MANIFEST
    // =========================================================================
    
    /**
     * Generate global manifest (_manifest.json)
     * Lists all slot directories and their paths
     */
    public static function generateManifest(): bool
    {
        self::init();
        
        $schema = self::loadSchema();
        $schemaSlots = $schema['slots'] ?? [];
        $slots = [];
        $excludedSlots = [];
        
        // Scan slot directories
        $dirs = glob(self::$cacheDir . '*', GLOB_ONLYDIR);
        
        foreach ($dirs as $dir) {
            $slotKey = basename($dir);
            $manifestPath = $dir . '/manifest.json';
            
            if (!is_file($manifestPath)) {
                continue;
            }

            // Keep this lightweight: avoid reading each manifest file on every save.
            // Types are sourced from schema, or default to object.
            $slotType = $schemaSlots[$slotKey]['type'] ?? 'object';
            if ($slotType === 'list' && !RelationService::isPublicList($slotKey, $schema)) {
                continue;
            }
            
            $slots[$slotKey] = [
                'type' => $slotType,
                'path' => $slotKey . '/manifest.json',
            ];
        }
        
        // Add excluded (internal-only) slots: massive (API-only) and list
        // (relation-target only, never served on its own — see generateForSlot).
        if ($schema && isset($schema['slots'])) {
            foreach ($schema['slots'] as $key => $slotDef) {
                $type = $slotDef['type'] ?? 'object';
                if ($type === 'massive') {
                    $excludedSlots[$key] = [
                        'type' => 'massive',
                        'reason' => 'API-only',
                    ];
                } elseif ($type === 'list' && !RelationService::isPublicList($key, $schema)) {
                    $excludedSlots[$key] = [
                        'type' => 'list',
                        'reason' => 'internal-only (relation target)',
                    ];
                }
            }
        }
        
        $globalManifest = [
            'version' => 2,
            'generated_at' => date('c'),
            'slots' => $slots,
            'excludedSlots' => $excludedSlots,
        ];
        
        $filepath = self::$cacheDir . '_manifest.json';
        $success = self::atomicWriteJson($filepath, $globalManifest);
        
        if ($success) {
            error_log("[StaticCache] Generated global manifest with " . count($slots) . " slots");
        }
        
        return $success;
    }

    /**
     * Check if there is enough request execution budget left.
     */
    private static function hasExecutionBudget(float $minRemainingSeconds): bool
    {
        $maxExecutionTime = (int) ini_get('max_execution_time');

        // 0 means unlimited execution time.
        if ($maxExecutionTime === 0) {
            return true;
        }

        $requestStart = $_SERVER['REQUEST_TIME_FLOAT'] ?? microtime(true);
        $elapsed = microtime(true) - $requestStart;
        $remaining = $maxExecutionTime - $elapsed;

        return $remaining >= $minRemainingSeconds;
    }
    
    // =========================================================================
    // REBUILD & INVALIDATION
    // =========================================================================
    
    /**
     * Rebuild all static cache
    /**
     * Rebuild all static cache
     *
     * BUGFIX (2026-08-28): the lock acquisition used to be non-blocking
     * (LOCK_EX | LOCK_NB) with a SILENT bail-out (`skipped: true`) whenever
     * another regeneration briefly held the lock. The caller (admin UI) had no
     * way to tell that result apart from "ran and found nothing to do", so a
     * rebuild could report success while touching zero files — the exact
     * symptom that made a manually unpublished item's stale JSON survive a
     * rebuild. This now waits a bounded amount of time for the lock (mirroring
     * forceRegenerateMetaFiles()) and, if it still cannot acquire it, returns an
     * explicit failure the caller must surface rather than a look-alike success.
     */
    public static function rebuildAll(int $concurrency = 1): array
    {
        self::init();
        $concurrency = max(1, min(4, $concurrency));
        
        // File-based lock to prevent concurrent rebuilds
        $lockFile = self::$cacheDir . '.rebuild.lock';
        $lockHandle = fopen($lockFile, 'c');
        
        if ($lockHandle === false) {
            return ['count' => 0, 'errors' => 1, 'slots' => [], 'locked' => false];
        }

        $maxWaitSeconds = 10;
        $waitedSeconds = 0.0;
        $lockAcquired = false;

        while ($waitedSeconds < $maxWaitSeconds) {
            if (flock($lockHandle, LOCK_EX | LOCK_NB)) {
                $lockAcquired = true;
                break;
            }
            usleep(200000);
            $waitedSeconds += 0.2;
        }

        if (!$lockAcquired) {
            fclose($lockHandle);
            // Explicit failure: no slot was touched. Distinguishable from a
            // normal result by both `locked: true` and the absence of `count`.
            return [
                'count' => 0,
                'errors' => 1,
                'slots' => [],
                'locked' => true,
                'message' => 'Another cache rebuild is already running. Please retry shortly.',
            ];
        }
        
        self::$forceSynchronousGeneration = true;

        try {
            // Clear old structure first
            self::clearLegacyFiles();
            
            $slots = ContentDatabase::getAllSlots();
            $schema = self::loadSchema();
            $count = 0;
            $errors = 0;
            $processed = [];
            $purged = 0;

            // Multi-process execution if concurrency > 1 and in CLI
            if ($concurrency > 1 && PHP_SAPI === 'cli' && function_exists('proc_open') && count($slots) > 1) {
                $bootstrapPath = dirname(__DIR__, 2) . '/bootstrap.php';
                $chunks = array_chunk($slots, (int)ceil(count($slots) / $concurrency));
                $processes = [];
                $pipesList = [];

                foreach ($chunks as $cIdx => $slotChunk) {
                    $keys = array_column($slotChunk, 'key');
                    $keysJson = escapeshellarg(json_encode($keys));
                    $phpCode = "require '{$bootstrapPath}'; \$keys = json_decode({$keysJson}, true); foreach (\$keys as \$k) { \$d = \\NomadCMS\\Database\\CollectionDatabase::isRegistered(\$k) ? null : \\NomadCMS\\Database\\ContentDatabase::getSlot(\$k); \\NomadCMS\\Services\\StaticCacheService::generateForSlot(\$k, \$d, null, true); }";
                    $cmd = [PHP_BINARY, '-r', $phpCode];

                    $descriptors = [
                        0 => ['pipe', 'r'],
                        1 => ['pipe', 'w'],
                        2 => ['pipe', 'w'],
                    ];
                    $proc = @proc_open($cmd, $descriptors, $pipes);
                    if (is_resource($proc)) {
                        $processes[$cIdx] = $proc;
                        $pipesList[$cIdx] = $pipes;
                    }
                }

                // Wait for all workers to finish
                foreach ($processes as $cIdx => $proc) {
                    if (isset($pipesList[$cIdx][0])) fclose($pipesList[$cIdx][0]);
                    if (isset($pipesList[$cIdx][1])) stream_get_contents($pipesList[$cIdx][1]);
                    if (isset($pipesList[$cIdx][2])) stream_get_contents($pipesList[$cIdx][2]);
                    if (isset($pipesList[$cIdx][1])) fclose($pipesList[$cIdx][1]);
                    if (isset($pipesList[$cIdx][2])) fclose($pipesList[$cIdx][2]);
                    proc_close($proc);
                }

                foreach ($slots as $slot) {
                    $key = $slot['key'];
                    $count++;
                    $processed[] = $key;
                    $purged += self::purgeOrphanedFiles($key)['deleted'];
                }
            } else {
                foreach ($slots as $slot) {
                    $key = $slot['key'];
                    $slotType = $schema['slots'][$key]['type'] ?? 'object';
                    
                    try {
                        $data = \NomadCMS\Database\CollectionDatabase::isRegistered($key) ? null : ContentDatabase::getSlot($key);
                        
                        if (self::generateForSlot($key, $data, $slotType, true)) {
                            $count++;
                            $processed[] = $key;
                        }

                        $purged += self::purgeOrphanedFiles($key)['deleted'];
                    } catch (\Exception $e) {
                        error_log("[StaticCache] Rebuild error for {$key}: " . $e->getMessage());
                        $errors++;
                    }
                }
            }
            
            // Generate global manifest
            self::generateManifest();

            // A full rebuild regenerates every slot manifest and the global
            // manifest synchronously, so any deferred regeneration the dirty
            // flag was tracking is now definitively done. Clear it, otherwise
            // getPendingStatus() keeps reporting "Cache Pending" forever even
            // though there is nothing left to regenerate.
            $dirtyFlagPath = self::$cacheDir . '.manifest_dirty';
            if (is_file($dirtyFlagPath)) {
                @unlink($dirtyFlagPath);
                clearstatcache(true, $dirtyFlagPath);
            }

            \NomadCMS\Services\SitemapService::markDirty();
            return [
                'count' => $count,
                'errors' => $errors,
                'slots' => $processed,
                'purged' => $purged,
                'locked' => false,
                'concurrency' => $concurrency,
            ];
        } finally {
            self::$forceSynchronousGeneration = false;
            flock($lockHandle, LOCK_UN);
            fclose($lockHandle);
            @unlink($lockFile);
        }
    }
    
    /**
     * Clear legacy flat files (from old system)
     */
    private static function clearLegacyFiles(): void
    {
        // Remove old flat JSON files (not in directories)
        $files = glob(self::$cacheDir . '*.json');
        
        foreach ($files as $file) {
            $basename = basename($file);
            
            // Keep global manifest
            if ($basename === '_manifest.json') {
                continue;
            }
            
            // Remove old bundle files
            if (str_starts_with($basename, '_bundle')) {
                @unlink($file);
                continue;
            }
            
            // Remove old flat slot files
            @unlink($file);
        }
        
        // Remove old etag files
        $etagFiles = glob(self::$cacheDir . '*.etag');
        foreach ($etagFiles as $file) {
            @unlink($file);
        }
    }
    
    /**
     * Invalidate cache for a slot
     */
    public static function invalidateSlot(string $key): bool
    {
        self::init();

        self::removeSlotCacheDirectory($key);

        error_log("[StaticCache] Invalidated cache for slot: {$key}");
        
        self::regenerateMetaFilesDebounced();

        // Ensure sitemap/llms caches are also marked dirty. Without this,
        // code paths that call invalidateSlot() directly (e.g. the DELETE
        // handler in data.php) could leave the sitemap stale if the
        // companion deleteSlot() markDirty() was skipped or raced.
        \NomadCMS\Services\SitemapService::markDirty();
        
        return true;
    }

    /** A guarded row-backed cache stays unreadable until a matching revision is published. */
    public static function markCollectionDirty(string $key): void
    {
        self::init();
        $slotDir=self::ensureSlotDirectory($key);
        @unlink($slotDir.'.collection_revision');
        \NomadCMS\Database\CollectionDatabase::enqueue($key);
        \NomadCMS\Services\SitemapService::markDirty();
    }

    /** Build changed documents only, with SQL-backed chunk membership and revision-checked publication. */
    public static function rebuildRowCollection(string $key): bool
    {
        $db=ContentDatabase::getInstance();
        if ($db->inTransaction()) throw new \LogicException('Collection cache publication must run after commit');
        $state=\NomadCMS\Database\CollectionDatabase::state($key);
        if (!$state) return false;
        $revision=(int)$state['revision']; $definition=json_decode($state['schema_json'],true);
        $slotDir=self::ensureSlotDirectory($key);
        $stage=sys_get_temp_dir().'/nomad-collection-'.bin2hex(random_bytes(12));
        if (!mkdir($stage,0700)) throw new \RuntimeException('Cannot stage collection cache');
        $records=fopen($stage.'/entries.ndjson','w+b');
        $published=false;
        $cursor=''; $generatedAt=gmdate('c'); $ordinal=0;
        try {
            do {
                $s=$db->prepare('SELECT item_uid FROM collection_dirty_items WHERE slot_key=? AND item_uid>? ORDER BY item_uid LIMIT 100');
                $s->execute([$key,$cursor]); $uids=$s->fetchAll(PDO::FETCH_COLUMN); $s->closeCursor();
                foreach ($uids as $uid) {
                    $cursor=$uid; $row=\NomadCMS\Database\CollectionDatabase::row($key,$uid);
                    $item=$row ? \NomadCMS\Database\CollectionDatabase::getItem($key,$uid) : null;
                    $record=['uid'=>$uid,'remove'=>!$item || !PublicPayloadService::isItemPublished($definition,$item)];
                    if (!$record['remove']) {
                        $item=RelationService::projectForPublic($key,$item);
                        $identifier=self::getItemIdentifier($item,self::detectItemIdentifier($definition,$item),(int)$row['row_id']);
                        $parts=PublicPayloadService::split($key,$item);
                        $root=PublicPayloadService::stripReservedKeys($parts['root'],$key,$identifier);
                        $entry=self::buildListEntry($identifier,$root,$parts['locales'],self::getExcludedManifestFields($definition));
                        $payload=self::buildSingleItemPayload($key,$item,$identifier);
                        $record+=['identifier'=>$identifier,'entry'=>$entry,'hash'=>MerkleService::hashPayload(['root'=>$root,'locales'=>$parts['locales']]),'file'=>(string)$ordinal++];
                        file_put_contents($stage.'/'.$record['file'],json_encode($payload,JSON_THROW_ON_ERROR|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES));
                    }
                    fwrite($records,json_encode($record,JSON_THROW_ON_ERROR|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)."\n");
                }
            } while (count($uids)===100);
            rewind($records);
            $published=\NomadCMS\Database\CollectionDatabase::transaction(function() use($db,$key,$state,$revision,$records,$stage,$slotDir,$definition,$generatedAt) {
                $current=\NomadCMS\Database\CollectionDatabase::state($key);
                if ((int)$current['revision']!==$revision || $current['schema_hash']!==$state['schema_hash']) return false;
                @unlink($slotDir.'.collection_revision');
                $chunkSize=self::getChunkSize();
                while (($line=fgets($records))!==false) {
                    $record=json_decode($line,true,512,JSON_THROW_ON_ERROR); $uid=$record['uid'];
                    $s=$db->prepare('SELECT * FROM collection_cache_entries WHERE slot_key=? AND item_uid=?'); $s->execute([$key,$uid]); $old=$s->fetch();
                    $raw=\NomadCMS\Database\CollectionDatabase::getItem($key,$uid);
                    if ($raw) {
                        \NomadCMS\Database\CollectionDatabase::reindexDerived($key,$uid,$raw);
                        \NomadCMS\Database\CollectionDatabase::refreshPublicMetadata($key,$uid,$raw);
                    }
                    if ($record['remove']) {
                        if ($old) @unlink($slotDir.$old['identifier'].'.json');
                        $db->prepare('DELETE FROM collection_cache_entries WHERE slot_key=? AND item_uid=?')->execute([$key,$uid]);
                        continue;
                    }
                    $identifier=$record['identifier'];
                    $s=$db->prepare('SELECT item_uid FROM collection_cache_entries WHERE slot_key=? AND identifier=? AND item_uid<>?'); $s->execute([$key,$identifier,$uid]);
                    if ($s->fetchColumn()) throw new \RuntimeException('Ambiguous public collection identifier: '.$identifier);
                    if ($old && $old['identifier']!==$identifier) @unlink($slotDir.$old['identifier'].'.json');
                    if (!$old || $old['item_hash']!==$record['hash'] || !is_file($slotDir.$identifier.'.json')) {
                        // Atomic JSON output rewrites only this document.
                        $payload=json_decode(file_get_contents($stage.'/'.$record['file']),true,512,JSON_THROW_ON_ERROR);
                        self::atomicWriteJson($slotDir.$identifier.'.json',$payload);
                    }
                    $s=$db->prepare('SELECT COALESCE(MAX(chunk_id),0) FROM collection_cache_entries WHERE slot_key=?'); $s->execute([$key]); $chunk=(int)$s->fetchColumn();
                    $itemRow=\NomadCMS\Database\CollectionDatabase::row($key,$uid);
                    $chunk=(int)floor((int)$itemRow['position']/1024/$chunkSize);
                    $db->prepare('INSERT INTO collection_cache_entries VALUES (?,?,?,?,?,?) ON CONFLICT(slot_key,item_uid) DO UPDATE SET identifier=excluded.identifier,chunk_id=excluded.chunk_id,entry_json=excluded.entry_json,item_hash=excluded.item_hash')->execute([$key,$uid,$identifier,$chunk,json_encode($record['entry'],JSON_THROW_ON_ERROR|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),$record['hash']]);

                }
                $s=$db->prepare('SELECT DISTINCT chunk_id FROM collection_cache_entries WHERE slot_key=? ORDER BY chunk_id'); $s->execute([$key]); $chunkIds=$s->fetchAll(PDO::FETCH_COLUMN);
                $chunks=[]; $hashes=[]; $count=0; $small=[];
                $oldMerkle=MerkleService::loadSlotMerkleState($slotDir);
                foreach ($chunkIds as $chunk) {
                    $s=$db->prepare('SELECT c.entry_json FROM collection_cache_entries c JOIN collection_items i ON i.slot_key=c.slot_key AND i.item_uid=c.item_uid WHERE c.slot_key=? AND c.chunk_id=? ORDER BY i.position,i.row_id'); $s->execute([$key,$chunk]);
                    $entries=[]; while ($row=$s->fetch()) $entries[]=json_decode($row['entry_json'],true);
                    $count+=count($entries); if (count($chunkIds)===1) $small=$entries;
                    $filename='chunk_'.$chunk.'.json'; $hashes[$filename]=MerkleService::hashPayload($entries);
                    if (($oldMerkle['chunks'][$filename]??null)!==$hashes[$filename] || !is_file($slotDir.$filename)) self::atomicWriteJson($slotDir.$filename,['slot'=>$key,'chunk'=>(int)$chunk,'generated_at'=>$generatedAt]+PublicPayloadService::envelopeLanguageMeta()+['identifierField'=>'slug','items'=>$entries]);
                    $chunks[]=['index'=>(int)$chunk,'path'=>$filename,'count'=>count($entries)];
                }
                $manifest=['slot'=>$key,'type'=>'collection','generated_at'=>$generatedAt]+PublicPayloadService::envelopeLanguageMeta()+['itemCount'=>$count,'identifierField'=>'slug'];
                if ($count<$chunkSize) {
                    $small=[];
                    $s=$db->prepare('SELECT c.entry_json FROM collection_cache_entries c JOIN collection_items i ON i.slot_key=c.slot_key AND i.item_uid=c.item_uid WHERE c.slot_key=? ORDER BY i.position,i.row_id LIMIT '.$chunkSize); $s->execute([$key]);
                    while ($entry=$s->fetchColumn()) $small[]=json_decode($entry,true);
                    $manifest['index']=$small;
                }
                else $manifest+=['hasChunks'=>true,'chunkSize'=>$chunkSize,'chunks'=>$chunks];
                foreach (array_keys($oldMerkle['chunks']??[]) as $filename) if (!isset($hashes[$filename])&&preg_match('/^chunk_[0-9]+\.json$/',$filename)) @unlink($slotDir.$filename);
                self::atomicWriteJson($slotDir.'manifest.json',$manifest);
                self::atomicWriteJson($slotDir.'.merkle.json',['root'=>MerkleService::hashSlotRoot($key,$hashes,['itemCount'=>$count]),'chunks'=>$hashes]);
                $db->prepare('DELETE FROM collection_dirty_items WHERE slot_key=?')->execute([$key]);
                $db->prepare('DELETE FROM collection_jobs WHERE slot_key=? AND revision=?')->execute([$key,$revision]);
                // The marker is written after committing below, so a failed SQL commit cannot expose cache.
                return true;
            });
            return $published;
        } finally {
            fclose($records);
            foreach (glob($stage.'/*')?:[] as $file) @unlink($file);
            @rmdir($stage);
            $current=\NomadCMS\Database\CollectionDatabase::state($key);
            $s=$db->prepare('SELECT 1 FROM collection_jobs WHERE slot_key=?'); $s->execute([$key]);
            if ($published && $current && (int)$current['revision']===$revision && !$s->fetchColumn()) self::atomicWriteJson($slotDir.'.collection_revision',['revision'=>$revision,'schema_revision'=>$current['schema_hash']]);
        }
    }

    /**
     * Delete a slot's entire cache directory, if it exists.
     *
     * Shared by invalidateSlot() (public API, also debounces the global
     * manifest) and the list-type skip in generateForSlot() (internal use,
     * must NOT trigger a debounce cycle from inside a generation call).
     */
    private static function removeSlotCacheDirectory(string $key): void
    {
        self::init();

        $slotDir = self::$cacheDir . self::sanitizeFilename($key) . '/';

        if (!is_dir($slotDir)) {
            return;
        }

        foreach (glob($slotDir . '*') ?: [] as $file) {
            if (is_file($file)) {
                @unlink($file);
            }
        }

        @rmdir($slotDir);
    }
    
    /**
     * Get cache path for a slot (directory)
     */
    public static function getCachePath(string $key): ?string
    {
        self::init();
        
        $slotDir = self::$cacheDir . self::sanitizeFilename($key) . '/';
        
        return is_dir($slotDir) ? $slotDir : null;
    }
    
    // =========================================================================
    // STATISTICS
    // =========================================================================
    
    /**
     * Get cache statistics
     */
    public static function getStats(): array
    {
        self::init();
        
        $totalFiles = 0;
        $totalSize = 0;
        $slotCount = 0;
        
        // Count slot directories
        $dirs = glob(self::$cacheDir . '*', GLOB_ONLYDIR);
        $slotCount = count($dirs);
        
        // Count files and sizes
        foreach ($dirs as $dir) {
            $files = glob($dir . '/*.json');
            $totalFiles += count($files);
            
            foreach ($files as $file) {
                $totalSize += filesize($file);
            }
        }
        
        // Add global manifest
        if (file_exists(self::$cacheDir . '_manifest.json')) {
            $totalFiles++;
            $totalSize += filesize(self::$cacheDir . '_manifest.json');
        }
        
        return [
            'total_files' => $totalFiles,
            'total_size' => $totalSize,
            'total_size_human' => self::formatBytes($totalSize),
            'slot_count' => $slotCount,
        ];
    }
    
    /**
     * Format bytes to human readable string
     */
    private static function formatBytes(int $bytes): string
    {
        if ($bytes === 0) return '0 B';
        
        $units = ['B', 'KB', 'MB', 'GB'];
        $i = floor(log($bytes, 1024));
        
        return round($bytes / pow(1024, $i), 2) . ' ' . $units[$i];
    }
    
    /**
     * Clear all cache
     */
    public static function clearAll(): int
    {
        self::init();
        
        $count = 0;
        
        // Helper function to recursively delete directory contents
        $deleteDir = function(string $dir) use (&$deleteDir, &$count): void {
            if (!is_dir($dir)) {
                return;
            }
            
            $items = scandir($dir);
            foreach ($items as $item) {
                if ($item === '.' || $item === '..') {
                    continue;
                }
                
                $path = $dir . '/' . $item;
                
                if (is_dir($path)) {
                    $deleteDir($path);
                    @rmdir($path);
                } else {
                    @unlink($path);
                    $count++;
                }
            }
        };
        
        // Delete all slot directories recursively
        $dirs = glob(self::$cacheDir . '*', GLOB_ONLYDIR);
        foreach ($dirs as $dir) {
            $deleteDir($dir);
            @rmdir($dir);
        }
        
        // Delete global manifest
        if (file_exists(self::$cacheDir . '_manifest.json')) {
            @unlink(self::$cacheDir . '_manifest.json');
            $count++;
        }
        
        // Delete any remaining files in root (legacy, lock files, etc)
        $files = glob(self::$cacheDir . '*');
        foreach ($files as $file) {
            if (is_file($file)) {
                @unlink($file);
                $count++;
            }
        }
        
        error_log("[StaticCache] Cleared all cache: {$count} files deleted");
        
        \NomadCMS\Services\SitemapService::markDirty();
        
        return $count;
    }
    
    // =========================================================================
    // META REGENERATION (Debounced)
    // =========================================================================
    
    /**
     * Regenerate global manifest
     */
    public static function regenerateMetaFiles(): bool
    {
        if (!self::isEnabled()) {
            return false;
        }
        
        try {
            return self::generateManifest();
        } catch (\Exception $e) {
            error_log("[StaticCache] Failed to regenerate meta files: " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Regenerate meta files with debouncing
     * 
     * BUGFIX (2026-05-23): Added max retry limit to tail recovery to prevent
     * infinite recursion when .manifest_dirty flag persists (e.g. from concurrent
     * writes or failed unlink). Previously this caused 30+ second timeouts.
     */
    private static int $tailRetryCount = 0;
    private const MAX_TAIL_RETRIES = 2;
    
    public static function regenerateMetaFilesDebounced(): bool
    {
        $debounceSeconds = CacheSettingsService::getInstance()->getDebounceSeconds();
        self::init();
        
        $dirtyFlagPath = self::$cacheDir . '.manifest_dirty';
        $lockFile = self::$cacheDir . '.regen_lock';
        $now = time();

        // If request is near timeout, defer manifest regeneration.
        if (!self::hasExecutionBudget(3.0)) {
            touch($dirtyFlagPath);
            return false;
        }
        
        // Check shared timestamp
        if (file_exists($lockFile)) {
            $lastRun = filemtime($lockFile);
            
            if ($lastRun !== false && ($now - $lastRun) < $debounceSeconds) {
                touch($dirtyFlagPath);
                return false;
            }
        }
        
        // Acquire exclusive lock
        $lockHandle = fopen($lockFile, 'c');
        if ($lockHandle === false) {
            touch($dirtyFlagPath);
            return false;
        }
        
        if (!flock($lockHandle, LOCK_EX | LOCK_NB)) {
            fclose($lockHandle);
            touch($dirtyFlagPath);
            return false;
        }
        
        try {
            // Double-check timestamp
            clearstatcache(true, $lockFile);
            $lastRun = filemtime($lockFile);
            if ($lastRun !== false && ($now - $lastRun) < $debounceSeconds) {
                touch($dirtyFlagPath);
                return false;
            }
            
            touch($lockFile);
            
            self::$lastMetaRegenTime = microtime(true);
            
            $result = self::regenerateMetaFiles();
            
            // Always clean up dirty flag after successful regeneration
            if ($result) {
                @unlink($dirtyFlagPath);
                clearstatcache(true, $dirtyFlagPath);
            }
            
            // Tail recovery - retry if dirty flag was re-created during regen
            // Limited to MAX_TAIL_RETRIES to prevent infinite recursion
            if (
                $result
                && file_exists($dirtyFlagPath)
                && self::$tailRetryCount < self::MAX_TAIL_RETRIES
                && self::hasExecutionBudget(8.0)
            ) {
                $executionTime = microtime(true) - ($_SERVER["REQUEST_TIME_FLOAT"] ?? microtime(true));
                
                if ($executionTime < 20) {
                    self::$tailRetryCount++;
                    usleep(500000);
                    
                    // Release lock before recursive call so it can re-acquire
                    flock($lockHandle, LOCK_UN);
                    fclose($lockHandle);
                    $lockHandle = null;
                    
                    $retryResult = self::regenerateMetaFilesDebounced();
                    self::$tailRetryCount = 0; // Reset after completion
                    return $retryResult;
                }
            }
            
            self::$tailRetryCount = 0; // Reset on normal completion
            return $result;
        } finally {
            if ($lockHandle !== null) {
                flock($lockHandle, LOCK_UN);
                fclose($lockHandle);
            }
        }
    }
    
    /**
     * Force meta regeneration
     */
    public static function forceRegenerateMetaFiles(): bool
    {
        self::init();
        
        $lockFile = self::$cacheDir . '.regen_lock';
        $lockHandle = fopen($lockFile, 'c');
        
        if ($lockHandle === false) {
            return false;
        }
        
        $maxWaitSeconds = 30;
        $waitedSeconds = 0;
        $lockAcquired = false;
        
        while ($waitedSeconds < $maxWaitSeconds) {
            if (flock($lockHandle, LOCK_EX | LOCK_NB)) {
                $lockAcquired = true;
                break;
            }
            usleep(100000);
            $waitedSeconds += 0.1;
        }
        
        if (!$lockAcquired) {
            fclose($lockHandle);
            return false;
        }
        
        try {
            touch($lockFile);
            self::$lastMetaRegenTime = microtime(true);
            
            $dirtyFlagPath = self::$cacheDir . '.manifest_dirty';
            @unlink($dirtyFlagPath);
            
            return self::regenerateMetaFiles();
        } finally {
            flock($lockHandle, LOCK_UN);
            fclose($lockHandle);
        }
    }
    
    /**
     * Process dirty flag
     */
    public static function processDirtyFlag(): bool
    {
        self::init();
        $dirtyFlagPath = self::$cacheDir . '.manifest_dirty';
        
        if (!file_exists($dirtyFlagPath)) {
            return false;
        }
        
        return self::regenerateMetaFilesDebounced();
    }

    /**
     * Get pending status for deferred manifest regeneration.
     */
    public static function getPendingStatus(): array
    {
        self::init();

        $dirtyFlagPath = self::$cacheDir . '.manifest_dirty';
        $lockFile = self::$cacheDir . '.regen_lock';

        $isPending = is_file($dirtyFlagPath);
        $isRegenerating = false;

        if (is_file($lockFile)) {
            $lockHandle = @fopen($lockFile, 'c');
            if ($lockHandle !== false) {
                // If non-blocking exclusive lock fails, another process is regenerating.
                if (!flock($lockHandle, LOCK_EX | LOCK_NB)) {
                    $isRegenerating = true;
                } else {
                    flock($lockHandle, LOCK_UN);
                }
                fclose($lockHandle);
            }
        }

        $pendingSince = null;
        if ($isPending) {
            $mtime = @filemtime($dirtyFlagPath);
            if ($mtime !== false) {
                $pendingSince = date('c', $mtime);
            }
        }

        return [
            'isPending' => $isPending,
            'isRegenerating' => $isRegenerating,
            'pendingSince' => $pendingSince,
            'dirtyFlagPath' => $dirtyFlagPath,
        ];
    }
}
