<?php
/**
 * NOMAD CMS — Optional social media delivery fallback.
 * Retries only confirmed media validation failures, once, using the same text/context.
 * Never fetches attachments and never retries ambiguous network errors or accepted messages.
 */
declare(strict_types=1);

namespace NomadCMS\Services;

final class SocialAlertDelivery
{
    /** The caller retains signing, SSRF controls, delivery identity and the total time budget. */
    public static function send(array $body, string $shape, callable $transport, ?float $deadline = null): array
    {
        $result = $transport($body);
        if (!in_array($shape, SocialAlertFormatter::SHAPES, true)
            || !empty($result['success'])
            || !in_array((int) ($result['status_code'] ?? 0), [400, 422], true)
            || ($deadline !== null && microtime(true) >= $deadline)) {
            return $result;
        }
        $error = strtolower((string) ($result['response_body'] ?? '') . ' ' . (string) ($result['error'] ?? ''));
        if (!preg_match('/image|photo|thumbnail|preview|invalid_blocks|invalid_url|failed.*url|url.*failed/', $error)) {
            return $result;
        }
        $fallback = self::withoutMedia($body, $shape);
        return $fallback === $body ? $result : $transport($fallback);
    }

    /** Keep the actual notification; remove only optional visual/link structures. */
    public static function withoutMedia(array $body, string $shape): array
    {
        if ($shape === 'social_discord') {
            foreach ($body['embeds'] ?? [] as $index => $embed) {
                unset($embed['image'], $embed['thumbnail'], $embed['url']);
                $body['embeds'][$index] = $embed;
            }
        } elseif ($shape === 'social_slack') {
            $body['blocks'] = array_values(array_filter($body['blocks'] ?? [], static fn (array $block): bool =>
                !in_array($block['type'] ?? '', ['image', 'actions'], true)
            ));
        } elseif ($shape === 'social_telegram') {
            $body['link_preview_options'] = ['is_disabled' => true];
        }
        return $body;
    }
}
