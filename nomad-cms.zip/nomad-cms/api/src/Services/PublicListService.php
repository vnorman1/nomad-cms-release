<?php
/**
 * NOMAD CMS — Opt-in public list delivery.
 * Shares payloads with static list manifests and UID-addressed documents.
 * Publication is checked before projection; lists remain small JSON-backed taxonomies.
 */
declare(strict_types=1);

namespace NomadCMS\Services;

use NomadCMS\Database\ContentDatabase;
use NomadCMS\Services\Schema\SchemaProvider;

final class PublicListService
{
    public static function read(string $key, ?string $uid = null, ?string $lang = null): array
    {
        SchemaProvider::lease($key);
        if (!RelationService::isPublicList($key)) {
            throw new \OutOfBoundsException('Content not publicly available');
        }
        $items = PublicPayloadService::filterPublished($key, ContentDatabase::getSlot($key) ?? []);
        if ($uid !== null) {
            $items = array_values(array_filter($items, static fn ($item) => RelationService::uidOf($item) === $uid));
            if ($items === []) {
                throw new \OutOfBoundsException('Content not found');
            }
        }
        $projected = RelationService::projectForPublic($key, $items);
        return ['success' => true, 'exists' => true, 'slot' => $key,
            'data' => self::payload($key, $uid === null ? $projected : $projected[0], $lang, $uid !== null)];
    }

    /** Input has already passed publication and relation projection. */
    public static function payload(string $key, array $data, ?string $lang = null, bool $single = false): array
    {
        $meta = ['slot' => $key, 'type' => 'list', 'generated_at' => gmdate('c')]
            + PublicPayloadService::envelopeLanguageMeta();
        if ($single) {
            return $meta + PublicPayloadService::merge(PublicPayloadService::split($key, $data), $lang);
        }
        $items = [];
        foreach ($data as $item) {
            if (is_array($item) && isset($item['uid'])) {
                $items[] = PublicPayloadService::merge(PublicPayloadService::split($key, $item), $lang);
            }
        }
        return $meta + ['itemCount' => count($items), 'identifierField' => 'uid', 'items' => $items];
    }
}
