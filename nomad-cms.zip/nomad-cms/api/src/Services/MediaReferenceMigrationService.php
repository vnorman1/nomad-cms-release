<?php
/**
 * NOMAD CMS — media reference migration across content and massive databases.
 * Rewrites current references through versioned collection/slot APIs, preserving blocks,
 * concurrency checks, encryption and search indexes. Historical payloads stay signed and intact.
 */
declare(strict_types=1);

namespace NomadCMS\Services;

use Generator;
use NomadCMS\Database\CollectionDatabase;
use NomadCMS\Database\ContentDatabase;
use NomadCMS\Database\MassiveEncryption;
use NomadCMS\Database\OptimisticLockException;
use NomadCMS\Security\BlindIndexService;
use NomadCMS\Security\EncryptionService;
use NomadCMS\Services\EditorialsHub\HubConfig;
use NomadCMS\Services\EditorialsHub\Persistence\ItemRepository;
use PDO;
use PDOStatement;
use RuntimeException;

/** Performs reference changes within the caller's transaction, including an attached massive.sqlite. */
final class MediaReferenceMigrationService
{
    private array $changedSlots = [];
    private array $hubStatements = [];
    private bool $hubHasTiles = false;

    private function __construct(
        private readonly PDO $db,
        private readonly MediaReferenceRewriter $rewriter,
        private readonly string $actor
    ) {
    }

    public static function attachMassive(PDO $db, ?string $path = null): bool
    {
        $path ??= dirname(__DIR__, 2) . '/databases/' . ($_ENV['DB_MASSIVE_DATABASE'] ?? 'massive.sqlite');
        if ($path === '' || !file_exists($path)) {
            return false;
        }
        if (!is_file($path) || !is_readable($path)) {
            throw new RuntimeException('The massive database is unavailable.');
        }
        $db->prepare('ATTACH DATABASE ? AS studio_massive')->execute([$path]);
        return true;
    }

    private static function hasTable(PDO $db, string $table, string $schema = 'main'): bool
    {
        $master = $schema === 'studio_massive' ? 'studio_massive.sqlite_master' : 'main.sqlite_master';
        $stmt = $db->prepare("SELECT 1 FROM $master WHERE type='table' AND name=?");
        $stmt->execute([$table]);
        $exists = (bool)$stmt->fetchColumn();
        $stmt->closeCursor();
        return $exists;
    }

    /** Replace exact filenames and local upload URLs, without matching similar names or foreign CDN paths. */
    public static function rewrite(mixed $value, string $from, string $to, ?string $apiBase = null): mixed
    {
        return (new MediaReferenceRewriter($from, $to, $apiBase ?? ($_ENV['APP_URL'] ?? '')))->rewrite($value);
    }

    /** Return affected slot keys; filesystem cache invalidation belongs after the caller's commit. */
    public static function migrate(PDO $db, string $from, string $to, string $actor, bool $massiveAttached): array
    {
        if (!$db->inTransaction()) {
            throw new RuntimeException('Reference migration requires a transaction.');
        }
        $schema = RelationService::loadSchema();
        $migration = new self($db, new MediaReferenceRewriter($from, $to, $_ENV['APP_URL'] ?? ''), $actor);
        $migration->slots($schema);
        $migration->collections();
        $migration->seo();
        if ($massiveAttached) {
            $migration->massive($schema);
            $migration->hub();
        }
        return array_keys($migration->changedSlots);
    }

    /** Only identifiers are buffered, and every SQLite cursor closes before any business write. */
    private function identifiers(string $sql, array $parameters, int|string $cursor = 0): Generator
    {
        $stmt = $this->db->prepare($sql);
        do {
            foreach ($parameters as $name => $value) {
                $stmt->bindValue($name, $value);
            }
            $stmt->bindValue(':cursor', $cursor, is_int($cursor) ? PDO::PARAM_INT : PDO::PARAM_STR);
            $stmt->execute();
            $ids = $stmt->fetchAll(PDO::FETCH_COLUMN);
            $stmt->closeCursor();
            foreach ($ids as $id) {
                yield $id;
            }
            if ($ids !== []) {
                $cursor = end($ids);
            }
        } while (count($ids) === 100);
    }

    private function condition(array $columns): array
    {
        $conditions = [];
        $parameters = [];
        foreach ($columns as $column) {
            foreach ($this->rewriter->needles() as $index => $needle) {
                if (str_contains($needle, '%') || str_contains($needle, '\\u')) {
                    $conditions[] = "INSTR(LOWER($column),:needle$index)>0";
                    $parameters[":needle$index"] = strtolower($needle);
                } else {
                    $conditions[] = "INSTR($column,:needle$index)>0";
                    $parameters[":needle$index"] = $needle;
                }
            }
        }
        return ['(' . implode(' OR ', $conditions) . ')', $parameters];
    }

    private static function read(PDOStatement $stmt, int|string|array $id): array
    {
        $stmt->execute(is_array($id) ? $id : [$id]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $stmt->closeCursor();
        if ($row === false) {
            throw new RuntimeException('A media reference disappeared during migration.');
        }
        return $row;
    }

    private static function json(mixed $value): string
    {
        return json_encode($value, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR);
    }

    private function slots(array $schema): void
    {
        [$condition, $parameters] = $this->condition(['data']);
        $sources = [];
        if (self::hasTable($this->db, 'media_usages')) {
            $sources[] = $this->identifiers(
                'SELECT slot_key FROM media_usages WHERE media_ref=:ref AND slot_key>:cursor ORDER BY slot_key LIMIT 100',
                [':ref' => $this->rewriter->from],
                ''
            );
        }
        $sources[] = $this->identifiers(
            "SELECT key FROM slots WHERE key>:cursor AND $condition ORDER BY key LIMIT 100",
            $parameters,
            ''
        );
        $read = $this->db->prepare('SELECT data FROM slots WHERE key=?');
        foreach ($sources as $source) {
            foreach ($source as $key) {
                if (CollectionDatabase::isRegistered($key)) {
                    continue;
                }
                $row = self::read($read, $key);
                $original = json_decode($row['data'], true, 512, JSON_THROW_ON_ERROR);
                $updated = $this->rewriter->rewrite($original);
                if ($updated === $original) {
                    continue;
                }
                $result = ContentDatabase::saveSlotWithResult($key, $updated, [
                    'expected_hash' => ContentDatabase::computeContentHash($original),
                    'changed_by' => $this->actor,
                    'force_version' => true,
                    'version_intent' => 'system',
                    'slot_type' => $schema['slots'][$key]['type'] ?? 'object',
                    'defer_effects' => true,
                ]);
                if (!($result['success'] ?? false)) {
                    if (($result['error'] ?? '') === 'CONFLICT') {
                        throw new OptimisticLockException($key);
                    }
                    throw new RuntimeException('Could not migrate slot references: ' . ($result['error'] ?? $key));
                }
                $this->changedSlots[$key] = true;
            }
        }
    }

    private function collections(): void
    {
        if (!self::hasTable($this->db, 'collection_items')) {
            return;
        }
        // The media B-tree identifies candidates without scanning every collection item/block.
        // A second SQL-filtered pass also covers bare, encoded and legacy /uploads/ references
        // which older usage indexes did not record. Already rewritten items become no-ops.
        foreach ($this->collectionReferences() as [$key, $uid]) {
            $row = CollectionDatabase::row($key, $uid);
            if ($row === null) {
                throw new RuntimeException('A collection item disappeared during media migration.');
            }
            $this->collectionItem($row);
        }
        [$condition, $parameters] = $this->condition(['i.data', 'b.data']);
        $parameters[':ref'] = $this->rewriter->from;
        $read = $this->db->prepare('SELECT slot_key,item_uid,revision,updated_at FROM collection_items WHERE row_id=?');
        $sql = "SELECT i.row_id FROM collection_items i WHERE i.row_id>:cursor
            AND NOT EXISTS (SELECT 1 FROM collection_media_usages u
                WHERE u.slot_key=i.slot_key AND u.item_uid=i.item_uid AND u.media_ref=:ref)
            AND EXISTS (SELECT 1 FROM (SELECT i.data AS data UNION ALL
                SELECT data FROM collection_blocks WHERE item_row_id=i.row_id) b WHERE $condition)
            ORDER BY i.row_id LIMIT 100";
        foreach ($this->identifiers($sql, $parameters) as $id) {
            $this->collectionItem(self::read($read, $id));
        }
    }

    /** The composite cursor follows idx_collection_media_ref without sorting all candidates per batch. */
    private function collectionReferences(): Generator
    {
        $stmt = $this->db->prepare('SELECT DISTINCT slot_key,item_uid FROM collection_media_usages
            WHERE media_ref=:ref AND (slot_key,item_uid)>(:slot,:uid)
            ORDER BY slot_key,item_uid LIMIT 100');
        $slot = '';
        $uid = '';
        do {
            $stmt->execute([':ref' => $this->rewriter->from, ':slot' => $slot, ':uid' => $uid]);
            $references = $stmt->fetchAll(PDO::FETCH_ASSOC);
            $stmt->closeCursor();
            foreach ($references as $reference) {
                yield [$reference['slot_key'], $reference['item_uid']];
            }
            if ($references !== []) {
                $last = end($references);
                $slot = $last['slot_key'];
                $uid = $last['item_uid'];
            }
        } while (count($references) === 100);
    }

    private function collectionItem(array $row): void
    {
        $key = $row['slot_key'];
        $uid = $row['item_uid'];
        $original = CollectionDatabase::getItem($key, $uid, true);
        if ($original === null) {
            throw new RuntimeException('A collection item disappeared during media migration.');
        }
        $updated = $this->rewriter->rewrite($original);
        if ($updated === $original) {
            return;
        }
        CollectionDatabase::writeItem($key, $uid, $updated, 'update', [
            'replace' => true,
            'expected_revision' => (int)$row['revision'],
            'client_updated_at' => $row['updated_at'],
            'expected_schema_revision' => CollectionDatabase::state($key)['schema_hash'],
            'changed_by' => $this->actor,
        ]);
        $this->changedSlots[$key] = true;
    }

    private function seo(): void
    {
        if (self::hasTable($this->db, 'seo_assets')) {
            $this->db->prepare('UPDATE seo_assets SET media_id=?,revision=revision+1,updated_at=? WHERE media_id=?')
                ->execute([$this->rewriter->to, gmdate('c'), $this->rewriter->from]);
        }
        if (self::hasTable($this->db, 'seo_asset_usages')) {
            $this->db->prepare("UPDATE OR IGNORE seo_asset_usages SET resource_id=? WHERE type='media' AND resource_id=?")
                ->execute([$this->rewriter->to, $this->rewriter->from]);
            $this->db->prepare("DELETE FROM seo_asset_usages WHERE type='media' AND resource_id=?")
                ->execute([$this->rewriter->from]);
        }
        foreach (['seo_routes' => ['id'], 'seo_documents' => ['target_id', 'locale']] as $table => $keys) {
            if (!self::hasTable($this->db, $table)) {
                continue;
            }
            [$condition, $parameters] = $this->condition(['data']);
            $identity = implode(' AND ', array_map(static fn (string $key): string => "$key=?", $keys));
            $read = $this->db->prepare("SELECT data,revision FROM $table WHERE $identity");
            $write = $this->db->prepare("UPDATE $table SET data=?,revision=revision+1,updated_at=? WHERE $identity AND revision=?");
            foreach ($this->seoKeys($table, $keys, $condition, $parameters) as $key) {
                $row = self::read($read, $key);
                $old = json_decode($row['data'], true, 512, JSON_THROW_ON_ERROR);
                $updated = $this->rewriter->rewrite($old);
                if ($updated !== $old) {
                    $write->execute([self::json($updated), gmdate('c'), ...$key, $row['revision']]);
                    if ($write->rowCount() !== 1) {
                        throw new RuntimeException('An SEO document changed during media migration.');
                    }
                }
            }
        }
    }

    /** Use declared primary keys: seo_documents has no rowid and each locale is a separate record. */
    private function seoKeys(string $table, array $keys, string $condition, array $parameters): Generator
    {
        $columns = implode(',', $keys);
        $placeholders = array_map(static fn (int $index): string => ':key' . $index, array_keys($keys));
        $cursor = array_fill_keys($placeholders, '');
        $comparison = count($keys) === 1
            ? $columns . '>' . $placeholders[0]
            : "($columns)>(" . implode(',', $placeholders) . ')';
        $stmt = $this->db->prepare("SELECT $columns FROM $table WHERE $comparison AND $condition ORDER BY $columns LIMIT 100");
        do {
            $stmt->execute($parameters + $cursor);
            $batch = $stmt->fetchAll(PDO::FETCH_NUM);
            $stmt->closeCursor();
            foreach ($batch as $key) {
                yield $key;
            }
            if ($batch !== []) {
                $cursor = array_combine($placeholders, end($batch));
            }
        } while (count($batch) === 100);
    }

    private function massive(array $schema): void
    {
        $definitions = [];
        foreach ($schema['slots'] ?? [] as $key => $definition) {
            if (($definition['type'] ?? '') === 'massive') {
                // SQL identifiers are generated exactly as in MassiveDatabase, never from raw input.
                $name = 'massive_' . preg_replace('/[^a-zA-Z0-9_]/', '_', $key);
                $definitions[$name] = $definition['massive'] ?? $definition['massiveConfig'] ?? $definition;
            }
        }
        $registry = self::hasTable($this->db, 'massive_slot_definitions', 'studio_massive')
            ? $this->db->prepare('SELECT definition FROM studio_massive.massive_slot_definitions WHERE slot_key=?')
            : null;
        $catalog = $this->db->query("SELECT name FROM studio_massive.sqlite_master WHERE type='table'")->fetchAll(PDO::FETCH_COLUMN);
        $tables = array_fill_keys($catalog, true);
        foreach ($catalog as $name) {
            if (!preg_match('/^massive_[a-zA-Z0-9_]+$/D', $name)) {
                continue;
            }
            $columns = $this->db->query('PRAGMA studio_massive.table_info("' . $name . '")')->fetchAll(PDO::FETCH_ASSOC);
            $columnNames = array_column($columns, 'name');
            if (array_diff(['id', 'data', 'updated_at'], $columnNames) !== []) {
                continue;
            }
            $idColumn = $columns[array_search('id', $columnNames, true)];
            if (strtoupper($idColumn['type']) !== 'INTEGER' || (int)$idColumn['pk'] !== 1) {
                continue;
            }
            $config = $definitions[$name] ?? null;
            if ($registry !== null) {
                $registry->execute([substr($name, 8)]);
                $stored = $registry->fetchColumn();
                $registry->closeCursor();
                if (is_string($stored)) {
                    $definition = json_decode($stored, true, 512, JSON_THROW_ON_ERROR);
                    $config = array_replace($config ?? [], $definition['massive'] ?? $definition['massiveConfig'] ?? $definition);
                }
            }
            $table = 'studio_massive."' . $name . '"';
            $fts = 'studio_massive."' . $name . '_fts"';
            $hasFts = isset($tables[$name . '_fts']);
            $read = $this->db->prepare("SELECT data FROM $table WHERE id=?");
            $write = $this->db->prepare("UPDATE $table SET data=?,updated_at=CURRENT_TIMESTAMP WHERE id=? AND data=?");
            $deleteFts = $hasFts ? $this->db->prepare("DELETE FROM $fts WHERE rowid=?") : null;
            $insertFts = $hasFts ? $this->db->prepare("INSERT INTO $fts(rowid,content) VALUES (?,?)") : null;
            [$condition, $parameters] = $this->condition(['data']);
            foreach ($this->identifiers("SELECT id FROM $table WHERE id>:cursor AND ($condition OR substr(data,1,3)='def') ORDER BY id LIMIT 100", $parameters) as $id) {
                $row = self::read($read, $id);
                $encrypted = MassiveEncryption::isEncrypted($row['data']);
                // Decode strictly: decryptData() intentionally tolerates invalid JSON on reads,
                // but a migration must abort instead of silently skipping unreadable references.
                try {
                    $json = $encrypted ? EncryptionService::decrypt($row['data']) : $row['data'];
                } catch (RuntimeException $error) {
                    throw new RuntimeException(
                        "Media conversion blocked: cannot decrypt $name record $id with the configured ENCRYPTION_KEY. "
                        . 'Restore the original key or explicitly archive the obsolete dataset. No conversion changes were saved.',
                        0,
                        $error
                    );
                }
                try {
                    $old = json_decode($json, true, 512, JSON_THROW_ON_ERROR);
                } catch (\JsonException $error) {
                    throw new RuntimeException("Media conversion blocked: $name record $id contains invalid JSON.", 0, $error);
                }
                $updated = $this->rewriter->rewrite($old);
                if ($updated === $old) {
                    continue;
                }
                if (!is_array($updated)) {
                    throw new RuntimeException('A massive record has an invalid content shape.');
                }
                $tokens = '';
                if ($hasFts) {
                    if ($encrypted && ($config === null || !is_array($config['searchableFields'] ?? []))) {
                        throw new RuntimeException('Missing encrypted search configuration for ' . $name);
                    }
                    $searchable = $config['searchableFields'] ?? [];
                    if ($encrypted && $searchable !== [] && !BlindIndexService::isConfigured()) {
                        throw new RuntimeException('Blind indexing is unavailable for ' . $name);
                    }
                    $tokens = $encrypted ? MassiveEncryption::generateBlindIndex($updated, $searchable) : self::flatten($updated);
                }
                $stored = $encrypted ? MassiveEncryption::encryptData($updated) : self::json($updated);
                $write->execute([$stored, $id, $row['data']]);
                if ($write->rowCount() !== 1) {
                    throw new RuntimeException('A massive record changed during media migration.');
                }
                if ($hasFts) {
                    $deleteFts->execute([$id]);
                    if ($tokens !== '') {
                        $insertFts->execute([$id, $tokens]);
                    }
                }
            }
        }
    }

    private static function flatten(array $data): string
    {
        $parts = [];
        foreach ($data as $entry) {
            if (is_array($entry)) {
                $parts[] = self::flatten($entry);
            } elseif (is_string($entry) || is_numeric($entry)) {
                $parts[] = (string)$entry;
            }
        }
        return implode(' ', $parts);
    }

    private function hub(): void
    {
        if (!self::hasTable($this->db, 'eh_items', 'studio_massive')) {
            return;
        }
        $this->hubHasTiles = self::hasTable($this->db, 'eh_tiles', 'studio_massive');
        $read = $this->db->prepare('SELECT * FROM studio_massive.eh_items WHERE id=?');
        $write = $this->db->prepare('UPDATE studio_massive.eh_items SET media_filename=?,metadata_revision=metadata_revision+1,updated_at=? WHERE id=? AND metadata_revision=?');
        foreach ($this->identifiers('SELECT id FROM studio_massive.eh_items WHERE id>:cursor AND media_filename=:ref ORDER BY id LIMIT 100', [':ref' => $this->rewriter->from]) as $id) {
            $item = self::read($read, $id);
            $write->execute([$this->rewriter->to, time(), $id, $item['metadata_revision']]);
            if ($write->rowCount() !== 1) {
                throw new RuntimeException('A Hub image changed during media migration.');
            }
            $this->hubChange($item, 'item.updated', $item['uuid'], (int)$item['metadata_revision'] + 1);
        }
        foreach (['eh_proposals' => ['target', 'values_json', 'field_media_json'], 'eh_references' => ['target']] as $table => $columns) {
            if (!self::hasTable($this->db, $table, 'studio_massive')) {
                continue;
            }
            [$condition, $parameters] = $this->condition($columns);
            $read = $this->db->prepare("SELECT * FROM studio_massive.$table WHERE id=?");
            $assignments = implode(',', array_map(static fn(string $column): string => "$column=?", $columns));
            $isProposal = $table === 'eh_proposals';
            $suffix = $isProposal ? ',revision=revision+1,updated_at=?' : '';
            $guard = $isProposal ? 'revision' : 'target';
            $write = $this->db->prepare("UPDATE studio_massive.$table SET $assignments$suffix WHERE id=? AND $guard=?");
            foreach ($this->identifiers("SELECT id FROM studio_massive.$table WHERE id>:cursor AND $condition ORDER BY id LIMIT 100", $parameters, '') as $id) {
                $row = self::read($read, $id);
                $values = [];
                $changed = false;
                foreach ($columns as $column) {
                    $old = json_decode($row[$column], true, 512, JSON_THROW_ON_ERROR);
                    $updated = $column === 'target' ? $this->target($old) : $this->rewriter->rewrite($old);
                    $changed = $changed || $updated !== $old;
                    $values[] = $updated === $old ? $row[$column] : self::json($updated);
                }
                if (!$changed) {
                    continue;
                }
                if ($isProposal) {
                    $values[] = time();
                }
                $write->execute([...$values, $id, $row[$guard]]);
                if ($write->rowCount() !== 1) {
                    throw new RuntimeException('A Hub reference changed during media migration.');
                }
                $item = $this->hubItem($row['item_id'], true);
                $this->hubChange($item, $isProposal ? 'proposal.updated' : 'item.updated', $isProposal ? $id : $item['uuid'], $isProposal ? (int)$row['revision'] + 1 : (int)$item['metadata_revision']);
            }
        }
        if (self::hasTable($this->db, 'eh_annotations', 'studio_massive')) {
            $read = $this->db->prepare('SELECT item_id FROM studio_massive.eh_annotations WHERE id=?');
            $write = $this->db->prepare("UPDATE studio_massive.eh_annotations SET target_item=? WHERE id=? AND target_kind='media' AND target_item=?");
            foreach ($this->identifiers("SELECT id FROM studio_massive.eh_annotations WHERE id>:cursor AND target_kind='media' AND target_item=:ref ORDER BY id LIMIT 100", [':ref' => $this->rewriter->from]) as $id) {
                $row = self::read($read, $id);
                $write->execute([$this->rewriter->to, $id, $this->rewriter->from]);
                if ($write->rowCount() !== 1) {
                    throw new RuntimeException('A Hub annotation changed during media migration.');
                }
                $item = $this->hubItem($row['item_id'], true);
                $this->hubChange($item, 'item.updated', $item['uuid'], (int)$item['metadata_revision']);
            }
        }
    }

    private function target(mixed $target): mixed
    {
        if (is_array($target) && ($target['kind'] ?? '') === 'media' && ($target['item'] ?? '') === $this->rewriter->from) {
            $target['item'] = $this->rewriter->to;
        }
        return $target;
    }

    private function hubItem(string $uuid, bool $touch = false): array
    {
        if ($touch) {
            $update = $this->hubStatements['touch'] ??= $this->db->prepare('UPDATE studio_massive.eh_items SET metadata_revision=metadata_revision+1,updated_at=? WHERE uuid=?');
            $update->execute([time(), $uuid]);
        }
        $stmt = $this->hubStatements['item'] ??= $this->db->prepare('SELECT * FROM studio_massive.eh_items WHERE uuid=?');
        return self::read($stmt, $uuid);
    }

    /** Qualify sync tables: the content database may contain identically named integration tables. */
    private function hubChange(array $item, string $kind, string $entity, int $revision): void
    {
        $update = $this->hubStatements['update'] ??= $this->db->prepare('UPDATE studio_massive.eh_boards SET change_sequence=change_sequence+1 WHERE id=?');
        $update->execute([$item['board_id']]);
        $read = $this->hubStatements['sequence'] ??= $this->db->prepare('SELECT change_sequence FROM studio_massive.eh_boards WHERE id=?');
        $sequence = self::read($read, $item['board_id'])['change_sequence'];
        $bounds = ItemRepository::boundsOf($item);
        if ($this->hubHasTiles) {
            // Membership does not change: advance existing viewport ETags without touching counts.
            $tiles = $this->hubStatements['tiles'] ??= $this->db->prepare("UPDATE studio_massive.eh_tiles
                SET revision=revision+1 WHERE board_id=:board AND level=:level AND owner_uuid IN ('',:owner)
                AND tile_x BETWEEN :min_x AND :max_x AND tile_y BETWEEN :min_y AND :max_y");
            for ($level = 0; $level < HubConfig::TILE_LEVELS; $level++) {
                $size = HubConfig::TILE_SIZE * (2 ** $level);
                $tiles->execute([
                    ':board' => $item['board_id'], ':level' => $level, ':owner' => $item['owner_uuid'],
                    ':min_x' => (int)floor($bounds['min_x'] / $size), ':max_x' => (int)floor($bounds['max_x'] / $size),
                    ':min_y' => (int)floor($bounds['min_y'] / $size), ':max_y' => (int)floor($bounds['max_y'] / $size),
                ]);
            }
        }
        $insert = $this->hubStatements['insert'] ??= $this->db->prepare('INSERT INTO studio_massive.eh_changes VALUES(?,?,?,?,?,?,?,?,?)');
        $insert->execute([
            $item['board_id'], $sequence, $kind, $entity, $revision,
            self::json($kind === 'proposal.updated' ? ['item_id' => $item['uuid'], 'proposal_id' => $entity] : []),
            self::json($bounds), self::json($bounds), time(),
        ]);
    }
}
