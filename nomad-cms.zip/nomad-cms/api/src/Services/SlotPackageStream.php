<?php
/**
 * NOMAD CMS - Slot Package Streamer
 * Memory-efficient streaming reader and writer for portable collection export/import packages
 *
 * Features:
 * - Constant O(1) memory footprint during multi-gigabyte collection imports/exports
 * - Streams JSON tokens into temporary file spools instead of loading entire arrays
 * - SHA-256 package checksum verification and tamper rejection
 * - Compatibility with legacy nomad-slot-export/v1 export formats
 * - Chunked generator yielding parsed items sequentially
 *
 * Storage: Temporary system spools, streaming I/O
 */

declare(strict_types=1);

namespace NomadCMS\Services;

use InvalidArgumentException;
use RuntimeException;

final class SlotPackageStream
{
    private $input;
    private $spool;
    private string $buffer = "";
    private int $cursor = 0;
    public array $package = [];
    public int $count = 0;
    public string $checksum;

    public function __construct(string $path)
    {
        $this->input = fopen($path, "rb");
        $this->spool = tmpfile();
        if (!$this->input || !$this->spool) {
            throw new RuntimeException("Cannot open backup");
        }
        try {
            $this->expect("{");
            $hash = hash_init("sha256");
            $seen = [];
            $hasData = false;
            while ($this->peek() !== "}") {
                $key = json_decode(
                    $this->value(),
                    true,
                    512,
                    JSON_THROW_ON_ERROR
                );
                if (!is_string($key) || isset($seen[$key])) {
                    throw new InvalidArgumentException(
                        "Invalid or duplicate backup property"
                    );
                }
                $seen[$key] = true;
                $this->expect(":");
                if ($key === "data") {
                    if (
                        isset($this->package["slot"]["type"]) &&
                        $this->package["slot"]["type"] !== "collection"
                    ) {
                        throw new InvalidArgumentException(
                            "Not a collection backup"
                        );
                    }
                    $hasData = true;
                    $this->expect("[");
                    hash_update($hash, "[");
                    while ($this->peek() !== "]") {
                        $raw = $this->value();
                        if (!str_starts_with(ltrim($raw), "{")) {
                            throw new InvalidArgumentException(
                                "Not a collection backup"
                            );
                        }
                        $item = json_decode(
                            $raw,
                            true,
                            512,
                            JSON_THROW_ON_ERROR
                        );
                        $json = json_encode(
                            $item,
                            JSON_THROW_ON_ERROR |
                                JSON_UNESCAPED_UNICODE |
                                JSON_UNESCAPED_SLASHES
                        );
                        hash_update($hash, ($this->count++ ? "," : "") . $json);
                        if (fwrite($this->spool, $json . "\n") === false) {
                            throw new RuntimeException("Cannot spool backup");
                        }
                        if ($this->peek() === "]") {
                            break;
                        }
                        $this->expect(",");
                        if ($this->peek() === "]") {
                            throw new InvalidArgumentException(
                                "Trailing comma in backup"
                            );
                        }
                    }
                    $this->expect("]");
                    hash_update($hash, "]");
                } else {
                    $this->package[$key] = json_decode(
                        $this->value(),
                        true,
                        512,
                        JSON_THROW_ON_ERROR
                    );
                }
                if ($this->peek() === "}") {
                    break;
                }
                $this->expect(",");
                if ($this->peek() === "}") {
                    throw new InvalidArgumentException(
                        "Trailing comma in backup"
                    );
                }
            }
            $this->expect("}");
            if ($this->peek() !== null || !$hasData) {
                throw new InvalidArgumentException("Invalid backup document");
            }
            $this->checksum = hash_final($hash);
            if (($this->package["_format"] ?? "") !== "nomad-slot-export/v1") {
                throw new InvalidArgumentException("Unsupported backup format");
            }
            if (
                ($this->package["slot"]["type"] ??
                    ($this->package["schema"]["type"] ?? "")) !==
                "collection"
            ) {
                throw new InvalidArgumentException("Not a collection backup");
            }
            $expected =
                (string) ($this->package["slot"]["checksum_sha256"] ?? "");
            if ($expected !== "" && !hash_equals($expected, $this->checksum)) {
                throw new InvalidArgumentException("Backup checksum mismatch");
            }
        } finally {
            fclose($this->input);
        }
    }

    public function __destruct()
    {
        if (is_resource($this->spool)) {
            fclose($this->spool);
        }
    }

    /** A second pass starts only after the entire document and checksum were verified. */
    public function items(): \Generator
    {
        rewind($this->spool);
        while (($line = fgets($this->spool)) !== false) {
            yield json_decode($line, true, 512, JSON_THROW_ON_ERROR);
        }
    }

    private function char(): ?string
    {
        if ($this->cursor >= strlen($this->buffer)) {
            $next = fread($this->input, 65536);
            if ($next === false) {
                throw new RuntimeException("Cannot read backup");
            }
            $this->buffer = $next;
            $this->cursor = 0;
            if ($next === "") {
                return null;
            }
        }
        return $this->buffer[$this->cursor];
    }

    private function peek(): ?string
    {
        while (
            ($char = $this->char()) !== null &&
            str_contains(" \n\r\t", $char)
        ) {
            $this->cursor++;
        }
        return $char;
    }

    private function expect(string $expected): void
    {
        if ($this->peek() !== $expected) {
            throw new InvalidArgumentException(
                "Malformed backup: expected $expected"
            );
        }
        $this->cursor++;
    }

    private function value(): string
    {
        $this->peek();
        $out = "";
        $depth = 0;
        $quoted = false;
        $escaped = false;
        while (($char = $this->char()) !== null) {
            if (
                !$quoted &&
                $depth === 0 &&
                ($char === "," ||
                    $char === ":" ||
                    $char === "]" ||
                    $char === "}" ||
                    str_contains(" \n\r\t", $char))
            ) {
                break;
            }
            $out .= $char;
            $this->cursor++;
            if ($quoted) {
                if ($escaped) {
                    $escaped = false;
                } elseif ($char === "\\") {
                    $escaped = true;
                } elseif ($char === '"') {
                    $quoted = false;
                }
            } elseif ($char === '"') {
                $quoted = true;
            } elseif ($char === "[" || $char === "{") {
                $depth++;
            } elseif ($char === "]" || $char === "}") {
                $depth--;
            }
            if (strlen($out) > 64 * 1024 * 1024) {
                throw new InvalidArgumentException(
                    "Backup item exceeds 64 MiB"
                );
            }
        }
        if ($out === "" || $quoted || $depth !== 0) {
            throw new InvalidArgumentException("Incomplete backup value");
        }
        return $out;
    }
}
