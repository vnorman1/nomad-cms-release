<?php
/**
 * NOMAD CMS - Spool Ingest Service
 *
 * Consumes the NDJSON spool files SpoolWriter appends to on the beacon hot
 * path and bulk-inserts them into massive_analytics_events, entirely OFF the
 * request path of any visitor (called only from the piggyback hook or the
 * dedicated CLI, never from collect.php).
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * CURSOR MODEL
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * Each spool file gets one row in massive_analytics_ingest_state tracking a
 * BYTE OFFSET into that file. A run reads from the last offset to EOF, but
 * only counts and advances the cursor past COMPLETE lines (ending in "\n") -
 * a partial trailing line (the writer was mid-append when this run started
 * reading) is left for the next run rather than risking a truncated/invalid
 * JSON parse. This makes ingest safe to run concurrently with an arbitrary
 * number of beacon writers, and safe to interrupt and resume at any point.
 *
 * A spool file is marked `completed` (and its lines_ingested/lines_failed
 * finalized) once the file's calendar day has fully elapsed AND every byte
 * up to the file's size at read time has been consumed - see isDayOver(). A
 * completed file's on-disk bytes are then deleted by the CALLER (task 8's
 * AnalyticsRetentionService), not by this service, keeping "read the data"
 * and "delete the data" as two independently testable steps.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * CONCURRENCY
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * A dedicated lock file (analytics/spool/.ingest.lock) with
 * flock(LOCK_EX|LOCK_NB) ensures at most one ingest run is active at a time -
 * both the piggyback hook and a manually invoked CLI could otherwise race and
 * double-count the same bytes. A run that cannot acquire the lock returns
 * immediately with ['skipped' => true] rather than blocking (mirrors
 * StaticCacheService's LOCK_EX|LOCK_NB pattern elsewhere in this codebase).
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * DAILY EVENT CAP
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * AnalyticsSettingsService::getDailyEventCap() is enforced HERE, at ingest
 * time, not in collect.php - deliberately, per collect.php's own docblock:
 * checking the cap on the hot path would mean a COUNT query on every single
 * beacon request, exactly the kind of per-visit database round trip this
 * whole module is built to avoid. Here, it costs one COUNT per (host, day)
 * per ingest batch instead of one per visitor.
 *
 * @package NomadCMS\Services\Analytics
 */

declare(strict_types=1);

namespace NomadCMS\Services\Analytics;

use PDO;

final class SpoolIngestService
{
    /** Lines processed per ingest call by default (piggyback-sized) */
    public const DEFAULT_BATCH_LINES = 500;

    /** Hard cap a single call will ever process, regardless of requested batch size */
    public const MAX_BATCH_LINES = 50_000;

    /** Bytes read from a spool file per chunk while scanning for complete lines */
    private const READ_CHUNK_BYTES = 1_048_576; // 1 MB

    private const LOCK_FILENAME = '.ingest.lock';

    /**
     * Ingest up to $maxLines complete lines across all pending spool files.
     *
     * @return array{
     *   skipped:bool, files_touched:int, lines_ingested:int, lines_failed:int,
     *   events_dropped_cap:int, elapsed_ms:float
     * }
     */
    public static function ingest(int $maxLines = self::DEFAULT_BATCH_LINES): array
    {
        $maxLines = max(1, min(self::MAX_BATCH_LINES, $maxLines));

        $lockHandle = self::acquireLock();
        if ($lockHandle === null) {
            return [
                'skipped' => true,
                'files_touched' => 0,
                'lines_ingested' => 0,
                'lines_failed' => 0,
                'events_dropped_cap' => 0,
                'elapsed_ms' => 0.0,
            ];
        }

        $start = microtime(true);

        try {
            AnalyticsSchema::ensureTables();

            $remaining = $maxLines;
            $filesTouched = 0;
            $totalIngested = 0;
            $totalFailed = 0;
            $totalDroppedForCap = 0;

            foreach (SpoolWriter::listSpoolFiles() as $spoolFile) {
                if ($remaining <= 0) {
                    break;
                }

                $result = self::ingestFile($spoolFile, $remaining);

                if ($result['lines_read'] > 0) {
                    $filesTouched++;
                }

                $remaining -= $result['lines_read'];
                $totalIngested += $result['lines_ingested'];
                $totalFailed += $result['lines_failed'];
                $totalDroppedForCap += $result['dropped_for_cap'];
            }

            return [
                'skipped' => false,
                'files_touched' => $filesTouched,
                'lines_ingested' => $totalIngested,
                'lines_failed' => $totalFailed,
                'events_dropped_cap' => $totalDroppedForCap,
                'elapsed_ms' => round((microtime(true) - $start) * 1000, 2),
            ];
        } finally {
            self::releaseLock($lockHandle);
        }
    }

    /**
     * @return array{lines_read:int, lines_ingested:int, lines_failed:int, dropped_for_cap:int}
     */
    private static function ingestFile(string $spoolFile, int $maxLines): array
    {
        $basename = basename($spoolFile, '.ndjson');
        $day = $basename;

        $state = self::getState($spoolFile);
        $offset = $state['byte_offset'] ?? 0;

        $fileSize = @filesize($spoolFile);
        if ($fileSize === false || $offset >= $fileSize) {
            return ['lines_read' => 0, 'lines_ingested' => 0, 'lines_failed' => 0, 'dropped_for_cap' => 0];
        }

        $handle = @fopen($spoolFile, 'rb');
        if ($handle === false) {
            return ['lines_read' => 0, 'lines_ingested' => 0, 'lines_failed' => 0, 'dropped_for_cap' => 0];
        }

        fseek($handle, $offset);

        $linesRead = 0;
        $linesIngested = 0;
        $linesFailed = 0;
        $droppedForCap = 0;
        $bytesConsumed = 0;
        $pendingRows = [];

        $settings = AnalyticsSettingsService::getInstance();
        $dailyCap = $settings->getDailyEventCap();
        $countedToday = self::countIngestedForDay($day);

        $buffer = '';
        $eof = false;

        while ($linesRead < $maxLines && !$eof) {
            $chunk = fread($handle, self::READ_CHUNK_BYTES);
            if ($chunk === false || $chunk === '') {
                $eof = true;
                break;
            }
            $buffer .= $chunk;

            while ($linesRead < $maxLines) {
                $newlinePos = strpos($buffer, "\n");
                if ($newlinePos === false) {
                    break; // Incomplete line - wait for more data or leave for next run.
                }

                $line = substr($buffer, 0, $newlinePos);
                $buffer = substr($buffer, $newlinePos + 1);
                $bytesConsumed += $newlinePos + 1;
                $linesRead++;

                $decoded = json_decode($line, true);
                if (!is_array($decoded) || !self::isValidEventShape($decoded)) {
                    $linesFailed++;
                    continue;
                }

                if ($countedToday + count($pendingRows) >= $dailyCap) {
                    $droppedForCap++;
                    continue; // Over budget for the day - drop, but still advance the cursor past this line.
                }

                $pendingRows[] = $decoded;
            }
        }

        fclose($handle);

        if (!empty($pendingRows)) {
            $linesIngested = self::bulkInsert($pendingRows);
        }

        self::advanceState($spoolFile, $offset + $bytesConsumed, $linesIngested, $linesFailed);

        return [
            'lines_read' => $linesRead,
            'lines_ingested' => $linesIngested,
            'lines_failed' => $linesFailed,
            'dropped_for_cap' => $droppedForCap,
        ];
    }

    private static function isValidEventShape(array $event): bool
    {
        foreach (['ts', 'day', 'host', 'path', 'visitor_hash'] as $field) {
            if (!array_key_exists($field, $event)) {
                return false;
            }
        }
        return is_int($event['ts']) && is_string($event['day']) && is_string($event['host'])
            && is_string($event['path']) && is_string($event['visitor_hash']);
    }

    /**
     * @param array<int, array<string, mixed>> $rows
     */
    private static function bulkInsert(array $rows): int
    {
        $db = AnalyticsSchema::db();
        $db->beginTransaction();

        try {
            $stmt = $db->prepare('
                INSERT INTO ' . AnalyticsSchema::TABLE_EVENTS . '
                    (ts, day, host, path, referrer_domain, device, country, utm_source, utm_medium, utm_campaign, utm_term, utm_content, visitor_hash)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ');

            $count = 0;
            foreach ($rows as $row) {
                $stmt->execute([
                    (int) $row['ts'],
                    (string) $row['day'],
                    (string) $row['host'],
                    (string) $row['path'],
                    (string) ($row['referrer_domain'] ?? AnalyticsSchema::DIM_NONE),
                    (string) ($row['device'] ?? AnalyticsSchema::DEVICE_OTHER),
                    (string) ($row['country'] ?? AnalyticsSchema::DIM_NONE),
                    (string) ($row['utm_source'] ?? AnalyticsSchema::DIM_NONE),
                    (string) ($row['utm_medium'] ?? AnalyticsSchema::DIM_NONE),
                    (string) ($row['utm_campaign'] ?? AnalyticsSchema::DIM_NONE),
                    (string) ($row['utm_term'] ?? AnalyticsSchema::DIM_NONE),
                    (string) ($row['utm_content'] ?? AnalyticsSchema::DIM_NONE),
                    (string) $row['visitor_hash'],
                ]);
                $count++;
            }

            $db->commit();
            return $count;
        } catch (\Throwable $e) {
            $db->rollBack();
            error_log('[Analytics] Bulk insert failed: ' . $e->getMessage());
            return 0;
        }
    }

    private static function countIngestedForDay(string $day): int
    {
        $db = AnalyticsSchema::db();
        $stmt = $db->prepare('SELECT COUNT(*) FROM ' . AnalyticsSchema::TABLE_EVENTS . ' WHERE day = ?');
        $stmt->execute([$day]);
        return (int) $stmt->fetchColumn();
    }

    /**
     * @return array{byte_offset:int, lines_ingested:int, lines_failed:int, completed:int}
     */
    private static function getState(string $spoolFile): array
    {
        $db = AnalyticsSchema::db();
        $stmt = $db->prepare('SELECT byte_offset, lines_ingested, lines_failed, completed FROM ' . AnalyticsSchema::TABLE_INGEST_STATE . ' WHERE spool_file = ?');
        $stmt->execute([basename($spoolFile)]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($row === false) {
            return ['byte_offset' => 0, 'lines_ingested' => 0, 'lines_failed' => 0, 'completed' => 0];
        }

        return [
            'byte_offset' => (int) $row['byte_offset'],
            'lines_ingested' => (int) $row['lines_ingested'],
            'lines_failed' => (int) $row['lines_failed'],
            'completed' => (int) $row['completed'],
        ];
    }

    private static function advanceState(string $spoolFile, int $newOffset, int $ingestedDelta, int $failedDelta): void
    {
        $db = AnalyticsSchema::db();
        $stmt = $db->prepare('
            INSERT INTO ' . AnalyticsSchema::TABLE_INGEST_STATE . " (spool_file, byte_offset, lines_ingested, lines_failed, updated_at)
            VALUES (?, ?, ?, ?, datetime('now'))
            ON CONFLICT(spool_file) DO UPDATE SET
                byte_offset = excluded.byte_offset,
                lines_ingested = lines_ingested + ?,
                lines_failed = lines_failed + ?,
                updated_at = excluded.updated_at
        ");
        $stmt->execute([basename($spoolFile), $newOffset, $ingestedDelta, $failedDelta, $ingestedDelta, $failedDelta]);
    }

    /**
     * Mark a spool file's ingest state as completed (called by
     * AggregationService/AnalyticsRetentionService once a day has been rolled
     * up and its raw events are eligible for purge).
     */
    public static function markCompleted(string $day): void
    {
        $db = AnalyticsSchema::db();
        $stmt = $db->prepare('UPDATE ' . AnalyticsSchema::TABLE_INGEST_STATE . " SET completed = 1, updated_at = datetime('now') WHERE spool_file = ?");
        $stmt->execute([$day . '.ndjson']);
    }

    /**
     * Current byte offset recorded for a spool file (0 if never ingested).
     */
    public static function getOffset(string $spoolFile): int
    {
        return self::getState($spoolFile)['byte_offset'];
    }

    // =========================================================================
    // LOCKING
    // =========================================================================

    /** @return resource|null */
    private static function acquireLock()
    {
        $dir = SpoolWriter::spoolDir();
        if (!is_dir($dir)) {
            @mkdir($dir, 0700, true);
        }

        $lockPath = $dir . '/' . self::LOCK_FILENAME;
        $handle = @fopen($lockPath, 'c');
        if ($handle === false) {
            return null;
        }

        if (!flock($handle, LOCK_EX | LOCK_NB)) {
            fclose($handle);
            return null;
        }

        return $handle;
    }

    /** @param resource $handle */
    private static function releaseLock($handle): void
    {
        flock($handle, LOCK_UN);
        fclose($handle);
    }
}
