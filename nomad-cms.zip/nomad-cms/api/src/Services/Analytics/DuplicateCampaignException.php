<?php
/**
 * NOMAD CMS - Duplicate Campaign Exception
 *
 * Thrown by CampaignService::create() when a campaign with the same
 * base_url + UTM combination already exists AND the caller did not pass
 * force=true. Carries the conflicting campaign's data so the caller (the
 * admin endpoint) can return it in the error response, letting the frontend
 * show "this already exists as [name] - save anyway?" instead of a generic
 * error.
 *
 * @package NomadCMS\Services\Analytics
 */

declare(strict_types=1);

namespace NomadCMS\Services\Analytics;

final class DuplicateCampaignException extends \RuntimeException
{
    /** @var array<string, mixed> */
    private array $existingCampaign;

    /**
     * @param array<string, mixed> $existingCampaign
     */
    public function __construct(array $existingCampaign)
    {
        parent::__construct('Egy kampány már létezik ugyanezzel az URL + UTM kombinációval.');
        $this->existingCampaign = $existingCampaign;
    }

    /**
     * @return array<string, mixed>
     */
    public function getExistingCampaign(): array
    {
        return $this->existingCampaign;
    }
}
