<?php
/**
 * NOMAD CMS - Analytics Campaigns Schema
 *
 * Storage for the UTM Campaign Builder: user-created "here's a link + its
 * UTM parameters" records that live alongside (but separately from) the
 * beacon-ingested analytics data (AnalyticsSchema). A campaign row is pure
 * marketing metadata - it does not itself produce any traffic; the "live"
 * metrics shown against it come from joining its UTM combination against
 * massive_analytics_daily_facts at read time (see
 * AnalyticsQueryService::metricsForUtmCombinations()).
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * WHY NO UNIQUE CONSTRAINT ON THE UTM COMBINATION
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * A campaign's "identity" is base_url + all five UTM fields, and duplicates
 * of that combination are a real-world, INTENTIONAL use case (task's own
 * requirement): the same campaign is often deliberately re-tagged onto
 * multiple landing pages, or a user may consciously want two saved links
 * with identical tracking but different internal names/notes. Enforcing a
 * UNIQUE index would make that a hard DB-level rejection with no way to
 * override it. Instead, this schema carries a plain (non-unique) composite
 * index for fast duplicate LOOKUP, and CampaignService decides whether to
 * block or allow a save based on an explicit, caller-supplied `force` flag -
 * the database only makes the lookup fast, never the decision.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * WHY EMPTY STRING, NOT NULL, FOR OPTIONAL UTM FIELDS
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * utm_term/utm_content are optional in the builder UI, but they are stored
 * as NOT NULL DEFAULT '' rather than nullable. Two NULLs are never equal to
 * each other in SQL (NULL != NULL), so a duplicate-lookup WHERE clause
 * comparing "utm_term = ?" with a NULL bind would silently fail to match two
 * campaigns that both simply omitted a term - defeating the entire point of
 * the duplicate check. Empty string is a normal, indexable, equality-
 * comparable value, so "both omitted" reliably compares as "both equal".
 *
 * @package NomadCMS\Services\Analytics
 */

declare(strict_types=1);

namespace NomadCMS\Services\Analytics;

use NomadCMS\Database\MassiveDatabase;
use PDO;

final class AnalyticsCampaignsSchema
{
    public const TABLE_CAMPAIGNS = 'massive_analytics_campaigns';

    /** Guard so the schema check runs once per process (same pattern as AnalyticsSchema) */
    private static bool $tablesReady = false;

    public static function db(): PDO
    {
        return MassiveDatabase::getInstance();
    }

    public static function ensureTables(): void
    {
        if (self::$tablesReady) {
            return;
        }

        $db = self::db();

        $db->exec('
            CREATE TABLE IF NOT EXISTS ' . self::TABLE_CAMPAIGNS . " (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                base_url TEXT NOT NULL DEFAULT '',
                utm_source TEXT NOT NULL DEFAULT '',
                utm_medium TEXT NOT NULL DEFAULT '',
                utm_campaign TEXT NOT NULL DEFAULT '',
                utm_term TEXT NOT NULL DEFAULT '',
                utm_content TEXT NOT NULL DEFAULT '',
                notes TEXT NOT NULL DEFAULT '',
                created_by TEXT,
                created_at TEXT DEFAULT (datetime('now')),
                updated_at TEXT DEFAULT (datetime('now'))
            )
        ");

        // Plain (non-unique) composite index: fast duplicate LOOKUP only.
        // See class docblock for why this is deliberately not a UNIQUE index.
        $db->exec('
            CREATE INDEX IF NOT EXISTS idx_analytics_campaigns_utm_combo
            ON ' . self::TABLE_CAMPAIGNS . ' (base_url, utm_source, utm_medium, utm_campaign, utm_term, utm_content)
        ');
        $db->exec('CREATE INDEX IF NOT EXISTS idx_analytics_campaigns_created_at ON ' . self::TABLE_CAMPAIGNS . '(created_at)');

        self::$tablesReady = true;
    }

    /** Reset the in-process memoization (tests only) */
    public static function resetMemoization(): void
    {
        self::$tablesReady = false;
    }
}
