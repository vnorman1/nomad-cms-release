<?php
/**
 * NOMAD CMS - Analytics Retention Service
 *
 * Storage-limitation enforcement for the Analytics module, and the piggyback
 * entrypoint that drives ingest + aggregation + finalize + purge without
 * needing cron/daemon access - the same "process a little on every request"
 * pattern already used by FormRetentionService and WebhookQueueService.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * WHAT GETS PURGED, AND WHEN
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *   RAW EVENTS (massive_analytics_events)
 *     Purged per-day, only once ALL of the following hold:
 *       1. The day is finalized (AggregationService::finalizeElapsedDays()
 *          has run for it - day has fully elapsed AND its spool backlog is 0)
 *       2. AnalyticsSettingsService::getRetentionRawHours() (default 48) have
 *          elapsed since finalization - NOT since the day itself ended. This
 *          matters: retention_raw_hours is a grace window for admins to still
 *          inspect/re-verify raw data shortly after finalization, not a
 *          "delete N hours after midnight" clock. daily_totals.updated_at is
 *          reused as the finalization timestamp: the finalize UPDATE is the
 *          LAST write that row will ever receive (a finalized day is never
 *          re-aggregated), so updated_at at that moment IS finalized_at -
 *          no extra schema column needed.
 *     Once purged, the day's spool file is also safe to unlink (ingest done +
 *     aggregation done + raw purge done - nothing will ever read it again).
 *
 *   AGGREGATED DATA (daily_totals / daily_facts)
 *     Purged per AnalyticsSettingsService::getRetentionDailyDays() (0 = keep
 *     forever - the common case; aggregated data has no PII in it at all, so
 *     there is no privacy pressure to delete it, only a storage-size choice
 *     left entirely to the admin).
 *
 * @package NomadCMS\Services\Analytics
 */

declare(strict_types=1);

namespace NomadCMS\Services\Analytics;

use PDO;
use Throwable;

final class AnalyticsRetentionService
{
    /** Percentage of requests that trigger a piggyback sweep (mirrors FormRetentionService) */
    private const PIGGYBACK_SAMPLE_PERCENT = 2;

    /** Lines ingested per piggyback run - small, since this runs on ~2% of ALL requests */
    private const PIGGYBACK_INGEST_LIMIT = 300;

    /** Max days purged per sweep call (raw purge + aggregated purge each) */
    private const MAX_DAYS_PER_SWEEP = 30;

    /**
     * Entry point for the piggyback shutdown handler. Sampled and fully
     * guarded: runs AFTER the response has been flushed, so a failure here
     * must never surface anywhere but the error log.
     */
    public static function piggyback(): void
    {
        try {
            if (!AnalyticsSettingsService::getInstance()->isEnabled()) {
                return;
            }

            if (random_int(1, 100) > self::PIGGYBACK_SAMPLE_PERCENT) {
                return;
            }

            SpoolIngestService::ingest(self::PIGGYBACK_INGEST_LIMIT);
            AggregationService::aggregateAllPending();
            AggregationService::finalizeElapsedDays();
            self::purgeFinalizedRawEvents();
            self::purgeExpiredAggregates();
        } catch (Throwable $e) {
            error_log('[Analytics] Retention piggyback error: ' . $e->getMessage());
        }
    }

    /**
     * Manually triggerable sweep (admin action / CLI), doing the same work as
     * piggyback() but without the sampling gate and with a caller-controlled
     * ingest batch size.
     *
     * @return array{ingested:int, raw_days_purged:int, aggregate_days_purged:int, quota_days_purged:int}
     */
    public static function sweep(int $ingestLimit = SpoolIngestService::DEFAULT_BATCH_LINES): array
    {
        AnalyticsSchema::ensureTables();

        $ingestResult = SpoolIngestService::ingest($ingestLimit);
        AggregationService::aggregateAllPending();
        AggregationService::finalizeElapsedDays();

        $rawPurged = self::purgeFinalizedRawEvents();
        $aggregatePurged = self::purgeExpiredAggregates();
        $quotaPurged = self::purgeByStorageQuota();

        return [
            'ingested' => $ingestResult['skipped'] ? 0 : $ingestResult['lines_ingested'],
            'raw_days_purged' => $rawPurged,
            'aggregate_days_purged' => $aggregatePurged,
            'quota_days_purged' => $quotaPurged,
        ];
    }

    // =========================================================================
    // RAW EVENT PURGE
    // =========================================================================

    /**
     * Purge raw events for days that are finalized AND past their raw
     * retention grace window. Also unlinks the corresponding spool file once
     * its raw rows are gone (ingest + aggregation + purge all done for it).
     *
     * @return int Days purged in this call
     */
    public static function purgeFinalizedRawEvents(): int
    {
        AnalyticsSchema::ensureTables();
        $db = AnalyticsSchema::db();

        $retentionHours = AnalyticsSettingsService::getInstance()->getRetentionRawHours();

        // finalized=1 AND updated_at (== finalized_at, see class docblock)
        // older than the retention window.
        $stmt = $db->prepare('
            SELECT DISTINCT day FROM ' . AnalyticsSchema::TABLE_DAILY_TOTALS . "
            WHERE finalized = 1
              AND updated_at <= datetime('now', ? )
            ORDER BY day ASC
            LIMIT ?
        ");
        $stmt->execute(['-' . $retentionHours . ' hours', self::MAX_DAYS_PER_SWEEP]);
        $days = array_column($stmt->fetchAll(PDO::FETCH_ASSOC), 'day');

        $purged = 0;
        foreach ($days as $day) {
            // Skip a day that somehow still has raw rows AND an unfinished
            // ingest backlog for its spool file (defensive - should not
            // happen given finalize's own backlog check, but purging raw rows
            // while a backlog still exists would silently lose those events).
            $spoolFile = SpoolWriter::spoolFilePath(SpoolWriter::spoolDir(), (string) $day);
            $fileSize = is_file($spoolFile) ? (int) filesize($spoolFile) : 0;
            $offset = SpoolIngestService::getOffset($spoolFile);
            if ($offset < $fileSize) {
                continue;
            }

            $delete = $db->prepare('DELETE FROM ' . AnalyticsSchema::TABLE_EVENTS . ' WHERE day = ?');
            $delete->execute([$day]);

            if (is_file($spoolFile)) {
                @unlink($spoolFile);
            }

            $purged++;
        }

        return $purged;
    }

    // =========================================================================
    // AGGREGATED DATA PURGE
    // =========================================================================

    /**
     * Purge daily_totals/daily_facts rows older than
     * AnalyticsSettingsService::getRetentionDailyDays(). 0 means "keep
     * forever" - the default - so this is a no-op on a fresh install.
     *
     * @return int Days purged in this call
     */
    public static function purgeExpiredAggregates(): int
    {
        AnalyticsSchema::ensureTables();

        $retentionDays = AnalyticsSettingsService::getInstance()->getRetentionDailyDays();
        if ($retentionDays === 0) {
            return 0; // Keep forever - explicit admin choice, same convention as Forms.
        }

        $db = AnalyticsSchema::db();
        $cutoff = date('Y-m-d', strtotime('-' . $retentionDays . ' days'));

        $stmt = $db->prepare('SELECT DISTINCT day FROM ' . AnalyticsSchema::TABLE_DAILY_TOTALS . ' WHERE day < ? LIMIT ?');
        $stmt->execute([$cutoff, self::MAX_DAYS_PER_SWEEP]);
        $days = array_column($stmt->fetchAll(PDO::FETCH_ASSOC), 'day');

        $purged = 0;
        foreach ($days as $day) {
            $db->prepare('DELETE FROM ' . AnalyticsSchema::TABLE_DAILY_TOTALS . ' WHERE day = ?')->execute([$day]);
            $db->prepare('DELETE FROM ' . AnalyticsSchema::TABLE_DAILY_FACTS . ' WHERE day = ?')->execute([$day]);
            $db->prepare('DELETE FROM ' . AnalyticsSchema::TABLE_HOURLY_TOTALS . ' WHERE day = ?')->execute([$day]);
            $db->prepare('DELETE FROM ' . AnalyticsSchema::TABLE_INGEST_STATE . ' WHERE spool_file = ?')->execute([$day . '.ndjson']);
            $purged++;
        }

        return $purged;
    }

    // =========================================================================
    // STORAGE QUOTA FIFO PURGE & MEASUREMENT
    // =========================================================================

    /**
     * Measure total analytics storage footprint in bytes:
     * - SQLite tables and indexes belonging to the analytics schema (via dbstat when available)
     * - Spool files on disk in api/storage/analytics/spool/
     */
    public static function getAnalyticsStorageBytes(): int
    {
        AnalyticsSchema::ensureTables();
        $db = AnalyticsSchema::db();
        $totalBytes = 0;

        // 1. Query SQLite storage footprint (tables + indexes)
        try {
            $stmt = $db->query("SELECT SUM(pgsize) FROM dbstat WHERE name LIKE '%analytics%'");
            $val = $stmt ? $stmt->fetchColumn() : null;
            if ($val !== false && $val !== null) {
                $totalBytes += (int) $val;
            }
        } catch (\Throwable $e) {
            // Fallback if dbstat is not compiled in
            try {
                $pageCount = (int) $db->query('PRAGMA page_count')->fetchColumn();
                $pageSize = (int) $db->query('PRAGMA page_size')->fetchColumn();
                $totalBytes += (int) ($pageCount * $pageSize);
            } catch (\Throwable $e2) {
                // Ignore fallback error
            }
        }

        // 2. Add spool files on disk
        foreach (SpoolWriter::listSpoolFiles() as $spoolFile) {
            if (is_file($spoolFile)) {
                $totalBytes += (int) filesize($spoolFile);
            }
        }

        return $totalBytes;
    }

    /**
     * Purge oldest aggregated days when total storage exceeds the configured
     * analytics.max_storage_mb quota (FIFO retention).
     *
     * Key safeguards:
     * - Never purges today's day (current active day is protected).
     * - Purges strictly in chronological order (oldest first).
     * - Targets 95% of quota (5% buffer) so it doesn't immediately bounce.
     * - Limited to MAX_DAYS_PER_SWEEP per call to prevent timeout.
     *
     * @return int Days purged in this call
     */
    public static function purgeByStorageQuota(?int $maxMbOverride = null, ?int $maxDaysLimit = null): int
    {
        AnalyticsSchema::ensureTables();
        $maxMb = $maxMbOverride ?? AnalyticsSettingsService::getInstance()->getMaxStorageMb();
        if ($maxMb <= 0) {
            return 0; // 0 = unlimited / no quota enforced
        }

        $maxBytes = $maxMb * 1024 * 1024;
        $currentBytes = self::getAnalyticsStorageBytes();
        if ($currentBytes <= $maxBytes) {
            return 0; // Within quota
        }

        $targetBytes = (int) ($maxBytes * 0.95); // 5% safety buffer
        $today = date('Y-m-d');
        $db = AnalyticsSchema::db();
        $limit = $maxDaysLimit ?? self::MAX_DAYS_PER_SWEEP;

        // Query oldest days, excluding today
        $stmt = $db->prepare('
            SELECT DISTINCT day FROM ' . AnalyticsSchema::TABLE_DAILY_TOTALS . '
            WHERE day < ?
            ORDER BY day ASC
            LIMIT ?
        ');
        $stmt->execute([$today, $limit]);
        $oldestDays = array_column($stmt->fetchAll(PDO::FETCH_ASSOC), 'day');

        if (empty($oldestDays)) {
            return 0;
        }

        $purged = 0;
        $spoolDir = SpoolWriter::spoolDir();

        foreach ($oldestDays as $day) {
            // Delete daily totals, hourly totals, daily facts, and events for this oldest day
            $db->prepare('DELETE FROM ' . AnalyticsSchema::TABLE_DAILY_TOTALS . ' WHERE day = ?')->execute([$day]);
            $db->prepare('DELETE FROM ' . AnalyticsSchema::TABLE_HOURLY_TOTALS . ' WHERE day = ?')->execute([$day]);
            $db->prepare('DELETE FROM ' . AnalyticsSchema::TABLE_DAILY_FACTS . ' WHERE day = ?')->execute([$day]);
            $db->prepare('DELETE FROM ' . AnalyticsSchema::TABLE_EVENTS . ' WHERE day = ?')->execute([$day]);
            $db->prepare('DELETE FROM ' . AnalyticsSchema::TABLE_INGEST_STATE . ' WHERE spool_file = ?')->execute([$day . '.ndjson']);

            // If spool file exists on disk, remove it as well
            $spoolFile = SpoolWriter::spoolFilePath($spoolDir, $day);
            if (is_file($spoolFile)) {
                @unlink($spoolFile);
            }

            $purged++;

            // Check if we are now under the target threshold
            $currentBytes = self::getAnalyticsStorageBytes();
            if ($currentBytes <= $targetBytes) {
                break;
            }
        }

        return $purged;
    }
}
