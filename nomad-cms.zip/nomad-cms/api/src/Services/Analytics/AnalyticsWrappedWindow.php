<?php
/**
 * NOMAD CMS - Analytics Wrapped Window
 *
 * Determines whether the "NOMAD Wrapped" yearly recap teaser/endpoint should
 * currently be active. The rule is intentionally hardcoded (not admin-
 * configurable per the task's own scope: 3=C, "automatikusan az aktuális
 * naptári év utolsó ~2 hete, évről évre ismétlődően") - the only admin
 * control is the master on/off switch (AnalyticsSettingsService::isWrappedEnabled()),
 * this class only answers "is it currently within the yearly window?".
 *
 * WINDOW: December 18th through January 1st (inclusive), spanning the
 * calendar year boundary. When "now" is in the December portion, the recap
 * year is the current year; when "now" is January 1st, the recap year is
 * the year that JUST ended (December 31st of last year), matching how
 * Spotify Wrapped etc. still call it "this year's wrapped" on New Year's Day.
 *
 * @package NomadCMS\Services\Analytics
 */

declare(strict_types=1);

namespace NomadCMS\Services\Analytics;

final class AnalyticsWrappedWindow
{
    /** Window opens on this month/day every year (inclusive) */
    private const WINDOW_START_MONTH = 12;
    private const WINDOW_START_DAY = 18;

    /** Window closes on this month/day of the FOLLOWING year (inclusive) */
    private const WINDOW_END_MONTH = 1;
    private const WINDOW_END_DAY = 1;

    /**
     * Whether the yearly Wrapped window is currently open.
     *
     * @param \DateTimeImmutable|null $now Injectable for tests; defaults to the real current time.
     */
    public static function isActive(?\DateTimeImmutable $now = null): bool
    {
        $now ??= new \DateTimeImmutable();

        $month = (int) $now->format('n');
        $day = (int) $now->format('j');

        if ($month === self::WINDOW_START_MONTH) {
            return $day >= self::WINDOW_START_DAY;
        }

        if ($month === self::WINDOW_END_MONTH) {
            return $day <= self::WINDOW_END_DAY;
        }

        return false;
    }

    /**
     * The calendar year the recap should cover for the given "now" - the
     * year that is ending/has just ended, NOT necessarily $now's own year
     * (see class docblock: on January 1st, the recap is for the year that
     * just finished, i.e. $now's year minus one).
     *
     * @param \DateTimeImmutable|null $now Injectable for tests; defaults to the real current time.
     */
    public static function recapYear(?\DateTimeImmutable $now = null): int
    {
        $now ??= new \DateTimeImmutable();

        $month = (int) $now->format('n');
        $year = (int) $now->format('Y');

        return $month === self::WINDOW_END_MONTH ? $year - 1 : $year;
    }
}
