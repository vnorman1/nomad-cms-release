<?php
/**
 * NOMAD CMS - Campaign Service
 *
 * CRUD + duplicate-detection for the UTM Campaign Builder
 * (massive_analytics_campaigns, see AnalyticsCampaignsSchema for the storage
 * rationale). This service owns exactly the campaign metadata rows - it
 * never touches beacon-ingested analytics data; "live metrics" for a
 * campaign are computed separately by
 * AnalyticsQueryService::metricsForUtmCombinations() and merged in by the
 * admin endpoint, keeping this service a pure metadata CRUD layer.
 *
 * @package NomadCMS\Services\Analytics
 */

declare(strict_types=1);

namespace NomadCMS\Services\Analytics;

use PDO;

final class CampaignService
{
    /** Max stored length for name/notes - generous but bounded (defense in depth, not a UX limit) */
    private const NAME_MAX_LENGTH = 200;
    private const NOTES_MAX_LENGTH = 2000;
    private const URL_MAX_LENGTH = 2048;
    private const UTM_FIELD_MAX_LENGTH = 255;

    /**
     * @return array<int, array<string, mixed>>
     */
    public static function list(): array
    {
        AnalyticsCampaignsSchema::ensureTables();
        $db = AnalyticsCampaignsSchema::db();

        $stmt = $db->prepare('
            SELECT id, name, base_url, utm_source, utm_medium, utm_campaign, utm_term, utm_content,
                   notes, created_by, created_at, updated_at
            FROM ' . AnalyticsCampaignsSchema::TABLE_CAMPAIGNS . '
            ORDER BY created_at DESC
        ');
        $stmt->execute();

        $rows = [];
        foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
            $rows[] = self::hydrate($row);
        }
        return $rows;
    }

    /**
     * @return array<string, mixed>|null
     */
    public static function find(int $id): ?array
    {
        AnalyticsCampaignsSchema::ensureTables();
        $db = AnalyticsCampaignsSchema::db();

        $stmt = $db->prepare('
            SELECT id, name, base_url, utm_source, utm_medium, utm_campaign, utm_term, utm_content,
                   notes, created_by, created_at, updated_at
            FROM ' . AnalyticsCampaignsSchema::TABLE_CAMPAIGNS . '
            WHERE id = ?
        ');
        $stmt->execute([$id]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);

        return is_array($row) ? self::hydrate($row) : null;
    }

    /**
     * Exact-match lookup on the (base_url, utm_source, utm_medium,
     * utm_campaign, utm_term, utm_content) combination - the campaign's
     * "identity" per the task's own definition. Uses the plain composite
     * index (see AnalyticsCampaignsSchema) for the lookup; does NOT rely on
     * a DB-level UNIQUE constraint, since a duplicate is a soft warning, not
     * a hard rejection.
     *
     * @return array<string, mixed>|null The first conflicting campaign, or null if none
     */
    public static function findDuplicate(
        string $baseUrl,
        string $utmSource,
        string $utmMedium,
        string $utmCampaign,
        string $utmTerm,
        string $utmContent,
        ?int $excludeId = null
    ): ?array {
        AnalyticsCampaignsSchema::ensureTables();
        $db = AnalyticsCampaignsSchema::db();

        $sql = '
            SELECT id, name, base_url, utm_source, utm_medium, utm_campaign, utm_term, utm_content,
                   notes, created_by, created_at, updated_at
            FROM ' . AnalyticsCampaignsSchema::TABLE_CAMPAIGNS . '
            WHERE base_url = ? AND utm_source = ? AND utm_medium = ? AND utm_campaign = ? AND utm_term = ? AND utm_content = ?
        ';
        $params = [$baseUrl, $utmSource, $utmMedium, $utmCampaign, $utmTerm, $utmContent];

        if ($excludeId !== null) {
            $sql .= ' AND id != ?';
            $params[] = $excludeId;
        }

        $sql .= ' LIMIT 1';

        $stmt = $db->prepare($sql);
        $stmt->execute($params);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);

        return is_array($row) ? self::hydrate($row) : null;
    }

    /**
     * @param array<string, mixed> $input
     * @throws DuplicateCampaignException when a conflicting campaign exists and $force is false
     * @throws \InvalidArgumentException on invalid input
     * @return array<string, mixed> The created campaign
     */
    public static function create(array $input, bool $force = false, ?string $createdBy = null): array
    {
        AnalyticsCampaignsSchema::ensureTables();

        $fields = self::sanitizeInput($input);

        if (!$force) {
            $duplicate = self::findDuplicate(
                $fields['base_url'],
                $fields['utm_source'],
                $fields['utm_medium'],
                $fields['utm_campaign'],
                $fields['utm_term'],
                $fields['utm_content']
            );
            if ($duplicate !== null) {
                throw new DuplicateCampaignException($duplicate);
            }
        }

        $db = AnalyticsCampaignsSchema::db();
        $stmt = $db->prepare('
            INSERT INTO ' . AnalyticsCampaignsSchema::TABLE_CAMPAIGNS . "
                (name, base_url, utm_source, utm_medium, utm_campaign, utm_term, utm_content, notes, created_by, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now'), datetime('now'))
        ");
        $stmt->execute([
            $fields['name'],
            $fields['base_url'],
            $fields['utm_source'],
            $fields['utm_medium'],
            $fields['utm_campaign'],
            $fields['utm_term'],
            $fields['utm_content'],
            $fields['notes'],
            $createdBy,
        ]);

        $id = (int) $db->lastInsertId();
        $created = self::find($id);
        if ($created === null) {
            throw new \RuntimeException('A kampány létrehozása után nem sikerült visszaolvasni a rekordot.');
        }
        return $created;
    }

    /**
     * @param array<string, mixed> $input
     * @throws DuplicateCampaignException when a conflicting campaign exists and $force is false
     * @throws \InvalidArgumentException on invalid input or unknown id
     * @return array<string, mixed> The updated campaign
     */
    public static function update(int $id, array $input, bool $force = false): array
    {
        AnalyticsCampaignsSchema::ensureTables();

        $existing = self::find($id);
        if ($existing === null) {
            throw new \InvalidArgumentException('Ismeretlen kampány azonosító.');
        }

        $fields = self::sanitizeInput($input);

        if (!$force) {
            $duplicate = self::findDuplicate(
                $fields['base_url'],
                $fields['utm_source'],
                $fields['utm_medium'],
                $fields['utm_campaign'],
                $fields['utm_term'],
                $fields['utm_content'],
                $id
            );
            if ($duplicate !== null) {
                throw new DuplicateCampaignException($duplicate);
            }
        }

        $db = AnalyticsCampaignsSchema::db();
        $stmt = $db->prepare('
            UPDATE ' . AnalyticsCampaignsSchema::TABLE_CAMPAIGNS . " SET
                name = ?, base_url = ?, utm_source = ?, utm_medium = ?, utm_campaign = ?,
                utm_term = ?, utm_content = ?, notes = ?, updated_at = datetime('now')
            WHERE id = ?
        ");
        $stmt->execute([
            $fields['name'],
            $fields['base_url'],
            $fields['utm_source'],
            $fields['utm_medium'],
            $fields['utm_campaign'],
            $fields['utm_term'],
            $fields['utm_content'],
            $fields['notes'],
            $id,
        ]);

        $updated = self::find($id);
        if ($updated === null) {
            throw new \RuntimeException('A kampány frissítése után nem sikerült visszaolvasni a rekordot.');
        }
        return $updated;
    }

    public static function delete(int $id): bool
    {
        AnalyticsCampaignsSchema::ensureTables();
        $db = AnalyticsCampaignsSchema::db();

        $stmt = $db->prepare('DELETE FROM ' . AnalyticsCampaignsSchema::TABLE_CAMPAIGNS . ' WHERE id = ?');
        $stmt->execute([$id]);
        return $stmt->rowCount() > 0;
    }

    // =========================================================================
    // INTERNAL
    // =========================================================================

    /**
     * @param array<string, mixed> $input
     * @return array{name:string, base_url:string, utm_source:string, utm_medium:string, utm_campaign:string, utm_term:string, utm_content:string, notes:string}
     */
    private static function sanitizeInput(array $input): array
    {
        $name = trim(is_scalar($input['name'] ?? null) ? (string) $input['name'] : '');
        if ($name === '') {
            throw new \InvalidArgumentException('A kampány neve kötelező.');
        }
        if (mb_strlen($name) > self::NAME_MAX_LENGTH) {
            $name = mb_substr($name, 0, self::NAME_MAX_LENGTH);
        }

        $baseUrl = trim(is_scalar($input['base_url'] ?? null) ? (string) $input['base_url'] : '');
        if ($baseUrl === '') {
            throw new \InvalidArgumentException('A cél URL kötelező.');
        }
        if (filter_var($baseUrl, FILTER_VALIDATE_URL) === false) {
            throw new \InvalidArgumentException('A cél URL nem érvényes URL formátum.');
        }
        if (strlen($baseUrl) > self::URL_MAX_LENGTH) {
            throw new \InvalidArgumentException('A cél URL túl hosszú.');
        }

        $utmSource = self::sanitizeUtmField($input['utm_source'] ?? '');
        $utmMedium = self::sanitizeUtmField($input['utm_medium'] ?? '');
        $utmCampaign = self::sanitizeUtmField($input['utm_campaign'] ?? '');
        $utmTerm = self::sanitizeUtmField($input['utm_term'] ?? '');
        $utmContent = self::sanitizeUtmField($input['utm_content'] ?? '');

        if ($utmSource === '' || $utmMedium === '' || $utmCampaign === '') {
            throw new \InvalidArgumentException('Az UTM forrás, médium és kampány mezők kötelezők.');
        }

        $notes = trim(is_scalar($input['notes'] ?? null) ? (string) $input['notes'] : '');
        if (mb_strlen($notes) > self::NOTES_MAX_LENGTH) {
            $notes = mb_substr($notes, 0, self::NOTES_MAX_LENGTH);
        }

        return [
            'name' => $name,
            'base_url' => $baseUrl,
            'utm_source' => $utmSource,
            'utm_medium' => $utmMedium,
            'utm_campaign' => $utmCampaign,
            'utm_term' => $utmTerm,
            'utm_content' => $utmContent,
            'notes' => $notes,
        ];
    }

    private static function sanitizeUtmField(mixed $raw): string
    {
        $value = trim(is_scalar($raw) ? (string) $raw : '');
        if (strlen($value) > self::UTM_FIELD_MAX_LENGTH) {
            $value = substr($value, 0, self::UTM_FIELD_MAX_LENGTH);
        }
        return $value;
    }

    /**
     * @param array<string, mixed> $row
     * @return array<string, mixed>
     */
    private static function hydrate(array $row): array
    {
        return [
            'id' => is_scalar($row['id']) ? (int) $row['id'] : 0,
            'name' => is_scalar($row['name']) ? (string) $row['name'] : '',
            'base_url' => is_scalar($row['base_url']) ? (string) $row['base_url'] : '',
            'utm_source' => is_scalar($row['utm_source']) ? (string) $row['utm_source'] : '',
            'utm_medium' => is_scalar($row['utm_medium']) ? (string) $row['utm_medium'] : '',
            'utm_campaign' => is_scalar($row['utm_campaign']) ? (string) $row['utm_campaign'] : '',
            'utm_term' => is_scalar($row['utm_term']) ? (string) $row['utm_term'] : '',
            'utm_content' => is_scalar($row['utm_content']) ? (string) $row['utm_content'] : '',
            'notes' => is_scalar($row['notes']) ? (string) $row['notes'] : '',
            'created_by' => is_scalar($row['created_by']) ? (string) $row['created_by'] : null,
            'created_at' => is_scalar($row['created_at']) ? (string) $row['created_at'] : '',
            'updated_at' => is_scalar($row['updated_at']) ? (string) $row['updated_at'] : '',
        ];
    }
}
