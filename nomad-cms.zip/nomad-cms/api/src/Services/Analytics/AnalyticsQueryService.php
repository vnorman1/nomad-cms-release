<?php
/**
 * NOMAD CMS - Analytics Query Service
 *
 * Read-only query layer over the AGGREGATED tables only
 * (massive_analytics_daily_totals / massive_analytics_daily_facts) - this
 * service NEVER touches massive_analytics_events. That table may not even
 * have rows for older, already-purged days (see AnalyticsRetentionService),
 * so any query answerable from raw events alone would silently stop working
 * once a day ages out. Everything here is designed to keep working forever,
 * because the aggregated tables never lose historical rows (unless the admin
 * explicitly sets a retention_daily_days cutoff).
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * TWO QUERY SHAPES
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *   overview(...)  Time-series views/visitors over a date range, a previous-
 *                   period comparison, and top-N lists per dimension. Views
 *                   and visitors both come from daily_totals (host-level) -
 *                   EXACT, never approximate, because daily_totals is written
 *                   from a true COUNT DISTINCT over raw events at aggregation
 *                   time (see AggregationService::computeTotals()).
 *
 *   explore(...)    Arbitrary filter combinations (dimension=value pairs,
 *                   ANDed together) + an optional breakdown dimension +
 *                   sorting/paging. Views are SUM(views) over the matching
 *                   daily_facts rows - EXACT. Visitors are the ESTIMATE of the
 *                   union of every matching row's VisitorSketch, merged via
 *                   VisitorSketch::merge() then ->estimate() - APPROXIMATE.
 *                   Every response from explore() carries an explicit
 *                   "approximate" flag on the visitor figures so the UI can
 *                   render the "~" affordance instead of presenting a fuzzy
 *                   number as if it were exact.
 *
 * @package NomadCMS\Services\Analytics
 */

declare(strict_types=1);

namespace NomadCMS\Services\Analytics;

use PDO;

final class AnalyticsQueryService
{
    /** Dimension columns explore() may filter/break down on */
    public const FILTERABLE_DIMENSIONS = [
        'path', 'referrer_domain', 'device', 'country',
        'utm_source', 'utm_medium', 'utm_campaign', 'utm_term', 'utm_content',
    ];

    /** Hard bounds on a query's date range, to keep a single request bounded */
    public const MAX_RANGE_DAYS = 366;

    // =========================================================================
    // OVERVIEW
    // =========================================================================

    /**
     * @param string $host
     * @param string $startDay Y-m-d, inclusive
     * @param string $endDay Y-m-d, inclusive
     * @return array{
     *   range:array{start:string,end:string},
     *   totals:array{views:int,visitors:int},
     *   previous_period:array{views:int,visitors:int,views_delta_pct:?float,visitors_delta_pct:?float},
     *   series:array<int,array{day:string,views:int,visitors:int}>,
     *   top:array<string,array<int,array{value:string,views:int}>>
     * }
     */
    public static function overview(string $host, string $startDay, string $endDay, int $topLimit = 10, ?int $dow = null): array
    {
        AnalyticsSchema::ensureTables();
        self::assertValidRange($startDay, $endDay);

        $db = AnalyticsSchema::db();

        $series = self::dailySeries($db, $host, $startDay, $endDay, $dow);
        $totals = self::sumSeries($series);

        $rangeDays = self::daysBetweenInclusive($startDay, $endDay);
        $prevEnd = date('Y-m-d', strtotime($startDay . ' -1 day'));
        $prevStart = date('Y-m-d', strtotime($prevEnd . ' -' . ($rangeDays - 1) . ' days'));
        $prevSeries = self::dailySeries($db, $host, $prevStart, $prevEnd, $dow);
        $prevTotals = self::sumSeries($prevSeries);

        $top = [];
        foreach (self::FILTERABLE_DIMENSIONS as $dimension) {
            $top[$dimension] = self::topForDimension($db, $host, $startDay, $endDay, $dimension, $topLimit, $dow);
        }

        return [
            'range' => ['start' => $startDay, 'end' => $endDay],
            'filtered_dow' => $dow,
            'totals' => $totals,
            'previous_period' => [
                'views' => $prevTotals['views'],
                'visitors' => $prevTotals['visitors'],
                'views_delta_pct' => self::deltaPct($prevTotals['views'], $totals['views']),
                'visitors_delta_pct' => self::deltaPct($prevTotals['visitors'], $totals['visitors']),
            ],
            'series' => $series,
            'top' => $top,
        ];
    }

    // =========================================================================
    // WRAPPED (Spotify-Wrapped-style yearly recap)
    // =========================================================================

    /**
     * Full-year recap for the NOMAD Wrapped feature: total views/visitors,
     * the busiest month, the single busiest day, and top-3 lists for path,
     * referrer_domain, device, and utm_campaign. Built ENTIRELY from
     * daily_totals/daily_facts (same aggregated tables as overview()/
     * explore() - never touches raw events), so it keeps working for any
     * past year regardless of raw-event retention.
     *
     * Monthly buckets are computed in PHP from the daily series rather than
     * a second SQL GROUP BY - daily_totals has no month column, and a whole
     * year is at most 366 rows, cheap to bucket in memory.
     *
     * @return array{
     *   year:int,
     *   range:array{start:string,end:string},
     *   totals:array{views:int,visitors:int},
     *   busiest_month:?array{month:string,views:int,visitors:int},
     *   monthly:array<int,array{month:string,views:int,visitors:int}>,
     *   busiest_day:?array{day:string,views:int,visitors:int},
     *   top_paths:array<int,array{value:string,views:int}>,
     *   top_referrers:array<int,array{value:string,views:int}>,
     *   top_devices:array<int,array{value:string,views:int}>,
     *   top_campaigns:array<int,array{value:string,views:int}>
     * }
     */
    public static function wrapped(string $host, int $year): array
    {
        AnalyticsSchema::ensureTables();

        $startDay = sprintf('%04d-01-01', $year);
        $endDay = sprintf('%04d-12-31', $year);
        self::assertValidRange($startDay, $endDay);

        $db = AnalyticsSchema::db();

        $series = self::dailySeries($db, $host, $startDay, $endDay);
        $totals = self::sumSeries($series);

        $monthly = self::bucketSeriesByMonth($series, $year);

        $busiestMonth = null;
        foreach ($monthly as $row) {
            if ($row['views'] > 0 && ($busiestMonth === null || $row['views'] > $busiestMonth['views'])) {
                $busiestMonth = $row;
            }
        }

        $busiestDay = null;
        foreach ($series as $row) {
            if ($row['views'] > 0 && ($busiestDay === null || $row['views'] > $busiestDay['views'])) {
                $busiestDay = $row;
            }
        }

        return [
            'year' => $year,
            'range' => ['start' => $startDay, 'end' => $endDay],
            'totals' => $totals,
            'busiest_month' => $busiestMonth,
            'monthly' => $monthly,
            'busiest_day' => $busiestDay,
            'top_paths' => self::topForDimension($db, $host, $startDay, $endDay, 'path', 3),
            'top_referrers' => self::topForDimension($db, $host, $startDay, $endDay, 'referrer_domain', 3),
            'top_devices' => self::topForDimension($db, $host, $startDay, $endDay, 'device', 3),
            'top_campaigns' => self::topForDimension($db, $host, $startDay, $endDay, 'utm_campaign', 3),
        ];
    }

    /**
     * Buckets a daily series into 12 calendar-month totals for the given
     * year. Always returns exactly 12 entries (Jan-Dec), even for months
     * with zero data, so the frontend never has to handle a sparse array.
     *
     * @param array<int, array{day:string, views:int, visitors:int}> $series
     * @return array<int, array{month:string, views:int, visitors:int}>
     */
    private static function bucketSeriesByMonth(array $series, int $year): array
    {
        $buckets = [];
        for ($m = 1; $m <= 12; $m++) {
            $monthKey = sprintf('%04d-%02d', $year, $m);
            $buckets[$monthKey] = ['month' => $monthKey, 'views' => 0, 'visitors' => 0];
        }

        foreach ($series as $row) {
            $monthKey = substr($row['day'], 0, 7); // 'YYYY-MM-DD' -> 'YYYY-MM'
            if (!isset($buckets[$monthKey])) {
                continue; // Defensive: a row outside the requested year should not happen, but never fatal if it does.
            }
            $buckets[$monthKey]['views'] += $row['views'];
            $buckets[$monthKey]['visitors'] += $row['visitors'];
        }

        return array_values($buckets);
    }

    /**
     * @return array<int, array{day:string, views:int, visitors:int}>
     */
    private static function dailySeries(PDO $db, string $host, string $startDay, string $endDay, ?int $dow = null): array
    {
        $dowSql = '';
        $params = [$host, $startDay, $endDay];
        if ($dow !== null && $dow >= 0 && $dow <= 6) {
            $dowSql = ' AND ((CAST(strftime(\'%w\', day) AS INTEGER) + 6) % 7) = CAST(? AS INTEGER)';
            $params[] = $dow;
        }

        $stmt = $db->prepare('
            SELECT day, views, visitors FROM ' . AnalyticsSchema::TABLE_DAILY_TOTALS . '
            WHERE host = ? AND day BETWEEN ? AND ?' . $dowSql . '
            ORDER BY day ASC
        ');
        $stmt->execute($params);

        $result = [];
        foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
            $result[] = ['day' => (string) $row['day'], 'views' => (int) $row['views'], 'visitors' => (int) $row['visitors']];
        }
        return $result;
    }

    /**
     * @param array<int, array{day:string, views:int, visitors:int}> $series
     * @return array{views:int, visitors:int}
     */
    private static function sumSeries(array $series): array
    {
        $views = 0;
        $visitors = 0;
        foreach ($series as $row) {
            $views += $row['views'];
            // NOTE: summing per-day EXACT visitor counts across days is not
            // itself a distinct-visitor count over the whole range (the same
            // visitor could appear on multiple days) - it is presented as
            // "visitor-days" in the UI's tooltip. A true range-wide unique
            // count would require merging sketches across days, which
            // daily_totals does not store (it is exact-only, no sketch column
            // by design - see AnalyticsSchema). This matches how most
            // lightweight analytics tools report multi-day unique counts.
            $visitors += $row['visitors'];
        }
        return ['views' => $views, 'visitors' => $visitors];
    }

    /**
     * @return array<int, array{value:string, views:int}>
     */
    private static function topForDimension(PDO $db, string $host, string $startDay, string $endDay, string $dimension, int $limit, ?int $dow = null): array
    {
        $safeColumn = self::assertFilterableDimension($dimension);

        $dowSql = '';
        $params = [$host, $startDay, $endDay];
        if ($dow !== null && $dow >= 0 && $dow <= 6) {
            $dowSql = ' AND ((CAST(strftime(\'%w\', day) AS INTEGER) + 6) % 7) = CAST(? AS INTEGER)';
            $params[] = $dow;
        }
        $params[] = $limit;

        $stmt = $db->prepare("
            SELECT {$safeColumn} AS value, SUM(views) AS views
            FROM " . AnalyticsSchema::TABLE_DAILY_FACTS . "
            WHERE host = ? AND day BETWEEN ? AND ?{$dowSql}
            GROUP BY {$safeColumn}
            ORDER BY views DESC
            LIMIT ?
        ");
        $stmt->execute($params);

        $result = [];
        foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
            $result[] = ['value' => (string) $row['value'], 'views' => (int) $row['views']];
        }
        return $result;
    }

    // =========================================================================
    // EXPLORE
    // =========================================================================

    /**
     * @param array<string, string> $filters dimension => exact-match value (ANDed)
     * @param string|null $breakdown Dimension to group results by; null = single aggregate row
     * @param string $sortBy Accepted for API stability; the only ordering
     *        SQL can perform is by exact `views` (visitors is a sketch-based
     *        estimate merged in PHP per row and cannot be summed/sorted in
     *        SQL), so this parameter is currently always views-ordered.
     * @param string $sortDir 'asc' or 'desc'
     * @return array{
     *   range:array{start:string,end:string},
     *   filters:array<string,string>,
     *   breakdown:?string,
     *   approximate:bool,
     *   rows:array<int,array{group:?string,views:int,visitors:int}>,
     *   total:array{views:int,visitors:int},
     *   pagination:array{page:int,pageSize:int,total_groups:int,total_pages:int}
     * }
     */
    public static function explore(
        string $host,
        string $startDay,
        string $endDay,
        array $filters = [],
        ?string $breakdown = null,
        int $page = 1,
        int $pageSize = 50,
        string $sortBy = 'views',
        string $sortDir = 'desc'
    ): array {
        AnalyticsSchema::ensureTables();
        self::assertValidRange($startDay, $endDay);

        $db = AnalyticsSchema::db();

        $page = max(1, $page);
        $pageSize = max(1, min(500, $pageSize));

        $where = ['host = ?', 'day BETWEEN ? AND ?'];
        $params = [$host, $startDay, $endDay];

        foreach ($filters as $dimension => $value) {
            $safeColumn = self::assertFilterableDimension($dimension);
            $where[] = "{$safeColumn} = ?";
            $params[] = (string) $value;
        }

        $whereClause = implode(' AND ', $where);

        if ($breakdown !== null) {
            $safeBreakdown = self::assertFilterableDimension($breakdown);
            $rows = self::exploreBreakdown($db, $whereClause, $params, $safeBreakdown, $page, $pageSize, $sortDir);
            $totalGroups = self::countBreakdownGroups($db, $whereClause, $params, $safeBreakdown);
        } else {
            $rows = [self::exploreSingleAggregate($db, $whereClause, $params)];
            $totalGroups = 1;
        }

        $total = self::exploreSingleAggregate($db, $whereClause, $params);

        $totalPages = $totalGroups > 0 ? (int) ceil($totalGroups / $pageSize) : 0;

        return [
            'range' => ['start' => $startDay, 'end' => $endDay],
            'filters' => $filters,
            'breakdown' => $breakdown,
            'approximate' => true, // Visitor figures in explore() are ALWAYS sketch-based estimates.
            'rows' => $rows,
            'total' => ['views' => $total['views'], 'visitors' => $total['visitors']],
            'pagination' => [
                'page' => $page,
                'pageSize' => $pageSize,
                'total_groups' => $totalGroups,
                'total_pages' => $totalPages,
            ],
        ];
    }

    /**
     * Count how many distinct breakdown-column values match the current
     * filter/range - the denominator the Explore UI needs to render real
     * page numbers (page 3 of 12) instead of just "next/prev" blindly.
     *
     * @param array<int, mixed> $params
     */
    private static function countBreakdownGroups(PDO $db, string $whereClause, array $params, string $breakdownColumn): int
    {
        $stmt = $db->prepare("
            SELECT COUNT(*) FROM (
                SELECT 1 FROM " . AnalyticsSchema::TABLE_DAILY_FACTS . "
                WHERE {$whereClause}
                GROUP BY {$breakdownColumn}
            )
        ");
        $stmt->execute($params);
        return (int) ($stmt->fetchColumn() ?: 0);
    }

    /**
     * @param array<int, mixed> $params
     * @return array<int, array{group:string, views:int, visitors:int}>
     */
    private static function exploreBreakdown(
        PDO $db,
        string $whereClause,
        array $params,
        string $breakdownColumn,
        int $page,
        int $pageSize,
        string $sortDir
    ): array {
        $page = max(1, $page);
        $pageSize = max(1, min(500, $pageSize));
        $offset = ($page - 1) * $pageSize;
        $sortDir = strtolower($sortDir) === 'asc' ? 'ASC' : 'DESC';

        // Sketches are BLOBs, so they cannot be merged in SQL (GROUP_CONCAT
        // over binary data is unreliable across drivers). Two-step approach:
        // first find which group values are in range/filtered, ordered/paged
        // by exact views; then fetch each group's raw rows and merge their
        // sketches in PHP.
        $orderStmt = $db->prepare("
            SELECT {$breakdownColumn} AS group_value, SUM(views) AS views
            FROM " . AnalyticsSchema::TABLE_DAILY_FACTS . "
            WHERE {$whereClause}
            GROUP BY {$breakdownColumn}
            ORDER BY views {$sortDir}
            LIMIT ? OFFSET ?
        ");
        $orderStmt->execute(array_merge($params, [$pageSize, $offset]));
        $groups = $orderStmt->fetchAll(PDO::FETCH_ASSOC);

        $rows = [];
        foreach ($groups as $group) {
            $groupValue = (string) $group['group_value'];

            $detailStmt = $db->prepare("
                SELECT sketch, sketch_mode FROM " . AnalyticsSchema::TABLE_DAILY_FACTS . "
                WHERE {$whereClause} AND {$breakdownColumn} = ?
            ");
            $detailStmt->execute(array_merge($params, [$groupValue]));

            $merged = VisitorSketch::createEmpty();
            foreach ($detailStmt->fetchAll(PDO::FETCH_ASSOC) as $detailRow) {
                if ($detailRow['sketch'] === null) {
                    continue;
                }
                $merged = $merged->merge(VisitorSketch::deserialize((string) $detailRow['sketch'], (string) $detailRow['sketch_mode']));
            }

            $rows[] = [
                'group' => $groupValue,
                'views' => (int) $group['views'],
                'visitors' => $merged->estimate(),
            ];
        }

        return $rows;
    }

    /**
     * @param array<int, mixed> $params
     * @return array{group:null, views:int, visitors:int}
     */
    private static function exploreSingleAggregate(PDO $db, string $whereClause, array $params): array
    {
        $viewsStmt = $db->prepare("SELECT SUM(views) AS views FROM " . AnalyticsSchema::TABLE_DAILY_FACTS . " WHERE {$whereClause}");
        $viewsStmt->execute($params);
        $views = (int) ($viewsStmt->fetchColumn() ?: 0);

        $sketchStmt = $db->prepare("SELECT sketch, sketch_mode FROM " . AnalyticsSchema::TABLE_DAILY_FACTS . " WHERE {$whereClause}");
        $sketchStmt->execute($params);

        $merged = VisitorSketch::createEmpty();
        foreach ($sketchStmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
            if ($row['sketch'] === null) {
                continue;
            }
            $merged = $merged->merge(VisitorSketch::deserialize((string) $row['sketch'], (string) $row['sketch_mode']));
        }

        return ['group' => null, 'views' => $views, 'visitors' => $merged->estimate()];
    }

    // =========================================================================
    // BATCH UTM-COMBINATION METRICS (Campaign Builder - no N+1)
    // =========================================================================

    /**
     * Views/visitors for MULTIPLE UTM combinations in a single pass over
     * daily_facts, instead of one explore() call per combination. Built for
     * the Campaign Builder's list view: with N saved campaigns, calling
     * explore() once per campaign would mean N sets of queries (and N
     * separate sketch-merge passes) on every page load - this method issues
     * exactly ONE query for the views SUM and ONE for the sketch rows,
     * covering every requested combination at once, then buckets/merges the
     * results in PHP.
     *
     * Rows are matched by the SAME five UTM columns explore() filters on
     * (utm_source/medium/campaign/term/content), scoped to $host and the
     * last $days days - deliberately NOT by base_url, since daily_facts has
     * no base_url column (that is Campaign Builder metadata, not a beacon
     * dimension). Two campaigns sharing identical UTM values but different
     * base_urls will therefore report the SAME traffic figures for that UTM
     * combination - this mirrors how the beacon itself does not distinguish
     * traffic by "which saved campaign a link belongs to", only by the UTM
     * values actually present on the incoming request.
     *
     * @param array<int, array{utm_source:string, utm_medium:string, utm_campaign:string, utm_term:string, utm_content:string}> $combinations
     * @param string|null $endDay Y-m-d, inclusive; defaults to today. Exposed as a parameter
     *        (rather than always using date('Y-m-d')) so callers - including
     *        tests - can anchor the range explicitly instead of depending on
     *        wall-clock "now", matching how overview()/explore() take explicit
     *        start/end days rather than computing them internally.
     * @return array<string, array{views:int, visitors:int, approximate:bool}> Keyed by combinationKey() of each input combination
     */
    public static function metricsForUtmCombinations(string $host, array $combinations, int $days = 30, ?string $endDay = null): array
    {
        AnalyticsSchema::ensureTables();

        if (empty($combinations)) {
            return [];
        }

        $db = AnalyticsSchema::db();

        $endDay ??= date('Y-m-d');
        $startDay = date('Y-m-d', strtotime($endDay . ' -' . max(1, $days - 1) . ' days'));

        // Build "(utm_source=? AND utm_medium=? AND utm_campaign=? AND utm_term=? AND utm_content=?) OR (...)"
        // - one bracketed AND-group per combination, ORed together - so the
        // whole batch is answerable in a single WHERE clause.
        $orGroups = [];
        $params = [$host, $startDay, $endDay];
        $seenKeys = [];

        foreach ($combinations as $combo) {
            $key = self::combinationKey($combo);
            if (isset($seenKeys[$key])) {
                continue; // De-duplicate identical combinations before hitting the DB.
            }
            $seenKeys[$key] = true;

            $orGroups[] = '(utm_source = ? AND utm_medium = ? AND utm_campaign = ? AND utm_term = ? AND utm_content = ?)';
            $params[] = $combo['utm_source'];
            $params[] = $combo['utm_medium'];
            $params[] = $combo['utm_campaign'];
            $params[] = $combo['utm_term'];
            $params[] = $combo['utm_content'];
        }

        if (empty($orGroups)) {
            return [];
        }

        $whereClause = 'host = ? AND day BETWEEN ? AND ? AND (' . implode(' OR ', $orGroups) . ')';

        $rowsStmt = $db->prepare('
            SELECT utm_source, utm_medium, utm_campaign, utm_term, utm_content, views, sketch, sketch_mode
            FROM ' . AnalyticsSchema::TABLE_DAILY_FACTS . "
            WHERE {$whereClause}
        ");
        $rowsStmt->execute($params);

        /** @var array<string, array{views:int, sketch:VisitorSketch}> $buckets */
        $buckets = [];
        foreach ($rowsStmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
            $key = self::combinationKey([
                'utm_source' => (string) $row['utm_source'],
                'utm_medium' => (string) $row['utm_medium'],
                'utm_campaign' => (string) $row['utm_campaign'],
                'utm_term' => (string) $row['utm_term'],
                'utm_content' => (string) $row['utm_content'],
            ]);

            if (!isset($buckets[$key])) {
                $buckets[$key] = ['views' => 0, 'sketch' => VisitorSketch::createEmpty()];
            }

            $buckets[$key]['views'] += (int) $row['views'];

            if ($row['sketch'] !== null) {
                $buckets[$key]['sketch'] = $buckets[$key]['sketch']->merge(
                    VisitorSketch::deserialize((string) $row['sketch'], (string) $row['sketch_mode'])
                );
            }
        }

        $result = [];
        foreach (array_keys($seenKeys) as $key) {
            $bucket = $buckets[$key] ?? null;
            $result[$key] = [
                'views' => $bucket !== null ? $bucket['views'] : 0,
                'visitors' => $bucket !== null ? $bucket['sketch']->estimate() : 0,
                'approximate' => true,
            ];
        }

        return $result;
    }

    /**
     * Deterministic key for a UTM combination - used both to de-duplicate
     * requested combinations and to bucket matching daily_facts rows, so the
     * two sides can be joined in PHP without a database-side GROUP BY across
     * a synthetic OR'd query (SQLite has no clean way to GROUP BY "which OR
     * branch matched"). Public so callers (e.g. the admin endpoint mapping
     * saved campaigns to their metrics) can compute the same key for a
     * campaign row without duplicating the concatenation logic.
     *
     * @param array{utm_source:string, utm_medium:string, utm_campaign:string, utm_term:string, utm_content:string} $combo
     */
    public static function combinationKey(array $combo): string
    {
        return implode("\x1f", [
            $combo['utm_source'],
            $combo['utm_medium'],
            $combo['utm_campaign'],
            $combo['utm_term'],
            $combo['utm_content'],
        ]);
    }

    // =========================================================================
    // CSV EXPORT (Explore results)
    // =========================================================================

    /**
     * @param array<string, string> $filters
     * @return string CSV content (with header row)
     */
    public static function exploreCsv(
        string $host,
        string $startDay,
        string $endDay,
        array $filters = [],
        ?string $breakdown = null
    ): string {
        $result = self::explore($host, $startDay, $endDay, $filters, $breakdown, 1, 5000, 'views', 'desc');

        $lines = [];
        $groupHeader = $breakdown ?? 'group';
        $lines[] = implode(',', [self::csvEscape($groupHeader), 'views', 'visitors_estimate']);

        foreach ($result['rows'] as $row) {
            $lines[] = implode(',', [
                self::csvEscape((string) ($row['group'] ?? 'total')),
                (string) $row['views'],
                (string) $row['visitors'],
            ]);
        }

        return implode("\r\n", $lines) . "\r\n";
    }

    private static function csvEscape(string $value): string
    {
        if (preg_match('/[",\r\n]/', $value)) {
            return '"' . str_replace('"', '""', $value) . '"';
        }
        return $value;
    }

    // =========================================================================
    // DIAGNOSTICS (pipeline / ingest health - read-only, admin-facing)
    // =========================================================================

    /**
     * Snapshot of the ingest/aggregation pipeline's health, entirely from
     * existing tables + the spool directory - never mutates anything. Meant
     * to answer "is the pipeline keeping up?" without needing shell/log
     * access: raw buffer size, per-spool-file ingest backlog, finalization
     * progress, and aggregated-table sizes.
     *
     * @return array{
     *   raw_events: array{total:int, oldest_day:?string, newest_day:?string},
     *   spool: array{files:int, pending_bytes:int, files_detail:array<int,array{file:string,size_bytes:int,offset_bytes:int,pending_bytes:int,completed:bool}>},
     *   daily_totals: array{rows:int, finalized:int, unfinalized:int, last_updated_at:?string},
     *   daily_facts: array{rows:int},
     *   settings_enabled: bool
     * }
     */
    public static function diagnostics(): array
    {
        AnalyticsSchema::ensureTables();
        $db = AnalyticsSchema::db();

        // --- Raw event buffer ---------------------------------------------
        $rawStmt = $db->prepare('SELECT COUNT(*) AS total, MIN(day) AS oldest_day, MAX(day) AS newest_day FROM ' . AnalyticsSchema::TABLE_EVENTS);
        $rawStmt->execute();
        $rawRow = $rawStmt->fetch(PDO::FETCH_ASSOC);
        if (!is_array($rawRow)) {
            $rawRow = ['total' => 0, 'oldest_day' => null, 'newest_day' => null];
        }

        // --- Spool backlog (per file: size on disk vs ingested offset) ----
        $filesDetail = [];
        $pendingBytesTotal = 0;
        foreach (SpoolWriter::listSpoolFiles() as $spoolFile) {
            $size = is_file($spoolFile) ? (int) filesize($spoolFile) : 0;
            $offset = SpoolIngestService::getOffset($spoolFile);
            $pending = max(0, $size - $offset);
            $pendingBytesTotal += $pending;

            $filesDetail[] = [
                'file' => basename($spoolFile),
                'size_bytes' => $size,
                'offset_bytes' => $offset,
                'pending_bytes' => $pending,
                'completed' => self::isSpoolFileCompleted($db, basename($spoolFile)),
            ];
        }

        // --- daily_totals / daily_facts sizes + finalization progress -----
        $totalsStmt = $db->prepare('
            SELECT COUNT(*) AS rows_count,
                   SUM(CASE WHEN finalized = 1 THEN 1 ELSE 0 END) AS finalized_count,
                   SUM(CASE WHEN finalized = 0 THEN 1 ELSE 0 END) AS unfinalized_count,
                   MAX(updated_at) AS last_updated_at
            FROM ' . AnalyticsSchema::TABLE_DAILY_TOTALS);
        $totalsStmt->execute();
        $totalsRow = $totalsStmt->fetch(PDO::FETCH_ASSOC);
        if (!is_array($totalsRow)) {
            $totalsRow = [];
        }

        $factsStmt = $db->prepare('SELECT COUNT(*) AS rows_count FROM ' . AnalyticsSchema::TABLE_DAILY_FACTS);
        $factsStmt->execute();
        $factsRow = $factsStmt->fetch(PDO::FETCH_ASSOC);
        if (!is_array($factsRow)) {
            $factsRow = ['rows_count' => 0];
        }

        $lastUpdatedAt = $totalsRow['last_updated_at'] ?? null;

        // --- Storage & Capacity Diagnostics -------------------------------
        $storageBytes = AnalyticsRetentionService::getAnalyticsStorageBytes();
        $quotaMb = AnalyticsSettingsService::getInstance()->getMaxStorageMb();

        $historyStmt = $db->query('
            SELECT COUNT(DISTINCT day) AS days_count,
                   MIN(day) AS oldest_day,
                   MAX(day) AS newest_day,
                   SUM(views) AS total_views
            FROM ' . AnalyticsSchema::TABLE_DAILY_TOTALS
        );
        $historyRow = $historyStmt ? $historyStmt->fetch(PDO::FETCH_ASSOC) : null;
        $daysStored = (int) ($historyRow['days_count'] ?? 0);
        $totalViews = (int) ($historyRow['total_views'] ?? 0);
        $oldestDay = $historyRow['oldest_day'] ?? null;
        $newestDay = $historyRow['newest_day'] ?? null;

        // Daily average storage consumption
        $avgBytesPerDay = $daysStored > 0
            ? (int) round($storageBytes / $daysStored)
            : 50_000; // Baseline fallback (~50KB/day)

        $avgBytesPerView = ($totalViews > 0)
            ? round($storageBytes / $totalViews, 2)
            : 45.0;

        $quotaBytes = $quotaMb > 0 ? $quotaMb * 1024 * 1024 : 0;
        $usedPercent = $quotaBytes > 0 ? min(100.0, round(($storageBytes / $quotaBytes) * 100, 1)) : 0.0;
        $remainingBytes = $quotaBytes > 0 ? max(0, $quotaBytes - $storageBytes) : null;

        $capacityDays = null;
        $capacityHours = null;
        $capacityWeeks = null;
        $capacityMonths = null;
        $capacityYears = null;

        if ($quotaBytes > 0 && $avgBytesPerDay > 0) {
            $capacityDays = round($quotaBytes / $avgBytesPerDay, 1);
            $capacityHours = round($capacityDays * 24, 0);
            $capacityWeeks = round($capacityDays / 7, 1);
            $capacityMonths = round($capacityDays / 30.4375, 1);
            $capacityYears = round($capacityDays / 365.25, 2);
        }

        return [
            'raw_events' => [
                'total' => (int) $rawRow['total'],
                'oldest_day' => $rawRow['oldest_day'] !== null ? (string) $rawRow['oldest_day'] : null,
                'newest_day' => $rawRow['newest_day'] !== null ? (string) $rawRow['newest_day'] : null,
            ],
            'spool' => [
                'files' => count($filesDetail),
                'pending_bytes' => $pendingBytesTotal,
                'files_detail' => $filesDetail,
            ],
            'daily_totals' => [
                'rows' => (int) ($totalsRow['rows_count'] ?? 0),
                'finalized' => (int) ($totalsRow['finalized_count'] ?? 0),
                'unfinalized' => (int) ($totalsRow['unfinalized_count'] ?? 0),
                'last_updated_at' => $lastUpdatedAt !== null ? (string) $lastUpdatedAt : null,
            ],
            'daily_facts' => [
                'rows' => (int) $factsRow['rows_count'],
            ],
            'storage' => [
                'current_bytes' => $storageBytes,
                'current_mb' => round($storageBytes / (1024 * 1024), 2),
                'quota_mb' => $quotaMb,
                'used_percent' => $usedPercent,
                'days_stored' => $daysStored,
                'total_views' => $totalViews,
                'oldest_day' => $oldestDay,
                'newest_day' => $newestDay,
                'avg_bytes_per_day' => $avgBytesPerDay,
                'avg_bytes_per_view' => $avgBytesPerView,
                'remaining_bytes' => $remainingBytes,
                'capacity' => [
                    'hours' => $capacityHours,
                    'days' => $capacityDays,
                    'weeks' => $capacityWeeks,
                    'months' => $capacityMonths,
                    'years' => $capacityYears,
                ],
            ],
            'settings_enabled' => AnalyticsSettingsService::getInstance()->isEnabled(),
        ];
    }

    private static function isSpoolFileCompleted(PDO $db, string $spoolFileBasename): bool
    {
        $stmt = $db->prepare('SELECT completed FROM ' . AnalyticsSchema::TABLE_INGEST_STATE . ' WHERE spool_file = ?');
        $stmt->execute([$spoolFileBasename]);
        $value = $stmt->fetchColumn();
        return $value !== false && (int) $value === 1;
    }

    // =========================================================================
    // HEATMAP (0-PII Time-Series Heatmap)
    // =========================================================================

    /**
     * @param string $host
     * @param string $startDay
     * @param string $endDay
     * @param string $type 'punchcard' | 'calendar'
     * @return array<string, mixed>
     */
    public static function heatmap(string $host, string $startDay, string $endDay, string $type = 'punchcard'): array
    {
        AnalyticsSchema::ensureTables();
        self::assertValidRange($startDay, $endDay);

        $db = AnalyticsSchema::db();

        if ($type === 'calendar') {
            return self::calendarHeatmap($db, $host, $startDay, $endDay);
        }

        return self::punchcardHeatmap($db, $host, $startDay, $endDay);
    }

    /**
     * 7 days of week (0=Mon..6=Sun) x 24 hours (0..23) activity punchcard.
     * Sourced from massive_analytics_hourly_totals only - 0 PII, exact aggregate numbers.
     *
     * @return array<string, mixed>
     */
    private static function punchcardHeatmap(PDO $db, string $host, string $startDay, string $endDay): array
    {
        $stmt = $db->prepare('
            SELECT 
                CAST(strftime(\'%w\', day) AS INTEGER) AS sqlite_dow,
                hour,
                SUM(views) AS views,
                SUM(visitors) AS visitors
            FROM ' . AnalyticsSchema::TABLE_HOURLY_TOTALS . '
            WHERE host = ? AND day BETWEEN ? AND ?
            GROUP BY sqlite_dow, hour
        ');
        $stmt->execute([$host, $startDay, $endDay]);
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Pre-populate 7 days (0=Mon..6=Sun) x 24 hours (0..23)
        $matrixMap = [];
        for ($d = 0; $d < 7; $d++) {
            for ($h = 0; $h < 24; $h++) {
                $matrixMap[$d][$h] = [
                    'dow' => $d,
                    'hour' => $h,
                    'views' => 0,
                    'visitors' => 0,
                ];
            }
        }

        $totalsByDow = array_fill(0, 7, ['views' => 0, 'visitors' => 0]);
        $totalsByHour = array_fill(0, 24, ['views' => 0, 'visitors' => 0]);
        $totalViews = 0;
        $totalVisitors = 0;
        $maxViews = 0;
        $maxVisitors = 0;
        $peak = ['dow' => 0, 'hour' => 12, 'views' => 0, 'visitors' => 0];

        foreach ($rows as $row) {
            $sqliteDow = (int) $row['sqlite_dow'];
            $isoDow = ($sqliteDow === 0) ? 6 : ($sqliteDow - 1); // 0=Mon, ..., 6=Sun
            $hour = (int) $row['hour'];
            $views = (int) $row['views'];
            $visitors = (int) $row['visitors'];

            if ($hour >= 0 && $hour < 24 && $isoDow >= 0 && $isoDow < 7) {
                $matrixMap[$isoDow][$hour] = [
                    'dow' => $isoDow,
                    'hour' => $hour,
                    'views' => $views,
                    'visitors' => $visitors,
                ];

                $totalsByDow[$isoDow]['views'] += $views;
                $totalsByDow[$isoDow]['visitors'] += $visitors;
                $totalsByHour[$hour]['views'] += $views;
                $totalsByHour[$hour]['visitors'] += $visitors;

                $totalViews += $views;
                $totalVisitors += $visitors;

                if ($views > $maxViews) {
                    $maxViews = $views;
                    $peak = ['dow' => $isoDow, 'hour' => $hour, 'views' => $views, 'visitors' => $visitors];
                }
                if ($visitors > $maxVisitors) {
                    $maxVisitors = $visitors;
                }
            }
        }

        // Flatten matrix into a list of 168 cells
        $matrix = [];
        for ($d = 0; $d < 7; $d++) {
            for ($h = 0; $h < 24; $h++) {
                $matrix[] = $matrixMap[$d][$h];
            }
        }

        return [
            'type' => 'punchcard',
            'range' => ['start' => $startDay, 'end' => $endDay],
            'matrix' => $matrix,
            'peak' => $peak,
            'totals_by_dow' => $totalsByDow,
            'totals_by_hour' => $totalsByHour,
            'total_views' => $totalViews,
            'total_visitors' => $totalVisitors,
            'max_views' => $maxViews,
            'max_visitors' => $maxVisitors,
        ];
    }

    /**
     * Daily calendar intensity series across the date range.
     * Sourced from massive_analytics_daily_totals only.
     *
     * @return array<string, mixed>
     */
    private static function calendarHeatmap(PDO $db, string $host, string $startDay, string $endDay): array
    {
        $stmt = $db->prepare('
            SELECT day, views, visitors
            FROM ' . AnalyticsSchema::TABLE_DAILY_TOTALS . '
            WHERE host = ? AND day BETWEEN ? AND ?
            ORDER BY day ASC
        ');
        $stmt->execute([$host, $startDay, $endDay]);
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $days = [];
        $maxViews = 0;
        $maxVisitors = 0;
        $totalViews = 0;
        $totalVisitors = 0;

        foreach ($rows as $row) {
            $day = (string) $row['day'];
            $views = (int) $row['views'];
            $visitors = (int) $row['visitors'];
            $sqliteDow = (int) date('w', strtotime($day));
            $isoDow = ($sqliteDow === 0) ? 6 : ($sqliteDow - 1);

            $days[] = [
                'day' => $day,
                'dow' => $isoDow,
                'views' => $views,
                'visitors' => $visitors,
            ];

            $totalViews += $views;
            $totalVisitors += $visitors;
            if ($views > $maxViews) $maxViews = $views;
            if ($visitors > $maxVisitors) $maxVisitors = $visitors;
        }

        return [
            'type' => 'calendar',
            'range' => ['start' => $startDay, 'end' => $endDay],
            'days' => $days,
            'total_views' => $totalViews,
            'total_visitors' => $totalVisitors,
            'max_views' => $maxViews,
            'max_visitors' => $maxVisitors,
        ];
    }

    // =========================================================================
    // VALIDATION HELPERS
    // =========================================================================

    private static function assertValidRange(string $startDay, string $endDay): void
    {
        if (!self::isValidDay($startDay) || !self::isValidDay($endDay)) {
            throw new \InvalidArgumentException('Invalid date format, expected Y-m-d');
        }
        if ($startDay > $endDay) {
            throw new \InvalidArgumentException('start day must not be after end day');
        }
        if (self::daysBetweenInclusive($startDay, $endDay) > self::MAX_RANGE_DAYS) {
            throw new \InvalidArgumentException('Date range exceeds maximum of ' . self::MAX_RANGE_DAYS . ' days');
        }
    }

    private static function isValidDay(string $day): bool
    {
        $parsed = \DateTime::createFromFormat('Y-m-d', $day);
        return $parsed !== false && $parsed->format('Y-m-d') === $day;
    }

    private static function daysBetweenInclusive(string $startDay, string $endDay): int
    {
        $start = new \DateTime($startDay);
        $end = new \DateTime($endDay);
        return (int) $start->diff($end)->days + 1;
    }

    private static function deltaPct(int $previous, int $current): ?float
    {
        if ($previous === 0) {
            return null; // Undefined percentage change from zero - the UI shows "new" instead of a number.
        }
        return round((($current - $previous) / $previous) * 100, 1);
    }

    private static function assertFilterableDimension(string $dimension): string
    {
        if (!in_array($dimension, self::FILTERABLE_DIMENSIONS, true)) {
            throw new \InvalidArgumentException("Unknown or non-filterable dimension: {$dimension}");
        }
        return $dimension;
    }
}
