<?php
/**
 * NOMAD CMS - Analytics Schema
 *
 * Central definition of the storage layout used by the native, 0-PII,
 * privacy-first Analytics module.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * WHY NOT MassiveDatabase's JSON-slot API
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * MassiveDatabase::ensureTable() gives every "massive" slot a generic
 * (id, data JSON, owner_uuid, created_at, updated_at) shape plus an FTS5
 * companion table. That fits documents (form submissions, subscriber rows),
 * but analytics needs none of it and pays for all of it:
 *
 *   - GROUP BY / COUNT(DISTINCT visitor_hash) on json_extract() expressions
 *     cannot use a real column index the way a native column can.
 *   - FTS5 indexing is pure overhead for numeric/dimension data nobody
 *     full-text searches.
 *   - The retention sweep deletes by day in bulk; a real indexed `day` column
 *     makes that a range delete instead of a table scan.
 *
 * This mirrors the precedent already set by FormRateLimiter (see
 * FormsSchema.php): the moment a table needs atomic counters or GROUP BY at
 * volume, it gets real columns instead of the generic JSON-slot shape, while
 * still living in the same physical massive.sqlite file via
 * MassiveDatabase::getInstance().
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * STORAGE MODEL (two-tier, see docs/analytics.md for the full rationale)
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *   analytics_events        raw event buffer. Rows only exist for days not yet
 *                            finalized by AggregationService, and are purged by
 *                            AnalyticsRetentionService shortly after finalization
 *                            (default: 48h). This table can NEVER grow forever.
 *
 *   analytics_daily_totals  one row per (day, host): exact pageviews and EXACT
 *                            unique visitors (COUNT(DISTINCT visitor_hash) over
 *                            the raw buffer while it still exists for that day).
 *                            This is the headline number shown in the UI and is
 *                            never approximate.
 *
 *   analytics_daily_facts   one row per (day, host, path, referrer_domain,
 *                            device, country, utm_*) dimension tuple: exact
 *                            views plus a mergeable HyperLogLog/sparse visitor
 *                            SKETCH (see VisitorSketch). Any ad-hoc filter
 *                            combination the Explore UI builds is a UNION of
 *                            these rows, and sketches are union-mergeable, so
 *                            "unique visitors under an arbitrary filter" stays
 *                            answerable WITHOUT re-touching raw events that have
 *                            already been purged.
 *
 *   analytics_ingest_state  single-row cursor: which spool files have been
 *                           consumed, byte offset within the current file, and
 *                           which days have been finalized.
 *
 *   analytics_settings      key/value settings store (CacheSettingsService
 *                           pattern): DB setting > .env fallback > hard default.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * ZERO PII BY CONSTRUCTION
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * No column in this schema can hold a raw IP address, a User-Agent string, or
 * any other directly identifying value. `visitor_hash` is a truncated (64-bit)
 * SHA-256 digest of a /24-or-/48-truncated IP + UA, salted with a salt that is
 * rotated and DELETED daily (see VisitorHashService) - once the salt is gone,
 * the hash cannot be reversed or linked across days, even by someone holding
 * the raw massive.sqlite file.
 *
 * @package NomadCMS\Services\Analytics
 */

declare(strict_types=1);

namespace NomadCMS\Services\Analytics;

use NomadCMS\Database\MassiveDatabase;
use PDO;

final class AnalyticsSchema
{
    /** Physical table names */
    public const TABLE_EVENTS = 'massive_analytics_events';
    public const TABLE_DAILY_TOTALS = 'massive_analytics_daily_totals';
    public const TABLE_DAILY_FACTS = 'massive_analytics_daily_facts';
    public const TABLE_HOURLY_TOTALS = 'massive_analytics_hourly_totals';
    public const TABLE_INGEST_STATE = 'massive_analytics_ingest_state';
    public const TABLE_SETTINGS = 'massive_analytics_settings';

    /** Device dimension buckets */
    public const DEVICE_DESKTOP = 'desktop';
    public const DEVICE_MOBILE = 'mobile';
    public const DEVICE_TABLET = 'tablet';
    public const DEVICE_OTHER = 'other';

    /** @var array<int, string> */
    public const DEVICES = [
        self::DEVICE_DESKTOP,
        self::DEVICE_MOBILE,
        self::DEVICE_TABLET,
        self::DEVICE_OTHER,
    ];

    /** Sentinel used in dimension columns instead of NULL/'' (keeps UNIQUE index well-defined) */
    public const DIM_NONE = '(none)';

    /** Overflow bucket for dimensions that exceed the per-day cardinality cap */
    public const DIM_OTHER = '(other)';

    /** Hard bounds for configurable settings (enforced regardless of stored value) */
    public const MIN_RETENTION_RAW_HOURS = 1;
    public const MAX_RETENTION_RAW_HOURS = 168; // 7 days
    public const MIN_RETENTION_DAILY_DAYS = 0; // 0 = keep forever
    public const MAX_RETENTION_DAILY_DAYS = 3650;
    public const MIN_MAX_STORAGE_MB = 0; // 0 = unlimited / disabled
    public const MAX_MAX_STORAGE_MB = 100_000; // 100 GB
    public const MIN_CARDINALITY_CAP = 10;
    public const MAX_CARDINALITY_CAP = 5000;
    public const MIN_DAILY_EVENT_CAP = 100;
    public const MAX_DAILY_EVENT_CAP = 5_000_000;

    /** Default per-dimension daily cardinality cap before values fold into DIM_OTHER */
    public const DEFAULT_CARDINALITY_CAP = 500;

    /** Default max events accepted into the spool per host per day (abuse ceiling) */
    public const DEFAULT_DAILY_EVENT_CAP = 200_000;

    /** Default raw-buffer retention after a day is finalized */
    public const DEFAULT_RETENTION_RAW_HOURS = 48;

    /** Default aggregated-data retention (0 = forever) */
    public const DEFAULT_RETENTION_DAILY_DAYS = 0;

    /** Default max storage quota in MB (0 = unlimited) */
    public const DEFAULT_MAX_STORAGE_MB = 0;

    /**
     * Guard so the (idempotent but not free) schema check runs once per
     * process instead of once per call - same rationale as
     * FormsSchema::$tablesReady.
     */
    private static bool $tablesReady = false;

    /** Shared PDO handle - same physical file as MassiveDatabase, no JSON-slot wrapping */
    public static function db(): PDO
    {
        return MassiveDatabase::getInstance();
    }

    /**
     * Create every analytics table (and its indexes) if missing. Idempotent.
     */
    public static function ensureTables(): void
    {
        if (self::$tablesReady) {
            return;
        }

        $db = self::db();

        $db->exec('
            CREATE TABLE IF NOT EXISTS ' . self::TABLE_EVENTS . ' (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                ts INTEGER NOT NULL,
                day TEXT NOT NULL,
                host TEXT NOT NULL,
                path TEXT NOT NULL,
                referrer_domain TEXT NOT NULL DEFAULT ' . self::sqlDefault(self::DIM_NONE) . ',
                device TEXT NOT NULL DEFAULT ' . self::sqlDefault(self::DEVICE_OTHER) . ',
                country TEXT NOT NULL DEFAULT ' . self::sqlDefault(self::DIM_NONE) . ',
                utm_source TEXT NOT NULL DEFAULT ' . self::sqlDefault(self::DIM_NONE) . ',
                utm_medium TEXT NOT NULL DEFAULT ' . self::sqlDefault(self::DIM_NONE) . ',
                utm_campaign TEXT NOT NULL DEFAULT ' . self::sqlDefault(self::DIM_NONE) . ',
                utm_term TEXT NOT NULL DEFAULT ' . self::sqlDefault(self::DIM_NONE) . ',
                utm_content TEXT NOT NULL DEFAULT ' . self::sqlDefault(self::DIM_NONE) . ',
                visitor_hash TEXT NOT NULL
            )
        ');
        $db->exec('CREATE INDEX IF NOT EXISTS idx_analytics_events_day ON ' . self::TABLE_EVENTS . '(day)');
        $db->exec('CREATE INDEX IF NOT EXISTS idx_analytics_events_day_visitor ON ' . self::TABLE_EVENTS . '(day, visitor_hash)');
        $db->exec('CREATE INDEX IF NOT EXISTS idx_analytics_events_day_path ON ' . self::TABLE_EVENTS . '(day, path)');

        $db->exec('
            CREATE TABLE IF NOT EXISTS ' . self::TABLE_DAILY_TOTALS . ' (
                day TEXT NOT NULL,
                host TEXT NOT NULL,
                views INTEGER NOT NULL DEFAULT 0,
                visitors INTEGER NOT NULL DEFAULT 0,
                finalized INTEGER NOT NULL DEFAULT 0,
                updated_at TEXT DEFAULT (datetime(\'now\')),
                PRIMARY KEY (day, host)
            )
        ');
        $db->exec('CREATE INDEX IF NOT EXISTS idx_analytics_daily_totals_day ON ' . self::TABLE_DAILY_TOTALS . '(day)');

        $db->exec('
            CREATE TABLE IF NOT EXISTS ' . self::TABLE_DAILY_FACTS . ' (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                day TEXT NOT NULL,
                host TEXT NOT NULL,
                path TEXT NOT NULL,
                referrer_domain TEXT NOT NULL DEFAULT ' . self::sqlDefault(self::DIM_NONE) . ',
                device TEXT NOT NULL DEFAULT ' . self::sqlDefault(self::DEVICE_OTHER) . ',
                country TEXT NOT NULL DEFAULT ' . self::sqlDefault(self::DIM_NONE) . ',
                utm_source TEXT NOT NULL DEFAULT ' . self::sqlDefault(self::DIM_NONE) . ',
                utm_medium TEXT NOT NULL DEFAULT ' . self::sqlDefault(self::DIM_NONE) . ',
                utm_campaign TEXT NOT NULL DEFAULT ' . self::sqlDefault(self::DIM_NONE) . ',
                utm_term TEXT NOT NULL DEFAULT ' . self::sqlDefault(self::DIM_NONE) . ',
                utm_content TEXT NOT NULL DEFAULT ' . self::sqlDefault(self::DIM_NONE) . ',
                views INTEGER NOT NULL DEFAULT 0,
                sketch BLOB,
                sketch_mode TEXT NOT NULL DEFAULT \'sparse\',
                updated_at TEXT DEFAULT (datetime(\'now\')),
                UNIQUE (day, host, path, referrer_domain, device, country, utm_source, utm_medium, utm_campaign, utm_term, utm_content)
            )
        ');
        $db->exec('CREATE INDEX IF NOT EXISTS idx_analytics_daily_facts_day_host ON ' . self::TABLE_DAILY_FACTS . '(day, host)');
        $db->exec('CREATE INDEX IF NOT EXISTS idx_analytics_daily_facts_path ON ' . self::TABLE_DAILY_FACTS . '(day, host, path)');
        $db->exec('CREATE INDEX IF NOT EXISTS idx_analytics_daily_facts_referrer ON ' . self::TABLE_DAILY_FACTS . '(day, host, referrer_domain)');
        $db->exec('CREATE INDEX IF NOT EXISTS idx_analytics_daily_facts_utm_source ON ' . self::TABLE_DAILY_FACTS . '(day, host, utm_source)');

        $db->exec('
            CREATE TABLE IF NOT EXISTS ' . self::TABLE_HOURLY_TOTALS . ' (
                day TEXT NOT NULL,
                hour INTEGER NOT NULL,
                host TEXT NOT NULL,
                views INTEGER NOT NULL DEFAULT 0,
                visitors INTEGER NOT NULL DEFAULT 0,
                updated_at TEXT DEFAULT (datetime(\'now\')),
                PRIMARY KEY (day, hour, host)
            )
        ');
        $db->exec('CREATE INDEX IF NOT EXISTS idx_analytics_hourly_totals_day ON ' . self::TABLE_HOURLY_TOTALS . '(day)');
        $db->exec('CREATE INDEX IF NOT EXISTS idx_analytics_hourly_totals_host ON ' . self::TABLE_HOURLY_TOTALS . '(host, day)');

        $db->exec('
            CREATE TABLE IF NOT EXISTS ' . self::TABLE_INGEST_STATE . ' (
                spool_file TEXT PRIMARY KEY,
                byte_offset INTEGER NOT NULL DEFAULT 0,
                lines_ingested INTEGER NOT NULL DEFAULT 0,
                lines_failed INTEGER NOT NULL DEFAULT 0,
                completed INTEGER NOT NULL DEFAULT 0,
                updated_at TEXT DEFAULT (datetime(\'now\'))
            )
        ');

        $db->exec('
            CREATE TABLE IF NOT EXISTS ' . self::TABLE_SETTINGS . ' (
                key TEXT PRIMARY KEY,
                value TEXT NOT NULL,
                updated_at TEXT DEFAULT (datetime(\'now\'))
            )
        ');

        self::$tablesReady = true;
    }

    /**
     * Reset the in-process "tables ready" memoization (tests only: lets a
     * fresh test DB re-run ensureTables()).
     */
    public static function resetMemoization(): void
    {
        self::$tablesReady = false;
    }

    private static function sqlDefault(string $value): string
    {
        return "'" . str_replace("'", "''", $value) . "'";
    }
}
