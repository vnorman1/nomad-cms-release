<?php
/**
 * NOMAD CMS - Analytics Settings Service
 *
 * Database-backed settings for the 0-PII Analytics module, following the same
 * pattern as CacheSettingsService: DB setting > .env fallback > hard default.
 *
 * Kept intentionally admin-editable at runtime (unlike the Forms module, this
 * is a single, CMS-wide feature - there is no per-form equivalent) so an admin
 * can flip it on/off, change retention, or update the domain allowlist from the
 * Settings panel without touching .env or redeploying.
 *
 * @package NomadCMS\Services\Analytics
 */

declare(strict_types=1);

namespace NomadCMS\Services\Analytics;

use PDO;

final class AnalyticsSettingsService
{
    private const KEY_ENABLED = 'analytics.enabled';
    private const KEY_RETENTION_RAW_HOURS = 'analytics.retention_raw_hours';
    private const KEY_RETENTION_DAILY_DAYS = 'analytics.retention_daily_days';
    private const KEY_BOT_FILTER_ENABLED = 'analytics.bot_filter_enabled';
    private const KEY_DOMAIN_ALLOWLIST = 'analytics.domain_allowlist'; // comma-separated hosts, empty = any
    private const KEY_RESPECT_DNT = 'analytics.respect_dnt';
    private const KEY_CARDINALITY_CAP = 'analytics.cardinality_cap';
    private const KEY_DAILY_EVENT_CAP = 'analytics.daily_event_cap';
    private const KEY_PIGGYBACK_ENABLED = 'analytics.piggyback_enabled';
    private const KEY_WRAPPED_ENABLED = 'analytics.wrapped_enabled';
    private const KEY_MAX_STORAGE_MB = 'analytics.max_storage_mb';

    private static ?self $instance = null;

    private PDO $db;

    /** @var array<string, string>|null */
    private ?array $settingsCache = null;

    private function __construct()
    {
        AnalyticsSchema::ensureTables();
        $this->db = AnalyticsSchema::db();
    }

    public static function getInstance(): self
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /** Reset singleton (tests only) */
    public static function resetInstance(): void
    {
        self::$instance = null;
    }

    // =========================================================================
    // READ ACCESSORS
    // =========================================================================

    public function isEnabled(): bool
    {
        $dbSetting = $this->getSetting(self::KEY_ENABLED);
        if ($dbSetting !== null) {
            return $dbSetting === 'true';
        }
        return ($_ENV['ANALYTICS_ENABLED'] ?? 'true') === 'true';
    }

    public function getRetentionRawHours(): int
    {
        $value = $this->getSetting(self::KEY_RETENTION_RAW_HOURS);
        $value ??= $_ENV['ANALYTICS_RETENTION_RAW_HOURS'] ?? AnalyticsSchema::DEFAULT_RETENTION_RAW_HOURS;
        return self::clampInt(
            (int) $value,
            AnalyticsSchema::MIN_RETENTION_RAW_HOURS,
            AnalyticsSchema::MAX_RETENTION_RAW_HOURS,
            AnalyticsSchema::DEFAULT_RETENTION_RAW_HOURS
        );
    }

    /** 0 = keep forever */
    public function getRetentionDailyDays(): int
    {
        $value = $this->getSetting(self::KEY_RETENTION_DAILY_DAYS);
        $value ??= $_ENV['ANALYTICS_RETENTION_DAILY_DAYS'] ?? AnalyticsSchema::DEFAULT_RETENTION_DAILY_DAYS;
        return self::clampInt(
            (int) $value,
            AnalyticsSchema::MIN_RETENTION_DAILY_DAYS,
            AnalyticsSchema::MAX_RETENTION_DAILY_DAYS,
            AnalyticsSchema::DEFAULT_RETENTION_DAILY_DAYS
        );
    }

    /** 0 = unlimited / no storage quota enforced */
    public function getMaxStorageMb(): int
    {
        $value = $this->getSetting(self::KEY_MAX_STORAGE_MB);
        $value ??= $_ENV['ANALYTICS_MAX_STORAGE_MB'] ?? AnalyticsSchema::DEFAULT_MAX_STORAGE_MB;
        return self::clampInt(
            (int) $value,
            AnalyticsSchema::MIN_MAX_STORAGE_MB,
            AnalyticsSchema::MAX_MAX_STORAGE_MB,
            AnalyticsSchema::DEFAULT_MAX_STORAGE_MB
        );
    }

    public function isBotFilterEnabled(): bool
    {
        $dbSetting = $this->getSetting(self::KEY_BOT_FILTER_ENABLED);
        if ($dbSetting !== null) {
            return $dbSetting === 'true';
        }
        return ($_ENV['ANALYTICS_BOT_FILTER_ENABLED'] ?? 'true') === 'true';
    }

    public function isRespectDntEnabled(): bool
    {
        $dbSetting = $this->getSetting(self::KEY_RESPECT_DNT);
        if ($dbSetting !== null) {
            return $dbSetting === 'true';
        }
        return ($_ENV['ANALYTICS_RESPECT_DNT'] ?? 'true') === 'true';
    }

    /**
     * Allowed hosts for the beacon to accept events for. Empty array = accept
     * any host (single-site installs where the CMS origin already implies the
     * one site being measured).
     *
     * @return array<int, string>
     */
    public function getDomainAllowlist(): array
    {
        $dbSetting = $this->getSetting(self::KEY_DOMAIN_ALLOWLIST);
        $raw = $dbSetting ?? ($_ENV['ANALYTICS_DOMAIN_ALLOWLIST'] ?? '');
        $raw = trim((string) $raw);
        if ($raw === '') {
            return [];
        }
        $hosts = array_map(static fn (string $h) => strtolower(trim($h)), explode(',', $raw));
        return array_values(array_filter($hosts, static fn (string $h) => $h !== ''));
    }

    public function getCardinalityCap(): int
    {
        $value = $this->getSetting(self::KEY_CARDINALITY_CAP);
        $value ??= $_ENV['ANALYTICS_CARDINALITY_CAP'] ?? AnalyticsSchema::DEFAULT_CARDINALITY_CAP;
        return self::clampInt(
            (int) $value,
            AnalyticsSchema::MIN_CARDINALITY_CAP,
            AnalyticsSchema::MAX_CARDINALITY_CAP,
            AnalyticsSchema::DEFAULT_CARDINALITY_CAP
        );
    }

    public function getDailyEventCap(): int
    {
        $value = $this->getSetting(self::KEY_DAILY_EVENT_CAP);
        $value ??= $_ENV['ANALYTICS_DAILY_EVENT_CAP'] ?? AnalyticsSchema::DEFAULT_DAILY_EVENT_CAP;
        return self::clampInt(
            (int) $value,
            AnalyticsSchema::MIN_DAILY_EVENT_CAP,
            AnalyticsSchema::MAX_DAILY_EVENT_CAP,
            AnalyticsSchema::DEFAULT_DAILY_EVENT_CAP
        );
    }

    public function isPiggybackEnabled(): bool
    {
        $dbSetting = $this->getSetting(self::KEY_PIGGYBACK_ENABLED);
        if ($dbSetting !== null) {
            return $dbSetting === 'true';
        }
        return ($_ENV['ANALYTICS_PIGGYBACK_PROCESSING'] ?? 'true') === 'true';
    }

    /**
     * Master on/off switch for the "NOMAD Wrapped" yearly recap teaser
     * (AnalyticsWrappedWindow controls WHEN it can show; this controls
     * whether it can EVER show, regardless of the calendar date). Defaults
     * to true - same "opt-out, not opt-in" philosophy as the rest of the
     * module (see isEnabled()'s own docblock).
     */
    public function isWrappedEnabled(): bool
    {
        $dbSetting = $this->getSetting(self::KEY_WRAPPED_ENABLED);
        if ($dbSetting !== null) {
            return $dbSetting === 'true';
        }
        return ($_ENV['ANALYTICS_WRAPPED_ENABLED'] ?? 'true') === 'true';
    }

    /**
     * @return array<string, mixed>
     */
    public function toArray(): array
    {
        return [
            'enabled' => $this->isEnabled(),
            'retention_raw_hours' => $this->getRetentionRawHours(),
            'retention_daily_days' => $this->getRetentionDailyDays(),
            'bot_filter_enabled' => $this->isBotFilterEnabled(),
            'respect_dnt' => $this->isRespectDntEnabled(),
            'domain_allowlist' => $this->getDomainAllowlist(),
            'cardinality_cap' => $this->getCardinalityCap(),
            'daily_event_cap' => $this->getDailyEventCap(),
            'piggyback_enabled' => $this->isPiggybackEnabled(),
            'wrapped_enabled' => $this->isWrappedEnabled(),
            'max_storage_mb' => $this->getMaxStorageMb(),
        ];
    }

    // =========================================================================
    // WRITE ACCESSORS
    // =========================================================================

    /**
     * Update settings from an admin-supplied partial map. Unknown keys are
     * ignored; every value is validated/clamped before being persisted.
     *
     * @param array<string, mixed> $input
     * @return array<string, mixed> The settings after the update
     */
    public function update(array $input): array
    {
        if (array_key_exists('enabled', $input)) {
            $this->setSetting(self::KEY_ENABLED, self::boolString($input['enabled']));
        }
        if (array_key_exists('retention_raw_hours', $input)) {
            $v = self::clampInt(
                (int) $input['retention_raw_hours'],
                AnalyticsSchema::MIN_RETENTION_RAW_HOURS,
                AnalyticsSchema::MAX_RETENTION_RAW_HOURS,
                AnalyticsSchema::DEFAULT_RETENTION_RAW_HOURS
            );
            $this->setSetting(self::KEY_RETENTION_RAW_HOURS, (string) $v);
        }
        if (array_key_exists('retention_daily_days', $input)) {
            $v = self::clampInt(
                (int) $input['retention_daily_days'],
                AnalyticsSchema::MIN_RETENTION_DAILY_DAYS,
                AnalyticsSchema::MAX_RETENTION_DAILY_DAYS,
                AnalyticsSchema::DEFAULT_RETENTION_DAILY_DAYS
            );
            $this->setSetting(self::KEY_RETENTION_DAILY_DAYS, (string) $v);
        }
        if (array_key_exists('bot_filter_enabled', $input)) {
            $this->setSetting(self::KEY_BOT_FILTER_ENABLED, self::boolString($input['bot_filter_enabled']));
        }
        if (array_key_exists('respect_dnt', $input)) {
            $this->setSetting(self::KEY_RESPECT_DNT, self::boolString($input['respect_dnt']));
        }
        if (array_key_exists('domain_allowlist', $input)) {
            $raw = $input['domain_allowlist'];
            $hosts = is_array($raw) ? $raw : explode(',', (string) $raw);
            $hosts = array_map(static fn ($h) => strtolower(trim((string) $h)), $hosts);
            $hosts = array_values(array_filter($hosts, static fn (string $h) => $h !== ''));
            $this->setSetting(self::KEY_DOMAIN_ALLOWLIST, implode(',', $hosts));
        }
        if (array_key_exists('cardinality_cap', $input)) {
            $v = self::clampInt(
                (int) $input['cardinality_cap'],
                AnalyticsSchema::MIN_CARDINALITY_CAP,
                AnalyticsSchema::MAX_CARDINALITY_CAP,
                AnalyticsSchema::DEFAULT_CARDINALITY_CAP
            );
            $this->setSetting(self::KEY_CARDINALITY_CAP, (string) $v);
        }
        if (array_key_exists('daily_event_cap', $input)) {
            $v = self::clampInt(
                (int) $input['daily_event_cap'],
                AnalyticsSchema::MIN_DAILY_EVENT_CAP,
                AnalyticsSchema::MAX_DAILY_EVENT_CAP,
                AnalyticsSchema::DEFAULT_DAILY_EVENT_CAP
            );
            $this->setSetting(self::KEY_DAILY_EVENT_CAP, (string) $v);
        }
        if (array_key_exists('piggyback_enabled', $input)) {
            $this->setSetting(self::KEY_PIGGYBACK_ENABLED, self::boolString($input['piggyback_enabled']));
        }
        if (array_key_exists('wrapped_enabled', $input)) {
            $this->setSetting(self::KEY_WRAPPED_ENABLED, self::boolString($input['wrapped_enabled']));
        }
        if (array_key_exists('max_storage_mb', $input)) {
            $v = self::clampInt(
                (int) $input['max_storage_mb'],
                AnalyticsSchema::MIN_MAX_STORAGE_MB,
                AnalyticsSchema::MAX_MAX_STORAGE_MB,
                AnalyticsSchema::DEFAULT_MAX_STORAGE_MB
            );
            $this->setSetting(self::KEY_MAX_STORAGE_MB, (string) $v);
        }

        return $this->toArray();
    }

    // =========================================================================
    // INTERNAL
    // =========================================================================

    private function getSetting(string $key): ?string
    {
        if ($this->settingsCache === null) {
            $this->loadSettingsCache();
        }
        return $this->settingsCache[$key] ?? null;
    }

    private function setSetting(string $key, string $value): void
    {
        $stmt = $this->db->prepare('
            INSERT INTO ' . AnalyticsSchema::TABLE_SETTINGS . " (key, value, updated_at)
            VALUES (?, ?, datetime('now'))
            ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at
        ");
        $stmt->execute([$key, $value]);
        $this->settingsCache = null;
    }

    private function loadSettingsCache(): void
    {
        $stmt = $this->db->query('SELECT key, value FROM ' . AnalyticsSchema::TABLE_SETTINGS);
        $this->settingsCache = [];
        foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
            $this->settingsCache[$row['key']] = $row['value'];
        }
    }

    private static function boolString(mixed $value): string
    {
        if (is_string($value)) {
            return $value === 'true' ? 'true' : ($value === 'false' ? 'false' : ((bool) $value ? 'true' : 'false'));
        }
        return $value ? 'true' : 'false';
    }

    private static function clampInt(int $value, int $min, int $max, int $default): int
    {
        if ($value < $min || $value > $max) {
            // Out-of-bounds input falls back to the safe default rather than
            // silently clamping to a boundary the admin didn't ask for.
            return $default;
        }
        return $value;
    }
}
