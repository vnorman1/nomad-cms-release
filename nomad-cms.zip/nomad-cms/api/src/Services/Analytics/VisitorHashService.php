<?php
/**
 * NOMAD CMS - Visitor Hash Service
 *
 * The privacy core of the Analytics module: turns a raw IP + User-Agent pair
 * into a short, NON-REVERSIBLE, NON-CROSS-DAY-LINKABLE pseudonymous token used
 * only to count unique visitors, never to identify one.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * WHY THIS IS A SEPARATE SERVICE FROM IpHashService
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * IpHashService::hash() uses a PERMANENT secret (IP_HASH_SECRET from .env):
 * the same IP always produces the same hash, forever. That is exactly right
 * for its job (rate limiting, submission provenance) but exactly WRONG here -
 * a permanent hash would let anyone holding massive.sqlite re-link the same
 * visitor's pageviews across every day since the install, which is the
 * tracking capability this module explicitly promises NOT to have.
 *
 * This service instead uses a salt that:
 *   - is randomly generated, never derived from any permanent secret
 *   - rotates once per calendar day
 *   - is DELETED the moment it rotates
 *
 * Once a day's salt file is gone, that day's visitor_hash values cannot be
 * recomputed or matched against a new IP/UA pair by ANYONE - not an attacker
 * with the raw database, not us, not a court order compelling us to try.
 * That is what makes cross-day tracking cryptographically impossible rather
 * than merely against policy.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * HARDENING APPLIED BEFORE HASHING
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *   1. IP TRUNCATION: IPv4 is masked to /24 (last octet zeroed), IPv6 to /48.
 *      This means every visitor sharing a /24 or /48 (a household, an office,
 *      a mobile carrier NAT pool) contributes to the SAME hash bucket for a
 *      day, trading a small amount of unique-visitor precision for a large
 *      reduction in how identifying the input to the hash is.
 *   2. TRUNCATED DIGEST: only the first 16 hex chars (64 bits) of the SHA-256
 *      digest are kept - plenty of entropy to keep same-day collisions
 *      statistically negligible for any realistic traffic volume, while
 *      keeping storage tiny.
 *
 * The raw IP and User-Agent string are NEVER written anywhere - this service
 * only ever returns the final hash.
 *
 * @package NomadCMS\Services\Analytics
 */

declare(strict_types=1);

namespace NomadCMS\Services\Analytics;

final class VisitorHashService
{
    /** Directory holding the daily salt file (outside any web-servable path) */
    private const SALT_DIR = __DIR__ . '/../../../analytics/salt';

    /** Salt file name (single file, overwritten/rotated daily) */
    private const SALT_FILENAME = 'daily.salt';

    /** Bytes of randomness in a freshly generated salt */
    private const SALT_BYTES = 32;

    /** Hex characters kept from the SHA-256 digest (64 bits) */
    private const HASH_LENGTH = 16;

    /** Per-request memoization: [day => [ip|ua => hash]] */
    private static array $requestCache = [];

    /** Memoized salt for the current process, invalidated on day change */
    private static ?string $cachedSalt = null;
    private static ?string $cachedSaltDay = null;

    /**
     * Compute the pseudonymous visitor hash for this request.
     *
     * @param string $ip Raw client IP (never stored, only hashed)
     * @param string $userAgent Raw User-Agent header (never stored, only hashed)
     * @param string|null $day Override for the "current day" (tests only); format Y-m-d, in the app timezone
     * @return string 16 hex character (64-bit) pseudonymous token
     */
    public static function hash(string $ip, string $userAgent, ?string $day = null): string
    {
        $day ??= date('Y-m-d');

        $cacheKey = $ip . '|' . $userAgent;
        if (isset(self::$requestCache[$day][$cacheKey])) {
            return self::$requestCache[$day][$cacheKey];
        }

        $truncatedIp = self::truncateIp($ip);
        $salt = self::getOrCreateSalt($day);

        $digest = hash('sha256', $truncatedIp . '|' . $userAgent . '|' . $salt);
        $token = substr($digest, 0, self::HASH_LENGTH);

        self::$requestCache[$day][$cacheKey] = $token;

        return $token;
    }

    /**
     * Truncate an IP address to reduce identifiability before hashing:
     * IPv4 -> /24 (zero last octet), IPv6 -> /48 (keep first 3 hextets).
     * Malformed input is treated as an unroutable placeholder rather than
     * hashed verbatim (never let an unparseable value slip through raw).
     */
    public static function truncateIp(string $ip): string
    {
        $ip = trim($ip);

        if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4) !== false) {
            $parts = explode('.', $ip);
            if (count($parts) === 4) {
                $parts[3] = '0';
                return implode('.', $parts);
            }
        }

        if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6) !== false) {
            $packed = @inet_pton($ip);
            if ($packed !== false && strlen($packed) === 16) {
                // Keep the first 48 bits (6 bytes), zero the rest.
                $truncated = substr($packed, 0, 6) . str_repeat("\0", 10);
                $readable = @inet_ntop($truncated);
                if ($readable !== false) {
                    return $readable;
                }
            }
        }

        return '0.0.0.0';
    }

    /**
     * Get today's salt, generating one if this is the first call of the day
     * (rotation) or the process has not seen it yet.
     */
    private static function getOrCreateSalt(string $day): string
    {
        if (self::$cachedSalt !== null && self::$cachedSaltDay === $day) {
            return self::$cachedSalt;
        }

        $dir = self::saltDir();
        self::ensureDirProtected($dir);

        $path = $dir . '/' . self::SALT_FILENAME;
        $meta = self::readSaltFile($path);

        if ($meta === null || $meta['day'] !== $day) {
            // No salt yet, or the day has rolled over: rotate. The old salt is
            // simply overwritten (via atomic tmp+rename) - once gone, any
            // hash computed with it becomes permanently unrecomputable.
            $salt = bin2hex(random_bytes(self::SALT_BYTES));
            self::writeSaltFile($path, $day, $salt);
        } else {
            $salt = $meta['salt'];
        }

        self::$cachedSalt = $salt;
        self::$cachedSaltDay = $day;

        return $salt;
    }

    /**
     * @return array{day:string, salt:string}|null
     */
    private static function readSaltFile(string $path): ?array
    {
        if (!is_file($path)) {
            return null;
        }

        $content = @file_get_contents($path);
        if ($content === false) {
            return null;
        }

        $decoded = json_decode($content, true);
        if (!is_array($decoded) || !isset($decoded['day'], $decoded['salt'])) {
            return null;
        }

        return ['day' => (string) $decoded['day'], 'salt' => (string) $decoded['salt']];
    }

    /**
     * Atomic write: tmp file in the same directory, then rename() over the
     * old salt file. rename() is atomic on POSIX filesystems, so a concurrent
     * request can never observe a half-written salt file.
     */
    private static function writeSaltFile(string $path, string $day, string $salt): void
    {
        $dir = dirname($path);
        $tmp = $dir . '/.' . self::SALT_FILENAME . '.' . bin2hex(random_bytes(4)) . '.tmp';

        $payload = json_encode(['day' => $day, 'salt' => $salt], JSON_UNESCAPED_SLASHES);

        if (file_put_contents($tmp, $payload) === false) {
            return;
        }
        chmod($tmp, 0600);

        if (!rename($tmp, $path)) {
            @unlink($tmp);
        }
    }

    private static function saltDir(): string
    {
        return rtrim(self::SALT_DIR, '/');
    }

    /**
     * Ensure the salt directory exists and is not web-servable: a stray
     * .htaccess (Apache) plus an index.php that 403s (any server) is the same
     * belt-and-suspenders pattern used by api/files/ and the Forms attachment
     * store elsewhere in this codebase.
     */
    private static function ensureDirProtected(string $dir): void
    {
        if (!is_dir($dir)) {
            @mkdir($dir, 0700, true);
        }

        $htaccess = $dir . '/.htaccess';
        if (!is_file($htaccess)) {
            @file_put_contents($htaccess, "Require all denied\nDeny from all\n");
        }

        $indexGuard = $dir . '/index.php';
        if (!is_file($indexGuard)) {
            @file_put_contents($indexGuard, "<?php\nhttp_response_code(403);\nexit;\n");
        }
    }

    // =========================================================================
    // TEST-ONLY HELPERS
    // =========================================================================

    /**
     * Force-rotate the salt right now (tests only), simulating a day change
     * without waiting for real midnight.
     */
    public static function rotateForTests(string $newDay): void
    {
        self::$cachedSalt = null;
        self::$cachedSaltDay = null;
        self::$requestCache = [];

        $path = self::saltDir() . '/' . self::SALT_FILENAME;
        self::ensureDirProtected(self::saltDir());
        $salt = bin2hex(random_bytes(self::SALT_BYTES));
        self::writeSaltFile($path, $newDay, $salt);
    }

    /**
     * Delete the salt file entirely (tests only), simulating the moment
     * after rotation where the previous day's salt is unrecoverable.
     */
    public static function deleteSaltForTests(): void
    {
        self::$cachedSalt = null;
        self::$cachedSaltDay = null;
        self::$requestCache = [];

        @unlink(self::saltDir() . '/' . self::SALT_FILENAME);
    }

    /** Clear only the in-process memoization (tests only) */
    public static function resetMemoizationForTests(): void
    {
        self::$cachedSalt = null;
        self::$cachedSaltDay = null;
        self::$requestCache = [];
    }
}
