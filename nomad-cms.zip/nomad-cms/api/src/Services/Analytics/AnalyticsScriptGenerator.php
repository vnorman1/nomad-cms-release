<?php
/**
 * NOMAD CMS - Analytics Script Generator
 *
 * Materializes the beacon snippet as a genuinely STATIC file
 * (api/static/nomad.js), served with ZERO PHP overhead in production
 * (nginx's existing `location /api/static/` alias, documented in the
 * project README as the "Zero PHP Overhead" static-serving tier - the same
 * mechanism StaticCacheService uses for content JSON).
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * WHY THIS IS NOT A PER-REQUEST PHP TEMPLATE
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * An earlier draft of this module planned a PHP endpoint that generated the
 * script body on every request (api/endpoints/public/analytics-script.php).
 * That would load the FULL bootstrap.php (env, DB pool warmup, middleware
 * chain) for every single page load of every measured site - exactly the
 * kind of per-visit server cost this module is built to avoid everywhere
 * else (see collect.php's own docblock). Per the user's explicit direction,
 * the script content is instead:
 *
 *   1. 100% STATIC TEXT - no PHP variable is ever interpolated into it. The
 *      SAME bytes are correct on every installation, because the script
 *      discovers its own API origin at RUNTIME in the browser (see below) -
 *      there is nothing installation-specific to bake in server-side.
 *   2. Written to disk ONCE (at install time, or on-demand via CLI/admin
 *      action), not regenerated per request.
 *   3. Served afterwards by the web server directly, or by a minimal
 *      bootstrap-free PHP fallback (see analytics-script.php) on setups
 *      without an nginx alias (e.g. the built-in `php -S` dev server).
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * SELF-DISCOVERY (client-side, no server involvement)
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * The script reads `document.currentScript.src`, extracts its ORIGIN (not
 * the current page's origin), and POSTs beacons to `{that origin}/api/collect`.
 * This is what lets a single embed snippet -
 *   <script defer src="https://cms.example.com/static/nomad.js"></script>
 * - work correctly whether the embedding page is on the SAME origin as the
 * CMS or a COMPLETELY DIFFERENT one, with no data-* configuration attribute
 * ever required.
 *
 * @package NomadCMS\Services\Analytics
 */

declare(strict_types=1);

namespace NomadCMS\Services\Analytics;

final class AnalyticsScriptGenerator
{
    /** Relative to the api/ directory */
    private const OUTPUT_PATH = __DIR__ . '/../../../static/nomad.js';

    /**
     * Write the static snippet to api/static/nomad.js. Idempotent and
     * safe to call repeatedly (install, CLI regen, admin action) - atomic
     * tmp+rename so a concurrent request never observes a half-written file.
     */
    public static function generate(): bool
    {
        $path = self::outputPath();
        $dir = dirname($path);

        if (!is_dir($dir)) {
            @mkdir($dir, 0755, true);
        }

        $tmp = $dir . '/.nomad.js.' . bin2hex(random_bytes(4)) . '.tmp';

        if (file_put_contents($tmp, self::scriptSource()) === false) {
            return false;
        }
        chmod($tmp, 0644);

        if (!rename($tmp, $path)) {
            @unlink($tmp);
            return false;
        }

        return true;
    }

    public static function outputPath(): string
    {
        return self::OUTPUT_PATH;
    }

    public static function exists(): bool
    {
        return is_file(self::outputPath());
    }

    /**
     * The full, static JS source. Deliberately plain ES2017-ish syntax (no
     * build step, no transpilation) - this file is committed to the static
     * output as-is, and needs to run unmodified in any browser this module
     * would plausibly be measuring traffic from.
     */
    public static function scriptSource(): string
    {
        return <<<'JS'
(function () {
  "use strict";

  var currentScript = document.currentScript;
  if (!currentScript) {
    var scripts = document.getElementsByTagName("script");
    for (var i = scripts.length - 1; i >= 0; i--) {
      if (scripts[i].src && scripts[i].src.indexOf("nomad.js") !== -1) {
        currentScript = scripts[i];
        break;
      }
    }
  }
  if (!currentScript || !currentScript.src) {
    return;
  }

  var origin;
  try {
    origin = new URL(currentScript.src).origin;
  } catch (e) {
    return;
  }

  var COLLECT_URL = origin + "/api/collect";

  function send(payload) {
    var body = JSON.stringify(payload);

    if (navigator.sendBeacon) {
      try {
        var blob = new Blob([body], { type: "text/plain" });
        if (navigator.sendBeacon(COLLECT_URL, blob)) {
          return;
        }
      } catch (e) {
      }
    }

    if (window.fetch) {
      try {
        fetch(COLLECT_URL, {
          method: "POST",
          body: body,
          headers: { "Content-Type": "text/plain" },
          keepalive: true,
          mode: "cors",
          credentials: "omit"
        }).catch(function () {});
        return;
      } catch (e) {
      }
    }
  }

  function currentUrl() {
    return location.href;
  }

  var lastTrackedUrl = null;

  function track() {
    var url = currentUrl();
    if (url === lastTrackedUrl) {
      return;
    }
    var isFirst = lastTrackedUrl === null;
    lastTrackedUrl = url;

    send({
      url: url,
      referrer: isFirst ? document.referrer : ""
    });
  }

  if (document.readyState === "complete" || document.readyState === "interactive") {
    track();
  } else {
    document.addEventListener("DOMContentLoaded", track, { once: true });
  }

  function patchHistory(method) {
    var original = history[method];
    if (typeof original !== "function") {
      return;
    }
    history[method] = function () {
      var result = original.apply(this, arguments);
      track();
      return result;
    };
  }

  patchHistory("pushState");
  patchHistory("replaceState");
  window.addEventListener("popstate", track);
})();
JS;
    }
}
