<?php
/**
 * NOMAD CMS - Aggregation Service
 *
 * Turns already-ingested massive_analytics_events rows into the two tables
 * the admin UI (and eventually the public "Explore" query layer) actually
 * reads: massive_analytics_daily_totals (exact headline numbers) and
 * massive_analytics_daily_facts (per-dimension-tuple views + mergeable
 * visitor sketch).
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * IDEMPOTENCY MODEL: RECOMPUTE, NOT INCREMENT
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * aggregateDay($day, $host) is safe to call repeatedly for the SAME
 * (day, host) - including for "today", which will be re-aggregated many
 * times before it is finalized. It achieves this by DELETING every existing
 * row for that (day, host) and re-INSERTing from a fresh GROUP BY over the
 * still-present raw buffer, inside one transaction. This only works because
 * raw events for an unfinalized day are guaranteed to still be fully present
 * (AnalyticsRetentionService, task 8, never purges a day before it is
 * finalized) - so "recompute from scratch" and "the true state for this day"
 * are always the same thing until the day is finalized and its raw rows are
 * gone for good.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * CARDINALITY CAPPING
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * AnalyticsSettingsService::getCardinalityCap() (default 500) is enforced
 * PER DIMENSION COLUMN, independently, before the GROUP BY that builds
 * daily_facts: for each dimension (path, referrer_domain, utm_source, ...),
 * only the top-N values BY RAW EVENT COUNT for that (day, host) keep their
 * real value: everything else folds into AnalyticsSchema::DIM_OTHER for that
 * column. This keeps daily_facts from exploding on a viral day with a long
 * tail of one-off paths/referrers, at the cost of merging rare values
 * together under "(other)" per dimension - never dropping the underlying
 * views/visitors, only their per-column identity.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * FINALIZATION
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * finalizeElapsedDays() marks a day's daily_totals row `finalized = 1` once
 * the day has fully elapsed (app timezone) AND its spool file's ingest
 * backlog is zero (SpoolIngestService::getOffset() caught up to file size) -
 * i.e. every event that will ever exist for that day has been counted. It
 * then calls SpoolIngestService::markCompleted($day), the signal task 8's
 * AnalyticsRetentionService uses to know it is safe to purge that day's raw
 * events.
 *
 * @package NomadCMS\Services\Analytics
 */

declare(strict_types=1);

namespace NomadCMS\Services\Analytics;

use PDO;

final class AggregationService
{
    /** @var array<int, string> Dimension columns individually cardinality-capped before the daily_facts GROUP BY */
    private const CAPPED_DIMENSIONS = [
        'path', 'referrer_domain', 'utm_source', 'utm_medium', 'utm_campaign', 'utm_term', 'utm_content',
    ];

    /**
     * Recompute daily_totals + daily_facts for one (day, host) from the raw
     * event buffer. Safe to call repeatedly (DELETE + re-INSERT inside one
     * transaction).
     *
     * @return array{views:int, visitors:int, fact_rows:int}
     */
    public static function aggregateDay(string $day, string $host): array
    {
        AnalyticsSchema::ensureTables();
        $db = AnalyticsSchema::db();

        $cardinalityCap = AnalyticsSettingsService::getInstance()->getCardinalityCap();

        $db->beginTransaction();
        try {
            $totals = self::computeTotals($db, $day, $host);
            $hourlyTotals = self::computeHourlyTotals($db, $day, $host);

            $capMaps = [];
            foreach (self::CAPPED_DIMENSIONS as $dimension) {
                $capMaps[$dimension] = self::topValuesForDimension($db, $day, $host, $dimension, $cardinalityCap);
            }

            $factRows = self::computeFactRows($db, $day, $host, $capMaps);

            self::replaceDailyTotals($db, $day, $host, $totals['views'], $totals['visitors']);
            self::replaceHourlyTotals($db, $day, $host, $hourlyTotals);
            self::replaceDailyFacts($db, $day, $host, $factRows);

            $db->commit();

            return ['views' => $totals['views'], 'visitors' => $totals['visitors'], 'fact_rows' => count($factRows)];
        } catch (\Throwable $e) {
            $db->rollBack();
            error_log('[Analytics] aggregateDay failed for ' . $day . '/' . $host . ': ' . $e->getMessage());
            return ['views' => 0, 'visitors' => 0, 'fact_rows' => 0];
        }
    }

    /**
     * Convenience: aggregate every (day, host) pair currently present in the
     * raw buffer. Used by the piggyback hook and CLI for "just catch
     * everything up" runs.
     *
     * @return array<int, array{day:string, host:string, views:int, visitors:int, fact_rows:int}>
     */
    public static function aggregateAllPending(): array
    {
        AnalyticsSchema::ensureTables();
        $db = AnalyticsSchema::db();

        $stmt = $db->query('SELECT DISTINCT day, host FROM ' . AnalyticsSchema::TABLE_EVENTS);
        $pairs = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $results = [];
        foreach ($pairs as $pair) {
            $day = (string) $pair['day'];
            $host = (string) $pair['host'];
            $result = self::aggregateDay($day, $host);
            $results[] = ['day' => $day, 'host' => $host] + $result;
        }

        return $results;
    }

    /**
     * Mark every day that has fully elapsed (app timezone) AND has zero
     * ingest backlog as finalized, and signal SpoolIngestService so the
     * retention sweep (task 8) knows it is safe to purge that day's raw rows.
     *
     * @return array<int, string> Days finalized in this call
     */
    public static function finalizeElapsedDays(): array
    {
        AnalyticsSchema::ensureTables();
        $db = AnalyticsSchema::db();

        $today = date('Y-m-d');

        $stmt = $db->prepare('
            SELECT day, host FROM ' . AnalyticsSchema::TABLE_DAILY_TOTALS . '
            WHERE finalized = 0 AND day < ?
        ');
        $stmt->execute([$today]);
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $finalizedDays = [];

        foreach ($rows as $row) {
            $day = (string) $row['day'];
            $host = (string) $row['host'];

            $spoolFile = SpoolWriter::spoolFilePath(SpoolWriter::spoolDir(), $day);
            $fileSize = is_file($spoolFile) ? (int) filesize($spoolFile) : 0;
            $offset = SpoolIngestService::getOffset($spoolFile);

            if ($offset < $fileSize) {
                continue; // Still backlog for this day - not safe to finalize yet.
            }

            // Re-aggregate one last time to make sure the finalized snapshot
            // reflects every ingested event before we mark it immutable.
            self::aggregateDay($day, $host);

            $update = $db->prepare('UPDATE ' . AnalyticsSchema::TABLE_DAILY_TOTALS . " SET finalized = 1, updated_at = datetime('now') WHERE day = ? AND host = ?");
            $update->execute([$day, $host]);

            SpoolIngestService::markCompleted($day);

            $finalizedDays[] = $day;
        }

        return array_values(array_unique($finalizedDays));
    }

    // =========================================================================
    // INTERNAL: TOTALS
    // =========================================================================

    /**
     * @return array{views:int, visitors:int}
     */
    private static function computeTotals(PDO $db, string $day, string $host): array
    {
        $stmt = $db->prepare('
            SELECT COUNT(*) AS views, COUNT(DISTINCT visitor_hash) AS visitors
            FROM ' . AnalyticsSchema::TABLE_EVENTS . '
            WHERE day = ? AND host = ?
        ');
        $stmt->execute([$day, $host]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC) ?: ['views' => 0, 'visitors' => 0];

        return ['views' => (int) $row['views'], 'visitors' => (int) $row['visitors']];
    }

    private static function replaceDailyTotals(PDO $db, string $day, string $host, int $views, int $visitors): void
    {
        $stmt = $db->prepare('
            INSERT INTO ' . AnalyticsSchema::TABLE_DAILY_TOTALS . " (day, host, views, visitors, updated_at)
            VALUES (?, ?, ?, ?, datetime('now'))
            ON CONFLICT(day, host) DO UPDATE SET
                views = excluded.views,
                visitors = excluded.visitors,
                updated_at = excluded.updated_at
        ");
        $stmt->execute([$day, $host, $views, $visitors]);
    }

    /**
     * @return array<int, array{hour:int, views:int, visitors:int}>
     */
    private static function computeHourlyTotals(PDO $db, string $day, string $host): array
    {
        // SQLite's strftime('%H', datetime(ts, 'unixepoch', 'localtime')) groups by the hour in local app timezone.
        $stmt = $db->prepare("
            SELECT 
                CAST(strftime('%H', datetime(ts, 'unixepoch', 'localtime')) AS INTEGER) AS hour,
                COUNT(*) AS views,
                COUNT(DISTINCT visitor_hash) AS visitors
            FROM " . AnalyticsSchema::TABLE_EVENTS . "
            WHERE day = ? AND host = ?
            GROUP BY hour
            ORDER BY hour ASC
        ");
        $stmt->execute([$day, $host]);
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $result = [];
        foreach ($rows as $row) {
            $result[] = [
                'hour' => (int) $row['hour'],
                'views' => (int) $row['views'],
                'visitors' => (int) $row['visitors'],
            ];
        }

        return $result;
    }

    /**
     * @param array<int, array{hour:int, views:int, visitors:int}> $hourlyTotals
     */
    private static function replaceHourlyTotals(PDO $db, string $day, string $host, array $hourlyTotals): void
    {
        $del = $db->prepare('DELETE FROM ' . AnalyticsSchema::TABLE_HOURLY_TOTALS . ' WHERE day = ? AND host = ?');
        $del->execute([$day, $host]);

        if (empty($hourlyTotals)) {
            return;
        }

        $ins = $db->prepare('
            INSERT INTO ' . AnalyticsSchema::TABLE_HOURLY_TOTALS . " (day, hour, host, views, visitors, updated_at)
            VALUES (?, ?, ?, ?, ?, datetime('now'))
        ");
        foreach ($hourlyTotals as $row) {
            $ins->execute([$day, $row['hour'], $host, $row['views'], $row['visitors']]);
        }
    }

    // =========================================================================
    // INTERNAL: CARDINALITY CAPPING
    // =========================================================================

    /**
     * The set of values for one dimension column that are allowed to keep
     * their real identity for this (day, host) - the top $cap by raw event
     * count. Anything not in this set folds into AnalyticsSchema::DIM_OTHER.
     *
     * @return array<string, true>
     */
    private static function topValuesForDimension(PDO $db, string $day, string $host, string $column, int $cap): array
    {
        $safeColumn = self::assertKnownColumn($column);

        $stmt = $db->prepare("
            SELECT {$safeColumn} AS value, COUNT(*) AS cnt
            FROM " . AnalyticsSchema::TABLE_EVENTS . "
            WHERE day = ? AND host = ?
            GROUP BY {$safeColumn}
            ORDER BY cnt DESC
            LIMIT ?
        ");
        $stmt->execute([$day, $host, $cap]);

        $allowed = [];
        foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
            $allowed[(string) $row['value']] = true;
        }

        return $allowed;
    }

    /**
     * Only ever called with a column name from CAPPED_DIMENSIONS (a fixed,
     * hardcoded list - never user input), but asserted anyway as
     * defense-in-depth against a future caller passing something unexpected.
     */
    private static function assertKnownColumn(string $column): string
    {
        if (!in_array($column, self::CAPPED_DIMENSIONS, true)) {
            throw new \InvalidArgumentException("Unknown dimension column: {$column}");
        }
        return $column;
    }

    // =========================================================================
    // INTERNAL: FACT ROWS (dimension tuple + sketch)
    // =========================================================================

    /**
     * @param array<string, array<string, true>> $capMaps column => allowed-value set
     * @return array<int, array<string, mixed>> Rows ready for replaceDailyFacts()
     */
    private static function computeFactRows(PDO $db, string $day, string $host, array $capMaps): array
    {
        $stmt = $db->prepare('
            SELECT path, referrer_domain, device, country, utm_source, utm_medium, utm_campaign, utm_term, utm_content, visitor_hash
            FROM ' . AnalyticsSchema::TABLE_EVENTS . '
            WHERE day = ? AND host = ?
        ');
        $stmt->execute([$day, $host]);

        /** @var array<string, array{tuple:array<string,string>, views:int, sketch:VisitorSketch}> $groups */
        $groups = [];

        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $tuple = [
                'path' => self::applyCap($capMaps, 'path', (string) $row['path']),
                'referrer_domain' => self::applyCap($capMaps, 'referrer_domain', (string) $row['referrer_domain']),
                'device' => (string) $row['device'],
                'country' => (string) $row['country'],
                'utm_source' => self::applyCap($capMaps, 'utm_source', (string) $row['utm_source']),
                'utm_medium' => self::applyCap($capMaps, 'utm_medium', (string) $row['utm_medium']),
                'utm_campaign' => self::applyCap($capMaps, 'utm_campaign', (string) $row['utm_campaign']),
                'utm_term' => self::applyCap($capMaps, 'utm_term', (string) $row['utm_term']),
                'utm_content' => self::applyCap($capMaps, 'utm_content', (string) $row['utm_content']),
            ];

            $key = implode("\x1f", $tuple);

            if (!isset($groups[$key])) {
                $groups[$key] = ['tuple' => $tuple, 'views' => 0, 'sketch' => VisitorSketch::createEmpty()];
            }

            $groups[$key]['views']++;
            $groups[$key]['sketch']->add((string) $row['visitor_hash']);
        }

        $result = [];
        foreach ($groups as $group) {
            $result[] = array_merge($group['tuple'], [
                'views' => $group['views'],
                'sketch' => $group['sketch']->serialize(),
                'sketch_mode' => $group['sketch']->mode(),
            ]);
        }

        return $result;
    }

    /**
     * @param array<string, array<string, true>> $capMaps
     */
    private static function applyCap(array $capMaps, string $dimension, string $value): string
    {
        if (!isset($capMaps[$dimension])) {
            return $value;
        }
        return isset($capMaps[$dimension][$value]) ? $value : AnalyticsSchema::DIM_OTHER;
    }

    /**
     * @param array<int, array<string, mixed>> $rows
     */
    private static function replaceDailyFacts(PDO $db, string $day, string $host, array $rows): void
    {
        $delete = $db->prepare('DELETE FROM ' . AnalyticsSchema::TABLE_DAILY_FACTS . ' WHERE day = ? AND host = ?');
        $delete->execute([$day, $host]);

        if (empty($rows)) {
            return;
        }

        $insert = $db->prepare('
            INSERT INTO ' . AnalyticsSchema::TABLE_DAILY_FACTS . '
                (day, host, path, referrer_domain, device, country, utm_source, utm_medium, utm_campaign, utm_term, utm_content, views, sketch, sketch_mode)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ');

        foreach ($rows as $row) {
            $insert->execute([
                $day,
                $host,
                $row['path'],
                $row['referrer_domain'],
                $row['device'],
                $row['country'],
                $row['utm_source'],
                $row['utm_medium'],
                $row['utm_campaign'],
                $row['utm_term'],
                $row['utm_content'],
                $row['views'],
                $row['sketch'],
                $row['sketch_mode'],
            ]);
        }
    }
}
