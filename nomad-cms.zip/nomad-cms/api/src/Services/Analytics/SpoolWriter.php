<?php
/**
 * NOMAD CMS - Spool Writer
 *
 * The hot-path persistence layer for a single analytics event: an append-only
 * NDJSON file per day, written with a plain O_APPEND write (no flock, no
 * database connection). This is what lets collect.php answer with 204 in a
 * couple of milliseconds regardless of how busy massive.sqlite is.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * WHY NO flock() HERE
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * On POSIX filesystems, a write() to a file opened with O_APPEND is atomic
 * with respect to other writers as long as a single write() syscall covers
 * the whole line and the line is smaller than the filesystem's atomic write
 * boundary (historically PIPE_BUF, 4096 bytes on Linux; our lines are a few
 * hundred bytes of single-line JSON). PHP's file_put_contents(..., FILE_APPEND)
 * performs exactly one such write for a string that small, so concurrent
 * beacon requests interleave whole lines, never partial ones. Skipping flock()
 * is not a shortcut - it is what keeps this the fast path: acquiring a lock
 * is exactly the kind of contention the whole spool design exists to avoid.
 *
 * The consumer (SpoolIngestService, task 5) tolerates a malformed trailing
 * line anyway (defensive: NFS and unusual filesystems do not always honour the
 * above guarantee), so nothing downstream assumes perfection here - it just
 * doesn't need to slow down every visitor to get very close to it.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * ABUSE CEILINGS
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * Two independent caps, both fail silently (return false, never throw):
 *   - per-line size cap (a malformed/huge payload is dropped, not written)
 *   - per-day total spool size cap (a runaway flood stops growing the file
 *     instead of filling the disk)
 *
 * @package NomadCMS\Services\Analytics
 */

declare(strict_types=1);

namespace NomadCMS\Services\Analytics;

final class SpoolWriter
{
    private const SPOOL_DIR = __DIR__ . '/../../../analytics/spool';

    /** Hard ceiling on a single serialized event line, regardless of settings */
    private const MAX_LINE_BYTES = 4096;

    /** Hard ceiling on one day's spool file size (abuse ceiling, independent of daily_event_cap) */
    private const MAX_SPOOL_FILE_BYTES = 64 * 1024 * 1024; // 64 MB

    /**
     * Append one normalized event to today's spool file.
     *
     * @param array{
     *   ts:int, day:string, host:string, path:string, referrer_domain:string,
     *   device:string, country:string, utm_source:string, utm_medium:string,
     *   utm_campaign:string, utm_term:string, utm_content:string, visitor_hash:string
     * } $event
     * @return bool True if the line was written (best-effort; false on any guard failure)
     */
    public static function append(array $event): bool
    {
        $day = $event['day'] ?? date('Y-m-d');
        $line = json_encode($event, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);

        if ($line === false) {
            return false;
        }

        $line .= "\n";

        if (strlen($line) > self::MAX_LINE_BYTES) {
            return false; // Malformed/oversized event - drop rather than risk a torn write.
        }

        $dir = self::spoolDir();
        self::ensureDirProtected($dir);

        $path = self::spoolFilePath($dir, $day);

        $currentSize = is_file($path) ? filesize($path) : 0;
        if ($currentSize !== false && $currentSize + strlen($line) > self::MAX_SPOOL_FILE_BYTES) {
            return false; // Daily spool file is at its abuse ceiling - stop growing it.
        }

        $written = @file_put_contents($path, $line, FILE_APPEND);

        return $written !== false;
    }

    /**
     * @return array<int, string> Absolute paths of every spool file, oldest first (lexicographic = chronological, filenames are Y-m-d.ndjson)
     */
    public static function listSpoolFiles(): array
    {
        $dir = self::spoolDir();
        if (!is_dir($dir)) {
            return [];
        }

        $files = glob($dir . '/*.ndjson') ?: [];
        sort($files);

        return $files;
    }

    public static function spoolFilePath(string $dir, string $day): string
    {
        $safeDay = preg_replace('/[^0-9\-]/', '', $day) ?? '';
        return $dir . '/' . $safeDay . '.ndjson';
    }

    public static function spoolDir(): string
    {
        return rtrim(self::SPOOL_DIR, '/');
    }

    /**
     * Same belt-and-suspenders pattern as VisitorHashService's salt dir: a
     * .htaccess (Apache) plus a 403ing index.php (any server), so a spool
     * file is never directly web-servable even if placed under a public root
     * by mistake.
     */
    private static function ensureDirProtected(string $dir): void
    {
        if (!is_dir($dir)) {
            @mkdir($dir, 0700, true);
        }

        $htaccess = $dir . '/.htaccess';
        if (!is_file($htaccess)) {
            @file_put_contents($htaccess, "Require all denied\nDeny from all\n");
        }

        $indexGuard = $dir . '/index.php';
        if (!is_file($indexGuard)) {
            @file_put_contents($indexGuard, "<?php\nhttp_response_code(403);\nexit;\n");
        }
    }

    // =========================================================================
    // TEST-ONLY HELPERS
    // =========================================================================

    /** Delete every spool file (tests only) */
    public static function clearAllForTests(): void
    {
        foreach (self::listSpoolFiles() as $file) {
            @unlink($file);
        }
    }
}
