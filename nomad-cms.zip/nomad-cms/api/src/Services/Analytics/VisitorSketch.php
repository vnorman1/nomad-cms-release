<?php
/**
 * NOMAD CMS - Visitor Sketch (Sparse + HyperLogLog)
 *
 * A mergeable, approximate-distinct-count data structure for the daily
 * visitor_hash values behind a single (day, host, path, referrer_domain,
 * device, country, utm_*) fact row (massive_analytics_daily_facts.sketch).
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * WHY THIS EXISTS AT ALL
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * The raw events table is purged shortly after a day is finalized (see
 * AnalyticsRetentionService, task 8) - by design, so it can never grow
 * forever. Once those rows are gone, "how many unique visitors filtered a
 * certain way" can no longer be answered with COUNT(DISTINCT visitor_hash)
 * over raw rows. A sketch solves this because sketches are UNION-MERGEABLE:
 * the Explore UI's "unique visitors under an arbitrary filter combination" is
 * just merge()-ing the sketches of every fact row the filter selects, then
 * calling estimate() once on the result - all without ever touching a raw
 * event again.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * TWO MODES
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *   SPARSE   Stores the exact set of truncated visitor_hash values (already
 *            16 hex chars / 64 bits from VisitorHashService). Below the
 *            promotion threshold this gives an EXACT count - most path/day
 *            combinations in a real site have well under 64 distinct daily
 *            visitors, so most rows never pay any estimation error at all.
 *
 *   DENSE    A classic HyperLogLog with p=10 (1024 registers, 6 bits each -
 *            classic Flajolet et al. bias-corrected estimator with linear
 *            counting for the small-cardinality regime). Used once a fact
 *            row's sparse set would exceed SPARSE_PROMOTION_THRESHOLD
 *            distinct hashes.
 *
 * A sparse sketch merged with a dense one, or a sparse sketch that grows past
 * the threshold during merge, is promoted to dense automatically - callers
 * never need to know which representation they are holding.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * SERIALIZATION
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * serialize() returns a compact binary string for the `sketch` BLOB column;
 * `sketch_mode` (a separate TEXT column) records 'sparse' or 'dense' so
 * deserialize() does not need to guess from the bytes alone. Format:
 *   sparse: 8 bytes per stored hash (the 64-bit value, packed)
 *   dense:  1024 bytes, one per register (values 0-63 fit in a byte; keeping
 *           byte-per-register instead of packing to 6 bits trades a small
 *           amount of space for a MUCH simpler, faster, less bug-prone
 *           merge()/serialize() - 1 KB per fact row is not a concern here)
 *
 * @package NomadCMS\Services\Analytics
 */

declare(strict_types=1);

namespace NomadCMS\Services\Analytics;

final class VisitorSketch
{
    public const MODE_SPARSE = 'sparse';
    public const MODE_DENSE = 'dense';

    /** Precision parameter: 2^10 = 1024 registers */
    private const PRECISION = 10;
    private const REGISTER_COUNT = 1 << self::PRECISION; // 1024

    /** Above this many distinct hashes, a sparse sketch is promoted to dense */
    public const SPARSE_PROMOTION_THRESHOLD = 64;

    /** Standard HLL bias-correction constant for m=1024 (alpha_m * m^2 term folded in at estimate time) */
    private const ALPHA_1024 = 0.7213 / (1 + 1.079 / self::REGISTER_COUNT);

    private string $mode;

    /** @var array<string, true> Sparse mode: set of distinct 64-bit hash values (as decimal strings, PHP has no native uint64) */
    private array $sparseSet = [];

    /** @var array<int, int> Dense mode: register index => max leading-zero-run+1 seen */
    private array $registers = [];

    private function __construct(string $mode)
    {
        $this->mode = $mode;
        if ($mode === self::MODE_DENSE) {
            $this->registers = array_fill(0, self::REGISTER_COUNT, 0);
        }
    }

    public static function createEmpty(): self
    {
        return new self(self::MODE_SPARSE);
    }

    public function mode(): string
    {
        return $this->mode;
    }

    /**
     * Add one truncated visitor hash (expects the 16-hex-char / 64-bit tokens
     * VisitorHashService produces, but accepts any string - it is hashed
     * again internally for uniform bit distribution).
     */
    public function add(string $truncatedHash): void
    {
        $hash64 = self::hashToUint64( $truncatedHash);

        if ($this->mode === self::MODE_SPARSE) {
            $this->sparseSet[$hash64] = true;

            if (count($this->sparseSet) > self::SPARSE_PROMOTION_THRESHOLD) {
                $this->promoteToDense();
            }
            return;
        }

        $this->addToDense($hash64);
    }

    /**
     * Merge another sketch's contents into this one (union). Returns $this
     * for chaining; the argument is left unmodified.
     */
    public function merge(VisitorSketch $other): self
    {
        if ($this->mode === self::MODE_SPARSE && $other->mode === self::MODE_SPARSE) {
            foreach ($other->sparseSet as $hash64 => $_) {
                $this->sparseSet[$hash64] = true;
            }
            if (count($this->sparseSet) > self::SPARSE_PROMOTION_THRESHOLD) {
                $this->promoteToDense();
            }
            return $this;
        }

        // At least one side is dense: result must be dense.
        if ($this->mode === self::MODE_SPARSE) {
            $this->promoteToDense();
        }

        if ($other->mode === self::MODE_SPARSE) {
            foreach ($other->sparseSet as $hash64 => $_) {
                $this->addToDense((string) $hash64);
            }
            return $this;
        }

        for ($i = 0; $i < self::REGISTER_COUNT; $i++) {
            if ($other->registers[$i] > $this->registers[$i]) {
                $this->registers[$i] = $other->registers[$i];
            }
        }

        return $this;
    }

    /**
     * Estimated (sparse: EXACT) distinct count.
     */
    public function estimate(): int
    {
        if ($this->mode === self::MODE_SPARSE) {
            return count($this->sparseSet);
        }

        return self::estimateFromRegisters($this->registers);
    }

    // =========================================================================
    // SERIALIZATION
    // =========================================================================

    public function serialize(): string
    {
        if ($this->mode === self::MODE_SPARSE) {
            $bytes = '';
            foreach (array_keys($this->sparseSet) as $hash64) {
                $bytes .= self::packUint64((string) $hash64);
            }
            return $bytes;
        }

        $bytes = '';
        for ($i = 0; $i < self::REGISTER_COUNT; $i++) {
            $bytes .= chr(min(255, $this->registers[$i]));
        }
        return $bytes;
    }

    public static function deserialize(string $blob, string $mode): self
    {
        $sketch = new self($mode === self::MODE_DENSE ? self::MODE_DENSE : self::MODE_SPARSE);

        if ($sketch->mode === self::MODE_SPARSE) {
            $len = strlen($blob);
            for ($offset = 0; $offset + 8 <= $len; $offset += 8) {
                $hash64 = self::unpackUint64(substr($blob, $offset, 8));
                $sketch->sparseSet[$hash64] = true;
            }
            return $sketch;
        }

        $len = min(self::REGISTER_COUNT, strlen($blob));
        for ($i = 0; $i < $len; $i++) {
            $sketch->registers[$i] = ord($blob[$i]);
        }
        return $sketch;
    }

    // =========================================================================
    // INTERNAL: DENSE (HYPERLOGLOG) MECHANICS
    // =========================================================================

    private function promoteToDense(): void
    {
        $existing = $this->sparseSet;
        $this->mode = self::MODE_DENSE;
        $this->registers = array_fill(0, self::REGISTER_COUNT, 0);
        $this->sparseSet = [];

        foreach (array_keys($existing) as $hash64) {
            $this->addToDense((string) $hash64);
        }
    }

    /**
     * @param string $hash64 Decimal-string representation of a 64-bit value
     */
    private function addToDense(string $hash64): void
    {
        // Use the low PRECISION bits to pick the register, and count leading
        // zeros (+1) in the REMAINING bits to get the rank. We work with the
        // 64-bit value split into a 32-bit "index source" and 32-bit "rank
        // source" via string-based big-int math (gmp/bcmath not guaranteed
        // available on shared hosting) - see hashToUint64()/splitHash64().
        [$indexBits, $rankBits] = self::splitHash64($hash64);

        $index = $indexBits & (self::REGISTER_COUNT - 1);
        $rank = self::leadingZeroCount32($rankBits, 32 - self::PRECISION) + 1;

        if ($rank > $this->registers[$index]) {
            $this->registers[$index] = $rank;
        }
    }

    /**
     * Classic Flajolet et al. HyperLogLog estimator with small-range
     * (linear counting) and large-range corrections.
     *
     * @param array<int, int> $registers
     */
    private static function estimateFromRegisters(array $registers): int
    {
        $m = self::REGISTER_COUNT;

        $sumInverse = 0.0;
        $zeroCount = 0;
        foreach ($registers as $value) {
            $sumInverse += 2 ** (-$value);
            if ($value === 0) {
                $zeroCount++;
            }
        }

        $rawEstimate = self::ALPHA_1024 * $m * $m / $sumInverse;

        // Small-range correction: linear counting when there are empty registers.
        if ($rawEstimate <= 2.5 * $m && $zeroCount > 0) {
            return (int) round($m * log($m / $zeroCount));
        }

        // Large-range correction (32-bit hash space overflow) is irrelevant at
        // our traffic scale (would only matter above ~2^28 distinct values
        // with a 32-bit rank source) and is intentionally omitted - it would
        // add complexity for a regime this module will never reach.

        return (int) round($rawEstimate);
    }

    // =========================================================================
    // INTERNAL: 64-BIT HASH HANDLING WITHOUT GMP/BCMATH
    // =========================================================================

    /**
     * Turn an arbitrary input string into a well-distributed 64-bit value,
     * represented as a base-10 string (PHP ints are 64-bit signed on 64-bit
     * builds, which is one bit short of unsigned 64-bit - we therefore keep
     * the value as two 32-bit halves under the hood via splitHash64(), and
     * only ever expose/store the combined value as a decimal string to avoid
     * sign-bit surprises).
     */
    private static function hashToUint64(string $input): string
    {
        $digest = hash('sha256', $input, true); // 32 raw bytes
        $high = unpack('N', substr($digest, 0, 4))[1]; // first 4 bytes, big-endian uint32
        $low = unpack('N', substr($digest, 4, 4))[1];   // next 4 bytes, big-endian uint32

        // Combine into a single decimal string representing high*2^32+low,
        // using string-safe arithmetic (no bcmath dependency): PHP's float
        // can exactly represent integers up to 2^53, and our combined value
        // is at most 2^64-1 - but we never need the COMBINED integer value
        // itself, only a stable, round-trippable encoding. Store as
        // "high:low" internally would be simpler, but the sparse-mode
        // dedup/serialize paths want a single scalar key - a zero-padded
        // concatenation of both decimal parts is unambiguous and exact.
        return sprintf('%u:%u', $high, $low);
    }

    /**
     * @return array{0:int, 1:int} [indexSourceBits (uint32), rankSourceBits (uint32)]
     */
    private static function splitHash64(string $hash64): array
    {
        [$high, $low] = array_map('intval', explode(':', $hash64));
        // High 32 bits pick the register (uses PRECISION low bits of $high);
        // low 32 bits are the rank source. This keeps both halves independent
        // uint32 values, sidestepping 64-bit arithmetic entirely.
        return [$high, $low];
    }

    /**
     * Count leading zero bits in a $bits-wide unsigned value (as a PHP int
     * holding a uint32), scanning from the MOST significant of those $bits.
     */
    private static function leadingZeroCount32(int $value, int $bits): int
    {
        if ($bits <= 0) {
            return 0;
        }

        for ($i = $bits - 1; $i >= 0; $i--) {
            if (($value >> $i) & 1) {
                return $bits - 1 - $i;
            }
        }

        return $bits; // All zero
    }

    private static function packUint64(string $hash64): string
    {
        [$high, $low] = array_map('intval', explode(':', $hash64));
        return pack('N', $high) . pack('N', $low);
    }

    private static function unpackUint64(string $bytes): string
    {
        $high = unpack('N', substr($bytes, 0, 4))[1];
        $low = unpack('N', substr($bytes, 4, 4))[1];
        return sprintf('%u:%u', $high, $low);
    }
}
