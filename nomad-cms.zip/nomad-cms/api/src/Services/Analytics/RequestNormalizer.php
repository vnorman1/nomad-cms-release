<?php
/**
 * NOMAD CMS - Request Normalizer
 *
 * Turns a raw HTTP request (URL, headers) into the small, fixed set of
 * dimensions the Analytics module is allowed to store. This is the single
 * chokepoint where PII gets filtered OUT before anything reaches the spool
 * writer - collect.php calls this and only ever appends what it returns.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * THE QUERY STRING PROBLEM
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * Classic analytics leaks happen through the query string: "?email=a@b.com",
 * "?token=...", "?session=...". The rule here is a DEFAULT-DENY allowlist:
 * every query parameter is discarded UNLESS it is one of the five UTM keys,
 * which get their own strict validation (charset, length, cardinality cap).
 * There is no path by which an arbitrary query parameter reaches storage.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * WHAT GETS NORMALIZED
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *   path              query string + fragment stripped, lowercased, trailing
 *                      slash collapsed (except root), length-capped
 *   referrer_domain    registrable domain only (scheme/path/query stripped);
 *                       a same-site referrer is dropped entirely (self-referrer
 *                       tells us nothing about acquisition)
 *   device             desktop | mobile | tablet | other, from User-Agent +
 *                       Sec-CH-UA-Mobile when present
 *   country            ISO-3166-1 alpha-2 from a CDN/proxy header ONLY - never
 *                       from a GeoIP database lookup on the raw IP (task scope
 *                       explicitly excludes shipping/maintaining a GeoIP DB)
 *   utm_source/medium/campaign/term/content
 *                      allowlisted query keys, charset+length restricted
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * REJECTION (returns null - caller must not record anything)
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *   - known bot/crawler/monitoring User-Agent
 *   - DNT: 1 or Sec-GPC: 1 and respect_dnt is enabled in settings
 *   - Sec-Purpose: prefetch (speculative browser prefetch, not a real visit)
 *   - empty/missing User-Agent (real browsers always send one)
 *   - host not in the configured domain allowlist (when non-empty)
 *
 * @package NomadCMS\Services\Analytics
 */

declare(strict_types=1);

namespace NomadCMS\Services\Analytics;

final class RequestNormalizer
{
    /** Only these query keys ever survive normalization */
    private const UTM_KEYS = ['utm_source', 'utm_medium', 'utm_campaign', 'utm_term', 'utm_content'];

    /** Max stored length for a UTM value */
    private const UTM_MAX_LENGTH = 64;

    /** Max stored length for a normalized path */
    private const PATH_MAX_LENGTH = 512;

    /**
     * Case-insensitive substrings matched against the User-Agent. Deliberately
     * broad (substring, not exact) - bot UAs vary in punctuation/version but
     * reliably contain one of these tokens. False positives here only cost a
     * legitimate visit not being counted, never a privacy leak, so erring
     * toward over-matching is the safe direction.
     *
     * @var array<int, string>
     */
    private const BOT_UA_SUBSTRINGS = [
        'bot', 'crawl', 'spider', 'slurp', 'archiver', 'scraper',
        'headless', 'phantom', 'puppeteer', 'playwright', 'selenium',
        'curl/', 'wget/', 'python-requests', 'python-urllib', 'go-http-client',
        'java/', 'libwww-perl', 'httpclient', 'okhttp', 'axios/', 'node-fetch',
        'facebookexternalhit', 'discordbot', 'telegrambot', 'slackbot', 'whatsapp',
        'pingdom', 'uptimerobot', 'monitor', 'statuscake', 'ahrefsbot', 'semrushbot',
        'mj12bot', 'dotbot', 'petalbot', 'bytespider', 'gptbot', 'ccbot', 'claudebot',
        'anthropic', 'facebot', 'linkedinbot', 'twitterbot', 'pinterest',
    ];

    /** ISO-3166-1 alpha-2 shape check (does not validate against the real list, just the format) */
    private const COUNTRY_CODE_PATTERN = '/^[A-Z]{2}$/';

    /**
     * @param array{
     *   url: string,
     *   referrer: ?string,
     *   user_agent: ?string,
     *   headers: array<string, string>,
     *   host_allowlist: array<int, string>,
     *   respect_dnt: bool,
     *   bot_filter_enabled: bool,
     *   cardinality_cap?: int
     * } $request
     * @return array{
     *   host: string, path: string, referrer_domain: string, device: string,
     *   country: string, utm_source: string, utm_medium: string,
     *   utm_campaign: string, utm_term: string, utm_content: string
     * }|null Null means: do not record this event at all.
     */
    public static function normalize(array $request): ?array
    {
        $userAgent = trim((string) ($request['user_agent'] ?? ''));
        if ($userAgent === '') {
            return null; // Real browsers always send a UA; anything else is not a browser visit worth counting.
        }

        if (($request['bot_filter_enabled'] ?? true) && self::looksLikeBot($userAgent)) {
            return null;
        }

        $headers = self::lowercaseHeaderKeys($request['headers'] ?? []);

        if (($request['respect_dnt'] ?? true) && self::hasDoNotTrack($headers)) {
            return null;
        }

        if (self::isPrefetch($headers)) {
            return null;
        }

        $url = (string) ($request['url'] ?? '');
        $parts = self::parseUrl($url);
        if ($parts === null) {
            return null;
        }

        $host = strtolower($parts['host']);
        $allowlist = $request['host_allowlist'] ?? [];
        if (!empty($allowlist) && !in_array($host, $allowlist, true)) {
            return null;
        }

        $path = self::normalizePath($parts['path']);
        $utm = self::normalizeUtm($parts['query']);
        $referrerDomain = self::normalizeReferrer((string) ($request['referrer'] ?? ''), $host);
        $device = self::classifyDevice($userAgent, $headers);
        $country = self::normalizeCountry($headers);

        return [
            'host' => $host,
            'path' => $path,
            'referrer_domain' => $referrerDomain,
            'device' => $device,
            'country' => $country,
            'utm_source' => $utm['utm_source'],
            'utm_medium' => $utm['utm_medium'],
            'utm_campaign' => $utm['utm_campaign'],
            'utm_term' => $utm['utm_term'],
            'utm_content' => $utm['utm_content'],
        ];
    }

    // =========================================================================
    // PATH
    // =========================================================================

    /**
     * Strip query/fragment (already gone via parseUrl, kept here for callers
     * that pass a raw path), lowercase, collapse trailing slash, cap length.
     */
    public static function normalizePath(string $path): string
    {
        $path = strtok($path, '?#') ?: '/';
        if ($path === '') {
            $path = '/';
        }
        if ($path[0] !== '/') {
            $path = '/' . $path;
        }

        $path = strtolower($path);

        if (strlen($path) > 1 && str_ends_with($path, '/')) {
            $path = rtrim($path, '/');
            if ($path === '') {
                $path = '/';
            }
        }

        if (strlen($path) > self::PATH_MAX_LENGTH) {
            $path = substr($path, 0, self::PATH_MAX_LENGTH);
        }

        return $path;
    }

    // =========================================================================
    // UTM (the one deliberate exception to "drop the query string")
    // =========================================================================

    /**
     * @param array<string, string> $query
     * @return array{utm_source:string, utm_medium:string, utm_campaign:string, utm_term:string, utm_content:string}
     */
    public static function normalizeUtm(array $query): array
    {
        $result = [];
        foreach (self::UTM_KEYS as $key) {
            $raw = $query[$key] ?? null;
            $result[$key] = self::sanitizeUtmValue($raw);
        }
        return $result;
    }

    private static function sanitizeUtmValue(?string $raw): string
    {
        if ($raw === null) {
            return AnalyticsSchema::DIM_NONE;
        }

        $value = strtolower(trim($raw));
        if ($value === '') {
            return AnalyticsSchema::DIM_NONE;
        }

        // Allowlist charset: letters, digits, dot, underscore, hyphen, plus, space.
        // Anything else (HTML, punctuation used for injection, control chars) is stripped.
        $value = preg_replace('/[^a-z0-9._\-+ ]/', '', $value) ?? '';
        $value = trim($value);

        if ($value === '') {
            return AnalyticsSchema::DIM_NONE;
        }

        if (strlen($value) > self::UTM_MAX_LENGTH) {
            $value = substr($value, 0, self::UTM_MAX_LENGTH);
        }

        return $value;
    }

    // =========================================================================
    // REFERRER
    // =========================================================================

    /**
     * Reduce a referrer URL to its registrable-ish domain (host without a
     * leading "www."), or DIM_NONE when absent/unparseable/same-site.
     */
    public static function normalizeReferrer(string $referrer, string $currentHost): string
    {
        $referrer = trim($referrer);
        if ($referrer === '') {
            return AnalyticsSchema::DIM_NONE;
        }

        $host = parse_url($referrer, PHP_URL_HOST);
        if (!is_string($host) || $host === '') {
            return AnalyticsSchema::DIM_NONE;
        }

        $host = strtolower($host);
        $normalizedHost = preg_replace('/^www\./', '', $host) ?? $host;
        $normalizedCurrent = preg_replace('/^www\./', '', strtolower($currentHost)) ?? strtolower($currentHost);

        if ($normalizedHost === $normalizedCurrent) {
            // Self-referrer (internal navigation) - not an acquisition source.
            return AnalyticsSchema::DIM_NONE;
        }

        return $normalizedHost;
    }

    // =========================================================================
    // DEVICE
    // =========================================================================

    /**
     * @param array<string, string> $headers Lowercased header names
     */
    public static function classifyDevice(string $userAgent, array $headers): string
    {
        $mobileHint = $headers['sec-ch-ua-mobile'] ?? null;
        if ($mobileHint === '?1') {
            return AnalyticsSchema::DEVICE_MOBILE;
        }

        $ua = strtolower($userAgent);

        if (str_contains($ua, 'ipad') || (str_contains($ua, 'tablet') && !str_contains($ua, 'mobile'))
            || (str_contains($ua, 'android') && !str_contains($ua, 'mobile'))
        ) {
            return AnalyticsSchema::DEVICE_TABLET;
        }

        if (str_contains($ua, 'mobi') || str_contains($ua, 'iphone') || str_contains($ua, 'android')) {
            return AnalyticsSchema::DEVICE_MOBILE;
        }

        if (str_contains($ua, 'windows') || str_contains($ua, 'macintosh') || str_contains($ua, 'linux')
            || str_contains($ua, 'x11') || str_contains($ua, 'cros')
        ) {
            return AnalyticsSchema::DEVICE_DESKTOP;
        }

        return AnalyticsSchema::DEVICE_OTHER;
    }

    // =========================================================================
    // COUNTRY
    // =========================================================================

    /**
     * ISO-3166-1 alpha-2 from a CDN/proxy header ONLY. No GeoIP database
     * lookup on the raw IP is ever performed by this module.
     *
     * @param array<string, string> $headers Lowercased header names
     */
    public static function normalizeCountry(array $headers): string
    {
        $candidate = $headers['cf-ipcountry'] ?? $headers['x-country-code'] ?? null;
        if (!is_string($candidate)) {
            return AnalyticsSchema::DIM_NONE;
        }

        $candidate = strtoupper(trim($candidate));

        // Cloudflare sends "XX" for unknown/Tor traffic - treat as none.
        if ($candidate === 'XX' || $candidate === '') {
            return AnalyticsSchema::DIM_NONE;
        }

        if (!preg_match(self::COUNTRY_CODE_PATTERN, $candidate)) {
            return AnalyticsSchema::DIM_NONE;
        }

        return $candidate;
    }

    // =========================================================================
    // BOT / DNT / PREFETCH FILTERING
    // =========================================================================

    public static function looksLikeBot(string $userAgent): bool
    {
        $ua = strtolower($userAgent);
        foreach (self::BOT_UA_SUBSTRINGS as $needle) {
            if (str_contains($ua, $needle)) {
                return true;
            }
        }
        return false;
    }

    /**
     * @param array<string, string> $headers Lowercased header names
     */
    public static function hasDoNotTrack(array $headers): bool
    {
        if (($headers['dnt'] ?? null) === '1') {
            return true;
        }
        if (($headers['sec-gpc'] ?? null) === '1') {
            return true;
        }
        return false;
    }

    /**
     * @param array<string, string> $headers Lowercased header names
     */
    public static function isPrefetch(array $headers): bool
    {
        $purpose = strtolower((string) ($headers['sec-purpose'] ?? ($headers['purpose'] ?? '')));
        return str_contains($purpose, 'prefetch') || str_contains($purpose, 'preview');
    }

    // =========================================================================
    // INTERNAL HELPERS
    // =========================================================================

    /**
     * @return array{host:string, path:string, query:array<string,string>}|null
     */
    private static function parseUrl(string $url): ?array
    {
        $host = parse_url($url, PHP_URL_HOST);
        $path = parse_url($url, PHP_URL_PATH);
        $queryString = parse_url($url, PHP_URL_QUERY);

        if (!is_string($host) || $host === '') {
            return null;
        }

        $query = [];
        if (is_string($queryString) && $queryString !== '') {
            parse_str($queryString, $parsed);
            foreach ($parsed as $k => $v) {
                if (is_string($v)) {
                    $query[strtolower((string) $k)] = $v;
                }
            }
        }

        return [
            'host' => $host,
            'path' => is_string($path) ? $path : '/',
            'query' => $query,
        ];
    }

    /**
     * @param array<string, string> $headers
     * @return array<string, string>
     */
    private static function lowercaseHeaderKeys(array $headers): array
    {
        $result = [];
        foreach ($headers as $k => $v) {
            $result[strtolower((string) $k)] = (string) $v;
        }
        return $result;
    }
}
