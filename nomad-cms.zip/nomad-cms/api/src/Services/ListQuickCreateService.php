<?php
/**
 * NOMAD CMS — Authenticated quick creation in small JSON-backed lists.
 * Serializes name lookup and append under SQLite's write lock, preserving history,
 * ownership and relation indexes. Cache publication always happens after commit.
 */
declare(strict_types=1);

namespace NomadCMS\Services;

use NomadCMS\Database\CollectionDatabase;
use NomadCMS\Database\ContentDatabase;
use NomadCMS\Middleware\AuthMiddleware;
use NomadCMS\Services\Schema\SchemaDefinition;
use NomadCMS\Services\Schema\SchemaProvider;

final class ListQuickCreateService
{
    public static function createAuthorized(string $key, mixed $name): array
    {
        if (!AuthMiddleware::getCurrentUser()) {
            AuthMiddleware::requireAuth();
        }
        AuthMiddleware::requireSlotAccess($key);
        $readAll = AuthMiddleware::hasPermission('content:read:*', $key);
        if ((!$readAll && !AuthMiddleware::hasGrantedScope('content:read:own'))
            || (!AuthMiddleware::hasPermission('content:create:*', $key) && !AuthMiddleware::hasGrantedScope('content:create:own'))) {
            throw new \RuntimeException('Read and create permissions are required.', 403);
        }
        $actor = (string) (AuthMiddleware::getCurrentUser()->uuid ?? '');
        $result = self::create($key, $name, $actor, static fn (string $uid): bool => $readAll
            || ($actor !== '' && ContentDatabase::isOwnedBy($key, $actor, $uid)));
        if ($result['created']) {
            self::refreshCaches($key);
            try {
                (new \NomadCMS\Security\WebhookService())->dispatchEventAsync('content.created', [
                    'id' => $key, 'slot' => $key, 'slot_type' => 'list',
                    'item_uid' => $result['item']['_dndId'], 'content' => $result['item'],
                    'author_id' => $actor, 'timestamp' => gmdate('c'),
                ], $key, 'list');
            } catch (\Throwable $error) {
                error_log('[QuickCreate] Webhook dispatch failed: ' . $error->getMessage());
            }
        }
        return $result;
    }

    /** Trusted callers supply the visibility predicate; the HTTP boundary is createAuthorized(). */
    public static function create(string $key, mixed $name, string $actor, callable $canRead): array
    {
        SchemaProvider::assertWritable($key);
        $schema = RelationService::loadSchema();
        $slot = $schema['slots'][$key] ?? [];
        $template = SchemaDefinition::quickCreateTemplate($slot);
        $name = self::name($name);
        $normalized = self::normalizeName($name);
        $field = $slot['quickCreateField'];
        $candidate = $template + [$field => $name];
        if (SchemaDefinition::issues($candidate, $slot) !== []) {
            throw new \InvalidArgumentException('Name does not satisfy the list field validation.', 422);
        }
        return CollectionDatabase::transaction(static function (\PDO $db) use ($key, $actor, $canRead, $schema, $field, $candidate, $normalized): array {
            // The transaction helper acquires a write lock before any list read.
            $state = ContentDatabase::getSlotWithVersion($key);
            $items = $state['data'] ?? [];
            if (!is_array($items) || !array_is_list($items)) {
                throw new \InvalidArgumentException('Quick create requires a list.');
            }
            $inaccessibleMatch = false;
            foreach ($items as $item) {
                if (is_string($item[$field] ?? null) && self::normalizeName($item[$field]) === $normalized) {
                    $uid = RelationService::uidOf($item);
                    if ($uid !== null && $canRead($uid)) {
                        return ['success' => true, 'created' => false, 'item' => $item];
                    }
                    $inaccessibleMatch = true;
                }
            }
            if ($inaccessibleMatch) {
                throw new \RuntimeException('An existing value cannot be selected.', 409);
            }
            $item = ['_dndId' => RelationService::generateUid()] + $candidate;
            $item = SchemaProvider::validateWrite($key, $item);
            $items[] = $item;
            $items = RelationService::normalizeForSave($key, $items, $schema);
            $item = $items[array_key_last($items)];
            $save = ContentDatabase::saveSlotWithResult($key, $items, [
                'slot_type' => 'list', 'changed_by' => $actor, 'version_intent' => 'manual',
                'expected_version' => $state['version'] ?? 0,
            ]);
            if (!$save['success']) {
                throw new \RuntimeException('List save failed.');
            }
            if ($actor !== '') {
                $db->prepare('INSERT OR IGNORE INTO slot_ownership(slot_key,item_uid,owner_uuid) VALUES(?,?,?)')
                    ->execute([$key, $item['_dndId'], $actor]);
            }
            RelationService::clearCache($key);
            return ['success' => true, 'created' => true, 'item' => $item, 'version' => $save['version']];
        });
    }

    private static function name(mixed $name): string
    {
        if (!is_string($name) || !mb_check_encoding($name, 'UTF-8') || mb_strlen($name) > 1000) {
            throw new \InvalidArgumentException('Invalid quick-create name.', 422);
        }
        $name = preg_replace('/^\s+|\s+$/u', '', $name);
        if ($name === '' || preg_match('/[\x00-\x1f\x7f]/u', $name)) {
            throw new \InvalidArgumentException('Name must contain printable text.', 422);
        }
        if (!class_exists(\Normalizer::class)) {
            throw new \RuntimeException('Quick create requires PHP intl for Unicode normalization.', 503);
        }
        return \Normalizer::normalize($name, \Normalizer::FORM_C);
    }

    public static function normalizeName(string $name): string
    {
        if (!class_exists(\Normalizer::class)) {
            throw new \RuntimeException('Quick create requires PHP intl for Unicode normalization.', 503);
        }
        $trimmed = preg_replace('/^\s+|\s+$/u', '', $name);
        $normalized = $trimmed === null ? false : \Normalizer::normalize($trimmed, \Normalizer::FORM_C);
        if ($normalized === false) {
            throw new \InvalidArgumentException('Invalid Unicode name.', 422);
        }
        return mb_strtolower($normalized, 'UTF-8');
    }

    /** Bounded collection queues avoid loading article bodies to refresh an embedded label. */
    public static function refreshCaches(string $key): void
    {
        RelationService::clearCache($key);
        foreach ([$key, ...RelationService::getDependentSlots($key)] as $slot) {
            try {
                if (CollectionDatabase::isRegistered($slot)) {
                    StaticCacheService::markCollectionDirty($slot);
                } else {
                    StaticCacheService::generateForSlot($slot, ContentDatabase::getSlot($slot), null, true);
                }
            } catch (\Throwable $error) {
                StaticCacheService::invalidateSlot($slot);
                error_log('[QuickCreate] Cache refresh failed: ' . $error->getMessage());
            }
        }
        StaticCacheService::generateManifest();
    }
}
