<?php
/**
 * NOMAD CMS - RBAC Service
 *
 * Extended RBAC/ABAC-hybrid permission evaluation:
 * - Role-based permission strings: "resource:action:scope"
 *   - resource: content, media, users, webhooks, system, versions, logs, backup, forge, api_keys, forms, mail
 *   - action:   create, read, update, delete, list, restore, export, manage, admin, upload, assign, backup, decrypt
 *   - scope:    '*' (all) | 'own' (only resources owned by the current user)
 * - Wildcards: '*' matches any segment anywhere in resource/action/scope (e.g. '*:*:*', 'content:*:*')
 * - Slot access: per-role wildcard patterns against slot keys (prefix wildcards, e.g. "cikk*")
 * - Ownership resolution delegates to ContentDatabase::isOwnedBy() for the 'own' scope
 *
 * PRIVACY-SENSITIVE ACTION: 'decrypt' (used as "forms:decrypt:*") is the only
 * way to read the values of an ENCRYPTED form submission. It is deliberately
 * absent from MANAGE_COVERS and ADMIN_COVERS below, so a role holding
 * "forms:manage:*" can administer forms - create, edit, delete, change
 * submission status - without ever being able to read the personal data inside
 * them. Only an explicit "forms:decrypt:*", or a wildcard such as "forms:*:*" /
 * "*:*:*" (super_admin), unlocks it. Every use is written to the audit log.
 */

declare(strict_types=1);

namespace NomadCMS\Services;

use NomadCMS\Database\ContentDatabase;
use NomadCMS\Database\RoleRepository;

final class RBACService
{
    /** @var array<string, array> Per-request cache of role data keyed by role_slug */
    private static array $roleCache = [];

    /**
     * Actions implicitly covered by a granted 'manage' action on the same
     * resource. A role with e.g. "webhooks:manage:*" should be able to
     * perform any of these actions on "webhooks" without needing each one
     * spelled out individually in the permission list.
     *
     * NOTE: 'decrypt' and 'export' are intentionally NOT listed. 'decrypt'
     * exposes personal data (encrypted form submissions) and must always be an
     * explicit, auditable grant - a form administrator is not automatically
     * entitled to read the data inside the forms.
     *
     * @var array<int, string>
     */
    private const MANAGE_COVERS = ['create', 'read', 'update', 'delete', 'list', 'upload', 'assign', 'manage'];

    /**
     * Actions implicitly covered by a granted 'admin' action on the same
     * resource. 'admin' sits above 'manage' in the action hierarchy, so it
     * covers everything 'manage' covers, plus 'admin' itself.
     *
     * Still excludes 'decrypt' for the same reason as MANAGE_COVERS.
     *
     * @var array<int, string>
     */
    private const ADMIN_COVERS = [...self::MANAGE_COVERS, 'admin'];

    /**
     * Reset the in-memory cache (mainly for tests / long-running workers).
     */
    public static function resetCache(): void
    {
        self::$roleCache = [];
    }

    /**
     * Get (and cache) full role data including permissions & slot_access.
     */
    private static function getRole(string $roleSlug): ?array
    {
        if (!array_key_exists($roleSlug, self::$roleCache)) {
            self::$roleCache[$roleSlug] = RoleRepository::findBySlug($roleSlug);
        }

        return self::$roleCache[$roleSlug];
    }

    /**
     * Check whether a user (JWT payload user object, or array) has a given permission.
     *
     * Permission format: "resource:action:scope"
     *   - scope 'own' additionally requires an ownership check against the target
     *     slot/item. If no $slotKey is provided for an 'own'-scoped check, access
     *     is DENIED (fail-closed) since ownership cannot be verified.
     *
     * @param object|array $user User object/array with at least 'role_slug' or legacy 'is_admin'/'role'
     * @param string $permission e.g. "content:update:own", "media:upload:*"
     * @param string|null $slotKey Required when checking an 'own'-scoped permission against content
     * @param string|null $itemUid Item `_dndId` for list/collection item-level ownership checks
     */
    public static function hasPermission(
        object|array $user,
        string $permission,
        ?string $slotKey = null,
        ?string $itemUid = null
    ): bool {
        if (str_starts_with($permission, 'schema:')) {
            return $permission === \NomadCMS\Services\Schema\SchemaAccess::PERMISSION
                && \NomadCMS\Services\Schema\SchemaAccess::allowed($user);
        }
        $userArr = self::toArray($user);
        $roleSlug = self::resolveRoleSlug($userArr);
        $role = self::getRole($roleSlug);

        if (!$role) {
            return false;
        }

        $reqParts = self::parsePermission($permission);
        if ($reqParts === null) {
            return false;
        }
        [$reqResource, $reqAction, $reqScope] = $reqParts;

        foreach ($role['permissions'] as $granted) {
            $parts = self::parsePermission($granted);
            if ($parts === null) {
                continue;
            }
            [$gResource, $gAction, $gScope] = $parts;

            if (!self::resourceMatches($gResource, $reqResource)) {
                continue;
            }
            if (!self::actionMatches($gAction, $reqAction)) {
                continue;
            }

            // Scope resolution:
            // - granted '*' covers any requested scope (own or *)
            // - granted 'own' only covers a requested 'own' check AND only if the
            //   current user actually owns the target slot/item
            if ($gScope === '*') {
                return true;
            }

            if ($gScope === 'own') {
                if ($reqScope !== 'own' && $reqScope !== '*') {
                    continue;
                }
                if ($slotKey === null) {
                    // Fail-closed: cannot verify ownership without a target
                    continue;
                }
                $userUuid = $userArr['uuid'] ?? null;
                if ($userUuid && ContentDatabase::isOwnedBy($slotKey, $userUuid, $itemUid)) {
                    return true;
                }
                continue;
            }
        }

        return false;
    }

    
    /**
     * Check whether a role has been GRANTED a given scope for a permission
     * string, WITHOUT performing any ownership verification. This is the
     * building block for resources whose ownership model lives outside
     * ContentDatabase::isOwnedBy() (e.g. media uploads via media_meta.uploaded_by,
     * or file-based logs) - those endpoints call this to find out "does this
     * role have :own (or *) for this action at all?" and then do their OWN
     * domain-specific ownership check (e.g. compare uploaded_by === current user).
     *
     * Contrast with hasPermission(), which for scope 'own' ALSO verifies
     * content-slot ownership via ContentDatabase::isOwnedBy() - that method
     * remains the correct one for content/slot permission checks.
     *
     * @param object|array $user
     * @param string $permission e.g. "media:read:own" - the scope segment
     *                            actually checked is 'own' or '*' as requested
     * @return bool True if the role has a granted permission whose scope is
     *              '*' (always covers) or exactly 'own' matching the requested scope.
     */
    public static function hasGrantedScope(object|array $user, string $permission): bool
    {
        if (str_starts_with($permission, 'schema:')) {
            return $permission === \NomadCMS\Services\Schema\SchemaAccess::PERMISSION
                && \NomadCMS\Services\Schema\SchemaAccess::allowed($user);
        }
        $userArr = self::toArray($user);
        $roleSlug = self::resolveRoleSlug($userArr);
        $role = self::getRole($roleSlug);

        if (!$role) {
            return false;
        }

        $reqParts = self::parsePermission($permission);
        if ($reqParts === null) {
            return false;
        }
        [$reqResource, $reqAction, $reqScope] = $reqParts;

        foreach ($role['permissions'] as $granted) {
            $parts = self::parsePermission($granted);
            if ($parts === null) {
                continue;
            }
            [$gResource, $gAction, $gScope] = $parts;

            if (!self::resourceMatches($gResource, $reqResource)) {
                continue;
            }
            if (!self::actionMatches($gAction, $reqAction)) {
                continue;
            }

            if ($gScope === '*') {
                return true;
            }

            // A granted 'own' only satisfies a requested 'own' check - it must
            // NOT satisfy a requested '*' check (that would incorrectly report
            // "has the wildcard grant" as true for an own-only role).
            if ($gScope === 'own' && $reqScope === 'own') {
                return true;
            }
        }

        return false;
    }

    /**
     * Check whether a role/user can access a given slot key, based on the
     * role's slot_access wildcard patterns (prefix wildcards only, e.g. "cikk*").
     *
     * An empty slot_access array means NO slots are accessible (fail-closed,
     * NOT treated as "all slots").
     */
    public static function canAccessSlot(object|array $user, string $slotKey): bool
    {
        $userArr = self::toArray($user);
        $roleSlug = self::resolveRoleSlug($userArr);
        $role = self::getRole($roleSlug);

        if (!$role || empty($role['slot_access'])) {
            return false;
        }

        foreach ($role['slot_access'] as $pattern) {
            if (self::slotPatternMatches($pattern, $slotKey)) {
                return true;
            }
        }

        return false;
    }

    /**
     * Check ownership of a slot / item for the given user.
     */
    public static function isOwner(object|array $user, string $slotKey, ?string $itemUid = null): bool
    {
        $userArr = self::toArray($user);
        $userUuid = $userArr['uuid'] ?? null;

        if (!$userUuid) {
            return false;
        }

        return ContentDatabase::isOwnedBy($slotKey, $userUuid, $itemUid);
    }

    /**
     * Get the full effective permission list for a role slug.
     *
     * @return array<int, string>
     */
    public static function getEffectivePermissions(string $roleSlug): array
    {
        $role = self::getRole($roleSlug);
        return $role['permissions'] ?? [];
    }

    /**
     * Get the slot_access wildcard patterns for a role slug.
     *
     * @return array<int, string>
     */
    public static function getSlotAccess(string $roleSlug): array
    {
        $role = self::getRole($roleSlug);
        return $role['slot_access'] ?? [];
    }

    /**
     * Get a summarized, top-level list of resources the role has any access to
     * (used for compact JWT payloads - NOT the full permission list).
     *
     * @return array<int, string> e.g. ["content", "media", "versions"]
     */
    public static function getResourceSummary(string $roleSlug): array
    {
        $role = self::getRole($roleSlug);
        if (!$role) {
            return [];
        }

        $resources = [];
        foreach ($role['permissions'] as $permission) {
            $parts = self::parsePermission($permission);
            if ($parts === null) {
                continue;
            }
            $resources[$parts[0]] = true;
        }

        return array_keys($resources);
    }

    // =========================================================================
    // Internal helpers
    // =========================================================================

    /**
     * Resolve the role_slug for a user, with legacy fallback for users created
     * before the extended RBAC migration (is_admin / role columns).
     */
    private static function resolveRoleSlug(array $user): string
    {
        if (!empty($user['role_slug'])) {
            return $user['role_slug'];
        }

        if (!empty($user['is_admin'])) {
            return 'super_admin';
        }

        if (!empty($user['role']) && $user['role'] === 'editor') {
            return 'editor';
        }

        return RoleRepository::FALLBACK_ROLE;
    }

    /**
     * Parse a "resource:action:scope" permission string.
     *
     * @return array{0:string,1:string,2:string}|null
     */
    private static function parsePermission(string $permission): ?array
    {
        $parts = explode(':', $permission, 3);
        if (count($parts) === 2) {
            return [$parts[0], $parts[1], '*'];
        }
        if (count($parts) !== 3) {
            return null;
        }
        return $parts;
    }

    /**
     * Compare a granted resource segment against a requested one, supporting
     * only the '*' wildcard (exact match otherwise). Resource segments never
     * get super-action expansion (that's action-only, see actionMatches()).
     */
    private static function resourceMatches(string $granted, string $requested): bool
    {
        return $granted === '*' || $granted === $requested;
    }

    /**
     * Compare a granted action segment against a requested one, supporting '*'
     * wildcard plus the 'manage'/'admin' super-action hierarchy:
     *   - granted '*'      -> matches any requested action
     *   - granted 'admin'  -> matches any action in ADMIN_COVERS (= MANAGE_COVERS + 'admin')
     *   - granted 'manage' -> matches any action in MANAGE_COVERS
     *   - otherwise        -> exact match only
     *
     * This lets role editors grant a single "manage" checkbox in the
     * permission matrix UI instead of requiring every individual CRUD
     * action to be ticked separately.
     */
    private static function actionMatches(string $granted, string $requested): bool
    {
        if ($granted === '*' || $granted === $requested) {
            return true;
        }

        if ($granted === 'manage' && in_array($requested, self::MANAGE_COVERS, true)) {
            return true;
        }

        if ($granted === 'admin' && in_array($requested, self::ADMIN_COVERS, true)) {
            return true;
        }

        return false;
    }

    /**
     * Match a slot key against a role's slot_access pattern.
     *
     * Supports:
     * - exact match: "cikkek" matches only "cikkek"
     * - global wildcard: "*" matches everything
     * - prefix wildcard: "cikk*" matches any slot key starting with "cikk"
     */
    private static function slotPatternMatches(string $pattern, string $slotKey): bool
    {
        if ($pattern === '*') {
            return true;
        }

        if (str_ends_with($pattern, '*')) {
            $prefix = substr($pattern, 0, -1);
            return $prefix === '' || str_starts_with($slotKey, $prefix);
        }

        return $pattern === $slotKey;
    }

    /**
     * Normalize a user object/array into an associative array.
     */
    private static function toArray(object|array $user): array
    {
        return is_array($user) ? $user : (array) $user;
    }
}
