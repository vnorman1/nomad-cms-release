<?php

/**
 * NOMAD CMS - Notification editor option discovery.
 * Provides bounded, purpose-authorized recipient and webhook choices.
 * Never returns credentials, full user records or arbitrary transport URLs.
 */

declare(strict_types=1);

namespace NomadCMS\Services\NotificationService;

use NomadCMS\Security\WebhookService;

/** Minimal editor options independent of user-administration privileges. */
final class AdminOptionsService
{
    public function __construct(private NotificationModule $module)
    {
    }

    public function recipients(string $actor, array $query): array
    {
        $kind = $query['kind'] ?? 'users';
        $purpose = $query['purpose'] ?? 'announcement';
        if (!in_array($kind, ['users', 'roles'], true) || !in_array($purpose, ['announcement', 'rule'], true)) {
            throw new NotificationException('invalid_filter');
        }
        $this->module->access->require($actor, $purpose === 'rule' ? 'events:manage:*' : 'notifications:send:*');
        if ($purpose === 'announcement' && $kind === 'roles') {
            $this->module->access->require($actor, 'notifications:broadcast:*');
        }
        $search = trim(Support::text($query['q'] ?? '', 100, false));
        $limit = max(1, min(50, (int) ($query['limit'] ?? 20)));
        $tokenPurpose = 'recipients:' . $purpose . ':' . $kind . ':' . hash('sha256', $search);
        $secret = Support::one($this->module->db, "SELECT value FROM notification_meta WHERE key='cursor_secret'")['value'];
        $after = '';
        if (!empty($query['cursor'])) {
            $after = Support::decode((string) $query['cursor'], $secret, $tokenPurpose, $actor)['after'];
        }
        $pattern = '%' . str_replace(['\\', '%', '_'], ['\\\\', '\\%', '\\_'], $search) . '%';
        // Table and column names are fixed choices; every user value is bound.
        if ($kind === 'users') {
            $sql = "SELECT uuid AS id,email AS label FROM users WHERE is_new_user=0 AND uuid>? AND email LIKE ? ESCAPE '\\' ORDER BY uuid LIMIT " . ($limit + 1);
        } else {
            $sql = "SELECT slug AS id,slug AS label FROM roles WHERE slug>? AND slug LIKE ? ESCAPE '\\' ORDER BY slug LIMIT " . ($limit + 1);
        }
        $statement = $this->module->db->prepare($sql);
        $statement->execute([$after, $pattern]);
        $rows = $statement->fetchAll(\PDO::FETCH_ASSOC);
        $more = count($rows) > $limit;
        $rows = array_slice($rows, 0, $limit);
        return ['items' => $rows, 'next_cursor' => $more ? Support::token([
            'purpose' => $tokenPurpose, 'user' => $actor, 'after' => $rows[array_key_last($rows)]['id'],
        ], $secret) : null];
    }

    public function webhooks(string $actor): array
    {
        $this->module->access->require($actor, 'events:manage:*');
        if (!Support::one($this->module->db, "SELECT name FROM sqlite_master WHERE type='table' AND name='webhooks'")) {
            return ['items' => []];
        }
        $enabled = (new WebhookService())->isOutgoingEnabled();
        $rows = $this->module->db->query('SELECT id,name,is_active FROM webhooks ORDER BY id LIMIT 200')->fetchAll(\PDO::FETCH_ASSOC);
        return ['items' => array_map(static fn(array $row): array => [
            'id' => (int) $row['id'], 'label' => $row['name'], 'available' => $enabled && (bool) $row['is_active'],
        ], $rows)];
    }
}
