<?php

/**
 * NOMAD CMS - Notification channel registry.
 * Holds installed transport adapters and separates missing capability from transport failure.
 * SMTP absence is a supported state and cannot disable the in-app channel.
 */

declare(strict_types=1);

namespace NomadCMS\Services\NotificationService\Channels;

use NomadCMS\Services\NotificationService\NotificationException;

/** Named, explicitly installed channels. */
final class ChannelRegistry
{
    private array $channels = [];

    public function register(string $name, ChannelInterface $channel): void
    {
        $this->channels[$name] = $channel;
    }

    public function get(string $name): ChannelInterface
    {
        return $this->channels[$name] ?? throw new NotificationException('channel_unavailable', 503);
    }

    public function capability(string $name, array $configuration = []): array
    {
        try {
            return $this->get($name)->capability($configuration);
        } catch (\Throwable) {
            return ['available' => false, 'reason' => 'channel_unavailable'];
        }
    }

    public function names(): array
    {
        return array_keys($this->channels);
    }
}
