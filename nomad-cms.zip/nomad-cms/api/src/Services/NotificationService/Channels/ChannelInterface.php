<?php

/**
 * NOMAD CMS - Notification delivery channel contract.
 * Each adapter performs one bounded attempt and returns only classified outcomes.
 * Retry scheduling, leases and persistence belong to the central worker.
 */

declare(strict_types=1);

namespace NomadCMS\Services\NotificationService\Channels;

/** Server-installed adapter; request data cannot supply callable implementations. */
interface ChannelInterface
{
    public function capability(array $configuration): array;

    public function deliver(array $message, array $configuration, int $timeoutSeconds, string $deliveryId): array;
}
