<?php

/**
 * NOMAD CMS - Central notification webhook adapter.
 * Reuses existing registered targets, payload shaping, signatures and SSRF protections.
 * Performs one direct attempt and never creates a second legacy queue entry.
 */

declare(strict_types=1);

namespace NomadCMS\Services\NotificationService\Channels;

use NomadCMS\Security\WebhookService;
use NomadCMS\Database\AuthDatabase;
use NomadCMS\Services\NotificationService\Support;

/** Outbound integration tied to a preconfigured webhook identifier. */
final class WebhookAdapter implements ChannelInterface
{
    public function capability(array $configuration): array
    {
        $service = new WebhookService();
        $webhook = $service->getWebhook((int) ($configuration['webhook_id'] ?? 0));
        if (!$service->isOutgoingEnabled() || !$webhook || !$webhook['is_active']) {
            return ['available' => false, 'reason' => 'webhook_unavailable'];
        }
        $credentials = Support::one(AuthDatabase::getInstance(false), 'SELECT secret,headers FROM webhooks WHERE id=?', [(int) $configuration['webhook_id']]);
        return ['available' => true, 'fingerprint' => hash('sha256', Support::canonical([$webhook, $credentials]))];
    }

    public function deliver(array $message, array $configuration, int $timeoutSeconds, string $deliveryId): array
    {
        $capability = $this->capability($configuration);
        if (!$capability['available'] || !hash_equals($configuration['fingerprint'] ?? '', $capability['fingerprint'] ?? '')) {
            return ['status' => 'blocked', 'code' => 'webhook_configuration_changed'];
        }
        $result = (new WebhookService())->sendNotificationDirect(
            (int) $configuration['webhook_id'],
            $message['type'],
            $message + ['delivery_id' => $deliveryId],
            $timeoutSeconds,
            $deliveryId
        );
        if ($result->success) {
            return ['status' => 'sent', 'code' => 'accepted'];
        }
        $status = (int) $result->statusCode;
        return ['status' => $status === 429 || $status === 408 || $status >= 500 || $status === 0 ? 'retry_wait' : 'dead',
            'code' => 'webhook_http_' . $status];
    }
}
