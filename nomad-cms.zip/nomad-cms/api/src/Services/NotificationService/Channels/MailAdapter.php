<?php

/**
 * NOMAD CMS - Central notification email adapter.
 * Uses the existing verified MailService gate, escaped templates and stable Message-ID.
 * Profile fingerprints prevent retries silently changing the configured sender identity.
 */

declare(strict_types=1);

namespace NomadCMS\Services\NotificationService\Channels;

use NomadCMS\Services\Mail\MailException;
use NomadCMS\Services\Mail\MailProfileStore;
use NomadCMS\Services\Mail\MailSchema;
use NomadCMS\Services\Mail\MailService;
use NomadCMS\Services\NotificationService\Support;

/** Optional outbound email through an already verified SMTP profile. */
final class MailAdapter implements ChannelInterface
{
    public function capability(array $configuration): array
    {
        if (($_ENV['FORMS_MAIL_ENABLED'] ?? 'true') === 'false') {
            return ['available' => false, 'reason' => 'email_disabled'];
        }
        MailProfileStore::clearCache();
        $config = MailProfileStore::resolve($configuration['profile_uuid'] ?? null);
        if ($config === null) {
            return ['available' => false, 'reason' => 'smtp_not_configured'];
        }
        if ($config['status'] !== MailSchema::STATUS_VERIFIED || $config['driver'] === MailSchema::DRIVER_DISABLED) {
            return ['available' => false, 'reason' => 'smtp_not_verified'];
        }
        if ($config['driver'] !== MailSchema::DRIVER_SMTP) {
            return ['available' => false, 'reason' => 'smtp_required'];
        }
        $identity = array_intersect_key($config, array_flip(['uuid', 'driver', 'host', 'port', 'encryption', 'username', 'from_email', 'from_name', 'advanced']));
        return ['available' => true, 'reason' => null, 'profile_uuid' => $config['uuid'],
            'fingerprint' => hash('sha256', Support::canonical($identity))];
    }

    public function deliver(array $message, array $configuration, int $timeoutSeconds, string $deliveryId): array
    {
        $current = $this->capability($configuration);
        if (!$current['available'] || !hash_equals($configuration['fingerprint'] ?? '', $current['fingerprint'] ?? '')) {
            return ['status' => 'blocked', 'code' => 'smtp_configuration_changed'];
        }
        $escape = static fn(string $text): string => htmlspecialchars($text, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
        $html = '<!doctype html><html><body><h1>' . $escape($message['title']) . '</h1><p>'
            . nl2br($escape($message['message'])) . '</p></body></html>';
        try {
            MailService::send(
                $configuration['email'],
                $message['title'],
                $message['message'],
                $html,
                $configuration['profile_uuid'],
                $timeoutSeconds,
                '<notification-' . $deliveryId . '@nomad.invalid>'
            );
            return ['status' => 'sent', 'code' => 'accepted'];
        } catch (MailException $error) {
            $code = $error->getErrorCode();
            $state = match ($code) {
                'MAIL_NOT_VERIFIED', 'MAIL_PROFILE_NOT_FOUND', 'MAIL_DRIVER_DISABLED', 'AUTH_FAILED', 'FROM_REJECTED', 'CERT_VERIFY_FAILED' => 'blocked',
                'RECIPIENT_REJECTED' => 'dead',
                default => 'retry_wait',
            };
            return ['status' => $state, 'code' => $code];
        }
    }
}
