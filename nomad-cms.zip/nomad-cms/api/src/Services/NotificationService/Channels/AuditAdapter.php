<?php

/**
 * NOMAD CMS - Idempotent notification audit output.
 * Writes a minimal durable occurrence without logging private payloads or secrets.
 * Domain security audits remain the responsibility of their original services.
 */

declare(strict_types=1);

namespace NomadCMS\Services\NotificationService\Channels;

use NomadCMS\Services\NotificationService\Support;
use PDO;

/** Independently selectable audit delivery adapter. */
final class AuditAdapter implements ChannelInterface
{
    public function __construct(private PDO $db, private \Closure $clock)
    {
    }

    public function capability(array $configuration): array
    {
        return ['available' => true, 'fingerprint' => 'audit.v1'];
    }

    public function deliver(array $message, array $configuration, int $timeoutSeconds, string $deliveryId): array
    {
        Support::run(
            $this->db,
            'INSERT OR IGNORE INTO notification_audit VALUES(?,?,?,?,?)',
            [$deliveryId, null, $message['event_id'], 'event.delivered', ($this->clock)()]
        );
        return ['status' => 'sent', 'code' => 'recorded'];
    }
}
