<?php

/**
 * NOMAD CMS - Notification persistence and cursor primitives.
 * Provides canonical JSON, savepoint-aware transactions and authenticated tokens.
 * No network calls or implicit schema changes belong in these helpers.
 */

declare(strict_types=1);

namespace NomadCMS\Services\NotificationService;

use PDO;
use Throwable;

/** Shared bounded serialization and transaction helpers. */
final class Support
{
    public static function id(): string
    {
        return \Ramsey\Uuid\Uuid::uuid4()->toString();
    }

    public static function json(mixed $value): string
    {
        return json_encode($value, JSON_THROW_ON_ERROR | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    }

    public static function canonical(mixed $value): string
    {
        if (is_array($value)) {
            if (!array_is_list($value)) {
                ksort($value);
            }
            foreach ($value as &$child) {
                $child = json_decode(self::canonical($child), true, 64, JSON_THROW_ON_ERROR);
            }
            unset($child);
        }
        return self::json($value);
    }

    public static function transaction(PDO $db, callable $work, bool $writer = false): mixed
    {
        $nested = $db->inTransaction();
        $savepoint = 'notification_' . bin2hex(random_bytes(6));
        $nested ? $db->exec('SAVEPOINT ' . $savepoint) : $db->beginTransaction();
        try {
            if ($writer) {
                $db->exec("UPDATE notification_meta SET value=value WHERE key='schema_version'");
            }
            $result = $work();
            $nested ? $db->exec('RELEASE SAVEPOINT ' . $savepoint) : $db->commit();
            return $result;
        } catch (Throwable $error) {
            if ($nested) {
                $db->exec('ROLLBACK TO SAVEPOINT ' . $savepoint);
                $db->exec('RELEASE SAVEPOINT ' . $savepoint);
            } elseif ($db->inTransaction()) {
                $db->rollBack();
            }
            throw $error;
        }
    }

    public static function one(PDO $db, string $sql, array $parameters = []): ?array
    {
        $statement = self::statement($db, $sql, $parameters);
        $row = $statement->fetch(PDO::FETCH_ASSOC);
        $statement->closeCursor();
        return $row ?: null;
    }

    public static function run(PDO $db, string $sql, array $parameters = []): int
    {
        $statement = self::statement($db, $sql, $parameters);
        return $statement->rowCount();
    }

    /** SQLite scalar MIN/MAX has no column affinity: sequence and time binds must stay numeric. */
    private static function statement(PDO $db, string $sql, array $parameters): \PDOStatement
    {
        $statement = $db->prepare($sql);
        foreach ($parameters as $key => $value) {
            $type = match (true) {
                is_int($value), is_bool($value) => PDO::PARAM_INT,
                $value === null => PDO::PARAM_NULL,
                default => PDO::PARAM_STR,
            };
            $statement->bindValue(is_int($key) ? $key + 1 : $key, $value, $type);
        }
        $statement->execute();
        return $statement;
    }

    public static function token(array $payload, string $secret): string
    {
        $body = rtrim(strtr(base64_encode(self::json($payload)), '+/', '-_'), '=');
        return $body . '.' . hash_hmac('sha256', $body, $secret);
    }

    public static function decode(string $token, string $secret, string $purpose, string $user): array
    {
        if (strlen($token) > 2048) {
            throw new NotificationException('invalid_cursor');
        }
        $parts = explode('.', $token);
        if (count($parts) !== 2 || !hash_equals(hash_hmac('sha256', $parts[0], $secret), $parts[1])) {
            throw new NotificationException('invalid_cursor');
        }
        $payload = json_decode((string) base64_decode(strtr($parts[0], '-_', '+/'), true), true);
        if (!is_array($payload) || ($payload['purpose'] ?? '') !== $purpose || ($payload['user'] ?? '') !== $user) {
            throw new NotificationException('invalid_cursor');
        }
        return $payload;
    }

    public static function keys(array $input, array $allowed): void
    {
        if (array_diff(array_keys($input), $allowed)) {
            throw new NotificationException('unknown_field');
        }
    }

    public static function text(mixed $value, int $max, bool $required = true): string
    {
        if (
            !is_string($value) || !mb_check_encoding($value, 'UTF-8') || mb_strlen($value) > $max
            || ($required && trim($value) === '') || preg_match('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/', $value)
        ) {
            throw new NotificationException('invalid_text');
        }
        return trim($value);
    }
}
