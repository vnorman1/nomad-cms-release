<?php

/**
 * NOMAD CMS - Central notification service contract.
 * Provides durable module publication and authenticated manual administrator submission.
 * Both operations enqueue work; neither performs synchronous external delivery.
 */

declare(strict_types=1);

namespace NomadCMS\Services\NotificationService;

use NomadCMS\Services\NotificationService\Contracts\AuthenticatedActor;
use NomadCMS\Services\NotificationService\Contracts\DomainEvent;
use PDO;

/** Public integration boundary; callers never write central notification tables. */
interface NotificationServiceInterface
{
    public function publish(PDO $sourceDb, DomainEvent $event): array;

    public function sendByAdmin(array $request, AuthenticatedActor $actor, string $idempotencyKey): array;
}
