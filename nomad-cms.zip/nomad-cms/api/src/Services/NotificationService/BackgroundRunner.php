<?php

/**
 * NOMAD CMS - Notification background orchestration.
 * Runs bounded local projections and external work under the caller's deadline.
 * The request fallback only moves SQLite records; it never calls SMTP or HTTP.
 */

declare(strict_types=1);

namespace NomadCMS\Services\NotificationService;

use NomadCMS\Database\AuthDatabase;
use NomadCMS\Database\ContentDatabase;
use NomadCMS\Database\MassiveDatabase;
use NomadCMS\Services\EditorialsHub\Notifications\MentionNotificationBridge;
use NomadCMS\Services\NotificationService\Events\SourcePublisher;
use NomadCMS\Services\NotificationService\Maintenance\MaintenanceService;
use NomadCMS\Services\NotificationService\Migrations\Schema;
use NomadCMS\Webhooks\Mapping\WebhookNotificationBridge;

/** Shared entry point for CLI, protected cron and the local request fallback. */
final class BackgroundRunner
{
    public const TASKS = ['event_outbox_relay', 'event_router', 'notification_batch_flush',
        'event_delivery', 'notification_retention'];

    public function __construct(private NotificationModule $module)
    {
    }

    public function run(string $task, float $deadline): int
    {
        return \NomadCMS\Security\PanicMutationGuard::run(function () use ($task, $deadline): int {
            if (!in_array($task, self::TASKS, true)) {
                throw new NotificationException('unknown_background_task');
            }
            if (microtime(true) >= $deadline) {
                return 0;
            }
            $count = match ($task) {
                'event_outbox_relay' => $this->relay($deadline),
                'event_router' => $this->module->router->run(100, $deadline),
                'notification_batch_flush' => $this->module->delivery->flush(50, $deadline),
                'event_delivery' => $this->module->delivery->process(5, $deadline),
                'notification_retention' => (new MaintenanceService($this->module->db, $this->module->clock))->run(),
            };
            Support::run(
                $this->module->db,
                'INSERT INTO notification_meta VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value',
                ['last_run:' . $task, (string) ($this->module->clock)()]
            );
            return $count;
        });
    }

    private function relay(float $deadline): int
    {
        $count = $this->module->publisher->relay($this->module->db, 50, $deadline);
        foreach (['DB_CONTENT_DATABASE' => ['database.sqlite', false], 'DB_MASSIVE_DATABASE' => ['massive.sqlite', true]] as $setting => [$default, $massive]) {
            $file = $_ENV[$setting] ?? $default;
            if (microtime(true) >= $deadline || !is_file(dirname(__DIR__, 3) . '/databases/' . $file)) {
                continue;
            }
            try {
                $source = $massive ? MassiveDatabase::getInstance(true) : ContentDatabase::getInstance(false);
                if ($massive) {
                    $count += (new WebhookNotificationBridge(
                        $source,
                        $this->module->db,
                        new SourcePublisher($this->module->events, $this->module->clock),
                        $this->module->clock
                    ))->run(50, $deadline);
                    $count += (new MentionNotificationBridge(
                        $source,
                        new SourcePublisher($this->module->events, $this->module->clock),
                        $this->module->clock
                    ))->run(50, $deadline);
                }
                if (!Support::one($source, "SELECT name FROM sqlite_master WHERE name='event_outbox' AND type='table'")) {
                    continue;
                }
                $count += $this->module->publisher->relay($source, 50, $deadline);
                Support::run(
                    $source,
                    "DELETE FROM event_outbox WHERE id IN(SELECT id FROM event_outbox WHERE state='accepted' AND accepted_at<? LIMIT 500)",
                    [($this->module->clock)() - 604800]
                );
            } catch (\PDOException) {
                // An unavailable source retains its own outbox for the next run.
                error_log('[notifications] source_relay_unavailable');
            }
        }
        return $count;
    }

    public static function isNotificationRequest(string $uri): bool
    {
        $path = parse_url($uri, PHP_URL_PATH) ?: '';
        return (bool) preg_match('~^/api/(?:endpoints/)?(?:admin/)?(?:notifications|notification-preferences|event-rules|event-destinations|event-deliveries|events)(?:/|\.php$|$)~D', $path);
    }

    public static function registerPiggyback(): void
    {
        if (
            PHP_SAPI === 'cli' || !is_file(dirname(__DIR__, 3) . '/.env')
            || ($_ENV['NOTIFICATIONS_PIGGYBACK_PROCESSING'] ?? 'true') !== 'true'
        ) {
            return;
        }
        $uri = $_SERVER['REQUEST_URI'] ?? '';
        if (
            str_contains($uri, '/collect') || str_contains($uri, '/cron')
            || \NomadCMS\Services\WebhookBackgroundPolicy::isEditorRequest($uri)
            || self::isNotificationRequest($uri)
            || \NomadCMS\Services\EditorialsHub\HttpPaths::isHub($uri)
        ) {
            return;
        }
        register_shutdown_function(static function (): void {
            if (function_exists('fastcgi_finish_request')) {
                fastcgi_finish_request();
            }
            try {
                if (\NomadCMS\Security\PanicModeService::isActive()) {
                    return;
                }
                \NomadCMS\Security\PanicMutationGuard::run(static function (): void {
                    $db = AuthDatabase::getInstance(false);
                    if (!Schema::installed($db)) {
                        return;
                    }
                    $due = Support::transaction($db, static function () use ($db): bool {
                        $last = Support::one($db, "SELECT value FROM notification_meta WHERE key='last_local_run'");
                        if ((int) ($last['value'] ?? 0) > time() - 10) {
                            return false;
                        }
                        Support::run($db, "INSERT INTO notification_meta VALUES('last_local_run',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value", [(string) time()]);
                        return true;
                    }, true);
                    if ($due) {
                        $runner = new self(NotificationModule::create());
                        $deadline = microtime(true) + 2;
                        $runner->run('event_outbox_relay', $deadline);
                        $runner->run('event_router', $deadline);
                        $runner->run('notification_batch_flush', $deadline);
                    }
                });
            } catch (\Throwable) {
                error_log('[notifications] local_processing_unavailable');
            }
        });
    }
}
