<?php

/**
 * NOMAD CMS - Notification schema.
 * Explicit, transactional installation of row-backed inbox, outbox and delivery state.
 * Never invoked from polling requests; grants are seeded once and never restored.
 */

declare(strict_types=1);

namespace NomadCMS\Services\NotificationService\Migrations;

use NomadCMS\Services\NotificationService\Support;
use PDO;

/** Versioned storage installation independent of Forms and Editorials Hub. */
final class Schema
{
    public static function installed(PDO $db): bool
    {
        return Support::one($db, "SELECT name FROM sqlite_master WHERE type='table' AND name='notification_meta'") !== null
            && Support::one($db, "SELECT value FROM notification_meta WHERE key='schema_version' AND value='2'") !== null;
    }

    public static function source(PDO $db): void
    {
        $db->exec(<<<'SQL'
CREATE TABLE IF NOT EXISTS event_outbox (
 id TEXT PRIMARY KEY, source TEXT NOT NULL, type TEXT NOT NULL, occurrence_key TEXT NOT NULL,
 payload TEXT NOT NULL, payload_hash TEXT NOT NULL, state TEXT NOT NULL DEFAULT 'pending'
 CHECK(state IN ('pending','accepted','dead')), available_at INTEGER NOT NULL,
 created_at INTEGER NOT NULL, accepted_at INTEGER, last_error TEXT,
 UNIQUE(source,type,occurrence_key)
);
CREATE INDEX IF NOT EXISTS event_outbox_pending ON event_outbox(state,available_at,id);
SQL);
    }

    /** Create the current schema directly on a fresh system database. */
    public static function install(PDO $db): void
    {
        if (self::installed($db)) {
            return;
        }
        if (Support::one($db, "SELECT 1 FROM sqlite_master WHERE type='table' AND name='notification_meta'")) {
            throw new \LogicException('Notification schema requires an explicit migration.');
        }
        self::apply($db, false);
    }

    public static function migrate(PDO $db): void
    {
        self::apply($db, true);
    }

    /** Shared current definitions; only upgrades inspect and alter legacy columns. */
    private static function apply(PDO $db, bool $upgrade): void
    {
        Support::transaction($db, static function () use ($db, $upgrade): void {
            $db->exec(<<<'SQL'
CREATE TABLE IF NOT EXISTS notification_meta(key TEXT PRIMARY KEY,value TEXT NOT NULL);
INSERT OR IGNORE INTO notification_meta VALUES('schema_version','2');
INSERT OR IGNORE INTO notification_meta VALUES('external_paused','0');
CREATE TABLE IF NOT EXISTS notification_announcements (
 id TEXT PRIMARY KEY, actor_uuid TEXT NOT NULL, idempotency_key TEXT NOT NULL,
 payload TEXT NOT NULL, payload_hash TEXT NOT NULL, event_id TEXT NOT NULL,
 receipt TEXT NOT NULL, created_at INTEGER NOT NULL,
 UNIQUE(actor_uuid,idempotency_key)
);
CREATE INDEX IF NOT EXISTS notification_announcements_created ON notification_announcements(created_at DESC,id DESC);
CREATE INDEX IF NOT EXISTS notification_announcements_actor ON notification_announcements(actor_uuid,created_at DESC,id DESC);
CREATE TABLE IF NOT EXISTS event_events (
 id TEXT PRIMARY KEY, source TEXT NOT NULL,type TEXT NOT NULL,occurrence_key TEXT NOT NULL,
 payload TEXT NOT NULL,payload_hash TEXT NOT NULL,received_at INTEGER NOT NULL,
 state TEXT NOT NULL DEFAULT 'pending' CHECK(state IN ('pending','routing','completed','dead')),
 rules_version TEXT,last_error TEXT,UNIQUE(source,type,occurrence_key)
);
CREATE INDEX IF NOT EXISTS event_events_pending ON event_events(state,received_at,id);
CREATE TABLE IF NOT EXISTS event_rule_sets(id TEXT PRIMARY KEY,payload TEXT NOT NULL,created_at INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS event_rules (
 id TEXT NOT NULL,version INTEGER NOT NULL,payload TEXT NOT NULL,active INTEGER NOT NULL,
 created_at INTEGER NOT NULL,PRIMARY KEY(id,version)
);
CREATE TABLE IF NOT EXISTS event_destinations (
 id TEXT PRIMARY KEY,version INTEGER NOT NULL,payload TEXT NOT NULL,active INTEGER NOT NULL,updated_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS event_routes (
 id TEXT PRIMARY KEY,event_id TEXT NOT NULL REFERENCES event_events(id),
 fingerprint TEXT NOT NULL,payload TEXT NOT NULL,state TEXT NOT NULL DEFAULT 'pending',
 UNIQUE(event_id,fingerprint)
);
CREATE INDEX IF NOT EXISTS event_routes_event ON event_routes(event_id,id);
CREATE INDEX IF NOT EXISTS event_routes_pending ON event_routes(state,id);
CREATE TABLE IF NOT EXISTS event_recipients (
 route_id TEXT NOT NULL REFERENCES event_routes(id),user_uuid TEXT NOT NULL,
 state TEXT NOT NULL DEFAULT 'pending',outcomes TEXT,PRIMARY KEY(route_id,user_uuid)
);
CREATE INDEX IF NOT EXISTS event_recipients_pending ON event_recipients(state,route_id,user_uuid);
CREATE TABLE IF NOT EXISTS notification_preferences (
 user_uuid TEXT NOT NULL,scope TEXT NOT NULL,in_app INTEGER NOT NULL,
 email TEXT NOT NULL CHECK(email IN ('off','immediate','digest')),version INTEGER NOT NULL,
 inherited INTEGER NOT NULL DEFAULT 0,
 PRIMARY KEY(user_uuid,scope)
);
CREATE TABLE IF NOT EXISTS notification_user_state (
 user_uuid TEXT PRIMARY KEY,last_activity_seq INTEGER NOT NULL DEFAULT 0,
 read_through_seq INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS notification_inbox (
 id TEXT PRIMARY KEY,user_uuid TEXT NOT NULL,event_id TEXT NOT NULL REFERENCES event_events(id),
 group_key TEXT NOT NULL,group_until INTEGER NOT NULL,payload TEXT NOT NULL,
 event_count INTEGER NOT NULL DEFAULT 1,activity_seq INTEGER NOT NULL,read_seq INTEGER NOT NULL DEFAULT 0,
 archived_at INTEGER,created_at INTEGER NOT NULL,updated_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS notification_inbox_page ON notification_inbox(user_uuid,created_at DESC,id DESC);
CREATE INDEX IF NOT EXISTS notification_inbox_unread ON notification_inbox(user_uuid,activity_seq) WHERE archived_at IS NULL;
CREATE INDEX IF NOT EXISTS notification_inbox_group ON notification_inbox(user_uuid,group_key,group_until) WHERE archived_at IS NULL;
CREATE TABLE IF NOT EXISTS notification_inbox_events (
 notification_id TEXT NOT NULL REFERENCES notification_inbox(id) ON DELETE CASCADE,
 event_id TEXT NOT NULL REFERENCES event_events(id),user_uuid TEXT NOT NULL,
 PRIMARY KEY(notification_id,event_id),UNIQUE(event_id,user_uuid)
);
CREATE TABLE IF NOT EXISTS notification_batches (
 id TEXT PRIMARY KEY,user_uuid TEXT NOT NULL,group_key TEXT NOT NULL,payload TEXT NOT NULL,
 state TEXT NOT NULL DEFAULT 'open',created_at INTEGER NOT NULL,closes_at INTEGER NOT NULL,max_closes_at INTEGER NOT NULL
);
CREATE UNIQUE INDEX IF NOT EXISTS notification_batches_open ON notification_batches(user_uuid,group_key) WHERE state='open';
CREATE INDEX IF NOT EXISTS notification_batches_due ON notification_batches(state,closes_at,id);
CREATE TABLE IF NOT EXISTS notification_batch_events (
 batch_id TEXT NOT NULL REFERENCES notification_batches(id) ON DELETE CASCADE,
 event_id TEXT NOT NULL REFERENCES event_events(id),PRIMARY KEY(batch_id,event_id)
);
CREATE TABLE IF NOT EXISTS event_deliveries (
 id TEXT PRIMARY KEY,event_id TEXT NOT NULL REFERENCES event_events(id),route_id TEXT NOT NULL,
 batch_id TEXT REFERENCES notification_batches(id),user_uuid TEXT,channel TEXT NOT NULL,
 payload TEXT NOT NULL,dedupe_key TEXT NOT NULL UNIQUE,
 state TEXT NOT NULL DEFAULT 'pending' CHECK(state IN ('pending','processing','retry_wait','blocked','sent','dead','cancelled')),
 priority INTEGER NOT NULL,available_at INTEGER NOT NULL,expires_at INTEGER NOT NULL,
 attempts INTEGER NOT NULL DEFAULT 0,lease_token TEXT,lease_until INTEGER,last_error TEXT,
 created_at INTEGER NOT NULL,completed_at INTEGER
);
CREATE INDEX IF NOT EXISTS event_deliveries_due ON event_deliveries(state,priority,available_at,id);
CREATE INDEX IF NOT EXISTS event_deliveries_lease ON event_deliveries(state,lease_until);
CREATE INDEX IF NOT EXISTS event_deliveries_expiry ON event_deliveries(state,expires_at,id);
CREATE INDEX IF NOT EXISTS event_deliveries_page ON event_deliveries(created_at DESC,id DESC);
CREATE INDEX IF NOT EXISTS event_deliveries_event ON event_deliveries(event_id,state);
CREATE INDEX IF NOT EXISTS event_deliveries_batch ON event_deliveries(batch_id);
CREATE TABLE IF NOT EXISTS event_delivery_attempts (
 id INTEGER PRIMARY KEY,delivery_id TEXT NOT NULL REFERENCES event_deliveries(id) ON DELETE CASCADE,
 attempt INTEGER NOT NULL,result TEXT NOT NULL,duration_ms INTEGER NOT NULL,created_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS event_attempts_created ON event_delivery_attempts(created_at,id);
CREATE TABLE IF NOT EXISTS event_dedup_receipts (
 source TEXT NOT NULL,type TEXT NOT NULL,occurrence_key TEXT NOT NULL,event_id TEXT NOT NULL,
 payload_hash TEXT NOT NULL,created_at INTEGER NOT NULL,PRIMARY KEY(source,type,occurrence_key)
);
CREATE TABLE IF NOT EXISTS notification_audit (
 id TEXT PRIMARY KEY,actor_uuid TEXT,event_id TEXT,operation TEXT NOT NULL,created_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS notification_audit_created ON notification_audit(created_at,id);
CREATE INDEX IF NOT EXISTS notification_inbox_events_event ON notification_inbox_events(event_id);
CREATE INDEX IF NOT EXISTS notification_batch_events_event ON notification_batch_events(event_id);
CREATE TABLE IF NOT EXISTS notification_rate_limits (
 user_uuid TEXT NOT NULL,bucket INTEGER NOT NULL,count INTEGER NOT NULL,PRIMARY KEY(user_uuid,bucket)
);
SQL);
            if ($upgrade) {
                $columns = $db->query('PRAGMA table_info(notification_preferences)')->fetchAll(PDO::FETCH_COLUMN, 1);
                if (!in_array('inherited', $columns, true)) {
                    $db->exec('ALTER TABLE notification_preferences ADD COLUMN inherited INTEGER NOT NULL DEFAULT 0');
                }
            }
            self::source($db);
            Support::run($db, "INSERT OR IGNORE INTO notification_meta VALUES('cursor_secret',?)", [bin2hex(random_bytes(32))]);
            if (!Support::one($db, "SELECT value FROM notification_meta WHERE key='permission_baseline'")) {
                $own = ['notifications:read:own', 'notifications:manage:own'];
                foreach ($own as $permission) {
                    Support::run($db, 'INSERT OR IGNORE INTO role_permissions(role_id,permission) SELECT id,? FROM roles', [$permission]);
                }
                $admin = ['notifications:send:*', 'notifications:broadcast:*', 'notifications:send_urgent:*',
                    'notifications:read_sent:*', 'events:read:*', 'events:manage:*', 'events:retry:*'];
                foreach ($admin as $permission) {
                    Support::run($db, "INSERT OR IGNORE INTO role_permissions(role_id,permission) SELECT id,? FROM roles WHERE slug='super_admin'", [$permission]);
                }
                Support::run($db, "INSERT INTO notification_meta VALUES('permission_baseline','1')");
            }
            Support::run($db, "UPDATE notification_meta SET value='2' WHERE key='schema_version'");
        });
    }
}
