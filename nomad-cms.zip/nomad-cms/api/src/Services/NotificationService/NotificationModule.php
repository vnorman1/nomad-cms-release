<?php

/**
 * NOMAD CMS - Notification composition root.
 * Assembles the standalone service from injected storage, clock, policies and channels.
 * Installation is explicit; constructing a module never changes the schema.
 */

declare(strict_types=1);

namespace NomadCMS\Services\NotificationService;

use NomadCMS\Database\AuthDatabase;
use NomadCMS\Services\NotificationService\Channels\AuditAdapter;
use NomadCMS\Services\NotificationService\Channels\ChannelRegistry;
use NomadCMS\Services\NotificationService\Channels\MailAdapter;
use NomadCMS\Services\NotificationService\Channels\WebhookAdapter;
use NomadCMS\Services\NotificationService\Delivery\DeliveryService;
use NomadCMS\Services\NotificationService\Events\EventDefinition;
use NomadCMS\Services\NotificationService\Events\EventPublisher;
use NomadCMS\Services\NotificationService\Events\EventRegistry;
use NomadCMS\Services\NotificationService\Inbox\InboxService;
use NomadCMS\Services\NotificationService\Migrations\Schema;
use NomadCMS\Services\NotificationService\Policy\Access;
use NomadCMS\Services\NotificationService\Preferences\PreferenceService;
use NomadCMS\Services\NotificationService\Routing\AudienceResolver;
use NomadCMS\Services\NotificationService\Routing\ControlService;
use NomadCMS\Services\NotificationService\Routing\EventRouter;
use NomadCMS\Services\NotificationService\Targets\TargetRegistry;
use PDO;

/** Central module usable without Forms, Editorials or SMTP configuration. */
final class NotificationModule
{
    private static ?\Closure $configurator = null;
    public readonly EventRegistry $events;
    public readonly ChannelRegistry $channels;
    public readonly TargetRegistry $targets;
    public readonly AudienceResolver $audiences;
    public readonly Access $access;
    public readonly EventPublisher $publisher;
    public readonly PreferenceService $preferences;
    public readonly InboxService $inbox;
    public readonly ControlService $controls;
    public readonly DeliveryService $delivery;
    public readonly EventRouter $router;
    public readonly NotificationService $service;
    public readonly \Closure $clock;

    public function __construct(public readonly PDO $db, ?\Closure $clock = null, ?\Closure $permissions = null)
    {
        if (!Schema::installed($db)) {
            throw new NotificationException('notification_migration_required', 503);
        }
        $this->clock = $clock ?? static fn(): int => time();
        $secret = Support::one($db, "SELECT value FROM notification_meta WHERE key='cursor_secret'")['value'];
        $this->events = new EventRegistry();
        $this->channels = new ChannelRegistry();
        $this->targets = new TargetRegistry();
        $this->audiences = new AudienceResolver($db);
        $this->access = new Access($db, $permissions);
        $this->channels->register('email', new MailAdapter());
        $this->channels->register('webhook', new WebhookAdapter());
        $this->channels->register('audit', new AuditAdapter($db, $this->clock));
        foreach (['notification.admin.announcement', 'notification.admin.urgent_announcement'] as $type) {
            $this->events->register(new EventDefinition($type, 'notifications', function (array $event): array {
                $row = Support::one($this->db, 'SELECT payload FROM notification_announcements WHERE id=?', [$event['data']['announcement_id'] ?? '']);
                if (!$row) {
                    throw new NotificationException('announcement_unavailable', 404);
                }
                $payload = json_decode($row['payload'], true);
                return array_intersect_key($payload, array_flip(['title', 'message', 'target', 'language']));
            }, fn(array $event, string $user): bool => $this->access->user($user) !== null
                && Support::one($this->db, 'SELECT id FROM notification_announcements WHERE id=?', [$event['data']['announcement_id'] ?? '']) !== null,
                $type === 'notification.admin.urgent_announcement', 0, true));
        }
        $this->publisher = new EventPublisher($db, $this->events, $this->clock);
        $this->preferences = new PreferenceService($db, $this->events, $this->channels);
        $this->inbox = new InboxService($db, $this->events, $this->targets, $secret, $this->clock);
        $this->controls = new ControlService($db, $this->events, $this->audiences, $this->channels, $this->clock);
        $this->delivery = new DeliveryService($db, $this->events, $this->channels, $this->targets, $this->access, $this->preferences, $this->clock);
        $this->router = new EventRouter(
            $db,
            $this->events,
            $this->audiences,
            $this->controls,
            $this->channels,
            $this->access,
            $this->preferences,
            $this->inbox,
            $this->delivery,
            $this->targets,
            $this->clock
        );
        $this->service = new NotificationService(
            $db,
            $this->publisher,
            $this->access,
            $this->audiences,
            $this->channels,
            $this->targets,
            $secret,
            $this->clock
        );
        if (self::$configurator !== null) {
            (self::$configurator)($this);
        }
    }

    /** Register trusted module definitions in application bootstrap, including worker processes. */
    public static function configure(?\Closure $configurator): void
    {
        self::$configurator = $configurator;
    }

    public static function create(): self
    {
        $integrationFile = dirname(__DIR__, 3) . '/notification-integrations.php';
        if (self::$configurator === null && is_file($integrationFile)) {
            $configurator = require $integrationFile;
            if (!$configurator instanceof \Closure) {
                throw new \LogicException('notification-integrations.php must return a Closure');
            }
            self::$configurator = $configurator;
        }
        return new self(AuthDatabase::getInstance(false));
    }

    /** Fresh system storage is provisioned directly at the current version. */
    public static function install(?PDO $db = null): void
    {
        Schema::install($db ?? AuthDatabase::getInstance());
        \NomadCMS\Services\RBACService::resetCache();
    }

    public static function migrate(?PDO $db = null): void
    {
        // Installed instances already have auth tables. Avoid unrelated auth DDL
        // and journal-mode changes while explicitly migrating notification storage.
        Schema::migrate($db ?? AuthDatabase::getInstance(false));
        \NomadCMS\Services\RBACService::resetCache();
    }
}
