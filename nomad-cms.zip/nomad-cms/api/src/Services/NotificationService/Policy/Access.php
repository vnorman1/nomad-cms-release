<?php

/**
 * NOMAD CMS - Notification authorization.
 * Reuses granted-scope RBAC while enforcing notification ownership locally.
 * Worker decisions reload the actor; a system worker never lends its permissions.
 */

declare(strict_types=1);

namespace NomadCMS\Services\NotificationService\Policy;

use NomadCMS\Services\NotificationService\NotificationException;
use NomadCMS\Services\NotificationService\Support;
use NomadCMS\Services\RBACService;
use PDO;

/** Fresh principal lookups and domain-owned scope checks. */
final class Access
{
    public function __construct(private PDO $db, private ?\Closure $permissions = null)
    {
    }

    public function user(string $uuid): ?array
    {
        return Support::one($this->db, 'SELECT * FROM users WHERE uuid=?', [$uuid]);
    }

    public function has(string $uuid, string $permission): bool
    {
        $user = $this->user($uuid);
        if (
            !$user || !empty($user['is_new_user'])
            || (!empty($user['locked_until']) && strtotime($user['locked_until']) > time())
        ) {
            return false;
        }
        if ($this->permissions !== null) {
            return (bool) ($this->permissions)($user, $permission);
        }
        RBACService::resetCache();
        return RBACService::hasGrantedScope($user, $permission);
    }

    public function require(string $uuid, string $permission): void
    {
        if (!$this->has($uuid, $permission)) {
            throw new NotificationException('forbidden', 403);
        }
    }

    public function canSend(string $uuid, array $request): bool
    {
        return $this->has($uuid, 'notifications:send:*')
            && (($request['audience']['kind'] ?? '') === 'users' || $this->has($uuid, 'notifications:broadcast:*'))
            && (($request['priority'] ?? 'normal') !== 'urgent' || $this->has($uuid, 'notifications:send_urgent:*'));
    }
}
