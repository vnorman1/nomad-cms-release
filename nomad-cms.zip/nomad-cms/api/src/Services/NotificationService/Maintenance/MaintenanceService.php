<?php

/**
 * NOMAD CMS - Notification retention and operational controls.
 * Deletes bounded terminal data while retaining live references and deduplication receipts.
 * Backup restoration pauses external delivery until an explicit operator reconciliation.
 */

declare(strict_types=1);

namespace NomadCMS\Services\NotificationService\Maintenance;

use NomadCMS\Services\NotificationService\Support;
use PDO;

/** Bounded housekeeping with a conservative receipt retention policy. */
final class MaintenanceService
{
    public function __construct(private PDO $db, private \Closure $clock)
    {
    }

    public function run(): int
    {
        return Support::transaction($this->db, function (): int {
            $now = ($this->clock)();
            $deleted = 0;
            // Read-all watermarks participate in retention; newer grouped activity remains unread.
            $deleted += Support::run($this->db, 'DELETE FROM notification_inbox WHERE id IN (SELECT i.id FROM notification_inbox i LEFT JOIN notification_user_state s ON s.user_uuid=i.user_uuid WHERE (i.updated_at<? AND (i.archived_at IS NOT NULL OR i.activity_seq<=MAX(i.read_seq,COALESCE(s.read_through_seq,0)))) OR i.updated_at<? OR NOT EXISTS(SELECT 1 FROM users u WHERE u.uuid=i.user_uuid) LIMIT 500)', [$now - 5184000, $now - 15552000]);
            $deleted += Support::run($this->db, "DELETE FROM event_delivery_attempts WHERE id IN(SELECT id FROM event_delivery_attempts WHERE created_at<? LIMIT 500)", [$now - 7776000]);
            $deleted += Support::run($this->db, "DELETE FROM event_deliveries WHERE id IN(SELECT id FROM event_deliveries WHERE (state='sent' AND completed_at<?) OR (state IN ('dead','cancelled') AND completed_at<?) LIMIT 500)", [$now - 2592000, $now - 7776000]);
            $deleted += Support::run($this->db, "DELETE FROM notification_batches WHERE id IN(SELECT b.id FROM notification_batches b WHERE b.state='closed' AND b.created_at<? AND NOT EXISTS(SELECT 1 FROM event_deliveries d WHERE d.batch_id=b.id) LIMIT 500)", [$now - 7776000]);
            $deleted += Support::run($this->db, 'DELETE FROM notification_preferences WHERE rowid IN(SELECT rowid FROM notification_preferences p WHERE NOT EXISTS(SELECT 1 FROM users u WHERE u.uuid=p.user_uuid) LIMIT 500)');
            $deleted += Support::run($this->db, 'DELETE FROM notification_user_state WHERE user_uuid IN(SELECT s.user_uuid FROM notification_user_state s WHERE NOT EXISTS(SELECT 1 FROM users u WHERE u.uuid=s.user_uuid) LIMIT 500)');
            $deleted += Support::run($this->db, 'DELETE FROM notification_rate_limits WHERE rowid IN(SELECT rowid FROM notification_rate_limits WHERE bucket<? LIMIT 500)', [intdiv($now, 60) - 60]);
            $deleted += Support::run($this->db, "DELETE FROM event_outbox WHERE id IN(SELECT id FROM event_outbox WHERE state='accepted' AND accepted_at<? LIMIT 500)", [$now - 604800]);
            Support::run($this->db, "UPDATE event_deliveries SET state='cancelled',last_error='recipient_deleted',completed_at=? WHERE id IN(SELECT id FROM event_deliveries d WHERE user_uuid IS NOT NULL AND state IN ('pending','retry_wait','blocked') AND NOT EXISTS(SELECT 1 FROM users u WHERE u.uuid=d.user_uuid) LIMIT 500)", [$now]);
            $deleted += Support::run($this->db, 'DELETE FROM notification_audit WHERE id IN(SELECT id FROM notification_audit WHERE created_at<? LIMIT 500)', [$now - 15552000]);
            $deleted += Support::run($this->db, 'DELETE FROM event_rule_sets WHERE id IN(SELECT id FROM event_rule_sets s WHERE created_at<? AND NOT EXISTS(SELECT 1 FROM event_events e WHERE e.rules_version=s.id) LIMIT 500)', [$now - 15552000]);
            $deleted += Support::run($this->db, 'DELETE FROM event_rules WHERE rowid IN(SELECT rowid FROM event_rules r WHERE created_at<? AND version<(SELECT MAX(version) FROM event_rules WHERE id=r.id) LIMIT 500)', [$now - 15552000]);
            // Compact completed events only after every dependent projection and delivery is gone.
            $statement = $this->db->prepare("SELECT e.id FROM event_events e WHERE e.state='completed' AND e.received_at<? AND NOT EXISTS(SELECT 1 FROM notification_inbox_events i WHERE i.event_id=e.id) AND NOT EXISTS(SELECT 1 FROM notification_batch_events b WHERE b.event_id=e.id) AND NOT EXISTS(SELECT 1 FROM event_deliveries d WHERE d.event_id=e.id) AND NOT EXISTS(SELECT 1 FROM event_recipients p JOIN event_routes r ON r.id=p.route_id WHERE r.event_id=e.id AND p.state='pending') LIMIT 500");
            $statement->execute([$now - 15552000]);
            $ids = $statement->fetchAll(PDO::FETCH_COLUMN);
            foreach ($ids as $id) {
                Support::run($this->db, 'DELETE FROM event_recipients WHERE route_id IN(SELECT id FROM event_routes WHERE event_id=?)', [$id]);
                Support::run($this->db, 'DELETE FROM event_routes WHERE event_id=?', [$id]);
                Support::run($this->db, 'DELETE FROM notification_announcements WHERE event_id=?', [$id]);
                $deleted += Support::run($this->db, 'DELETE FROM event_events WHERE id=?', [$id]);
            }
            // Payload-free receipts intentionally outlive event payloads; source outages cannot resurrect sends.
            return $deleted;
        }, true);
    }

    public function pause(bool $paused, string $actor = 'operator'): void
    {
        Support::transaction($this->db, function () use ($paused, $actor): void {
            Support::run($this->db, "UPDATE notification_meta SET value=? WHERE key='external_paused'", [$paused ? '1' : '0']);
            if ($paused && $actor === 'backup-restore') {
                Support::run($this->db, "INSERT INTO notification_meta VALUES('restore_cutoff',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value", [(string) ($this->clock)()]);
            }
            Support::run(
                $this->db,
                'INSERT INTO notification_audit VALUES(?,?,?,?,?)',
                [Support::id(), $actor, null, $paused ? 'delivery.paused' : 'delivery.resumed', ($this->clock)()]
            );
        }, true);
    }

    public function status(): array
    {
        $result = ['external_paused' => Support::one($this->db, "SELECT value FROM notification_meta WHERE key='external_paused'")['value'] !== '0'];
        foreach (['event_outbox', 'event_events', 'event_deliveries'] as $table) {
            $result[$table] = $this->db->query("SELECT state,COUNT(*) AS count FROM $table GROUP BY state")->fetchAll(PDO::FETCH_ASSOC);
        }
        $result['oldest_pending_at'] = Support::one($this->db, "SELECT MIN(received_at) AS oldest FROM event_events WHERE state IN ('pending','routing')")['oldest'];
        $result['oldest_delivery_at'] = Support::one($this->db, "SELECT MIN(created_at) AS oldest FROM event_deliveries WHERE state IN ('pending','retry_wait','processing')")['oldest'];
        $result['last_runs'] = $this->db->query("SELECT key,value FROM notification_meta WHERE key LIKE 'last_run:%' ORDER BY key")->fetchAll(PDO::FETCH_KEY_PAIR);
        return $result;
    }
}
