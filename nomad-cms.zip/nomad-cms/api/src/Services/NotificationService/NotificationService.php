<?php

/**
 * NOMAD CMS - Central NotificationService facade.
 * Offers durable module publication, standalone administrator announcements and history.
 * SMTP is optional; urgent delivery overrides preferences only with a separate permission.
 */

declare(strict_types=1);

namespace NomadCMS\Services\NotificationService;

use NomadCMS\Services\NotificationService\Channels\ChannelRegistry;
use NomadCMS\Services\NotificationService\Contracts\AuthenticatedActor;
use NomadCMS\Services\NotificationService\Contracts\DomainEvent;
use NomadCMS\Services\NotificationService\Events\EventPublisher;
use NomadCMS\Services\NotificationService\Policy\Access;
use NomadCMS\Services\NotificationService\Routing\AudienceResolver;
use NomadCMS\Services\NotificationService\Targets\TargetRegistry;
use PDO;

/** Public backend notification boundary independent of existing business modules. */
final class NotificationService implements NotificationServiceInterface
{
    public function __construct(
        private PDO $db,
        private EventPublisher $publisher,
        private Access $access,
        private AudienceResolver $audiences,
        private ChannelRegistry $channels,
        private TargetRegistry $targets,
        private string $secret,
        private \Closure $clock
    ) {
    }

    public function publish(PDO $sourceDb, DomainEvent $event): array
    {
        if (str_starts_with($event->payload['type'], 'notification.admin.')) {
            throw new NotificationException('reserved_event_type', 403);
        }
        return $this->publisher->record($sourceDb, $event);
    }

    private function normalize(array $request, string $actor): array
    {
        Support::keys($request, ['title', 'message', 'audience', 'priority', 'delivery_policy', 'target', 'language']);
        $request['title'] = Support::text($request['title'] ?? null, 200);
        if (str_contains($request['title'], "\n") || str_contains($request['title'], "\r")) {
            throw new NotificationException('invalid_title');
        }
        $request['message'] = Support::text($request['message'] ?? null, 2000);
        $request += ['priority' => 'normal', 'delivery_policy' => 'in_app', 'target' => null, 'language' => 'hu'];
        if (
            !in_array($request['priority'], ['normal', 'urgent'], true)
            || !in_array($request['delivery_policy'], ['in_app', 'in_app_email'], true)
            || !in_array($request['language'], ['hu', 'en'], true) || !is_array($request['audience'] ?? null)
            || ($request['target'] !== null && !is_array($request['target']))
        ) {
            throw new NotificationException('invalid_announcement');
        }
        if ($request['priority'] === 'urgent') {
            $request['delivery_policy'] = 'in_app_email';
        }
        if (!$this->access->canSend($actor, $request)) {
            throw new NotificationException('forbidden', 403);
        }
        $request['audience'] = $this->audiences->validate($request['audience'], true);
        $this->targets->resolve($request['target'], $actor);
        if (strlen(Support::json($request)) > 16384) {
            throw new NotificationException('payload_too_large', 413);
        }
        return $request;
    }

    public function capabilities(AuthenticatedActor $actor): array
    {
        $this->access->require($actor->uuid, 'notifications:send:*');
        $email = $this->channels->capability('email');
        return ['can_send' => true, 'target_kinds' => $this->targets->names(), 'can_broadcast' => $this->access->has($actor->uuid, 'notifications:broadcast:*'),
            'can_send_urgent' => $this->access->has($actor->uuid, 'notifications:send_urgent:*'),
            'audience_modes' => $this->access->has($actor->uuid, 'notifications:broadcast:*') ? ['users', 'roles', 'all_users'] : ['users'],
            'channels' => ['in_app' => ['available' => true], 'email' => array_intersect_key($email, ['available' => true, 'reason' => true])]];
    }

    public function preview(array $request, AuthenticatedActor $actor): array
    {
        $normalized = $this->normalize($request, $actor->uuid);
        return ['valid' => true, 'request' => $normalized, 'capabilities' => $this->capabilities($actor),
            'estimated_recipients' => $this->audiences->estimate($normalized['audience']), 'audience_is_snapshot' => false];
    }

    public function sendByAdmin(array $request, AuthenticatedActor $actor, string $idempotencyKey): array
    {
        $request = $this->normalize($request, $actor->uuid);
        if (!preg_match('/^[A-Za-z0-9_.:-]{8,128}$/D', $idempotencyKey)) {
            throw new NotificationException('invalid_idempotency_key');
        }
        $hash = hash('sha256', Support::canonical($request));
        return Support::transaction($this->db, function () use ($request, $actor, $idempotencyKey, $hash): array {
            $existing = Support::one($this->db, 'SELECT * FROM notification_announcements WHERE actor_uuid=? AND idempotency_key=?', [$actor->uuid, $idempotencyKey]);
            if ($existing) {
                if (!hash_equals($existing['payload_hash'], $hash)) {
                    throw new NotificationException('idempotency_conflict', 409);
                }
                $receipt = json_decode($existing['receipt'], true);
                unset($receipt['_email_capability']);
                return $receipt;
            }
            $now = ($this->clock)();
            $bucket = intdiv($now, 60);
            Support::run($this->db, 'INSERT INTO notification_rate_limits VALUES(?,?,1) ON CONFLICT(user_uuid,bucket) DO UPDATE SET count=count+1', [$actor->uuid, $bucket]);
            if ((int) Support::one($this->db, 'SELECT count FROM notification_rate_limits WHERE user_uuid=? AND bucket=?', [$actor->uuid, $bucket])['count'] > 20) {
                throw new NotificationException('rate_limited', 429);
            }
            $id = Support::id();
            $eventId = Support::id();
            $email = $this->channels->capability('email');
            $wanted = $request['delivery_policy'] === 'in_app_email';
            $receipt = ['success' => true, 'announcement_id' => $id, 'status' => 'accepted', 'priority' => $request['priority'],
                'channels' => ['in_app' => ['status' => 'queued'], 'email' => ['status' => !$wanted ? 'not_requested' : ($email['available'] ? 'queued' : 'skipped_unavailable'), 'reason' => $wanted ? ($email['reason'] ?? null) : null]],
                'warnings' => $wanted && !$email['available'] ? ['email_channel_unavailable'] : [], '_email_capability' => $email];
            Support::run(
                $this->db,
                'INSERT INTO notification_announcements VALUES(?,?,?,?,?,?,?,?)',
                [$id, $actor->uuid, $idempotencyKey, Support::json($request), $hash, $eventId, Support::json($receipt), $now]
            );
            $event = new DomainEvent(['id' => $eventId, 'source' => 'notifications',
                'type' => $request['priority'] === 'urgent' ? 'notification.admin.urgent_announcement' : 'notification.admin.announcement',
                'occurrence_key' => 'announcement:' . $id, 'actor' => ['kind' => 'user', 'id' => $actor->uuid],
                'subject' => ['kind' => 'notification.announcement', 'id' => $id], 'audience' => $request['audience'],
                'priority' => $request['priority'], 'data' => ['announcement_id' => $id]]);
            $this->publisher->record($this->db, $event);
            Support::run($this->db, 'INSERT INTO notification_audit VALUES(?,?,?,?,?)', [Support::id(), $actor->uuid, $eventId, 'announcement.submitted', $now]);
            unset($receipt['_email_capability']);
            return $receipt;
        }, true);
    }

    public function announcement(string $id, AuthenticatedActor $actor): array
    {
        $row = Support::one($this->db, 'SELECT * FROM notification_announcements WHERE id=?', [$id]);
        if (
            !$row || (!$this->access->has($actor->uuid, 'notifications:read_sent:*')
            && ($row['actor_uuid'] !== $actor->uuid || !$this->access->has($actor->uuid, 'notifications:read_sent:own')))
        ) {
            throw new NotificationException('not_found', 404);
        }
        $event = Support::one($this->db, 'SELECT state,last_error FROM event_events WHERE id=?', [$row['event_id']]);
        $statement = $this->db->prepare('SELECT channel,state,COUNT(*) AS count FROM event_deliveries WHERE event_id=? GROUP BY channel,state');
        $statement->execute([$row['event_id']]);
        $deliveries = $statement->fetchAll(PDO::FETCH_ASSOC);
        $outcomes = [];
        $statement = $this->db->prepare('SELECT p.outcomes FROM event_recipients p JOIN event_routes r ON r.id=p.route_id WHERE r.event_id=? AND p.outcomes IS NOT NULL');
        $statement->execute([$row['event_id']]);
        while ($recipient = $statement->fetch(PDO::FETCH_ASSOC)) {
            foreach (json_decode($recipient['outcomes'], true) as $channel => $outcome) {
                $outcomes[$channel][$outcome] = ($outcomes[$channel][$outcome] ?? 0) + 1;
            }
        }
        $status = match ($event['state'] ?? 'pending') {
            'pending' => 'accepted', 'routing' => 'resolving', 'dead' => 'failed', default => 'completed',
        };
        if (($event['last_error'] ?? null) === 'actor_permission_revoked') {
            $status = 'cancelled';
        }
        foreach ($deliveries as $delivery) {
            if (in_array($delivery['state'], ['pending', 'processing', 'retry_wait', 'blocked'], true)) {
                $status = 'dispatching';
            } elseif ($delivery['state'] === 'dead' && $status === 'completed') {
                $status = 'partial_failure';
            }
        }
        return ['id' => $id, 'actor_uuid' => $row['actor_uuid'], 'request' => json_decode($row['payload'], true),
            'created_at' => (int) $row['created_at'], 'status' => $status, 'outcomes' => $outcomes,
            'deliveries' => $deliveries, 'last_error' => $event['last_error'] ?? null];
    }

    public function history(AuthenticatedActor $actor, array $query = []): array
    {
        $all = $this->access->has($actor->uuid, 'notifications:read_sent:*');
        if (!$all) {
            $this->access->require($actor->uuid, 'notifications:read_sent:own');
        }
        $where = $all ? '1=1' : 'actor_uuid=?';
        $parameters = $all ? [] : [$actor->uuid];
        if (!empty($query['cursor'])) {
            $cursor = Support::decode((string) $query['cursor'], $this->secret, 'history', $actor->uuid);
            $where .= ' AND (created_at<? OR (created_at=? AND id<?))';
            array_push($parameters, $cursor['created_at'], $cursor['created_at'], $cursor['id']);
        }
        $limit = max(1, min(100, (int) ($query['limit'] ?? 25)));
        $statement = $this->db->prepare('SELECT id,created_at FROM notification_announcements WHERE ' . $where . ' ORDER BY created_at DESC,id DESC LIMIT ' . ($limit + 1));
        $statement->execute($parameters);
        $rows = $statement->fetchAll(PDO::FETCH_ASSOC);
        $more = count($rows) > $limit;
        $rows = array_slice($rows, 0, $limit);
        $last = $rows ? $rows[array_key_last($rows)] : null;
        return ['items' => array_map(fn(array $row): array => $this->announcement($row['id'], $actor), $rows),
            'next_cursor' => $more && $last ? Support::token(['purpose' => 'history', 'user' => $actor->uuid] + $last, $this->secret) : null];
    }
}
