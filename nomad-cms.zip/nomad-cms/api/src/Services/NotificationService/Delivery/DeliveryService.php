<?php

/**
 * NOMAD CMS - Notification delivery queue and aggregation.
 * Owns leased single-attempt work, finite retries, digest batches and safe diagnostics.
 * Network adapters run after the claim transaction commits, never under a database lock.
 */

declare(strict_types=1);

namespace NomadCMS\Services\NotificationService\Delivery;

use NomadCMS\Services\NotificationService\Channels\ChannelRegistry;
use NomadCMS\Services\NotificationService\Events\EventRegistry;
use NomadCMS\Services\NotificationService\NotificationException;
use NomadCMS\Services\NotificationService\Policy\Access;
use NomadCMS\Services\NotificationService\Preferences\PreferenceService;
use NomadCMS\Services\NotificationService\Support;
use NomadCMS\Services\NotificationService\Targets\TargetRegistry;
use PDO;

/** Shared queue used by automatic events and manual administrator announcements. */
final class DeliveryService
{
    private const RETRY_DELAYS = [60, 300, 900, 3600, 10800];

    public function __construct(
        private PDO $db,
        private EventRegistry $events,
        private ChannelRegistry $channels,
        private TargetRegistry $targets,
        private Access $access,
        private PreferenceService $preferences,
        private \Closure $clock
    ) {
    }

    public function enqueue(
        array $event,
        string $route,
        ?string $user,
        string $channel,
        array $configuration,
        ?string $batch = null
    ): string {
        if (!$this->events->get($event['type'])->allowsChannel($channel)) {
            throw new NotificationException('event_channel_forbidden', 409);
        }
        $id = Support::id();
        $key = hash('sha256', Support::canonical([$batch ?? $event['id'], $user, $channel, $configuration]));
        $now = ($this->clock)();
        $cutoff = (int) (Support::one($this->db, "SELECT value FROM notification_meta WHERE key='restore_cutoff'")['value'] ?? 0);
        $uncertain = $cutoff > 0 && (strtotime($event['occurred_at']) ?: 0) <= $cutoff;
        Support::run(
            $this->db,
            'INSERT OR IGNORE INTO event_deliveries(id,event_id,route_id,batch_id,user_uuid,channel,payload,dedupe_key,priority,available_at,expires_at,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)',
            [$id, $event['id'], $route, $batch, $user, $channel, Support::json($configuration), $key,
                match ($event['priority']) {
            'urgent' => 0, 'normal' => 1, default => 2
                }, $now,
            $now + ($event['priority'] === 'urgent' ? 86400 : 604800),
            $now]
        );
        $id = Support::one($this->db, 'SELECT id FROM event_deliveries WHERE dedupe_key=?', [$key])['id'];
        if ($uncertain) {
            Support::run($this->db, "UPDATE event_deliveries SET state='blocked',last_error='restore_uncertain' WHERE id=? AND state='pending' AND attempts=0", [$id]);
        }
        return $id;
    }

    public function batch(array $event, string $route, string $user, array $configuration): void
    {
        if (!$this->events->get($event['type'])->allowsChannel('email')) {
            throw new NotificationException('event_channel_forbidden', 409);
        }
        $now = ($this->clock)();
        $definition = $this->events->get($event['type']);
        $window = max(120, $definition->windowSeconds);
        $group = hash('sha256', Support::canonical([$event['type'], $event['subject'], $configuration]));
        $row = Support::one($this->db, "SELECT * FROM notification_batches WHERE user_uuid=? AND group_key=? AND state='open'", [$user, $group]);
        if ($row && (int) $row['closes_at'] <= $now) {
            $this->close($row);
            $row = null;
        }
        if (!$row) {
            $id = Support::id();
            $payload = ['configuration' => $configuration, 'route_id' => $route, 'event_id' => $event['id']];
            Support::run(
                $this->db,
                'INSERT INTO notification_batches VALUES(?,?,?,?,?,?,?,?)',
                [$id, $user, $group, Support::json($payload), 'open', $now, $now + $window, $now + max(300, $window * 6)]
            );
        } else {
            $id = $row['id'];
        }
        $added = Support::run($this->db, 'INSERT OR IGNORE INTO notification_batch_events VALUES(?,?)', [$id, $event['id']]);
        if ($row && $added) {
            Support::run($this->db, 'UPDATE notification_batches SET closes_at=MIN(max_closes_at,?) WHERE id=?', [$now + $window, $id]);
        }
        $count = (int) Support::one($this->db, 'SELECT COUNT(*) AS n FROM notification_batch_events WHERE batch_id=?', [$id])['n'];
        if ($count >= 50) {
            $this->close(Support::one($this->db, 'SELECT * FROM notification_batches WHERE id=?', [$id]));
        }
    }

    private function close(array $batch): void
    {
        $payload = json_decode($batch['payload'], true);
        $event = json_decode(Support::one($this->db, 'SELECT payload FROM event_events WHERE id=?', [$payload['event_id']])['payload'], true);
        $this->enqueue($event, $payload['route_id'], $batch['user_uuid'], 'email', $payload['configuration'], $batch['id']);
        Support::run($this->db, "UPDATE notification_batches SET state='closed' WHERE id=?", [$batch['id']]);
    }

    public function flush(int $limit = 50, ?float $deadline = null): int
    {
        $count = 0;
        while ($count < min(50, $limit) && ($deadline === null || microtime(true) < $deadline)) {
            $closed = Support::transaction($this->db, function (): bool {
                $row = Support::one($this->db, "SELECT * FROM notification_batches WHERE state='open' AND closes_at<=? ORDER BY closes_at,id LIMIT 1", [($this->clock)()]);
                if (!$row) {
                    return false;
                }
                $this->close($row);
                return true;
            }, true);
            if (!$closed) {
                break;
            }
            $count++;
        }
        return $count;
    }

    public function claim(bool $serveNormal = false): ?array
    {
        return Support::transaction($this->db, function () use ($serveNormal): ?array {
            if (Support::one($this->db, "SELECT value FROM notification_meta WHERE key='external_paused'")['value'] !== '0') {
                return null;
            }
            $now = ($this->clock)();
            Support::run($this->db, "UPDATE event_deliveries SET state=CASE WHEN attempts>=6 THEN 'dead' ELSE 'retry_wait' END,completed_at=CASE WHEN attempts>=6 THEN ? ELSE NULL END,available_at=?,lease_token=NULL,lease_until=NULL,last_error='lease_expired' WHERE id IN(SELECT id FROM event_deliveries WHERE state='processing' AND lease_until<=? LIMIT 100)", [$now, $now, $now]);
            Support::run($this->db, "UPDATE event_deliveries SET state='dead',last_error='expired',completed_at=? WHERE id IN(SELECT id FROM event_deliveries WHERE state IN ('pending','retry_wait','blocked') AND expires_at<=? LIMIT 100)", [$now, $now]);
            $sql = "SELECT * FROM event_deliveries WHERE state IN ('pending','retry_wait') AND available_at<=? AND attempts<6";
            $row = $serveNormal ? Support::one($this->db, $sql . ' AND priority>0 ORDER BY available_at,id LIMIT 1', [$now]) : null;
            $row ??= Support::one($this->db, $sql . ' ORDER BY priority,available_at,id LIMIT 1', [$now]);
            if (!$row) {
                return null;
            }
            $row['lease_token'] = bin2hex(random_bytes(24));
            $row['attempts'] = (int) $row['attempts'] + 1;
            Support::run($this->db, "UPDATE event_deliveries SET state='processing',attempts=?,lease_token=?,lease_until=? WHERE id=?", [$row['attempts'], $row['lease_token'], $now + 120, $row['id']]);
            return $row;
        }, true);
    }

    public function finish(array $claim, array $result, int $durationMs = 0): bool
    {
        return Support::transaction($this->db, function () use ($claim, $result, $durationMs): bool {
            $state = $result['status'] ?? 'dead';
            $code = $result['code'] ?? 'invalid_adapter_result';
            if (!is_string($code) || !preg_match('/^[a-zA-Z0-9_.:-]{1,100}$/D', $code)) {
                $code = 'invalid_adapter_result';
            }
            if (!in_array($state, ['sent', 'retry_wait', 'blocked', 'dead', 'cancelled'], true)) {
                $state = 'dead';
            }
            if ($state === 'retry_wait' && $claim['attempts'] >= 6) {
                $state = 'dead';
            }
            $now = ($this->clock)();
            $delay = self::RETRY_DELAYS[min(4, max(0, $claim['attempts'] - 1))];
            $changed = Support::run(
                $this->db,
                "UPDATE event_deliveries SET state=?,available_at=?,last_error=?,completed_at=?,lease_token=NULL,lease_until=NULL WHERE id=? AND state='processing' AND lease_token=? AND lease_until>?",
                [$state, $now + $delay + random_int(0, max(1, (int) ($delay / 10))), $code,
                in_array($state, ['sent', 'dead', 'cancelled'], true) ? $now : null,
                $claim['id'],
                $claim['lease_token'],
                $now]
            );
            if ($changed) {
                Support::run(
                    $this->db,
                    'INSERT INTO event_delivery_attempts(delivery_id,attempt,result,duration_ms,created_at) VALUES(?,?,?,?,?)',
                    [$claim['id'], $claim['attempts'], $state . ':' . $code, max(0, $durationMs), $now]
                );
            }
            return $changed > 0;
        }, true);
    }

    public function actorAllowed(array $event): bool
    {
        if (!str_starts_with($event['type'], 'notification.admin.')) {
            return true;
        }
        $announcement = Support::one($this->db, 'SELECT payload,actor_uuid FROM notification_announcements WHERE id=?', [$event['data']['announcement_id'] ?? '']);
        return $announcement !== null && $this->access->canSend($announcement['actor_uuid'], json_decode($announcement['payload'], true));
    }

    public function message(array $row): ?array
    {
        $statement = $this->db->prepare($row['batch_id'] === null
            ? 'SELECT payload FROM event_events WHERE id=?'
            : 'SELECT e.payload FROM notification_batch_events b JOIN event_events e ON e.id=b.event_id WHERE b.batch_id=? ORDER BY e.received_at,e.id LIMIT 50');
        $statement->execute([$row['batch_id'] ?? $row['event_id']]);
        $content = null;
        $count = 0;
        while ($record = $statement->fetch(PDO::FETCH_ASSOC)) {
            $event = json_decode($record['payload'], true);
            if (!$this->events->get($event['type'])->allowsChannel($row['channel'] ?? 'email')) {
                continue;
            }
            if (!$this->actorAllowed($event)) {
                continue;
            }
            if ($row['user_uuid'] !== null) {
                if (!$this->access->user($row['user_uuid']) || !$this->events->canRead($event, $row['user_uuid'])) {
                    continue;
                }
                $preferences = $this->preferences->effective($row['user_uuid'], $event);
                if ($preferences['email'] === 'off') {
                    continue;
                }
            }
            $rendered = $this->events->render($event);
            if ($row['user_uuid'] !== null && !$this->targets->accessible($rendered['target'], $row['user_uuid'])) {
                continue;
            }
            $content ??= $rendered + ['type' => $event['type'], 'event_id' => $event['id']];
            $count++;
        }
        if (!$content) {
            return null;
        }
        unset($content['target']);
        if ($count > 1) {
            $content['title'] = $content['language'] === 'en' ? "$count new notifications" : "$count új értesítés";
            $content['message'] = $content['language'] === 'en' ? 'Open the CMS inbox to view the updates.' : 'Az új eseményeket a CMS értesítési postaládájában találod.';
        }
        return $content + ['count' => $count];
    }

    public function process(int $limit, float $deadline): int
    {
        $processed = 0;
        while ($processed < min(5, $limit) && $deadline - microtime(true) >= 3) {
            $claim = $this->claim($processed % 5 === 4);
            if (!$claim) {
                break;
            }
            $started = microtime(true);
            try {
                $configuration = json_decode($claim['payload'], true);
                $message = $this->message($claim);
                $result = ['status' => 'cancelled', 'code' => 'access_or_preference_revoked'];
                if ($message !== null) {
                    if ($claim['user_uuid'] !== null && ($this->access->user($claim['user_uuid'])['email'] ?? '') !== ($configuration['email'] ?? '')) {
                        $result = ['status' => 'blocked', 'code' => 'recipient_address_changed'];
                    } elseif (isset($configuration['destination_id'])) {
                        $destination = Support::one($this->db, 'SELECT version,active FROM event_destinations WHERE id=?', [$configuration['destination_id']]);
                        if (!$destination || !$destination['active'] || (int) $destination['version'] !== $configuration['destination_version']) {
                            $result = ['status' => 'cancelled', 'code' => 'destination_changed'];
                        } else {
                            $fields = array_fill_keys($configuration['fields'], true);
                            $message = array_intersect_key($message, $fields + ['type' => true, 'event_id' => true]);
                            $result = $this->channels->get($claim['channel'])->deliver($message, $configuration, max(1, min(15, (int) ($deadline - microtime(true) - 1))), $claim['id']);
                        }
                    } else {
                        $result = $this->channels->get($claim['channel'])->deliver($message, $configuration, max(1, min(15, (int) ($deadline - microtime(true) - 1))), $claim['id']);
                    }
                }
            } catch (\Throwable) {
                $result = ['status' => 'retry_wait', 'code' => 'adapter_failure'];
            }
            $this->finish($claim, $result, (int) ((microtime(true) - $started) * 1000));
            $processed++;
        }
        return $processed;
    }

    public function retry(string $id): void
    {
        $now = ($this->clock)();
        $changed = Support::run($this->db, "UPDATE event_deliveries SET state='pending',attempts=0,available_at=?,completed_at=NULL,last_error=NULL WHERE id=? AND state IN ('blocked','dead') AND created_at>? AND expires_at>?", [$now, $id, $now - 7776000, $now]);
        if (!$changed) {
            throw new NotificationException('delivery_not_retryable', 409);
        }
    }

    public function listing(string $actor, array $query = []): array
    {
        $secret = Support::one($this->db, "SELECT value FROM notification_meta WHERE key='cursor_secret'")['value'];
        $where = '1=1';
        $parameters = [];
        if (isset($query['state'])) {
            if (!in_array($query['state'], ['pending', 'processing', 'retry_wait', 'blocked', 'sent', 'dead', 'cancelled'], true)) {
                throw new NotificationException('invalid_filter');
            }
            $where .= ' AND state=?';
            $parameters[] = $query['state'];
        }
        $purpose = 'deliveries:' . ($query['state'] ?? 'all');
        if (!empty($query['cursor'])) {
            $cursor = Support::decode((string) $query['cursor'], $secret, $purpose, $actor);
            $where .= ' AND (created_at<? OR (created_at=? AND id<?))';
            array_push($parameters, $cursor['created_at'], $cursor['created_at'], $cursor['id']);
        }
        $limit = max(1, min(100, (int) ($query['limit'] ?? 25)));
        $statement = $this->db->prepare('SELECT id,event_id,channel,state,attempts,last_error,available_at,created_at,completed_at FROM event_deliveries WHERE ' . $where . ' ORDER BY created_at DESC,id DESC LIMIT ' . ($limit + 1));
        $statement->execute($parameters);
        $rows = $statement->fetchAll(PDO::FETCH_ASSOC);
        $more = count($rows) > $limit;
        $rows = array_slice($rows, 0, $limit);
        $last = $rows ? $rows[array_key_last($rows)] : null;
        return ['items' => $rows, 'next_cursor' => $more && $last ? Support::token([
            'purpose' => $purpose, 'user' => $actor, 'created_at' => $last['created_at'], 'id' => $last['id'],
        ], $secret) : null];
    }
}
