<?php

/**
 * NOMAD CMS - Notification channel preferences.
 * Maintains per-user overrides with optimistic versions, independent of UI preferences.
 * Urgent obligations are applied by policy, never persisted as user overrides.
 */

declare(strict_types=1);

namespace NomadCMS\Services\NotificationService\Preferences;

use NomadCMS\Services\NotificationService\Events\EventRegistry;
use NomadCMS\Services\NotificationService\NotificationException;
use NomadCMS\Services\NotificationService\Support;
use PDO;
use NomadCMS\Services\NotificationService\Channels\ChannelRegistry;

/** Scoped, concurrency-safe channel settings. */
final class PreferenceService
{
    public function __construct(private PDO $db, private EventRegistry $registry, private ?ChannelRegistry $channels = null)
    {
    }

    public function effective(string $user, array $event): array
    {
        if ($event['priority'] === 'urgent') {
            return $this->constrain(['in_app' => true, 'email' => 'immediate', 'mandatory' => true], $event);
        }
        foreach (['event:' . $event['type'], 'module:' . $event['source'], '*'] as $scope) {
            $row = Support::one($this->db, 'SELECT in_app,email FROM notification_preferences WHERE user_uuid=? AND scope=? AND inherited=0', [$user, $scope]);
            if ($row) {
                return $this->constrain(['in_app' => (bool) $row['in_app'], 'email' => $row['email'], 'mandatory' => false], $event);
            }
        }
        return $this->constrain(['in_app' => true, 'email' => $this->registry->get($event['type'])->emailDefault ? 'immediate' : 'off', 'mandatory' => false], $event);
    }

    private function constrain(array $preferences, array $event): array
    {
        $definition = $this->registry->get($event['type']);
        if (!$definition->allowsChannel('in_app')) {
            $preferences['in_app'] = false;
        }
        if (!$definition->allowsChannel('email')) {
            $preferences['email'] = 'off';
        }
        return $preferences;
    }

    public function get(string $user): array
    {
        $statement = $this->db->prepare('SELECT scope,in_app,email,version,inherited FROM notification_preferences WHERE user_uuid=? ORDER BY scope LIMIT 200');
        $statement->execute([$user]);
        $rows = $statement->fetchAll(PDO::FETCH_ASSOC);
        $versions = [];
        $overrides = [];
        foreach ($rows as $row) {
            $versions[$row['scope']] = (int) $row['version'];
            if (!(bool) $row['inherited']) {
                unset($row['inherited']);
                $row['in_app'] = (bool) $row['in_app'];
                $row['version'] = (int) $row['version'];
                $overrides[] = $row;
            }
        }
        $email = $this->channels?->capability('email') ?? ['available' => false, 'reason' => 'smtp_not_configured'];
        return ['overrides' => $overrides, 'scope_versions' => (object) $versions,
            'channels' => ['email' => array_intersect_key($email, ['available' => true, 'reason' => true])], 'mandatory_urgent' => true,
            'defaults' => ['in_app' => true, 'email' => 'off'], 'events' => $this->registry->catalog()];
    }

    public function put(string $user, array $input): array
    {
        Support::keys($input, ['scope', 'in_app', 'email', 'version', 'inherit']);
        $inherit = ($input['inherit'] ?? false) === true;
        $scope = Support::text($input['scope'] ?? null, 220);
        if ($scope !== '*' && !preg_match('/^(?:event|module):[a-z][a-z0-9_.-]+$/D', $scope)) {
            throw new NotificationException('invalid_scope');
        }
        if (str_starts_with($scope, 'event:')) {
            $this->registry->get(substr($scope, 6));
        }
        if (
            (isset($input['inherit']) && !is_bool($input['inherit']))
            || ($inherit && (isset($input['in_app']) || isset($input['email'])))
            || (!$inherit && (!is_bool($input['in_app'] ?? null) || !in_array($input['email'] ?? null, ['off', 'immediate', 'digest'], true)))
            || !is_int($input['version'] ?? null) || $input['version'] < 0
        ) {
            throw new NotificationException('invalid_preference');
        }
        return Support::transaction($this->db, function () use ($user, $scope, $input, $inherit): array {
            $row = Support::one($this->db, 'SELECT version FROM notification_preferences WHERE user_uuid=? AND scope=?', [$user, $scope]);
            if ((int) ($row['version'] ?? 0) !== $input['version']) {
                throw new NotificationException('version_conflict', 409);
            }
            if (!$row && (int) Support::one($this->db, 'SELECT COUNT(*) AS n FROM notification_preferences WHERE user_uuid=?', [$user])['n'] >= 200) {
                throw new NotificationException('preference_limit');
            }
            Support::run(
                $this->db,
                'INSERT INTO notification_preferences(user_uuid,scope,in_app,email,version,inherited) VALUES(?,?,?,?,?,?) ON CONFLICT(user_uuid,scope) DO UPDATE SET in_app=excluded.in_app,email=excluded.email,version=excluded.version,inherited=excluded.inherited',
                [$user, $scope, (int) ($input['in_app'] ?? true), $input['email'] ?? 'off', $input['version'] + 1, (int) $inherit]
            );
            return $this->get($user);
        }, true);
    }
}
