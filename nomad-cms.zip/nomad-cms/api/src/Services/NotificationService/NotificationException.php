<?php

/**
 * NOMAD CMS - Notification failures.
 * Stable, non-sensitive error codes shared by the service and HTTP boundary.
 * Transport diagnostics must never be exposed through these messages.
 */

declare(strict_types=1);

namespace NomadCMS\Services\NotificationService;

/** A classified notification failure suitable for an API response. */
final class NotificationException extends \RuntimeException
{
    public function __construct(public readonly string $errorCode, public readonly int $status = 422)
    {
        parent::__construct($errorCode);
    }
}
