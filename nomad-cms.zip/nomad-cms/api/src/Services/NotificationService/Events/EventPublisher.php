<?php

/**
 * NOMAD CMS - Transactional notification publication and relay.
 * Couples the source event to its business transaction, then copies it idempotently.
 * Central commit always precedes source acknowledgement across SQLite files.
 */

declare(strict_types=1);

namespace NomadCMS\Services\NotificationService\Events;

use NomadCMS\Services\NotificationService\Contracts\DomainEvent;
use NomadCMS\Services\NotificationService\NotificationException;
use NomadCMS\Services\NotificationService\Support;
use PDO;

/** Durable at-least-once transfer without cross-database transactions. */
final class EventPublisher
{
    public function __construct(private PDO $central, private EventRegistry $registry, private \Closure $clock)
    {
    }

    public function record(PDO $source, DomainEvent $event): array
    {
        return (new SourcePublisher($this->registry, $this->clock))->record($source, $event);
    }

    public function accept(array $row): string
    {
        return Support::transaction($this->central, function () use ($row): string {
            $key = [$row['source'], $row['type'], $row['occurrence_key']];
            $receipt = Support::one($this->central, 'SELECT * FROM event_dedup_receipts WHERE source=? AND type=? AND occurrence_key=?', $key);
            if ($receipt) {
                if (!hash_equals($receipt['payload_hash'], $row['payload_hash'])) {
                    throw new NotificationException('occurrence_conflict', 409);
                }
                return $receipt['event_id'];
            }
            Support::run(
                $this->central,
                'INSERT INTO event_events(id,source,type,occurrence_key,payload,payload_hash,received_at) VALUES(?,?,?,?,?,?,?)',
                [$row['id'], ...$key, $row['payload'], $row['payload_hash'], ($this->clock)()]
            );
            Support::run(
                $this->central,
                'INSERT INTO event_dedup_receipts VALUES(?,?,?,?,?,?)',
                [...$key, $row['id'], $row['payload_hash'], ($this->clock)()]
            );
            return $row['id'];
        }, true);
    }

    public function relay(PDO $source, int $limit = 50, ?float $deadline = null): int
    {
        if ($source->inTransaction()) {
            throw new NotificationException('source_transaction_active', 409);
        }
        if (!Support::one($source, "SELECT name FROM sqlite_master WHERE type='table' AND name='event_outbox'")) {
            return 0;
        }
        $count = 0;
        while ($count < min(50, $limit) && ($deadline === null || microtime(true) < $deadline)) {
            $row = Support::one($source, "SELECT * FROM event_outbox WHERE state='pending' AND available_at<=? ORDER BY available_at,id LIMIT 1", [($this->clock)()]);
            if (!$row) {
                break;
            }
            try {
                $this->accept($row);
                Support::run($source, "UPDATE event_outbox SET state='accepted',accepted_at=? WHERE id=?", [($this->clock)(), $row['id']]);
            } catch (NotificationException $error) {
                Support::run($source, "UPDATE event_outbox SET state='dead',last_error=? WHERE id=?", [$error->errorCode, $row['id']]);
            }
            $count++;
        }
        return $count;
    }
}
