<?php

/**
 * NOMAD CMS - Source-local notification publisher.
 * Records an event using only its source transaction and code-level event catalogue.
 * Publication remains available while the central database is offline.
 */

declare(strict_types=1);

namespace NomadCMS\Services\NotificationService\Events;

use NomadCMS\Services\NotificationService\Contracts\DomainEvent;
use NomadCMS\Services\NotificationService\NotificationException;
use NomadCMS\Services\NotificationService\Support;
use PDO;

/** Lightweight source-side client with no central database or transport dependency. */
final class SourcePublisher
{
    public function __construct(private EventRegistry $registry, private \Closure $clock)
    {
    }

    public function record(PDO $source, DomainEvent $event): array
    {
        if (!$source->inTransaction()) {
            throw new NotificationException('source_transaction_required', 409);
        }
        $payload = $event->payload;
        $this->registry->validate($payload);
        $hash = hash('sha256', Support::canonical(array_diff_key($payload, array_flip(['id', 'correlation_id', 'occurred_at']))));
        $key = [$payload['source'], $payload['type'], $payload['occurrence_key']];
        Support::run(
            $source,
            'INSERT OR IGNORE INTO event_outbox(id,source,type,occurrence_key,payload,payload_hash,available_at,created_at) VALUES(?,?,?,?,?,?,?,?)',
            [$payload['id'], ...$key, Support::json($payload), $hash, ($this->clock)(), ($this->clock)()]
        );
        $existing = Support::one($source, 'SELECT id,payload_hash FROM event_outbox WHERE source=? AND type=? AND occurrence_key=?', $key);
        if (!$existing || !hash_equals($existing['payload_hash'], $hash)) {
            throw new NotificationException('occurrence_conflict', 409);
        }
        return ['event_id' => $existing['id'], 'status' => 'accepted'];
    }
}
