<?php

/**
 * NOMAD CMS - Registered notification event definition.
 * Binds a versioned event to trusted rendering, authorization and aggregation policy.
 * Callable policies are server code and are never accepted from the rule API.
 */

declare(strict_types=1);

namespace NomadCMS\Services\NotificationService\Events;

/** Immutable code-level event contract. */
final class EventDefinition
{
    public function __construct(
        public readonly string $type,
        public readonly string $source,
        public readonly \Closure $render,
        public readonly \Closure $canRead,
        public readonly bool $urgent = false,
        public readonly int $windowSeconds = 120,
        public readonly bool $emailDefault = false,
        public readonly bool $machineOutputs = false,
        public readonly array $filterFields = [],
        public readonly ?array $allowedChannels = null,
        public readonly ?string $presentationKey = null,
        public readonly array $presentationParams = []
    ) {
    }

    /** A code-level ceiling that preferences and routing rules cannot expand. */
    public function allowsChannel(string $channel): bool
    {
        return $this->allowedChannels === null || in_array($channel, $this->allowedChannels, true);
    }
}
