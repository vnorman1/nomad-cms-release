<?php

/**
 * NOMAD CMS - Notification event catalogue.
 * Keeps module contracts independent of channel implementations and applies safe rendering.
 * Unknown event types and unsupported priorities fail before durable publication.
 */

declare(strict_types=1);

namespace NomadCMS\Services\NotificationService\Events;

use NomadCMS\Services\NotificationService\NotificationException;
use NomadCMS\Services\NotificationService\Support;

/** Trusted event definitions installed by the composition root. */
final class EventRegistry
{
    private array $definitions = [];

    public function register(EventDefinition $definition): void
    {
        $this->definitions[$definition->type] = $definition;
    }

    public function get(string $type): EventDefinition
    {
        return $this->definitions[$type] ?? throw new NotificationException('unknown_event_type');
    }

    public function validate(array $event): void
    {
        $definition = $this->get($event['type']);
        if ($definition->source !== $event['source'] || ($event['priority'] === 'urgent' && !$definition->urgent)) {
            throw new NotificationException('invalid_event_policy');
        }
    }

    public function render(array $event): array
    {
        $definition = $this->get($event['type']);
        $result = ($definition->render)($event);
        if (!is_array($result)) {
            throw new NotificationException('invalid_event_content');
        }
        Support::keys($result, ['title', 'message', 'target', 'language', 'presentation']);
        $result['title'] = Support::text($result['title'] ?? null, 200);
        $result['message'] = Support::text($result['message'] ?? '', 2000, false);
        $result += ['target' => null, 'language' => 'hu'];
        if (
            str_contains($result['title'], "\n") || str_contains($result['title'], "\r")
            || !in_array($result['language'], ['hu', 'en'], true)
            || ($result['target'] !== null && !is_array($result['target']))
        ) {
            throw new NotificationException('invalid_event_content');
        }
        if (isset($result['presentation'])) {
            $presentation = $result['presentation'];
            if (!is_array($presentation)) {
                throw new NotificationException('invalid_event_content');
            }
            Support::keys($presentation, ['key', 'params']);
            if ($definition->presentationKey === null || ($presentation['key'] ?? null) !== $definition->presentationKey
                || !is_array($presentation['params'] ?? null)) {
                throw new NotificationException('invalid_event_content');
            }
            Support::keys($presentation['params'], $definition->presentationParams);
            foreach ($presentation['params'] as $value) {
                Support::text($value, 200, false);
            }
        }
        return $result;
    }

    public function canRead(array $event, string $user): bool
    {
        try {
            return (bool) ($this->get($event['type'])->canRead)($event, $user);
        } catch (\Throwable) {
            return false;
        }
    }

    public function catalog(): array
    {
        return array_values(array_map(static fn(EventDefinition $definition): array => [
            'type' => $definition->type, 'source' => $definition->source, 'schema_version' => 1,
            'urgent_allowed' => $definition->urgent, 'email_default' => $definition->emailDefault, 'window_seconds' => $definition->windowSeconds,
            'filter_fields' => $definition->filterFields, 'machine_outputs' => $definition->machineOutputs,
            'allowed_channels' => $definition->allowedChannels,
        ], $this->definitions));
    }
}
