<?php

/**
 * NOMAD CMS - Notification routing configuration.
 * Validates bounded declarative rules and versioned registered destinations.
 * Administrative configuration cannot execute code or introduce arbitrary transport URLs.
 */

declare(strict_types=1);

namespace NomadCMS\Services\NotificationService\Routing;

use NomadCMS\Services\NotificationService\Channels\ChannelRegistry;
use NomadCMS\Services\NotificationService\Events\EventRegistry;
use NomadCMS\Services\NotificationService\NotificationException;
use NomadCMS\Services\NotificationService\Support;
use PDO;

/** Safe, optimistic configuration writes and immutable routing snapshots. */
final class ControlService
{
    public function __construct(
        private PDO $db,
        private EventRegistry $events,
        private AudienceResolver $audiences,
        private ChannelRegistry $channels,
        private \Closure $clock
    ) {
    }

    public function matching(array $event, ?array $rules = null): array
    {
        $matched = [];
        foreach ($rules ?? $this->rules() as $rule) {
            if (empty($rule['active']) || !in_array($event['type'], $rule['event_types'], true)) {
                continue;
            }
            $accept = true;
            foreach ($rule['conditions'] as $condition) {
                $value = $event;
                foreach (explode('.', $condition['field']) as $segment) {
                    $value = is_array($value) ? ($value[$segment] ?? null) : null;
                }
                $expected = $condition['value'] ?? null;
                $accept = $accept && match ($condition['operator']) {
                    'eq' => $value === $expected,
                    'in' => in_array($value, $expected, true),
                    'gte' => is_numeric($value) && is_numeric($expected) && $value >= $expected,
                    'exists' => $value !== null,
                };
            }
            if ($accept) {
                $matched[] = $rule;
            }
        }
        return $matched;
    }

    public function rules(): array
    {
        $statement = $this->db->query('SELECT r.* FROM event_rules r WHERE version=(SELECT MAX(version) FROM event_rules WHERE id=r.id) ORDER BY id LIMIT 201');
        $rules = [];
        while ($row = $statement->fetch(PDO::FETCH_ASSOC)) {
            $rules[] = json_decode($row['payload'], true) + ['id' => $row['id'], 'version' => (int) $row['version'], 'active' => (bool) $row['active']];
        }
        return $rules;
    }

    public function saveRule(array $input, ?string $id = null, ?string $actor = null): array
    {
        $payload = $this->validateRule($input);
        return Support::transaction($this->db, function () use ($id, $input, $payload, $actor): array {
            $row = $id === null ? null : Support::one($this->db, 'SELECT version FROM event_rules WHERE id=? ORDER BY version DESC LIMIT 1', [$id]);
            if ($id !== null && !$row) {
                throw new NotificationException('not_found', 404);
            }
            if ((int) ($row['version'] ?? 0) !== ($input['version'] ?? 0)) {
                throw new NotificationException('version_conflict', 409);
            }
            if ($id === null && count($this->rules()) >= 200) {
                throw new NotificationException('rule_limit');
            }
            $id ??= Support::id();
            $version = (int) ($row['version'] ?? 0) + 1;
            Support::run(
                $this->db,
                'INSERT INTO event_rules VALUES(?,?,?,?,?)',
                [$id, $version, Support::json($payload), (int) ($input['active'] ?? true), ($this->clock)()]
            );
            Support::run(
                $this->db,
                'INSERT INTO notification_audit VALUES(?,?,?,?,?)',
                [Support::id(), $actor, null, 'rule.saved:' . $id . ':' . $version, ($this->clock)()]
            );
            return $payload + ['id' => $id, 'version' => $version, 'active' => $input['active'] ?? true];
        }, true);
    }

    /** Shared validation for persisted rules and side-effect-free draft previews. */
    public function validateRule(array $input): array
    {
        Support::keys($input, ['version', 'active', 'event_types', 'conditions', 'outputs']);
        if (!is_bool($input['active'] ?? true) || !is_int($input['version'] ?? 0)) {
            throw new NotificationException('invalid_rule');
        }
        $types = $input['event_types'] ?? [];
        if (!is_array($types) || !array_is_list($types) || count($types) < 1 || count($types) > 20) {
            throw new NotificationException('invalid_rule');
        }
        $allowed = null;
        foreach ($types as $type) {
            if (!is_string($type) || str_starts_with($type, 'notification.admin.')) {
                throw new NotificationException('reserved_event_type');
            }
            $definition = $this->events->get($type);
            $fields = ['source', 'priority', ...$definition->filterFields];
            $allowed = $allowed === null ? $fields : array_intersect($allowed, $fields);
        }
        $conditions = $input['conditions'] ?? [];
        if (!is_array($conditions) || !array_is_list($conditions) || count($conditions) > 20) {
            throw new NotificationException('invalid_conditions');
        }
        foreach ($conditions as $condition) {
            if (!is_array($condition)) {
                throw new NotificationException('invalid_conditions');
            }
            Support::keys($condition, ['field', 'operator', 'value']);
            if (
                !in_array($condition['field'] ?? '', $allowed, true)
                || !in_array($condition['operator'] ?? '', ['eq', 'in', 'gte', 'exists'], true)
                || (($condition['operator'] ?? '') === 'in' && (!is_array($condition['value'] ?? null) || count($condition['value']) > 100))
            ) {
                throw new NotificationException('invalid_conditions');
            }
        }
        $outputs = $input['outputs'] ?? [];
        if (!is_array($outputs) || !array_is_list($outputs) || count($outputs) < 1 || count($outputs) > 10) {
            throw new NotificationException('invalid_outputs');
        }
        foreach ($outputs as &$output) {
            if (!is_array($output)) {
                throw new NotificationException('invalid_outputs');
            }
            if (($output['kind'] ?? '') === 'notify') {
                Support::keys($output, ['kind', 'audience', 'channels']);
                if (isset($output['audience'])) {
                    if (!is_array($output['audience'])) {
                        throw new NotificationException('invalid_audience');
                    }
                    $output['audience'] = $this->audiences->validate($output['audience']);
                }
                if (
                    !is_array($output['channels'] ?? null) || !array_is_list($output['channels'])
                    || count($output['channels']) < 1 || count($output['channels']) > 2
                    || count(array_filter($output['channels'], 'is_string')) !== count($output['channels'])
                    || array_diff($output['channels'], ['in_app', 'email'])
                ) {
                    throw new NotificationException('invalid_outputs');
                }
            } elseif (($output['kind'] ?? '') === 'invoke') {
                Support::keys($output, ['kind', 'destination_id']);
                $destination = $this->destination((string) ($output['destination_id'] ?? ''));
                foreach ($types as $type) {
                    if (!$this->events->get($type)->machineOutputs || !in_array($type, $destination['event_types'], true)) {
                        throw new NotificationException('destination_event_forbidden');
                    }
                }
            } else {
                throw new NotificationException('invalid_outputs');
            }
        }
        unset($output);
        $payload = ['event_types' => array_values(array_unique($types)), 'conditions' => $conditions, 'outputs' => $outputs];
        if (strlen(Support::json($payload)) > 16384) {
            throw new NotificationException('payload_too_large', 413);
        }
        return $payload;
    }

    public function previewRule(array $input, array $event): array
    {
        $rule = $this->validateRule($input) + ['active' => true];
        return ['draft_match' => count($this->matching($event, [$rule])) > 0, 'outputs' => $rule['outputs']];
    }

    public function destination(string $id): array
    {
        $row = Support::one($this->db, 'SELECT * FROM event_destinations WHERE id=?', [$id]);
        if (!$row) {
            throw new NotificationException('not_found', 404);
        }
        return json_decode($row['payload'], true) + ['id' => $id, 'version' => (int) $row['version'], 'active' => (bool) $row['active']];
    }

    public function destinations(): array
    {
        $statement = $this->db->query('SELECT id FROM event_destinations ORDER BY id LIMIT 200');
        $result = [];
        while ($row = $statement->fetch(PDO::FETCH_ASSOC)) {
            $result[] = $this->destination($row['id']);
        }
        return $result;
    }

    public function saveDestination(array $input, ?string $id = null, ?string $actor = null): array
    {
        Support::keys($input, ['version', 'active', 'channel', 'configuration', 'event_types', 'fields']);
        $channel = $input['channel'] ?? '';
        if (
            !is_string($channel) || $channel === 'email' || !in_array($channel, $this->channels->names(), true)
            || !is_array($input['configuration'] ?? null) || !is_bool($input['active'] ?? true)
            || !is_int($input['version'] ?? 0) || !is_array($input['event_types'] ?? null)
            || count($input['event_types']) < 1 || count($input['event_types']) > 20
            || !is_array($input['fields'] ?? []) || !array_is_list($input['fields'] ?? [])
            || count(array_filter($input['fields'] ?? [], 'is_string')) !== count($input['fields'] ?? [])
            || array_diff($input['fields'] ?? [], ['event_id', 'type', 'title', 'message', 'count'])
        ) {
            throw new NotificationException('invalid_destination');
        }
        foreach ($input['event_types'] as $type) {
            if (!is_string($type) || !$this->events->get($type)->machineOutputs) {
                throw new NotificationException('destination_event_forbidden');
            }
        }
        if ($channel === 'webhook') {
            Support::keys($input['configuration'], ['webhook_id']);
            if (!is_int($input['configuration']['webhook_id'] ?? null)) {
                throw new NotificationException('invalid_destination');
            }
        } elseif ($channel === 'audit') {
            Support::keys($input['configuration'], []);
        }
        $capability = $this->channels->capability($channel, $input['configuration']);
        if (!$capability['available'] && ($input['active'] ?? true)) {
            throw new NotificationException('destination_unavailable');
        }
        $payload = ['channel' => $channel, 'configuration' => $input['configuration'],
            'event_types' => $input['event_types'], 'fields' => $input['fields'] ?? ['event_id', 'type'],
            'fingerprint' => $capability['fingerprint'] ?? ''];
        if (strlen(Support::json($payload)) > 16384) {
            throw new NotificationException('payload_too_large', 413);
        }
        return Support::transaction($this->db, function () use ($id, $input, $payload, $actor): array {
            $row = $id === null ? null : $this->destination($id);
            if ((int) ($row['version'] ?? 0) !== ($input['version'] ?? 0)) {
                throw new NotificationException('version_conflict', 409);
            }
            if ($id === null && count($this->destinations()) >= 200) {
                throw new NotificationException('destination_limit');
            }
            $id ??= Support::id();
            $version = (int) ($row['version'] ?? 0) + 1;
            Support::run(
                $this->db,
                'INSERT INTO event_destinations VALUES(?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET version=excluded.version,payload=excluded.payload,active=excluded.active,updated_at=excluded.updated_at',
                [$id, $version, Support::json($payload), (int) ($input['active'] ?? true), ($this->clock)()]
            );
            Support::run(
                $this->db,
                'INSERT INTO notification_audit VALUES(?,?,?,?,?)',
                [Support::id(), $actor, null, 'destination.saved:' . $id . ':' . $version, ($this->clock)()]
            );
            return $payload + ['id' => $id, 'version' => $version, 'active' => $input['active'] ?? true];
        }, true);
    }
}
