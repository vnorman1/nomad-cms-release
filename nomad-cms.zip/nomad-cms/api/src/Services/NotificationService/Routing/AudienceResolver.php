<?php

/**
 * NOMAD CMS - Frozen notification audiences.
 * Native user/role audiences are materialized using SQL without unbounded PHP arrays.
 * Resource-specific audiences are supplied by trusted, snapshot-aware module resolvers.
 */

declare(strict_types=1);

namespace NomadCMS\Services\NotificationService\Routing;

use NomadCMS\Services\NotificationService\NotificationException;
use NomadCMS\Services\NotificationService\Support;
use PDO;

/** Validates and freezes delivery recipients before fan-out begins. */
final class AudienceResolver
{
    private array $custom = [];

    public function __construct(private PDO $db)
    {
    }

    public function register(string $kind, \Closure $snapshot): void
    {
        $this->custom[$kind] = $snapshot;
    }

    public function validate(array $audience, bool $admin = false): array
    {
        $kind = $audience['kind'] ?? '';
        if (!is_string($kind)) {
            throw new NotificationException('invalid_audience');
        }
        if ($kind === 'all_users') {
            Support::keys($audience, ['kind']);
        } elseif ($kind === 'users' || $kind === 'roles') {
            $field = $kind === 'users' ? 'ids' : 'roles';
            Support::keys($audience, ['kind', $field]);
            $values = $audience[$field] ?? null;
            if (!is_array($values) || !array_is_list($values) || count($values) < 1 || count($values) > ($kind === 'users' ? 100 : 20)) {
                throw new NotificationException('invalid_audience');
            }
            foreach ($values as $value) {
                Support::text($value, 100);
                $table = $kind === 'users' ? 'users' : 'roles';
                $column = $kind === 'users' ? 'uuid' : 'slug';
                if (!Support::one($this->db, "SELECT $column FROM $table WHERE $column=?", [$value])) {
                    throw new NotificationException('invalid_audience');
                }
            }
            $audience[$field] = array_values(array_unique($values));
            sort($audience[$field]);
        } elseif ($admin || !isset($this->custom[$kind])) {
            throw new NotificationException('invalid_audience');
        }
        return $audience;
    }

    /** Informational count only; the worker freezes the actual recipient set later. */
    public function estimate(array $audience): int
    {
        $parameters = [];
        $where = 'is_new_user=0';
        if ($audience['kind'] === 'users') {
            $parameters = $audience['ids'];
            $where .= ' AND uuid IN(' . implode(',', array_fill(0, count($parameters), '?')) . ')';
        } elseif ($audience['kind'] === 'roles') {
            $parameters = $audience['roles'];
            $where .= " AND COALESCE(NULLIF(role_slug,''),CASE WHEN is_admin=1 THEN 'super_admin' WHEN role='editor' THEN 'editor' ELSE 'viewer' END) IN(" . implode(',', array_fill(0, count($parameters), '?')) . ')';
        }
        return (int) Support::one($this->db, 'SELECT COUNT(*) AS n FROM users WHERE ' . $where, $parameters)['n'];
    }

    public function snapshot(string $route, array $audience, array $event): void
    {
        $kind = $audience['kind'];
        if ($kind === 'users') {
            foreach ($audience['ids'] as $uuid) {
                Support::run($this->db, 'INSERT OR IGNORE INTO event_recipients(route_id,user_uuid) SELECT ?,uuid FROM users WHERE uuid=? AND is_new_user=0', [$route, $uuid]);
            }
        } elseif ($kind === 'all_users') {
            Support::run($this->db, 'INSERT OR IGNORE INTO event_recipients(route_id,user_uuid) SELECT ?,uuid FROM users WHERE is_new_user=0', [$route]);
        } elseif ($kind === 'roles') {
            $marks = implode(',', array_fill(0, count($audience['roles']), '?'));
            Support::run($this->db, "INSERT OR IGNORE INTO event_recipients(route_id,user_uuid) SELECT ?,uuid FROM users WHERE is_new_user=0 AND COALESCE(NULLIF(role_slug,''),CASE WHEN is_admin=1 THEN 'super_admin' WHEN role='editor' THEN 'editor' ELSE 'viewer' END) IN ($marks)", [$route, ...$audience['roles']]);
        } elseif (isset($this->custom[$kind])) {
            foreach (($this->custom[$kind])($audience, $event) as $uuid) {
                Support::run($this->db, 'INSERT OR IGNORE INTO event_recipients(route_id,user_uuid) SELECT ?,uuid FROM users WHERE uuid=? AND is_new_user=0', [$route, $uuid]);
            }
        } else {
            throw new NotificationException('audience_unavailable');
        }
    }
}
