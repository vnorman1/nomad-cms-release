<?php

/**
 * NOMAD CMS - Central notification router.
 * Freezes routing policy and audiences, then projects recipients in bounded transactions.
 * Administrator announcements have an intrinsic route that user rules cannot expand.
 */

declare(strict_types=1);

namespace NomadCMS\Services\NotificationService\Routing;

use NomadCMS\Services\NotificationService\Channels\ChannelRegistry;
use NomadCMS\Services\NotificationService\Delivery\DeliveryService;
use NomadCMS\Services\NotificationService\Events\EventRegistry;
use NomadCMS\Services\NotificationService\Inbox\InboxService;
use NomadCMS\Services\NotificationService\NotificationException;
use NomadCMS\Services\NotificationService\Policy\Access;
use NomadCMS\Services\NotificationService\Preferences\PreferenceService;
use NomadCMS\Services\NotificationService\Support;
use NomadCMS\Services\NotificationService\Targets\TargetRegistry;
use PDO;

/** One routing authority for every registered source and installed output. */
final class EventRouter
{
    public function __construct(
        private PDO $db,
        private EventRegistry $events,
        private AudienceResolver $audiences,
        private ControlService $controls,
        private ChannelRegistry $channels,
        private Access $access,
        private PreferenceService $preferences,
        private InboxService $inbox,
        private DeliveryService $delivery,
        private TargetRegistry $targets,
        private \Closure $clock
    ) {
    }

    private function plan(array $row): void
    {
        $event = json_decode($row['payload'], true);
        $this->events->validate($event);
        $this->events->render($event);
        if (!$this->delivery->actorAllowed($event)) {
            Support::run($this->db, "UPDATE event_events SET state='completed',last_error='actor_permission_revoked' WHERE id=?", [$row['id']]);
            return;
        }
        $rules = $this->controls->rules();
        $version = hash('sha256', Support::canonical($rules));
        Support::run($this->db, 'INSERT OR IGNORE INTO event_rule_sets VALUES(?,?,?)', [$version, Support::json($rules), ($this->clock)()]);
        $outputs = [];
        if (str_starts_with($event['type'], 'notification.admin.')) {
            $announcement = Support::one($this->db, 'SELECT payload,receipt FROM notification_announcements WHERE id=?', [$event['data']['announcement_id']]);
            $request = json_decode($announcement['payload'], true);
            $receipt = json_decode($announcement['receipt'], true);
            $outputs[] = ['kind' => 'notify', 'audience' => $request['audience'],
                'channels' => $request['delivery_policy'] === 'in_app' ? ['in_app'] : ['in_app', 'email'],
                'email_capability' => $receipt['_email_capability']];
        } else {
            $matched = $this->controls->matching($event, $rules);
            foreach ($matched as $rule) {
                foreach ($rule['outputs'] as $output) {
                    $output['rule_ref'] = ['id' => $rule['id'], 'version' => $rule['version']];
                    $outputs[] = $output;
                }
            }
            if (!$matched) {
                $outputs[] = ['kind' => 'notify', 'audience' => $event['audience'], 'channels' => ['in_app', 'email']];
            }
            if ($event['priority'] === 'urgent') {
                // Rules may add recipients or machine actions, but cannot suppress the mandatory alert.
                $outputs[] = ['kind' => 'notify', 'audience' => $event['audience'], 'channels' => ['in_app', 'email']];
            }
        }
        foreach ($outputs as $output) {
            if ($output['kind'] === 'notify') {
                $output['channels'] = array_values(array_filter($output['channels'],
                    fn(string $channel): bool => $this->events->get($event['type'])->allowsChannel($channel)));
                if ($output['channels'] === []) {
                    continue;
                }
                $output['audience'] ??= $event['audience'];
                $output['email_capability'] ??= $this->channels->capability('email');
            } else {
                $destination = $this->controls->destination($output['destination_id']);
                if (!$destination['active']) {
                    continue;
                }
                if (!$this->events->get($event['type'])->allowsChannel($destination['channel'])) {
                    continue;
                }
                $output['destination'] = $destination;
            }
            $identity = $output;
            unset($identity['rule_ref']);
            $fingerprint = hash('sha256', Support::canonical($identity));
            $id = Support::id();
            $created = Support::run(
                $this->db,
                'INSERT OR IGNORE INTO event_routes(id,event_id,fingerprint,payload) VALUES(?,?,?,?)',
                [$id, $event['id'], $fingerprint, Support::json($output)]
            );
            if (!$created) {
                continue;
            }
            if ($output['kind'] === 'notify') {
                $this->audiences->snapshot($id, $output['audience'], $event);
            } else {
                $destination = $output['destination'];
                if (!$this->events->get($event['type'])->machineOutputs || !in_array($event['type'], $destination['event_types'], true)) {
                    throw new NotificationException('destination_event_forbidden');
                }
                $configuration = $destination['configuration'] + ['destination_id' => $destination['id'],
                    'destination_version' => $destination['version'], 'fields' => $destination['fields'], 'fingerprint' => $destination['fingerprint']];
                $this->delivery->enqueue($event, $id, null, $destination['channel'], $configuration);
                Support::run($this->db, "UPDATE event_routes SET state='completed' WHERE id=?", [$id]);
            }
        }
        Support::run($this->db, "UPDATE event_events SET state='routing',rules_version=? WHERE id=?", [$version, $event['id']]);
    }

    private function project(array $row): void
    {
        $event = json_decode($row['event_payload'], true);
        $route = json_decode($row['route_payload'], true);
        $user = $row['user_uuid'];
        $outcomes = [];
        if (
            !$this->delivery->actorAllowed($event) || !$this->access->user($user) || !$this->events->canRead($event, $user)
            || (!str_starts_with($event['type'], 'notification.admin.') && ($event['actor']['id'] ?? null) === $user)
        ) {
            $outcomes['all'] = 'skipped_access';
        } else {
            $content = $this->events->render($event);
            if (!$this->targets->accessible($content['target'], $user)) {
                $outcomes['all'] = 'skipped_access';
            } else {
                $preferences = $this->preferences->effective($user, $event);
                if (in_array('in_app', $route['channels'], true) && $this->events->get($event['type'])->allowsChannel('in_app')) {
                    if ($preferences['in_app']) {
                        $this->inbox->add($user, $event, $content);
                        $outcomes['in_app'] = 'delivered';
                    } else {
                        $outcomes['in_app'] = 'skipped_preference';
                    }
                }
                if (in_array('email', $route['channels'], true) && $this->events->get($event['type'])->allowsChannel('email')) {
                    $capability = $route['email_capability'];
                    if (!$capability['available']) {
                        $outcomes['email'] = 'skipped_unavailable';
                    } elseif ($preferences['email'] === 'off') {
                        $outcomes['email'] = 'skipped_preference';
                    } else {
                        $configuration = ['profile_uuid' => $capability['profile_uuid'], 'fingerprint' => $capability['fingerprint'],
                            'email' => $this->access->user($user)['email']];
                        if ($preferences['email'] === 'digest' && $event['priority'] !== 'urgent') {
                            $this->delivery->batch($event, $row['route_id'], $user, $configuration);
                        } else {
                            $this->delivery->enqueue($event, $row['route_id'], $user, 'email', $configuration);
                        }
                        $outcomes['email'] = 'queued';
                    }
                }
            }
        }
        Support::run($this->db, "UPDATE event_recipients SET state='completed',outcomes=? WHERE route_id=? AND user_uuid=?", [Support::json($outcomes), $row['route_id'], $user]);
    }

    public function run(int $limit = 100, ?float $deadline = null): int
    {
        $count = 0;
        while ($count < min(100, $limit) && ($deadline === null || microtime(true) < $deadline)) {
            $worked = Support::transaction($this->db, function () use ($count): bool {
                $recipient = Support::one($this->db, "SELECT p.route_id,p.user_uuid,r.payload AS route_payload,e.payload AS event_payload FROM event_recipients p JOIN event_routes r ON r.id=p.route_id JOIN event_events e ON e.id=r.event_id WHERE p.state='pending' ORDER BY p.route_id,p.user_uuid LIMIT 1");
                $row = Support::one($this->db, "SELECT * FROM event_events WHERE state='pending' ORDER BY received_at,id LIMIT 1");
                if ($row && (!$recipient || $count % 2 === 0)) {
                    try {
                        // The savepoint prevents a partially planned event surviving a policy failure.
                        Support::transaction($this->db, fn() => $this->plan($row));
                    } catch (NotificationException $error) {
                        Support::run($this->db, "UPDATE event_events SET state='dead',last_error=? WHERE id=?", [$error->errorCode, $row['id']]);
                    }
                    return true;
                }
                if ($recipient) {
                    $this->project($recipient);
                    return true;
                }
                $completed = Support::run($this->db, "UPDATE event_routes SET state='completed' WHERE id IN(SELECT id FROM event_routes r WHERE state='pending' AND NOT EXISTS(SELECT 1 FROM event_recipients p WHERE p.route_id=r.id AND p.state='pending') LIMIT 100)");
                $completed += Support::run($this->db, "UPDATE event_events SET state='completed' WHERE id IN(SELECT id FROM event_events e WHERE state='routing' AND NOT EXISTS(SELECT 1 FROM event_routes r WHERE r.event_id=e.id AND r.state='pending') LIMIT 100)");
                if ($completed > 0) {
                    return true;
                }
                return false;
            }, true);
            if (!$worked) {
                break;
            }
            $count++;
        }
        return $count;
    }
}
