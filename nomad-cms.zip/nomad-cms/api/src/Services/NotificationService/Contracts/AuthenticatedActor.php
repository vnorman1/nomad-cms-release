<?php

/**
 * NOMAD CMS - Trusted notification actor.
 * Created by the authenticated backend boundary, never decoded from request JSON.
 * Fresh roles and permissions are checked by the service on every mutation.
 */

declare(strict_types=1);

namespace NomadCMS\Services\NotificationService\Contracts;

/** Server-authenticated principal identifier. */
final class AuthenticatedActor
{
    public function __construct(public readonly string $uuid)
    {
    }
}
