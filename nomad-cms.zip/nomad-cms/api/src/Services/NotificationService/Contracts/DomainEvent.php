<?php

/**
 * NOMAD CMS - Domain notification envelope.
 * Carries a versioned business occurrence, not transport credentials or arbitrary URLs.
 * The source must record this envelope inside its own business transaction.
 */

declare(strict_types=1);

namespace NomadCMS\Services\NotificationService\Contracts;

use NomadCMS\Services\NotificationService\NotificationException;
use NomadCMS\Services\NotificationService\Support;

/** Immutable, bounded event envelope for server-side integrations. */
final class DomainEvent
{
    public readonly array $payload;

    public function __construct(array $payload)
    {
        Support::keys($payload, ['id', 'source', 'type', 'schema_version', 'occurrence_key', 'occurred_at',
            'actor', 'subject', 'context', 'audience', 'priority', 'data', 'correlation_id', 'causation_id', 'hop_count']);
        foreach (['source', 'type', 'occurrence_key'] as $field) {
            Support::text($payload[$field] ?? null, 200);
        }
        if (
            !preg_match('/^[a-z][a-z0-9_.-]+$/D', $payload['type'])
            || !in_array($payload['priority'] ?? 'normal', ['low', 'normal', 'urgent'], true)
            || ($payload['schema_version'] ?? 1) !== 1 || !is_array($payload['audience'] ?? null)
            || !is_array($payload['data'] ?? []) || !is_int($payload['hop_count'] ?? 0)
            || ($payload['hop_count'] ?? 0) > 5 || ($payload['hop_count'] ?? 0) < 0
        ) {
            throw new NotificationException('invalid_event');
        }
        $payload += ['id' => Support::id(), 'schema_version' => 1, 'priority' => 'normal',
            'occurred_at' => gmdate('c'), 'actor' => ['kind' => 'system'], 'subject' => null,
            'context' => [], 'data' => [], 'correlation_id' => Support::id(), 'causation_id' => null, 'hop_count' => 0];
        foreach (['id', 'correlation_id', 'occurred_at'] as $field) {
            Support::text($payload[$field], 100);
        }
        if (
            !preg_match('/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:\d{2})$/D', $payload['occurred_at'])
            || strtotime($payload['occurred_at']) === false
        ) {
            throw new NotificationException('invalid_event_time');
        }
        if (
            !is_array($payload['actor']) || !is_array($payload['context'])
            || !in_array($payload['actor']['kind'] ?? '', ['user', 'system'], true)
        ) {
            throw new NotificationException('invalid_event');
        }
        Support::keys($payload['actor'], ['kind', 'id']);
        if ($payload['actor']['kind'] === 'user') {
            Support::text($payload['actor']['id'] ?? null, 100);
        }
        if ($payload['subject'] !== null) {
            if (!is_array($payload['subject'])) {
                throw new NotificationException('invalid_event');
            }
            Support::keys($payload['subject'], ['kind', 'id']);
            Support::text($payload['subject']['kind'] ?? null, 100);
            Support::text($payload['subject']['id'] ?? null, 200);
        }
        if ($payload['causation_id'] !== null) {
            Support::text($payload['causation_id'], 100);
        }
        if (strlen(Support::json($payload)) > 16384) {
            throw new NotificationException('payload_too_large', 413);
        }
        $this->payload = $payload;
    }
}
