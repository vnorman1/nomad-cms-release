<?php

/**
 * NOMAD CMS - Personal notification inbox.
 * Uses indexed cursors, observed activity sequences and authenticated read-all watermarks.
 * Content and targets are reauthorized on every response, including aggregated entries.
 */

declare(strict_types=1);

namespace NomadCMS\Services\NotificationService\Inbox;

use NomadCMS\Services\NotificationService\Events\EventRegistry;
use NomadCMS\Services\NotificationService\NotificationException;
use NomadCMS\Services\NotificationService\Support;
use NomadCMS\Services\NotificationService\Targets\TargetRegistry;
use PDO;

/** Row-backed per-user mailbox with race-safe read semantics. */
final class InboxService
{
    public function __construct(
        private PDO $db,
        private EventRegistry $events,
        private TargetRegistry $targets,
        private string $secret,
        private \Closure $clock
    ) {
    }

    public function add(string $user, array $event, array $content): void
    {
        if (Support::one($this->db, 'SELECT notification_id FROM notification_inbox_events WHERE event_id=? AND user_uuid=?', [$event['id'], $user])) {
            return;
        }
        $now = ($this->clock)();
        $window = $event['priority'] === 'urgent' ? 0 : $this->events->get($event['type'])->windowSeconds;
        $group = hash('sha256', Support::canonical([$event['type'], $event['subject'], $content['target'], $content['language']]));
        $row = $window === 0 ? null : Support::one(
            $this->db,
            'SELECT * FROM notification_inbox WHERE user_uuid=? AND group_key=? AND group_until>? AND archived_at IS NULL AND event_count<50 ORDER BY created_at DESC LIMIT 1',
            [$user, $group, $now]
        );
        Support::run($this->db, 'INSERT OR IGNORE INTO notification_user_state(user_uuid) VALUES(?)', [$user]);
        Support::run($this->db, 'UPDATE notification_user_state SET last_activity_seq=last_activity_seq+1 WHERE user_uuid=?', [$user]);
        $sequence = (int) Support::one($this->db, 'SELECT last_activity_seq FROM notification_user_state WHERE user_uuid=?', [$user])['last_activity_seq'];
        if ($row) {
            $id = $row['id'];
            Support::run(
                $this->db,
                'UPDATE notification_inbox SET event_count=event_count+1,activity_seq=?,updated_at=?,group_until=? WHERE id=?',
                [$sequence, $now, min((int) $row['created_at'] + max(300, $window), $now + $window), $id]
            );
        } else {
            $id = Support::id();
            Support::run(
                $this->db,
                'INSERT INTO notification_inbox(id,user_uuid,event_id,group_key,group_until,payload,activity_seq,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?)',
                [$id, $user, $event['id'], $group, $now + $window, Support::json($content), $sequence, $now, $now]
            );
        }
        Support::run($this->db, 'INSERT INTO notification_inbox_events VALUES(?,?,?)', [$id, $event['id'], $user]);
    }

    private function watermark(string $user): int
    {
        return (int) (Support::one($this->db, 'SELECT read_through_seq FROM notification_user_state WHERE user_uuid=?', [$user])['read_through_seq'] ?? 0);
    }

    private function own(string $user, string $id): array
    {
        return Support::one($this->db, 'SELECT * FROM notification_inbox WHERE user_uuid=? AND id=?', [$user, $id])
            ?? throw new NotificationException('not_found', 404);
    }

    private function present(array $row, int $watermark): array
    {
        $safe = ['id' => $row['id'], 'activity_seq' => (int) $row['activity_seq'],
            'unread' => $row['archived_at'] === null && $row['activity_seq'] > max($watermark, (int) $row['read_seq']),
            'archived' => $row['archived_at'] !== null, 'created_at' => (int) $row['created_at'], 'updated_at' => (int) $row['updated_at']];
        $statement = $this->db->prepare('SELECT e.payload FROM notification_inbox_events c JOIN event_events e ON e.id=c.event_id WHERE c.notification_id=? ORDER BY e.received_at,e.id LIMIT 50');
        $statement->execute([$row['id']]);
        $content = null;
        $count = 0;
        while ($contribution = $statement->fetch(PDO::FETCH_ASSOC)) {
            $event = json_decode($contribution['payload'], true);
            if (!$this->events->canRead($event, $row['user_uuid'])) {
                continue;
            }
            $rendered = $this->events->render($event);
            if (!$this->targets->accessible($rendered['target'], $row['user_uuid'])) {
                continue;
            }
            $content ??= $rendered + ['actor' => $event['actor'], 'priority' => $event['priority'], 'source' => $event['source']];
            $count++;
        }
        if ($content === null) {
            return $safe + ['unavailable' => true, 'title' => 'Az értesítés már nem elérhető'];
        }
        $target = $content['target'];
        unset($content['target']);
        return $safe + $content + ['unavailable' => false, 'event_count' => $count,
            'action_path' => $this->targets->resolve($target, $row['user_uuid'])];
    }

    public function page(string $user, array $query = []): array
    {
        $limit = max(1, min(100, (int) ($query['limit'] ?? 25)));
        $status = $query['status'] ?? 'active';
        if (!in_array($status, ['active', 'unread', 'archived', 'all'], true)) {
            throw new NotificationException('invalid_filter');
        }
        $parameters = [$user];
        $where = 'user_uuid=?';
        // Capture before fetching: activity committed during this response must stay unread.
        $sequence = (int) (Support::one($this->db, 'SELECT last_activity_seq FROM notification_user_state WHERE user_uuid=?', [$user])['last_activity_seq'] ?? 0);
        $watermark = $this->watermark($user);
        if ($status === 'active' || $status === 'unread') {
            $where .= ' AND archived_at IS NULL';
        } elseif ($status === 'archived') {
            $where .= ' AND archived_at IS NOT NULL';
        }
        if ($status === 'unread') {
            $where .= ' AND activity_seq>? AND activity_seq>read_seq';
            $parameters[] = $watermark;
        }
        if (!empty($query['cursor'])) {
            $cursor = Support::decode((string) $query['cursor'], $this->secret, 'inbox:' . $status, $user);
            $where .= ' AND (created_at<? OR (created_at=? AND id<?))';
            array_push($parameters, $cursor['created_at'], $cursor['created_at'], $cursor['id']);
        }
        $statement = $this->db->prepare('SELECT * FROM notification_inbox WHERE ' . $where . ' ORDER BY created_at DESC,id DESC LIMIT ' . ($limit + 1));
        $statement->execute($parameters);
        $rows = $statement->fetchAll(PDO::FETCH_ASSOC);
        $more = count($rows) > $limit;
        $rows = array_slice($rows, 0, $limit);
        $last = $rows ? $rows[array_key_last($rows)] : null;
        return ['items' => array_map(fn(array $row): array => $this->present($row, $watermark), $rows),
            'next_cursor' => $more && $last ? Support::token(['purpose' => 'inbox:' . $status, 'user' => $user, 'created_at' => $last['created_at'], 'id' => $last['id']], $this->secret) : null,
            'read_token' => Support::token(['purpose' => 'read_all', 'user' => $user, 'sequence' => $sequence], $this->secret)];
    }

    /** Reauthorizes a deep-linked entry without modifying its read state. */
    public function item(string $user, string $id): array
    {
        return $this->present($this->own($user, $id), $this->watermark($user));
    }

    /** Bounded activity feed; the initial cursor establishes a silent baseline. */
    public function updates(string $user, array $query): array
    {
        $sequence = (int) (Support::one($this->db, 'SELECT last_activity_seq FROM notification_user_state WHERE user_uuid=?', [$user])['last_activity_seq'] ?? 0);
        $after = $sequence;
        if (!empty($query['cursor'])) {
            $cursor = Support::decode((string) $query['cursor'], $this->secret, 'updates', $user);
            $after = (int) $cursor['sequence'];
            if ($after > $sequence) {
                $after = $sequence;
            }
        }
        $limit = max(1, min(100, (int) ($query['limit'] ?? 50)));
        $statement = $this->db->prepare('SELECT * FROM notification_inbox WHERE user_uuid=? AND archived_at IS NULL AND activity_seq>? AND activity_seq<=? ORDER BY activity_seq LIMIT ' . ($limit + 1));
        $statement->execute([$user, $after, $sequence]);
        $rows = $statement->fetchAll(PDO::FETCH_ASSOC);
        $more = count($rows) > $limit;
        $rows = array_slice($rows, 0, $limit);
        $next = $more ? (int) $rows[array_key_last($rows)]['activity_seq'] : $sequence;
        return ['unread_count' => $this->count($user),
            'items' => array_map(fn(array $row): array => $this->present($row, $this->watermark($user)), $rows),
            'cursor' => Support::token(['purpose' => 'updates', 'user' => $user, 'sequence' => $next], $this->secret),
            'has_more_updates' => $more];
    }

    public function count(string $user): array
    {
        $row = Support::one($this->db, 'SELECT COUNT(*) AS count FROM (SELECT 1 FROM notification_inbox WHERE user_uuid=? AND archived_at IS NULL AND activity_seq>? AND activity_seq>read_seq LIMIT 1000)', [$user, $this->watermark($user)]);
        return ['count' => min(999, (int) $row['count']), 'has_more' => (int) $row['count'] > 999];
    }

    public function read(string $user, string $id, int $observed): void
    {
        $row = $this->own($user, $id);
        if ($observed < 0 || $observed > (int) $row['activity_seq']) {
            throw new NotificationException('invalid_sequence');
        }
        Support::run($this->db, 'UPDATE notification_inbox SET read_seq=MAX(read_seq,?) WHERE id=? AND user_uuid=?', [$observed, $id, $user]);
    }

    public function readAll(string $user, string $token): void
    {
        $payload = Support::decode($token, $this->secret, 'read_all', $user);
        Support::run($this->db, 'UPDATE notification_user_state SET read_through_seq=MAX(read_through_seq,?) WHERE user_uuid=?', [(int) $payload['sequence'], $user]);
    }

    public function archive(string $user, string $id): void
    {
        $this->own($user, $id);
        Support::run($this->db, 'UPDATE notification_inbox SET archived_at=COALESCE(archived_at,?),group_until=0 WHERE id=? AND user_uuid=?', [($this->clock)(), $id, $user]);
    }

    public function target(string $user, string $id): array
    {
        $view = $this->present($this->own($user, $id), $this->watermark($user));
        return $view['unavailable'] ? ['unavailable' => true] : ['unavailable' => false, 'path' => $view['action_path']];
    }
}
