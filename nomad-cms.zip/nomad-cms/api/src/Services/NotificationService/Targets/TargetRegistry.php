<?php

/**
 * NOMAD CMS - Notification resource targets.
 * Code-registered resolvers authorize structured resources and produce internal paths.
 * Request bodies cannot install resolvers, URLs, PHP callbacks or redirects.
 */

declare(strict_types=1);

namespace NomadCMS\Services\NotificationService\Targets;

use NomadCMS\Services\NotificationService\NotificationException;
use NomadCMS\Services\NotificationService\Support;

/** Resource-specific access and safe path resolution. */
final class TargetRegistry
{
    private array $resolvers = [];

    public function register(string $kind, \Closure $resolver): void
    {
        $this->resolvers[$kind] = $resolver;
    }

    /** Code-registered kinds available to the announcement composer. */
    public function names(): array
    {
        $names = array_keys($this->resolvers);
        sort($names);
        return $names;
    }

    public function resolve(?array $target, string $user): ?string
    {
        if ($target === null) {
            return null;
        }
        Support::keys($target, ['kind', 'id']);
        $kind = Support::text($target['kind'] ?? null, 100);
        Support::text($target['id'] ?? null, 200);
        if (!isset($this->resolvers[$kind])) {
            throw new NotificationException('target_unavailable', 404);
        }
        $path = ($this->resolvers[$kind])($target, $user);
        if (
            !is_string($path) || !str_starts_with($path, '/') || str_starts_with($path, '//')
            || str_contains($path, '\\') || preg_match('/[\x00-\x20\x7f]/', $path)
            || preg_match('/%(?:0[0-9a-f]|1[0-9a-f]|2f|5c)/i', $path)
        ) {
            throw new NotificationException('target_unavailable', 404);
        }
        return $path;
    }

    public function accessible(?array $target, string $user): bool
    {
        try {
            $this->resolve($target, $user);
            return true;
        } catch (NotificationException) {
            return false;
        }
    }
}
