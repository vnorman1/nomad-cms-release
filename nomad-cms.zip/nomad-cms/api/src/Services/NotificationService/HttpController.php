<?php

/**
 * NOMAD CMS - Notification HTTP boundary.
 * Authenticates human users, validates bounded JSON and dispatches service operations.
 * Schema changes and external delivery never run in these request handlers.
 */

declare(strict_types=1);

namespace NomadCMS\Services\NotificationService;

use NomadCMS\Middleware\AuthMiddleware;
use NomadCMS\Middleware\CSRFMiddleware;
use NomadCMS\Middleware\RateLimitMiddleware;
use NomadCMS\Services\NotificationService\Contracts\AuthenticatedActor;
use NomadCMS\Services\NotificationService\Contracts\DomainEvent;
use NomadCMS\Services\NotificationService\Maintenance\MaintenanceService;

/** Thin authenticated endpoints around the central service. */
final class HttpController
{
    private const GROUPS = [
        'inbox' => ['inbox', 'unread_count', 'read', 'read_all', 'archive', 'target', 'item', 'updates'],
        'preferences' => ['preferences'],
        'admin' => ['announcements', 'announcement', 'capabilities', 'preview', 'recipients'],
        'rules' => ['rules', 'rule', 'rule_preview'],
        'destinations' => ['destinations', 'destination'],
        'deliveries' => ['deliveries', 'retry'],
        'events' => ['catalog', 'status', 'webhook_options'],
    ];

    private const METHODS = [
        'item' => ['GET'], 'updates' => ['GET'], 'recipients' => ['GET'], 'webhook_options' => ['GET'],
        'inbox' => ['GET'], 'unread_count' => ['GET'], 'read' => ['POST'], 'read_all' => ['POST'],
        'archive' => ['POST'], 'target' => ['GET'], 'preferences' => ['GET', 'PUT'],
        'announcements' => ['GET', 'POST'], 'announcement' => ['GET'], 'capabilities' => ['GET'], 'preview' => ['POST'],
        'rules' => ['GET', 'POST'], 'rule' => ['GET', 'PUT', 'DELETE'], 'rule_preview' => ['POST'],
        'destinations' => ['GET', 'POST'], 'destination' => ['PUT', 'DELETE'],
        'deliveries' => ['GET'], 'retry' => ['POST'], 'catalog' => ['GET'], 'status' => ['GET'],
    ];

    public static function dispatch(string $group): void
    {
        header('Content-Type: application/json; charset=utf-8');
        header('Cache-Control: private, no-store');
        try {
            $action = (string) ($_GET['_notification_action'] ?? match ($group) {
                'admin' => 'announcements', default => $group,
            });
            if (!in_array($action, self::GROUPS[$group] ?? [], true)) {
                throw new NotificationException('not_found', 404);
            }
            $method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
            if (!in_array($method, self::METHODS[$action], true)) {
                header('Allow: ' . implode(', ', self::METHODS[$action]));
                throw new NotificationException('method_not_allowed', 405);
            }
            $authenticated = AuthMiddleware::requireAuth();
            if (($authenticated->source ?? '') === 'api_key') {
                throw new NotificationException('human_session_required', 403);
            }
            $module = NotificationModule::create();
            $actor = new AuthenticatedActor((string) $authenticated->uuid);
            if (!$module->access->user($actor->uuid)) {
                throw new NotificationException('unauthorized', 401);
            }
            if ($method !== 'GET') {
                CSRFMiddleware::validateForSession();
                RateLimitMiddleware::check('notifications:mutation:' . $actor->uuid, 60, 60);
            }
            if (session_status() === PHP_SESSION_ACTIVE) {
                session_write_close();
            }
            $body = $method === 'GET' ? [] : self::body();
            $id = (string) ($_GET['notification_id'] ?? '');
            $result = self::execute($module, $actor, $action, $method, $id, $body);
            if ($action === 'announcements' && $method === 'POST') {
                http_response_code(202);
            }
            echo Support::json(['success' => true] + $result);
        } catch (NotificationException $error) {
            http_response_code($error->status);
            echo Support::json(['success' => false, 'error' => $error->errorCode]);
        } catch (\Throwable $error) {
            error_log('[notifications] ' . get_class($error));
            http_response_code(500);
            echo Support::json(['success' => false, 'error' => 'notification_internal_error']);
        }
    }

    private static function body(): array
    {
        $raw = file_get_contents('php://input', false, null, 0, 16385);
        if ($raw === false || strlen($raw) > 16384) {
            throw new NotificationException('payload_too_large', 413);
        }
        if ($raw === '') {
            return [];
        }
        try {
            $input = json_decode($raw, true, 16, JSON_THROW_ON_ERROR);
        } catch (\JsonException) {
            throw new NotificationException('invalid_json', 400);
        }
        if (!is_array($input) || !str_starts_with(ltrim($raw), '{')) {
            throw new NotificationException('invalid_json', 400);
        }
        return $input;
    }

    private static function execute(
        NotificationModule $module,
        AuthenticatedActor $actor,
        string $action,
        string $method,
        string $id,
        array $body
    ): array {
        $uuid = $actor->uuid;
        if (in_array($action, ['inbox', 'unread_count', 'target', 'item', 'updates'], true)) {
            $module->access->require($uuid, 'notifications:read:own');
        } elseif (in_array($action, ['read', 'read_all', 'archive', 'preferences'], true)) {
            $module->access->require($uuid, 'notifications:manage:own');
        } elseif (in_array($action, ['rules', 'rule', 'rule_preview', 'destinations', 'destination', 'catalog', 'deliveries', 'status'], true)) {
            $module->access->require($uuid, $method === 'GET' || $action === 'rule_preview' ? 'events:read:*' : 'events:manage:*');
        } elseif ($action === 'retry') {
            $module->access->require($uuid, 'events:retry:*');
        }
        switch ($action) {
            case 'inbox':
                return $module->inbox->page($uuid, $_GET);
            case 'item':
                return $module->inbox->item($uuid, $id);
            case 'updates':
                return $module->inbox->updates($uuid, $_GET);
            case 'recipients':
                return (new AdminOptionsService($module))->recipients($uuid, $_GET);
            case 'webhook_options':
                return (new AdminOptionsService($module))->webhooks($uuid);
            case 'unread_count':
                return $module->inbox->count($uuid);
            case 'read':
                Support::keys($body, ['activity_seq']);
                if (!is_int($body['activity_seq'] ?? null)) {
                    throw new NotificationException('invalid_sequence');
                }
                $module->inbox->read($uuid, $id, $body['activity_seq']);
                return [];
            case 'read_all':
                Support::keys($body, ['read_token']);
                $module->inbox->readAll($uuid, Support::text($body['read_token'] ?? null, 2048));
                return [];
            case 'archive':
                Support::keys($body, []);
                $module->inbox->archive($uuid, $id);
                return [];
            case 'target':
                return $module->inbox->target($uuid, $id);
            case 'preferences':
                return $method === 'GET' ? $module->preferences->get($uuid) : $module->preferences->put($uuid, $body);
            case 'capabilities':
                return $module->service->capabilities($actor);
            case 'preview':
                return $module->service->preview($body, $actor);
            case 'announcement':
                return $module->service->announcement($id, $actor);
            case 'announcements':
                return $method === 'GET' ? $module->service->history($actor, $_GET)
                    : $module->service->sendByAdmin($body, $actor, (string) ($_SERVER['HTTP_IDEMPOTENCY_KEY'] ?? ''));
            case 'rules':
                return $method === 'GET' ? ['items' => $module->controls->rules()] : $module->controls->saveRule($body, null, $uuid);
            case 'rule':
                $rule = null;
                foreach ($module->controls->rules() as $candidate) {
                    if ($candidate['id'] === $id) {
                        $rule = $candidate;
                        break;
                    }
                }
                if (!$rule) {
                    throw new NotificationException('not_found', 404);
                }
                if ($method === 'GET') {
                    return $rule;
                }
                if ($method === 'DELETE') {
                    Support::keys($body, ['version']);
                    if (!is_int($body['version'] ?? null)) {
                        throw new NotificationException('invalid_version');
                    }
                    unset($rule['id']);
                    $body = array_replace($rule, $body, ['active' => false]);
                }
                return $module->controls->saveRule($body, $id, $uuid);
            case 'rule_preview':
                Support::keys($body, ['event', 'rule']);
                if (!is_array($body['event'] ?? null)) {
                    throw new NotificationException('invalid_event');
                }
                $event = new DomainEvent($body['event'] ?? []);
                $module->events->validate($event->payload);
                if (!$module->events->canRead($event->payload, $uuid)) {
                    throw new NotificationException('forbidden', 403);
                }
                $result = ['matches' => $module->controls->matching($event->payload)];
                if (isset($body['rule'])) {
                    $module->access->require($uuid, 'events:manage:*');
                    if (!is_array($body['rule'])) {
                        throw new NotificationException('invalid_rule');
                    }
                    $result += $module->controls->previewRule($body['rule'], $event->payload);
                }
                return $result;
            case 'destinations':
                return $method === 'GET' ? ['items' => $module->controls->destinations()] : $module->controls->saveDestination($body, null, $uuid);
            case 'destination':
                if ($method === 'DELETE') {
                    Support::keys($body, ['version']);
                    if (!is_int($body['version'] ?? null)) {
                        throw new NotificationException('invalid_version');
                    }
                    $destination = $module->controls->destination($id);
                    unset($destination['id'], $destination['fingerprint']);
                    $body = array_replace($destination, $body, ['active' => false]);
                }
                return $module->controls->saveDestination($body, $id, $uuid);
            case 'catalog':
                return ['events' => $module->events->catalog(), 'channels' => $module->channels->names()];
            case 'status':
                return (new MaintenanceService($module->db, $module->clock))->status();
            case 'deliveries':
                return $module->delivery->listing($uuid, $_GET);
            case 'retry':
                Support::keys($body, []);
                Support::transaction($module->db, function () use ($module, $id, $uuid): void {
                    $module->delivery->retry($id);
                    Support::run($module->db, 'INSERT INTO notification_audit VALUES(?,?,?,?,?)', [Support::id(), $uuid, null, 'delivery.retry:' . $id, ($module->clock)()]);
                }, true);
                return [];
        }
        throw new NotificationException('not_found', 404);
    }
}
