<?php
/**
 * NOMAD CMS - Batch Content Service
 *
 * Provides high-performance batched retrieval for multiple content and massive slots.
 * Features:
 * 1. Ultra-fast Summary Mode for login/dashboard (uses SQLite json_array_length/length).
 * 2. Overload protection for large collections (bounds items to limit, strips heavy blocks).
 * 3. MassiveDatabase integration for massive slots.
 * 4. Input sanitization, deduplication, and boundary checks.
 */

declare(strict_types=1);

namespace NomadCMS\Services;

use NomadCMS\Database\ContentDatabase;
use NomadCMS\Database\CollectionDatabase;
use NomadCMS\Middleware\AuthMiddleware;
use NomadCMS\Database\MassiveDatabase;
use NomadCMS\Security\InputSanitizer;

final class BatchContentService
{
    public const MAX_KEYS_PER_BATCH = 50;
    public const DEFAULT_COLLECTION_LIMIT = 50;

    /**
     * Process a batch content request with overload protection.
     *
     * @param array $keys List of slot keys requested
     * @param array $options Options array:
     *   - 'summary' (bool): If true, returns only aggregated item counts & sizes without loading payloads
     *   - 'mode' (string): 'summary' | 'stats' | 'data'
     *   - 'limit' (int): Maximum items to return per collection/massive slot (default 50)
     *   - 'lightweight' (bool): Force stripping heavy fields on collections even under limit
     * @return array Response array ready for JSON serialization
     */
    public static function process(array $keys, array $options = []): array
    {
        // 1. Validate keys
        if (count($keys) === 0 && empty($options['summary']) && !in_array($options['mode'] ?? '', ['summary', 'stats'], true)) {
            return [
                'success' => true,
                'data' => new \stdClass(),
                'count' => 0,
            ];
        }

        if (count($keys) > self::MAX_KEYS_PER_BATCH) {
            return [
                'success' => false,
                'status' => 400,
                'error' => "Maximum " . self::MAX_KEYS_PER_BATCH . " keys per batch allowed",
                'received' => count($keys),
                'max' => self::MAX_KEYS_PER_BATCH,
            ];
        }

        // 2. Deduplicate and sanitize keys
        $processedKeys = [];
        foreach ($keys as $key) {
            if (!is_string($key)) {
                continue;
            }
            $sanitizedKey = InputSanitizer::slotKey($key);
            if (empty($sanitizedKey) || isset($processedKeys[$sanitizedKey])) {
                continue;
            }
            $processedKeys[$sanitizedKey] = true;
        }

        if (empty($processedKeys) && empty($options['summary']) && !in_array($options['mode'] ?? '', ['summary', 'stats'], true)) {
            return [
                'success' => true,
                'data' => new \stdClass(),
                'count' => 0,
            ];
        }

        $isSummary = !empty($options['summary']) 
            || (($options['mode'] ?? '') === 'summary') 
            || (($options['mode'] ?? '') === 'stats');

        $limit = isset($options['limit']) && is_numeric($options['limit']) 
            ? min(100, max(1, (int)$options['limit']))
            : self::DEFAULT_COLLECTION_LIMIT;

        $schema = RelationService::loadSchema();
        $slotDefs = $schema['slots'] ?? [];

        // ---------------------------------------------------------------------
        // SUMMARY / STATS MODE:
        // Ultra-lightweight aggregation for login / dashboard.
        // Uses fast SQLite internal C functions (json_array_length, length) - 0 MB memory overhead.
        // ---------------------------------------------------------------------
        if ($isSummary) {
            $user = AuthMiddleware::getCurrentUser();
            if ($user !== null) {
                $processedKeys = array_filter($processedKeys, static fn(string $key): bool =>
                    !empty($user->is_admin) || RBACService::canAccessSlot($user, $key), ARRAY_FILTER_USE_KEY);
            }
            $media = null;
            if (($options['includeMedia'] ?? true) && (AuthMiddleware::hasGrantedScope('media:read:*') || AuthMiddleware::hasGrantedScope('media:read:own'))) {
                $media = MediaService::getInstance()->getSummary(AuthMiddleware::hasGrantedScope('media:read:*') ? null : ($user->uuid ?? ''));
            }
            $contentKeys = [];
            $massiveKeys = [];

            foreach (array_keys($processedKeys) as $key) {
                $type = $slotDefs[$key]['type'] ?? 'object';
                if ($type === 'massive') {
                    $massiveKeys[] = $key;
                } else {
                    $contentKeys[] = $key;
                }
            }

            $contentSummaries = !empty($contentKeys) ? ContentDatabase::getSlotSummaries($contentKeys) : [];

            $slots = [];
            $totalItems = 0;
            $totalSize = 0;

            foreach (array_keys($processedKeys) as $key) {
                $slotDef = $slotDefs[$key] ?? null;
                $declaredType = $slotDef['type'] ?? 'object';

                if ($declaredType === 'massive') {
                    try {
                        $mStats = MassiveDatabase::getStats($key);
                        $cnt = (int)($mStats['total'] ?? 0);
                    } catch (\Throwable $e) {
                        $cnt = 0;
                    }
                    $slots[$key] = [
                        'type' => 'massive',
                        'count' => $cnt,
                        'size' => 0,
                        'exists' => true,
                    ];
                    $totalItems += $cnt;
                } else {
                    $cSummary = $contentSummaries[$key] ?? [
                        'count' => 0,
                        'size' => 0,
                        'exists' => false,
                        'type' => $declaredType,
                    ];
                    $slots[$key] = [
                        'type' => $declaredType,
                        'count' => (int)$cSummary['count'],
                        'size' => (int)$cSummary['size'],
                        'exists' => (bool)$cSummary['exists'],
                    ];
                    $totalItems += (int)$cSummary['count'];
                    $totalSize += (int)$cSummary['size'];
                }
            }

            return [
                'success' => true,
                'mode' => 'summary',
                'totalItems' => $totalItems,
                'totalSize' => $totalSize,
                'activeModules' => count($processedKeys),
                'media' => $media,
                'slots' => $slots,
            ];
        }

        // ---------------------------------------------------------------------
        // STANDARD BATCH DATA MODE:
        // With collection and massive overload protection ("csak annyit amennyi szükséges").
        // Prevents unbounded 4000+ item dumps from crashing the backend.
        // ---------------------------------------------------------------------
        $results = [];
        foreach (array_keys($processedKeys) as $key) {
            $slotDef = $slotDefs[$key] ?? null;
            $declaredType = $slotDef['type'] ?? 'object';

            if ($declaredType === 'massive') {
                // Massive slot: fetch sample from massive.sqlite with pagination
                try {
                    $paginated = MassiveDatabase::getPaginated($key, 1, $limit);
                    $items = $paginated['items'] ?? [];
                    $total = (int)($paginated['total'] ?? count($items));
                    $results[$key] = [
                        'type' => 'massive',
                        'total' => $total,
                        'count' => count($items),
                        'items' => $items,
                        'hasMore' => $total > count($items),
                    ];
                } catch (\Throwable $e) {
                    error_log("Batch massive slot error for key '$key': " . $e->getMessage());
                    $results[$key] = null;
                }
            } elseif ($declaredType === 'collection') {
                // Collection slot: prevent dumping 4000 items with heavy Gutenberg blocks
                try {
                    if (CollectionDatabase::isRegistered($key)) {
                        $page = CollectionDatabase::page($key, ['limit' => $limit, 'include_blocks' => false]);
                        $results[$key] = ['type' => 'collection', 'total' => $page['total'],
                            'count' => count($page['items']), 'items' => $page['items'],
                            'hasMore' => $page['total'] > count($page['items'])];
                        continue;
                    }
                    $data = ContentDatabase::getSlot($key);
                    if (is_array($data)) {
                        $totalCount = count($data);
                        if ($totalCount > $limit || !empty($options['lightweight'])) {
                            $excluded = StaticCacheService::getExcludedManifestFields($slotDef);
                            $sliced = array_slice($data, 0, $limit);
                            $lightItems = [];
                            foreach ($sliced as $item) {
                                if (!is_array($item)) {
                                    $lightItems[] = $item;
                                    continue;
                                }
                                foreach ($excluded as $exField => $_) {
                                    unset($item[$exField]);
                                    if (isset($item['locales']) && is_array($item['locales'])) {
                                        foreach ($item['locales'] as $locKey => $locVal) {
                                            if (is_array($locVal)) {
                                                unset($item['locales'][$locKey][$exField]);
                                            }
                                        }
                                    }
                                }
                                $lightItems[] = $item;
                            }
                            $results[$key] = [
                                'type' => 'collection',
                                'total' => $totalCount,
                                'count' => count($lightItems),
                                'items' => $lightItems,
                                'hasMore' => $totalCount > count($lightItems),
                            ];
                        } else {
                            $results[$key] = $data;
                        }
                    } else {
                        $results[$key] = $data;
                    }
                } catch (\Throwable $e) {
                    error_log("Batch content error for key '$key': " . $e->getMessage());
                    $results[$key] = null;
                }
            } else {
                // Object or list slot: normal load
                try {
                    $data = ContentDatabase::getSlot($key);
                    $results[$key] = $data; // null if not found
                } catch (\Throwable $e) {
                    error_log("Batch content error for key '$key': " . $e->getMessage());
                    $results[$key] = null;
                }
            }
        }

        return [
            'success' => true,
            'data' => !empty($results) ? $results : new \stdClass(),
            'count' => count($results),
        ];
    }
}
