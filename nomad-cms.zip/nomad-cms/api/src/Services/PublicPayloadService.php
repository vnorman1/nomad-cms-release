<?php
/**
 * NOMAD CMS - Public Payload Service
 *
 * Turns internal slot content into the shape that is served to a public,
 * headless consumer. It is the LAST step of the public pipeline:
 *
 *   RelationService::projectForPublic()   relations merged, "_" keys removed
 *     -> filterPublishedContent()          unpublished items dropped
 *       -> PublicPayloadService            language split + flattening
 *
 * =============================================================================
 * THE OUTPUT CONTRACT
 * =============================================================================
 * MULTILINGUAL (i18n enabled AND more than one language):
 *
 *   {
 *     "slug": "first-project",           <- envelope / identity
 *     "year": 2025,                      <- language-independent content, ONCE
 *     "livelink": "https://example.com",
 *     "locales": {
 *       "en": { "title": "First Project",
 *               "image": { "src": "...", "alt": "stunning" },
 *               "sections": [ { "type": "richtext", "data": "..." } ] },
 *       "hu": { ... }
 *     }
 *   }
 *
 * SINGLE LANGUAGE (or i18n disabled): there is nothing to choose between, so
 * the `locales` wrapper is omitted entirely and every field sits at the root,
 * already flattened:
 *
 *   { "slug": "first-project", "year": 2025, "title": "First Project",
 *     "image": { "src": "...", "alt": "stunning" }, "sections": [ ... ] }
 *
 * Inside a locale branch NOTHING is language-keyed any more: no `{en,hu}` maps
 * and no `alt` maps. One index into `locales[lang]` and the consumer is done.
 *
 * Block identity (`id`) and the editor-only block name (`label`) are removed
 * here, and ONLY here. They are live editor handles (`onUpdate(block.id, ...)`,
 * the table of contents caption), so they stay in the stored content and in every
 * internal/admin read — they are merely useless weight in public output.
 *
 * =============================================================================
 * SHARED-HOSTING BUDGET
 * =============================================================================
 * The work happens once, when the cache is written; public reads are static
 * files. Within a generation run:
 *
 *   - the schema is parsed once (memoised),
 *   - the per-slot field plan is computed once and reused for every item,
 *   - the media metadata map is loaded once,
 *   - each item tree is walked ONCE while all languages are materialised
 *     together (see materialize()), instead of one full walk per language,
 *   - language-independent subtrees are detected and shared rather than copied
 *     per language.
 */

declare(strict_types=1);

namespace NomadCMS\Services;

use NomadCMS\Database\ContentDatabase;

final class PublicPayloadService
{
    /**
     * Marker for "this value is identical in every language".
     *
     * materialize() returns either [ANY_LANG => value] or a per-language map.
     * Keeping the distinction is what lets a language-independent subtree be
     * traversed and stored once instead of once per language.
     */
    private const ANY_LANG = '*';

    /** Field types whose value carries media (and therefore a localized alt). */
    private const MEDIA_FIELD_TYPES = ['image', 'gallery', 'video', 'audio', 'gif'];

    /**
     * Field types that always belong under `locales`.
     *
     * Media types are here even when the field is not declared `localized`:
     * the ALT text comes from the central media metadata, which is per language.
     * That is why a non-localized `image` still appears inside every locale
     * branch, with the same `src` but its own `alt`.
     */
    private const LOCALE_BEARING_TYPES = [
        'image', 'gallery', 'video', 'audio', 'gif', 'richtext', 'blocks',
    ];

    /** Envelope keys a content field must not overwrite. */
    private const RESERVED_ENVELOPE_KEYS = [
        'slot', 'slug', 'generated_at', 'locales', 'languages', 'defaultLanguage',
    ];

    /** @var array|null Parsed schema (per request). */
    private static ?array $schema = null;

    /** @var array|null ['output'=>string[], 'known'=>string[], 'default'=>?string, 'multi'=>bool] */
    private static ?array $languageInfo = null;

    /** @var array<string, array<string, string>> slotKey => (fieldId => 'root'|'locale') */
    private static array $fieldPlans = [];

    /** @var array<string, bool> slotKey => does it carry any localized/media field */
    private static array $targetLocaleFlags = [];

    /** @var array|null Media metadata indexed by filename/url. */
    private static ?array $mediaMeta = null;

    /**
     * Drop every per-request cache. Call after the schema file was rewritten.
     */
    public static function clearCaches(): void
    {
        self::$schema = null;
        self::$languageInfo = null;
        self::$fieldPlans = [];
        self::$targetLocaleFlags = [];
        self::$mediaMeta = null;
    }

    /**
     * Forget only the media metadata (e.g. after an upload changed ALT texts).
     */
    public static function clearMediaMetaCache(): void
    {
        self::$mediaMeta = null;
    }

    // =========================================================================
    // SCHEMA / LANGUAGES
    // =========================================================================

    private static function schema(): array
    {
        if (self::$schema !== null) {
            return self::$schema;
        }

        // RelationService already memoises the same file; reuse it so a
        // generation run parses nomad.schema.json exactly once.
        return self::$schema = RelationService::loadSchema();
    }

    /**
     * Language configuration, resolved once.
     *
     * - `output`  languages the payload is emitted for.
     * - `known`   every language the schema has ever declared. Used only to
     *             RECOGNISE a language map in stored content: data may still
     *             hold `{hu: ..., en: ...}` after i18n was disabled or a
     *             language was removed, and that map must still be flattened
     *             rather than published as-is.
     * - `default` fallback language for missing translations.
     * - `multi`   false => no `locales` wrapper at all.
     *
     * @return array{output: string[], known: string[], default: ?string, multi: bool}
     */
    public static function languageInfo(): array
    {
        if (self::$languageInfo !== null) {
            return self::$languageInfo;
        }

        $i18n = self::schema()['i18n'] ?? [];
        $enabled = (bool) ($i18n['enabled'] ?? false);

        $known = [];
        foreach ((array) ($i18n['languages'] ?? []) as $lang) {
            if (is_string($lang) && trim($lang) !== '') {
                $known[] = trim($lang);
            }
        }
        $known = array_values(array_unique($known));

        $default = $i18n['defaultLanguage'] ?? null;
        if (!is_string($default) || $default === '') {
            $default = $known[0] ?? null;
        }

        // Single language, or i18n switched off: emit one flat payload.
        if (!$enabled || count($known) <= 1) {
            $single = in_array((string) $default, $known, true)
                ? (string) $default
                : ($known[0] ?? $default);

            return self::$languageInfo = [
                'output'  => is_string($single) && $single !== '' ? [$single] : [],
                'known'   => $known,
                'default' => is_string($single) && $single !== '' ? $single : null,
                'multi'   => false,
            ];
        }

        if (!in_array((string) $default, $known, true)) {
            $default = $known[0];
        }

        return self::$languageInfo = [
            'output'  => $known,
            'known'   => $known,
            'default' => (string) $default,
            'multi'   => true,
        ];
    }

    public static function isMultilingual(): bool
    {
        return self::languageInfo()['multi'];
    }

    /**
     * Language metadata for the envelope. Empty when there is nothing to choose.
     *
     * @return array{languages?: string[], defaultLanguage?: string}
     */
    public static function envelopeLanguageMeta(): array
    {
        $info = self::languageInfo();

        if (!$info['multi']) {
            return [];
        }

        return [
            'languages'       => $info['output'],
            'defaultLanguage' => (string) $info['default'],
        ];
    }

    // =========================================================================
    // FIELD PLAN
    // =========================================================================

    /**
     * Where each field of a slot belongs: 'root', 'locale', or 'omit'.
     *
     * 'omit' is currently only the schema's declared `publishedField` — a
     * CMS-internal visibility switch, not content, so it never reaches the
     * public payload in any form.
     *
     * Computed from the SCHEMA (not from the data) so the output shape is stable
     * whether or not a given item happens to have translations filled in.
     * Memoised per slot: this is derived once per generation run, not per item.
     *
     * @return array<string, string>
     */
    public static function fieldPlan(string $slotKey): array
    {
        if (isset(self::$fieldPlans[$slotKey])) {
            return self::$fieldPlans[$slotKey];
        }

        $slotDef = self::schema()['slots'][$slotKey] ?? [];
        $fields  = $slotDef['fields'] ?? [];
        $plan    = [];

        // The field that gates public visibility (e.g. "public", "published")
        // is a CMS-internal control, not content. It already did its job by the
        // time this runs — filterPublishedContent() used it to decide whether
        // the item is here at all — so publishing the flag itself would only be
        // bloat for a headless consumer. Dropped entirely: neither root nor
        // locales. A slot without a declared publishedField (e.g. one that uses
        // the implicit status/boolean convention instead) simply has nothing to
        // drop here — filterPublishedContent()'s other conventions are plain
        // content fields and are left alone.
        $publishedField = is_string($slotDef['publishedField'] ?? null) ? $slotDef['publishedField'] : null;

        if (is_array($fields)) {
            foreach ($fields as $field) {
                if (!is_array($field) || !isset($field['id']) || !is_string($field['id'])) {
                    continue;
                }

                $fieldId = $field['id'];

                if ($publishedField !== null && $fieldId === $publishedField) {
                    $plan[$fieldId] = 'omit';
                    continue;
                }

                $type = is_string($field['type'] ?? null) ? $field['type'] : '';

                if (!empty($field['localized'])) {
                    $plan[$fieldId] = 'locale';
                    continue;
                }

                if (in_array($type, self::LOCALE_BEARING_TYPES, true)) {
                    $plan[$fieldId] = 'locale';
                    continue;
                }

                if (in_array($type, RelationService::RELATION_TYPES, true)) {
                    // The embed copies the target's fields in, so it inherits the
                    // target's language dependence.
                    $target = is_string($field['target'] ?? null) ? $field['target'] : '';
                    $plan[$fieldId] = ($target !== '' && self::slotCarriesLocaleContent($target))
                        ? 'locale'
                        : 'root';
                    continue;
                }

                $plan[$fieldId] = 'root';
            }
        }

        if (RelationService::isPublicList($slotKey, self::schema())) {
            $plan['uid'] = 'root';
        }
        return self::$fieldPlans[$slotKey] = $plan;
    }

    /**
     * Does this slot have any field whose value can differ per language?
     *
     * Deliberately NOT recursive: a relation embed is depth-1, so only the
     * target's own fields can ever reach the payload.
     */
    private static function slotCarriesLocaleContent(string $slotKey): bool
    {
        if (isset(self::$targetLocaleFlags[$slotKey])) {
            return self::$targetLocaleFlags[$slotKey];
        }

        $fields = self::schema()['slots'][$slotKey]['fields'] ?? [];
        $carries = false;

        if (is_array($fields)) {
            foreach ($fields as $field) {
                if (!is_array($field)) {
                    continue;
                }
                $type = is_string($field['type'] ?? null) ? $field['type'] : '';
                if (!empty($field['localized']) || in_array($type, self::LOCALE_BEARING_TYPES, true)) {
                    $carries = true;
                    break;
                }
            }
        }

        return self::$targetLocaleFlags[$slotKey] = $carries;
    }

    // =========================================================================
    // SPLIT — the entry point
    // =========================================================================

    /**
     * Split one item (or one object slot's payload) into root + locales.
     *
     * @param  string $slotKey
     * @param  array  $item    Already relation-projected and cleaned content.
     * @return array{root: array, locales: ?array<string, array>}
     */
    public static function split(string $slotKey, array $item): array
    {
        $info = self::languageInfo();
        $plan = self::fieldPlan($slotKey);

        // --- single language / i18n off: one flat payload, no wrapper --------
        if (!$info['multi']) {
            $lang = $info['default'];
            $flat = [];
            foreach ($item as $key => $value) {
                if (($plan[$key] ?? 'root') === 'omit') {
                    continue;
                }
                $flat[$key] = self::materializeOne($value, $lang);
            }

            return ['root' => $flat, 'locales' => null];
        }

        // --- multilingual ----------------------------------------------------
        $langs   = $info['output'];
        $root    = [];
        $locales = array_fill_keys($langs, []);

        foreach ($item as $key => $value) {
            $placement = $plan[$key] ?? 'omit';

            if ($placement === 'omit') {
                continue;
            }

            $variants = self::materialize($value);

            $languageIndependent = array_key_exists(self::ANY_LANG, $variants);
            $wantsLocale = ($placement === 'locale');

            // A field the schema calls language-independent but whose VALUE is
            // language dependent still has to go under locales — there is no way
            // to represent it once at the root without losing information.
            if (!$wantsLocale && $languageIndependent) {
                $root[$key] = $variants[self::ANY_LANG];
                continue;
            }

            foreach ($langs as $lang) {
                $locales[$lang][$key] = $languageIndependent
                    ? $variants[self::ANY_LANG]
                    : ($variants[$lang] ?? null);
            }
        }

        // Nothing turned out to be language dependent (a slot with no localized,
        // media or relation fields): emitting empty per-language branches would
        // be pure noise, so drop the wrapper entirely. Consumers already treat a
        // missing `locales` as "everything is at the root".
        foreach ($locales as $branch) {
            if ($branch !== []) {
                return ['root' => $root, 'locales' => $locales];
            }
        }

        return ['root' => $root, 'locales' => null];
    }

    /**
     * Filter unpublished items out of collection/list slot data according to schema publishedField or conventions.
     * If publishedField is declared in the slot schema: only items with explicit truthy values are included (missing/empty = false).
     * If no publishedField is declared in the slot schema: bypasses and includes the item.
     */
    /**
     * Check if a single item is published according to the slot schema publishedField or conventions.
     */
    public static function isItemPublished(array $slotDef, mixed $item): bool
    {
        if (!is_array($item)) {
            return true;
        }

        $publishedField = is_string($slotDef['publishedField'] ?? null) ? $slotDef['publishedField'] : null;

        // 1. Explicit Schema Setting: slot declares publishedField
        if ($publishedField !== null) {
            if (isset($item[$publishedField])) {
                $val = filter_var($item[$publishedField], FILTER_VALIDATE_BOOLEAN, FILTER_NULL_ON_FAILURE);
                return $val !== null ? $val : !empty($item[$publishedField]);
            }
            // Field exists in slot schema, but item does not have it -> draft/unpublished (no bypass)
            return false;
        }

        // 2. Status Field Convention (when no explicit publishedField is declared)
        if (isset($item['status'])) {
            $allowed = ['stabil', 'mukodo', 'published', 'active'];
            return in_array($item['status'], $allowed, true);
        }

        // 3. Implicit Boolean Fields (when no explicit publishedField is declared)
        $implicitFields = ['published', 'isPublished', 'active', 'isActive'];
        foreach ($implicitFields as $field) {
            if (array_key_exists($field, $item)) {
                $val = filter_var($item[$field], FILTER_VALIDATE_BOOLEAN, FILTER_NULL_ON_FAILURE);
                if ($val !== null) {
                    return $val;
                }
                return !empty($item[$field]);
            }
        }

        // Default: Include if slot schema has no publishedField configured (bypass)
        return true;
    }

    /**
     * Filter unpublished items out of collection/list slot data according to schema publishedField or conventions.
     * If publishedField is declared in the slot schema: only items with explicit truthy values are included (missing/empty = false).
     * If no publishedField is declared in the slot schema: bypasses and includes the item.
     * If $includeDrafts is true, bypasses filtering completely.
     */
    public static function filterPublished(string $slotKey, mixed $data, bool $includeDrafts = false): mixed
    {
        if (!is_array($data) || !array_is_list($data)) {
            return $data;
        }

        if ($includeDrafts) {
            return $data;
        }

        $slotDef = self::schema()['slots'][$slotKey] ?? [];

        return array_values(array_filter($data, function ($item) use ($slotDef) {
            return self::isItemPublished($slotDef, $item);
        }));
    }

    /**
     * Build the public payload of a whole slot, without a cache envelope.
     *
     * Used by the dynamic public endpoint, so it returns exactly what the static
     * cache stores for the same content.
     *
     * @param  string      $slotKey
     * @param  mixed       $data          List of items, or a single object payload.
     * @param  string|null $onlyLang      Narrow `locales` to one language.
     * @param  bool        $includeDrafts Include draft items if authorized.
     * @return mixed
     */
    public static function projectSlot(string $slotKey, mixed $data, ?string $onlyLang = null, bool $includeDrafts = false): mixed
    {
        if (!is_array($data)) {
            return $data;
        }

        if (array_is_list($data)) {
            $filtered = self::filterPublished($slotKey, $data, $includeDrafts);
            $out = [];
            foreach ($filtered as $item) {
                $out[] = is_array($item)
                    ? self::merge(self::split($slotKey, $item), $onlyLang)
                    : $item;
            }
            return $out;
        }

        return self::merge(self::split($slotKey, $data), $onlyLang);
    }

    /**
     * Flatten a split result into a single payload object.
     *
     * @param array{root: array, locales: ?array<string, array>} $parts
     */
    public static function merge(array $parts, ?string $onlyLang = null): array
    {
        $payload = $parts['root'];

        if ($parts['locales'] === null) {
            return $payload;
        }

        $payload['locales'] = self::narrowLocales($parts['locales'], $onlyLang);

        return $payload;
    }

    /**
     * Keep a single language in a locales map.
     *
     * Pure key selection — the languages were already materialised, so `?lang=`
     * costs nothing beyond dropping the other keys.
     */
    public static function narrowLocales(array $locales, ?string $onlyLang): array
    {
        if ($onlyLang === null || $onlyLang === '' || !isset($locales[$onlyLang])) {
            return $locales;
        }

        return [$onlyLang => $locales[$onlyLang]];
    }

    /**
     * Reserved-key guard for envelopes that hoist content to the top level.
     *
     * The envelope owns `slot`, `slug`, `generated_at`, `locales`, `languages`
     * and `defaultLanguage`. A content field with one of those names would
     * silently corrupt the identity of the file, so it is dropped.
     *
     * `slug` is the expected, benign case: a collection item usually HAS a slug
     * field, and the envelope already carries the same value as the item's public
     * identifier. It is dropped without noise — unless it actually disagrees with
     * the identifier, which is worth knowing about because the file name (and so
     * the item's public URL) is derived from the identifier, not from the field.
     *
     * @param string|null $identifier The item's public identifier, when known.
     */
    public static function stripReservedKeys(array $root, string $slotKey, ?string $identifier = null): array
    {
        foreach (self::RESERVED_ENVELOPE_KEYS as $reserved) {
            if (!array_key_exists($reserved, $root)) {
                continue;
            }

            if ($reserved === 'slug') {
                $value = $root['slug'];
                if ($identifier !== null && is_string($value) && $value !== $identifier) {
                    error_log("[PublicPayload] '{$slotKey}' item slug '{$value}' differs from its public identifier '{$identifier}'; the identifier wins");
                }
                unset($root['slug']);
                continue;
            }

            unset($root[$reserved]);
            error_log("[PublicPayload] Dropped content field '{$reserved}' from '{$slotKey}' root: the name is reserved for the payload envelope");
        }

        return $root;
    }

    // =========================================================================
    // MATERIALISATION — one traversal, every language
    // =========================================================================

    /**
     * Materialise a value for every output language in a single traversal.
     *
     * @return array [ANY_LANG => value] when the value cannot differ per
     *               language, otherwise [lang => value].
     */
    private static function materialize(mixed $node): array
    {
        $info  = self::languageInfo();
        $langs = $info['output'];

        if (is_string($node)) {
            // Rich text: the central ALT injected into <img> is per language, so
            // the string itself becomes language dependent.
            if (self::hasMediaMarkup($node)) {
                $out = [];
                foreach ($langs as $lang) {
                    $out[$lang] = self::injectMediaAlt($node, $lang);
                }
                return $out;
            }

            // A bare media path becomes { src, alt } and alt is per language.
            if (self::isMediaString($node)) {
                $out = [];
                foreach ($langs as $lang) {
                    $out[$lang] = self::mediaObject($node, null, $lang);
                }
                return $out;
            }

            return [self::ANY_LANG => $node];
        }

        if (!is_array($node)) {
            return [self::ANY_LANG => $node];
        }

        if (self::isMediaObject($node)) {
            $out = [];
            foreach ($langs as $lang) {
                $out[$lang] = self::mediaObject($node['src'], $node['alt'] ?? null, $lang);
            }
            return $out;
        }

        if (self::isLanguageMap($node)) {
            $out = [];
            foreach ($langs as $lang) {
                // Descend into the chosen branch for THIS language only: each
                // branch is a disjoint subtree, so the whole map still costs one
                // traversal in total.
                $out[$lang] = self::materializeOne(self::pickLanguageBranch($node, $lang), $lang);
            }
            return $out;
        }

        if (self::isBlocksArray($node)) {
            return self::materializeChildren(self::stripEditorMetadata($node), true);
        }

        return self::materializeChildren($node, array_is_list($node));
    }

    /**
     * Materialise the children of a list/map and recombine them.
     *
     * When every child turned out to be language-independent the container is
     * rebuilt once and returned as ANY_LANG — that is what keeps a large,
     * untranslated subtree from being duplicated per language.
     */
    private static function materializeChildren(array $node, bool $isList): array
    {
        $langs = self::languageInfo()['output'];

        $childVariants = [];
        $allIndependent = true;

        foreach ($node as $key => $value) {
            $variants = self::materialize($value);
            $childVariants[$key] = $variants;
            if (!array_key_exists(self::ANY_LANG, $variants)) {
                $allIndependent = false;
            }
        }

        if ($allIndependent) {
            $rebuilt = [];
            foreach ($childVariants as $key => $variants) {
                $rebuilt[$key] = $variants[self::ANY_LANG];
            }
            return [self::ANY_LANG => $isList ? array_values($rebuilt) : $rebuilt];
        }

        $out = [];
        foreach ($langs as $lang) {
            $built = [];
            foreach ($childVariants as $key => $variants) {
                $built[$key] = array_key_exists(self::ANY_LANG, $variants)
                    ? $variants[self::ANY_LANG]
                    : ($variants[$lang] ?? null);
            }
            $out[$lang] = $isList ? array_values($built) : $built;
        }

        return $out;
    }

    /**
     * Materialise a value for ONE language.
     *
     * Used inside an already-chosen language branch, and for the whole payload
     * in single-language mode.
     */
    private static function materializeOne(mixed $node, ?string $lang): mixed
    {
        if (is_string($node)) {
            if (self::hasMediaMarkup($node)) {
                return self::injectMediaAlt($node, $lang);
            }
            if (self::isMediaString($node)) {
                return self::mediaObject($node, null, $lang);
            }
            return $node;
        }

        if (!is_array($node)) {
            return $node;
        }

        if (self::isMediaObject($node)) {
            return self::mediaObject($node['src'], $node['alt'] ?? null, $lang);
        }

        if (self::isLanguageMap($node)) {
            return self::materializeOne(self::pickLanguageBranch($node, $lang), $lang);
        }

        if (self::isBlocksArray($node)) {
            $node = self::stripEditorMetadata($node);
        }

        $isList = array_is_list($node);
        $out = [];
        foreach ($node as $key => $value) {
            $out[$key] = self::materializeOne($value, $lang);
        }

        return $isList ? array_values($out) : $out;
    }

    // =========================================================================
    // LANGUAGE MAPS
    // =========================================================================

    /**
     * Is this array a language-keyed map?
     *
     * Deliberately tolerant, because stored content outlives the schema: after a
     * language is removed (or i18n is switched off) the data still holds
     * `{hu: ..., en: ...}`, and such a map MUST still be flattened rather than
     * published as-is.
     *
     * A map qualifies when every key looks like a language tag AND at least one
     * of them is a language the schema declares. The second condition is what
     * keeps ordinary content objects out: `{id: ..., url: ...}` also looks like
     * language tags by shape, but neither key is a configured language.
     */
    private static function isLanguageMap(array $node): bool
    {
        if ($node === [] || array_is_list($node)) {
            return false;
        }

        $known = self::languageInfo()['known'];
        if ($known === []) {
            // No languages configured at all: nothing to flatten toward, and
            // guessing would risk mangling ordinary content.
            return false;
        }

        $sawKnown = false;

        foreach (array_keys($node) as $key) {
            if (!is_string($key) || !preg_match('/^[a-z]{2,3}(?:[-_][A-Za-z0-9]{2,8})*$/', $key)) {
                return false;
            }
            if (in_array($key, $known, true)) {
                $sawKnown = true;
            }
        }

        return $sawKnown;
    }

    /**
     * Pick a language branch: exact match, then the default language, then the
     * first non-empty entry.
     *
     * Falling back rather than returning null keeps the payload renderable when
     * a translation has not been written yet.
     */
    private static function pickLanguageBranch(array $map, ?string $lang): mixed
    {
        if ($lang !== null && isset($map[$lang]) && !self::isBlank($map[$lang])) {
            return $map[$lang];
        }

        $default = self::languageInfo()['default'];
        if ($default !== null && isset($map[$default]) && !self::isBlank($map[$default])) {
            return $map[$default];
        }

        foreach ($map as $value) {
            if (!self::isBlank($value)) {
                return $value;
            }
        }

        // Everything is empty: preserve the requested language's own empty value
        // so the key keeps its type (empty string vs empty list).
        return $map[$lang] ?? reset($map) ?: null;
    }

    private static function isBlank(mixed $value): bool
    {
        return $value === null || $value === '' || $value === [];
    }

    // =========================================================================
    // BLOCKS
    // =========================================================================

    /**
     * A list of content blocks?
     *
     * `id` is optional here on purpose: the cache path may already have removed
     * it before this runs.
     */
    private static function isBlocksArray(array $node): bool
    {
        if ($node === [] || !array_is_list($node)) {
            return false;
        }

        $first = $node[0];

        return is_array($first)
            && isset($first['type'])
            && is_string($first['type'])
            && array_key_exists('data', $first);
    }

    /**
     * Drop editor-only metadata from public output.
     *
     * `id` is how the editor addresses a block (`onUpdate(block.id, ...)`) and
     * `label` is the custom name shown in its table of contents. Both are stored
     * with the content and kept in internal/admin reads; a public consumer only
     * needs `type` and `data`.
     */
    private static function stripEditorMetadata(array $blocks): array
    {
        foreach ($blocks as $index => $block) {
            if (is_array($block)) {
                unset($blocks[$index]['id'], $blocks[$index]['label'], $blocks[$index]['_recommendation']);
            }
        }

        return $blocks;
    }

    // =========================================================================
    // MEDIA
    // =========================================================================

    private static function mediaMeta(): array
    {
        if (self::$mediaMeta === null) {
            try {
                self::$mediaMeta = ContentDatabase::getAllMediaMeta();
            } catch (\Throwable $e) {
                error_log('[PublicPayload] Media metadata unavailable: ' . $e->getMessage());
                self::$mediaMeta = [];
            }
        }

        return self::$mediaMeta;
    }

    private static function isMediaString(mixed $value): bool
    {
        if (!is_string($value) || $value === '') {
            return false;
        }

        if (str_starts_with($value, '/api/uploads/') || str_starts_with($value, '/uploads/')) {
            return true;
        }

        $meta = self::mediaMeta();
        $filename = basename(rawurldecode(parse_url($value, PHP_URL_PATH) ?? $value));

        return isset($meta[$filename]) || isset($meta[$value]);
    }

    private static function isMediaObject(array $node): bool
    {
        return isset($node['src']) && is_string($node['src']);
    }

    private static function findMediaMeta(string $src): ?array
    {
        $meta = self::mediaMeta();
        $filename = basename(rawurldecode(parse_url($src, PHP_URL_PATH) ?? $src));

        return $meta[$filename] ?? $meta[$src] ?? null;
    }

    /**
     * Build a public media object for one language: { src, alt? }.
     *
     * The central ALT from the media library is the base; a per-item custom ALT
     * overrides it. `alt` is omitted entirely when there is no text, so a
     * consumer never has to distinguish null from "".
     */
    private static function mediaObject(string $src, mixed $customAlt, ?string $lang): array
    {
        $meta = self::findMediaMeta($src);
        $central = is_array($meta['alt'] ?? null) ? $meta['alt'] : [];

        $custom = [];
        if (is_array($customAlt)) {
            foreach ($customAlt as $key => $value) {
                if (is_string($value) && trim($value) !== '') {
                    $custom[$key] = $value;
                }
            }
        } elseif (is_string($customAlt) && trim($customAlt) !== '') {
            // Already flattened (or a non-localized alt): treat it as this
            // language's text.
            $custom = $lang !== null ? [$lang => $customAlt] : ['*' => $customAlt];
        }

        $merged = array_merge($central, $custom);

        $text = null;
        if ($merged !== []) {
            $picked = self::isLanguageMap($merged)
                ? self::pickLanguageBranch($merged, $lang)
                : ($merged[$lang] ?? $merged['*'] ?? reset($merged));
            if (is_string($picked) && trim($picked) !== '') {
                $text = $picked;
            }
        }

        return $text !== null ? ['src' => $src, 'alt' => $text] : ['src' => $src];
    }

    private static function hasMediaMarkup(string $value): bool
    {
        return str_contains($value, '<img')
            || str_contains($value, '<video')
            || str_contains($value, '<audio');
    }

    /**
     * Inject the central ALT into <img>/<video>/<audio> tags of a rich text
     * string, for one language.
     *
     * An ALT the author typed by hand always wins; only empty/missing ones are
     * filled. This mirrors what the dynamic endpoint used to do on its own, so
     * both paths now produce identical HTML.
     */
    private static function injectMediaAlt(string $html, ?string $lang): string
    {
        $result = preg_replace_callback(
            '/<(img|video|audio)\b([^>]*)>/i',
            static function (array $matches) use ($lang): string {
                $tag   = $matches[1];
                $attrs = $matches[2];

                if (!preg_match('/\bsrc\s*=\s*["\']([^"\']+)["\']/i', $attrs, $srcMatch)) {
                    return $matches[0];
                }

                // Respect an explicit, non-empty alt.
                if (preg_match('/\balt\s*=\s*["\']([^"\']*)["\']/i', $attrs, $altMatch)
                    && trim($altMatch[1]) !== ''
                ) {
                    return $matches[0];
                }

                $meta = self::findMediaMeta($srcMatch[1]);
                if ($meta === null) {
                    return $matches[0];
                }

                $central = is_array($meta['alt'] ?? null) ? $meta['alt'] : [];
                if ($central === []) {
                    return $matches[0];
                }

                $text = self::pickLanguageBranch($central, $lang);
                if (!is_string($text) || trim($text) === '') {
                    return $matches[0];
                }

                $escaped = htmlspecialchars($text, ENT_QUOTES | ENT_HTML5, 'UTF-8');

                if (preg_match('/\balt\s*=\s*["\'][^"\']*["\']/i', $attrs)) {
                    $attrs = preg_replace('/\balt\s*=\s*["\'][^"\']*["\']/i', 'alt="' . $escaped . '"', $attrs);
                } else {
                    $attrs .= ' alt="' . $escaped . '"';
                }

                return '<' . $tag . $attrs . '>';
            },
            $html
        );

        return $result ?? $html;
    }
}
