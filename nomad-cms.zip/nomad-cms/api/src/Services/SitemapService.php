<?php
/**
 * NOMAD CMS - Sitemap Service
 * Race condition-free event-driven sitemap generator and cache coordinator
 * Dirty Flag + Lazy Build Architecture
 */

declare(strict_types=1);

namespace NomadCMS\Services;

final class SitemapService
{
    private static ?string $cacheDir = null;

    public static function getCacheDir(): string
    {
        if (self::$cacheDir === null) {
            self::$cacheDir = dirname(__DIR__, 2) . '/storage/cache';
        }
        return self::$cacheDir;
    }

    public static function getCacheFilePath(): string
    {
        return self::getCacheDir() . '/sitemap.xml';
    }

    public static function getDirtyFilePath(): string
    {
        return self::getCacheDir() . '/sitemap.dirty';
    }

    public static function getLockFilePath(): string
    {
        return self::getCacheDir() . '/sitemap.lock';
    }

    public static function getLlmsCacheFilePath(): string
    {
        return self::getCacheDir() . '/llms.txt';
    }

    public static function getLlmsDirtyFilePath(): string
    {
        return self::getCacheDir() . '/llms.dirty';
    }

    public static function getLlmsLockFilePath(): string
    {
        return self::getCacheDir() . '/llms.lock';
    }

    public static function getRobotsCacheFilePath(): string
    {
        return self::getCacheDir() . '/robots.txt';
    }

    public static function getRobotsDirtyFilePath(): string
    {
        return self::getCacheDir() . '/robots.dirty';
    }

    public static function getRobotsLockFilePath(): string
    {
        return self::getCacheDir() . '/robots.lock';
    }

    /**
     * Mark sitemap and llms.txt as dirty (< 1ms execution time)
     */
    public static function markDirty(): void
    {
        $dir = self::getCacheDir();
        if (!is_dir($dir)) {
            @mkdir($dir, 0777, true);
            @chmod($dir, 0777);
        }
        // A token and publication lock preserve saves that race a multi-request generation.
        $lock = fopen($dir . '/discovery-invalidation.lock', 'c+');
        if ($lock === false || !flock($lock, LOCK_EX)) {
            throw new \RuntimeException('Unable to coordinate discovery invalidation');
        }
        try {
            $token = bin2hex(random_bytes(16));
            DiscoveryService::atomic(self::getDirtyFilePath(), $token);
            DiscoveryService::atomic(self::getLlmsDirtyFilePath(), $token);
        } finally {
            flock($lock, LOCK_UN);
            fclose($lock);
        }
    }

    /**
     * Mark robots.txt as dirty (< 1ms execution time)
     * Note: Not triggered automatically by content changes
     */
    public static function markRobotsDirty(): void
    {
        $dir = self::getCacheDir();
        if (!is_dir($dir)) {
            @mkdir($dir, 0777, true);
            @chmod($dir, 0777);
        }
        $robotsDirtyFile = self::getRobotsDirtyFilePath();
        @touch($robotsDirtyFile);
        @chmod($robotsDirtyFile, 0666);
    }

    /**
     * Clear sitemap dirty flag
     */
    public static function clearDirty(): void
    {
        $dirtyFile = self::getDirtyFilePath();
        if (file_exists($dirtyFile)) {
            @chmod($dirtyFile, 0666);
            @unlink($dirtyFile);
        }
    }

    /**
     * Clear llms dirty flag
     */
    public static function clearLlmsDirty(): void
    {
        $llmsDirtyFile = self::getLlmsDirtyFilePath();
        if (file_exists($llmsDirtyFile)) {
            @chmod($llmsDirtyFile, 0666);
            @unlink($llmsDirtyFile);
        }
    }

    /**
     * Clear robots dirty flag
     */
    public static function clearRobotsDirty(): void
    {
        $robotsDirtyFile = self::getRobotsDirtyFilePath();
        if (file_exists($robotsDirtyFile)) {
            @chmod($robotsDirtyFile, 0666);
            @unlink($robotsDirtyFile);
        }
    }

    /**
     * Check if sitemap cache is dirty or missing
     */
    public static function isDirty(): bool
    {
        return file_exists(self::getDirtyFilePath()) || !file_exists(self::getCacheFilePath());
    }

    /**
     * Check if llms cache is dirty or missing
     */
    public static function isLlmsDirty(): bool
    {
        return file_exists(self::getLlmsDirtyFilePath()) || !file_exists(self::getLlmsCacheFilePath());
    }

    /**
     * Check if robots cache is dirty or missing
     */
    public static function isRobotsDirty(): bool
    {
        return file_exists(self::getRobotsDirtyFilePath()) || !file_exists(self::getRobotsCacheFilePath());
    }
}
