<?php

/**
 * NOMAD CMS - Webhook background scheduling policy.
 * Editor requests only persist changes; eligible unrelated requests and cron
 * drain the durable queue. This also protects non-FPM, single-worker hosting.
 */

declare(strict_types=1);

namespace NomadCMS\Services;

final class WebhookBackgroundPolicy
{
    public static function isEditorRequest(string $uri): bool
    {
        $path = parse_url($uri, PHP_URL_PATH) ?: '';
        return (bool) preg_match(
            '~^/api/(?:endpoints/)?(?:admin/)?(?:data|content|versions|relations|locks)(?:/|\.php$|$)~D',
            $path
        );
    }
}
