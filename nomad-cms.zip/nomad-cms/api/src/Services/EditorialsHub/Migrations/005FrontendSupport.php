<?php

/**
 * NOMAD CMS - Editorials Hub frontend support migration.
 *
 * Adds indexed persistent ticket ordering and saved message reference identities.
 * Runs explicitly and transactionally; installed databases are never upgraded by GET requests.
 *
 * @package NomadCMS\Services\EditorialsHub\Migrations
 */

declare(strict_types=1);

use NomadCMS\Services\EditorialsHub\Support;

return static function (PDO $db): void {
    Support::transaction($db, static function () use ($db): void {
        if ($db->query('SELECT 1 FROM eh_migrations WHERE version=5')->fetchColumn()) {
            return;
        }

        $db->exec(<<<'SQL'
ALTER TABLE eh_items ADD COLUMN ticket_order INTEGER NOT NULL DEFAULT 0;
UPDATE eh_items SET ticket_order=id*1024;
CREATE INDEX eh_tickets_order ON eh_items(board_id,ticket_order,id) WHERE deleted_at IS NULL;
CREATE INDEX eh_tickets_status_order ON eh_items(board_id,status_id,ticket_order,id) WHERE deleted_at IS NULL;
CREATE INDEX eh_tickets_owner_order ON eh_items(board_id,owner_uuid,ticket_order,id) WHERE deleted_at IS NULL;
CREATE INDEX eh_tickets_status_owner_order ON eh_items(board_id,status_id,owner_uuid,ticket_order,id) WHERE deleted_at IS NULL;
CREATE INDEX eh_tickets_assignee_order ON eh_items(board_id,assignee_uuid,ticket_order,id) WHERE deleted_at IS NULL;
CREATE INDEX eh_tickets_status_assignee_order ON eh_items(board_id,status_id,assignee_uuid,ticket_order,id) WHERE deleted_at IS NULL;
CREATE TABLE eh_message_references(
 message_id TEXT NOT NULL REFERENCES eh_messages(uuid) ON DELETE CASCADE,
 reference_id TEXT NOT NULL REFERENCES eh_references(id) ON DELETE CASCADE,
 position INTEGER NOT NULL,
 PRIMARY KEY(message_id,reference_id)
);
CREATE INDEX eh_message_references_order ON eh_message_references(message_id,position,reference_id);
SQL);

        $db->prepare('INSERT INTO eh_migrations(version,applied_at) VALUES(5,?)')->execute([time()]);
    });
};
