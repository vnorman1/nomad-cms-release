<?php

/**
 * NOMAD CMS - Editorials Hub 003DestinationReceipts.
 *
 * Install a durable receipt beside each destination, including the CMS content database.
 * Backend-only PHP/SQLite module; resource budgets and authorization are enforced at service boundaries.
 *
 * @package NomadCMS\Services\EditorialsHub
 */

declare(strict_types=1);

/** Install a durable receipt beside each destination, including the CMS content database. */
return static function (PDO $db): void {
    $db->beginTransaction();
    try {
        $db->exec('CREATE TABLE IF NOT EXISTS eh_destination_receipts(idempotency_key TEXT PRIMARY KEY,plan_id TEXT NOT NULL UNIQUE,proposal_id TEXT UNIQUE,actor_uuid TEXT NOT NULL,checksum TEXT NOT NULL,destination TEXT NOT NULL,result TEXT NOT NULL,plan TEXT NOT NULL,effects_done INTEGER NOT NULL DEFAULT 0,created_at INTEGER NOT NULL)');
        $db->exec('CREATE INDEX IF NOT EXISTS eh_destination_effects ON eh_destination_receipts(effects_done,created_at)');
        $db->commit();
    } catch (Throwable $error) {
        $db->rollBack();
        throw $error;
    }
};
