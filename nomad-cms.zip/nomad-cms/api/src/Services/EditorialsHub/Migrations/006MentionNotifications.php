<?php

/**
 * NOMAD CMS - Editorials mention notification migration.
 * Prepares the source-local central outbox and establishes a no-history baseline.
 * Runs only during explicit installation; polling never changes schemas or events.
 */

declare(strict_types=1);

use NomadCMS\Services\EditorialsHub\Support;
use NomadCMS\Services\NotificationService\Migrations\Schema;

return static function (PDO $db): void {
    Support::transaction($db, static function () use ($db): void {
        if ($db->query('SELECT 1 FROM eh_migrations WHERE version=6')->fetchColumn()) {
            return;
        }
        Schema::source($db);
        // Previously parked mentions were never promised to the central inbox.
        // Keep them as receipts without sending a historical notification flood.
        $db->exec("UPDATE eh_outbox SET state='historical' WHERE state='parked'");
        $db->prepare('INSERT INTO eh_migrations(version,applied_at) VALUES(6,?)')->execute([time()]);
    });
};
