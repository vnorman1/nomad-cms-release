<?php

/**
 * NOMAD CMS — Editorial canvas draft migration.
 *
 * Adds explicit proposal presentation and durable private-media bindings without
 * changing item identities or the existing note/image storage contract.
 * Runs only through the explicit module installer, never during a hot read.
 *
 * @package NomadCMS\Services\EditorialsHub\Migrations
 */

declare(strict_types=1);

use NomadCMS\Services\EditorialsHub\Support;

return static function (PDO $db): void {
    Support::transaction($db, static function () use ($db): void {
        if ($db->query('SELECT 1 FROM eh_migrations WHERE version=7')->fetchColumn()) {
            return;
        }

        $db->exec(<<<'SQL'
ALTER TABLE eh_proposals ADD COLUMN role TEXT NOT NULL DEFAULT 'standard' CHECK(role IN ('standard','canvas_draft'));
ALTER TABLE eh_proposals ADD COLUMN field_media_json TEXT NOT NULL DEFAULT '[]';
CREATE UNIQUE INDEX eh_canvas_proposal ON eh_proposals(item_id) WHERE role='canvas_draft';
CREATE TABLE eh_proposal_attachment_usages(
 proposal_id TEXT NOT NULL REFERENCES eh_proposals(id) ON DELETE CASCADE,
 attachment_id TEXT NOT NULL REFERENCES eh_attachments(id) ON DELETE CASCADE,
 PRIMARY KEY(proposal_id,attachment_id)
);
CREATE INDEX eh_proposal_attachment_lookup ON eh_proposal_attachment_usages(attachment_id,proposal_id);
CREATE INDEX eh_transfer_proposal ON eh_transfer_plans(proposal_id,id);
SQL);

        $db->prepare('INSERT INTO eh_migrations(version,applied_at) VALUES(7,?)')->execute([time()]);
    });
};
