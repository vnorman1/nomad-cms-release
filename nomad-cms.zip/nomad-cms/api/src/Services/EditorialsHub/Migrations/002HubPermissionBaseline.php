<?php

/**
 * NOMAD CMS - Editorials Hub 002HubPermissionBaseline.
 *
 * Add Hub grants once; do not restore grants removed by administrators later.
 * Backend-only PHP/SQLite module; resource budgets and authorization are enforced at service boundaries.
 *
 * @package NomadCMS\Services\EditorialsHub
 */

declare(strict_types=1);

/** Add Hub grants once; do not restore grants removed by administrators later. */
return static function (PDO $db): void {
    $db->exec('CREATE TABLE IF NOT EXISTS eh_auth_migrations(version INTEGER PRIMARY KEY,applied_at INTEGER NOT NULL)');
    $db->beginTransaction();
    try {
        $db->exec('UPDATE eh_auth_migrations SET applied_at=applied_at WHERE 0');
        if (!$db->query('SELECT 1 FROM eh_auth_migrations WHERE version=2')->fetchColumn()) {
            $grants = ['editorials:read:*','editorials:create:*','editorials:update:*','editorials:comment:*','editorials:delete:own','editorials:manage:own'];
            $insert = $db->prepare('INSERT OR IGNORE INTO role_permissions(role_id,permission) SELECT id,? FROM roles');
            foreach ($grants as $grant) {
                $insert->execute([$grant]);
            }
            $db->prepare('INSERT INTO eh_auth_migrations VALUES(2,?)')->execute([time()]);
        }
        $db->commit();
    } catch (Throwable $error) {
        $db->rollBack();
        throw $error;
    }
};
