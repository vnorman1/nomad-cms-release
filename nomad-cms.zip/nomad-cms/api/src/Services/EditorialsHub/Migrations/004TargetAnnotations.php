<?php

/**
 * NOMAD CMS - Editorials Hub target annotation migration.
 *
 * Indexes comments by stable CMS identity while retaining ordinary Hub threads.
 * Runs only during explicit installation/update; never from a read endpoint.
 *
 * @package NomadCMS\Services\EditorialsHub\Migrations
 */

declare(strict_types=1);

use NomadCMS\Services\EditorialsHub\Support;

return static function (PDO $db): void {
    Support::transaction($db, static function () use ($db): void {
        if ($db->query('SELECT 1 FROM eh_migrations WHERE version=4')->fetchColumn()) {
            return;
        }

        $db->exec(<<<'SQL'
CREATE TABLE eh_annotations(
 id INTEGER PRIMARY KEY,
 thread_id TEXT NOT NULL UNIQUE REFERENCES eh_threads(uuid) ON DELETE CASCADE,
 reference_id TEXT NOT NULL REFERENCES eh_references(id) ON DELETE CASCADE,
 board_id INTEGER NOT NULL REFERENCES eh_boards(id) ON DELETE CASCADE,
 item_id TEXT NOT NULL REFERENCES eh_items(uuid) ON DELETE CASCADE,
 target_kind TEXT NOT NULL CHECK(target_kind IN ('slot','media','module')),
 target_slot TEXT NOT NULL,
 target_item TEXT NOT NULL,
 target_field TEXT NOT NULL,
 target_locale TEXT NOT NULL,
 target_path TEXT NOT NULL
);
CREATE INDEX eh_annotations_target ON eh_annotations(target_kind,target_slot,target_item,id);
CREATE INDEX eh_annotations_board ON eh_annotations(board_id,id);
CREATE INDEX eh_annotations_item ON eh_annotations(item_id,id);
CREATE INDEX eh_annotations_reference ON eh_annotations(reference_id);
CREATE INDEX eh_messages_live ON eh_messages(thread_id,id) WHERE deleted_at IS NULL;
SQL);

        $db->prepare('INSERT INTO eh_migrations(version,applied_at) VALUES(4,?)')->execute([time()]);
    });
};
