<?php

/**
 * NOMAD CMS - Editorials Hub 001InitialSchema.
 *
 * Explicit installer migration. Execute whole statements, never split trigger SQL.
 * Backend-only PHP/SQLite module; resource budgets and authorization are enforced at service boundaries.
 *
 * @package NomadCMS\Services\EditorialsHub
 */

declare(strict_types=1);

use NomadCMS\Services\EditorialsHub\Support;

/** Explicit installer migration. Execute whole statements, never split trigger SQL. */
return static function (PDO $db, bool $enableRtree = true): void {
    $db->exec('CREATE TABLE IF NOT EXISTS eh_migrations(version INTEGER PRIMARY KEY, applied_at INTEGER NOT NULL)');
    Support::transaction($db, static function () use ($db, $enableRtree): void {
        if ($db->query('SELECT 1 FROM eh_migrations WHERE version=1')->fetchColumn()) {
            return;
        }
        $db->exec(<<<'SQL'
CREATE TABLE eh_settings(key TEXT PRIMARY KEY, value TEXT NOT NULL);
CREATE TABLE eh_boards(
 id INTEGER PRIMARY KEY, uuid TEXT NOT NULL UNIQUE, owner_uuid TEXT NOT NULL,
 title TEXT NOT NULL, visibility TEXT NOT NULL CHECK(visibility IN ('shared','private')),
 retention_seconds INTEGER, revision INTEGER NOT NULL DEFAULT 1, access_revision INTEGER NOT NULL DEFAULT 1,
 change_sequence INTEGER NOT NULL DEFAULT 0, min_sequence INTEGER NOT NULL DEFAULT 0,
 created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL, deleted_at INTEGER
);
CREATE INDEX eh_board_owner ON eh_boards(owner_uuid, id);
CREATE TABLE eh_board_members(
 board_id INTEGER NOT NULL REFERENCES eh_boards(id) ON DELETE CASCADE,
 user_uuid TEXT NOT NULL, created_at INTEGER NOT NULL, PRIMARY KEY(board_id,user_uuid)
);
CREATE INDEX eh_members_user ON eh_board_members(user_uuid,board_id);
CREATE TABLE eh_board_statuses(
 id TEXT PRIMARY KEY, board_id INTEGER NOT NULL REFERENCES eh_boards(id) ON DELETE CASCADE,
 name TEXT NOT NULL, position INTEGER NOT NULL
);
CREATE INDEX eh_status_board ON eh_board_statuses(board_id,position,id);
CREATE TABLE eh_items(
 id INTEGER PRIMARY KEY, uuid TEXT NOT NULL UNIQUE, board_id INTEGER NOT NULL REFERENCES eh_boards(id) ON DELETE CASCADE,
 owner_uuid TEXT NOT NULL, type TEXT NOT NULL CHECK(type IN ('note','image')),
 x REAL NOT NULL, y REAL NOT NULL, width REAL NOT NULL CHECK(width BETWEEN 16 AND 4096), height REAL NOT NULL CHECK(height BETWEEN 16 AND 4096),
 min_x REAL NOT NULL, max_x REAL NOT NULL, min_y REAL NOT NULL, max_y REAL NOT NULL,
 title TEXT NOT NULL DEFAULT '', preview TEXT NOT NULL DEFAULT '',
 status_id TEXT REFERENCES eh_board_statuses(id), assignee_uuid TEXT, priority TEXT NOT NULL DEFAULT 'normal', due_at INTEGER,
 attachment_id TEXT, media_filename TEXT, thread_count INTEGER NOT NULL DEFAULT 0,
 metadata_revision INTEGER NOT NULL DEFAULT 1, geometry_revision INTEGER NOT NULL DEFAULT 1,
 created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL, deleted_at INTEGER
);
CREATE INDEX eh_items_board_id ON eh_items(board_id,id) WHERE deleted_at IS NULL;
CREATE INDEX eh_items_owner ON eh_items(board_id,owner_uuid,id) WHERE deleted_at IS NULL;
CREATE INDEX eh_items_status ON eh_items(board_id,status_id,id) WHERE deleted_at IS NULL;
CREATE INDEX eh_items_assignee ON eh_items(board_id,assignee_uuid,id) WHERE deleted_at IS NULL;
CREATE INDEX eh_items_media ON eh_items(media_filename,board_id) WHERE deleted_at IS NULL AND media_filename IS NOT NULL;
CREATE INDEX eh_items_x ON eh_items(board_id,min_x,max_x,id) WHERE deleted_at IS NULL;
CREATE INDEX eh_items_y ON eh_items(board_id,min_y,max_y,id) WHERE deleted_at IS NULL;
CREATE TABLE eh_tiles(
 board_id INTEGER NOT NULL REFERENCES eh_boards(id) ON DELETE CASCADE, level INTEGER NOT NULL,
 tile_x INTEGER NOT NULL, tile_y INTEGER NOT NULL, revision INTEGER NOT NULL DEFAULT 1,
 owner_uuid TEXT NOT NULL DEFAULT '',
 item_count INTEGER NOT NULL DEFAULT 0, note_count INTEGER NOT NULL DEFAULT 0, image_count INTEGER NOT NULL DEFAULT 0,
 PRIMARY KEY(board_id,level,owner_uuid,tile_x,tile_y)
);
CREATE TABLE eh_connectors(
 id INTEGER PRIMARY KEY, uuid TEXT NOT NULL UNIQUE, board_id INTEGER NOT NULL REFERENCES eh_boards(id) ON DELETE CASCADE,
 owner_uuid TEXT NOT NULL, from_item TEXT NOT NULL REFERENCES eh_items(uuid) ON DELETE CASCADE,
 to_item TEXT NOT NULL REFERENCES eh_items(uuid) ON DELETE CASCADE,
 from_x REAL NOT NULL,from_y REAL NOT NULL,to_x REAL NOT NULL,to_y REAL NOT NULL,
 min_x REAL NOT NULL,max_x REAL NOT NULL,min_y REAL NOT NULL,max_y REAL NOT NULL,
 revision INTEGER NOT NULL DEFAULT 1,created_at INTEGER NOT NULL,deleted_at INTEGER
);
CREATE INDEX eh_connectors_board ON eh_connectors(board_id,id) WHERE deleted_at IS NULL;
CREATE INDEX eh_connectors_from ON eh_connectors(from_item);
CREATE INDEX eh_connectors_to ON eh_connectors(to_item);
CREATE TABLE eh_note_documents(
 note_id TEXT PRIMARY KEY REFERENCES eh_items(uuid) ON DELETE CASCADE,
 epoch INTEGER NOT NULL DEFAULT 1, sequence INTEGER NOT NULL DEFAULT 0, format_version INTEGER NOT NULL DEFAULT 1
);
CREATE TABLE eh_note_updates(
 note_id TEXT NOT NULL REFERENCES eh_note_documents(note_id) ON DELETE CASCADE,
 epoch INTEGER NOT NULL,sequence INTEGER NOT NULL,operation_id TEXT NOT NULL,actor_uuid TEXT NOT NULL,
 checksum TEXT NOT NULL,payload BLOB NOT NULL,created_at INTEGER NOT NULL,encoding TEXT NOT NULL DEFAULT 'raw',
 PRIMARY KEY(note_id,epoch,sequence),UNIQUE(note_id,epoch,operation_id)
);
CREATE TABLE eh_note_checkpoints(
 id INTEGER PRIMARY KEY,note_id TEXT NOT NULL REFERENCES eh_note_documents(note_id) ON DELETE CASCADE,
 epoch INTEGER NOT NULL,sequence INTEGER NOT NULL,checksum TEXT NOT NULL,payload BLOB NOT NULL,
 actor_uuid TEXT NOT NULL,created_at INTEGER NOT NULL,UNIQUE(note_id,epoch,sequence,checksum)
);
CREATE INDEX eh_checkpoint_latest ON eh_note_checkpoints(note_id,epoch,sequence DESC,id DESC);
CREATE INDEX eh_updates_archive ON eh_note_updates(encoding,created_at,note_id,epoch,sequence);
CREATE TABLE eh_note_projections(
 note_id TEXT PRIMARY KEY REFERENCES eh_note_documents(note_id) ON DELETE CASCADE,
 epoch INTEGER NOT NULL,sequence INTEGER NOT NULL,ast TEXT NOT NULL,plain_text TEXT NOT NULL,
 checksum TEXT NOT NULL,actor_uuid TEXT NOT NULL,updated_at INTEGER NOT NULL
);
CREATE TABLE eh_threads(
 id INTEGER PRIMARY KEY,uuid TEXT NOT NULL UNIQUE,item_id TEXT NOT NULL REFERENCES eh_items(uuid) ON DELETE CASCADE,
 board_id INTEGER NOT NULL REFERENCES eh_boards(id) ON DELETE CASCADE,owner_uuid TEXT NOT NULL,
 title TEXT NOT NULL,revision INTEGER NOT NULL DEFAULT 1,created_at INTEGER NOT NULL,
 last_reply_at INTEGER NOT NULL,expires_at INTEGER,deleted_at INTEGER
);
CREATE INDEX eh_thread_item ON eh_threads(item_id,id);
CREATE INDEX eh_thread_expiry ON eh_threads(expires_at,id) WHERE expires_at IS NOT NULL;
CREATE TABLE eh_messages(
 id INTEGER PRIMARY KEY,uuid TEXT NOT NULL UNIQUE,thread_id TEXT NOT NULL REFERENCES eh_threads(uuid) ON DELETE CASCADE,
 author_uuid TEXT NOT NULL,body TEXT NOT NULL,revision INTEGER NOT NULL DEFAULT 1,
 created_at INTEGER NOT NULL,updated_at INTEGER NOT NULL,deleted_at INTEGER
);
CREATE INDEX eh_messages_thread ON eh_messages(thread_id,id);
CREATE TABLE eh_references(
 id TEXT PRIMARY KEY,board_id INTEGER NOT NULL REFERENCES eh_boards(id) ON DELETE CASCADE,
 item_id TEXT NOT NULL REFERENCES eh_items(uuid) ON DELETE CASCADE,actor_uuid TEXT NOT NULL,
 occurrence_id TEXT NOT NULL,target TEXT NOT NULL,created_at INTEGER NOT NULL,
 UNIQUE(item_id,occurrence_id)
);
CREATE INDEX eh_refs_board ON eh_references(board_id,id);
CREATE TABLE eh_proposals(
 id TEXT PRIMARY KEY,board_id INTEGER NOT NULL REFERENCES eh_boards(id) ON DELETE CASCADE,
 item_id TEXT NOT NULL REFERENCES eh_items(uuid) ON DELETE CASCADE,owner_uuid TEXT NOT NULL,
 target TEXT NOT NULL,values_json TEXT NOT NULL,revision INTEGER NOT NULL DEFAULT 1,
 created_at INTEGER NOT NULL,updated_at INTEGER NOT NULL
);
CREATE TABLE eh_changes(
 board_id INTEGER NOT NULL REFERENCES eh_boards(id) ON DELETE CASCADE,sequence INTEGER NOT NULL,
 kind TEXT NOT NULL,entity_id TEXT NOT NULL,revision INTEGER NOT NULL,payload TEXT NOT NULL,
 old_bounds TEXT,new_bounds TEXT,created_at INTEGER NOT NULL,PRIMARY KEY(board_id,sequence)
);
CREATE INDEX eh_changes_time ON eh_changes(created_at,board_id,sequence);
CREATE TABLE eh_attachments(
 id TEXT PRIMARY KEY,board_id INTEGER NOT NULL REFERENCES eh_boards(id) ON DELETE CASCADE,
 owner_uuid TEXT NOT NULL,filename TEXT NOT NULL,mime TEXT NOT NULL,byte_size INTEGER NOT NULL,
 width INTEGER NOT NULL,height INTEGER NOT NULL,checksum TEXT NOT NULL,storage_key TEXT NOT NULL UNIQUE,
 thumbnail_key TEXT,thumbnail_mime TEXT,thumbnail_size INTEGER,created_at INTEGER NOT NULL,deleted_at INTEGER
);
CREATE INDEX eh_attachment_board ON eh_attachments(board_id,id);
CREATE TABLE eh_attachment_usages(
 attachment_id TEXT NOT NULL REFERENCES eh_attachments(id) ON DELETE CASCADE,
 item_id TEXT NOT NULL REFERENCES eh_items(uuid) ON DELETE CASCADE,PRIMARY KEY(attachment_id,item_id)
);
CREATE TABLE eh_transfer_plans(
 id TEXT PRIMARY KEY,board_id INTEGER NOT NULL,
 item_id TEXT NOT NULL,actor_uuid TEXT NOT NULL,
 proposal_id TEXT,plan TEXT NOT NULL,checksum TEXT NOT NULL,expires_at INTEGER NOT NULL,created_at INTEGER NOT NULL
);
CREATE TABLE eh_transfer_receipts(
 idempotency_key TEXT PRIMARY KEY,plan_id TEXT NOT NULL UNIQUE,board_id INTEGER NOT NULL,
 actor_uuid TEXT NOT NULL,checksum TEXT NOT NULL,state TEXT NOT NULL,
 destination TEXT,destination_db TEXT NOT NULL,result TEXT,created_at INTEGER NOT NULL,updated_at INTEGER NOT NULL
);
CREATE INDEX eh_transfer_pending ON eh_transfer_receipts(state,updated_at);
CREATE TABLE eh_outbox(
 id TEXT PRIMARY KEY,board_id INTEGER NOT NULL,actor_uuid TEXT NOT NULL,recipient_uuid TEXT,
 kind TEXT NOT NULL,occurrence_id TEXT,payload TEXT NOT NULL,state TEXT NOT NULL DEFAULT 'parked',
 created_at INTEGER NOT NULL,delivered_at INTEGER,UNIQUE(kind,occurrence_id,recipient_uuid)
);
CREATE INDEX eh_outbox_pending ON eh_outbox(state,created_at,id);
CREATE TABLE eh_requests(
 actor_uuid TEXT NOT NULL,operation TEXT NOT NULL,request_key TEXT NOT NULL,
 checksum TEXT NOT NULL,result TEXT NOT NULL,created_at INTEGER NOT NULL,
 PRIMARY KEY(actor_uuid,operation,request_key)
);
CREATE TABLE eh_audit(
 id INTEGER PRIMARY KEY,actor_uuid TEXT NOT NULL,board_id INTEGER NOT NULL,operation TEXT NOT NULL,created_at INTEGER NOT NULL
);
SQL);
        $rtree = false;
        if ($enableRtree) {
            try {
                $db->exec('CREATE VIRTUAL TABLE eh_item_bounds USING rtree(id,min_x,max_x,min_y,max_y,min_board,max_board)');
                $db->exec('CREATE VIRTUAL TABLE eh_connector_bounds USING rtree(id,min_x,max_x,min_y,max_y,min_board,max_board)');
                $rtree = true;
            } catch (PDOException $error) {
                if (!str_contains($error->getMessage(), 'no such module')) {
                    throw $error;
                }
            }
        }
        if ($rtree) {
            foreach (['items' => 'item', 'connectors' => 'connector'] as $table => $name) {
                $db->exec("CREATE TRIGGER eh_{$name}_insert AFTER INSERT ON eh_{$table} WHEN new.deleted_at IS NULL BEGIN INSERT INTO eh_{$name}_bounds VALUES(new.id,new.min_x,new.max_x,new.min_y,new.max_y,new.board_id,new.board_id); END");
                $db->exec("CREATE TRIGGER eh_{$name}_update AFTER UPDATE OF min_x,max_x,min_y,max_y,deleted_at ON eh_{$table} BEGIN DELETE FROM eh_{$name}_bounds WHERE id=old.id; INSERT INTO eh_{$name}_bounds SELECT new.id,new.min_x,new.max_x,new.min_y,new.max_y,new.board_id,new.board_id WHERE new.deleted_at IS NULL; END");
                $db->exec("CREATE TRIGGER eh_{$name}_delete AFTER DELETE ON eh_{$table} BEGIN DELETE FROM eh_{$name}_bounds WHERE id=old.id; END");
            }
        }
        $stmt = $db->prepare('INSERT INTO eh_settings(key,value) VALUES(?,?)');
        $stmt->execute(['spatial_mode', $rtree ? 'rtree' : 'btree']);
        $db->prepare('INSERT INTO eh_migrations VALUES(1,?)')->execute([time()]);
    });
};
