<?php

/**
 * NOMAD CMS - Editorials Hub MaintenanceService.
 *
 * Bounded retention/reconciliation job; public reads never trigger maintenance.
 * Backend-only PHP/SQLite module; resource budgets and authorization are enforced at service boundaries.
 *
 * @package NomadCMS\Services\EditorialsHub\Maintenance
 */

declare(strict_types=1);

namespace NomadCMS\Services\EditorialsHub\Maintenance;

use NomadCMS\Services\EditorialsHub\EditorialsHubModule;
use NomadCMS\Services\EditorialsHub\HubConfig;
use NomadCMS\Services\EditorialsHub\Persistence\BoardRepository;
use NomadCMS\Services\EditorialsHub\Persistence\ItemRepository;
use NomadCMS\Services\EditorialsHub\Persistence\SyncRepository;
use NomadCMS\Services\EditorialsHub\Support;

/** Bounded retention/reconciliation job; public reads never trigger maintenance. */
final class MaintenanceService
{
    public function __construct(private EditorialsHubModule $module)
    {
    }
    public function run(int $limit = 100): array
    {
        $limit = max(1, min(100, $limit));
        $repo = new BoardRepository($this->module->db);
        $stats = ['reconciled' => $this->module->transfers()->reconcile(20),'threads' => 0,'messages' => 0,'items' => 0,'children' => 0,'changes' => 0,'files' => 0,'archived' => 0];
        $audit = $repo->one("SELECT value FROM eh_settings WHERE key='restore_audit_cursor'");
        if ($audit) {
            $progress = $this->module->transfers()->auditAfterRestore((int)$audit['value']);
            $stats['restore_conflicts'] = $progress['conflicts'];
            if ($progress['has_more']) {
                $repo->run("UPDATE eh_settings SET value=? WHERE key='restore_audit_cursor'", [(string)$progress['cursor']]);
            } else {
                $repo->run("DELETE FROM eh_settings WHERE key='restore_audit_cursor'");
            }
        }
        // Compress one original update at a time, outside a writer transaction. No semantic pruning.
        $cold = $repo->all("SELECT note_id,epoch,sequence,checksum FROM eh_note_updates WHERE encoding='raw' AND created_at<? ORDER BY created_at LIMIT " . min(20, $limit), [time() - 7 * 86400]);
        foreach ($cold as $row) {
            $payload = $repo->one("SELECT payload FROM eh_note_updates WHERE note_id=? AND epoch=? AND sequence=? AND encoding='raw'", [$row['note_id'],$row['epoch'],$row['sequence']]);
            if (!$payload || !hash_equals($row['checksum'], hash('sha256', $payload['payload']))) {
                continue;
            }
            $compressed = gzencode($payload['payload'], 6);
            if ($compressed === false) {
                continue;
            }
            $stmt = $repo->db->prepare("UPDATE eh_note_updates SET payload=?,encoding='gzip' WHERE note_id=? AND epoch=? AND sequence=? AND encoding='raw' AND checksum=?");
            $stmt->bindValue(1, $compressed, \PDO::PARAM_LOB);
            $stmt->bindValue(2, $row['note_id']);
            $stmt->bindValue(3, $row['epoch'], \PDO::PARAM_INT);
            $stmt->bindValue(4, $row['sequence'], \PDO::PARAM_INT);
            $stmt->bindValue(5, $row['checksum']);
            $stmt->execute();
            $stats['archived'] += $stmt->rowCount();
        }
        Support::transaction($repo->db, function () use ($repo, $limit, &$stats): void {
            $rows = $repo->all('SELECT t.*,i.deleted_at AS item_deleted,b.deleted_at AS board_deleted FROM eh_threads t JOIN eh_items i ON i.uuid=t.item_id JOIN eh_boards b ON b.id=t.board_id WHERE t.deleted_at IS NOT NULL OR i.deleted_at IS NOT NULL OR b.deleted_at IS NOT NULL OR (t.expires_at IS NOT NULL AND t.expires_at<=?) ORDER BY t.id LIMIT ' . $limit, [time()]);
            foreach ($rows as $thread) {
                if ($thread['deleted_at'] === null) {
                    $repo->run('UPDATE eh_threads SET deleted_at=? WHERE id=?', [time(),$thread['id']]);
                    $repo->run('UPDATE eh_items SET thread_count=max(0,thread_count-1) WHERE uuid=?', [$thread['item_id']]);
                    $item = $repo->one('SELECT * FROM eh_items WHERE uuid=?', [$thread['item_id']]);
                    $g = ItemRepository::boundsOf($item);
                    (new ItemRepository($repo->db))->touchTiles((int)$thread['board_id'], $g, $g, $item['type'], $item['owner_uuid']);
                    (new SyncRepository($repo->db))->change((int)$thread['board_id'], 'thread.deleted', $thread['uuid'], (int)$thread['revision'] + 1, ['item_id' => $thread['item_id']], $g, $g);
                }
                $remaining = $limit - $stats['messages'];
                if ($remaining > 0) {
                    $s = $repo->run('DELETE FROM eh_messages WHERE id IN(SELECT id FROM eh_messages WHERE thread_id=? ORDER BY id LIMIT ' . $remaining . ')', [$thread['uuid']]);
                    $stats['messages'] += $s->rowCount();
                }
                if (!$repo->one('SELECT 1 FROM eh_messages WHERE thread_id=? LIMIT 1', [$thread['uuid']])) {
                    $repo->run('DELETE FROM eh_threads WHERE id=?', [$thread['id']]);
                    $stats['threads']++;
                }
            }
            $items = $repo->all("SELECT i.id,i.uuid FROM eh_items i JOIN eh_boards b ON b.id=i.board_id WHERE (i.deleted_at IS NOT NULL OR b.deleted_at IS NOT NULL) AND NOT EXISTS(SELECT 1 FROM eh_threads t WHERE t.item_id=i.uuid) AND NOT EXISTS(SELECT 1 FROM eh_transfer_plans p JOIN eh_transfer_receipts r ON r.plan_id=p.id WHERE p.item_id=i.uuid AND r.state='prepared') ORDER BY i.id LIMIT " . $limit);
            foreach ($items as $item) {
                // Keep durable receipts/plans available for retries; retire card-owned records in batches.
                $hasChildren = false;
                foreach (['eh_note_updates' => 'note_id','eh_note_checkpoints' => 'note_id','eh_references' => 'item_id','eh_proposals' => 'item_id','eh_attachment_usages' => 'item_id'] as $table => $column) {
                    $remaining = $limit - $stats['children'];
                    if ($remaining > 0) {
                        $deleted = $repo->run("DELETE FROM {$table} WHERE rowid IN(SELECT rowid FROM {$table} WHERE {$column}=? LIMIT {$remaining})", [$item['uuid']]);
                        $stats['children'] += $deleted->rowCount();
                    }
                    if ($repo->one("SELECT 1 FROM {$table} WHERE {$column}=? LIMIT 1", [$item['uuid']])) {
                        $hasChildren = true;
                    }
                }
                $remaining = $limit - $stats['children'];
                if ($remaining > 0) {
                    $deleted = $repo->run('DELETE FROM eh_connectors WHERE id IN(SELECT id FROM eh_connectors WHERE from_item=? OR to_item=? LIMIT ' . $remaining . ')', [$item['uuid'],$item['uuid']]);
                    $stats['children'] += $deleted->rowCount();
                }
                if ($hasChildren || $repo->one('SELECT 1 FROM eh_connectors WHERE from_item=? OR to_item=? LIMIT 1', [$item['uuid'],$item['uuid']])) {
                    continue;
                }
                $repo->run('DELETE FROM eh_items WHERE id=?', [$item['id']]);
                $stats['items']++;
            }
            $changes = $repo->all('SELECT board_id,sequence FROM eh_changes WHERE created_at<? ORDER BY created_at,board_id,sequence LIMIT ' . $limit, [time() - HubConfig::CHANGE_DAYS * 86400]);
            foreach ($changes as $change) {
                $repo->run('DELETE FROM eh_changes WHERE board_id=? AND sequence=?', [$change['board_id'],$change['sequence']]);
                $repo->run('UPDATE eh_boards SET min_sequence=max(min_sequence,?) WHERE id=?', [$change['sequence'],$change['board_id']]);
                $stats['changes']++;
            }
            $repo->run("DELETE FROM eh_outbox WHERE id IN(SELECT o.id FROM eh_outbox o JOIN eh_boards b ON b.id=o.board_id WHERE b.deleted_at IS NOT NULL LIMIT " . $limit . ')');
        });
        $attachments = $repo->all('SELECT a.* FROM eh_attachments a JOIN eh_boards b ON b.id=a.board_id WHERE (a.deleted_at IS NOT NULL OR b.deleted_at IS NOT NULL OR a.created_at<?) AND NOT EXISTS(SELECT 1 FROM eh_attachment_usages u WHERE u.attachment_id=a.id) AND NOT EXISTS(SELECT 1 FROM eh_proposal_attachment_usages u WHERE u.attachment_id=a.id) AND NOT EXISTS(SELECT 1 FROM eh_transfer_plans p JOIN eh_transfer_receipts r ON r.plan_id=p.id WHERE r.state=\'prepared\' AND (json_extract(p.plan,\'$.media_publication.attachment_id\')=a.id OR EXISTS(SELECT 1 FROM json_each(p.plan,\'$.media_publications\') publication WHERE json_extract(publication.value,\'$.attachment_id\')=a.id))) ORDER BY a.created_at LIMIT ' . $limit, [time() - 86400]);
        foreach ($attachments as $a) {
            $repo->run('UPDATE eh_attachments SET deleted_at=COALESCE(deleted_at,?) WHERE id=?', [time(),$a['id']]);
            $this->module->storage->remove($a['storage_key']);
            if ($a['thumbnail_key']) {
                $this->module->storage->remove($a['thumbnail_key']);
            }
            $repo->run('DELETE FROM eh_attachments WHERE id=?', [$a['id']]);
            $stats['files']++;
        }
        // Incremental orphan-file scan; no whole-directory array and no work during GET requests.
        $stats['files'] += $this->module->storage->sweepOrphans(fn($key)=>(bool)$repo->one('SELECT 1 FROM eh_attachments WHERE storage_key=? OR thumbnail_key=? LIMIT 1', [$key,$key]), $limit);
        Support::transaction($repo->db, function () use ($repo, $limit): void {
            $boards = $repo->all('SELECT id FROM eh_boards WHERE deleted_at IS NOT NULL AND NOT EXISTS(SELECT 1 FROM eh_items WHERE board_id=eh_boards.id) AND NOT EXISTS(SELECT 1 FROM eh_attachments WHERE board_id=eh_boards.id) LIMIT 1');
            foreach ($boards as $board) {
                foreach (['eh_tiles','eh_changes','eh_board_members','eh_board_statuses'] as $table) {
                    $repo->run("DELETE FROM {$table} WHERE rowid IN(SELECT rowid FROM {$table} WHERE board_id=? LIMIT {$limit})", [$board['id']]);
                }
                if (!$repo->one('SELECT 1 FROM eh_tiles WHERE board_id=? LIMIT 1', [$board['id']]) && !$repo->one('SELECT 1 FROM eh_changes WHERE board_id=? LIMIT 1', [$board['id']]) && !$repo->one('SELECT 1 FROM eh_board_members WHERE board_id=? LIMIT 1', [$board['id']]) && !$repo->one('SELECT 1 FROM eh_board_statuses WHERE board_id=? LIMIT 1', [$board['id']])) {
                    $repo->run('DELETE FROM eh_boards WHERE id=?', [$board['id']]);
                }
            }
        });
        return $stats;
    }
}
