<?php

/**
 * NOMAD CMS - Editorials Hub ListIdentityMigration.
 *
 * Explicit, repeatable legacy LIST identity migration through the native versioned slot saver.
 * Backend-only PHP/SQLite module; resource budgets and authorization are enforced at service boundaries.
 *
 * @package NomadCMS\Services\EditorialsHub\Maintenance
 */

declare(strict_types=1);

namespace NomadCMS\Services\EditorialsHub\Maintenance;

use NomadCMS\Database\ContentDatabase;
use NomadCMS\Services\EditorialsHub\EditorialsHubModule;
use NomadCMS\Services\EditorialsHub\HubException;
use NomadCMS\Services\EditorialsHub\Integration\Writers\ObjectListWriter;
use NomadCMS\Services\EditorialsHub\Support;

/** Explicit, repeatable legacy LIST identity migration through the native versioned slot saver. */
final class ListIdentityMigration
{
    public function __construct(private EditorialsHubModule $module)
    {
    }
    public function run(string $slot): array
    {
        $ctx = $this->module->context;
        if (!$ctx->superAdmin) {
            throw new HubException('forbidden', 403);
        }
        $definition = $this->module->targets()->slots->definition($slot);
        if (($definition['type'] ?? '') !== 'list') {
            throw new HubException('not_a_list');
        }
        $db = ContentDatabase::getInstance();
        $result = Support::transaction($db, function () use ($db, $slot, $ctx): array {
            $stmt = $db->prepare('SELECT data FROM slots WHERE key=? AND length(data)<=2097152');
            $stmt->execute([$slot]);
            $json = $stmt->fetchColumn();
            $stmt->closeCursor();
            if ($json === false) {
                throw new HubException('target_unavailable', 404);
            }
            $data = json_decode($json, true, 64, JSON_THROW_ON_ERROR);
            if (!is_array($data) || !array_is_list($data)) {
                throw new HubException('invalid_list');
            }
            $before = $data;
            $seen = [];
            $changed = 0;
            foreach ($data as &$item) {
                if (!is_array($item)) {
                    throw new HubException('invalid_list');
                }
                $id = $item['_dndId'] ?? null;
                if (!is_string($id) || $id === '') {
                    $id = Support::uuid();
                    $item['_dndId'] = $id;
                    $changed++;
                }
                if (isset($seen[$id])) {
                    throw new HubException('duplicate_list_identity', 409);
                } $seen[$id] = true;
            } unset($item);
            if ($changed) {
                ContentDatabase::saveSlot($slot, $data, ['expected_hash' => ContentDatabase::computeContentHash($before),'require_existing' => true,'slot_type' => 'list','changed_by' => $ctx->uuid,'defer_effects' => true]);
            }
            return ['slot' => $slot,'changed' => $changed,'hash' => ContentDatabase::computeContentHash($data)];
        }, 'eh_destination_receipts');
        if ($result['changed']) {
            (new ObjectListWriter($db, $ctx))->postCommit(['target' => ['slot' => $slot]]);
        }
        return $result;
    }
}
