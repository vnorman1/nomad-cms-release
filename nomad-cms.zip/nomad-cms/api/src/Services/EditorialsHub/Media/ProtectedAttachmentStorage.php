<?php

/**
 * NOMAD CMS - Editorials Hub ProtectedAttachmentStorage.
 *
 * Private, inert files with streamed staging/rename; no image decoding or public fallback.
 * Backend-only PHP/SQLite module; resource budgets and authorization are enforced at service boundaries.
 *
 * @package NomadCMS\Services\EditorialsHub\Media
 */

declare(strict_types=1);

namespace NomadCMS\Services\EditorialsHub\Media;

use NomadCMS\Services\EditorialsHub\HubException;
use NomadCMS\Services\EditorialsHub\Support;

/** Private, inert files with streamed staging/rename; no image decoding or public fallback. */
final class ProtectedAttachmentStorage
{
    private string $directory;
    public function __construct(?string $directory = null, private ?string $uploads = null)
    {
        $this->directory = $directory ?? dirname(__DIR__, 4) . '/files/editorials';
    }

    public function initialize(): void
    {
        if (!is_dir($this->directory) && !mkdir($this->directory, 0700, true) && !is_dir($this->directory)) {
            throw new HubException('attachment_storage_unavailable', 503);
        }
        $deny = "<IfModule mod_authz_core.c>\n    Require all denied\n</IfModule>\n<IfModule !mod_authz_core.c>\n    Order allow,deny\n    Deny from all\n</IfModule>\n";
        if (!is_file($this->directory . '/.htaccess') && file_put_contents($this->directory . '/.htaccess', $deny, LOCK_EX) === false) {
            throw new HubException('attachment_storage_unprotected', 503);
        }
    }

    public function inspect(string $source, bool $thumbnail = false): array
    {
        $size = filesize($source);
        $max = $thumbnail ? 262144 : (int)($_ENV['EDITORIALS_MAX_UPLOAD_BYTES'] ?? 20971520);
        if (!$size || $size > $max) {
            throw new HubException('payload_too_large', 413);
        }
        $mime = (new \finfo(FILEINFO_MIME_TYPE))->file($source);
        $dimensions = @getimagesize($source);
        $allowed = $thumbnail ? ['image/png','image/jpeg','image/webp'] : ['image/png','image/jpeg','image/webp','image/gif','image/avif'];
        if (!$dimensions || !in_array($mime, $allowed, true) || ($dimensions['mime'] ?? '') !== $mime || $dimensions[0] > 32768 || $dimensions[1] > 32768 || ($thumbnail && ($dimensions[0] > 1024 || $dimensions[1] > 1024))) {
            throw new HubException('invalid_image');
        }
        return ['mime' => $mime,'width' => $dimensions[0],'height' => $dimensions[1],'size' => $size,'checksum' => hash_file('sha256', $source)];
    }

    public function path(string $key): string
    {
        if (!preg_match('/^[a-f0-9-]{36}(?:-thumb)?\.nomad$/D', $key)) {
            throw new HubException('invalid_storage_key');
        }
        return $this->directory . '/' . $key;
    }

    public function stage(string $source, string $key): void
    {
        if (!is_file($this->directory . '/.htaccess')) {
            throw new HubException('attachment_storage_unprotected', 503);
        }
        $destination = $this->path($key);
        $temporary = $destination . '.' . bin2hex(random_bytes(6)) . '.tmp';
        $input = fopen($source, 'rb');
        $output = fopen($temporary, 'xb');
        if (!$input || !$output) {
            if (is_resource($input)) {
                fclose($input);
            } throw new HubException('attachment_storage_unavailable', 503);
        }
        try {
            if (stream_copy_to_stream($input, $output) === false) {
                throw new HubException('attachment_copy_failed', 503);
            } fflush($output);
        } finally {
            fclose($input);
            fclose($output);
        }
        chmod($temporary, 0600);
        if (!rename($temporary, $destination)) {
            @unlink($temporary);
            throw new HubException('attachment_copy_failed', 503);
        }
    }

    public function remove(string $key): void
    {
        $path = $this->path($key);
        if (is_file($path)) {
            unlink($path);
        }
    }

    public function publish(array $attachment, string $filename, ?string $uploads = null): void
    {
        if (!preg_match('/^eh-[a-f0-9-]{36}\.(png|jpg|webp|gif|avif)$/D', $filename)) {
            throw new HubException('invalid_media_filename');
        }
        $uploads ??= $this->uploads ?? dirname(__DIR__, 4) . '/uploads';
        if (!is_dir($uploads) && !mkdir($uploads, 0755, true) && !is_dir($uploads)) {
            throw new HubException('media_storage_unavailable', 503);
        }
        $dest = $uploads . '/' . $filename;
        $source = $this->path($attachment['storage_key']);
        if (is_file($dest) && hash_file('sha256', $dest) === $attachment['checksum']) {
            return;
        }
        if (!is_file($source) || hash_file('sha256', $source) !== $attachment['checksum']) {
            throw new HubException('attachment_unavailable', 503);
        }
        $tmp = $dest . '.' . bin2hex(random_bytes(6)) . '.tmp';
        if (!copy($source, $tmp) || !rename($tmp, $dest)) {
            @unlink($tmp);
            throw new HubException('media_publication_failed', 503);
        }
        chmod($dest, 0644);
    }

    public function directory(): string
    {
        return $this->directory;
    }

    /** Resume a bounded directory scan across maintenance invocations; fresh staging files are safe. */
    public function sweepOrphans(\Closure $known, int $limit = 100): int
    {
        if (!is_dir($this->directory)) {
            return 0;
        }
        $state = $this->directory . '/.sweep-offset';
        $offset = (int)(is_file($state) ? file_get_contents($state) : 0);
        $removed = 0;
        $scanned = 0;
        $iterator = new \DirectoryIterator($this->directory);
        try {
            $iterator->seek(max(0, $offset));
        } catch (\OutOfBoundsException $error) {
            $iterator->rewind();
        }
        while ($iterator->valid() && $scanned++ < max(1, min(100, $limit))) {
            $name = $iterator->getFilename();
            if ($iterator->isFile() && !str_starts_with($name, '.') && $iterator->getMTime() < time() - 86400) {
                if (str_ends_with($name, '.tmp') || (preg_match('/^[a-f0-9-]{36}(?:-thumb)?\.nomad$/D', $name) && !$known($name))) {
                    unlink($iterator->getPathname());
                    $removed++;
                }
            }
            $iterator->next();
        }
        file_put_contents($state, (string)($iterator->valid() ? $iterator->key() : 0), LOCK_EX);
        return $removed;
    }
}
