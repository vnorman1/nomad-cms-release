<?php

/**
 * NOMAD CMS - Editorials Hub AttachmentService.
 *
 * Authorized private image upload/download; filesystem work stays outside SQLite transactions.
 * Backend-only PHP/SQLite module; resource budgets and authorization are enforced at service boundaries.
 *
 * @package NomadCMS\Services\EditorialsHub\Media
 */

declare(strict_types=1);

namespace NomadCMS\Services\EditorialsHub\Media;

use NomadCMS\Services\EditorialsHub\Access\HubAccessPolicy;
use NomadCMS\Services\EditorialsHub\HubException;
use NomadCMS\Services\EditorialsHub\Persistence\BoardRepository;
use NomadCMS\Services\EditorialsHub\Support;

/** Authorized private image upload/download; filesystem work stays outside SQLite transactions. */
final class AttachmentService
{
    public function __construct(private BoardRepository $repo, private HubAccessPolicy $access, public readonly ProtectedAttachmentStorage $storage)
    {
    }

    public function upload(string $boardUuid, string $source, string $filename, string $key, ?string $thumbnail = null): array
    {
        $board = $this->access->board($boardUuid);
        $ctx = $this->access->context;
        $this->access->require('create', $ctx->uuid);
        $image = $this->storage->inspect($source);
        $thumb = $thumbnail ? $this->storage->inspect($thumbnail, true) : null;
        $filename = Support::text(basename($filename), 160);
        $id = Support::uuid();
        $storageKey = $id . '.nomad';
        $thumbKey = $thumbnail ? $id . '-thumb.nomad' : null;
        $this->storage->stage($source, $storageKey);
        if ($thumbnail) {
            $this->storage->stage($thumbnail, $thumbKey);
        }
        try {
            $result = $this->repo->idempotent($ctx->uuid, 'attachment.upload:' . $boardUuid, $key, [$filename,$image['checksum'],$thumb['checksum'] ?? null], function () use ($boardUuid, $ctx, $id, $filename, $image, $storageKey, $thumbKey, $thumb): array {
                $board = $this->access->board($boardUuid);
                $this->access->require('create', $ctx->uuid);
                $this->repo->run('INSERT INTO eh_attachments VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,NULL)', [$id,$board['id'],$ctx->uuid,$filename,$image['mime'],$image['size'],$image['width'],$image['height'],$image['checksum'],$storageKey,$thumbKey,$thumb['mime'] ?? null,$thumb['size'] ?? null,time()]);
                return ['id' => $id,'mime' => $image['mime'],'width' => $image['width'],'height' => $image['height'],'byte_size' => $image['size'],'content_url' => '/api/admin/editorials/attachments/' . $id . '/content'];
            });
            if ($result['id'] !== $id) {
                $this->storage->remove($storageKey);
                if ($thumbKey) {
                    $this->storage->remove($thumbKey);
                }
            }
            return $result;
        } catch (\Throwable $e) {
            $this->storage->remove($storageKey);
            if ($thumbKey) {
                $this->storage->remove($thumbKey);
            } throw $e;
        }
    }

    public function content(string $id, bool $thumbnail = false): array
    {
        $attachment = $this->repo->one('SELECT a.*,b.uuid AS board_uuid FROM eh_attachments a JOIN eh_boards b ON b.id=a.board_id WHERE a.id=? AND a.deleted_at IS NULL AND b.deleted_at IS NULL', [$id]);
        if (!$attachment) {
            throw new HubException('not_found', 404);
        }
        $this->access->board($attachment['board_uuid']);
        // Thumbnails are optional at upload time. Older files and browsers that
        // cannot generate one still have an authorized original to display.
        $thumbnail = $thumbnail && $attachment['thumbnail_key'] !== null;
        $path = $this->storage->path($thumbnail ? $attachment['thumbnail_key'] : $attachment['storage_key']);
        if (!is_file($path)) {
            throw new HubException('not_found', 404);
        }
        return ['path' => $path,'mime' => $thumbnail ? $attachment['thumbnail_mime'] : $attachment['mime'],'size' => $thumbnail ? $attachment['thumbnail_size'] : $attachment['byte_size'],'filename' => $attachment['filename']];
    }
}
