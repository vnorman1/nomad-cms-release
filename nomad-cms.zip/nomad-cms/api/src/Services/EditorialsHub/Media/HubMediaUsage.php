<?php

/**
 * NOMAD CMS - Editorials Hub HubMediaUsage.
 *
 * Cross-database media deletion guards without revealing private board titles or item IDs.
 * Backend-only PHP/SQLite module; resource budgets and authorization are enforced at service boundaries.
 *
 * @package NomadCMS\Services\EditorialsHub\Media
 */

declare(strict_types=1);

namespace NomadCMS\Services\EditorialsHub\Media;

use NomadCMS\Database\MassiveDatabase;
use NomadCMS\Services\EditorialsHub\EditorialsHubModule;

/** Cross-database media deletion guards without revealing private board titles or item IDs. */
final class HubMediaUsage
{
    public static function counts(): array
    {
        $db = MassiveDatabase::getInstance(true);
        if (!EditorialsHubModule::installed($db)) {
            return [];
        }
        $stmt = $db->query('SELECT i.media_filename,COUNT(*) AS n FROM eh_items i JOIN eh_boards b ON b.id=i.board_id WHERE i.media_filename IS NOT NULL AND i.deleted_at IS NULL AND b.deleted_at IS NULL GROUP BY i.media_filename');
        $out = [];
        while ($row = $stmt->fetch()) {
            $out[$row['media_filename']] = (int)$row['n'];
        } $stmt->closeCursor();
        return $out;
    }
    public static function find(string $filename): array
    {
        $db = MassiveDatabase::getInstance(true);
        if (!EditorialsHubModule::installed($db)) {
            return [];
        }
        $stmt = $db->prepare('SELECT i.id FROM eh_items i JOIN eh_boards b ON b.id=i.board_id WHERE i.media_filename=? AND i.deleted_at IS NULL AND b.deleted_at IS NULL LIMIT 100');
        $stmt->execute([$filename]);
        $out = [];
        while ($stmt->fetch()) {
            $out[] = ['slotKey' => 'editorials_hub','slotLabel' => 'Editorials Hub','field' => 'image','path' => null,'itemId' => null,'itemTitle' => null,'hub' => true];
        }
        $stmt->closeCursor();
        return $out;
    }
}
