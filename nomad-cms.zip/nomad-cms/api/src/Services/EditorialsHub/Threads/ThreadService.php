<?php

/**
 * NOMAD CMS - Editorials Hub ThreadService.
 *
 * Multiple threads per card, author-only edits and reply-based expiration.
 * Backend-only PHP/SQLite module; resource budgets and authorization are enforced at service boundaries.
 *
 * @package NomadCMS\Services\EditorialsHub\Threads
 */

declare(strict_types=1);

namespace NomadCMS\Services\EditorialsHub\Threads;

use NomadCMS\Services\EditorialsHub\Access\HubAccessPolicy;
use NomadCMS\Services\EditorialsHub\HubException;
use NomadCMS\Services\EditorialsHub\Notifications\MentionEventService;
use NomadCMS\Services\EditorialsHub\Persistence\ItemRepository;
use NomadCMS\Services\EditorialsHub\Persistence\ThreadRepository;
use NomadCMS\Services\EditorialsHub\Persistence\SyncRepository;
use NomadCMS\Services\EditorialsHub\Support;

/** Multiple threads per card, author-only edits and reply-based expiration. */
final class ThreadService
{
    public function __construct(private ThreadRepository $repo, private HubAccessPolicy $access, private SyncRepository $sync, private MentionEventService $mentions)
    {
    }

    private function live(string $id): array
    {
        $thread = $this->repo->find($id);
        if (!$thread) {
            throw new HubException('not_found', 404);
        }
        $this->access->item($thread['item_id']);
        return $thread;
    }

    public function list(string $itemId, array $query): array
    {
        $this->access->item($itemId);
        $ctx = $this->access->context;
        $binding = ['actor' => $ctx->uuid,'item' => $itemId,'kind' => 'threads'];
        $after = empty($query['cursor']) ? 0 : (int)Support::decodeCursor($query['cursor'], $ctx->cursorSecret, $binding)['after'];
        $rows = $this->repo->all('SELECT t.*,a.thread_id AS annotation_id,a.reference_id FROM eh_threads t LEFT JOIN eh_annotations a ON a.thread_id=t.uuid WHERE t.item_id=? AND t.id>? AND t.deleted_at IS NULL AND (t.expires_at IS NULL OR t.expires_at>?) ORDER BY t.id LIMIT 101', [$itemId,$after,time()]);
        $more = count($rows) > 100;
        $rows = array_slice($rows, 0, 100);
        return Support::page($rows, ['has_more' => $more,'cursor' => $rows ? Support::cursor($binding + ['after' => (int)end($rows)['id']], $ctx->cursorSecret) : null]);
    }

    public function create(string $itemId, array $input, string $key): array
    {
        $item = $this->access->item($itemId);
        $ctx = $this->access->context;
        $this->access->require('comment', $ctx->uuid);
        return $this->repo->idempotent($ctx->uuid, 'thread.create:' . $itemId, $key, $input, function () use ($itemId, $input, $ctx): array {
            $item = $this->access->item($itemId);
            $this->access->require('comment', $ctx->uuid);
            $b = $this->repo->one('SELECT retention_seconds FROM eh_boards WHERE id=?', [$item['board_id']]);
            $uuid = Support::uuid();
            $now = time();
            $expiry = $b['retention_seconds'] === null ? null : $now + (int)$b['retention_seconds'];
            $this->repo->run('INSERT INTO eh_threads(uuid,item_id,board_id,owner_uuid,title,created_at,last_reply_at,expires_at) VALUES(?,?,?,?,?,?,?,?)', [$uuid,$itemId,$item['board_id'],$ctx->uuid,Support::text($input['title'] ?? '', 160),$now,$now,$expiry]);
            $this->repo->run('UPDATE eh_items SET thread_count=thread_count+1 WHERE uuid=?', [$itemId]);
            $this->changed($item, 'thread.created', $uuid, 1);
            return $this->repo->find($uuid);
        });
    }

    public function messages(string $threadId, array $query): array
    {
        $this->live($threadId);
        $ctx = $this->access->context;
        $binding = ['actor' => $ctx->uuid,'thread' => $threadId,'kind' => 'messages'];
        $after = empty($query['cursor']) ? 0 : (int)Support::decodeCursor($query['cursor'], $ctx->cursorSecret, $binding)['after'];
        $rows = $this->repo->withReferences($this->repo->all('SELECT * FROM eh_messages WHERE thread_id=? AND id>? AND deleted_at IS NULL ORDER BY id LIMIT 51', [$threadId,$after]));
        $more = count($rows) > 50;
        $result = [];
        $bytes = 0;
        foreach (array_slice($rows, 0, 50) as $row) {
            $length = strlen(Support::json($row));
            if ($bytes + $length > 250000) {
                $more = true;
                break;
            }
            $bytes += $length;
            $result[] = $row;
            $after = (int)$row['id'];
        }
        return Support::page($result, ['has_more' => $more,'cursor' => Support::cursor($binding + ['after' => $after], $ctx->cursorSecret)]);
    }

    public function reply(string $threadId, array $input, string $key): array
    {
        $this->live($threadId);
        $ctx = $this->access->context;
        $this->access->require('comment', $ctx->uuid);
        return $this->repo->idempotent($ctx->uuid, 'message.create:' . $threadId, $key, $input, function () use ($threadId, $input, $ctx): array {
            $thread = $this->live($threadId);
            $this->access->require('comment', $ctx->uuid);
            $body = Support::text($input['body'] ?? '', 4096);
            if (trim($body) === '') {
                throw new HubException('empty_message');
            }
            $references = $this->messageReferences($input['references'] ?? [], $thread['item_id']);
            $uuid = Support::uuid();
            $now = time();
            $this->repo->run('INSERT INTO eh_messages(uuid,thread_id,author_uuid,body,created_at,updated_at) VALUES(?,?,?,?,?,?)', [$uuid,$threadId,$ctx->uuid,$body,$now,$now]);
            $this->repo->replaceReferences($uuid, $references);
            $b = $this->repo->one('SELECT retention_seconds FROM eh_boards WHERE id=?', [$thread['board_id']]);
            $expiry = $b['retention_seconds'] === null ? null : $now + (int)$b['retention_seconds'];
            $this->repo->run('UPDATE eh_threads SET last_reply_at=?,expires_at=?,revision=revision+1 WHERE uuid=?', [$now,$expiry,$threadId]);
            $item = $this->access->item($thread['item_id']);
            $this->mentions->record($item, $references, 'message:' . $uuid);
            $this->changed($item, 'thread.reply', $threadId, (int)$thread['revision'] + 1);
            return $this->repo->message($uuid);
        });
    }

    public function editMessage(string $uuid, array $input): array
    {
        return Support::transaction($this->repo->db, function () use ($uuid, $input): array {
            $message = $this->repo->message($uuid);
            if (!$message) {
                throw new HubException('not_found', 404);
            }
            $thread = $this->live($message['thread_id']);
            $ctx = $this->access->context;
            if ($message['author_uuid'] !== $ctx->uuid) {
                throw new HubException('forbidden', 403);
            } $this->access->require('comment', $ctx->uuid);
            if ((int)($input['expected_revision'] ?? 0) !== (int)$message['revision']) {
                throw new HubException('version_conflict', 409);
            }
            $body = Support::text($input['body'] ?? '', 4096);
            if (trim($body) === '') {
                throw new HubException('empty_message');
            }
            $references = $this->messageReferences($input['references'] ?? $message['references'], $thread['item_id']);
            $this->repo->run('UPDATE eh_messages SET body=?,revision=revision+1,updated_at=? WHERE uuid=?', [$body,time(),$uuid]);
            $this->repo->replaceReferences($uuid, $references);
            $this->mentions->record($this->access->item($thread['item_id']), $references, 'message:' . $uuid);
            // Editing deliberately leaves thread.last_reply_at and expires_at unchanged.
            $this->changed($this->access->item($thread['item_id']), 'thread.message_updated', $thread['uuid'], (int)$message['revision'] + 1);
            return $this->repo->message($uuid);
        });
    }

    private function messageReferences(mixed $input, string $itemId): array
    {
        if (!is_array($input) || !array_is_list($input) || count($input) > 50) {
            throw new HubException('invalid_reference');
        }
        $references = [];
        foreach ($input as $id) {
            if (!is_string($id) || !$this->repo->one('SELECT 1 FROM eh_references WHERE id=? AND item_id=?', [$id, $itemId])) {
                throw new HubException('invalid_reference');
            }
            $references[$id] = $id;
        }

        return array_values($references);
    }

    public function deleteMessage(string $uuid, int $revision): void
    {
        Support::transaction($this->repo->db, function () use ($uuid, $revision): void {
            $message = $this->repo->message($uuid);
            if (!$message) {
                throw new HubException('not_found', 404);
            }
            $thread = $this->live($message['thread_id']);
            $item = $this->access->item($thread['item_id']);
            $b = $this->repo->one('SELECT * FROM eh_boards WHERE id=?', [$thread['board_id']]);
            if ($message['author_uuid'] === $this->access->context->uuid) {
                $this->access->require('comment', $message['author_uuid']);
            } else {
                $this->access->manage($b);
            }
            if ((int)$message['revision'] !== $revision) {
                throw new HubException('version_conflict', 409);
            }
            $this->repo->run('UPDATE eh_messages SET deleted_at=? WHERE uuid=?', [time(),$uuid]);
            $this->changed($item, 'thread.message_deleted', $thread['uuid'], $revision + 1);
        });
    }

    public function delete(string $uuid, int $revision): void
    {
        Support::transaction($this->repo->db, function () use ($uuid, $revision): void {
            $thread = $this->live($uuid);
            $item = $this->access->item($thread['item_id']);
            $b = $this->repo->one('SELECT * FROM eh_boards WHERE id=?', [$thread['board_id']]);
            if (!$this->access->granted('delete', $thread['owner_uuid'])) {
                $this->access->manage($b);
            }
            if ((int)$thread['revision'] !== $revision) {
                throw new HubException('version_conflict', 409);
            }
            $this->repo->run('UPDATE eh_threads SET deleted_at=? WHERE uuid=?', [time(),$uuid]);
            $this->repo->run('UPDATE eh_items SET thread_count=max(0,thread_count-1) WHERE uuid=?', [$thread['item_id']]);
            $this->changed($item, 'thread.deleted', $uuid, $revision + 1);
        });
    }

    private function changed(array $item, string $kind, string $id, int $revision): void
    {
        $g = ItemRepository::boundsOf($item);
        (new ItemRepository($this->repo->db))->touchTiles((int)$item['board_id'], $g, $g, $item['type'], $item['owner_uuid']);
        $this->sync->change((int)$item['board_id'], $kind, $id, $revision, ['item_id' => $item['uuid']], $g, $g);
    }
}
