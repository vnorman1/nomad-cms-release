<?php

/**
 * NOMAD CMS - Editorials Hub AnnotationService.
 *
 * Creates target-anchored comments and exposes their reverse CMS lookup.
 * Reuses thread replies/moderation/retention; visibility requires both Hub and
 * target permissions. Navigation is a backend location contract, not UI code.
 *
 * @package NomadCMS\Services\EditorialsHub\Annotations
 */

declare(strict_types=1);

namespace NomadCMS\Services\EditorialsHub\Annotations;

use NomadCMS\Services\EditorialsHub\Access\HubAccessPolicy;
use NomadCMS\Services\EditorialsHub\Contracts\TargetDescriptor;
use NomadCMS\Services\EditorialsHub\HubException;
use NomadCMS\Services\EditorialsHub\Persistence\AnnotationRepository;
use NomadCMS\Services\EditorialsHub\Persistence\ItemRepository;
use NomadCMS\Services\EditorialsHub\Persistence\SyncRepository;
use NomadCMS\Services\EditorialsHub\References\TargetRegistry;
use NomadCMS\Services\EditorialsHub\Support;
use NomadCMS\Services\EditorialsHub\Threads\ThreadService;

/** Target annotations with bounded reverse lookup and ordinary thread lifecycle. */
final class AnnotationService
{
    public function __construct(
        private AnnotationRepository $repo,
        private HubAccessPolicy $access,
        private TargetRegistry $targets,
        private ThreadService $threads,
        private SyncRepository $sync
    ) {
    }

    /** Add a comment without requiring CMS write or card-edit permission. */
    public function create(string $itemId, array $input, string $key): array
    {
        $item = $this->access->item($itemId);
        $this->access->require('comment', $this->access->context->uuid);
        $this->inputTarget($item, $input);
        $body = Support::text($input['body'] ?? '', 4096);
        if (trim($body) === '') {
            throw new HubException('empty_message');
        }

        $result = $this->repo->idempotent(
            $this->access->context->uuid,
            'annotation.create:' . $itemId,
            $key,
            $input,
            function () use ($itemId, $input, $body): array {
                $item = $this->access->item($itemId);
                $this->access->require('comment', $this->access->context->uuid);
                $target = $this->inputTarget($item, $input);
                $thread = $this->threads->create($itemId, ['title' => $input['title'] ?? ''], Support::uuid());
                $this->threads->reply($thread['uuid'], ['body' => $body, 'references' => $input['references'] ?? []], Support::uuid());
                $referenceId = $input['reference_id'] ?? null;
                if ($referenceId === null) {
                    $referenceId = Support::uuid();
                    $this->repo->run(
                        'INSERT INTO eh_references(id,board_id,item_id,actor_uuid,occurrence_id,target,created_at) VALUES(?,?,?,?,?,?,?)',
                        [$referenceId, $item['board_id'], $itemId, $this->access->context->uuid, 'annotation-' . $thread['uuid'], Support::json($target->toArray()), time()]
                    );
                }

                $this->repo->run(
                    'INSERT INTO eh_annotations(thread_id,reference_id,board_id,item_id,target_kind,target_slot,target_item,target_field,target_locale,target_path) VALUES(?,?,?,?,?,?,?,?,?,?)',
                    [$thread['uuid'], $referenceId, $item['board_id'], $itemId, $target->kind, $target->slot, $target->item ?? '', $target->field ?? '', $target->locale ?? '', Support::json($target->path)]
                );
                $bounds = ItemRepository::boundsOf($item);
                $this->sync->change((int) $item['board_id'], 'thread.annotation_created', $thread['uuid'], 2, ['item_id' => $itemId, 'reference_id' => $referenceId], $bounds, $bounds);
                return ['thread_id' => $thread['uuid']];
            }
        );

        // Replay returns current state and checks access/expiry again, not a cached body.
        return $this->get($result['thread_id']);
    }

    private function inputTarget(array $item, array $input): TargetDescriptor
    {
        if (isset($input['reference_id'])) {
            if (isset($input['target'])) {
                throw new HubException('ambiguous_target');
            }
            $reference = $this->repo->one('SELECT target FROM eh_references WHERE id=? AND item_id=? AND board_id=?', [$input['reference_id'], $item['uuid'], $item['board_id']]);
            if (!$reference) {
                throw new HubException('target_unavailable', 404);
            }
            $descriptor = TargetDescriptor::fromArray(json_decode($reference['target'], true, 32, JSON_THROW_ON_ERROR));
        } else {
            $descriptor = TargetDescriptor::fromArray($input['target'] ?? []);
        }

        $board = $this->repo->one('SELECT uuid FROM eh_boards WHERE id=?', [$item['board_id']]);
        $target = $this->canonical($descriptor);
        $this->targets->resolve($target, $board['uuid']);
        return $target;
    }

    private function canonical(TargetDescriptor $target): TargetDescriptor
    {
        if ($target->kind === 'user' || $target->item === 'new' || ($target->field === null && ($target->locale !== null || $target->path !== []))) {
            throw new HubException('invalid_annotation_target');
        }
        $slot = $target->slot;
        $item = $target->item;
        if ($target->kind === 'slot') {
            $definition = $this->targets->slots->definition($slot);
            $type = $definition['type'] ?? 'object';
            if (($type === 'object' && $item !== null) || ($type !== 'object' && $item === null && $target->field !== null)) {
                throw new HubException('invalid_annotation_target');
            }
            if ($type === 'massive' && $item !== null && ctype_digit($item)) {
                $item = (string) (int) $item;
            }
        } elseif ($target->kind === 'media') {
            $slot = '';
        } elseif (in_array($slot, ['napló', 'naplo'], true)) {
            $slot = 'logs';
        }

        return new TargetDescriptor($target->kind, $slot, $item, $target->field, $target->locale, $target->path);
    }

    /** Reopen a comment; a lost CMS permission redacts its target on the Hub. */
    public function get(string $threadId): array
    {
        $row = $this->repo->find($threadId);
        if (!$row) {
            throw new HubException('not_found', 404);
        }
        $this->access->item($row['item_id']);
        return $this->present($row);
    }

    public function forItem(string $itemId, array $query): array
    {
        $item = $this->access->item($itemId);
        $board = $this->repo->one('SELECT access_revision FROM eh_boards WHERE id=?', [$item['board_id']]);
        return $this->page('a.item_id=?', [$itemId], ['kind' => 'annotations.item', 'item' => $itemId, 'access' => (int) $board['access_revision']], $query, false);
    }

    public function forBoard(string $boardId, array $query): array
    {
        $board = $this->access->board($boardId);
        return $this->page('a.board_id=?', [$board['id']], ['kind' => 'annotations.board', 'board' => $boardId, 'access' => (int) $board['access_revision']], $query, false);
    }

    /** Called from a CMS item/field modal; no board identifier is required. */
    public function forTarget(array $input): array
    {
        $context = $this->access->context;
        if (!$context->has('editorials:read:*') && !$context->has('editorials:read:own')) {
            throw new HubException('forbidden', 403);
        }
        $target = $this->canonical(TargetDescriptor::fromArray($input['target'] ?? []));
        $this->targets->resolveContentTarget($target);
        $scope = $input['scope'] ?? 'item';
        if (!in_array($scope, ['item', 'exact'], true)) {
            throw new HubException('invalid_annotation_scope');
        }
        $where = 'a.target_kind=? AND a.target_slot=? AND a.target_item=?';
        $params = [$target->kind, $target->slot, $target->item ?? ''];
        if ($scope === 'exact') {
            $where .= ' AND a.target_field=? AND a.target_locale=? AND a.target_path=?';
            array_push($params, $target->field ?? '', $target->locale ?? '', Support::json($target->path));
        }

        return $this->page($where, $params, ['kind' => 'annotations.target', 'query' => hash('sha256', Support::json([$target->toArray(), $scope]))], $input, true);
    }

    private function page(string $where, array $params, array $binding, array $query, bool $requireTarget): array
    {
        $context = $this->access->context;
        $binding['actor'] = $context->uuid;
        $binding['read_scope'] = $context->has('editorials:read:*') ? '*' : 'own';
        $after = empty($query['cursor']) ? 0 : (int) Support::decodeCursor($query['cursor'], $context->cursorSecret, $binding)['after'];
        $limit = max(1, min(50, (int) ($query['limit'] ?? 20)));
        if (!$context->superAdmin) {
            $where .= " AND (b.visibility='shared' OR b.owner_uuid=? OR EXISTS(SELECT 1 FROM eh_board_members bm WHERE bm.board_id=b.id AND bm.user_uuid=?))";
            array_push($params, $context->uuid, $context->uuid);
        }
        if (!$context->has('editorials:read:*')) {
            $where .= ' AND b.owner_uuid=? AND i.owner_uuid=?';
            array_push($params, $context->uuid, $context->uuid);
        }
        if ($requireTarget) {
            $where .= ' AND EXISTS(SELECT 1 FROM eh_messages m WHERE m.thread_id=a.thread_id AND m.deleted_at IS NULL)';
        }
        array_push($params, time(), $after);
        $rows = $this->repo->all(AnnotationRepository::SELECT . ' WHERE ' . $where . ' AND ' . AnnotationRepository::LIVE . ' AND a.id>? ORDER BY a.id LIMIT 201', $params);
        $result = [];
        $bytes = 0;
        $more = false;
        foreach ($rows as $index => $row) {
            if ($index >= 200 || count($result) >= $limit) {
                $more = true;
                break;
            }
            try {
                $this->access->item($row['item_id']);
                $annotation = $this->present($row);
            } catch (HubException $error) {
                if (!in_array($error->status, [403, 404], true)) {
                    throw $error;
                }
                $after = (int) $row['id'];
                continue;
            }
            if ($requireTarget && !$annotation['target']['available']) {
                $after = (int) $row['id'];
                continue;
            }
            $length = strlen(Support::json($annotation));
            if ($bytes + $length > 245760) {
                $more = true;
                break;
            }
            $result[] = $annotation;
            $bytes += $length;
            $after = (int) $row['id'];
        }

        return Support::page($result, [
            'has_annotations' => $result !== [] ? true : ($more ? null : false),
            'has_more' => $more,
            'cursor' => Support::cursor($binding + ['after' => $after], $context->cursorSecret),
        ]);
    }

    private function present(array $row): array
    {
        $descriptor = new TargetDescriptor($row['target_kind'], $row['target_slot'], $row['target_item'] === '' ? null : $row['target_item'], $row['target_field'] === '' ? null : $row['target_field'], $row['target_locale'] === '' ? null : $row['target_locale'], json_decode($row['target_path'], true, 32, JSON_THROW_ON_ERROR));
        try {
            $target = $this->targets->resolve($descriptor, $row['board_uuid']);
            unset($target['value'], $target['value_truncated']);
        } catch (HubException $error) {
            if (!in_array($error->status, [403, 404], true) && $error->errorCode !== 'invalid_locale') {
                throw $error;
            }
            $target = ['available' => false, 'writable' => false, 'navigation' => null];
        }

        return [
            'id' => $row['thread_id'],
            'thread_id' => $row['thread_id'],
            'reference_id' => $row['reference_id'],
            'revision' => (int) $row['thread_revision'],
            'title' => $row['thread_title'],
            'created_at' => (int) $row['created_at'],
            'last_reply_at' => (int) $row['last_reply_at'],
            'expires_at' => $row['expires_at'] === null ? null : (int) $row['expires_at'],
            'message' => $this->repo->firstMessage($row['thread_id']),
            'target' => $target,
            'hub_location' => [
                'board_id' => $row['board_uuid'],
                'board_title' => $row['board_title'],
                'item_id' => $row['item_id'],
                'item_title' => $row['item_title'],
                'thread_id' => $row['thread_id'],
                'reference_id' => $row['reference_id'],
                'focus' => ['x' => (float) $row['x'], 'y' => (float) $row['y'], 'width' => (float) $row['width'], 'height' => (float) $row['height']],
            ],
        ];
    }
}
