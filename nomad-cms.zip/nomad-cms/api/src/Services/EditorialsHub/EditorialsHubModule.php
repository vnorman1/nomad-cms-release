<?php

/**
 * NOMAD CMS - Editorials Hub EditorialsHubModule.
 *
 * Composition root. Hot reads open only massive/system storage and perform no schema work.
 * Backend-only PHP/SQLite module; resource budgets and authorization are enforced at service boundaries.
 *
 * @package NomadCMS\Services\EditorialsHub
 */

declare(strict_types=1);

namespace NomadCMS\Services\EditorialsHub;

use NomadCMS\Database\AuthDatabase;
use NomadCMS\Database\ContentDatabase;
use NomadCMS\Database\MassiveDatabase;
use NomadCMS\Services\EditorialsHub\Access\HubAccessPolicy;
use NomadCMS\Services\EditorialsHub\Contracts\HubRequestContext;
use NomadCMS\Services\EditorialsHub\Persistence\BoardRepository;
use NomadCMS\Services\EditorialsHub\Persistence\ItemRepository;
use NomadCMS\Services\EditorialsHub\Persistence\SyncRepository;
use NomadCMS\Services\EditorialsHub\Persistence\ReferenceRepository;
use NomadCMS\Services\EditorialsHub\Persistence\ThreadRepository;
use NomadCMS\Services\EditorialsHub\Persistence\TransferRepository;
use NomadCMS\Services\EditorialsHub\References\TargetRegistry;
use NomadCMS\Services\EditorialsHub\References\UserDirectoryService;
use NomadCMS\Services\EditorialsHub\References\Adapters\SlotTargetAdapter;
use NomadCMS\Services\EditorialsHub\References\Adapters\MediaTargetAdapter;
use NomadCMS\Services\EditorialsHub\References\Adapters\ModuleTargetAdapter;
use NomadCMS\Services\EditorialsHub\Media\ProtectedAttachmentStorage;
use PDO;

/** Composition root. Hot reads open only massive/system storage and perform no schema work. */
final class EditorialsHubModule
{
    public readonly HubAccessPolicy $access;
    private ?TargetRegistry $targets = null;
    private ?UserDirectoryService $directory = null;
    public readonly ProtectedAttachmentStorage $storage;

    public function __construct(public readonly PDO $db, public readonly HubRequestContext $context, private ?PDO $auth = null, private ?PDO $content = null, private ?array $schema = null, ?ProtectedAttachmentStorage $storage = null)
    {
        $this->access = new HubAccessPolicy($context, new BoardRepository($db), new ItemRepository($db));
        $this->storage = $storage ?? new ProtectedAttachmentStorage();
    }

    public static function installed(PDO $db): bool
    {
        $exists = $db->query("SELECT 1 FROM sqlite_master WHERE type='table' AND name='eh_migrations'")->fetchColumn();
        return $exists && (bool)$db->query('SELECT 1 FROM eh_migrations WHERE version=7')->fetchColumn();
    }

    /** Create current tables directly for a fresh installation. */
    public static function install(?PDO $hub = null, ?PDO $auth = null, ?PDO $content = null, bool $rtree = true, ?ProtectedAttachmentStorage $storage = null): void
    {
        Schema::install(
            $hub ?? MassiveDatabase::getInstance(),
            $auth ?? AuthDatabase::getInstance(),
            $content ?? ContentDatabase::getInstance(),
            $rtree
        );
        ($storage ?? new ProtectedAttachmentStorage())->initialize();
        \NomadCMS\Services\RBACService::resetCache();
    }

    /** Explicit install/update only; tests may inject all databases and private storage. */
    public static function migrate(?PDO $hub = null, ?PDO $auth = null, ?PDO $content = null, bool $rtree = true, ?ProtectedAttachmentStorage $storage = null): void
    {
        $hub ??= MassiveDatabase::getInstance();
        $auth ??= AuthDatabase::getInstance();
        $content ??= ContentDatabase::getInstance();
        $migration = require __DIR__ . '/Migrations/001InitialSchema.php';
        $migration($hub, $rtree);
        $annotations = require __DIR__ . '/Migrations/004TargetAnnotations.php';
        $annotations($hub);
        $frontend = require __DIR__ . '/Migrations/005FrontendSupport.php';
        $frontend($hub);
        $notifications = require __DIR__ . '/Migrations/006MentionNotifications.php';
        $notifications($hub);
        $canvasDrafts = require __DIR__ . '/Migrations/007CanvasDrafts.php';
        $canvasDrafts($hub);
        $receipts = require __DIR__ . '/Migrations/003DestinationReceipts.php';
        $receipts($content);
        $receipts($hub);
        $grants = require __DIR__ . '/Migrations/002HubPermissionBaseline.php';
        $grants($auth);
        ($storage ?? new ProtectedAttachmentStorage())->initialize();
        \NomadCMS\Services\RBACService::resetCache();
    }

    public function users(): UserDirectoryService
    {
        return $this->directory ??= new UserDirectoryService($this->auth ??= AuthDatabase::getInstance(false), $this->db, $this->access);
    }

    public function targets(): TargetRegistry
    {
        if ($this->targets === null) {
            $this->content ??= ContentDatabase::getInstance(false);
            $this->schema ??= TargetRegistry::schema($this->content);
            $slots = new SlotTargetAdapter($this->content, $this->db, $this->context, $this->schema);
            $media = new MediaTargetAdapter($this->content, $this->context);
            $this->targets = new TargetRegistry($slots, $media, new ModuleTargetAdapter($this->context), $this->users(), $this->access, $this->db);
        }
        return $this->targets;
    }

    public function boards(): Boards\BoardService
    {
        return new Boards\BoardService(new BoardRepository($this->db), $this->access, new SyncRepository($this->db), fn($id)=>$this->users()->eligible($id));
    }
    public function items(): Items\ItemService
    {
        return new Items\ItemService(new ItemRepository($this->db), $this->access, new SyncRepository($this->db), fn($id)=>$this->users()->eligible($id), function ($name): bool {
            try {
                $this->targets()->media->record($name);
                return true;
            } catch (HubException $e) {
                return false;
            }
        }, function (array $item, string $slot): void {
            $this->references()->proposal([
                'item_id' => $item['uuid'],
                'target' => ['kind' => 'slot', 'slot' => $slot, 'item' => 'new'],
                'values' => [],
            ], 'canvas_draft_' . $item['uuid'], 'canvas_draft');
        });
    }
    public function viewport(): Items\ViewportService
    {
        return new Items\ViewportService(new ItemRepository($this->db), $this->access);
    }
    public function tickets(): Items\TicketQueryService
    {
        return new Items\TicketQueryService(new ItemRepository($this->db), $this->access);
    }
    public function connectors(): Items\ConnectorService
    {
        return new Items\ConnectorService(new ItemRepository($this->db), $this->access, new SyncRepository($this->db));
    }
    public function changes(): Sync\ChangeFeedService
    {
        return new Sync\ChangeFeedService(new SyncRepository($this->db), $this->access);
    }
    public function notes(): Sync\NoteSyncService
    {
        return new Sync\NoteSyncService(new SyncRepository($this->db), $this->access);
    }
    public function mentions(): Notifications\MentionEventService
    {
        return new Notifications\MentionEventService(new ReferenceRepository($this->db), $this->access, fn($id)=>$this->users()->eligible($id));
    }
    public function projections(): Sync\NoteProjectionService
    {
        return new Sync\NoteProjectionService(new SyncRepository($this->db), $this->access, $this->mentions());
    }
    public function threads(): Threads\ThreadService
    {
        return new Threads\ThreadService(new ThreadRepository($this->db), $this->access, new SyncRepository($this->db), $this->mentions());
    }
    public function references(): References\ReferenceService
    {
        return new References\ReferenceService(new ReferenceRepository($this->db), $this->access, $this->targets());
    }
    public function annotations(): Annotations\AnnotationService
    {
        return new Annotations\AnnotationService(new Persistence\AnnotationRepository($this->db), $this->access, $this->targets(), $this->threads(), new SyncRepository($this->db));
    }
    public function attachments(): Media\AttachmentService
    {
        return new Media\AttachmentService(new BoardRepository($this->db), $this->access, $this->storage);
    }

    public function transfers(?\Closure $failpoint = null): Integration\TransferService
    {
        $targets = $this->targets();
        return new Integration\TransferService(new TransferRepository($this->db), $this->access, $targets, [
            'object_list' => new Integration\Writers\ObjectListWriter($this->content, $this->context),
            'collection' => new Integration\Writers\CollectionWriter($this->content),
            'massive' => new Integration\Writers\MassiveWriter($this->db, $this->context, $targets->slots),
            'media' => new Integration\Writers\MediaMetadataWriter($this->content, $targets->media),
        ], $this->storage, $failpoint);
    }
}
