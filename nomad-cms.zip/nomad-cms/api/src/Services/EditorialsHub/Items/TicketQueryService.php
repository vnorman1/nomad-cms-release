<?php

/**
 * NOMAD CMS - Editorials Hub TicketQueryService.
 *
 * Cursor-paginated tickets; callers independently paginate each Kanban status.
 * Backend-only PHP/SQLite module; resource budgets and authorization are enforced at service boundaries.
 *
 * @package NomadCMS\Services\EditorialsHub\Items
 */

declare(strict_types=1);

namespace NomadCMS\Services\EditorialsHub\Items;

use NomadCMS\Services\EditorialsHub\Access\HubAccessPolicy;
use NomadCMS\Services\EditorialsHub\Persistence\ItemRepository;
use NomadCMS\Services\EditorialsHub\Support;

/** Cursor-paginated tickets; callers independently paginate each Kanban status. */
final class TicketQueryService
{
    public function __construct(private ItemRepository $repo, private HubAccessPolicy $access)
    {
    }
    public function read(string $uuid, array $query): array
    {
        $b = $this->access->board($uuid);
        $ctx = $this->access->context;
        $status = $query['status_id'] ?? null;
        $assignee = $query['assignee_uuid'] ?? null;
        $binding = ['actor' => $ctx->uuid,'board' => $uuid,'access' => (int)$b['access_revision'],'kind' => 'tickets','order' => 'rank-v1','filter' => hash('sha256', Support::json([$status,$assignee]))];
        $cursor = empty($query['cursor']) ? null : Support::decodeCursor($query['cursor'], $ctx->cursorSecret, $binding);
        $highWater = (int)($cursor['high_water'] ?? $b['change_sequence']);
        $sql = 'SELECT ' . ItemRepository::LIGHT . ' FROM eh_items i WHERE i.board_id=? AND i.deleted_at IS NULL';
        $params = [$b['id']];
        if ($cursor !== null) {
            $afterOrder = (int)($cursor['after_order'] ?? 0);
            $afterId = (int)($cursor['after'] ?? 0);
            $sql .= ' AND (i.ticket_order,i.id)>(?,?)';
            array_push($params, $afterOrder, $afterId);
        }
        if (!$ctx->has('editorials:read:*')) {
            $sql .= ' AND i.owner_uuid=?';
            $params[] = $ctx->uuid;
        }
        if ($status !== null) {
            $sql .= ' AND i.status_id=?';
            $params[] = $status;
        }
        if ($assignee !== null) {
            $sql .= ' AND i.assignee_uuid=?';
            $params[] = $assignee;
        }
        $rows = $this->repo->all($sql . ' ORDER BY i.ticket_order,i.id LIMIT 101', $params);
        $more = count($rows) > 100;
        $rows = $this->repo->withCanvasDrafts(array_slice($rows, 0, 100));
        $last = $rows ? end($rows) : null;
        return Support::page($rows, ['has_more' => $more,'cursor' => $last ? Support::cursor($binding + ['after' => (int)$last['id'],'after_order' => (int)$last['ticket_order'],'high_water' => $highWater], $ctx->cursorSecret) : null,'high_water' => $highWater]);
    }
}
