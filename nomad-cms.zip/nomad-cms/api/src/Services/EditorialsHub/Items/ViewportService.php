<?php

/**
 * NOMAD CMS - Editorials Hub ViewportService.
 *
 * Viewport-only hydration; distant zoom returns hierarchical cell summaries.
 * Backend-only PHP/SQLite module; resource budgets and authorization are enforced at service boundaries.
 *
 * @package NomadCMS\Services\EditorialsHub\Items
 */

declare(strict_types=1);

namespace NomadCMS\Services\EditorialsHub\Items;

use NomadCMS\Services\EditorialsHub\Access\HubAccessPolicy;
use NomadCMS\Services\EditorialsHub\HubConfig;
use NomadCMS\Services\EditorialsHub\Persistence\ItemRepository;
use NomadCMS\Services\EditorialsHub\Support;

/** Viewport-only hydration; distant zoom returns hierarchical cell summaries. */
final class ViewportService
{
    /** Tile-cache coarsening must not replace usable cards at working zooms. */
    public const SUMMARY_ZOOM_THRESHOLD = 0.1;

    public function __construct(private ItemRepository $repo, private HubAccessPolicy $access)
    {
    }

    public function read(string $uuid, array $query): array
    {
        $board = $this->access->board($uuid);
        $ctx = $this->access->context;
        $bounds = Support::bounds($query, true);
        $level = 0;
        while ($level < HubConfig::TILE_LEVELS - 1) {
            $size = HubConfig::TILE_SIZE * (2 ** $level);
            $count = ((int)floor($bounds['max_x'] / $size) - (int)floor($bounds['min_x'] / $size) + 1) * ((int)floor($bounds['max_y'] / $size) - (int)floor($bounds['min_y'] / $size) + 1);
            if ($count <= 64) {
                break;
            } $level++;
        }
        $cells = ItemRepository::cells($bounds, $level);
        $size = HubConfig::TILE_SIZE * (2 ** $level);
        $scope = $ctx->has('editorials:read:*') ? '' : $ctx->uuid;
        $tiles = $this->repo->all('SELECT tile_x,tile_y,revision,item_count,note_count,image_count FROM eh_tiles WHERE board_id=? AND level=? AND owner_uuid=? AND tile_x BETWEEN ? AND ? AND tile_y BETWEEN ? AND ? ORDER BY tile_x,tile_y', [$board['id'],$level,$scope,(int)floor($bounds['min_x'] / $size),(int)floor($bounds['max_x'] / $size),(int)floor($bounds['min_y'] / $size),(int)floor($bounds['max_y'] / $size)]);
        $zoom = isset($query['zoom']) ? Support::finite($query['zoom']) : 1;
        if ($zoom <= 0) {
            throw new \NomadCMS\Services\EditorialsHub\HubException('invalid_zoom');
        }
        // Tile level limits aggregate/cache work to 64 cells. It is independent
        // of representation: large displays still hydrate bounded item pages.
        $summary = $zoom < self::SUMMARY_ZOOM_THRESHOLD;
        $binding = ['actor' => $ctx->uuid,'board' => $uuid,'access' => (int)$board['access_revision'],'scope' => $scope,'query' => hash('sha256', Support::json([$bounds,$level,$summary]))];
        $after = 0;
        $head = (int)$board['change_sequence'];
        if (!empty($query['cursor'])) {
            $c = Support::decodeCursor($query['cursor'], $ctx->cursorSecret, $binding);
            $after = (int)$c['after'];
            $head = (int)$c['head'];
        }
        $meta = ['bounds' => $bounds,'level' => $level,'high_water' => $head,'spatial_mode' => $this->repo->rtree() ? 'rtree' : 'btree','has_more' => false,'cursor' => null];
        $connectors = [];
        if ($summary) {
            $result = Support::page(['mode' => 'summary','cells' => $tiles], $meta);
        } else {
            $rows = $this->repo->spatial((int)$board['id'], $bounds, $after, 101, $ctx->has('editorials:read:*') ? null : $ctx->uuid);
            $more = count($rows) > 100;
            $rows = array_slice($rows, 0, 100);
            $accepted = [];
            $bytes = 0;
            foreach ($rows as $row) {
                unset($row['board_id']);
                $row['thumbnail_url'] = $row['attachment_id'] ? '/api/admin/editorials/attachments/' . $row['attachment_id'] . '/content?thumbnail=1' : null;
                $length = strlen(Support::json($row));
                if ($bytes + $length > HubConfig::RESPONSE_BYTES - 16384) {
                    $more = true;
                    break;
                }
                $bytes += $length;
                $accepted[] = $row;
                $after = (int)$row['id'];
            }
            $meta['has_more'] = $more;
            $meta['cursor'] = Support::cursor($binding + ['after' => $after,'head' => $head], $ctx->cursorSecret);
            $connectors = (new ConnectorService($this->repo, $this->access, new \NomadCMS\Services\EditorialsHub\Persistence\SyncRepository($this->repo->db)))->visible((int)$board['id'], $bounds);
            $result = Support::page(['mode' => 'items','items' => $accepted,'connectors' => $connectors], $meta);
        }
        // Offscreen changes do not affect this ETag; membership and query do.
        $result['meta']['etag'] = '"' . hash('sha256', Support::json([$binding,$tiles,$after,$connectors])) . '"';
        return $result;
    }
}
