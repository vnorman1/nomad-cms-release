<?php

/**
 * NOMAD CMS - Editorials Hub ConnectorService.
 *
 * Bounded card links; line bounds remain visible with both endpoint cards offscreen.
 * Backend-only PHP/SQLite module; resource budgets and authorization are enforced at service boundaries.
 *
 * @package NomadCMS\Services\EditorialsHub\Items
 */

declare(strict_types=1);

namespace NomadCMS\Services\EditorialsHub\Items;

use NomadCMS\Services\EditorialsHub\Access\HubAccessPolicy;
use NomadCMS\Services\EditorialsHub\HubException;
use NomadCMS\Services\EditorialsHub\Persistence\ItemRepository;
use NomadCMS\Services\EditorialsHub\Persistence\SyncRepository;
use NomadCMS\Services\EditorialsHub\Support;

/** Bounded card links; line bounds remain visible with both endpoint cards offscreen. */
final class ConnectorService
{
    public function __construct(private ItemRepository $repo, private HubAccessPolicy $access, private SyncRepository $sync)
    {
    }

    private function geometry(array $a, array $b): array
    {
        $ax = (float)$a['x'] + (float)$a['width'] / 2;
        $ay = (float)$a['y'] + (float)$a['height'] / 2;
        $bx = (float)$b['x'] + (float)$b['width'] / 2;
        $by = (float)$b['y'] + (float)$b['height'] / 2;
        return ['from_x' => $ax,'from_y' => $ay,'to_x' => $bx,'to_y' => $by,'min_x' => min($ax, $bx),'max_x' => max($ax, $bx),'min_y' => min($ay, $by),'max_y' => max($ay, $by)];
    }

    public function create(string $boardUuid, array $input, string $key): array
    {
        $b = $this->access->board($boardUuid);
        $ctx = $this->access->context;
        $this->access->require('create', $ctx->uuid);
        return $this->repo->idempotent($ctx->uuid, 'connector.create:' . $boardUuid, $key, $input, function () use ($boardUuid, $input, $ctx): array {
            $b = $this->access->board($boardUuid);
            $a = $this->access->item((string)($input['from_item'] ?? ''));
            $c = $this->access->item((string)($input['to_item'] ?? ''));
            if ($a['uuid'] === $c['uuid'] || (int)$a['board_id'] !== (int)$b['id'] || (int)$c['board_id'] !== (int)$b['id']) {
                throw new HubException('invalid_connector');
            }
            foreach ([$a['uuid'],$c['uuid']] as $id) {
                $n = $this->repo->one('SELECT COUNT(*) AS n FROM eh_connectors WHERE (from_item=? OR to_item=?) AND deleted_at IS NULL', [$id,$id]);
                if ((int)$n['n'] >= 100) {
                    throw new HubException('connector_limit');
                }
            }
            $g = $this->geometry($a, $c);
            $uuid = Support::uuid();
            $this->repo->run('INSERT INTO eh_connectors(uuid,board_id,owner_uuid,from_item,to_item,from_x,from_y,to_x,to_y,min_x,max_x,min_y,max_y,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)', [$uuid,$b['id'],$ctx->uuid,$a['uuid'],$c['uuid'],$g['from_x'],$g['from_y'],$g['to_x'],$g['to_y'],$g['min_x'],$g['max_x'],$g['min_y'],$g['max_y'],time()]);
            $this->sync->change((int)$b['id'], 'connector.created', $uuid, 1, [], null, $g);
            // A line can span billions of units. Never enumerate its base tiles.
            return $this->repo->one('SELECT * FROM eh_connectors WHERE uuid=?', [$uuid]);
        });
    }

    public function visible(int $board, array $b): array
    {
        $rtree = $this->repo->rtree();
        $join = $rtree ? ' JOIN eh_connector_bounds r ON r.id=c.id' : '';
        $extra = $rtree ? ' AND r.min_board<=? AND r.max_board>=? AND r.min_x<=? AND r.max_x>=? AND r.min_y<=? AND r.max_y>=?' : '';
        $params = [$board];
        if ($rtree) {
            array_push($params, $board, $board, $b['max_x'], $b['min_x'], $b['max_y'], $b['min_y']);
        }
        array_push($params, $b['max_x'], $b['min_x'], $b['max_y'], $b['min_y']);
        $owner = '';
        if (!$this->access->context->has('editorials:read:*')) {
            $owner = ' AND c.owner_uuid=? AND EXISTS(SELECT 1 FROM eh_items a WHERE a.uuid=c.from_item AND a.owner_uuid=?) AND EXISTS(SELECT 1 FROM eh_items z WHERE z.uuid=c.to_item AND z.owner_uuid=?)';
            array_push($params, $this->access->context->uuid, $this->access->context->uuid, $this->access->context->uuid);
        }
        return $this->repo->all('SELECT c.uuid,c.from_item,c.to_item,c.from_x,c.from_y,c.to_x,c.to_y,c.min_x,c.max_x,c.min_y,c.max_y,c.revision FROM eh_connectors c' . $join . ' WHERE c.board_id=? AND c.deleted_at IS NULL' . $extra . ' AND c.min_x<=? AND c.max_x>=? AND c.min_y<=? AND c.max_y>=?' . $owner . ' ORDER BY c.id LIMIT 100', $params);
    }

    public function refreshForItem(string $uuid): void
    {
        $edges = $this->repo->all('SELECT * FROM eh_connectors WHERE (from_item=? OR to_item=?) AND deleted_at IS NULL LIMIT 200', [$uuid,$uuid]);
        foreach ($edges as $e) {
            $a = $this->repo->find($e['from_item']);
            $b = $this->repo->find($e['to_item']);
            if (!$a || !$b) {
                continue;
            }
            $g = $this->geometry($a, $b);
            $old = ItemRepository::boundsOf($e);
            $this->repo->run('UPDATE eh_connectors SET from_x=?,from_y=?,to_x=?,to_y=?,min_x=?,max_x=?,min_y=?,max_y=?,revision=revision+1 WHERE id=?', [$g['from_x'],$g['from_y'],$g['to_x'],$g['to_y'],$g['min_x'],$g['max_x'],$g['min_y'],$g['max_y'],$e['id']]);
            $this->sync->change((int)$e['board_id'], 'connector.updated', $e['uuid'], (int)$e['revision'] + 1, [], $old, $g);
        }
    }

    public function delete(string $boardUuid, string $uuid, int $revision): void
    {
        $b = $this->access->board($boardUuid);
        Support::transaction($this->repo->db, function () use ($b, $uuid, $revision): void {
            $e = $this->repo->one('SELECT * FROM eh_connectors WHERE uuid=? AND board_id=? AND deleted_at IS NULL', [$uuid,$b['id']]);
            if (!$e) {
                throw new HubException('not_found', 404);
            } $this->access->require('delete', $e['owner_uuid']);
            if ((int)$e['revision'] !== $revision) {
                throw new HubException('version_conflict', 409);
            }
            $this->repo->run('UPDATE eh_connectors SET deleted_at=? WHERE id=?', [time(),$e['id']]);
            $g = ItemRepository::boundsOf($e);
            $this->sync->change((int)$b['id'], 'connector.deleted', $uuid, $revision + 1, [], $g, null);
        });
    }
}
