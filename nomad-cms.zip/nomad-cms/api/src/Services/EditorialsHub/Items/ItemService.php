<?php

/**
 * NOMAD CMS - Editorials Hub ItemService.
 *
 * Card lifecycle; geometry and metadata use independent optimistic revisions.
 * Backend-only PHP/SQLite module; resource budgets and authorization are enforced at service boundaries.
 *
 * @package NomadCMS\Services\EditorialsHub\Items
 */

declare(strict_types=1);

namespace NomadCMS\Services\EditorialsHub\Items;

use NomadCMS\Services\EditorialsHub\Access\HubAccessPolicy;
use NomadCMS\Services\EditorialsHub\HubException;
use NomadCMS\Services\EditorialsHub\Persistence\ItemRepository;
use NomadCMS\Services\EditorialsHub\Persistence\SyncRepository;
use NomadCMS\Services\EditorialsHub\Support;

/** Card lifecycle; geometry and metadata use independent optimistic revisions. */
final class ItemService
{
    public function __construct(private ItemRepository $repo, private HubAccessPolicy $access, private SyncRepository $sync, private ?\Closure $eligibleUser = null, private ?\Closure $mediaAccess = null, private ?\Closure $canvasDraft = null)
    {
    }

    private function metadata(array $input, array $board, array $old = []): array
    {
        $title = Support::text($input['title'] ?? $old['title'] ?? '', 160);
        $status = $input['status_id'] ?? $old['status_id'] ?? $this->repo->one('SELECT id FROM eh_board_statuses WHERE board_id=? ORDER BY position,id LIMIT 1', [$board['id']])['id'];
        if (!$this->repo->one('SELECT 1 FROM eh_board_statuses WHERE id=? AND board_id=?', [$status,$board['id']])) {
            throw new HubException('invalid_status');
        }
        $assignee = array_key_exists('assignee_uuid', $input) ? $input['assignee_uuid'] : ($old['assignee_uuid'] ?? null);
        if ($assignee !== null) {
            if (!is_string($assignee) || $this->eligibleUser === null || !($this->eligibleUser)($assignee)) {
                throw new HubException('ineligible_user');
            }
            if ($board['visibility'] === 'private' && $assignee !== $board['owner_uuid'] && !$this->repo->one('SELECT 1 FROM eh_board_members WHERE board_id=? AND user_uuid=?', [$board['id'],$assignee])) {
                throw new HubException('ineligible_user');
            }
        }
        $priority = $input['priority'] ?? $old['priority'] ?? 'normal';
        $due = array_key_exists('due_at', $input) ? $input['due_at'] : ($old['due_at'] ?? null);
        if (!in_array($priority, ['low','normal','high','urgent'], true) || ($due !== null && (!is_int($due) || $due < 0))) {
            throw new HubException('invalid_metadata');
        }
        return [$title,$status,$assignee,$priority,$due];
    }

    private function geometry(array $input, array $old = []): array
    {
        $x = Support::finite($input['x'] ?? $old['x'] ?? 0);
        $y = Support::finite($input['y'] ?? $old['y'] ?? 0);
        $w = Support::finite($input['width'] ?? $old['width'] ?? 320);
        $h = Support::finite($input['height'] ?? $old['height'] ?? 240);
        if ($w < 16 || $h < 16 || $w > 4096 || $h > 4096) {
            throw new HubException('invalid_dimensions');
        }
        return [$x,$y,$w,$h];
    }

    public function create(string $boardUuid, array $input, string $key): array
    {
        $b = $this->access->board($boardUuid);
        $ctx = $this->access->context;
        $this->access->require('create', $ctx->uuid);
        return $this->repo->idempotent($ctx->uuid, 'item.create:' . $boardUuid, $key, $input, function () use ($boardUuid, $input, $ctx): array {
            $b = $this->access->board($boardUuid);
            $this->access->require('create', $ctx->uuid);
            $type = $input['type'] ?? 'note';
            if (!in_array($type, ['note','image'], true)) {
                throw new HubException('invalid_item_type');
            }
            $draft = $input['cms_draft'] ?? null;
            if ($draft !== null && ($type !== 'note' || !is_array($draft) || !is_string($draft['slot'] ?? null) || $this->canvasDraft === null)) {
                throw new HubException('invalid_proposal');
            }
            [$x,$y,$w,$h] = $this->geometry($input);
            [$title,$status,$assignee,$priority,$due] = $this->metadata($input, $b);
            $attachment = $input['attachment_id'] ?? null;
            $media = $input['media_filename'] ?? null;
            if ($type === 'image') {
                if (($attachment === null) == ($media === null)) {
                    throw new HubException('image_source_required');
                }
                if ($attachment !== null && !$this->repo->one('SELECT 1 FROM eh_attachments WHERE id=? AND board_id=? AND deleted_at IS NULL', [$attachment,$b['id']])) {
                    throw new HubException('invalid_attachment');
                }
                if ($media !== null && ($this->mediaAccess === null || !($this->mediaAccess)($media))) {
                    throw new HubException('media_unavailable', 404);
                }
            } elseif ($attachment !== null || $media !== null) {
                throw new HubException('invalid_item_source');
            }
            $uuid = Support::uuid();
            $now = time();
            $order = $this->repo->appendOrder((int)$b['id'], (string)$status);
            $this->repo->run('INSERT INTO eh_items(uuid,board_id,owner_uuid,type,x,y,width,height,min_x,max_x,min_y,max_y,title,status_id,assignee_uuid,priority,due_at,attachment_id,media_filename,created_at,updated_at,ticket_order) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)', [$uuid,$b['id'],$ctx->uuid,$type,$x,$y,$w,$h,$x,$x + $w,$y,$y + $h,$title,$status,$assignee,$priority,$due,$attachment,$media,$now,$now,$order]);
            if ($type === 'note') {
                $this->repo->run('INSERT INTO eh_note_documents(note_id) VALUES(?)', [$uuid]);
                $ast = ['type' => 'doc','content' => []];
                $this->repo->run('INSERT INTO eh_note_projections VALUES(?,1,0,?,?,?,?,?)', [$uuid,Support::json($ast),'',hash('sha256', Support::json($ast)),$ctx->uuid,$now]);
            }
            if ($attachment !== null) {
                $this->repo->run('INSERT INTO eh_attachment_usages VALUES(?,?)', [$attachment,$uuid]);
            }
            if ($draft !== null) {
                ($this->canvasDraft)($this->repo->find($uuid), $draft['slot']);
            }
            $item = $this->repo->find($uuid);
            $bounds = ItemRepository::boundsOf($item);
            $this->repo->touchTiles((int)$b['id'], null, $bounds, $type, $ctx->uuid);
            $this->sync->change((int)$b['id'], 'item.created', $uuid, 1, [], null, $bounds);
            return $item;
        });
    }

    public function get(string $uuid): array
    {
        $item = $this->access->item($uuid);
        $item['thread_count'] = (int)$this->repo->one('SELECT COUNT(*) AS n FROM eh_threads WHERE item_id=? AND deleted_at IS NULL AND (expires_at IS NULL OR expires_at>?)', [$uuid,time()])['n'];
        if ($item['type'] === 'note') {
            $item['document'] = $this->repo->one('SELECT epoch,sequence,format_version FROM eh_note_documents WHERE note_id=?', [$uuid]);
        }
        $item['references'] = $this->repo->all('SELECT id,occurrence_id FROM eh_references WHERE item_id=? ORDER BY created_at,id LIMIT 50', [$uuid]);
        $item['proposals'] = $this->repo->all('SELECT id,revision FROM eh_proposals WHERE item_id=? ORDER BY created_at,id LIMIT 20', [$uuid]);
        $item['transfers'] = $this->repo->all('SELECT idempotency_key AS id,state,updated_at FROM eh_transfer_receipts r JOIN eh_transfer_plans p ON p.id=r.plan_id WHERE p.item_id=? ORDER BY r.updated_at DESC LIMIT 20', [$uuid]);
        return $item;
    }

    public function update(string $uuid, array $input): array
    {
        $this->access->item($uuid, 'update');
        return Support::transaction($this->repo->db, function () use ($uuid, $input): array {
            $item = $this->access->item($uuid, 'update');
            if ((int)($input['expected_revision'] ?? 0) !== (int)$item['metadata_revision']) {
                throw new HubException('version_conflict', 409);
            }
            $b = $this->repo->one('SELECT * FROM eh_boards WHERE id=?', [$item['board_id']]);
            [$title,$status,$assignee,$priority,$due] = $this->metadata($input, $b, $item);
            $order = $status === $item['status_id'] ? (int)$item['ticket_order'] : $this->repo->appendOrder((int)$item['board_id'], (string)$status);
            $this->repo->run('UPDATE eh_items SET title=?,status_id=?,assignee_uuid=?,priority=?,due_at=?,ticket_order=?,metadata_revision=metadata_revision+1,updated_at=? WHERE uuid=?', [$title,$status,$assignee,$priority,$due,$order,time(),$uuid]);
            $bounds = ItemRepository::boundsOf($item);
            $this->repo->touchTiles((int)$item['board_id'], $bounds, $bounds, $item['type'], $item['owner_uuid']);
            $this->sync->change((int)$item['board_id'], 'item.updated', $uuid, (int)$item['metadata_revision'] + 1, [], $bounds, $bounds);
            return $this->repo->find($uuid);
        });
    }

    /** Move one ticket atomically; null before_item_uuid appends to the destination status. */
    public function moveTicket(string $boardUuid, array $input): array
    {
        $this->access->board($boardUuid);
        $uuid = (string)($input['item_uuid'] ?? '');
        $this->access->item($uuid, 'update');

        return Support::transaction($this->repo->db, function () use ($boardUuid, $input, $uuid): array {
            $board = $this->access->board($boardUuid);
            $item = $this->access->item($uuid, 'update');
            if ((int)$item['board_id'] !== (int)$board['id']) {
                throw new HubException('not_found', 404);
            }
            if ((int)($input['expected_revision'] ?? 0) !== (int)$item['metadata_revision']) {
                throw new HubException('version_conflict', 409);
            }

            $status = $input['status_id'] ?? null;
            if (!is_string($status) || !$this->repo->one('SELECT 1 FROM eh_board_statuses WHERE id=? AND board_id=?', [$status, $board['id']])) {
                throw new HubException('invalid_status');
            }
            $beforeId = $input['before_item_uuid'] ?? null;
            if ($beforeId !== null && (!is_string($beforeId) || $beforeId === $uuid)) {
                throw new HubException('invalid_ticket_position');
            }

            if ($beforeId === null) {
                $order = $this->repo->appendOrder((int)$board['id'], $status);
            } else {
                $before = $this->access->item($beforeId);
                if ((int)$before['board_id'] !== (int)$board['id'] || $before['status_id'] !== $status) {
                    throw new HubException('invalid_ticket_position');
                }
                $order = $this->orderBefore((int)$board['id'], $status, $before, $uuid);
            }

            $this->repo->run('UPDATE eh_items SET status_id=?,ticket_order=?,metadata_revision=metadata_revision+1,updated_at=? WHERE uuid=?', [$status, $order, time(), $uuid]);
            $bounds = ItemRepository::boundsOf($item);
            $this->repo->touchTiles((int)$board['id'], $bounds, $bounds, $item['type'], $item['owner_uuid']);
            $this->sync->change((int)$board['id'], 'item.updated', $uuid, (int)$item['metadata_revision'] + 1, ['reset_tickets' => true], $bounds, $bounds);

            return $this->repo->find($uuid);
        });
    }

    private function orderBefore(int $boardId, string $statusId, array $before, string $movingUuid): int
    {
        $previous = $this->repo->one('SELECT ticket_order FROM eh_items WHERE board_id=? AND status_id=? AND deleted_at IS NULL AND uuid<>? AND (ticket_order<? OR (ticket_order=? AND id<?)) ORDER BY ticket_order DESC,id DESC LIMIT 1', [$boardId, $statusId, $movingUuid, $before['ticket_order'], $before['ticket_order'], $before['id']]);
        $lower = (int)($previous['ticket_order'] ?? 0);
        $upper = (int)$before['ticket_order'];

        if ($upper - $lower <= 1) {
            $this->repo->rebalanceOrder($boardId, $statusId);
            $before = $this->repo->find($before['uuid']);
            return $this->orderBefore($boardId, $statusId, $before, $movingUuid);
        }

        return $lower + intdiv($upper - $lower, 2);
    }

    public function geometryBatch(string $boardUuid, array $input): array
    {
        $b = $this->access->board($boardUuid);
        $changes = $input['items'] ?? [];
        if (!is_array($changes) || count($changes) < 1 || count($changes) > 20) {
            throw new HubException('invalid_geometry_batch');
        }
        return Support::transaction($this->repo->db, function () use ($boardUuid, $changes): array {
            $b = $this->access->board($boardUuid);
            $result = [];
            $seen = [];
            foreach ($changes as $change) {
                $uuid = (string)($change['uuid'] ?? '');
                if (isset($seen[$uuid])) {
                    throw new HubException('invalid_geometry_batch');
                } $seen[$uuid] = true;
                $item = $this->access->item($uuid, 'update');
                if ((int)$item['board_id'] !== (int)$b['id']) {
                    throw new HubException('not_found', 404);
                }
                if ((int)($change['expected_revision'] ?? 0) !== (int)$item['geometry_revision']) {
                    throw new HubException('version_conflict', 409, ['item' => $uuid]);
                }
                [$x,$y,$w,$h] = $this->geometry($change, $item);
                $old = ItemRepository::boundsOf($item);
                $new = ['min_x' => $x,'max_x' => $x + $w,'min_y' => $y,'max_y' => $y + $h];
                $this->repo->run('UPDATE eh_items SET x=?,y=?,width=?,height=?,min_x=?,max_x=?,min_y=?,max_y=?,geometry_revision=geometry_revision+1,updated_at=? WHERE uuid=?', [$x,$y,$w,$h,$x,$x + $w,$y,$y + $h,time(),$uuid]);
                $this->repo->touchTiles((int)$b['id'], $old, $new, $item['type'], $item['owner_uuid']);
                $this->sync->change((int)$b['id'], 'item.geometry', $uuid, (int)$item['geometry_revision'] + 1, [], $old, $new);
                (new ConnectorService($this->repo, $this->access, $this->sync))->refreshForItem($uuid);
                $result[] = ['uuid' => $uuid,'geometry_revision' => (int)$item['geometry_revision'] + 1];
            }
            return $result;
        });
    }

    public function delete(string $uuid, int $revision): void
    {
        $item = $this->access->item($uuid);
        $b = $this->repo->one('SELECT * FROM eh_boards WHERE id=?', [$item['board_id']]);
        if (!$this->access->granted('delete', $item['owner_uuid'])) {
            $this->access->manage($b);
        }
        Support::transaction($this->repo->db, function () use ($uuid, $revision): void {
            $item = $this->access->item($uuid);
            $b = $this->repo->one('SELECT * FROM eh_boards WHERE id=?', [$item['board_id']]);
            if (!$this->access->granted('delete', $item['owner_uuid'])) {
                $this->access->manage($b);
            }
            if ((int)$item['metadata_revision'] !== $revision) {
                throw new HubException('version_conflict', 409);
            }
            $this->repo->run('UPDATE eh_items SET deleted_at=? WHERE uuid=?', [time(),$uuid]);
            $bounds = ItemRepository::boundsOf($item);
            $this->repo->touchTiles((int)$item['board_id'], $bounds, null, $item['type'], $item['owner_uuid']);
            $this->sync->change((int)$item['board_id'], 'item.deleted', $uuid, $revision + 1, [], $bounds, null);
            $edges = $this->repo->all('SELECT * FROM eh_connectors WHERE (from_item=? OR to_item=?) AND deleted_at IS NULL LIMIT 201', [$uuid,$uuid]);
            foreach ($edges as $edge) {
                $this->repo->run('UPDATE eh_connectors SET deleted_at=? WHERE id=?', [time(),$edge['id']]);
                $eb = ItemRepository::boundsOf($edge);
                $this->sync->change((int)$item['board_id'], 'connector.deleted', $edge['uuid'], (int)$edge['revision'] + 1, [], $eb, null);
            }
        });
    }
}
