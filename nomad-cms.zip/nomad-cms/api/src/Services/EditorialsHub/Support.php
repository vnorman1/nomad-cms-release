<?php

/**
 * NOMAD CMS - Editorials Hub Support.
 *
 * JSON, transaction and signed-cursor primitives shared by the Hub services.
 * Backend-only PHP/SQLite module; resource budgets and authorization are enforced at service boundaries.
 *
 * @package NomadCMS\Services\EditorialsHub
 */

declare(strict_types=1);

namespace NomadCMS\Services\EditorialsHub;

use PDO;

/** JSON, transaction and signed-cursor primitives shared by the Hub services. */
final class Support
{
    public static function json(mixed $value): string
    {
        return json_encode($value, JSON_THROW_ON_ERROR | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    }

    public static function uuid(): string
    {
        $bytes = random_bytes(16);
        $bytes[6] = chr((ord($bytes[6]) & 15) | 64);
        $bytes[8] = chr((ord($bytes[8]) & 63) | 128);
        $hex = bin2hex($bytes);
        return substr($hex, 0, 8) . '-' . substr($hex, 8, 4) . '-' . substr($hex, 12, 4) . '-' . substr($hex, 16, 4) . '-' . substr($hex, 20);
    }

    public static function now(): int
    {
        return time();
    }

    public static function transaction(PDO $db, callable $work, string $lockTable = 'eh_migrations'): mixed
    {
        $nested = $db->inTransaction();
        $point = 'eh_' . bin2hex(random_bytes(6));
        if ($nested) {
            $db->exec('SAVEPOINT ' . $point);
        } else {
            $db->beginTransaction();
        }
        try {
            // Obtain the writer lock before any revision/receipt read.
            if ($lockTable === 'eh_migrations') {
                $db->exec('UPDATE eh_migrations SET applied_at=applied_at WHERE 0');
            } elseif ($lockTable === 'eh_destination_receipts') {
                $db->exec('UPDATE eh_destination_receipts SET created_at=created_at WHERE 0');
            } else {
                throw new \LogicException('Unsupported transaction lock table');
            }
            $result = $work();
            if ($nested) {
                $db->exec('RELEASE SAVEPOINT ' . $point);
            } else {
                $db->commit();
            }
            return $result;
        } catch (\Throwable $error) {
            if ($db->inTransaction()) {
                if ($nested) {
                    $db->exec('ROLLBACK TO SAVEPOINT ' . $point);
                    $db->exec('RELEASE SAVEPOINT ' . $point);
                } else {
                    $db->rollBack();
                }
            }
            throw $error;
        }
    }

    public static function finite(mixed $value): float
    {
        if (!is_numeric($value) || !is_finite((float) $value) || abs((float) $value) > 1000000000) {
            throw new HubException('invalid_coordinate');
        }
        return (float) $value;
    }

    public static function bounds(array $input, bool $overscan = false): array
    {
        $result = [];
        foreach (['min_x', 'min_y', 'max_x', 'max_y'] as $key) {
            $result[$key] = self::finite($input[$key] ?? null);
        }
        if ($result['max_x'] <= $result['min_x'] || $result['max_y'] <= $result['min_y']) {
            throw new HubException('invalid_bounds');
        }
        if ($overscan) {
            $dx = ($result['max_x'] - $result['min_x']) * .2;
            $dy = ($result['max_y'] - $result['min_y']) * .2;
            $result['min_x'] -= $dx;
            $result['max_x'] += $dx;
            $result['min_y'] -= $dy;
            $result['max_y'] += $dy;
        }
        return $result;
    }

    public static function intersects(array $a, array $b): bool
    {
        return $a['min_x'] <= $b['max_x'] && $a['max_x'] >= $b['min_x'] && $a['min_y'] <= $b['max_y'] && $a['max_y'] >= $b['min_y'];
    }

    public static function text(mixed $value, int $limit = 512): string
    {
        if (!is_string($value) || !mb_check_encoding($value, 'UTF-8') || mb_strlen($value) > $limit) {
            throw new HubException('invalid_text');
        }
        return $value;
    }

    public static function key(string $value): string
    {
        if (!preg_match('/^[a-zA-Z0-9_-]{8,128}$/D', $value)) {
            throw new HubException('invalid_operation_id');
        }
        return $value;
    }

    public static function page(array $data, array $meta = []): array
    {
        return ['success' => true, 'data' => $data, 'meta' => $meta + ['server_time' => time()]];
    }

    public static function cursor(array $value, string $secret): string
    {
        $encoded = rtrim(strtr(base64_encode(self::json($value)), '+/', '-_'), '=');
        return $encoded . '.' . hash_hmac('sha256', $encoded, $secret);
    }

    public static function decodeCursor(string $cursor, string $secret, array $binding): array
    {
        if (strlen($cursor) > 4096) {
            throw new HubException('invalid_cursor');
        }
        $parts = explode('.', $cursor);
        if (count($parts) !== 2 || !hash_equals(hash_hmac('sha256', $parts[0], $secret), $parts[1])) {
            throw new HubException('invalid_cursor');
        }
        $value = json_decode((string) base64_decode(strtr($parts[0], '-_', '+/'), true), true);
        if (!is_array($value)) {
            throw new HubException('invalid_cursor');
        }
        foreach ($binding as $key => $expected) {
            if (($value[$key] ?? null) !== $expected) {
                throw new HubException('invalid_cursor');
            }
        }
        return $value;
    }
}
