<?php

/**
 * NOMAD CMS — Editorials Hub fresh-install schema.
 * Creates the current row-backed tables, indexes and optional spatial triggers directly.
 * Existing installations retain the separate, explicit historical migration path.
 *
 * @package NomadCMS\Services\EditorialsHub
 */

declare(strict_types=1);

namespace NomadCMS\Services\EditorialsHub;

use NomadCMS\Services\NotificationService\Migrations\Schema as NotificationSchema;
use PDO;
use PDOException;

/** Current schema snapshot and initial permissions for new installations. */
final class Schema
{
    public static function install(PDO $hub, PDO $auth, PDO $content, bool $enableRtree = true): void
    {
        $exists = (bool) $hub->query("SELECT 1 FROM sqlite_master WHERE type='table' AND name='eh_migrations'")->fetchColumn();
        if ($exists && !EditorialsHubModule::installed($hub)) {
            throw new \LogicException('Editorials Hub schema requires an explicit migration.');
        }
        // Resume interrupted installations without replaying upgrades or duplicating tables.
        if (!$exists) {
            $hub->beginTransaction();
            try {
                $hub->exec('CREATE TABLE eh_migrations(version INTEGER PRIMARY KEY, applied_at INTEGER NOT NULL)');
                $hub->exec(self::definitions());
                NotificationSchema::source($hub);
                self::spatial($hub, $enableRtree);
                $record = $hub->prepare('INSERT INTO eh_migrations(version,applied_at) VALUES (?,?)');
                foreach ([1, 4, 5, 6, 7] as $version) {
                    $record->execute([$version, time()]);
                }
                $hub->commit();
            } catch (\Throwable $error) {
                $hub->rollBack();
                throw $error;
            }
        }

        $content->beginTransaction();
        try {
            $content->exec('CREATE TABLE IF NOT EXISTS eh_destination_receipts(idempotency_key TEXT PRIMARY KEY,plan_id TEXT NOT NULL UNIQUE,proposal_id TEXT UNIQUE,actor_uuid TEXT NOT NULL,checksum TEXT NOT NULL,destination TEXT NOT NULL,result TEXT NOT NULL,plan TEXT NOT NULL,effects_done INTEGER NOT NULL DEFAULT 0,created_at INTEGER NOT NULL)');
            $content->exec('CREATE INDEX IF NOT EXISTS eh_destination_effects ON eh_destination_receipts(effects_done,created_at)');
            NotificationSchema::source($content);
            $content->commit();
        } catch (\Throwable $error) {
            $content->rollBack();
            throw $error;
        }

        $auth->beginTransaction();
        try {
            $auth->exec('CREATE TABLE IF NOT EXISTS eh_auth_migrations(version INTEGER PRIMARY KEY,applied_at INTEGER NOT NULL)');
            if (!$auth->query('SELECT 1 FROM eh_auth_migrations WHERE version=2')->fetchColumn()) {
                $grants = ['editorials:read:*', 'editorials:create:*', 'editorials:update:*', 'editorials:comment:*', 'editorials:delete:own', 'editorials:manage:own'];
                $insert = $auth->prepare('INSERT OR IGNORE INTO role_permissions(role_id,permission) SELECT id,? FROM roles');
                foreach ($grants as $grant) {
                    $insert->execute([$grant]);
                }
                $auth->prepare('INSERT INTO eh_auth_migrations(version,applied_at) VALUES(2,?)')->execute([time()]);
            }
            $auth->commit();
        } catch (\Throwable $error) {
            $auth->rollBack();
            throw $error;
        }
    }

    /** Current fresh-install SQL; execute whole statements without splitting triggers. */
    private static function definitions(): string
    {
        return <<<'SQL'
        -- NOMAD CMS Editorials Hub: current fresh-install schema (version 7).
        -- Historical data conversions belong exclusively to Migrations/.
        CREATE TABLE eh_settings(key TEXT PRIMARY KEY, value TEXT NOT NULL);
        CREATE TABLE eh_boards(
         id INTEGER PRIMARY KEY, uuid TEXT NOT NULL UNIQUE, owner_uuid TEXT NOT NULL,
         title TEXT NOT NULL, visibility TEXT NOT NULL CHECK(visibility IN ('shared','private')),
         retention_seconds INTEGER, revision INTEGER NOT NULL DEFAULT 1, access_revision INTEGER NOT NULL DEFAULT 1,
         change_sequence INTEGER NOT NULL DEFAULT 0, min_sequence INTEGER NOT NULL DEFAULT 0,
         created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL, deleted_at INTEGER
        );
        CREATE INDEX eh_board_owner ON eh_boards(owner_uuid, id);
        CREATE TABLE eh_board_members(
         board_id INTEGER NOT NULL REFERENCES eh_boards(id) ON DELETE CASCADE,
         user_uuid TEXT NOT NULL, created_at INTEGER NOT NULL, PRIMARY KEY(board_id,user_uuid)
        );
        CREATE INDEX eh_members_user ON eh_board_members(user_uuid,board_id);
        CREATE TABLE eh_board_statuses(
         id TEXT PRIMARY KEY, board_id INTEGER NOT NULL REFERENCES eh_boards(id) ON DELETE CASCADE,
         name TEXT NOT NULL, position INTEGER NOT NULL
        );
        CREATE INDEX eh_status_board ON eh_board_statuses(board_id,position,id);
        CREATE TABLE eh_items(
         id INTEGER PRIMARY KEY, uuid TEXT NOT NULL UNIQUE, board_id INTEGER NOT NULL REFERENCES eh_boards(id) ON DELETE CASCADE,
         owner_uuid TEXT NOT NULL, type TEXT NOT NULL CHECK(type IN ('note','image')),
         x REAL NOT NULL, y REAL NOT NULL, width REAL NOT NULL CHECK(width BETWEEN 16 AND 4096), height REAL NOT NULL CHECK(height BETWEEN 16 AND 4096),
         min_x REAL NOT NULL, max_x REAL NOT NULL, min_y REAL NOT NULL, max_y REAL NOT NULL,
         title TEXT NOT NULL DEFAULT '', preview TEXT NOT NULL DEFAULT '',
         status_id TEXT REFERENCES eh_board_statuses(id), assignee_uuid TEXT, priority TEXT NOT NULL DEFAULT 'normal', due_at INTEGER,
         ticket_order INTEGER NOT NULL DEFAULT 0,
         attachment_id TEXT, media_filename TEXT, thread_count INTEGER NOT NULL DEFAULT 0,
         metadata_revision INTEGER NOT NULL DEFAULT 1, geometry_revision INTEGER NOT NULL DEFAULT 1,
         created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL, deleted_at INTEGER
        );
        CREATE INDEX eh_items_board_id ON eh_items(board_id,id) WHERE deleted_at IS NULL;
        CREATE INDEX eh_items_owner ON eh_items(board_id,owner_uuid,id) WHERE deleted_at IS NULL;
        CREATE INDEX eh_items_status ON eh_items(board_id,status_id,id) WHERE deleted_at IS NULL;
        CREATE INDEX eh_items_assignee ON eh_items(board_id,assignee_uuid,id) WHERE deleted_at IS NULL;
        CREATE INDEX eh_items_media ON eh_items(media_filename,board_id) WHERE deleted_at IS NULL AND media_filename IS NOT NULL;
        CREATE INDEX eh_items_x ON eh_items(board_id,min_x,max_x,id) WHERE deleted_at IS NULL;
        CREATE INDEX eh_items_y ON eh_items(board_id,min_y,max_y,id) WHERE deleted_at IS NULL;
        CREATE TABLE eh_tiles(
         board_id INTEGER NOT NULL REFERENCES eh_boards(id) ON DELETE CASCADE, level INTEGER NOT NULL,
         tile_x INTEGER NOT NULL, tile_y INTEGER NOT NULL, revision INTEGER NOT NULL DEFAULT 1,
         owner_uuid TEXT NOT NULL DEFAULT '',
         item_count INTEGER NOT NULL DEFAULT 0, note_count INTEGER NOT NULL DEFAULT 0, image_count INTEGER NOT NULL DEFAULT 0,
         PRIMARY KEY(board_id,level,owner_uuid,tile_x,tile_y)
        );
        CREATE TABLE eh_connectors(
         id INTEGER PRIMARY KEY, uuid TEXT NOT NULL UNIQUE, board_id INTEGER NOT NULL REFERENCES eh_boards(id) ON DELETE CASCADE,
         owner_uuid TEXT NOT NULL, from_item TEXT NOT NULL REFERENCES eh_items(uuid) ON DELETE CASCADE,
         to_item TEXT NOT NULL REFERENCES eh_items(uuid) ON DELETE CASCADE,
         from_x REAL NOT NULL,from_y REAL NOT NULL,to_x REAL NOT NULL,to_y REAL NOT NULL,
         min_x REAL NOT NULL,max_x REAL NOT NULL,min_y REAL NOT NULL,max_y REAL NOT NULL,
         revision INTEGER NOT NULL DEFAULT 1,created_at INTEGER NOT NULL,deleted_at INTEGER
        );
        CREATE INDEX eh_connectors_board ON eh_connectors(board_id,id) WHERE deleted_at IS NULL;
        CREATE INDEX eh_connectors_from ON eh_connectors(from_item);
        CREATE INDEX eh_connectors_to ON eh_connectors(to_item);
        CREATE TABLE eh_note_documents(
         note_id TEXT PRIMARY KEY REFERENCES eh_items(uuid) ON DELETE CASCADE,
         epoch INTEGER NOT NULL DEFAULT 1, sequence INTEGER NOT NULL DEFAULT 0, format_version INTEGER NOT NULL DEFAULT 1
        );
        CREATE TABLE eh_note_updates(
         note_id TEXT NOT NULL REFERENCES eh_note_documents(note_id) ON DELETE CASCADE,
         epoch INTEGER NOT NULL,sequence INTEGER NOT NULL,operation_id TEXT NOT NULL,actor_uuid TEXT NOT NULL,
         checksum TEXT NOT NULL,payload BLOB NOT NULL,created_at INTEGER NOT NULL,encoding TEXT NOT NULL DEFAULT 'raw',
         PRIMARY KEY(note_id,epoch,sequence),UNIQUE(note_id,epoch,operation_id)
        );
        CREATE TABLE eh_note_checkpoints(
         id INTEGER PRIMARY KEY,note_id TEXT NOT NULL REFERENCES eh_note_documents(note_id) ON DELETE CASCADE,
         epoch INTEGER NOT NULL,sequence INTEGER NOT NULL,checksum TEXT NOT NULL,payload BLOB NOT NULL,
         actor_uuid TEXT NOT NULL,created_at INTEGER NOT NULL,UNIQUE(note_id,epoch,sequence,checksum)
        );
        CREATE INDEX eh_checkpoint_latest ON eh_note_checkpoints(note_id,epoch,sequence DESC,id DESC);
        CREATE INDEX eh_updates_archive ON eh_note_updates(encoding,created_at,note_id,epoch,sequence);
        CREATE TABLE eh_note_projections(
         note_id TEXT PRIMARY KEY REFERENCES eh_note_documents(note_id) ON DELETE CASCADE,
         epoch INTEGER NOT NULL,sequence INTEGER NOT NULL,ast TEXT NOT NULL,plain_text TEXT NOT NULL,
         checksum TEXT NOT NULL,actor_uuid TEXT NOT NULL,updated_at INTEGER NOT NULL
        );
        CREATE TABLE eh_threads(
         id INTEGER PRIMARY KEY,uuid TEXT NOT NULL UNIQUE,item_id TEXT NOT NULL REFERENCES eh_items(uuid) ON DELETE CASCADE,
         board_id INTEGER NOT NULL REFERENCES eh_boards(id) ON DELETE CASCADE,owner_uuid TEXT NOT NULL,
         title TEXT NOT NULL,revision INTEGER NOT NULL DEFAULT 1,created_at INTEGER NOT NULL,
         last_reply_at INTEGER NOT NULL,expires_at INTEGER,deleted_at INTEGER
        );
        CREATE INDEX eh_thread_item ON eh_threads(item_id,id);
        CREATE INDEX eh_thread_expiry ON eh_threads(expires_at,id) WHERE expires_at IS NOT NULL;
        CREATE TABLE eh_messages(
         id INTEGER PRIMARY KEY,uuid TEXT NOT NULL UNIQUE,thread_id TEXT NOT NULL REFERENCES eh_threads(uuid) ON DELETE CASCADE,
         author_uuid TEXT NOT NULL,body TEXT NOT NULL,revision INTEGER NOT NULL DEFAULT 1,
         created_at INTEGER NOT NULL,updated_at INTEGER NOT NULL,deleted_at INTEGER
        );
        CREATE INDEX eh_messages_thread ON eh_messages(thread_id,id);
        CREATE TABLE eh_references(
         id TEXT PRIMARY KEY,board_id INTEGER NOT NULL REFERENCES eh_boards(id) ON DELETE CASCADE,
         item_id TEXT NOT NULL REFERENCES eh_items(uuid) ON DELETE CASCADE,actor_uuid TEXT NOT NULL,
         occurrence_id TEXT NOT NULL,target TEXT NOT NULL,created_at INTEGER NOT NULL,
         UNIQUE(item_id,occurrence_id)
        );
        CREATE INDEX eh_refs_board ON eh_references(board_id,id);
        CREATE TABLE eh_proposals(
         id TEXT PRIMARY KEY,board_id INTEGER NOT NULL REFERENCES eh_boards(id) ON DELETE CASCADE,
         item_id TEXT NOT NULL REFERENCES eh_items(uuid) ON DELETE CASCADE,owner_uuid TEXT NOT NULL,
         target TEXT NOT NULL,values_json TEXT NOT NULL,revision INTEGER NOT NULL DEFAULT 1,
         role TEXT NOT NULL DEFAULT 'standard' CHECK(role IN ('standard','canvas_draft')),
         field_media_json TEXT NOT NULL DEFAULT '[]',
         created_at INTEGER NOT NULL,updated_at INTEGER NOT NULL
        );
        CREATE TABLE eh_changes(
         board_id INTEGER NOT NULL REFERENCES eh_boards(id) ON DELETE CASCADE,sequence INTEGER NOT NULL,
         kind TEXT NOT NULL,entity_id TEXT NOT NULL,revision INTEGER NOT NULL,payload TEXT NOT NULL,
         old_bounds TEXT,new_bounds TEXT,created_at INTEGER NOT NULL,PRIMARY KEY(board_id,sequence)
        );
        CREATE INDEX eh_changes_time ON eh_changes(created_at,board_id,sequence);
        CREATE TABLE eh_attachments(
         id TEXT PRIMARY KEY,board_id INTEGER NOT NULL REFERENCES eh_boards(id) ON DELETE CASCADE,
         owner_uuid TEXT NOT NULL,filename TEXT NOT NULL,mime TEXT NOT NULL,byte_size INTEGER NOT NULL,
         width INTEGER NOT NULL,height INTEGER NOT NULL,checksum TEXT NOT NULL,storage_key TEXT NOT NULL UNIQUE,
         thumbnail_key TEXT,thumbnail_mime TEXT,thumbnail_size INTEGER,created_at INTEGER NOT NULL,deleted_at INTEGER
        );
        CREATE INDEX eh_attachment_board ON eh_attachments(board_id,id);
        CREATE TABLE eh_attachment_usages(
         attachment_id TEXT NOT NULL REFERENCES eh_attachments(id) ON DELETE CASCADE,
         item_id TEXT NOT NULL REFERENCES eh_items(uuid) ON DELETE CASCADE,PRIMARY KEY(attachment_id,item_id)
        );
        CREATE TABLE eh_transfer_plans(
         id TEXT PRIMARY KEY,board_id INTEGER NOT NULL,
         item_id TEXT NOT NULL,actor_uuid TEXT NOT NULL,
         proposal_id TEXT,plan TEXT NOT NULL,checksum TEXT NOT NULL,expires_at INTEGER NOT NULL,created_at INTEGER NOT NULL
        );
        CREATE TABLE eh_transfer_receipts(
         idempotency_key TEXT PRIMARY KEY,plan_id TEXT NOT NULL UNIQUE,board_id INTEGER NOT NULL,
         actor_uuid TEXT NOT NULL,checksum TEXT NOT NULL,state TEXT NOT NULL,
         destination TEXT,destination_db TEXT NOT NULL,result TEXT,created_at INTEGER NOT NULL,updated_at INTEGER NOT NULL
        );
        CREATE INDEX eh_transfer_pending ON eh_transfer_receipts(state,updated_at);
        CREATE TABLE eh_outbox(
         id TEXT PRIMARY KEY,board_id INTEGER NOT NULL,actor_uuid TEXT NOT NULL,recipient_uuid TEXT,
         kind TEXT NOT NULL,occurrence_id TEXT,payload TEXT NOT NULL,state TEXT NOT NULL DEFAULT 'parked',
         created_at INTEGER NOT NULL,delivered_at INTEGER,UNIQUE(kind,occurrence_id,recipient_uuid)
        );
        CREATE INDEX eh_outbox_pending ON eh_outbox(state,created_at,id);
        CREATE TABLE eh_requests(
         actor_uuid TEXT NOT NULL,operation TEXT NOT NULL,request_key TEXT NOT NULL,
         checksum TEXT NOT NULL,result TEXT NOT NULL,created_at INTEGER NOT NULL,
         PRIMARY KEY(actor_uuid,operation,request_key)
        );
        CREATE TABLE eh_audit(
         id INTEGER PRIMARY KEY,actor_uuid TEXT NOT NULL,board_id INTEGER NOT NULL,operation TEXT NOT NULL,created_at INTEGER NOT NULL
        );
        CREATE TABLE eh_annotations(
         id INTEGER PRIMARY KEY,
         thread_id TEXT NOT NULL UNIQUE REFERENCES eh_threads(uuid) ON DELETE CASCADE,
         reference_id TEXT NOT NULL REFERENCES eh_references(id) ON DELETE CASCADE,
         board_id INTEGER NOT NULL REFERENCES eh_boards(id) ON DELETE CASCADE,
         item_id TEXT NOT NULL REFERENCES eh_items(uuid) ON DELETE CASCADE,
         target_kind TEXT NOT NULL CHECK(target_kind IN ('slot','media','module')),
         target_slot TEXT NOT NULL,
         target_item TEXT NOT NULL,
         target_field TEXT NOT NULL,
         target_locale TEXT NOT NULL,
         target_path TEXT NOT NULL
        );
        CREATE INDEX eh_annotations_target ON eh_annotations(target_kind,target_slot,target_item,id);
        CREATE INDEX eh_annotations_board ON eh_annotations(board_id,id);
        CREATE INDEX eh_annotations_item ON eh_annotations(item_id,id);
        CREATE INDEX eh_annotations_reference ON eh_annotations(reference_id);
        CREATE INDEX eh_messages_live ON eh_messages(thread_id,id) WHERE deleted_at IS NULL;
        CREATE INDEX eh_tickets_order ON eh_items(board_id,ticket_order,id) WHERE deleted_at IS NULL;
        CREATE INDEX eh_tickets_status_order ON eh_items(board_id,status_id,ticket_order,id) WHERE deleted_at IS NULL;
        CREATE INDEX eh_tickets_owner_order ON eh_items(board_id,owner_uuid,ticket_order,id) WHERE deleted_at IS NULL;
        CREATE INDEX eh_tickets_status_owner_order ON eh_items(board_id,status_id,owner_uuid,ticket_order,id) WHERE deleted_at IS NULL;
        CREATE INDEX eh_tickets_assignee_order ON eh_items(board_id,assignee_uuid,ticket_order,id) WHERE deleted_at IS NULL;
        CREATE INDEX eh_tickets_status_assignee_order ON eh_items(board_id,status_id,assignee_uuid,ticket_order,id) WHERE deleted_at IS NULL;
        CREATE TABLE eh_message_references(
         message_id TEXT NOT NULL REFERENCES eh_messages(uuid) ON DELETE CASCADE,
         reference_id TEXT NOT NULL REFERENCES eh_references(id) ON DELETE CASCADE,
         position INTEGER NOT NULL,
         PRIMARY KEY(message_id,reference_id)
        );
        CREATE INDEX eh_message_references_order ON eh_message_references(message_id,position,reference_id);
        CREATE UNIQUE INDEX eh_canvas_proposal ON eh_proposals(item_id) WHERE role='canvas_draft';
        CREATE TABLE eh_proposal_attachment_usages(
         proposal_id TEXT NOT NULL REFERENCES eh_proposals(id) ON DELETE CASCADE,
         attachment_id TEXT NOT NULL REFERENCES eh_attachments(id) ON DELETE CASCADE,
         PRIMARY KEY(proposal_id,attachment_id)
        );
        CREATE INDEX eh_proposal_attachment_lookup ON eh_proposal_attachment_usages(attachment_id,proposal_id);
        CREATE INDEX eh_transfer_proposal ON eh_transfer_plans(proposal_id,id);
        CREATE TABLE IF NOT EXISTS eh_destination_receipts(idempotency_key TEXT PRIMARY KEY,plan_id TEXT NOT NULL UNIQUE,proposal_id TEXT UNIQUE,actor_uuid TEXT NOT NULL,checksum TEXT NOT NULL,destination TEXT NOT NULL,result TEXT NOT NULL,plan TEXT NOT NULL,effects_done INTEGER NOT NULL DEFAULT 0,created_at INTEGER NOT NULL);
        CREATE INDEX IF NOT EXISTS eh_destination_effects ON eh_destination_receipts(effects_done,created_at);
        SQL;
    }

    /** Match the legacy spatial fallback without requiring the RTree extension. */
    private static function spatial(PDO $db, bool $enableRtree): void
    {
        $rtree = false;
        if ($enableRtree) {
            try {
                $db->exec('CREATE VIRTUAL TABLE eh_item_bounds USING rtree(id,min_x,max_x,min_y,max_y,min_board,max_board)');
                $db->exec('CREATE VIRTUAL TABLE eh_connector_bounds USING rtree(id,min_x,max_x,min_y,max_y,min_board,max_board)');
                $rtree = true;
            } catch (PDOException $error) {
                if (!str_contains($error->getMessage(), 'no such module')) {
                    throw $error;
                }
            }
        }
        if ($rtree) {
            foreach (['items' => 'item', 'connectors' => 'connector'] as $table => $name) {
                $db->exec("CREATE TRIGGER eh_{$name}_insert AFTER INSERT ON eh_{$table} WHEN new.deleted_at IS NULL BEGIN INSERT INTO eh_{$name}_bounds VALUES(new.id,new.min_x,new.max_x,new.min_y,new.max_y,new.board_id,new.board_id); END");
                $db->exec("CREATE TRIGGER eh_{$name}_update AFTER UPDATE OF min_x,max_x,min_y,max_y,deleted_at ON eh_{$table} BEGIN DELETE FROM eh_{$name}_bounds WHERE id=old.id; INSERT INTO eh_{$name}_bounds SELECT new.id,new.min_x,new.max_x,new.min_y,new.max_y,new.board_id,new.board_id WHERE new.deleted_at IS NULL; END");
                $db->exec("CREATE TRIGGER eh_{$name}_delete AFTER DELETE ON eh_{$table} BEGIN DELETE FROM eh_{$name}_bounds WHERE id=old.id; END");
            }
        }
        $stmt = $db->prepare('INSERT INTO eh_settings(key,value) VALUES(?,?)');
        $stmt->execute(['spatial_mode', $rtree ? 'rtree' : 'btree']);
    }
}
