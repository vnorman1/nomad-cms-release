<?php

/**
 * NOMAD CMS - Editorials Hub HubAccessPolicy.
 *
 * Intersection of global RBAC, board visibility and domain ownership, on every request.
 * Backend-only PHP/SQLite module; resource budgets and authorization are enforced at service boundaries.
 *
 * @package NomadCMS\Services\EditorialsHub\Access
 */

declare(strict_types=1);

namespace NomadCMS\Services\EditorialsHub\Access;

use NomadCMS\Services\EditorialsHub\Contracts\HubRequestContext;
use NomadCMS\Services\EditorialsHub\HubException;
use NomadCMS\Services\EditorialsHub\Persistence\BoardRepository;
use NomadCMS\Services\EditorialsHub\Persistence\ItemRepository;

/** Intersection of global RBAC, board visibility and domain ownership, on every request. */
final class HubAccessPolicy
{
    public function __construct(public readonly HubRequestContext $context, private BoardRepository $boards, private ItemRepository $items)
    {
    }

    public function granted(string $action, string $owner): bool
    {
        return $this->context->has('editorials:' . $action . ':*') || ($owner === $this->context->uuid && $this->context->has('editorials:' . $action . ':own'));
    }

    public function require(string $action, string $owner): void
    {
        if (!$this->granted($action, $owner)) {
            throw new HubException('forbidden', 403);
        }
    }

    public function board(string $uuid, string $action = 'read'): array
    {
        $board = $this->boards->find($uuid);
        if (!$board) {
            throw new HubException('not_found', 404);
        }
        if ($board['visibility'] === 'private' && $board['owner_uuid'] !== $this->context->uuid && !$this->boards->member((int)$board['id'], $this->context->uuid)) {
            if (!$this->context->superAdmin) {
                throw new HubException('not_found', 404);
            }
            // Audit without a database write on hot GET/304 paths.
            error_log('[editorials.private_override] actor=' . $this->context->uuid . ' board=' . $uuid . ' action=' . $action);
        }
        $this->require($action, $board['owner_uuid']);
        return $board;
    }

    public function item(string $uuid, string $action = 'read'): array
    {
        $item = $this->items->find($uuid);
        if (!$item) {
            throw new HubException('not_found', 404);
        }
        $board = $this->boards->one('SELECT uuid FROM eh_boards WHERE id=? AND deleted_at IS NULL', [$item['board_id']]);
        if (!$board) {
            throw new HubException('not_found', 404);
        }
        $this->board($board['uuid']);
        $this->require($action, $item['owner_uuid']);
        return $item;
    }

    public function manage(array $board): void
    {
        $this->require('manage', $board['owner_uuid']);
    }
}
