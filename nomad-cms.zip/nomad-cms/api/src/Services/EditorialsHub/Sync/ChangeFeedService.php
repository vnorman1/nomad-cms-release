<?php

/**
 * NOMAD CMS - Editorials Hub ChangeFeedService.
 *
 * Bounded feed scanning with cursor advancement only through processed events.
 * Backend-only PHP/SQLite module; resource budgets and authorization are enforced at service boundaries.
 *
 * @package NomadCMS\Services\EditorialsHub\Sync
 */

declare(strict_types=1);

namespace NomadCMS\Services\EditorialsHub\Sync;

use NomadCMS\Services\EditorialsHub\Access\HubAccessPolicy;
use NomadCMS\Services\EditorialsHub\HubConfig;
use NomadCMS\Services\EditorialsHub\HubException;
use NomadCMS\Services\EditorialsHub\Persistence\ItemRepository;
use NomadCMS\Services\EditorialsHub\Persistence\SyncRepository;
use NomadCMS\Services\EditorialsHub\Support;

/** Bounded feed scanning with cursor advancement only through processed events. */
final class ChangeFeedService
{
    public function __construct(private SyncRepository $repo, private HubAccessPolicy $access)
    {
    }
    public function read(string $uuid, array $query): array
    {
        $b = $this->access->board($uuid);
        $ctx = $this->access->context;
        $binding = ['actor' => $ctx->uuid,'board' => $uuid,'access' => (int)$b['access_revision'],'kind' => 'changes'];
        $after = empty($query['cursor']) ? (int)($query['since'] ?? $b['change_sequence']) : (int)Support::decodeCursor($query['cursor'], $ctx->cursorSecret, $binding)['after'];
        if ($after < (int)$b['min_sequence'] || $after > (int)$b['change_sequence'] || $after < 0) {
            throw new HubException('reset_required', 409);
        }
        $bounds = isset($query['min_x']) ? Support::bounds($query, true) : null;
        $cached = $query['cached_tiles'] ?? [];
        if (is_string($cached)) {
            $cached = json_decode($cached, true);
        }
        if (!is_array($cached) || count($cached) > 64) {
            throw new HubException('invalid_cached_tiles');
        }
        $windows = $bounds ? [$bounds] : [];
        foreach ($cached as $tile) {
            $level = (int)($tile['level'] ?? -1);
            if ($level < 0 || $level >= HubConfig::TILE_LEVELS) {
                throw new HubException('invalid_cached_tiles');
            }
            $size = HubConfig::TILE_SIZE * (2 ** $level);
            $x = Support::finite($tile['x'] ?? null);
            $y = Support::finite($tile['y'] ?? null);
            $windows[] = ['min_x' => $x * $size,'max_x' => ($x + 1) * $size,'min_y' => $y * $size,'max_y' => ($y + 1) * $size];
        }
        $rows = $this->repo->all('SELECT sequence,kind,entity_id,revision,payload,old_bounds,new_bounds FROM eh_changes WHERE board_id=? AND sequence>? ORDER BY sequence LIMIT 1000', [$b['id'],$after]);
        $events = [];
        $bytes = 0;
        $more = false;
        foreach ($rows as $row) {
            $old = $row['old_bounds'] ? json_decode($row['old_bounds'], true) : null;
            $new = $row['new_bounds'] ? json_decode($row['new_bounds'], true) : null;
            $visible = ($old === null && $new === null) || $windows === [];
            foreach ($windows as $w) {
                if (($old && Support::intersects($old, $w)) || ($new && Support::intersects($new, $w))) {
                    $visible = true;
                    break;
                }
            }
            if ($visible && !$ctx->has('editorials:read:*') && !str_starts_with($row['kind'], 'board.')) {
                $payload = json_decode($row['payload'], true);
                if (str_starts_with($row['kind'], 'connector.')) {
                    $owner = $this->repo->one('SELECT c.owner_uuid FROM eh_connectors c JOIN eh_items a ON a.uuid=c.from_item JOIN eh_items z ON z.uuid=c.to_item WHERE c.uuid=? AND a.owner_uuid=? AND z.owner_uuid=?', [$row['entity_id'],$ctx->uuid,$ctx->uuid]);
                } else {
                    $owner = $this->repo->one('SELECT owner_uuid FROM eh_items WHERE uuid=?', [$payload['item_id'] ?? $row['entity_id']]);
                }
                $visible = $owner && $owner['owner_uuid'] === $ctx->uuid;
            }
            if ($visible) {
                $event = ['sequence' => (int)$row['sequence'],'kind' => $row['kind'],'entity_id' => $row['entity_id'],'revision' => (int)$row['revision'],'data' => json_decode($row['payload'], true),'old_bounds' => $old,'new_bounds' => $new];
                if (str_starts_with($row['kind'], 'item.') || str_starts_with($row['kind'], 'note.') || str_starts_with($row['kind'], 'thread.') || str_starts_with($row['kind'], 'proposal.')) {
                    $itemId = $event['data']['item_id'] ?? $row['entity_id'];
                    $item = $this->repo->one('SELECT ' . ItemRepository::LIGHT . ' FROM eh_items i WHERE i.uuid=? AND i.board_id=? AND i.deleted_at IS NULL', [$itemId,$b['id']]);
                    if ($item) {
                        $event['item'] = (new ItemRepository($this->repo->db))->withCanvasDrafts([$item])[0];
                    }
                }
                $length = strlen(Support::json($event));
                if (count($events) >= 200 || $bytes + $length > HubConfig::RESPONSE_BYTES - 4096) {
                    $more = true;
                    break;
                }
                $bytes += $length;
                $events[] = $event;
            }
            $after = (int)$row['sequence'];
        }
        $more = $more || $after < (int)$b['change_sequence'];
        return Support::page($events, ['cursor' => Support::cursor($binding + ['after' => $after], $ctx->cursorSecret),'sequence' => $after,'head' => (int)$b['change_sequence'],'has_more' => $more,'poll_after_ms' => $events ? 1000 : 3000]);
    }
}
