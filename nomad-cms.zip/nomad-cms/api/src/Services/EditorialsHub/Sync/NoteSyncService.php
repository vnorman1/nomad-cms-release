<?php

/**
 * NOMAD CMS - Editorials Hub NoteSyncService.
 *
 * Opaque Yjs HTTP relay. Transport checks never claim semantic Yjs validation.
 * Backend-only PHP/SQLite module; resource budgets and authorization are enforced at service boundaries.
 *
 * @package NomadCMS\Services\EditorialsHub\Sync
 */

declare(strict_types=1);

namespace NomadCMS\Services\EditorialsHub\Sync;

use NomadCMS\Services\EditorialsHub\Access\HubAccessPolicy;
use NomadCMS\Services\EditorialsHub\HubConfig;
use NomadCMS\Services\EditorialsHub\HubException;
use NomadCMS\Services\EditorialsHub\Persistence\ItemRepository;
use NomadCMS\Services\EditorialsHub\Persistence\SyncRepository;
use NomadCMS\Services\EditorialsHub\Support;

/** Opaque Yjs HTTP relay. Transport checks never claim semantic Yjs validation. */
final class NoteSyncService
{
    public function __construct(private SyncRepository $repo, private HubAccessPolicy $access)
    {
    }

    private function note(string $id, string $action): array
    {
        $item = $this->access->item($id, $action);
        if ($item['type'] !== 'note') {
            throw new HubException('not_a_note');
        }
        return $item;
    }

    public function append(string $id, int $epoch, string $operation, string $payload, int $format = 1): array
    {
        $this->note($id, 'update');
        Support::key($operation);
        if ($payload === '' || strlen($payload) > HubConfig::UPDATE_BYTES) {
            throw new HubException('payload_too_large', 413);
        }
        if ($format !== 1) {
            throw new HubException('unsupported_document_format');
        }
        return Support::transaction($this->repo->db, function () use ($id, $epoch, $operation, $payload): array {
            $item = $this->note($id, 'update');
            $doc = $this->repo->one('SELECT * FROM eh_note_documents WHERE note_id=?', [$id]);
            if ((int)$doc['epoch'] !== $epoch) {
                throw new HubException('reset_required', 409);
            }
            $checksum = hash('sha256', $payload);
            $old = $this->repo->one('SELECT sequence,checksum FROM eh_note_updates WHERE note_id=? AND epoch=? AND operation_id=?', [$id,$epoch,$operation]);
            if ($old) {
                if (!hash_equals($old['checksum'], $checksum)) {
                    throw new HubException('idempotency_conflict', 409);
                }
                return ['epoch' => $epoch,'sequence' => (int)$old['sequence'],'checksum' => $checksum];
            }
            $seq = (int)$doc['sequence'] + 1;
            $stmt = $this->repo->db->prepare('INSERT INTO eh_note_updates(note_id,epoch,sequence,operation_id,actor_uuid,checksum,payload,created_at) VALUES(?,?,?,?,?,?,?,?)');
            foreach ([$id,$epoch,$seq,$operation,$this->access->context->uuid,$checksum] as $n => $value) {
                $stmt->bindValue($n + 1, $value, is_int($value) ? \PDO::PARAM_INT : \PDO::PARAM_STR);
            }
            $stmt->bindValue(7, $payload, \PDO::PARAM_LOB);
            $stmt->bindValue(8, time(), \PDO::PARAM_INT);
            $stmt->execute();
            $this->repo->run('UPDATE eh_note_documents SET sequence=? WHERE note_id=?', [$seq,$id]);
            $g = ItemRepository::boundsOf($item);
            $this->syncChange($item, $id, $seq, $g);
            return ['epoch' => $epoch,'sequence' => $seq,'checksum' => $checksum];
        });
    }

    private function syncChange(array $item, string $id, int $seq, array $g): void
    {
        $this->repo->change((int)$item['board_id'], 'note.updated', $id, $seq, ['item_id' => $id], $g, $g);
    }

    public function pull(string $id, int $epoch, int $after): array
    {
        $this->note($id, 'read');
        $doc = $this->repo->one('SELECT * FROM eh_note_documents WHERE note_id=?', [$id]);
        if ((int)$doc['epoch'] !== $epoch || $after < 0 || $after > (int)$doc['sequence']) {
            throw new HubException('reset_required', 409);
        }
        $stmt = $this->repo->run('SELECT sequence,checksum,payload,encoding FROM eh_note_updates WHERE note_id=? AND epoch=? AND sequence>? ORDER BY sequence LIMIT 100', [$id,$epoch,$after]);
        $frames = '';
        $count = 0;
        while ($row = $stmt->fetch()) {
            $payload = is_resource($row['payload']) ? stream_get_contents($row['payload']) : $row['payload'];
            if ($row['encoding'] === 'gzip') {
                $payload = @gzdecode($payload, HubConfig::UPDATE_BYTES);
            }
            if (!is_string($payload) || !hash_equals($row['checksum'], hash('sha256', $payload))) {
                $stmt->closeCursor();
                throw new HubException('document_corrupted', 409);
            }
            $frame = pack('N2', (int)$row['sequence'], strlen($payload)) . hex2bin($row['checksum']) . $payload;
            if ($count > 0 && strlen($frames) + strlen($frame) > HubConfig::RESPONSE_BYTES) {
                break;
            }
            $frames .= $frame;
            $after = (int)$row['sequence'];
            $count++;
        }
        $stmt->closeCursor();
        return ['binary' => $frames,'epoch' => $epoch,'sequence' => $after,'head' => (int)$doc['sequence'],'frame_count' => $count,'has_more' => $after < (int)$doc['sequence']];
    }

    public function checkpoint(string $id, int $epoch, int $seq, string $payload): array
    {
        $this->note($id, 'update');
        if ($payload === '' || strlen($payload) > HubConfig::CHECKPOINT_BYTES) {
            throw new HubException('payload_too_large', 413);
        }
        return Support::transaction($this->repo->db, function () use ($id, $epoch, $seq, $payload): array {
            $this->note($id, 'update');
            $doc = $this->repo->one('SELECT * FROM eh_note_documents WHERE note_id=?', [$id]);
            if ($epoch !== (int)$doc['epoch'] || $seq < 0 || $seq > (int)$doc['sequence']) {
                throw new HubException('invalid_checkpoint', 409);
            }
            $checksum = hash('sha256', $payload);
            $stmt = $this->repo->db->prepare('INSERT OR IGNORE INTO eh_note_checkpoints(note_id,epoch,sequence,checksum,payload,actor_uuid,created_at) VALUES(?,?,?,?,?,?,?)');
            foreach ([$id,$epoch,$seq,$checksum] as $n => $value) {
                $stmt->bindValue($n + 1, $value, is_int($value) ? \PDO::PARAM_INT : \PDO::PARAM_STR);
            }
            $stmt->bindValue(5, $payload, \PDO::PARAM_LOB);
            $stmt->bindValue(6, $this->access->context->uuid);
            $stmt->bindValue(7, time(), \PDO::PARAM_INT);
            $stmt->execute();
            // Original updates remain available for independent recovery.
            return ['epoch' => $epoch,'sequence' => $seq,'checksum' => $checksum];
        });
    }

    public function latestCheckpoint(string $id): array
    {
        $this->note($id, 'read');
        $doc = $this->repo->one('SELECT * FROM eh_note_documents WHERE note_id=?', [$id]);
        $row = $this->repo->one('SELECT sequence,checksum,payload FROM eh_note_checkpoints WHERE note_id=? AND epoch=? ORDER BY sequence DESC,id DESC LIMIT 1', [$id,$doc['epoch']]);
        if ($row && !hash_equals($row['checksum'], hash('sha256', $row['payload']))) {
            throw new HubException('checkpoint_corrupted', 409);
        }
        return ['binary' => $row['payload'] ?? '','epoch' => (int)$doc['epoch'],'sequence' => (int)($row['sequence'] ?? 0),'head' => (int)$doc['sequence'],'checksum' => $row['checksum'] ?? null];
    }
}
