<?php

/**
 * NOMAD CMS - Editorials Hub PresenceService.
 *
 * Ephemeral, flock-protected presence; reads never create files or write SQLite.
 * Backend-only PHP/SQLite module; resource budgets and authorization are enforced at service boundaries.
 *
 * @package NomadCMS\Services\EditorialsHub\Sync
 */

declare(strict_types=1);

namespace NomadCMS\Services\EditorialsHub\Sync;

use NomadCMS\Services\EditorialsHub\Access\HubAccessPolicy;
use NomadCMS\Services\EditorialsHub\HubConfig;
use NomadCMS\Services\EditorialsHub\HubException;
use NomadCMS\Services\EditorialsHub\Support;

/** Ephemeral, flock-protected presence; reads never create files or write SQLite. */
final class PresenceService
{
    public function __construct(private HubAccessPolicy $access, private ?string $directory = null)
    {
    }
    private function path(string $board): string
    {
        return ($this->directory ?? HubConfig::storageDirectory()) . '/presence/' . hash('sha256', $board) . '.json';
    }

    public function read(string $board): array
    {
        $this->access->board($board);
        $path = $this->path($board);
        if (!is_file($path)) {
            return [];
        }
        $file = fopen($path, 'rb');
        if (!$file || !flock($file, LOCK_SH)) {
            throw new HubException('presence_busy', 503);
        }
        try {
            $data = json_decode((string)stream_get_contents($file, 131072), true) ?? [];
        } finally {
            flock($file, LOCK_UN);
            fclose($file);
        }
        return $this->visible($data);
    }

    public function heartbeat(string $board, array $input, bool $remove = false): array
    {
        $this->access->board($board);
        $path = $this->path($board);
        $dir = dirname($path);
        if (!is_dir($dir) && !mkdir($dir, 0700, true) && !is_dir($dir)) {
            throw new HubException('presence_unavailable', 503);
        }
        $file = fopen($path, 'c+b');
        if (!$file || !flock($file, LOCK_EX)) {
            throw new HubException('presence_busy', 503);
        }
        try {
            $data = json_decode((string)stream_get_contents($file, 131072), true) ?? [];
            $data = array_filter($data, static fn($v)=>$v['expires_at'] > time());
            $user = $this->access->context->uuid;
            if ($remove) {
                unset($data[$user]);
            } else {
                if (count($data) >= 100 && !isset($data[$user])) {
                    throw new HubException('presence_limit', 429);
                }
                $note = $input['note_id'] ?? null;
                if ($note !== null) {
                    $item = $this->access->item((string)$note);
                    $b = $this->access->board($board);
                    if ((int)$item['board_id'] !== (int)$b['id']) {
                        throw new HubException('not_found', 404);
                    }
                }
                $data[$user] = ['user_uuid' => $user,'note_id' => $note,'expires_at' => time() + 60];
            }
            rewind($file);
            ftruncate($file, 0);
            fwrite($file, Support::json($data));
            fflush($file);
            return $this->visible($data);
        } finally {
            flock($file, LOCK_UN);
            fclose($file);
        }
    }

    private function visible(array $data): array
    {
        $result = [];
        foreach ($data as $entry) {
            if ($entry['expires_at'] <= time()) {
                continue;
            }
            if ($entry['note_id'] !== null) {
                try {
                    $this->access->item($entry['note_id']);
                } catch (HubException $error) {
                    $entry['note_id'] = null;
                }
            }
            $result[] = $entry;
        }
        return $result;
    }
}
