<?php

/**
 * NOMAD CMS - Editorials Hub NoteProjectionService.
 *
 * Allowlisted editor AST projection. Never executes attributes supplied inside a CRDT.
 * Backend-only PHP/SQLite module; resource budgets and authorization are enforced at service boundaries.
 *
 * @package NomadCMS\Services\EditorialsHub\Sync
 */

declare(strict_types=1);

namespace NomadCMS\Services\EditorialsHub\Sync;

use NomadCMS\Services\EditorialsHub\Access\HubAccessPolicy;
use NomadCMS\Services\EditorialsHub\HubConfig;
use NomadCMS\Services\EditorialsHub\HubException;
use NomadCMS\Services\EditorialsHub\Notifications\MentionEventService;
use NomadCMS\Services\EditorialsHub\Persistence\ItemRepository;
use NomadCMS\Services\EditorialsHub\Persistence\SyncRepository;
use NomadCMS\Services\EditorialsHub\Support;

/** Allowlisted editor AST projection. Never executes attributes supplied inside a CRDT. */
final class NoteProjectionService
{
    public function __construct(private SyncRepository $repo, private HubAccessPolicy $access, private MentionEventService $mentions)
    {
    }

    public static function normalize(array $ast): array
    {
        $nodes = 0;
        $references = [];
        $visit = static function (array $node, int $depth) use (&$visit, &$nodes, &$references): array {
            if (++$nodes > 5000 || $depth > 24) {
                throw new HubException('projection_complexity');
            }
            $type = $node['type'] ?? '';
            if (!in_array($type, ['doc','paragraph','text','heading','bulletList','orderedList','listItem','blockquote','codeBlock','hardBreak','mention'], true)) {
                throw new HubException('unsupported_editor_node');
            }
            $clean = ['type' => $type];
            if ($type === 'text') {
                $clean['text'] = Support::text($node['text'] ?? '', 65536);
                if (!is_array($node['marks'] ?? []) || count($node['marks'] ?? []) > 5) {
                    throw new HubException('projection_complexity');
                }
                $marks = []; foreach ($node['marks'] ?? [] as $mark) {
                    $kind = $mark['type'] ?? '';
                    if (!in_array($kind, ['bold','italic','strike','code','link'], true)) {
                        throw new HubException('unsupported_editor_mark');
                    }
                    $m = ['type' => $kind];
                    if ($kind === 'link') {
                        $url = Support::text($mark['attrs']['href'] ?? '', 2048);
                        if (!preg_match('~^(https?://|mailto:|/(?!/))~i', $url) || preg_match('/[\x00-\x20]/', $url)) {
                            throw new HubException('unsafe_url');
                        }
                        $m['attrs'] = ['href' => $url];
                    }
                    $marks[] = $m;
                }
                if ($marks) {
                    $clean['marks'] = $marks;
                }
            }
            if ($type === 'heading') {
                $level = (int)($node['attrs']['level'] ?? 2);
                if ($level < 1 || $level > 6) {
                    throw new HubException('invalid_heading');
                } $clean['attrs'] = ['level' => $level];
            }
            if ($type === 'mention') {
                $id = Support::text($node['attrs']['reference_id'] ?? '', 128);
                $clean['attrs'] = ['reference_id' => $id];
                $references[] = $id;
            }
            if (isset($node['content'])) {
                if (!is_array($node['content']) || in_array($type, ['text','mention','hardBreak'], true)) {
                    throw new HubException('invalid_editor_node');
                }
                $clean['content'] = array_map(static fn($child)=>is_array($child) ? $visit($child, $depth + 1) : throw new HubException('invalid_editor_node'), $node['content']);
            }
            return $clean;
        };
        if (($ast['type'] ?? '') !== 'doc') {
            throw new HubException('invalid_document');
        }
        $clean = $visit($ast, 0);
        $json = Support::json($clean);
        if (strlen($json) > HubConfig::RESPONSE_BYTES - 4096) {
            throw new HubException('payload_too_large', 413);
        }
        return ['ast' => $clean,'references' => array_values(array_unique($references)),'plain_text' => self::plain($clean)];
    }

    public static function plain(array $node): string
    {
        if ($node['type'] === 'text') {
            return $node['text'];
        }
        if ($node['type'] === 'hardBreak') {
            return "\n";
        }
        $text = implode('', array_map([self::class,'plain'], $node['content'] ?? []));
        return $text . (in_array($node['type'], ['paragraph','heading','listItem','codeBlock'], true) ? "\n" : '');
    }

    public static function html(array $node, ?callable $renderMention = null): string
    {
        if ($node['type'] === 'text') {
            $text = htmlspecialchars($node['text'], ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
            foreach ($node['marks'] ?? [] as $m) {
                $text = match ($m['type']) {
                    'bold'=>'<strong>' . $text . '</strong>','italic'=>'<em>' . $text . '</em>','strike'=>'<s>' . $text . '</s>','code'=>'<code>' . $text . '</code>',
                    'link'=>'<a href="' . htmlspecialchars($m['attrs']['href'], ENT_QUOTES, 'UTF-8') . '" rel="noopener noreferrer">' . $text . '</a>',default=>$text
                };
            }
            return $text;
        }
        if ($node['type'] === 'hardBreak') {
            return '<br>';
        }
        // Internal mention identity never becomes a public CMS admin URL.
        if ($node['type'] === 'mention') {
            return $renderMention ? $renderMention($node['attrs']['reference_id']) : '';
        }
        $body = implode('', array_map(static fn(array $child): string => self::html($child, $renderMention), $node['content'] ?? []));
        $tag = match ($node['type']) {
            'paragraph'=>'p','heading'=>'h' . ($node['attrs']['level'] ?? 2),'bulletList'=>'ul','orderedList'=>'ol','listItem'=>'li','blockquote'=>'blockquote','codeBlock'=>'pre',default=>null
        };
        return $tag ? '<' . $tag . '>' . $body . '</' . $tag . '>' : $body;
    }

    public function get(string $id): array
    {
        $this->access->item($id);
        $row = $this->repo->one('SELECT epoch,sequence,ast,checksum FROM eh_note_projections WHERE note_id=?', [$id]);
        if (!$row) {
            throw new HubException('not_found', 404);
        } $row['ast'] = json_decode($row['ast'], true);
        return $row;
    }

    public function save(string $id, array $input): array
    {
        $this->access->item($id, 'update');
        $projection = self::normalize($input['ast'] ?? []);
        return Support::transaction($this->repo->db, function () use ($id, $input, $projection): array {
            $item = $this->access->item($id, 'update');
            $doc = $this->repo->one('SELECT * FROM eh_note_documents WHERE note_id=?', [$id]);
            if (!$doc || (int)($input['epoch'] ?? 0) !== (int)$doc['epoch'] || (int)($input['sequence'] ?? -1) !== (int)$doc['sequence']) {
                throw new HubException('projection_outdated', 409);
            }
            $json = Support::json($projection['ast']);
            $hash = hash('sha256', $json);
            $old = $this->repo->one('SELECT sequence,checksum FROM eh_note_projections WHERE note_id=?', [$id]);
            if ($old && (int)$old['sequence'] === (int)$doc['sequence'] && hash_equals($old['checksum'], $hash)) {
                return ['checksum' => $hash,'sequence' => (int)$doc['sequence'],'metadata_revision' => (int)$item['metadata_revision']];
            }
            $this->mentions->record($item, $projection['references'], 'note:' . $id);
            $this->repo->run('INSERT INTO eh_note_projections VALUES(?,?,?,?,?,?,?,?) ON CONFLICT(note_id) DO UPDATE SET epoch=excluded.epoch,sequence=excluded.sequence,ast=excluded.ast,plain_text=excluded.plain_text,checksum=excluded.checksum,actor_uuid=excluded.actor_uuid,updated_at=excluded.updated_at', [$id,$doc['epoch'],$doc['sequence'],$json,$projection['plain_text'],$hash,$this->access->context->uuid,time()]);
            $preview = mb_substr(trim($projection['plain_text']), 0, 320);
            $this->repo->run('UPDATE eh_items SET preview=?,metadata_revision=metadata_revision+1,updated_at=? WHERE uuid=?', [$preview,time(),$id]);
            $g = ItemRepository::boundsOf($item);
            (new ItemRepository($this->repo->db))->touchTiles((int)$item['board_id'], $g, $g, 'note', $item['owner_uuid']);
            $this->repo->change((int)$item['board_id'], 'note.projection', $id, (int)$doc['sequence'], ['item_id' => $id], $g, $g);
            return ['checksum' => $hash,'sequence' => (int)$doc['sequence'],'metadata_revision' => (int)$item['metadata_revision'] + 1];
        });
    }
}
