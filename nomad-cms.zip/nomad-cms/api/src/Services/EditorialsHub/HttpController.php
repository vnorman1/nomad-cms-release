<?php

/**
 * NOMAD CMS - Editorials Hub HttpController.
 *
 * Thin route dispatch, bounded input/output and authenticated binary streaming.
 * Backend-only PHP/SQLite module; resource budgets and authorization are enforced at service boundaries.
 *
 * @package NomadCMS\Services\EditorialsHub
 */

declare(strict_types=1);

namespace NomadCMS\Services\EditorialsHub;

use NomadCMS\Database\AuthDatabase;
use NomadCMS\Database\MassiveDatabase;
use NomadCMS\Middleware\AuthMiddleware;
use NomadCMS\Middleware\CSRFMiddleware;
use NomadCMS\Services\EditorialsHub\Contracts\HubRequestContext;
use NomadCMS\Services\EditorialsHub\Sync\PresenceService;

/** Thin route dispatch, bounded input/output and authenticated binary streaming. */
final class HttpController
{
    private const METHODS = [
        'boards' => ['GET','POST'],'board' => ['GET','PATCH','DELETE'],'members' => ['GET','POST','DELETE'],'statuses' => ['GET','PUT'],
        'items' => ['POST'],'item' => ['GET','PATCH','DELETE'],'viewport' => ['GET'],'tickets' => ['GET'],'ticket_move' => ['PATCH'],'geometry' => ['PATCH'],
        'connectors' => ['POST'],'connector' => ['DELETE'],'threads' => ['GET','POST'],'thread' => ['DELETE'],'messages' => ['GET','POST'],'message' => ['PATCH','DELETE'],
        'changes' => ['GET'],'presence' => ['GET','POST','DELETE'],'updates' => ['GET','POST'],'checkpoint' => ['GET','POST'],'projection' => ['GET','PUT'],
        'suggest' => ['GET'],'users' => ['GET'],'references' => ['POST'],'reference' => ['GET'],'proposals' => ['POST'],'proposal' => ['GET','PATCH'],
        'preview' => ['POST'],'apply' => ['POST'],'attachments' => ['POST'],'content' => ['GET'],
        'annotations' => ['GET','POST'],'board_annotations' => ['GET'],'target_annotations' => ['GET'],'annotation' => ['GET'],
    ];
    private const GROUPS = [
        'boards' => ['boards','board','members','statuses'], 'items' => ['items','item','viewport','tickets','ticket_move','geometry','connectors','connector'],
        'threads' => ['threads','thread','messages','message'], 'sync' => ['changes','presence','updates','checkpoint','projection'],
        'targets' => ['suggest','users','references','reference','proposals','proposal'], 'transfers' => ['preview','apply'], 'attachments' => ['attachments','content'],
        'annotations' => ['annotations','board_annotations','target_annotations','annotation'],
    ];

    public static function dispatch(string $group): void
    {
        try {
            $action = (string)($_GET['_eh_action'] ?? $group);
            $method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
            if (!in_array($action, self::GROUPS[$group] ?? [], true)) {
                throw new HubException('not_found', 404);
            }
            if (!in_array($method, self::METHODS[$action], true)) {
                header('Allow: ' . implode(', ', self::METHODS[$action]));
                throw new HubException('method_not_allowed', 405);
            }
            $hub = MassiveDatabase::getInstance(true);
            if (!EditorialsHubModule::installed($hub)) {
                throw new HubException('migration_required', 503);
            }
            $auth = AuthDatabase::getInstance(false);
            if (!$auth->query("SELECT 1 FROM sqlite_master WHERE type='table' AND name='eh_auth_migrations'")->fetchColumn() || !$auth->query('SELECT 1 FROM eh_auth_migrations WHERE version=2')->fetchColumn()) {
                throw new HubException('migration_required', 503);
            }
            $user = AuthMiddleware::requireAuth();
            if (($user->source ?? '') === 'api_key') {
                throw new HubException('human_session_required', 403);
            }
            // Fail closed even if the legacy auth middleware tolerates a DB lookup failure.
            $lookup = $auth->prepare('SELECT role_slug,role,is_admin,is_new_user,locked_until FROM users WHERE uuid=?');
            $lookup->execute([$user->uuid ?? '']);
            $fresh = $lookup->fetch();
            $lookup->closeCursor();
            if (!$fresh || $fresh['is_new_user'] || ($fresh['locked_until'] !== null && strtotime($fresh['locked_until']) > time())) {
                throw new HubException('unauthorized', 401);
            }
            foreach (['role_slug','role','is_admin','is_new_user'] as $field) {
                $user->$field = $fresh[$field];
            }
            if ($method !== 'GET') {
                CSRFMiddleware::validateForSession();
            }
            if (session_status() === PHP_SESSION_ACTIVE) {
                session_write_close();
            }
            $secret = (string)($_ENV['ENCRYPTION_KEY'] ?? '');
            if ($secret === '') {
                throw new HubException('configuration_required', 503);
            }
            $context = HubRequestContext::fromUser($user, hash_hmac('sha256', 'editorials.cursor.v1', $secret));
            $module = new EditorialsHubModule($hub, $context, $auth);
            // Loading a board must not spend the tokens reserved for edits.
            // Private streams have their own budget so images cannot starve metadata reads.
            $bucket = match (true) {
                $action === 'viewport' => 'viewport',
                in_array($action, ['changes', 'presence'], true) => 'poll',
                $action === 'content' => 'content',
                $method === 'GET' => 'read',
                $action === 'updates' => 'note_update',
                $action === 'attachments' => 'upload',
                default => 'mutation',
            };
            (new AtomicRateLimiter())->consume($context->uuid, $bucket);
            $binary = in_array($action, ['updates','checkpoint'], true) && $method === 'POST';
            $input = ($method === 'GET' || $action === 'attachments' || $binary) ? [] : self::body();
            $result = self::execute($module, $action, $method, $input);
            if (isset($result['binary'])) {
                header('Content-Type: application/octet-stream');
                header('Cache-Control: private, no-store');
                foreach (['epoch','sequence','head','frame_count','has_more','checksum'] as $key) {
                    if (isset($result[$key])) {
                        header('X-Document-' . str_replace('_', '-', ucwords($key, '_')) . ': ' . (is_bool($result[$key]) ? ($result[$key] ? '1' : '0') : $result[$key]));
                    }
                }
                echo $result['binary'];
                return;
            }
            if (isset($result['path'])) {
                header('Content-Type: ' . $result['mime']);
                header('Content-Length: ' . $result['size']);
                header('Cache-Control: private, no-store');
                header('X-Content-Type-Options: nosniff');
                header("Content-Disposition: inline; filename*=UTF-8''" . rawurlencode($result['filename']));
                $stream = fopen($result['path'], 'rb');
                if (!$stream) {
                    throw new HubException('not_found', 404);
                } fpassthru($stream);
                fclose($stream);
                return;
            }
            $response = isset($result['success']) ? $result : Support::page($result);
            header('Content-Type: application/json; charset=utf-8');
            header('Cache-Control: private, no-cache');
            if (isset($response['meta']['etag'])) {
                header('ETag: ' . $response['meta']['etag']);
                if (($_SERVER['HTTP_IF_NONE_MATCH'] ?? '') === $response['meta']['etag']) {
                    http_response_code(304);
                    return;
                }
            }
            $json = Support::json($response);
            if (strlen($json) > HubConfig::RESPONSE_BYTES) {
                throw new HubException('response_limit_exceeded', 503);
            } echo $json;
        } catch (HubException $error) {
            self::error($error);
        } catch (\TypeError | \ValueError | \JsonException $error) {
            self::error(new HubException('invalid_input', 422));
        } catch (\NomadCMS\Database\OptimisticLockException $error) {
            self::error(new HubException('version_conflict', 409));
        } catch (\PDOException $error) {
            $busy = str_contains($error->getMessage(), 'locked') || str_contains($error->getMessage(), 'busy');
            error_log('[editorials.database] ' . $error->getMessage());
            self::error(new HubException($busy ? 'database_busy' : 'database_unavailable', 503, ['retry_after' => 1]));
        } catch (\Throwable $error) {
            error_log('[editorials] ' . $error->getMessage());
            self::error(new HubException('internal_error', 500));
        }
    }

    private static function error(HubException $error): void
    {
        http_response_code($error->status);
        header('Content-Type: application/json; charset=utf-8');
        header('Cache-Control: private, no-store');
        if (isset($error->details['retry_after'])) {
            header('Retry-After: ' . $error->details['retry_after']);
        }
        echo Support::json(['success' => false,'error' => $error->errorCode,'code' => $error->errorCode,'details' => $error->details]);
    }

    private static function body(int $max = 262144): array
    {
        $raw = self::binaryBody($max);
        try {
            $value = json_decode($raw, true, 32, JSON_THROW_ON_ERROR);
        } catch (\JsonException $error) {
            throw new HubException('invalid_json', 400);
        }
        if (!is_array($value) || array_is_list($value) && $value !== []) {
            throw new HubException('invalid_json', 400);
        } return $value;
    }

    private static function binaryBody(int $max): string
    {
        if ((int)($_SERVER['CONTENT_LENGTH'] ?? 0) > $max) {
            throw new HubException('payload_too_large', 413);
        }
        $stream = fopen('php://input', 'rb');
        $raw = stream_get_contents($stream, $max + 1);
        fclose($stream);
        if ($raw === false || strlen($raw) > $max) {
            throw new HubException('payload_too_large', 413);
        } return $raw;
    }

    private static function execute(EditorialsHubModule $m, string $action, string $method, array $input): array
    {
        $board = (string)($_GET['board'] ?? '');
        $item = (string)($_GET['item'] ?? '');
        $thread = (string)($_GET['thread'] ?? '');
        $key = (string)($_SERVER['HTTP_IDEMPOTENCY_KEY'] ?? '');
        $revision = (int)($input['expected_revision'] ?? $_GET['expected_revision'] ?? 0);
        switch ($action) {
            case 'boards':
                return $method === 'GET' ? $m->boards()->list($_GET) : $m->boards()->create($input, $key);
            case 'board':
                if ($method === 'GET') {
                    return $m->boards()->get($board);
                } if ($method === 'PATCH') {
                    return $m->boards()->update($board, $input);
                } $m->boards()->delete($board, $revision);
                return [];
            case 'members':
                if ($method === 'GET') {
                    return $m->boards()->members($board);
                } $m->boards()->member($board, (string)($input['user_uuid'] ?? ''), $method === 'POST');
                return [];
            case 'statuses':
                return $method === 'GET' ? $m->boards()->get($board)['statuses'] : $m->boards()->statuses($board, $input);
            case 'items':
                return $m->items()->create($board, $input, $key);
            case 'item':
                if ($method === 'GET') {
                    return $m->items()->get($item);
                } if ($method === 'PATCH') {
                    return $m->items()->update($item, $input);
                } $m->items()->delete($item, $revision);
                return [];
            case 'viewport':
                return $m->viewport()->read($board, $_GET);
            case 'tickets':
                return $m->tickets()->read($board, $_GET);
            case 'ticket_move':
                return $m->items()->moveTicket($board, $input);
            case 'geometry':
                return $m->items()->geometryBatch($board, $input);
            case 'connectors':
                return $m->connectors()->create($board, $input, $key);
            case 'connector':
                $m->connectors()->delete($board, (string)($_GET['connector'] ?? ''), $revision);
                return [];
            case 'threads':
                return $method === 'GET' ? $m->threads()->list($item, $_GET) : $m->threads()->create($item, $input, $key);
            case 'annotations':
                return $method === 'GET' ? $m->annotations()->forItem($item, $_GET) : $m->annotations()->create($item, $input, $key);
            case 'board_annotations':
                return $m->annotations()->forBoard($board, $_GET);
            case 'target_annotations':
                $query = $_GET;
                if (is_string($query['target'] ?? null)) {
                    $query['target'] = json_decode($query['target'], true, 32, JSON_THROW_ON_ERROR);
                }
                return $m->annotations()->forTarget($query);
            case 'annotation':
                return $m->annotations()->get((string)($_GET['annotation'] ?? ''));
            case 'thread':
                $m->threads()->delete($thread, $revision);
                return [];
            case 'messages':
                return $method === 'GET' ? $m->threads()->messages($thread, $_GET) : $m->threads()->reply($thread, $input, $key);
            case 'message':
                $id = (string)($_GET['message'] ?? '');
                if ($method === 'PATCH') {
                    return $m->threads()->editMessage($id, $input);
                } $m->threads()->deleteMessage($id, $revision);
                return [];
            case 'changes':
                return $m->changes()->read($board, $_GET);
            case 'presence':
                $presence = new PresenceService($m->access);
                return $method === 'GET' ? $presence->read($board) : $presence->heartbeat($board, $input, $method === 'DELETE');
            case 'updates':
                $note = (string)($_GET['note'] ?? '');
                return $method === 'GET' ? $m->notes()->pull($note, (int)($_GET['epoch'] ?? 1), (int)($_GET['after'] ?? 0)) : $m->notes()->append($note, (int)($_SERVER['HTTP_X_DOCUMENT_EPOCH'] ?? 1), $key, self::binaryBody(HubConfig::UPDATE_BYTES), (int)($_SERVER['HTTP_X_DOCUMENT_FORMAT'] ?? 1));
            case 'checkpoint':
                $note = (string)($_GET['note'] ?? '');
                return $method === 'GET' ? $m->notes()->latestCheckpoint($note) : $m->notes()->checkpoint($note, (int)($_SERVER['HTTP_X_DOCUMENT_EPOCH'] ?? 1), (int)($_SERVER['HTTP_X_DOCUMENT_SEQUENCE'] ?? -1), self::binaryBody(HubConfig::CHECKPOINT_BYTES));
            case 'projection':
                $note = (string)($_GET['note'] ?? '');
                return $method === 'GET' ? $m->projections()->get($note) : $m->projections()->save($note, $input);
            case 'suggest':
                return $m->targets()->suggest($board, $_GET);
            case 'users':
                return $m->users()->suggest($board, (string)($_GET['q'] ?? ''), ($_GET['invite'] ?? '0') === '1');
            case 'references':
                return $m->references()->bind($input, $key);
            case 'reference':
                return $m->references()->resolve((string)($_GET['reference'] ?? ''));
            case 'proposals':
                return $m->references()->proposal($input, $key);
            case 'proposal':
                return $method === 'GET' ? $m->references()->getProposal((string)($_GET['proposal'] ?? '')) : $m->references()->updateProposal((string)($_GET['proposal'] ?? ''), $input);
            case 'preview':
                return $m->transfers()->preview($input);
            case 'apply':
                return $m->transfers()->apply((string)($input['plan_id'] ?? ''), $key, (string)($input['checksum'] ?? ''));
            case 'attachments':
                $file = $_FILES['file'] ?? null;
                $thumbnail = $_FILES['thumbnail'] ?? null;
                if (!$file || ($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK || !is_uploaded_file($file['tmp_name'])) {
                    throw new HubException('invalid_upload');
                }
                if ($thumbnail && (($thumbnail['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK || !is_uploaded_file($thumbnail['tmp_name']))) {
                    throw new HubException('invalid_thumbnail');
                }
                return $m->attachments()->upload($board, $file['tmp_name'], $file['name'], $key, $thumbnail['tmp_name'] ?? null);
            case 'content':
                return $m->attachments()->content((string)($_GET['attachment'] ?? ''), ($_GET['thumbnail'] ?? '0') === '1');
        }
        throw new HubException('not_found', 404);
    }
}
