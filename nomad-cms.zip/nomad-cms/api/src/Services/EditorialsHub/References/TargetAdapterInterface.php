<?php

/**
 * NOMAD CMS - Editorials Hub TargetAdapterInterface.
 *
 * Explicit target families; each adapter authorizes every lookup independently.
 * Backend-only PHP/SQLite module; resource budgets and authorization are enforced at service boundaries.
 *
 * @package NomadCMS\Services\EditorialsHub\References
 */

declare(strict_types=1);

namespace NomadCMS\Services\EditorialsHub\References;

use NomadCMS\Services\EditorialsHub\Contracts\TargetDescriptor;

/** Explicit target families; each adapter authorizes every lookup independently. */
interface TargetAdapterInterface
{
    public function resolve(TargetDescriptor $target): array;
    public function suggest(array $query): array;
}
