<?php

/**
 * NOMAD CMS - Editorials Hub TargetRegistry.
 *
 * Per-request registry with an active schema overlay and an explicit adapter map.
 * Backend-only PHP/SQLite module; resource budgets and authorization are enforced at service boundaries.
 *
 * @package NomadCMS\Services\EditorialsHub\References
 */

declare(strict_types=1);

namespace NomadCMS\Services\EditorialsHub\References;

use NomadCMS\Services\EditorialsHub\Access\HubAccessPolicy;
use NomadCMS\Services\EditorialsHub\Contracts\TargetDescriptor;
use NomadCMS\Services\EditorialsHub\HubException;
use NomadCMS\Services\EditorialsHub\References\Adapters\SlotTargetAdapter;
use NomadCMS\Services\EditorialsHub\References\Adapters\MediaTargetAdapter;
use NomadCMS\Services\EditorialsHub\References\Adapters\ModuleTargetAdapter;
use NomadCMS\Services\EditorialsHub\Support;
use PDO;

/** Per-request registry with an active schema overlay and an explicit adapter map. */
final class TargetRegistry
{
    private array $adapters;
    public function __construct(public readonly SlotTargetAdapter $slots, public readonly MediaTargetAdapter $media, ModuleTargetAdapter $modules, private UserDirectoryService $users, private HubAccessPolicy $access, private PDO $hub)
    {
        $this->adapters = ['slot' => $slots,'media' => $media,'module' => $modules];
    }

    public static function schema(PDO $content): array
    {
        $schema = \NomadCMS\Services\Schema\SchemaProvider::schema();
        return $schema;
    }

    public function resolve(TargetDescriptor $target, string $boardUuid): array
    {
        $b = $this->access->board($boardUuid);
        if ($target->kind === 'user') {
            $user = $this->users->find($target->item ?? '');
            if (!$user || $target->field !== null || $target->path !== []) {
                throw new HubException('target_unavailable', 404);
            }
            if ($b['visibility'] === 'private' && $user['uuid'] !== $b['owner_uuid']) {
                $repo = new \NomadCMS\Services\EditorialsHub\Persistence\BoardRepository($this->accessDb());
                if (!$repo->member((int)$b['id'], $user['uuid'])) {
                    throw new HubException('target_unavailable', 404);
                }
            }
            return ['available' => true,'target' => $target->toArray(),'label' => $user['name'],'writable' => false,'navigation' => null,'preview' => ['kind' => 'user', 'text' => $user['name']]];
        }
        return $this->adapters[$target->kind]->resolve($target);
    }

    private function accessDb(): PDO
    {
        // Both SlotTargetAdapter and Hub persistence share massive.sqlite.
        return $this->hub;
    }

    /** Resolve a CMS-side reverse lookup without granting access to any board. */
    public function resolveContentTarget(TargetDescriptor $target): array
    {
        if (!isset($this->adapters[$target->kind])) {
            throw new HubException('target_unavailable', 404);
        }
        return $this->adapters[$target->kind]->resolve($target);
    }

    public function suggest(string $board, array $query): array
    {
        $this->access->board($board);
        Support::text($query['q'] ?? '', 128);
        $kind = $query['kind'] ?? null;
        if ($kind === 'user') {
            return $this->users->suggest($board, $query['q'] ?? '');
        }
        if ($kind !== null) {
            if (!isset($this->adapters[$kind])) {
                throw new HubException('invalid_target_kind');
            } return $this->suggestionPreviews($board, $this->adapters[$kind]->suggest($query));
        }
        if (isset($query['slot'])) {
            return $this->suggestionPreviews($board, $this->slots->suggest($query));
        }
        return $this->suggestionPreviews($board, array_slice([...$this->users->suggest($board, $query['q'] ?? ''),...$this->slots->suggest($query),...$this->adapters['module']->suggest($query)], 0, 20));
    }

    private function suggestionPreviews(string $board, array $rows): array
    {
        $result = [];
        foreach ($rows as $row) {
            if (!isset($row['target'])) {
                $row['preview'] = ['kind' => 'user', 'text' => $row['name'] ?? ''];
                $result[] = $row;
                continue;
            }
            try {
                $resolved = $this->resolve(TargetDescriptor::fromArray($row['target']), $board);
                if (isset($resolved['preview'])) {
                    $row['preview'] = $resolved['preview'];
                }
                $result[] = $row;
            } catch (HubException $error) {
                if (!in_array($error->status, [403, 404], true)) {
                    throw $error;
                }
            }
        }
        return $result;
    }

    /** Export only server-bound media mentions; internal user/CMS links stay private. */
    public function exportMention(string $reference, string $board, ?string $sourceItem): string
    {
        if ($sourceItem === null) {
            return '';
        }
        $allowedBoard = $this->access->board($board);
        $statement = $this->hub->prepare('SELECT target FROM eh_references WHERE id=? AND item_id=? AND board_id=?');
        $statement->execute([$reference, $sourceItem, $allowedBoard['id']]);
        $raw = $statement->fetchColumn();
        $statement->closeCursor();
        if (!$raw) {
            throw new HubException('reference_unavailable', 404);
        }
        $target = TargetDescriptor::fromArray(json_decode($raw, true));
        $resolved = $this->resolve($target, $board);
        $preview = $resolved['preview'] ?? [];
        if (!in_array($preview['kind'] ?? '', ['image', 'gallery'], true)) {
            return '';
        }
        $html = '';
        $images = $target->kind === 'slot' ? $this->slots->exportImages($target) : ($preview['images'] ?? []);
        foreach ($images as $image) {
            $html .= '<img src="' . htmlspecialchars($image['url'], ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') . '" alt="' . htmlspecialchars($image['alt'] ?? '', ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') . '">';
        }
        return $html;
    }
}
