<?php

/**
 * NOMAD CMS - Editorials Hub ModuleTargetAdapter.
 *
 * Explicit navigation-only module allowlist, including Hungarian log aliases.
 * Backend-only PHP/SQLite module; resource budgets and authorization are enforced at service boundaries.
 *
 * @package NomadCMS\Services\EditorialsHub\References\Adapters
 */

declare(strict_types=1);

namespace NomadCMS\Services\EditorialsHub\References\Adapters;

use NomadCMS\Services\EditorialsHub\Contracts\HubRequestContext;
use NomadCMS\Services\EditorialsHub\Contracts\TargetDescriptor;
use NomadCMS\Services\EditorialsHub\HubException;
use NomadCMS\Services\EditorialsHub\References\TargetAdapterInterface;

/** Explicit navigation-only module allowlist, including Hungarian log aliases. */
final class ModuleTargetAdapter implements TargetAdapterInterface
{
    private const MODULES = [
        'logs' => [
            'en' => 'Logs',
            'hu' => 'Napló',
            'aliases' => 'naplo log logs',
            'permission' => 'logs:read:*',
            'navigation' => '/logs',
        ],
        'smtp' => [
            'en' => 'SMTP',
            'hu' => 'SMTP',
            'aliases' => 'mail levelezes postazo',
            'permission' => 'mail:manage:*',
            'navigation' => '/settings',
        ],
        'settings' => [
            'en' => 'Settings',
            'hu' => 'Beállítások',
            'aliases' => 'beallitasok beallitas setting settings',
            'permission' => 'system:read:*',
            'navigation' => '/settings',
        ],
        'analytics' => [
            'en' => 'Analytics',
            'hu' => 'Analitika',
            'aliases' => 'analitika analytic analytics',
            'permission' => 'analytics:read:*',
            'navigation' => '/analytics',
        ],
        'forms' => [
            'en' => 'Forms',
            'hu' => 'Űrlapok',
            'aliases' => 'urlapok urlap form forms',
            'permission' => 'forms:read:*',
            'navigation' => '/forms',
        ],
        'webhooks' => [
            'en' => 'Webhooks',
            'hu' => 'Webhookok',
            'aliases' => 'webhook webhookok webhooks',
            'permission' => 'webhooks:read:*',
            'navigation' => '/webhooks',
        ],
        'users' => [
            'en' => 'Users',
            'hu' => 'Felhasználók',
            'aliases' => 'felhasznalok felhasznalo user users',
            'permission' => 'users:read:*',
            'navigation' => '/users',
        ],
        'schema' => [
            'en' => 'Schema',
            'hu' => 'Séma',
            'aliases' => 'sema schema',
            'permission' => 'system:read:*',
            'navigation' => '/schema',
        ],
    ];

    public function __construct(private HubRequestContext $context)
    {
    }

    private function resolveLocale(?string $preferred = null): string
    {
        $raw = strtolower((string) (
            $preferred
            ?? $_GET['lang']
            ?? $_GET['locale']
            ?? $_SERVER['HTTP_X_LANGUAGE']
            ?? $_SERVER['HTTP_ACCEPT_LANGUAGE']
            ?? 'en'
        ));

        return str_starts_with($raw, 'hu') ? 'hu' : 'en';
    }

    public function resolve(TargetDescriptor $target, ?string $locale = null): array
    {
        $key = in_array($target->slot, ['napló', 'naplo'], true) ? 'logs' : $target->slot;
        $module = self::MODULES[$key] ?? null;

        if (!$module || !$this->context->has($module['permission']) || $target->field !== null || $target->item !== null || $target->path !== []) {
            throw new HubException('target_unavailable', 404);
        }

        $lang = $this->resolveLocale($locale ?? $target->locale);

        return [
            'available' => true,
            'target' => [
                'kind' => 'module',
                'slot' => $key,
            ],
            'label' => $module[$lang],
            'writable' => false,
            'navigation' => $module['navigation'],
        ];
    }

    public function suggest(array $query): array
    {
        $locale = $this->resolveLocale($query['lang'] ?? $query['locale'] ?? null);
        $q = trim((string) ($query['q'] ?? ''));
        $out = [];

        foreach (self::MODULES as $key => $module) {
            if (!$this->context->has($module['permission'])) {
                continue;
            }

            $searchTarget = $key . ' ' . $module['en'] . ' ' . $module['hu'] . ' ' . $module['aliases'];
            if ($q === '' || mb_stripos($searchTarget, $q) !== false) {
                $out[] = $this->resolve(new TargetDescriptor('module', $key), $locale);
            }
        }

        return $out;
    }
}
