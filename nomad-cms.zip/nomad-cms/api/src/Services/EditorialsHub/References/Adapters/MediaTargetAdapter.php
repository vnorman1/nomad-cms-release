<?php

/**
 * NOMAD CMS - Editorials Hub MediaTargetAdapter.
 *
 * Metadata-only media targets. Original bytes and owner/security fields are never editable.
 * Backend-only PHP/SQLite module; resource budgets and authorization are enforced at service boundaries.
 *
 * @package NomadCMS\Services\EditorialsHub\References\Adapters
 */

declare(strict_types=1);

namespace NomadCMS\Services\EditorialsHub\References\Adapters;

use NomadCMS\Services\EditorialsHub\Contracts\HubRequestContext;
use NomadCMS\Services\EditorialsHub\Contracts\TargetDescriptor;
use NomadCMS\Services\EditorialsHub\HubException;
use NomadCMS\Services\EditorialsHub\References\TargetAdapterInterface;
use PDO;

/** Metadata-only media targets. Original bytes and owner/security fields are never editable. */
final class MediaTargetAdapter implements TargetAdapterInterface
{
    public function __construct(private PDO $db, private HubRequestContext $context)
    {
    }
    public function record(string $filename): array
    {
        $stmt = $this->db->prepare('SELECT filename,title,caption,tags,alt_texts,uploaded_by,updated_at,mime_type,is_external,dimensions FROM media_meta WHERE filename=?');
        $stmt->execute([$filename]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $stmt->closeCursor();
        if (!$row || (!$this->context->has('media:read:*') && (! $this->context->has('media:read:own') || $row['uploaded_by'] !== $this->context->uuid))) {
            throw new HubException('target_unavailable', 404);
        }
        return $row;
    }

    /** Derive image URLs and display metadata only from an authorized media record. */
    public function image(string $filename, ?string $locale = null): array
    {
        $row = $this->record($filename);
        $mime = $row['mime_type'] ?: match (strtolower(pathinfo((string)parse_url($filename, PHP_URL_PATH), PATHINFO_EXTENSION))) {
            'jpg', 'jpeg' => 'image/jpeg',
            'png' => 'image/png',
            'webp' => 'image/webp',
            'gif' => 'image/gif',
            'avif' => 'image/avif',
            default => '',
        };
        if (!in_array($mime, ['image/png', 'image/jpeg', 'image/webp', 'image/gif', 'image/avif'], true)) {
            throw new HubException('image_target_incompatible');
        }
        if ($row['is_external']) {
            if (!preg_match('~^https?://~i', $filename) || preg_match('/[\x00-\x20]/', $filename)) {
                throw new HubException('invalid_media');
            }
            $url = $filename;
        } else {
            $url = '/api/uploads/' . rawurlencode($filename);
        }
        $alts = json_decode($row['alt_texts'] ?: '{}', true);
        $alt = is_array($alts) ? ($alts[$locale ?? 'hu'] ?? $alts['en'] ?? reset($alts) ?: '') : '';
        $dimensions = json_decode($row['dimensions'] ?: '{}', true);
        $image = ['url' => $url, 'alt' => is_string($alt) ? mb_substr($alt, 0, 512) : '', 'mime' => $mime];
        foreach (['width', 'height'] as $dimension) {
            if (is_numeric($dimensions[$dimension] ?? null) && $dimensions[$dimension] > 0) {
                $image[$dimension] = (int)$dimensions[$dimension];
            }
        }
        return $image;
    }

    public function preview(string $filename, ?string $locale = null): ?array
    {
        try {
            $image = $this->image($filename, $locale);
            unset($image['mime']);
            return ['kind' => 'image', 'images' => [$image]];
        } catch (HubException $error) {
            return null;
        }
    }
    public function resolve(TargetDescriptor $target): array
    {
        $row = $this->record($target->item ?? '');
        $field = $target->field;
        if ($field !== null && !in_array($field, ['title','caption','tags','alt'], true)) {
            throw new HubException('target_unavailable', 404);
        }
        $value = $field === null ? null : ($field === 'alt' ? json_decode($row['alt_texts'], true) : ($field === 'tags' ? json_decode($row['tags'], true) : $row[$field]));
        if ($target->locale !== null) {
            if ($field !== 'alt') {
                throw new HubException('invalid_locale');
            } $value = $value[$target->locale] ?? null;
        }
        foreach ($target->path as $p) {
            if (!is_array($value) || !array_key_exists($p, $value)) {
                throw new HubException('target_unavailable', 404);
            } $value = $value[$p];
        }
        $result = ['available' => true,'target' => $target->toArray(),'label' => $field ?? ($row['title'] ?: $row['filename']),'type' => $field === 'tags' ? 'multiselect' : 'text','value' => $value,
            'writable' => $field !== null && $target->path === [] && ($this->context->has('media:update:*') || ($row['uploaded_by'] === $this->context->uuid && $this->context->has('media:update:own'))),
            'navigation' => '/media?file=' . rawurlencode($row['filename'])];
        if ($field === null) {
            $preview = $this->preview($row['filename'], $target->locale);
            if ($preview !== null) {
                $result['preview'] = $preview;
            }
        } elseif (is_scalar($value)) {
            $result['preview'] = ['kind' => 'text', 'text' => mb_substr(strip_tags((string)$value), 0, 320)];
        }
        return $result;
    }
    public function suggest(array $query): array
    {
        if (!empty($query['item'])) {
            $this->record($query['item']);
            return array_map(static fn($f)=>['target' => ['kind' => 'media','item' => $query['item'],'field' => $f],'label' => $f], ['title','caption','tags','alt']);
        }
        if (!$this->context->has('media:read:*') && !$this->context->has('media:read:own')) {
            return [];
        }
        $sql = 'SELECT filename,title FROM media_meta WHERE (filename LIKE ? OR title LIKE ?)';
        $q = '%' . ($query['q'] ?? '') . '%';
        $params = [$q,$q];
        if (!$this->context->has('media:read:*')) {
            $sql .= ' AND uploaded_by=?';
            $params[] = $this->context->uuid;
        }
        $stmt = $this->db->prepare($sql . ' ORDER BY filename LIMIT 20');
        $stmt->execute($params);
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $stmt->closeCursor();
        return array_map(static fn($r)=>['target' => ['kind' => 'media','item' => $r['filename']],'label' => $r['title'] ?: $r['filename']], $rows);
    }
}
