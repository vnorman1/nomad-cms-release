<?php

/**
 * NOMAD CMS - Editorials Hub SlotTargetAdapter.
 *
 * Scoped slot/record/schema-field resolution. Reads never invoke schema migration.
 * Backend-only PHP/SQLite module; resource budgets and authorization are enforced at service boundaries.
 *
 * @package NomadCMS\Services\EditorialsHub\References\Adapters
 */

declare(strict_types=1);

namespace NomadCMS\Services\EditorialsHub\References\Adapters;

use NomadCMS\Database\MassiveEncryption;
use NomadCMS\Services\EditorialsHub\Contracts\HubRequestContext;
use NomadCMS\Services\EditorialsHub\Contracts\TargetDescriptor;
use NomadCMS\Services\EditorialsHub\HubException;
use NomadCMS\Services\EditorialsHub\References\TargetAdapterInterface;
use NomadCMS\Services\EditorialsHub\Support;
use PDO;

/** Scoped slot/record/schema-field resolution. Reads never invoke schema migration. */
final class SlotTargetAdapter implements TargetAdapterInterface
{
    public function __construct(private PDO $content, private PDO $massive, private HubRequestContext $context, private array $schema)
    {
    }
    public function schema(): array
    {
        return $this->schema;
    }

    public function definition(string $slot): array
    {
        $definition = $this->schema['slots'][$slot] ?? null;
        if (!$definition || !$this->context->canAccessSlot($slot)) {
            throw new HubException('target_unavailable', 404);
        }
        if (!$this->context->has('content:read:*') && !$this->context->has('content:read:own')) {
            throw new HubException('target_unavailable', 404);
        }
        return $definition;
    }

    public static function field(array $definition, string $id): ?array
    {
        foreach ($definition['fields'] ?? [] as $field) {
            if (($field['id'] ?? '') === $id) {
                return \NomadCMS\Services\Schema\TemporalField::normalize($field);
            }
        } return null;
    }

    private function one(PDO $db, string $sql, array $params): ?array
    {
        $stmt = $db->prepare($sql);
        $stmt->execute($params);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $stmt->closeCursor();
        return $row ?: null;
    }

    public static function massiveTable(string $slot): string
    {
        if (!preg_match('/^[a-zA-Z0-9_-]{1,128}$/D', $slot)) {
            throw new HubException('target_unavailable', 404);
        }
        return 'massive_' . str_replace('-', '_', $slot);
    }

    public function record(TargetDescriptor $target, bool $allowEmptyObject = false): array
    {
        $definition = $this->definition($target->slot);
        $type = $definition['type'] ?? 'object';
        $owner = null;
        $condition = $this->context->has('content:read:*') ? '' : ' AND owner_uuid=?';
        $params = [$target->slot];
        if ($type === 'collection') {
            $sql = 'SELECT item_uid,data,owner_uuid,revision,updated_at,content_hash FROM collection_items WHERE slot_key=? AND item_uid=?';
            $params[] = $target->item;
            if ($condition) {
                $sql .= $condition;
                $params[] = $this->context->uuid;
            }
            $row = $this->one($this->content, $sql . ' AND length(data)<=1048576', $params);
            if (!$row) {
                throw new HubException('target_unavailable', 404);
            }
            $data = json_decode($row['data'], true, 64, JSON_THROW_ON_ERROR);
            $owner = $row['owner_uuid'];
            $preconditions = ['expected_revision' => (int)$row['revision'],'client_updated_at' => $row['updated_at'],'content_hash' => $row['content_hash']];
        } elseif ($type === 'massive') {
            if ($target->item === null || !ctype_digit($target->item)) {
                throw new HubException('target_unavailable', 404);
            }
            $table = self::massiveTable($target->slot);
            if (!$this->one($this->massive, "SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", [$table])) {
                throw new HubException('target_unavailable', 404);
            }
            $params = [(int)$target->item];
            $sql = "SELECT data,owner_uuid,updated_at FROM {$table} WHERE id=?";
            if ($condition) {
                $sql .= $condition;
                $params[] = $this->context->uuid;
            }
            $row = $this->one($this->massive, $sql . ' AND length(data)<=1048576', $params);
            if (!$row) {
                throw new HubException('target_unavailable', 404);
            }
            $data = MassiveEncryption::isEncrypted($row['data']) ? MassiveEncryption::decryptData($row['data']) : json_decode($row['data'], true, 64, JSON_THROW_ON_ERROR);
            $owner = $row['owner_uuid'];
            $preconditions = ['content_hash' => hash('sha256', Support::json($data))];
        } else {
            $row = $this->one($this->content, 'SELECT data FROM slots WHERE key=? AND length(data)<=2097152', [$target->slot]);
            if (!$row) {
                // Schema activation does not create content rows. Empty objects can
                // still be mentioned, but must not become writable or bypass ownership.
                if (
                    $allowEmptyObject
                    && $type === 'object'
                    && $this->context->has('content:read:*')
                    && !$this->one($this->content, 'SELECT 1 FROM slots WHERE key=?', [$target->slot])
                ) {
                    return [
                        'data' => [],
                        'owner' => null,
                        'preconditions' => [],
                        'definition' => $definition,
                        'exists' => false,
                    ];
                }
                throw new HubException('target_unavailable', 404);
            }
            $data = json_decode($row['data'], true, 64, JSON_THROW_ON_ERROR);
            $preconditions = ['expected_hash' => hash('sha256', Support::json($data))];
            if ($type === 'list') {
                $found = null;
                foreach ($data as $entry) {
                    if (is_array($entry) && ($entry['_dndId'] ?? null) === $target->item) {
                        $found = $entry;
                        break;
                    }
                }
                if ($found === null) {
                    throw new HubException('target_unavailable', 404);
                } $data = $found;
            }
            $owned = $this->one($this->content, 'SELECT owner_uuid FROM slot_ownership WHERE slot_key=? AND item_uid IS ? LIMIT 1', [$target->slot,$type === 'list' ? $target->item : null]);
            $owner = $owned['owner_uuid'] ?? null;
            if (!$this->context->has('content:read:*') && $owner !== $this->context->uuid) {
                throw new HubException('target_unavailable', 404);
            }
        }
        return ['data' => $data,'owner' => $owner,'preconditions' => $preconditions,'definition' => $definition];
    }

    public function canWrite(array $record, bool $create = false): bool
    {
        if (($record['exists'] ?? true) === false) {
            return false;
        }
        $action = $create ? 'create' : 'update';
        return $this->context->has('content:' . $action . ':*') || ($this->context->has('content:' . $action . ':own') && ($create || $record['owner'] === $this->context->uuid));
    }

    public function resolve(TargetDescriptor $target): array
    {
        $definition = $this->definition($target->slot);
        $type = $definition['type'] ?? 'object';
        $base = ['available' => true,'target' => $target->toArray(),'label' => $definition['label'] ?? $target->slot,'type' => $type,'writable' => false,'navigation' => '/slots/' . rawurlencode($target->slot)];
        $base['breadcrumbs'] = [(string) $base['label']];
        if ($target->item === 'new') {
            $base['breadcrumbs'][] = 'new';
            if (!in_array($type, ['collection','list','massive'], true)) {
                throw new HubException('new_not_supported');
            }
            if ($target->path !== []) {
                throw new HubException('target_unavailable', 404);
            }
            if ($target->field !== null) {
                $field = self::field($definition, $target->field);
                if (!$field || ($field['hidden'] ?? false)) {
                    throw new HubException('target_unavailable', 404);
                }
                if ($target->locale !== null && (!($field['localized'] ?? false) || !in_array($target->locale, $this->schema['i18n']['languages'] ?? [], true))) {
                    throw new HubException('invalid_locale');
                }
                $base['label'] = $field['label'] ?? $field['id'];
                $base['breadcrumbs'][] = (string) $base['label'];
                $base['type'] = $field['type'] ?? 'text';
                $base['writable'] = !($field['readonly'] ?? $field['readOnly'] ?? false) && !($field['disabled'] ?? false) && !in_array($base['type'], ['slug','blocks','json','array','map','iframe','video','audio','file'], true) && $this->canWrite(['owner' => null], true);
            }
            return $base + ['can_create' => $this->canWrite(['owner' => null], true)];
        }
        if ($target->item === null && $type !== 'object') {
            return $base;
        }
        $record = $this->record($target, true);
        $data = $record['data'];
        if ($target->item !== null) {
            $base['navigation'] .= '?item=' . rawurlencode($target->item);
        }
        $labelField = $definition['titleField'] ?? 'title';
        $label = $data[$labelField] ?? $target->item ?? $base['label'];
        if (is_array($label)) {
            $label = $label[$this->schema['i18n']['defaultLanguage'] ?? 'hu'] ?? reset($label);
        }
        if (is_scalar($label)) {
            $base['label'] = mb_substr((string)$label, 0, 160);
        }
        if ($target->item !== null) {
            $base['breadcrumbs'][] = (string) $base['label'];
        }
        if ($target->field === null) {
            $base['preview'] = ['kind' => 'text', 'text' => mb_substr(strip_tags((string)$base['label']), 0, 320)];
            return $base;
        }
        $field = self::field($definition, $target->field);
        if (!$field) {
            throw new HubException('target_unavailable', 404);
        }
        if (($field['hidden'] ?? false) === true) {
            throw new HubException('target_unavailable', 404);
        }
        $value = $data[$target->field] ?? null;
        if ($target->locale !== null) {
            if (!($field['localized'] ?? false) || !in_array($target->locale, $this->schema['i18n']['languages'] ?? [], true)) {
                throw new HubException('invalid_locale');
            }
            $value = is_array($value) ? ($value[$target->locale] ?? null) : null;
        }
        foreach ($target->path as $segment) {
            if (!is_array($value) || !array_key_exists($segment, $value)) {
                throw new HubException('target_unavailable', 404);
            } $value = $value[$segment];
        }
        $base['label'] = $field['label'] ?? $field['id'];
        $base['breadcrumbs'][] = (string) $base['label'];
        foreach ($target->path as $segment) {
            $base['breadcrumbs'][] = (string) $segment;
        }
        $base['type'] = $field['type'] ?? 'text';
        $base['writable'] = $target->path === [] && !($field['readonly'] ?? $field['readOnly'] ?? false) && !($field['disabled'] ?? false) && !in_array($base['type'], ['slug','blocks','json','array','map','iframe','video','audio','file'], true) && $this->canWrite($record);
        $previewValue = $value;
        if (($field['localized'] ?? false) && $target->locale === null && is_array($value)) {
            $previewValue = $value[$this->schema['i18n']['defaultLanguage'] ?? 'hu'] ?? null;
        }
        $preview = $this->fieldPreview($previewValue, $base['type'], $target->locale);
        if ($preview !== null) {
            $base['preview'] = $preview;
        }
        if (is_string($value) && strlen($value) > 4096) {
            $base['value'] = mb_substr(strip_tags($value), 0, 320);
            $base['value_truncated'] = true;
        } elseif (is_array($value)) {
            $base['value'] = null;
            $base['value_truncated'] = true;
        } else {
            $base['value'] = $value;
        }
        return $base;
    }

    /** Keep media previews bounded and resolve every URL through current media access. */
    private function fieldPreview(mixed $value, string $type, ?string $locale, int $limit = 4): ?array
    {
        if (in_array($type, ['image', 'gif', 'gallery'], true)) {
            $entries = $type === 'gallery' && is_array($value) ? $value : [$value];
            $images = [];
            $media = new MediaTargetAdapter($this->content, $this->context);
            foreach (array_slice($entries, 0, $limit) as $entry) {
                $source = is_array($entry) ? ($entry['src'] ?? null) : $entry;
                if (!is_string($source) || $source === '') {
                    continue;
                }
                $filename = str_starts_with($source, '/api/uploads/') ? rawurldecode(basename((string)parse_url($source, PHP_URL_PATH))) : $source;
                $preview = $media->preview($filename, $locale);
                if ($preview !== null) {
                    $images[] = $preview['images'][0];
                }
            }
            return $images === [] ? null : ['kind' => $type === 'gallery' ? 'gallery' : 'image', 'images' => $images];
        }
        if (is_scalar($value)) {
            return ['kind' => 'text', 'text' => mb_substr(html_entity_decode(strip_tags((string)$value), ENT_QUOTES | ENT_HTML5, 'UTF-8'), 0, 320)];
        }
        return null;
    }

    /** Explicit transfer may export a complete bounded gallery rather than its hover thumbnail. */
    public function exportImages(TargetDescriptor $target): array
    {
        $resolved = $this->resolve($target);
        if (!in_array($resolved['type'] ?? '', ['image', 'gif', 'gallery'], true) || $target->field === null || $target->item === 'new') {
            return [];
        }
        $record = $this->record($target);
        $field = self::field($record['definition'], $target->field);
        $value = $record['data'][$target->field] ?? null;
        if ($field['localized'] ?? false) {
            $locale = $target->locale ?? ($this->schema['i18n']['defaultLanguage'] ?? 'hu');
            $value = is_array($value) ? ($value[$locale] ?? null) : null;
        }
        foreach ($target->path as $segment) {
            $value = is_array($value) ? ($value[$segment] ?? null) : null;
        }
        return $this->fieldPreview($value, $resolved['type'], $target->locale, 100)['images'] ?? [];
    }

    public function suggest(array $query): array
    {
        $q = Support::text($query['q'] ?? '', 128);
        $slot = $query['slot'] ?? null;
        if ($slot === null) {
            $out = []; foreach ($this->schema['slots'] ?? [] as $key => $d) {
                if (!$this->context->canAccessSlot($key) || (!$this->context->has('content:read:*') && !$this->context->has('content:read:own'))) {
                    continue;
                }
                $label = is_string($d['label'] ?? null) ? $d['label'] : $key;
                if ($q === '' || mb_stripos($key . ' ' . $label, $q) !== false) {
                    $out[] = [
                        'target' => ['kind' => 'slot', 'slot' => $key],
                        'label' => $label,
                        'breadcrumbs' => [$label],
                        'type' => $d['type'] ?? 'object',
                    ];
                }
                if (count($out) === 20) {
                    break;
                }
            } return $out;
        }
        $d = $this->definition($slot);
        $type = $d['type'] ?? 'object';
        if (isset($query['item']) || $type === 'object') {
            $target = new TargetDescriptor('slot', $slot, $query['item'] ?? null);
            $parent = $this->resolve($target);
            $out = [];
            foreach ($d['fields'] ?? [] as $f) {
                if ($f['hidden'] ?? false) {
                    continue;
                }
                $label = is_string($f['label'] ?? null) ? $f['label'] : $f['id'];
                if ($q === '' || mb_stripos($f['id'] . ' ' . $label, $q) !== false) {
                    $out[] = [
                        'target' => ['kind' => 'slot', 'slot' => $slot, 'item' => $target->item, 'field' => $f['id']],
                        'label' => $label,
                        'breadcrumbs' => [...$parent['breadcrumbs'], $label],
                        'type' => $f['type'] ?? 'text',
                    ];
                }
                if (count($out) === 20) {
                    break;
                }
            } return $out;
        }
        $rows = [];
        $title = $d['titleField'] ?? 'title';
        $owner = $this->context->has('content:read:*') ? null : $this->context->uuid;
        if ($type === 'collection') {
            $where = 'i.slot_key=?';
            $params = [$slot];
            $join = '';
            if ($owner !== null) {
                $where .= ' AND i.owner_uuid=?';
                $params[] = $owner;
            }
            if ($q !== '') {
                $tokens = preg_split('/[^\p{L}\p{N}_]+/u', $q, -1, PREG_SPLIT_NO_EMPTY);
                $fts = implode(' ', array_map(static fn($t)=>'"' . str_replace('"', '""', $t) . '"*', array_slice($tokens, 0, 6)));
                if ($fts === '') {
                    return [];
                }
                $join = ' JOIN collection_fts ON collection_fts.rowid=i.row_id';
                $where .= ' AND collection_fts MATCH ?';
                $params[] = $fts;
            }
            $stmt = $this->content->prepare('SELECT i.item_uid AS uid,json_extract(i.data,?) AS label FROM collection_items i' . $join . ' WHERE ' . $where . ' ORDER BY i.position,i.row_id LIMIT 20');
            $stmt->execute(['$.' . Support::json($title),...$params]);
            $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
            $stmt->closeCursor();
            if ($q !== '') {
                $exact = $this->content->prepare('SELECT i.item_uid AS uid,json_extract(i.data,?) AS label FROM collection_items i WHERE i.slot_key=? AND (i.item_uid=? OR i.slug=? OR i.business_id=?)' . ($owner !== null ? ' AND i.owner_uuid=?' : '') . ' LIMIT 2');
                $exact->execute(['$.' . Support::json($title),$slot,$q,$q,$q,...($owner !== null ? [$owner] : [])]);
                $rows = [...$exact->fetchAll(PDO::FETCH_ASSOC),...$rows];
                $exact->closeCursor();
            }
        } elseif ($type === 'massive') {
            $table = self::massiveTable($slot);
            $encrypted = (bool)($d['encrypted'] ?? false);
            $params = [];
            $where = '1=1';
            if (!$this->one($this->massive, "SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", [$table])) {
                return [];
            }
            if ($owner !== null) {
                $where .= ' AND owner_uuid=?';
                $params[] = $owner;
            }
            if ($q !== '' && ctype_digit($q)) {
                $where .= ' AND id=?';
                $params[] = (int)$q;
            } elseif ($q !== '') {
                if ($encrypted) {
                    $fields = $d['searchableFields'] ?? [];
                    if (!$fields) {
                        return [];
                    }
                    $fts = MassiveEncryption::buildBlindSearchQuery($q, $fields);
                } else {
                    $tokens = preg_split('/[^\p{L}\p{N}_]+/u', $q, -1, PREG_SPLIT_NO_EMPTY);
                    $fts = implode(' ', array_map(static fn($t)=>'"' . $t . '"*', array_slice($tokens, 0, 6)));
                }
                if (!$fts) {
                    return [];
                } $where .= " AND id IN(SELECT rowid FROM {$table}_fts WHERE {$table}_fts MATCH ?)";
                $params[] = $fts;
            }
            $stmt = $this->massive->prepare("SELECT id AS uid FROM {$table} WHERE {$where} ORDER BY id DESC LIMIT 20");
            $stmt->execute($params);
            $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
            $stmt->closeCursor();
            foreach ($rows as &$row) {
                $row['label'] = (string)$row['uid'];
            } unset($row);
        } elseif ($type === 'list') {
            $where = "s.key=? AND json_type(j.value,'$.\"_dndId\"')='text'";
            $params = [$slot];
            if ($owner !== null) {
                $where .= " AND EXISTS(SELECT 1 FROM slot_ownership o WHERE o.slot_key=s.key AND o.item_uid=json_extract(j.value,'$.\"_dndId\"') AND o.owner_uuid=?)";
                $params[] = $owner;
            }
            if ($q !== '') {
                $where .= ' AND (CAST(json_extract(j.value,?) AS TEXT) LIKE ? OR json_extract(j.value,\'$."_dndId"\')=?)';
                array_push($params, '$.' . Support::json($title), '%' . strtr($q, ['%' => '\\%','_' => '\\_']) . '%', $q);
            }
            $stmt = $this->content->prepare('SELECT json_extract(j.value,\'$."_dndId"\') AS uid,json_extract(j.value,?) AS label FROM slots s,json_each(s.data) j WHERE ' . $where . ' LIMIT 20');
            $stmt->execute(['$.' . Support::json($title),...$params]);
            $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
            $stmt->closeCursor();
        }
        $out = [];
        $seen = [];
        foreach ($rows as $row) {
            $uid = (string)$row['uid'];
            if (isset($seen[$uid])) {
                continue;
            } $seen[$uid] = true;
            $label = $row['label'] ?? $uid;
            if (is_string($label) && str_starts_with($label, '{')) {
                $localized = json_decode($label, true);
                $label = $localized[$this->schema['i18n']['defaultLanguage'] ?? 'hu'] ?? $uid;
            }
            $itemLabel = mb_substr((string) $label, 0, 160);
            $out[] = [
                'target' => ['kind' => 'slot', 'slot' => $slot, 'item' => $uid],
                'label' => $itemLabel,
                'breadcrumbs' => [(string) ($d['label'] ?? $slot), $itemLabel],
                'type' => $type,
            ];
            if (count($out) === 20) {
                break;
            }
        }
        return $out;
    }
}
