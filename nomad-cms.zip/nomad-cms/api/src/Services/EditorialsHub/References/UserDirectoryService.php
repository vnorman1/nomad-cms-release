<?php

/**
 * NOMAD CMS - Editorials Hub UserDirectoryService.
 *
 * Minimal directory of onboarded Hub users; never exposes authentication records.
 * Backend-only PHP/SQLite module; resource budgets and authorization are enforced at service boundaries.
 *
 * @package NomadCMS\Services\EditorialsHub\References
 */

declare(strict_types=1);

namespace NomadCMS\Services\EditorialsHub\References;

use NomadCMS\Services\EditorialsHub\Access\HubAccessPolicy;
use NomadCMS\Services\EditorialsHub\HubException;
use NomadCMS\Services\EditorialsHub\Support;
use NomadCMS\Services\RBACService;
use PDO;

/** Minimal directory of onboarded Hub users; never exposes authentication records. */
final class UserDirectoryService
{
    public function __construct(private PDO $auth, private PDO $hub, private HubAccessPolicy $access)
    {
    }
    public function eligible(string $uuid): bool
    {
        return $this->find($uuid) !== null;
    }

    public function find(string $uuid): ?array
    {
        $stmt = $this->auth->prepare('SELECT uuid,email,first_name,last_name,role_slug,is_admin,role FROM users WHERE uuid=? AND is_new_user=0 AND (locked_until IS NULL OR locked_until<=datetime(\'now\'))');
        $stmt->execute([$uuid]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $stmt->closeCursor();
        if (!$row || (!RBACService::hasGrantedScope($row, 'editorials:read:*') && !RBACService::hasGrantedScope($row, 'editorials:read:own'))) {
            return null;
        }
        $name = trim(($row['first_name'] ?? '') . ' ' . ($row['last_name'] ?? ''));
        return ['uuid' => $row['uuid'],'name' => $name !== '' ? $name : $row['email']];
    }

    public function suggest(string $boardUuid, string $query, bool $invite = false): array
    {
        $b = $this->access->board($boardUuid);
        if ($invite) {
            $this->access->manage($b);
        }
        Support::text($query, 128);
        $escaped = strtr($query, ['\\' => '\\\\','%' => '\\%','_' => '\\_']);
        $stmt = $this->auth->prepare("SELECT uuid FROM users WHERE is_new_user=0 AND (email LIKE ? ESCAPE '\\' OR (COALESCE(first_name,'')||' '||COALESCE(last_name,'')) LIKE ? ESCAPE '\\') ORDER BY email LIMIT 100");
        $stmt->execute(['%' . $escaped . '%','%' . $escaped . '%']);
        $ids = $stmt->fetchAll(PDO::FETCH_COLUMN);
        $stmt->closeCursor();
        $result = [];
        foreach ($ids as $id) {
            $user = $this->find($id);
            if (!$user) {
                continue;
            }
            if (!$invite && $b['visibility'] === 'private' && $id !== $b['owner_uuid']) {
                $member = $this->hub->prepare('SELECT 1 FROM eh_board_members WHERE board_id=? AND user_uuid=?');
                $member->execute([$b['id'],$id]);
                if (!$member->fetchColumn()) {
                    continue;
                }
            }
            $result[] = $user;
            if (count($result) === 20) {
                break;
            }
        }
        return $result;
    }
}
