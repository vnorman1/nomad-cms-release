<?php

/**
 * NOMAD CMS - Editorials Hub ReferenceService.
 *
 * Server-owned mention identities and explicit future-item proposals.
 * Backend-only PHP/SQLite module; resource budgets and authorization are enforced at service boundaries.
 *
 * @package NomadCMS\Services\EditorialsHub\References
 */

declare(strict_types=1);

namespace NomadCMS\Services\EditorialsHub\References;

use NomadCMS\Services\EditorialsHub\Access\HubAccessPolicy;
use NomadCMS\Services\EditorialsHub\Contracts\TargetDescriptor;
use NomadCMS\Services\EditorialsHub\HubException;
use NomadCMS\Services\EditorialsHub\Integration\ProposalMediaService;
use NomadCMS\Services\EditorialsHub\Persistence\ItemRepository;
use NomadCMS\Services\EditorialsHub\Persistence\ReferenceRepository;
use NomadCMS\Services\EditorialsHub\Persistence\SyncRepository;
use NomadCMS\Services\EditorialsHub\Support;

/** Server-owned mention identities and explicit future-item proposals. */
final class ReferenceService
{
    public function __construct(private ReferenceRepository $repo, private HubAccessPolicy $access, private TargetRegistry $targets)
    {
    }
    private function boardUuid(int $id): string
    {
        return $this->repo->one('SELECT uuid FROM eh_boards WHERE id=?', [$id])['uuid'];
    }

    public function bind(array $input, string $key): array
    {
        $purpose = $input['purpose'] ?? 'note';
        if (!in_array($purpose, ['note','comment'], true)) {
            throw new HubException('invalid_reference_purpose');
        }
        $item = $this->bindAccess((string)($input['item_id'] ?? ''), $purpose);
        $target = TargetDescriptor::fromArray($input['target'] ?? []);
        $this->targets->resolve($target, $this->boardUuid((int)$item['board_id']));
        $ctx = $this->access->context;
        return $this->repo->idempotent($ctx->uuid, 'reference.create:' . $item['uuid'], $key, $input, function () use ($input, $item, $target, $ctx, $purpose): array {
            $this->bindAccess($item['uuid'], $purpose);
            $this->targets->resolve($target, $this->boardUuid((int)$item['board_id']));
            $occurrence = Support::key((string)($input['occurrence_id'] ?? ''));
            $old = $this->repo->one('SELECT * FROM eh_references WHERE item_id=? AND occurrence_id=?', [$item['uuid'],$occurrence]);
            if ($old) {
                if ($old['target'] !== Support::json($target->toArray())) {
                    throw new HubException('reference_conflict', 409);
                } return ['id' => $old['id']];
            }
            $id = Support::uuid();
            $this->repo->run('INSERT INTO eh_references VALUES(?,?,?,?,?,?,?)', [$id,$item['board_id'],$item['uuid'],$ctx->uuid,$occurrence,Support::json($target->toArray()),time()]);
            return ['id' => $id];
        });
    }

    /** Comment references do not confer permission to edit the underlying note. */
    private function bindAccess(string $itemId, string $purpose): array
    {
        $item = $this->access->item($itemId, $purpose === 'comment' ? 'read' : 'update');
        if ($purpose === 'comment') {
            $this->access->require('comment', $this->access->context->uuid);
        }

        return $item;
    }

    public function resolve(string $id): array
    {
        $ref = $this->repo->find($id);
        if (!$ref) {
            throw new HubException('not_found', 404);
        } $this->access->item($ref['item_id']);
        try {
            return ['id' => $id] + $this->targets->resolve(TargetDescriptor::fromArray(json_decode($ref['target'], true)), $this->boardUuid((int)$ref['board_id']));
        } catch (HubException $error) {
            if ($error->status !== 404 && $error->status !== 403) {
                throw $error;
            } return ['id' => $id,'available' => false,'writable' => false,'navigation' => null];
        }
    }

    public function proposal(array $input, string $key, string $role = 'standard'): array
    {
        $item = $this->access->item((string)($input['item_id'] ?? ''), 'update');
        $target = TargetDescriptor::fromArray($input['target'] ?? []);
        $board = $this->boardUuid((int)$item['board_id']);
        $resolved = $this->targets->resolve($target, $board);
        if ($target->kind !== 'slot' || $target->path !== [] || ($target->item !== 'new' && !$resolved['writable']) || ($target->item === 'new' && !($resolved['can_create'] ?? false))) {
            throw new HubException('target_not_writable', 403);
        }
        if (
            !in_array($role, ['standard', 'canvas_draft'], true)
            || ($role === 'canvas_draft' && ($item['type'] !== 'note' || $target->item !== 'new' || $target->field !== null))
        ) {
            throw new HubException('invalid_proposal');
        }
        $values = $input['values'] ?? [];
        if (!is_array($values) || strlen(Support::json($values)) > 262144) {
            throw new HubException('invalid_proposal');
        }
        if ($role === 'canvas_draft' && $values === []) {
            $schema = $this->targets->slots->schema();
            foreach ($this->targets->slots->definition($target->slot)['fields'] ?? [] as $field) {
                if (
                    !array_key_exists('defaultValue', $field)
                    || ($field['hidden'] ?? false)
                    || ($field['readonly'] ?? $field['readOnly'] ?? false)
                    || ($field['disabled'] ?? false)
                    || in_array($field['type'] ?? 'text', ['slug', 'blocks', 'json', 'array', 'map', 'iframe', 'file', 'video', 'audio'], true)
                ) {
                    continue;
                }
                $value = $field['defaultValue'];
                if ($field['localized'] ?? false) {
                    $value = is_array($value) && !array_is_list($value)
                        ? array_intersect_key($value, array_flip($schema['i18n']['languages'] ?? []))
                        : [($schema['i18n']['defaultLanguage'] ?? 'hu') => $value];
                }
                $values[$field['id']] = $value;
            }
        }
        $media = (new ProposalMediaService($this->repo->db, $this->targets))->normalize(
            $target,
            $input['field_media'] ?? [],
            $values,
            (int)$item['board_id'],
        );
        $this->proposalBudget($values, $media);
        $ctx = $this->access->context;
        return $this->repo->idempotent($ctx->uuid, 'proposal.create:' . $item['uuid'], $key, $input, function () use ($item, $target, $values, $ctx, $role, $media): array {
            $id = Support::uuid();
            $this->repo->run(
                'INSERT INTO eh_proposals(id,board_id,item_id,owner_uuid,target,values_json,revision,created_at,updated_at,role,field_media_json) VALUES(?,?,?,?,?,?,1,?,?,?,?)',
                [$id, $item['board_id'], $item['uuid'], $ctx->uuid, Support::json($target->toArray()), Support::json($values), time(), time(), $role, Support::json($media)],
            );
            $this->syncMediaUsages($id, $media);
            $this->proposalChanged($item, $id, 1, 'proposal.created');
            return ['id' => $id,'revision' => 1];
        });
    }

    /** Reload a saved proposal without exposing an unavailable destination. */
    public function getProposal(string $id): array
    {
        $proposal = $this->repo->proposal($id);
        if (!$proposal) {
            throw new HubException('not_found', 404);
        }
        $this->access->item($proposal['item_id']);
        try {
            $target = $this->targets->resolve(TargetDescriptor::fromArray(json_decode($proposal['target'], true)), $this->boardUuid((int)$proposal['board_id']));
            unset($target['value']);
        } catch (HubException $error) {
            if (!in_array($error->status, [403,404], true)) {
                throw $error;
            } $target = ['available' => false,'writable' => false,'navigation' => null];
        }
        $values = json_decode($proposal['values_json'], true);
        $result = [
            'id' => $id,
            'item_id' => $proposal['item_id'],
            'revision' => (int)$proposal['revision'],
            'values' => $values === [] ? (object)[] : $values,
            'target' => $target,
            'role' => $proposal['role'],
            'field_media' => json_decode($proposal['field_media_json'], true),
        ];
        $receipt = $this->appliedReceipt($id);
        if ($receipt !== null) {
            $result['transfer'] = ['state' => 'applied'];
            try {
                $rawDestination = json_decode($receipt['destination'], true);
                $destination = TargetDescriptor::fromArray($rawDestination);
                $this->targets->resolve($destination, $this->boardUuid((int)$proposal['board_id']));
                $result['transfer']['destination'] = $rawDestination;
            } catch (HubException $error) {
                if (!in_array($error->status, [403, 404], true)) {
                    throw $error;
                }
            }
        }
        return $result;
    }

    public function updateProposal(string $id, array $input): array
    {
        return Support::transaction($this->repo->db, function () use ($id, $input): array {
            $p = $this->repo->proposal($id);
            if (!$p) {
                throw new HubException('not_found', 404);
            }
            $item = $this->access->item($p['item_id'], 'update');
            if ((int)($input['expected_revision'] ?? 0) !== (int)$p['revision']) {
                throw new HubException('version_conflict', 409);
            }
            if ($p['role'] === 'canvas_draft' && $this->appliedReceipt($id) !== null) {
                throw new HubException('proposal_already_applied', 409);
            }
            $target = TargetDescriptor::fromArray(json_decode($p['target'], true));
            $resolved = $this->targets->resolve($target, $this->boardUuid((int)$p['board_id']));
            if (($target->item === 'new' && !($resolved['can_create'] ?? false)) || ($target->item !== 'new' && !$resolved['writable'])) {
                throw new HubException('target_not_writable', 403);
            }
            $values = $input['values'] ?? [];
            if (!is_array($values) || strlen(Support::json($values)) > 262144) {
                throw new HubException('invalid_proposal');
            }
            $media = (new ProposalMediaService($this->repo->db, $this->targets))->normalize(
                $target,
                $input['field_media'] ?? json_decode($p['field_media_json'], true),
                $values,
                (int)$p['board_id'],
            );
            $this->proposalBudget($values, $media);
            $this->repo->run(
                'UPDATE eh_proposals SET values_json=?,field_media_json=?,revision=revision+1,updated_at=? WHERE id=?',
                [Support::json($values), Support::json($media), time(), $id],
            );
            $this->syncMediaUsages($id, $media);
            $this->proposalChanged($item, $id, (int)$p['revision'] + 1, 'proposal.updated');
            return ['id' => $id,'revision' => (int)$p['revision'] + 1];
        });
    }

    /** Typed media and editable values share the existing bounded proposal payload. */
    private function proposalBudget(array $values, array $media): void
    {
        if (strlen(Support::json($values)) + ($media === [] ? 0 : strlen(Support::json($media))) > 262144) {
            throw new HubException('invalid_proposal');
        }
    }

    private function syncMediaUsages(string $proposal, array $bindings): void
    {
        $this->repo->run('DELETE FROM eh_proposal_attachment_usages WHERE proposal_id=?', [$proposal]);
        foreach ($bindings as $binding) {
            foreach ($binding['sources'] as $source) {
                if ($source['kind'] === 'attachment') {
                    $this->repo->run(
                        'INSERT OR IGNORE INTO eh_proposal_attachment_usages(proposal_id,attachment_id) VALUES(?,?)',
                        [$proposal, $source['attachment_id']],
                    );
                }
            }
        }
    }

    private function proposalChanged(array $item, string $proposal, int $revision, string $kind): void
    {
        $this->repo->run('UPDATE eh_items SET metadata_revision=metadata_revision+1,updated_at=? WHERE uuid=?', [time(), $item['uuid']]);
        $bounds = ItemRepository::boundsOf($item);
        (new ItemRepository($this->repo->db))->touchTiles((int)$item['board_id'], $bounds, $bounds, $item['type'], $item['owner_uuid']);
        (new SyncRepository($this->repo->db))->change(
            (int)$item['board_id'],
            $kind,
            $proposal,
            $revision,
            ['item_id' => $item['uuid'], 'proposal_id' => $proposal],
            $bounds,
            $bounds,
        );
    }

    private function appliedReceipt(string $proposal): ?array
    {
        return $this->repo->one(
            "SELECT r.destination FROM eh_transfer_plans p JOIN eh_transfer_receipts r ON r.plan_id=p.id WHERE p.proposal_id=? AND r.state='applied' ORDER BY r.updated_at DESC LIMIT 1",
            [$proposal],
        );
    }
}
