<?php

/**
 * NOMAD CMS - Editorials Hub TargetDescriptor.
 *
 * Immutable canonical identity; presentation and capabilities are resolved per actor.
 * Backend-only PHP/SQLite module; resource budgets and authorization are enforced at service boundaries.
 *
 * @package NomadCMS\Services\EditorialsHub\Contracts
 */

declare(strict_types=1);

namespace NomadCMS\Services\EditorialsHub\Contracts;

use NomadCMS\Services\EditorialsHub\HubException;

/** Immutable canonical identity; presentation and capabilities are resolved per actor. */
final class TargetDescriptor
{
    public function __construct(public readonly string $kind, public readonly string $slot = '', public readonly ?string $item = null, public readonly ?string $field = null, public readonly ?string $locale = null, public readonly array $path = [])
    {
        if (!in_array($kind, ['slot', 'media', 'module', 'user'], true) || count($path) > 16) {
            throw new HubException('invalid_target');
        }
        foreach ([$slot, $item, $field, $locale, ...$path] as $value) {
            if ($value !== null && (!is_string($value) || strlen($value) > 256 || preg_match('/[\x00-\x1f]/', $value))) {
                throw new HubException('invalid_target');
            }
        }
    }

    public static function fromArray(array $value): self
    {
        return new self((string) ($value['kind'] ?? ''), (string) ($value['slot'] ?? ''), isset($value['item']) ? (string) $value['item'] : null, isset($value['field']) ? (string) $value['field'] : null, isset($value['locale']) ? (string) $value['locale'] : null, $value['path'] ?? []);
    }

    public function toArray(): array
    {
        return get_object_vars($this);
    }
}
