<?php

/**
 * NOMAD CMS - Editorials Hub HubRequestContext.
 *
 * Authoritative human actor; callbacks allow isolated, in-memory policy tests.
 * Backend-only PHP/SQLite module; resource budgets and authorization are enforced at service boundaries.
 *
 * @package NomadCMS\Services\EditorialsHub\Contracts
 */

declare(strict_types=1);

namespace NomadCMS\Services\EditorialsHub\Contracts;

use NomadCMS\Services\EditorialsHub\HubException;
use NomadCMS\Services\RBACService;

/** Authoritative human actor; callbacks allow isolated, in-memory policy tests. */
final class HubRequestContext
{
    private \Closure $permission;
    private \Closure $slotAccess;

    public function __construct(public readonly string $uuid, public readonly string $cursorSecret, ?callable $permission = null, ?callable $slotAccess = null, public readonly bool $superAdmin = false)
    {
        if ($uuid === '' || strlen($cursorSecret) < 32) {
            throw new HubException('invalid_context', 401);
        }
        $this->permission = \Closure::fromCallable($permission ?? static fn(string $p): bool => false);
        $this->slotAccess = \Closure::fromCallable($slotAccess ?? static fn(string $s): bool => false);
    }

    public static function fromUser(object $user, string $secret): self
    {
        if (($user->source ?? '') === 'api_key' || empty($user->uuid)) {
            throw new HubException('human_session_required', 403);
        }
        $super = RBACService::hasGrantedScope($user, '*:*:*');
        return new self(
            (string) $user->uuid,
            $secret,
            static fn(string $p): bool => RBACService::hasGrantedScope($user, $p),
            static fn(string $s): bool => RBACService::canAccessSlot($user, $s),
            $super
        );
    }

    public function has(string $permission): bool
    {
        return ($this->permission)($permission);
    }
    public function canAccessSlot(string $slot): bool
    {
        return ($this->slotAccess)($slot);
    }
}
