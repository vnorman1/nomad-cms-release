<?php

/**
 * NOMAD CMS - Editorials Hub TransferPlan.
 *
 * Server-stored preview, concurrency preconditions and destination mutation values.
 * Backend-only PHP/SQLite module; resource budgets and authorization are enforced at service boundaries.
 *
 * @package NomadCMS\Services\EditorialsHub\Contracts
 */

declare(strict_types=1);

namespace NomadCMS\Services\EditorialsHub\Contracts;

/** Server-stored preview, concurrency preconditions and destination mutation values. */
final class TransferPlan
{
    public function __construct(public readonly array $data)
    {
    }
    public function toArray(): array
    {
        return $this->data;
    }
}
