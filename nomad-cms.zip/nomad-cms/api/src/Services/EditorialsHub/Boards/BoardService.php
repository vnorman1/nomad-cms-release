<?php

/**
 * NOMAD CMS - Editorials Hub BoardService.
 *
 * Boards, invited collaborators and owner-managed statuses/retention.
 * Backend-only PHP/SQLite module; resource budgets and authorization are enforced at service boundaries.
 *
 * @package NomadCMS\Services\EditorialsHub\Boards
 */

declare(strict_types=1);

namespace NomadCMS\Services\EditorialsHub\Boards;

use NomadCMS\Services\EditorialsHub\Access\HubAccessPolicy;
use NomadCMS\Services\EditorialsHub\HubException;
use NomadCMS\Services\EditorialsHub\Persistence\BoardRepository;
use NomadCMS\Services\EditorialsHub\Persistence\ItemRepository;
use NomadCMS\Services\EditorialsHub\Persistence\SyncRepository;
use NomadCMS\Services\EditorialsHub\Support;

/** Boards, invited collaborators and owner-managed statuses/retention. */
final class BoardService
{
    public function __construct(private BoardRepository $repo, private HubAccessPolicy $access, private SyncRepository $sync, private ?\Closure $eligibleUser = null)
    {
    }

    public function list(array $query): array
    {
        $ctx = $this->access->context;
        $after = 0;
        $binding = ['actor' => $ctx->uuid,'kind' => 'boards'];
        if (!empty($query['cursor'])) {
            $after = (int)Support::decodeCursor($query['cursor'], $ctx->cursorSecret, $binding)['after'];
        }
        $all = $ctx->has('editorials:read:*');
        if (!$all && !$ctx->has('editorials:read:own')) {
            throw new HubException('forbidden', 403);
        }
        $sql = 'SELECT b.* FROM eh_boards b WHERE b.id>? AND b.deleted_at IS NULL AND ';
        $params = [$after];
        if (!$all) {
            $sql .= 'b.owner_uuid=?';
            $params[] = $ctx->uuid;
        } elseif (!$ctx->superAdmin) {
            $sql .= "(b.visibility='shared' OR b.owner_uuid=? OR EXISTS(SELECT 1 FROM eh_board_members m WHERE m.board_id=b.id AND m.user_uuid=?))";
            array_push($params, $ctx->uuid, $ctx->uuid);
        } else {
            $sql .= '1=1';
        }
        $rows = $this->repo->all($sql . ' ORDER BY b.id LIMIT 101', $params);
        $more = count($rows) > 100;
        $rows = array_slice($rows, 0, 100);
        return Support::page($rows, ['has_more' => $more,'cursor' => $rows ? Support::cursor($binding + ['after' => (int)end($rows)['id']], $ctx->cursorSecret) : null]);
    }

    public function create(array $input, string $key): array
    {
        $ctx = $this->access->context;
        $this->access->require('create', $ctx->uuid);
        $title = Support::text($input['title'] ?? '', 160);
        $visibility = $input['visibility'] ?? 'shared';
        $locale = $input['locale'] ?? 'en';
        if (trim($title) === '' || !in_array($visibility, ['shared','private'], true) || !in_array($locale, ['hu','en'], true)) {
            throw new HubException('invalid_board');
        }
        return $this->repo->idempotent($ctx->uuid, 'board.create', $key, $input, function () use ($title, $visibility, $ctx): array {
            $uuid = Support::uuid();
            $now = time();
            $this->repo->run('INSERT INTO eh_boards(uuid,owner_uuid,title,visibility,created_at,updated_at) VALUES(?,?,?,?,?,?)', [$uuid,$ctx->uuid,$title,$visibility,$now,$now]);
            $id = (int)$this->repo->db->lastInsertId();
            // Generated labels use English for every admin locale; user-defined status names remain untouched.
            $names = ['Idea', 'Planned', 'In progress', 'Done'];
            foreach ($names as $position => $name) {
                $this->repo->run('INSERT INTO eh_board_statuses VALUES(?,?,?,?)', [Support::uuid(),$id,$name,$position]);
            }
            $this->sync->change($id, 'board.created', $uuid, 1);
            return $this->repo->find($uuid);
        });
    }

    public function get(string $uuid): array
    {
        $board = $this->access->board($uuid);
        $board['statuses'] = $this->repo->all('SELECT id,name,position FROM eh_board_statuses WHERE board_id=? ORDER BY position,id', [$board['id']]);
        return $board;
    }

    public function update(string $uuid, array $input): array
    {
        $board = $this->access->board($uuid);
        $this->access->manage($board);
        return Support::transaction($this->repo->db, function () use ($uuid, $input, $board): array {
            $current = $this->access->board($uuid);
            $this->access->manage($current);
            if ((int)($input['expected_revision'] ?? 0) !== (int)$current['revision']) {
                throw new HubException('version_conflict', 409);
            }
            $title = Support::text($input['title'] ?? $current['title'], 160);
            $visibility = $input['visibility'] ?? $current['visibility'];
            $retention = $input['retention_seconds'] ?? $current['retention_seconds'];
            if (array_key_exists('retention_seconds', $input) && $input['retention_seconds'] === null) {
                $retention = null;
            }
            if (trim($title) === '' || !in_array($visibility, ['shared','private'], true) || ($retention !== null && (!is_int($retention) || $retention < 60 || $retention > 31536000))) {
                throw new HubException('invalid_board');
            }
            $this->repo->run('UPDATE eh_boards SET title=?,visibility=?,retention_seconds=?,revision=revision+1,access_revision=access_revision+1,updated_at=? WHERE id=?', [$title,$visibility,$retention,time(),$current['id']]);
            $this->repo->run('UPDATE eh_threads SET expires_at=CASE WHEN ? IS NULL THEN NULL ELSE last_reply_at+? END WHERE board_id=? AND deleted_at IS NULL', [$retention,$retention,$current['id']]);
            $this->sync->change((int)$board['id'], 'board.updated', $uuid, (int)$current['revision'] + 1);
            return $this->repo->find($uuid);
        });
    }

    public function delete(string $uuid, int $revision): void
    {
        $board = $this->access->board($uuid);
        $this->access->require('delete', $board['owner_uuid']);
        Support::transaction($this->repo->db, function () use ($uuid, $revision): void {
            $board = $this->access->board($uuid);
            $this->access->require('delete', $board['owner_uuid']);
            if ((int)$board['revision'] !== $revision) {
                throw new HubException('version_conflict', 409);
            }
            // One board tombstone immediately revokes every child read/write.
            // Bounded maintenance removes private contents without a large HTTP transaction.
            $this->repo->run('UPDATE eh_boards SET deleted_at=?,revision=revision+1,access_revision=access_revision+1,updated_at=? WHERE id=?', [time(),time(),$board['id']]);
            $this->sync->change((int)$board['id'], 'board.deleted', $uuid, $revision + 1);
        });
    }

    public function members(string $uuid): array
    {
        $b = $this->access->board($uuid);
        $this->access->manage($b);
        return $this->repo->all('SELECT user_uuid,created_at FROM eh_board_members WHERE board_id=? ORDER BY user_uuid LIMIT 100', [$b['id']]);
    }

    public function member(string $uuid, string $user, bool $add): void
    {
        $board = $this->access->board($uuid);
        $this->access->manage($board);
        if ($add && ($this->eligibleUser === null || !($this->eligibleUser)($user))) {
            throw new HubException('ineligible_user');
        }
        Support::transaction($this->repo->db, function () use ($uuid, $user, $add): void {
            $b = $this->access->board($uuid);
            $this->access->manage($b);
            if ($add) {
                $this->repo->run('INSERT OR IGNORE INTO eh_board_members VALUES(?,?,?)', [$b['id'],$user,time()]);
            } else {
                $this->repo->run('DELETE FROM eh_board_members WHERE board_id=? AND user_uuid=?', [$b['id'],$user]);
            }
            $this->repo->run('UPDATE eh_boards SET access_revision=access_revision+1 WHERE id=?', [$b['id']]);
            $this->sync->change((int)$b['id'], 'board.members', $uuid, (int)$b['access_revision'] + 1);
        });
    }

    public function statuses(string $uuid, array $input): array
    {
        $b = $this->access->board($uuid);
        $this->access->manage($b);
        return Support::transaction($this->repo->db, function () use ($uuid, $input): array {
            $b = $this->access->board($uuid);
            $this->access->manage($b);
            if ((int)($input['expected_revision'] ?? 0) !== (int)$b['revision']) {
                throw new HubException('version_conflict', 409);
            }
            $statuses = $input['statuses'] ?? [];
            if (!is_array($statuses) || count($statuses) < 1 || count($statuses) > 20) {
                throw new HubException('invalid_statuses');
            }
            $existing = $this->repo->all('SELECT id FROM eh_board_statuses WHERE board_id=?', [$b['id']]);
            $ids = [];
            foreach ($statuses as $position => $s) {
                $id = $s['id'] ?? Support::uuid();
                if (isset($ids[$id])) {
                    throw new HubException('invalid_statuses');
                }
                $foreign = $this->repo->one('SELECT board_id FROM eh_board_statuses WHERE id=?', [$id]);
                if ($foreign && (int)$foreign['board_id'] !== (int)$b['id']) {
                    throw new HubException('invalid_statuses');
                }
                $ids[$id] = true;
                $this->repo->run('INSERT INTO eh_board_statuses VALUES(?,?,?,?) ON CONFLICT(id) DO UPDATE SET name=excluded.name,position=excluded.position', [$id,$b['id'],Support::text($s['name'] ?? '', 80),$position]);
            }
            foreach ($existing as $s) {
                if (isset($ids[$s['id']])) {
                    continue;
                }
                $target = $input['reassign'][$s['id']] ?? null;
                if (!isset($ids[$target ?? ''])) {
                    throw new HubException('status_reassignment_required');
                }
                $order = (new ItemRepository($this->repo->db))->appendOrder((int)$b['id'], $target);
                $this->repo->run('WITH ranked AS (SELECT id,ROW_NUMBER() OVER (ORDER BY ticket_order,id)-1 AS offset FROM eh_items WHERE board_id=? AND status_id=?) UPDATE eh_items SET status_id=?,ticket_order=?+(SELECT offset FROM ranked WHERE ranked.id=eh_items.id)*1024,metadata_revision=metadata_revision+1 WHERE id IN (SELECT id FROM ranked)', [$b['id'], $s['id'], $target, $order]);
                $this->repo->run('DELETE FROM eh_board_statuses WHERE id=?', [$s['id']]);
            }
            $this->repo->run('UPDATE eh_boards SET revision=revision+1 WHERE id=?', [$b['id']]);
            // Reassignment affects arbitrary cells; invalidate the bounded viewport signature.
            $this->repo->run('UPDATE eh_boards SET access_revision=access_revision+1 WHERE id=?', [$b['id']]);
            $this->sync->change((int)$b['id'], 'board.statuses', $uuid, (int)$b['revision'] + 1, ['reset_tickets' => true,'reset_viewport' => true]);
            return $this->get($uuid)['statuses'];
        });
    }
}
