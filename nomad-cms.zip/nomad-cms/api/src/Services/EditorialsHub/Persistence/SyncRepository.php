<?php

/**
 * NOMAD CMS - Editorials Hub SyncRepository.
 *
 * Append-only, per-board sequence feed; must be called inside the business transaction.
 * Backend-only PHP/SQLite module; resource budgets and authorization are enforced at service boundaries.
 *
 * @package NomadCMS\Services\EditorialsHub\Persistence
 */

declare(strict_types=1);

namespace NomadCMS\Services\EditorialsHub\Persistence;

use NomadCMS\Services\EditorialsHub\Support;

/** Append-only, per-board sequence feed; must be called inside the business transaction. */
final class SyncRepository extends Repository
{
    public function change(int $board, string $kind, string $entity, int $revision, array $payload = [], ?array $old = null, ?array $new = null): int
    {
        $this->run('UPDATE eh_boards SET change_sequence=change_sequence+1 WHERE id=?', [$board]);
        $seq = (int)$this->one('SELECT change_sequence FROM eh_boards WHERE id=?', [$board])['change_sequence'];
        $this->run('INSERT INTO eh_changes VALUES(?,?,?,?,?,?,?,?,?)', [$board,$seq,$kind,$entity,$revision,Support::json($payload),$old ? Support::json($old) : null,$new ? Support::json($new) : null,time()]);
        return $seq;
    }
}
