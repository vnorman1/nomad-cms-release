<?php

/**
 * NOMAD CMS - Editorials Hub BoardRepository.
 *
 * Board and membership queries, including immediate soft-delete filtering.
 * Backend-only PHP/SQLite module; resource budgets and authorization are enforced at service boundaries.
 *
 * @package NomadCMS\Services\EditorialsHub\Persistence
 */

declare(strict_types=1);

namespace NomadCMS\Services\EditorialsHub\Persistence;

/** Board and membership queries, including immediate soft-delete filtering. */
final class BoardRepository extends Repository
{
    public function find(string $uuid): ?array
    {
        return $this->one('SELECT * FROM eh_boards WHERE uuid=? AND deleted_at IS NULL', [$uuid]);
    }
    public function member(int $board, string $user): bool
    {
        return $this->one('SELECT 1 FROM eh_board_members WHERE board_id=? AND user_uuid=?', [$board,$user]) !== null;
    }
}
