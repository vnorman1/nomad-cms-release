<?php

/**
 * NOMAD CMS - Editorials Hub Repository.
 *
 * Prepared-query helpers and transactional replay records; no request-global state.
 * Backend-only PHP/SQLite module; resource budgets and authorization are enforced at service boundaries.
 *
 * @package NomadCMS\Services\EditorialsHub\Persistence
 */

declare(strict_types=1);

namespace NomadCMS\Services\EditorialsHub\Persistence;

use NomadCMS\Services\EditorialsHub\HubException;
use NomadCMS\Services\EditorialsHub\Support;
use PDO;

/** Prepared-query helpers and transactional replay records; no request-global state. */
abstract class Repository
{
    public function __construct(public readonly PDO $db)
    {
    }
    public function run(string $sql, array $parameters = []): \PDOStatement
    {
        $stmt = $this->db->prepare($sql);
        $stmt->execute($parameters);
        return $stmt;
    }
    public function one(string $sql, array $parameters = []): ?array
    {
        $stmt = $this->run($sql, $parameters);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $stmt->closeCursor();
        return $row ?: null;
    }
    public function all(string $sql, array $parameters = []): array
    {
        $stmt = $this->run($sql, $parameters);
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $stmt->closeCursor();
        return $rows;
    }
    public function idempotent(string $actor, string $operation, string $key, array $input, callable $work): array
    {
        Support::key($key);
        $checksum = hash('sha256', Support::json($input));
        return Support::transaction($this->db, function () use ($actor, $operation, $key, $checksum, $work): array {
            $old = $this->one('SELECT checksum,result FROM eh_requests WHERE actor_uuid=? AND operation=? AND request_key=?', [$actor,$operation,$key]);
            if ($old) {
                if (!hash_equals($old['checksum'], $checksum)) {
                    throw new HubException('idempotency_conflict', 409);
                }
                return json_decode($old['result'], true, 64, JSON_THROW_ON_ERROR);
            }
            $result = $work();
            $this->run('INSERT INTO eh_requests VALUES(?,?,?,?,?,?)', [$actor,$operation,$key,$checksum,Support::json($result),time()]);
            return $result;
        });
    }
}
