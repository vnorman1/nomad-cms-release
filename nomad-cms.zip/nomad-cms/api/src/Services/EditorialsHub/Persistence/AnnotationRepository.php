<?php

/**
 * NOMAD CMS - Editorials Hub AnnotationRepository.
 *
 * Bounded, indexed reverse lookups from CMS identities to live Hub comments.
 * Deleted cards, boards and expired threads disappear before physical cleanup.
 *
 * @package NomadCMS\Services\EditorialsHub\Persistence
 */

declare(strict_types=1);

namespace NomadCMS\Services\EditorialsHub\Persistence;

/** Persistence for target-anchored threads; no whole-board or CMS scans. */
final class AnnotationRepository extends Repository
{
    public const SELECT = 'SELECT a.*,t.owner_uuid,t.title AS thread_title,t.revision AS thread_revision,t.last_reply_at,t.created_at,t.expires_at,b.uuid AS board_uuid,b.title AS board_title,i.title AS item_title,i.x,i.y,i.width,i.height FROM eh_annotations a JOIN eh_threads t ON t.uuid=a.thread_id JOIN eh_items i ON i.uuid=a.item_id JOIN eh_boards b ON b.id=a.board_id';
    public const LIVE = 't.deleted_at IS NULL AND i.deleted_at IS NULL AND b.deleted_at IS NULL AND (t.expires_at IS NULL OR t.expires_at>?)';

    public function find(string $threadId): ?array
    {
        return $this->one(self::SELECT . ' WHERE a.thread_id=? AND ' . self::LIVE, [$threadId, time()]);
    }

    public function firstMessage(string $threadId): ?array
    {
        return $this->one('SELECT uuid,author_uuid,body,revision,created_at,updated_at FROM eh_messages WHERE thread_id=? AND deleted_at IS NULL ORDER BY id LIMIT 1', [$threadId]);
    }
}
