<?php

/**
 * NOMAD CMS - Editorials Hub ItemRepository.
 *
 * Light card projections and bounded spatial queries, with an exact B-tree fallback.
 * Backend-only PHP/SQLite module; resource budgets and authorization are enforced at service boundaries.
 *
 * @package NomadCMS\Services\EditorialsHub\Persistence
 */

declare(strict_types=1);

namespace NomadCMS\Services\EditorialsHub\Persistence;

use NomadCMS\Services\EditorialsHub\HubConfig;
use NomadCMS\Services\EditorialsHub\Support;

/** Light card projections and bounded spatial queries, with an exact B-tree fallback. */
final class ItemRepository extends Repository
{
    public const LIGHT = 'i.id,i.uuid,i.board_id,i.owner_uuid,i.type,i.x,i.y,i.width,i.height,i.title,i.preview,i.status_id,i.assignee_uuid,i.priority,i.due_at,i.attachment_id,i.media_filename,i.thread_count,i.metadata_revision,i.geometry_revision,i.ticket_order';

    /** Append using the status index; callers already hold the transaction writer lock. */
    public function appendOrder(int $boardId, string $statusId): int
    {
        $last = $this->one('SELECT ticket_order FROM eh_items WHERE board_id=? AND status_id=? AND deleted_at IS NULL ORDER BY ticket_order DESC,id DESC LIMIT 1', [$boardId, $statusId]);
        $order = (int)($last['ticket_order'] ?? 0);
        if ($order > PHP_INT_MAX - 1024) {
            $this->rebalanceOrder($boardId, $statusId);
            return $this->appendOrder($boardId, $statusId);
        }

        return $order + 1024;
    }

    /** Rare gap exhaustion is resolved in SQLite without hydrating the column into PHP. */
    public function rebalanceOrder(int $boardId, string $statusId): void
    {
        $this->run('WITH ranked AS (SELECT id,ROW_NUMBER() OVER (ORDER BY ticket_order,id)*1024 AS rank FROM eh_items WHERE board_id=? AND status_id=? AND deleted_at IS NULL) UPDATE eh_items SET ticket_order=(SELECT rank FROM ranked WHERE ranked.id=eh_items.id) WHERE id IN (SELECT id FROM ranked)', [$boardId, $statusId]);
    }

    public function find(string $uuid): ?array
    {
        $item = $this->one('SELECT * FROM eh_items WHERE uuid=? AND deleted_at IS NULL', [$uuid]);
        return $item ? $this->withCanvasDrafts([$item])[0] : null;
    }

    /** Hydrate lightweight presentation descriptors in one bounded indexed query. */
    public function withCanvasDrafts(array $items): array
    {
        if ($items === []) {
            return [];
        }
        $ids = array_column($items, 'uuid');
        $parameters = implode(',', array_fill(0, count($ids), '?'));
        $drafts = [];
        foreach ($this->all("SELECT item_id,id,revision FROM eh_proposals WHERE role='canvas_draft' AND item_id IN ({$parameters})", $ids) as $proposal) {
            $drafts[$proposal['item_id']] = ['proposal_id' => $proposal['id'], 'revision' => (int)$proposal['revision']];
        }
        foreach ($items as &$item) {
            $item['cms_draft'] = $drafts[$item['uuid']] ?? null;
        }
        unset($item);
        return $items;
    }
    public function rtree(): bool
    {
        return ($this->one("SELECT value FROM eh_settings WHERE key='spatial_mode'")['value'] ?? '') === 'rtree';
    }

    public function spatialSql(bool $rtree, bool $owner = false): string
    {
        $from = $rtree ? 'eh_item_bounds r CROSS JOIN eh_items i ON i.id=r.id' : 'eh_items i INDEXED BY eh_items_x';
        $filter = $rtree ? ' AND r.min_board<=? AND r.max_board>=? AND r.min_x<=? AND r.max_x>=? AND r.min_y<=? AND r.max_y>=?' : ' AND i.min_x>=?';
        return 'SELECT ' . self::LIGHT . ' FROM ' . $from . ' WHERE i.board_id=? AND i.deleted_at IS NULL AND i.id>?' . $filter . ' AND i.min_x<=? AND i.max_x>=? AND i.min_y<=? AND i.max_y>=?' . ($owner ? ' AND i.owner_uuid=?' : '') . ' ORDER BY i.id LIMIT ?';
    }

    public function spatial(int $board, array $b, int $after, int $limit, ?string $owner = null): array
    {
        $rtree = $this->rtree();
        $params = [$board,$after];
        if ($rtree) {
            array_push($params, $board, $board, $b['max_x'], $b['min_x'], $b['max_y'], $b['min_y']);
        } else {
            // Card width is bounded by validation/schema, so distant origins cannot intersect.
            $params[] = $b['min_x'] - 4096;
        }
        array_push($params, $b['max_x'], $b['min_x'], $b['max_y'], $b['min_y']);
        if ($owner !== null) {
            $params[] = $owner;
        }
        $stmt = $this->db->prepare($this->spatialSql($rtree, $owner !== null));
        foreach ($params as $i => $value) {
            $stmt->bindValue($i + 1, $value, is_int($value) ? \PDO::PARAM_INT : \PDO::PARAM_STR);
        }
        $stmt->bindValue(count($params) + 1, $limit, \PDO::PARAM_INT);
        $stmt->execute();
        $rows = $stmt->fetchAll(\PDO::FETCH_ASSOC);
        $stmt->closeCursor();
        return $this->withCanvasDrafts($rows);
    }

    public static function boundsOf(array $item): array
    {
        return ['min_x' => (float)$item['min_x'],'max_x' => (float)$item['max_x'],'min_y' => (float)$item['min_y'],'max_y' => (float)$item['max_y']];
    }

    public static function cells(array $bounds, int $level): array
    {
        $size = HubConfig::TILE_SIZE * (2 ** $level);
        $cells = [];
        for ($x = (int)floor($bounds['min_x'] / $size); $x <= (int)floor($bounds['max_x'] / $size); $x++) {
            for ($y = (int)floor($bounds['min_y'] / $size); $y <= (int)floor($bounds['max_y'] / $size); $y++) {
                $cells[$x . ':' . $y] = [$x,$y];
            }
        }
        return $cells;
    }

    public function touchTiles(int $board, ?array $old, ?array $new, string $type, string $owner): void
    {
        $stmt = $this->db->prepare('INSERT INTO eh_tiles(board_id,level,tile_x,tile_y,owner_uuid,revision,item_count,note_count,image_count) VALUES(?,?,?,?,?,1,?,?,?) ON CONFLICT(board_id,level,owner_uuid,tile_x,tile_y) DO UPDATE SET revision=revision+1,item_count=item_count+excluded.item_count,note_count=note_count+excluded.note_count,image_count=image_count+excluded.image_count');
        for ($level = 0; $level < HubConfig::TILE_LEVELS; $level++) {
            $before = $old ? self::cells($old, $level) : [];
            $after = $new ? self::cells($new, $level) : [];
            foreach ($before + $after as $key => [$x,$y]) {
                $delta = (isset($after[$key]) ? 1 : 0) - (isset($before[$key]) ? 1 : 0);
                foreach (['',$owner] as $scope) {
                    $stmt->execute([$board,$level,$x,$y,$scope,$delta,$type === 'note' ? $delta : 0,$type === 'image' ? $delta : 0]);
                }
            }
        }
    }
}
