<?php

/**
 * NOMAD CMS - Editorials Hub ThreadRepository.
 *
 * Live thread and message lookups; expiry is effective before physical cleanup.
 * Backend-only PHP/SQLite module; resource budgets and authorization are enforced at service boundaries.
 *
 * @package NomadCMS\Services\EditorialsHub\Persistence
 */

declare(strict_types=1);

namespace NomadCMS\Services\EditorialsHub\Persistence;

/** Live thread and message lookups; expiry is effective before physical cleanup. */
final class ThreadRepository extends Repository
{
    public function find(string $uuid): ?array
    {
        return $this->one('SELECT * FROM eh_threads WHERE uuid=? AND deleted_at IS NULL AND (expires_at IS NULL OR expires_at>?)', [$uuid,time()]);
    }
    public function message(string $uuid): ?array
    {
        $message = $this->one('SELECT * FROM eh_messages WHERE uuid=? AND deleted_at IS NULL', [$uuid]);
        return $message === null ? null : $this->withReferences([$message])[0];
    }

    /** Hydrate one bounded page with one association query instead of per-message lookups. */
    public function withReferences(array $messages): array
    {
        if ($messages === []) {
            return [];
        }
        $ids = array_column($messages, 'uuid');
        $marks = implode(',', array_fill(0, count($ids), '?'));
        $references = $this->all('SELECT message_id,reference_id FROM eh_message_references WHERE message_id IN (' . $marks . ') ORDER BY message_id,position,reference_id', $ids);
        $byMessage = [];
        foreach ($references as $reference) {
            $byMessage[$reference['message_id']][] = $reference['reference_id'];
        }
        foreach ($messages as &$message) {
            $message['references'] = $byMessage[$message['uuid']] ?? [];
        }
        unset($message);

        return $messages;
    }

    public function replaceReferences(string $messageId, array $references): void
    {
        $this->run('DELETE FROM eh_message_references WHERE message_id=?', [$messageId]);
        foreach ($references as $position => $referenceId) {
            $this->run('INSERT INTO eh_message_references(message_id,reference_id,position) VALUES(?,?,?)', [$messageId, $referenceId, $position]);
        }
    }
}
