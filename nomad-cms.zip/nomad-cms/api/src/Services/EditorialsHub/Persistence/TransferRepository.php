<?php

/**
 * NOMAD CMS - Editorials Hub TransferRepository.
 *
 * Durable preview/receipt records used to reconcile independent SQLite commits.
 * Backend-only PHP/SQLite module; resource budgets and authorization are enforced at service boundaries.
 *
 * @package NomadCMS\Services\EditorialsHub\Persistence
 */

declare(strict_types=1);

namespace NomadCMS\Services\EditorialsHub\Persistence;

/** Durable preview/receipt records used to reconcile independent SQLite commits. */
final class TransferRepository extends Repository
{
    public function plan(string $id): ?array
    {
        return $this->one('SELECT * FROM eh_transfer_plans WHERE id=?', [$id]);
    }
    public function receipt(string $key): ?array
    {
        return $this->one('SELECT * FROM eh_transfer_receipts WHERE idempotency_key=?', [$key]);
    }
}
