<?php

/**
 * NOMAD CMS - Editorials Hub ReferenceRepository.
 *
 * Stable reference bindings; resolved titles and privileges are never stored as authority.
 * Backend-only PHP/SQLite module; resource budgets and authorization are enforced at service boundaries.
 *
 * @package NomadCMS\Services\EditorialsHub\Persistence
 */

declare(strict_types=1);

namespace NomadCMS\Services\EditorialsHub\Persistence;

/** Stable reference bindings; resolved titles and privileges are never stored as authority. */
final class ReferenceRepository extends Repository
{
    public function find(string $id): ?array
    {
        return $this->one('SELECT * FROM eh_references WHERE id=?', [$id]);
    }
    public function proposal(string $id): ?array
    {
        return $this->one('SELECT * FROM eh_proposals WHERE id=?', [$id]);
    }
}
