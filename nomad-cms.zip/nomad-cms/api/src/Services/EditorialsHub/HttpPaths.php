<?php

/**
 * NOMAD CMS - Editorials Hub HttpPaths.
 *
 * Exact route-family matching for logging and bootstrap exclusions, including dev aliases.
 * Backend-only PHP/SQLite module; resource budgets and authorization are enforced at service boundaries.
 *
 * @package NomadCMS\Services\EditorialsHub
 */

declare(strict_types=1);

namespace NomadCMS\Services\EditorialsHub;

/** Exact route-family matching for logging and bootstrap exclusions, including dev aliases. */
final class HttpPaths
{
    public static function isHub(string $uri): bool
    {
        $path = (string)parse_url($uri, PHP_URL_PATH);
        return preg_match('~^(?:/api)?/(?:admin/editorials(?:/|$)|endpoints/admin/editorials/[^/]+\.php$)~D', $path) === 1;
    }
}
