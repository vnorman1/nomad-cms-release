<?php

/**
 * NOMAD CMS - Editorials Hub ObjectListWriter.
 *
 * Object/list mutation through the native, versioned slot saver with hash concurrency.
 * Backend-only PHP/SQLite module; resource budgets and authorization are enforced at service boundaries.
 *
 * @package NomadCMS\Services\EditorialsHub\Integration\Writers
 */

declare(strict_types=1);

namespace NomadCMS\Services\EditorialsHub\Integration\Writers;

use NomadCMS\Database\ContentDatabase;
use NomadCMS\Services\EditorialsHub\Contracts\HubRequestContext;
use NomadCMS\Services\EditorialsHub\HubException;
use NomadCMS\Services\EditorialsHub\Integration\DestinationWriterInterface;
use NomadCMS\Services\EditorialsHub\Support;
use NomadCMS\Services\SitemapService;
use NomadCMS\Services\StaticCacheService;
use PDO;

/** Object/list mutation through the native, versioned slot saver with hash concurrency. */
final class ObjectListWriter implements DestinationWriterInterface
{
    public function __construct(private PDO $db, private HubRequestContext $context)
    {
    }
    public function database(): PDO
    {
        return $this->db;
    }
    public function write(array $plan): array
    {
        $slot = $plan['target']['slot'];
        $stmt = $this->db->prepare('SELECT data FROM slots WHERE key=? AND length(data)<=2097152');
        $stmt->execute([$slot]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $stmt->closeCursor();
        $data = $row ? json_decode($row['data'], true, 64, JSON_THROW_ON_ERROR) : null;
        $hash = $data === null ? null : ContentDatabase::computeContentHash($data);
        if ($hash !== ($plan['preconditions']['expected_hash'] ?? null)) {
            throw new HubException('version_conflict', 409);
        }
        if ($plan['slot_type'] === 'list') {
            $data ??= [];
            $uid = $plan['destination_uid'];
            if ($plan['create']) {
                $data[] = ['_dndId' => $uid] + $plan['values'];
            } else {
                $found = false;
                foreach ($data as &$entry) {
                    if (($entry['_dndId'] ?? null) === $uid) {
                            $entry = array_replace($entry, $plan['values']);
                            $found = true;
                            break;
                    }
                } unset($entry);
                if (!$found) {
                    throw new HubException('target_unavailable', 404);
                }
            }
        } else {
            if ($data === null) {
                throw new HubException('target_unavailable', 404);
            } $data = array_replace($data, $plan['values']);
        }
        ContentDatabase::saveSlot($slot, $data, ['expected_hash' => $hash,'require_existing' => $row !== false && $row !== null,'owner_uuid' => $this->context->uuid,'changed_by' => $this->context->uuid,'slot_type' => $plan['slot_type'],'defer_effects' => true]);
        return ['kind' => 'slot','slot' => $slot,'item' => $plan['slot_type'] === 'list' ? $plan['destination_uid'] : null];
    }
    public function postCommit(array $plan): void
    {
        SitemapService::markDirty();
        StaticCacheService::invalidateSlot($plan['target']['slot']);
        foreach (\NomadCMS\Services\RelationService::getDependentSlots($plan['target']['slot']) as $dependent) {
            if (\NomadCMS\Database\CollectionDatabase::isRegistered($dependent)) {
                StaticCacheService::markCollectionDirty($dependent);
            } else {
                StaticCacheService::invalidateSlot($dependent);
            }
        }
    }
}
