<?php

/**
 * NOMAD CMS - Editorials Hub CollectionWriter.
 *
 * Native collection API preserves row storage, HMAC history, blocks and ownership checks.
 * Backend-only PHP/SQLite module; resource budgets and authorization are enforced at service boundaries.
 *
 * @package NomadCMS\Services\EditorialsHub\Integration\Writers
 */

declare(strict_types=1);

namespace NomadCMS\Services\EditorialsHub\Integration\Writers;

use NomadCMS\Services\CollectionApiService;
use NomadCMS\Services\EditorialsHub\Integration\DestinationWriterInterface;
use PDO;

/** Native collection API preserves row storage, HMAC history, blocks and ownership checks. */
final class CollectionWriter implements DestinationWriterInterface
{
    public function __construct(private PDO $db)
    {
    }
    public function database(): PDO
    {
        return $this->db;
    }
    public function write(array $plan): array
    {
        $body = ['item_dnd_id' => $plan['destination_uid'],'operation' => $plan['create'] ? 'create' : 'update','item_data' => $plan['values'],'expected_schema_revision' => $plan['schema_revision']];
        if (!$plan['create']) {
            $body['expected_revision'] = $plan['preconditions']['expected_revision'];
            $body['client_updated_at'] = $plan['preconditions']['client_updated_at'];
        }
        try {
            CollectionApiService::write($plan['target']['slot'], $body, true);
        } catch (\NomadCMS\Database\OptimisticLockException $error) {
            throw new \NomadCMS\Services\EditorialsHub\HubException('version_conflict', 409);
        }
        return ['kind' => 'slot','slot' => $plan['target']['slot'],'item' => $plan['destination_uid']];
    }
    public function postCommit(array $plan): void
    {
        CollectionApiService::invalidateAfterCommit($plan['target']['slot']);
    }
}
