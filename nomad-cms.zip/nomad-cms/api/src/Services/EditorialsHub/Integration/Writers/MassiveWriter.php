<?php

/**
 * NOMAD CMS - Editorials Hub MassiveWriter.
 *
 * Native encrypted/indexed MASSIVE writes; the Hub and destination share one SQLite file.
 * Backend-only PHP/SQLite module; resource budgets and authorization are enforced at service boundaries.
 *
 * @package NomadCMS\Services\EditorialsHub\Integration\Writers
 */

declare(strict_types=1);

namespace NomadCMS\Services\EditorialsHub\Integration\Writers;

use NomadCMS\Database\MassiveDatabase;
use NomadCMS\Services\EditorialsHub\Contracts\HubRequestContext;
use NomadCMS\Services\EditorialsHub\Contracts\TargetDescriptor;
use NomadCMS\Services\EditorialsHub\HubException;
use NomadCMS\Services\EditorialsHub\Integration\DestinationWriterInterface;
use NomadCMS\Services\EditorialsHub\References\Adapters\SlotTargetAdapter;
use PDO;

/** Native encrypted/indexed MASSIVE writes; the Hub and destination share one SQLite file. */
final class MassiveWriter implements DestinationWriterInterface
{
    public function __construct(private PDO $db, private HubRequestContext $context, private SlotTargetAdapter $slots)
    {
    }
    public function database(): PDO
    {
        return $this->db;
    }
    public function write(array $plan): array
    {
        $slot = $plan['target']['slot'];
        $d = $this->slots->definition($slot);
        $encrypted = (bool)($d['encrypted'] ?? false);
        $searchable = $d['searchableFields'] ?? [];
        if ($plan['create']) {
            $id = MassiveDatabase::insert($slot, $plan['values'], $encrypted, $searchable, $this->context->uuid);
        } else {
            $record = $this->slots->record(TargetDescriptor::fromArray($plan['target']));
            if ($record['preconditions']['content_hash'] !== $plan['preconditions']['content_hash']) {
                throw new HubException('version_conflict', 409);
            }
            $id = (int)$plan['target']['item'];
            if (!MassiveDatabase::update($slot, $id, array_replace($record['data'], $plan['values']), $encrypted, $searchable)) {
                throw new HubException('target_unavailable', 404);
            }
        }
        return ['kind' => 'slot','slot' => $slot,'item' => (string)$id];
    }
    public function postCommit(array $plan): void
    {
    }
}
