<?php

/**
 * NOMAD CMS - Editorials Hub MediaMetadataWriter.
 *
 * Apply only declared media metadata through the existing metadata writer.
 * New media publications preserve existing files and metadata on retries.
 * Backend-only PHP/SQLite module; resource budgets and authorization are enforced at service boundaries.
 *
 * @package NomadCMS\Services\EditorialsHub\Integration\Writers
 */

declare(strict_types=1);

namespace NomadCMS\Services\EditorialsHub\Integration\Writers;

use NomadCMS\Database\ContentDatabase;
use NomadCMS\Services\EditorialsHub\HubException;
use NomadCMS\Services\EditorialsHub\Integration\DestinationWriterInterface;
use NomadCMS\Services\EditorialsHub\References\Adapters\MediaTargetAdapter;
use NomadCMS\Services\EditorialsHub\Support;
use PDO;

/** Apply only declared media metadata through the existing metadata writer. */
final class MediaMetadataWriter implements DestinationWriterInterface
{
    public function __construct(private PDO $db, private MediaTargetAdapter $media)
    {
    }
    public function database(): PDO
    {
        return $this->db;
    }
    public function write(array $plan): array
    {
        if ($plan['create']) {
            $file = $plan['destination_uid'];
            $statement = $this->db->prepare('SELECT 1 FROM media_meta WHERE filename=?');
            $statement->execute([$file]);
            $exists = (bool) $statement->fetchColumn();
            $statement->closeCursor();
            if ($exists) {
                // Reusing an already published image never overwrites its metadata or bytes.
                $this->media->record($file);
            } else {
                $publication = $plan['media_publication'] ?? null;
                if (!$publication || !ContentDatabase::saveMediaMeta(
                    $file,
                    [],
                    title: $plan['values']['title'] ?? '',
                    mimeType: $publication['mime'],
                    dimensions: ['width' => $publication['width'], 'height' => $publication['height']],
                    uploadedBy: $plan['actor_uuid'],
                )) {
                    throw new HubException('media_write_failed', 503);
                }
            }
            return ['kind' => 'media', 'item' => $file];
        }
        $file = $plan['target']['item'];
        $old = $this->media->record($file);
        if (hash('sha256', Support::json($old)) !== $plan['preconditions']['content_hash']) {
            throw new HubException('version_conflict', 409);
        }
        $v = $plan['values'];
        if (!ContentDatabase::saveMediaMeta($file, $v['alt'] ?? [], $v['title'] ?? null, $v['caption'] ?? null, $v['tags'] ?? null)) {
            throw new HubException('media_write_failed', 503);
        }
        return ['kind' => 'media','item' => $file];
    }
    public function postCommit(array $plan): void
    {
    }
}
