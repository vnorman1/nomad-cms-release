<?php

/**
 * NOMAD CMS — Editorial proposal media bindings.
 *
 * Validates ordered schema-field media sources and resolves private attachments
 * into deterministic publication plans without publishing during preview.
 * All identities are authorized against the proposal's own board and schema.
 *
 * @package NomadCMS\Services\EditorialsHub\Integration
 */

declare(strict_types=1);

namespace NomadCMS\Services\EditorialsHub\Integration;

use NomadCMS\Services\EditorialsHub\Contracts\TargetDescriptor;
use NomadCMS\Services\EditorialsHub\HubException;
use NomadCMS\Services\EditorialsHub\References\Adapters\SlotTargetAdapter;
use NomadCMS\Services\EditorialsHub\References\TargetRegistry;
use NomadCMS\Services\EditorialsHub\Support;
use PDO;

/** Bounded, server-owned conversion from draft media identities to CMS URLs. */
final class ProposalMediaService
{
    public function __construct(private PDO $db, private TargetRegistry $targets)
    {
    }

    public function normalize(TargetDescriptor $target, mixed $bindings, array $values, int $board): array
    {
        if (
            !is_array($bindings)
            || !array_is_list($bindings)
            || count($bindings) > 100
            || strlen(Support::json($bindings)) > 131072
        ) {
            throw new HubException('invalid_media');
        }
        if ($bindings === []) {
            return [];
        }
        if ($target->kind !== 'slot') {
            throw new HubException('image_target_incompatible');
        }
        $definition = $this->targets->slots->definition($target->slot);
        $seen = [];
        $attachments = [];
        $result = [];
        foreach ($bindings as $binding) {
            if (!is_array($binding) || !is_string($binding['field'] ?? null)) {
                throw new HubException('invalid_media');
            }
            $id = $binding['field'];
            $field = SlotTargetAdapter::field($definition, $id);
            $type = $field['type'] ?? '';
            if (
                !$field
                || ($field['hidden'] ?? false)
                || ($field['readonly'] ?? $field['readOnly'] ?? false)
                || ($field['disabled'] ?? false)
                || !in_array($type, ['image', 'gif', 'gallery'], true)
            ) {
                throw new HubException('field_not_writable', 422, ['field' => $id]);
            }
            if (($target->field !== null && $target->field !== $id) || array_key_exists($id, $values)) {
                throw new HubException('proposal_field_mismatch');
            }
            $locale = $binding['locale'] ?? null;
            if (($field['localized'] ?? false) && $locale === null) {
                $locale = $this->targets->slots->schema()['i18n']['defaultLanguage'] ?? 'hu';
            }
            if (
                $locale !== null
                && (
                    !is_string($locale)
                    || !($field['localized'] ?? false)
                    || !in_array($locale, $this->targets->slots->schema()['i18n']['languages'] ?? [], true)
                )
            ) {
                throw new HubException('invalid_locale');
            }
            $key = $id . ':' . ($locale ?? '');
            $sources = $binding['sources'] ?? null;
            if (isset($seen[$key]) || !is_array($sources) || !array_is_list($sources) || count($sources) > ($type === 'gallery' ? 100 : 1)) {
                throw new HubException('invalid_media');
            }
            $seen[$key] = true;
            $normalized = [];
            $sourceKeys = [];
            foreach ($sources as $source) {
                if (!is_array($source)) {
                    throw new HubException('invalid_media');
                }
                if (($source['kind'] ?? '') === 'attachment') {
                    $attachment = $this->attachment(Support::text($source['attachment_id'] ?? '', 128), $board);
                    if ($type === 'gif' && $attachment['mime'] !== 'image/gif') {
                        throw new HubException('image_target_incompatible');
                    }
                    $entry = ['kind' => 'attachment', 'attachment_id' => $attachment['id']];
                    $sourceKey = 'attachment:' . $attachment['id'];
                    $attachments[$attachment['id']] = true;
                } elseif (($source['kind'] ?? '') === 'media') {
                    $filename = Support::text($source['filename'] ?? '', 2048);
                    $image = $this->targets->media->image($filename, $locale);
                    if ($type === 'gif' && ($image['mime'] ?? '') !== 'image/gif') {
                        throw new HubException('image_target_incompatible');
                    }
                    $entry = ['kind' => 'media', 'filename' => $filename];
                    $sourceKey = 'media:' . $filename;
                } else {
                    throw new HubException('invalid_media');
                }
                if (!isset($sourceKeys[$sourceKey])) {
                    $normalized[] = $entry;
                    $sourceKeys[$sourceKey] = true;
                }
            }
            if (count($attachments) > 100) {
                throw new HubException('invalid_media');
            }
            $result[] = ['field' => $id, 'locale' => $locale, 'sources' => $normalized];
        }
        return $result;
    }

    public function attachment(string $id, int $board): array
    {
        $statement = $this->db->prepare('SELECT * FROM eh_attachments WHERE id=? AND board_id=? AND deleted_at IS NULL');
        $statement->execute([$id, $board]);
        $attachment = $statement->fetch(PDO::FETCH_ASSOC);
        $statement->closeCursor();
        if (!$attachment) {
            throw new HubException('attachment_unavailable', 404);
        }
        return $attachment;
    }

    public static function publication(array $attachment): array
    {
        $extension = match ($attachment['mime']) {
            'image/png' => 'png',
            'image/jpeg' => 'jpg',
            'image/webp' => 'webp',
            'image/gif' => 'gif',
            'image/avif' => 'avif',
            default => throw new HubException('invalid_image'),
        };
        return [
            'attachment_id' => $attachment['id'],
            'filename' => 'eh-' . $attachment['id'] . '.' . $extension,
            'checksum' => $attachment['checksum'],
            'mime' => $attachment['mime'],
            'width' => $attachment['width'],
            'height' => $attachment['height'],
        ];
    }

    /** Return values and publication metadata; filesystem side effects belong to apply. */
    public function resolve(array $bindings, array $values, int $board, string $slot): array
    {
        $publications = [];
        $definition = $this->targets->slots->definition($slot);
        foreach ($bindings as $binding) {
            $field = $binding['field'];
            $urls = [];
            foreach ($binding['sources'] as $source) {
                if ($source['kind'] === 'attachment') {
                    $publication = self::publication($this->attachment($source['attachment_id'], $board));
                    $publications[$publication['attachment_id']] = $publication;
                    $urls[] = '/api/uploads/' . $publication['filename'];
                } else {
                    $urls[] = $this->targets->media->image($source['filename'], $binding['locale'])['url'];
                }
            }
            $type = SlotTargetAdapter::field($definition, $field)['type'];
            $value = $type === 'gallery' ? $urls : ($urls[0] ?? null);
            if ($binding['locale'] !== null) {
                $values[$field][$binding['locale']] = $value;
            } else {
                $values[$field] = $value;
            }
        }
        return ['values' => $values, 'publications' => array_values($publications)];
    }
}
