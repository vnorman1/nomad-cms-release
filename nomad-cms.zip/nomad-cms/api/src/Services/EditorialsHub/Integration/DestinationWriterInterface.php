<?php

/**
 * NOMAD CMS - Editorials Hub DestinationWriterInterface.
 *
 * Native destination writers run inside the destination receipt transaction.
 * Backend-only PHP/SQLite module; resource budgets and authorization are enforced at service boundaries.
 *
 * @package NomadCMS\Services\EditorialsHub\Integration
 */

declare(strict_types=1);

namespace NomadCMS\Services\EditorialsHub\Integration;

use PDO;

/** Native destination writers run inside the destination receipt transaction. */
interface DestinationWriterInterface
{
    public function database(): PDO;
    public function write(array $plan): array;
    public function postCommit(array $plan): void;
}
