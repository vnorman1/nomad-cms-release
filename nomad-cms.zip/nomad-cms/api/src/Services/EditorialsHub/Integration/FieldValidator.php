<?php

/**
 * NOMAD CMS - Editorials Hub FieldValidator.
 *
 * Shared server-side schema validation; projections never supply raw HTML or executable fields.
 * Backend-only PHP/SQLite module; resource budgets and authorization are enforced at service boundaries.
 *
 * @package NomadCMS\Services\EditorialsHub\Integration
 */

declare(strict_types=1);

namespace NomadCMS\Services\EditorialsHub\Integration;

use NomadCMS\Services\Schema\TemporalField;
use NomadCMS\Services\EditorialsHub\Contracts\TargetDescriptor;
use NomadCMS\Services\EditorialsHub\HubConfig;
use NomadCMS\Services\EditorialsHub\HubException;
use NomadCMS\Services\EditorialsHub\References\Adapters\SlotTargetAdapter;
use NomadCMS\Services\EditorialsHub\References\TargetRegistry;
use NomadCMS\Services\EditorialsHub\Sync\NoteProjectionService;
use NomadCMS\Services\EditorialsHub\Support;

/** Shared server-side schema validation; projections never supply raw HTML or executable fields. */
final class FieldValidator
{
    private array $referenceExports = [];
    private ?string $sourceItem = null;
    private int $exportedMediaBytes = 0;

    public function __construct(private TargetRegistry $targets)
    {
    }

    public function normalize(array $definition, array $values, array $existing, bool $create, string $board, array|string|null $plannedMedia = null, ?string $sourceItem = null): array
    {
        $plannedMedia = is_array($plannedMedia) ? $plannedMedia : ($plannedMedia === null ? [] : [$plannedMedia]);
        $this->sourceItem = $sourceItem;
        $this->referenceExports = [];
        $this->exportedMediaBytes = 0;
        $result = [];
        foreach ($values as $id => $value) {
            $field = SlotTargetAdapter::field($definition, (string)$id);
            if (!$field || ($field['hidden'] ?? false) || ($field['readonly'] ?? $field['readOnly'] ?? false) || ($field['disabled'] ?? false) || in_array($field['type'] ?? 'text', ['slug','blocks','json','array','map','iframe','file','video','audio'], true)) {
                throw new HubException('field_not_writable', 422, ['field' => $id]);
            }
            if ($field['localized'] ?? false) {
                if (!is_array($value) || array_is_list($value) || $value === []) {
                    throw new HubException('invalid_localized_value', 422, ['field' => $id]);
                }
                $normalized = is_array($existing[$id] ?? null) ? $existing[$id] : [];
                foreach ($value as $locale => $entry) {
                    if (!in_array($locale, $this->targets->slots->schema()['i18n']['languages'] ?? [], true)) {
                        throw new HubException('invalid_locale');
                    }
                    $normalized[$locale] = array_key_exists($locale, $normalized) && $normalized[$locale] === $entry
                        ? $entry : $this->scalar($field, $entry, $board, $plannedMedia);
                }
                $result[$id] = $normalized;
            } else {
                $result[$id] = array_key_exists($id, $existing) && $existing[$id] === $value
                    ? $value : $this->scalar($field, $value, $board, $plannedMedia);
            }
        }
        $combined = array_replace($existing, $result);
        $default = $this->targets->slots->schema()['i18n']['defaultLanguage'] ?? 'hu';
        foreach ($definition['fields'] ?? [] as $field) {
            $id = $field['id'];
            if (!($field['required'] ?? false) || (!$create && !array_key_exists($id, $values))) {
                continue;
            }
            $value = $combined[$id] ?? null;
            if ($field['localized'] ?? false) {
                $value = is_array($value) ? ($value[$default] ?? null) : null;
            }
            if ($value === null || $value === '' || $value === []) {
                throw new HubException('required_field', 422, ['field' => $id]);
            }
        }
        if (strlen(Support::json($result)) > HubConfig::RESPONSE_BYTES - 4096) {
            throw new HubException('payload_too_large', 413);
        }
        return $result;
    }

    public function referenceExports(): array
    {
        return $this->referenceExports;
    }

    private function scalar(array $field, mixed $value, string $board, array $plannedMedia): mixed
    {
        $type = $field['type'] ?? 'text';
        if ($value === null && !($field['required'] ?? false)) {
            return null;
        }
        if ($type === 'boolean') {
            if (!is_bool($value)) {
                throw new HubException('invalid_boolean');
            } return $value;
        }
        if ($type === 'number') {
            if ((!is_int($value) && !is_float($value)) || !is_finite((float)$value) || (isset($field['min']) && $value < $field['min']) || (isset($field['max']) && $value > $field['max'])) {
                throw new HubException('invalid_number');
            } return $value;
        }
        if ($type === 'richtext') {
            if (!is_array($value)) {
                throw new HubException('richtext_ast_required');
            }
            $document = NoteProjectionService::normalize($value);
            return NoteProjectionService::html($document['ast'], function (string $reference) use ($board): string {
                if (!array_key_exists($reference, $this->referenceExports)) {
                    $this->referenceExports[$reference] = $this->targets->exportMention($reference, $board, $this->sourceItem);
                }
                $html = $this->referenceExports[$reference];
                $this->exportedMediaBytes += strlen($html);
                if ($this->exportedMediaBytes > HubConfig::RESPONSE_BYTES - 4096) {
                    throw new HubException('payload_too_large', 413);
                }
                return $html;
            });
        }
        if (in_array($type, ['relation','relation_many'], true)) {
            $ids = $type === 'relation_many' ? $value : [$value];
            if (!is_array($ids) || count($ids) > 100) {
                throw new HubException('invalid_relation');
            }
            $slot = $field['target'] ?? $field['relation']['slot'] ?? $field['targetSlot'] ?? $field['relationSlot'] ?? null;
            if (!is_string($slot)) {
                throw new HubException('invalid_relation_schema');
            }
            foreach ($ids as $id) {
                if (!is_string($id)) {
                    throw new HubException('invalid_relation');
                } $this->targets->resolve(new TargetDescriptor('slot', $slot, $id), $board);
            }
            return $type === 'relation_many' ? array_values(array_unique($ids)) : $value;
        }
        if (in_array($type, ['image','gif','gallery'], true)) {
            $images = $type === 'gallery' ? $value : [$value];
            if (!is_array($images) || count($images) > 100) {
                throw new HubException('invalid_media');
            }
            foreach ($images as $url) {
                if (!is_string($url)) {
                    throw new HubException('invalid_media');
                }
                if (in_array(str_starts_with($url, '/api/uploads/') ? substr($url, strlen('/api/uploads/')) : '', $plannedMedia, true)) {
                    continue;
                }
                $filename = str_starts_with($url, '/api/uploads/') ? rawurldecode(basename((string)parse_url($url, PHP_URL_PATH))) : $url;
                $this->targets->media->record($filename);
            }
            return $value;
        }
        if (in_array($type, ['select','multiselect'], true)) {
            $options = array_map(static fn($o)=>is_array($o) ? ($o['value'] ?? $o['id'] ?? null) : $o, $field['options'] ?? []);
            $selected = $type === 'multiselect' ? $value : [$value];
            if (!is_array($selected) || count($selected) > 100) {
                throw new HubException('invalid_selection');
            }
            foreach ($selected as $entry) {
                if (!in_array($entry, $options, true)) {
                    throw new HubException('invalid_selection');
                }
            } return $value;
        }
        $value = Support::text($value, 65536);
        if ($value === '' && !($field['required'] ?? false)) {
            return $value;
        }
        if (isset($field['maxLength']) && mb_strlen($value) > (int)$field['maxLength']) {
            throw new HubException('text_too_long');
        }
        if (isset($field['minLength']) && mb_strlen($value) < (int)$field['minLength']) {
            throw new HubException('text_too_short');
        }
        if (isset($field['pattern']) && @preg_match('~' . str_replace('~', '\\~', $field['pattern']) . '~u', $value) !== 1) {
            throw new HubException('pattern_mismatch');
        }
        if ($type === 'email' && !filter_var($value, FILTER_VALIDATE_EMAIL)) {
            throw new HubException('invalid_email');
        }
        if ($type === 'url' && (!filter_var($value, FILTER_VALIDATE_URL) || !in_array(strtolower((string)parse_url($value, PHP_URL_SCHEME)), ['http','https'], true))) {
            throw new HubException('unsafe_url');
        }
        if (TemporalField::isTemporal($field) && !TemporalField::validValue($value, $field)) {
            throw new HubException($type === 'time' ? 'invalid_time' : 'invalid_date');
        }
        if ($type === 'color' && !preg_match('/^#(?:[a-f0-9]{3}|[a-f0-9]{6}|[a-f0-9]{8})$/iD', $value)) {
            throw new HubException('invalid_color');
        }
        if (!in_array($type, ['text','textarea','email','url','date','time','color'], true)) {
            throw new HubException('unsupported_field_type');
        }
        return $value;
    }
}
