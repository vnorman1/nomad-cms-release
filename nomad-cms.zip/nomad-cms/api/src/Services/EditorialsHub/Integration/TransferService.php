<?php

/**
 * NOMAD CMS - Editorials Hub TransferService.
 *
 * Explicit preview/apply saga with a receipt committed beside every destination mutation.
 * Backend-only PHP/SQLite module; resource budgets and authorization are enforced at service boundaries.
 *
 * @package NomadCMS\Services\EditorialsHub\Integration
 */

declare(strict_types=1);

namespace NomadCMS\Services\EditorialsHub\Integration;

use NomadCMS\Database\ContentDatabase;
use NomadCMS\Services\EditorialsHub\Access\HubAccessPolicy;
use NomadCMS\Services\EditorialsHub\Contracts\TargetDescriptor;
use NomadCMS\Services\EditorialsHub\Contracts\TransferPlan;
use NomadCMS\Services\EditorialsHub\HubException;
use NomadCMS\Services\EditorialsHub\Media\ProtectedAttachmentStorage;
use NomadCMS\Services\EditorialsHub\Persistence\TransferRepository;
use NomadCMS\Services\EditorialsHub\Persistence\ItemRepository;
use NomadCMS\Services\EditorialsHub\Persistence\SyncRepository;
use NomadCMS\Services\EditorialsHub\References\TargetRegistry;
use NomadCMS\Services\EditorialsHub\References\Adapters\SlotTargetAdapter;
use NomadCMS\Services\EditorialsHub\Sync\NoteProjectionService;
use NomadCMS\Services\EditorialsHub\Support;
use PDO;

/** Explicit preview/apply saga with a receipt committed beside every destination mutation. */
final class TransferService
{
    public function __construct(private TransferRepository $repo, private HubAccessPolicy $access, private TargetRegistry $targets, private array $writers, private ProtectedAttachmentStorage $storage, private ?\Closure $afterDestinationCommit = null)
    {
    }

    private function writer(array $plan): DestinationWriterInterface
    {
        return $this->writers[$plan['writer']] ?? throw new HubException('target_not_writable', 403);
    }

    private function boardUuid(int $id): string
    {
        return $this->repo->one('SELECT uuid FROM eh_boards WHERE id=?', [$id])['uuid'];
    }

    public function preview(array $input): array
    {
        $item = $this->access->item((string)($input['item_id'] ?? ''), 'update');
        $proposal = null;
        $bindings = [];
        if (!empty($input['proposal_id'])) {
            $proposal = $this->repo->one('SELECT * FROM eh_proposals WHERE id=? AND item_id=?', [$input['proposal_id'],$item['uuid']]);
            if (!$proposal) {
                throw new HubException('not_found', 404);
            }
            $target = TargetDescriptor::fromArray(json_decode($proposal['target'], true));
            $values = json_decode($proposal['values_json'], true);
            $bindings = json_decode($proposal['field_media_json'], true);
        } else {
            $target = TargetDescriptor::fromArray($input['target'] ?? []);
            $values = $input['values'] ?? null;
        }
        $board = $this->boardUuid((int)$item['board_id']);
        $mediaLibrary = $target->kind === 'media' && $target->item === 'new' && $target->field === null;
        $resolved = $mediaLibrary ? ['writable' => true] : $this->targets->resolve($target, $board);
        if (!in_array($target->kind, ['slot','media'], true) || $target->path !== []) {
            throw new HubException('target_not_writable', 403);
        }
        $projection = $item['type'] === 'note' ? $this->repo->one('SELECT p.*,d.sequence AS head FROM eh_note_projections p JOIN eh_note_documents d ON d.note_id=p.note_id WHERE p.note_id=?', [$item['uuid']]) : null;
        if ($projection && (int)$projection['sequence'] !== (int)$projection['head']) {
            throw new HubException('projection_outdated', 409);
        }
        $create = ($target->kind === 'slot' && $target->item === 'new') || $mediaLibrary;
        $publication = null;
        $publications = [];
        $plan = ['item_id' => $item['uuid'],'board_id' => (int)$item['board_id'],'board_uuid' => $board,'actor_uuid' => $this->access->context->uuid,
            'target' => $target->toArray(),'source_revision' => (int)$item['metadata_revision'],'source_sequence' => $projection ? (int)$projection['sequence'] : null,'source_checksum' => $projection['checksum'] ?? null,
            'proposal_id' => $proposal['id'] ?? null,'proposal_revision' => $proposal ? (int)$proposal['revision'] : null,'create' => $create];
        if ($mediaLibrary) {
            $source = $this->mediaLibrarySource($item);
            $publication = $source['publication'];
            $publications = $publication === null ? [] : [$publication];
            $values = ['title' => Support::text($item['title'], 500)];
            $plan += [
                'writer' => 'media',
                'slot_type' => 'media',
                'schema_revision' => 'media-library-v1',
                'preconditions' => [],
                'destination_uid' => $source['filename'],
            ];
        } elseif ($target->kind === 'media') {
            if (!$resolved['writable'] || $target->field === null) {
                throw new HubException('target_not_writable', 403);
            }
            $record = $this->targets->media->record($target->item ?? '');
            $value = array_key_exists('value', $input) ? $input['value'] : ($values[$target->field] ?? ($projection['plain_text'] ?? $item['title']));
            if ($target->field === 'tags') {
                if (!is_array($value) || count($value) > 50) {
                    throw new HubException('invalid_tags');
                } $value = array_map(static fn($v)=>Support::text($v, 80), $value);
            } else {
                $value = Support::text($value, 65536);
            }
            if ($target->field === 'alt') {
                $locale = $target->locale ?? ($this->targets->slots->schema()['i18n']['defaultLanguage'] ?? 'hu');
                $values = ['alt' => [$locale => $value]];
            } else {
                $values = [$target->field => $value];
            }
            $plan += ['writer' => 'media','slot_type' => 'media','schema_revision' => 'media-v1','preconditions' => ['content_hash' => hash('sha256', Support::json($record))],'destination_uid' => $target->item];
        } else {
            $definition = $this->targets->slots->definition($target->slot);
            $type = $definition['type'] ?? 'object';
            if (!in_array($type, ['object','list','collection','massive'], true)) {
                throw new HubException('target_not_writable', 403);
            }
            if ($create) {
                if (!($resolved['can_create'] ?? false)) {
                    throw new HubException('target_not_writable', 403);
                }
                $record = ['data' => [],'owner' => null,'preconditions' => []];
                if ($type === 'list') {
                    $stmt = $this->writers['object_list']->database()->prepare('SELECT data FROM slots WHERE key=? AND length(data)<=2097152');
                    $stmt->execute([$target->slot]);
                    $row = $stmt->fetch(PDO::FETCH_ASSOC);
                    $stmt->closeCursor();
                    $record['preconditions']['expected_hash'] = $row ? ContentDatabase::computeContentHash(json_decode($row['data'], true)) : null;
                }
            } else {
                $record = $this->targets->slots->record($target);
                if (!$this->targets->slots->canWrite($record)) {
                    throw new HubException('target_not_writable', 403);
                }
                if ($target->field !== null && !$resolved['writable']) {
                    throw new HubException('field_not_writable');
                }
            }
            if ($bindings !== []) {
                $media = new ProposalMediaService($this->repo->db, $this->targets);
                $normalizedBindings = $media->normalize($target, $bindings, $values ?? [], (int)$item['board_id']);
                $bound = $media->resolve($normalizedBindings, $values ?? [], (int)$item['board_id'], $target->slot);
                $values = $bound['values'];
                $publications = $bound['publications'];
                if (
                    $publications !== []
                    && !$this->access->context->has('media:upload:*')
                    && !$this->access->context->has('media:upload:own')
                ) {
                    throw new HubException('forbidden', 403);
                }
            }
            if ($item['type'] === 'image') {
                if ($target->field === null && !($create && $target->slot === 'projects')) {
                    throw new HubException('image_field_required');
                }
                $fieldId = $target->field ?? 'image';
                $field = SlotTargetAdapter::field($definition, $fieldId);
                $fieldType = $field['type'] ?? '';
                if (!in_array($fieldType, ['image','gif','gallery'], true)) {
                    throw new HubException('image_target_incompatible');
                }
                if ($item['attachment_id']) {
                    $a = $this->repo->one('SELECT * FROM eh_attachments WHERE id=? AND board_id=? AND deleted_at IS NULL', [$item['attachment_id'],$item['board_id']]);
                    if (!$a) {
                        throw new HubException('attachment_unavailable', 404);
                    }
                    if (!$this->access->context->has('media:upload:*') && !$this->access->context->has('media:upload:own')) {
                        throw new HubException('forbidden', 403);
                    }
                    if ($fieldType === 'gif' && $a['mime'] !== 'image/gif') {
                        throw new HubException('image_target_incompatible');
                    }
                    $ext = match ($a['mime']) {
                        'image/png'=>'png','image/jpeg'=>'jpg','image/webp'=>'webp','image/gif'=>'gif','image/avif'=>'avif',default=>throw new HubException('invalid_image')
                    };
                    $publication = ['attachment_id' => $a['id'],'filename' => 'eh-' . $a['id'] . '.' . $ext,'checksum' => $a['checksum'],'mime' => $a['mime'],'width' => $a['width'],'height' => $a['height']];
                    $publications[] = $publication;
                    $url = '/api/uploads/' . $publication['filename'];
                } else {
                    $this->targets->media->record($item['media_filename']);
                    $url = '/api/uploads/' . $item['media_filename'];
                }
                $values = is_array($values) ? $values : [];
                $values[$fieldId] = $fieldType === 'gallery' ? [$url] : $url;
            } elseif ($values === null) {
                if ($target->field !== null) {
                    $field = SlotTargetAdapter::field($definition, $target->field);
                    $value = array_key_exists('value', $input) ? $input['value'] : (($field['type'] ?? '') === 'richtext' ? json_decode($projection['ast'], true) : trim($projection['plain_text'] ?? ''));
                    if ($field['localized'] ?? false) {
                        $value = [$target->locale ?? ($this->targets->slots->schema()['i18n']['defaultLanguage'] ?? 'hu') => $value];
                    }
                    $values = [$target->field => $value];
                } elseif ($create && $target->slot === 'projects') {
                    $values = [];
                } else {
                    throw new HubException('transfer_values_required');
                }
            }
            if ($create && $target->slot === 'projects') {
                $locale = $this->targets->slots->schema()['i18n']['defaultLanguage'] ?? 'hu';
                $titleId = $definition['titleField'] ?? 'title';
                $summaryId = $definition['summaryField'] ?? 'description';
                if (!isset($values[$titleId])) {
                    $title = $item['title'] ?: mb_substr(trim($projection['plain_text'] ?? ''), 0, 160);
                    $f = SlotTargetAdapter::field($definition, $titleId);
                    $values[$titleId] = ($f['localized'] ?? false) ? [$locale => $title] : $title;
                }
                if ($projection && !isset($values[$summaryId]) && SlotTargetAdapter::field($definition, $summaryId)) {
                    $f = SlotTargetAdapter::field($definition, $summaryId);
                    $summary = trim($projection['plain_text']);
                    $values[$summaryId] = ($f['localized'] ?? false) ? [$locale => $summary] : $summary;
                }
                if (!empty($definition['publishedField'])) {
                    $values[$definition['publishedField']] = false;
                }
            }
            if (!is_array($values)) {
                throw new HubException('invalid_transfer_values');
            }
            if ($target->field !== null && (count($values) !== 1 || !array_key_exists($target->field, $values))) {
                throw new HubException('proposal_field_mismatch');
            }
            try {
                $validator = new FieldValidator($this->targets);
                $values = $validator->normalize(
                    $definition,
                    $values,
                    $record['data'],
                    $create,
                    $board,
                    array_column($publications, 'filename'),
                    $item['uuid'],
                );
                $plan['reference_exports'] = $validator->referenceExports();
            } catch (HubException $error) {
                return [
                    'ready' => false,
                    'errors' => [['code' => $error->errorCode] + $error->details],
                    'handoff' => [
                        'navigation' => '/edit/' . rawurlencode($target->slot),
                        'values' => $values,
                    ],
                ];
            }
            $plan += ['writer' => match ($type) {
                'collection'=>'collection','massive'=>'massive',default=>'object_list'
            },'slot_type' => $type,
                'schema_revision' => hash('sha256', Support::json($definition)),'preconditions' => $record['preconditions'],'destination_uid' => $create ? Support::uuid() : $target->item];
        }
        $plan['values'] = $values;
        $plan['media_publication'] = $publication;
        $plan['media_publications'] = $publications;
        $plan = (new TransferPlan($plan))->toArray();
        $id = Support::uuid();
        $hash = hash('sha256', Support::json($plan));
        $this->repo->run('INSERT INTO eh_transfer_plans VALUES(?,?,?,?,?,?,?,?,?)', [$id,$item['board_id'],$item['uuid'],$this->access->context->uuid,$proposal['id'] ?? null,Support::json($plan),$hash,time() + 600,time()]);
        return ['ready' => true,'plan_id' => $id,'checksum' => $hash,'expires_at' => time() + 600,'target' => $target->toArray(),'values' => $values,'create' => $create];
    }

    private function authorize(array $plan, bool $checkSource): void
    {
        $item = $this->access->item($plan['item_id'], 'update');
        $target = TargetDescriptor::fromArray($plan['target']);
        $mediaLibrary = $target->kind === 'media' && $target->item === 'new' && $target->field === null;
        $resolved = $mediaLibrary ? ['writable' => true] : $this->targets->resolve($target, $plan['board_uuid']);
        if ($mediaLibrary) {
            $source = $this->mediaLibrarySource($item);
            if ($source['filename'] !== $plan['destination_uid'] || $source['publication'] !== $plan['media_publication']) {
                throw new HubException('source_changed', 409);
            }
        } elseif ($target->kind === 'slot') {
            $d = $this->targets->slots->definition($target->slot);
            if (hash('sha256', Support::json($d)) !== $plan['schema_revision']) {
                throw new HubException('schema_changed', 409);
            }
            if ($plan['create']) {
                if (!($resolved['can_create'] ?? false)) {
                    throw new HubException('target_not_writable', 403);
                }
            } elseif (!$this->targets->slots->canWrite($this->targets->slots->record($target))) {
                throw new HubException('target_not_writable', 403);
            }
            $publications = $this->publications($plan);
            if ($publications !== []) {
                if (!$this->access->context->has('media:upload:*') && !$this->access->context->has('media:upload:own')) {
                    throw new HubException('forbidden', 403);
                }
                foreach ($publications as $publication) {
                    $attachment = $this->repo->one(
                        'SELECT checksum,storage_key FROM eh_attachments WHERE id=? AND board_id=? AND deleted_at IS NULL',
                        [$publication['attachment_id'], $plan['board_id']],
                    );
                    if (!$attachment || $attachment['checksum'] !== $publication['checksum']) {
                        throw new HubException('attachment_unavailable', 404);
                    }
                }
            }
            foreach ($plan['reference_exports'] ?? [] as $reference => $html) {
                if ($this->targets->exportMention($reference, $plan['board_uuid'], $plan['item_id']) !== $html) {
                    throw new HubException('source_changed', 409);
                }
            }
            // Related records and existing media may have lost access after preview.
            $plannedUrls = array_map(static fn(array $p): string => '/api/uploads/' . $p['filename'], $publications);
            foreach ($plan['values'] as $id => $value) {
                $field = SlotTargetAdapter::field($d, (string)$id);
                $type = $field['type'] ?? '';
                $entries = ($field['localized'] ?? false) ? array_values($value) : [$value];
                foreach ($entries as $entry) {
                    if (in_array($type, ['image','gif','gallery'], true)) {
                        foreach ($type === 'gallery' ? ($entry ?? []) : [$entry] as $url) {
                            if ($url === null || $url === '') {
                                continue;
                            }
                            if (in_array($url, $plannedUrls, true)) {
                                continue;
                            }
                            $this->targets->media->record(str_starts_with($url, '/api/uploads/') ? rawurldecode(basename((string)parse_url($url, PHP_URL_PATH))) : $url);
                        }
                    } elseif (in_array($type, ['relation','relation_many'], true)) {
                        $slot = $field['target'] ?? $field['relation']['slot'] ?? $field['targetSlot'] ?? $field['relationSlot'] ?? '';
                        foreach ($type === 'relation_many' ? ($entry ?? []) : [$entry] as $related) {
                            if ($related !== null && $related !== '') {
                                $this->targets->resolve(new TargetDescriptor('slot', $slot, $related), $plan['board_uuid']);
                            }
                        }
                    }
                }
            }
        } elseif (!$resolved['writable']) {
            throw new HubException('target_not_writable', 403);
        }
        if ($checkSource) {
            if ((int)$item['metadata_revision'] !== $plan['source_revision']) {
                throw new HubException('source_changed', 409);
            }
            if ($plan['source_sequence'] !== null) {
                $p = $this->repo->one('SELECT p.checksum,d.sequence FROM eh_note_projections p JOIN eh_note_documents d ON d.note_id=p.note_id WHERE p.note_id=?', [$item['uuid']]);
                if (!$p || (int)$p['sequence'] !== $plan['source_sequence'] || $p['checksum'] !== $plan['source_checksum']) {
                    throw new HubException('source_changed', 409);
                }
            }
            if ($plan['proposal_id'] !== null) {
                $p = $this->repo->one('SELECT revision FROM eh_proposals WHERE id=?', [$plan['proposal_id']]);
                if (!$p || (int)$p['revision'] !== $plan['proposal_revision']) {
                    throw new HubException('source_changed', 409);
                }
            }
        }
    }

    public function apply(string $planId, string $clientKey, string $checksum): array
    {
        Support::key($clientKey);
        $row = $this->repo->plan($planId);
        $ctx = $this->access->context;
        if (!$row || $row['actor_uuid'] !== $ctx->uuid) {
            throw new HubException('not_found', 404);
        }
        if (!hash_equals($row['checksum'], $checksum)) {
            throw new HubException('plan_checksum_mismatch', 409);
        }
        $plan = json_decode($row['plan'], true, 64, JSON_THROW_ON_ERROR);
        $this->authorize($plan, false);
        $key = hash('sha256', $ctx->uuid . ':' . $clientKey);
        $writer = $this->writer($plan);
        $destination = $writer->database();
        $old = $this->repo->receipt($key);
        if ($old && ($old['plan_id'] !== $planId || !hash_equals($old['checksum'], $checksum))) {
            throw new HubException('idempotency_conflict', 409);
        }
        if ($old && $old['state'] === 'applied') {
            $result = json_decode($old['result'], true, 64, JSON_THROW_ON_ERROR);
            $this->targets->resolve(TargetDescriptor::fromArray($result['destination']), $plan['board_uuid']);
            return $result;
        }
        $existing = $this->destinationReceipt($destination, $key, $plan['proposal_id']);
        if (!$existing) {
            if ((int)$row['expires_at'] <= time()) {
                throw new HubException('plan_expired', 409);
            } $this->authorize($plan, true);
        }
        Support::transaction($this->repo->db, function () use ($key, $planId, $plan, $checksum): void {
            $other = $this->repo->one('SELECT idempotency_key FROM eh_transfer_receipts WHERE plan_id=?', [$planId]);
            if ($other && $other['idempotency_key'] !== $key) {
                throw new HubException('plan_already_used', 409);
            }
            $this->repo->run("INSERT OR IGNORE INTO eh_transfer_receipts VALUES(?,?,?,?,?,'prepared',NULL,?,NULL,?,?)", [$key,$planId,$plan['board_id'],$plan['actor_uuid'],$checksum,$plan['writer'] === 'massive' ? 'massive' : 'content',time(),time()]);
        });
        if (!$existing) {
            $existing = Support::transaction($destination, function () use ($destination, $key, $planId, $plan, $checksum, $writer): array {
                $old = $this->destinationReceipt($destination, $key, $plan['proposal_id']);
                if ($old) {
                    return $old;
                }
                $this->authorize($plan, true);
                if ($plan['writer'] !== 'massive' && !($plan['writer'] === 'media' && $plan['create'])) {
                    foreach ($this->publications($plan) as $p) {
                        $saved = ContentDatabase::saveMediaMeta(
                            $p['filename'],
                            [],
                            mimeType: $p['mime'],
                            dimensions: ['width' => $p['width'], 'height' => $p['height']],
                            uploadedBy: $plan['actor_uuid'],
                        );
                        if (!$saved) {
                            throw new HubException('media_write_failed', 503);
                        }
                    }
                }
                $target = $writer->write($plan);
                $result = ['state' => 'applied','destination' => $target,'item_id' => $plan['item_id'],'plan_id' => $planId];
                $stmt = $destination->prepare('INSERT INTO eh_destination_receipts(idempotency_key,plan_id,proposal_id,actor_uuid,checksum,destination,result,plan,created_at) VALUES(?,?,?,?,?,?,?,?,?)');
                $stmt->execute([$key,$planId,$plan['proposal_id'],$plan['actor_uuid'],$checksum,Support::json($target),Support::json($result),Support::json($plan),time()]);
                return $this->destinationReceipt($destination, $key, null);
            }, 'eh_destination_receipts');
            if ($this->afterDestinationCommit) {
                ($this->afterDestinationCommit)();
            }
        }
        if ($existing['actor_uuid'] !== $ctx->uuid && $existing['proposal_id'] === null) {
            throw new HubException('idempotency_conflict', 409);
        }
        $this->targets->resolve(
            TargetDescriptor::fromArray(json_decode($existing['destination'], true)),
            $plan['board_uuid'],
        );
        return $this->finish($key, $existing, $writer);
    }

    private function destinationReceipt(PDO $db, string $key, ?string $proposal): ?array
    {
        $stmt = $db->prepare('SELECT * FROM eh_destination_receipts WHERE idempotency_key=?' . ($proposal !== null ? ' OR proposal_id=?' : ''));
        $stmt->execute($proposal !== null ? [$key,$proposal] : [$key]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $stmt->closeCursor();
        return $row ?: null;
    }

    private function finish(string $key, array $receipt, DestinationWriterInterface $writer): array
    {
        $plan = json_decode($receipt['plan'], true, 64, JSON_THROW_ON_ERROR);
        $result = json_decode($receipt['result'], true, 64, JSON_THROW_ON_ERROR);
        if (!(int)$receipt['effects_done']) {
            foreach ($this->publications($plan) as $p) {
                $a = $this->repo->one('SELECT * FROM eh_attachments WHERE id=?', [$p['attachment_id']]);
                if (!$a || $a['checksum'] !== $p['checksum']) {
                    throw new HubException('attachment_unavailable', 503);
                }
                $this->storage->publish($a, $p['filename']);
                if ($plan['writer'] === 'massive') {
                    $saved = ContentDatabase::saveMediaMeta(
                        $p['filename'],
                        [],
                        mimeType: $p['mime'],
                        dimensions: ['width' => $p['width'], 'height' => $p['height']],
                        uploadedBy: $plan['actor_uuid'],
                    );
                    if (!$saved) {
                        throw new HubException('media_write_failed', 503);
                    }
                }
            }
            $writer->postCommit($plan);
            $writer->database()->prepare('UPDATE eh_destination_receipts SET effects_done=1 WHERE idempotency_key=?')->execute([$receipt['idempotency_key']]);
        }
        Support::transaction($this->repo->db, function () use ($key, $receipt, $result, $plan): void {
            $old = $this->repo->receipt($key);
            if (!$old || $old['state'] === 'applied') {
                return;
            }
            $this->repo->run("UPDATE eh_transfer_receipts SET state='applied',destination=?,result=?,updated_at=? WHERE idempotency_key=?", [$receipt['destination'],Support::json($result),time(),$key]);
            $item = $this->repo->one('SELECT * FROM eh_items WHERE uuid=?', [$plan['item_id']]);
            if ($item) {
                $previousApply = $plan['proposal_id'] === null ? null : $this->repo->one(
                    "SELECT 1 FROM eh_transfer_plans p JOIN eh_transfer_receipts r ON r.plan_id=p.id WHERE p.proposal_id=? AND r.state='applied' AND r.idempotency_key<>? LIMIT 1",
                    [$plan['proposal_id'], $key],
                );
                if ($plan['proposal_id'] !== null && $previousApply === null) {
                    $this->repo->run(
                        "UPDATE eh_proposals SET revision=revision+1,updated_at=? WHERE id=? AND role='canvas_draft'",
                        [time(), $plan['proposal_id']],
                    );
                }
                $this->repo->run('UPDATE eh_items SET metadata_revision=metadata_revision+1,updated_at=? WHERE uuid=?', [time(), $item['uuid']]);
                $id = Support::uuid();
                $this->repo->run('INSERT INTO eh_references VALUES(?,?,?,?,?,?,?) ON CONFLICT(item_id,occurrence_id) DO UPDATE SET target=excluded.target', [$id,$item['board_id'],$item['uuid'],$plan['actor_uuid'],'transfer:' . $key,$receipt['destination'],time()]);
                $g = ItemRepository::boundsOf($item);
                (new ItemRepository($this->repo->db))->touchTiles((int)$item['board_id'], $g, $g, $item['type'], $item['owner_uuid']);
                (new SyncRepository($this->repo->db))->change((int)$item['board_id'], 'item.transferred', $item['uuid'], (int)$item['metadata_revision'] + 1, ['receipt_id' => $key], $g, $g);
            }
        });
        return $result;
    }

    /** Detect a cross-file restore mismatch without silently recreating CMS data. */
    public function auditAfterRestore(int $after = 0, int $limit = 20): array
    {
        $rows = $this->repo->all("SELECT r.rowid AS audit_id,r.idempotency_key,p.plan FROM eh_transfer_receipts r JOIN eh_transfer_plans p ON p.id=r.plan_id WHERE r.rowid>? AND r.state='applied' ORDER BY r.rowid LIMIT " . max(1, min(20, $limit)), [$after]);
        $conflicts = 0;
        foreach ($rows as $row) {
            $plan = json_decode($row['plan'], true);
            $writer = $this->writer($plan);
            $receipt = $this->destinationReceipt($writer->database(), $row['idempotency_key'], $plan['proposal_id']);
            if (!$receipt) {
                $this->repo->run("UPDATE eh_transfer_receipts SET state='restore_conflict',result=NULL,updated_at=? WHERE idempotency_key=?", [time(),$row['idempotency_key']]);
                $conflicts++;
            } elseif (!(int)$receipt['effects_done']) {
                $this->finish($row['idempotency_key'], $receipt, $writer);
            } else {
                foreach ($this->publications($plan) as $publication) {
                    $a = $this->repo->one('SELECT * FROM eh_attachments WHERE id=?', [$publication['attachment_id']]);
                    if ($a) {
                        $this->storage->publish($a, $publication['filename']);
                    }
                }
            }
            $after = (int)$row['audit_id'];
        }
        return ['cursor' => $after,'conflicts' => $conflicts,'has_more' => count($rows) === max(1, min(20, $limit))];
    }

    /** Maintenance only reconciles already-committed destinations; it never initiates a CMS write. */
    public function reconcile(int $limit = 20): int
    {
        $rows = $this->repo->all("SELECT r.*,p.plan FROM eh_transfer_receipts r JOIN eh_transfer_plans p ON p.id=r.plan_id WHERE r.state='prepared' ORDER BY r.created_at LIMIT " . max(1, min(20, $limit)));
        $done = 0;
        foreach ($rows as $row) {
            $plan = json_decode($row['plan'], true);
            $writer = $this->writer($plan);
            $receipt = $this->destinationReceipt($writer->database(), $row['idempotency_key'], $plan['proposal_id']);
            if ($receipt) {
                $this->finish($row['idempotency_key'], $receipt, $writer);
                $done++;
            } elseif ((int)$row['created_at'] < time() - 3600) {
                $this->repo->run("UPDATE eh_transfer_receipts SET state='abandoned' WHERE idempotency_key=?", [$row['idempotency_key']]);
            }
        }
        return $done;
    }

    /** Old stored receipts used a single publication; retries must remain compatible. */
    private function publications(array $plan): array
    {
        $publications = $plan['media_publications'] ?? [];
        if ($publications === [] && !empty($plan['media_publication'])) {
            $publications = [$plan['media_publication']];
        }
        $unique = [];
        foreach ($publications as $publication) {
            $unique[$publication['attachment_id']] = $publication;
        }
        return array_values($unique);
    }

    /** Publish a private image through the existing preview/receipt saga, without replacing media bytes. */
    private function mediaLibrarySource(array $item): array
    {
        if ($item['type'] !== 'image') {
            throw new HubException('image_target_incompatible');
        }
        if (!$this->access->context->has('media:read:*') && !$this->access->context->has('media:read:own')) {
            throw new HubException('forbidden', 403);
        }
        if ($item['attachment_id']) {
            if (!$this->access->context->has('media:upload:*') && !$this->access->context->has('media:upload:own')) {
                throw new HubException('forbidden', 403);
            }
            $attachment = (new ProposalMediaService($this->repo->db, $this->targets))->attachment($item['attachment_id'], (int) $item['board_id']);
            $publication = ProposalMediaService::publication($attachment);
            return ['filename' => $publication['filename'], 'publication' => $publication];
        }
        $this->targets->media->image($item['media_filename'] ?? '');
        return ['filename' => $item['media_filename'], 'publication' => null];
    }
}
