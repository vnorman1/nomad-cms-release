<?php

/**
 * NOMAD CMS - Editorials Hub HubException.
 *
 * Stable, non-sensitive errors exposed by the Editorials Hub API.
 * Backend-only PHP/SQLite module; resource budgets and authorization are enforced at service boundaries.
 *
 * @package NomadCMS\Services\EditorialsHub
 */

declare(strict_types=1);

namespace NomadCMS\Services\EditorialsHub;

/** Stable, non-sensitive errors exposed by the Editorials Hub API. */
final class HubException extends \RuntimeException
{
    public function __construct(public readonly string $errorCode, public readonly int $status = 422, public readonly array $details = [])
    {
        parent::__construct($errorCode);
    }
}
