<?php

/**
 * NOMAD CMS - Editorials central notification integration.
 * Registers trusted mention rendering and current-access deep-link resolution.
 * Uses lazy read-only domain lookups and a code-level in-app-only channel policy.
 */

declare(strict_types=1);

namespace NomadCMS\Services\EditorialsHub\Notifications;

use NomadCMS\Database\MassiveDatabase;
use NomadCMS\Services\EditorialsHub\Access\HubAccessPolicy;
use NomadCMS\Services\EditorialsHub\Contracts\HubRequestContext;
use NomadCMS\Services\EditorialsHub\Persistence\BoardRepository;
use NomadCMS\Services\EditorialsHub\Persistence\ItemRepository;
use NomadCMS\Services\NotificationService\Events\EventDefinition;
use NomadCMS\Services\NotificationService\NotificationException;
use NomadCMS\Services\NotificationService\NotificationModule;
use NomadCMS\Services\NotificationService\Support;
use PDO;

/** Authorization is recomputed when routing, opening the inbox and following its target. */
final class MentionNotificationIntegration
{
    public const EVENT_TYPE = 'editorials.user.mentioned';
    public const TARGET_KIND = 'editorials.mention';
    public const PRESENTATION_KEY = 'editorialsMention';

    public function __construct(private NotificationModule $central, private ?PDO $hub = null)
    {
    }

    public function register(): void
    {
        $this->central->events->register(new EventDefinition(
            self::EVENT_TYPE,
            'editorials',
            fn(array $event): array => $this->render($event),
            function (array $event, string $user): bool {
                try {
                    $row = $this->location((string) ($event['data']['mention_id'] ?? ''), $user);
                    return $row['recipient_uuid'] === $user;
                } catch (\Throwable) {
                    return false;
                }
            },
            false,
            0,
            false,
            false,
            [],
            ['in_app'],
            self::PRESENTATION_KEY,
            ['actor', 'card', 'board']
        ));
        $this->central->targets->register(self::TARGET_KIND, function (array $target, string $user): string {
            try {
                $row = $this->location($target['id'], $user);
            } catch (\Throwable) {
                throw new NotificationException('target_unavailable', 404);
            }
            $query = ['item' => $row['item_uuid']];
            if ($row['thread_uuid'] !== null) {
                $query['thread'] = $row['thread_uuid'];
            }
            return '/editorials/' . rawurlencode($row['board_uuid']) . '?' . http_build_query($query, '', '&', PHP_QUERY_RFC3986);
        });
    }

    private function database(): PDO
    {
        return $this->hub ??= MassiveDatabase::getInstance(true);
    }

    private function location(string $id, string $user): array
    {
        $db = $this->database();
        if (!MentionNotificationBridge::installed($db)) {
            throw new NotificationException('target_unavailable', 404);
        }
        $row = Support::one($db, "SELECT o.*,i.uuid AS item_uuid,i.title AS card_title,b.uuid AS board_uuid,b.title AS board_title
            FROM eh_outbox o JOIN eh_items i ON i.uuid=json_extract(o.payload,'$.item_id')
            JOIN eh_boards b ON b.id=o.board_id AND b.id=i.board_id
            WHERE o.id=? AND o.kind='user.mentioned' AND i.deleted_at IS NULL AND b.deleted_at IS NULL", [$id]);
        if (!$row || $row['recipient_uuid'] !== $user) {
            throw new NotificationException('target_unavailable', 404);
        }
        $context = new HubRequestContext(
            $user,
            str_repeat('notification-read-context', 2),
            fn(string $permission): bool => $this->central->access->has($user, $permission),
            null,
            $this->central->access->has($user, '*:*:*')
        );
        (new HubAccessPolicy($context, new BoardRepository($db), new ItemRepository($db)))->item($row['item_uuid']);
        $row['thread_uuid'] = null;
        if (preg_match('/^message:([^:]+):/', (string) $row['occurrence_id'], $match)) {
            $thread = Support::one($db, 'SELECT t.uuid FROM eh_messages m JOIN eh_threads t ON t.uuid=m.thread_id
                WHERE m.uuid=? AND m.deleted_at IS NULL AND t.deleted_at IS NULL AND t.item_id=?
                AND (t.expires_at IS NULL OR t.expires_at>?)', [$match[1], $row['item_uuid'], time()]);
            if (!$thread) {
                throw new NotificationException('target_unavailable', 404);
            }
            $row['thread_uuid'] = $thread['uuid'];
        }
        return $row;
    }

    private function render(array $event): array
    {
        $recipient = (string) ($event['audience']['ids'][0] ?? '');
        try {
            $row = $this->location((string) ($event['data']['mention_id'] ?? ''), $recipient);
        } catch (\Throwable) {
            // An unavailable source must never permanently dead-letter the occurrence.
            // canRead/target policies hide it until access can be established again.
            return ['title' => 'Megemlítettek az Editorials Hubban', 'message' => '', 'target' => null];
        }
        $actor = $this->central->access->user($row['actor_uuid']);
        $name = trim(($actor['first_name'] ?? '') . ' ' . ($actor['last_name'] ?? ''));
        $params = [
            'actor' => mb_substr($name, 0, 200),
            'card' => mb_substr((string) $row['card_title'], 0, 200),
            'board' => mb_substr((string) $row['board_title'], 0, 200),
        ];
        return [
            'title' => 'Megemlítettek az Editorials Hubban',
            'message' => mb_substr(($name !== '' ? $name : 'Egy munkatárs') . ' megemlített: ' . $row['card_title'], 0, 2000),
            'target' => ['kind' => self::TARGET_KIND, 'id' => $row['id']],
            'language' => 'hu',
            'presentation' => ['key' => self::PRESENTATION_KEY, 'params' => $params],
        ];
    }
}
