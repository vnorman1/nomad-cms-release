<?php

/**
 * NOMAD CMS - Editorials mention outbox bridge.
 * Moves a bounded batch into the central source-local event protocol atomically.
 * Requires an explicit migration and performs no delivery or network work.
 */

declare(strict_types=1);

namespace NomadCMS\Services\EditorialsHub\Notifications;

use NomadCMS\Services\EditorialsHub\Support;
use NomadCMS\Services\NotificationService\Contracts\DomainEvent;
use NomadCMS\Services\NotificationService\Events\SourcePublisher;
use PDO;

/** Replay-safe adapter between the Hub business outbox and central relay. */
final class MentionNotificationBridge
{
    public function __construct(private PDO $db, private SourcePublisher $publisher, private \Closure $clock)
    {
    }

    public static function installed(PDO $db): bool
    {
        $exists = $db->query("SELECT 1 FROM sqlite_master WHERE type='table' AND name='eh_migrations'")->fetchColumn();
        return $exists && (bool) $db->query('SELECT 1 FROM eh_migrations WHERE version=6')->fetchColumn();
    }

    public function run(int $limit = 50, ?float $deadline = null): int
    {
        if (!self::installed($this->db)) {
            return 0;
        }
        $count = 0;
        while ($count < max(0, min(50, $limit)) && ($deadline === null || microtime(true) < $deadline)) {
            $worked = Support::transaction($this->db, function (): bool {
                $statement = $this->db->query("SELECT * FROM eh_outbox WHERE state='parked' ORDER BY created_at,id LIMIT 1");
                $row = $statement->fetch(PDO::FETCH_ASSOC);
                $statement->closeCursor();
                if (!$row) {
                    return false;
                }
                if ($row['kind'] !== 'user.mentioned' || !$row['recipient_uuid']) {
                    $this->mark($row['id'], 'ignored');
                    return true;
                }
                $payload = json_decode($row['payload'], true, 16, JSON_THROW_ON_ERROR);
                $this->publisher->record($this->db, new DomainEvent([
                    'id' => $row['id'],
                    'source' => 'editorials',
                    'type' => MentionNotificationIntegration::EVENT_TYPE,
                    'occurrence_key' => hash('sha256', $row['occurrence_id'] . ':' . $row['recipient_uuid']),
                    'occurred_at' => gmdate('c', (int) $row['created_at']),
                    'actor' => ['kind' => 'user', 'id' => $row['actor_uuid']],
                    'subject' => ['kind' => 'editorials.item', 'id' => $payload['item_id']],
                    'audience' => ['kind' => 'users', 'ids' => [$row['recipient_uuid']]],
                    'data' => ['mention_id' => $row['id']],
                ]));
                $this->mark($row['id'], 'bridged');
                return true;
            });
            if (!$worked) {
                break;
            }
            $count++;
        }
        return $count;
    }

    private function mark(string $id, string $state): void
    {
        $this->db->prepare('UPDATE eh_outbox SET state=?,delivered_at=? WHERE id=?')->execute([$state, ($this->clock)(), $id]);
    }
}
