<?php

/**
 * NOMAD CMS - Editorials Hub NotificationSinkInterface.
 *
 * Future notification consumer. Deliveries are at least once; implementations deduplicate id.
 * Backend-only PHP/SQLite module; resource budgets and authorization are enforced at service boundaries.
 *
 * @package NomadCMS\Services\EditorialsHub\Notifications
 */

declare(strict_types=1);

namespace NomadCMS\Services\EditorialsHub\Notifications;

/** Future notification consumer. Deliveries are at least once; implementations deduplicate id. */
interface NotificationSinkInterface
{
    public function deliver(array $event): void;
}
