<?php

/**
 * NOMAD CMS - Editorials Hub MentionEventService.
 *
 * Durable mention events bound to saved references, with no UI/email side effects.
 * Backend-only PHP/SQLite module; resource budgets and authorization are enforced at service boundaries.
 *
 * @package NomadCMS\Services\EditorialsHub\Notifications
 */

declare(strict_types=1);

namespace NomadCMS\Services\EditorialsHub\Notifications;

use NomadCMS\Services\EditorialsHub\Access\HubAccessPolicy;
use NomadCMS\Services\EditorialsHub\HubException;
use NomadCMS\Services\EditorialsHub\Persistence\ReferenceRepository;
use NomadCMS\Services\EditorialsHub\Support;

/** Durable mention events bound to saved references, with no UI/email side effects. */
final class MentionEventService
{
    public function __construct(private ReferenceRepository $repo, private HubAccessPolicy $access, private ?\Closure $eligibleUser = null)
    {
    }

    public function record(array $item, array $ids, string $occurrencePrefix): void
    {
        if (count($ids) > 50) {
            throw new HubException('mention_limit');
        }
        foreach (array_unique($ids) as $id) {
            $reference = $this->repo->find((string)$id);
            if (!$reference || $reference['item_id'] !== $item['uuid'] || (int)$reference['board_id'] !== (int)$item['board_id']) {
                throw new HubException('invalid_reference');
            }
            $target = json_decode($reference['target'], true);
            if (($target['kind'] ?? '') !== 'user') {
                continue;
            }
            $recipient = (string)($target['item'] ?? '');
            $actor = $this->access->context->uuid;
            if ($recipient === $actor || $this->eligibleUser === null || !($this->eligibleUser)($recipient)) {
                continue;
            }
            $board = $this->repo->one('SELECT owner_uuid,visibility FROM eh_boards WHERE id=? AND deleted_at IS NULL', [$item['board_id']]);
            if (!$board) {
                continue;
            }
            if ($board['visibility'] === 'private' && $recipient !== $board['owner_uuid'] && !$this->repo->one('SELECT 1 FROM eh_board_members WHERE board_id=? AND user_uuid=?', [$item['board_id'],$recipient])) {
                continue;
            }
            $occurrence = $occurrencePrefix . ':' . $reference['id'];
            $this->repo->run("INSERT OR IGNORE INTO eh_outbox(id,board_id,actor_uuid,recipient_uuid,kind,occurrence_id,payload,created_at) VALUES(?,?,?,?,'user.mentioned',?,?,?)", [Support::uuid(),$item['board_id'],$actor,$recipient,$occurrence,Support::json(['item_id' => $item['uuid'],'reference_id' => $reference['id']]),time()]);
        }
    }
}
