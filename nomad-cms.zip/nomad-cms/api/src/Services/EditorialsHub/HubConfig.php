<?php

/**
 * NOMAD CMS - Editorials Hub HubConfig.
 *
 * Shared, bounded resource budgets for daemon-free PHP hosting.
 * Backend-only PHP/SQLite module; resource budgets and authorization are enforced at service boundaries.
 *
 * @package NomadCMS\Services\EditorialsHub
 */

declare(strict_types=1);

namespace NomadCMS\Services\EditorialsHub;

/** Shared, bounded resource budgets for daemon-free PHP hosting. */
final class HubConfig
{
    public const PAGE_SIZE = 100;
    public const RESPONSE_BYTES = 262144;
    public const UPDATE_BYTES = 262144;
    public const CHECKPOINT_BYTES = 1048576;
    public const TILE_SIZE = 512;
    public const TILE_LEVELS = 24;
    public const CHANGE_DAYS = 7;
    public const SUGGESTIONS = 20;

    public static function storageDirectory(): string
    {
        return $_ENV['EDITORIALS_STATE_DIRECTORY'] ?? dirname(__DIR__, 3) . '/storage/editorials';
    }
}
