<?php

/**
 * NOMAD CMS - Editorials Hub AtomicRateLimiter.
 *
 * Atomic per-actor token buckets. Camera reads permit a 60-request burst and 12/s refill.
 * Backend-only PHP/SQLite module; resource budgets and authorization are enforced at service boundaries.
 *
 * @package NomadCMS\Services\EditorialsHub
 */

declare(strict_types=1);

namespace NomadCMS\Services\EditorialsHub;

/** Atomic per-actor token buckets. Camera reads permit a 60-request burst and 12/s refill. */
final class AtomicRateLimiter
{
    public function __construct(private ?string $directory = null)
    {
    }
    public function consume(string $actor, string $operation, ?float $now = null): void
    {
        [$capacity,$refill] = match ($operation) {
            'viewport', 'read', 'content' => [60, 12],
            'poll' => [12, 3],
            'note_update' => [40, 10],
            'upload' => [10, .2],
            default => [40, 4],
        };
        $dir = $this->directory ?? HubConfig::storageDirectory() . '/limits';
        if (!is_dir($dir) && !mkdir($dir, 0700, true) && !is_dir($dir)) {
            throw new HubException('rate_limit_unavailable', 503);
        }
        $file = fopen($dir . '/' . hash('sha256', $actor . ':' . $operation) . '.bucket', 'c+b');
        if (!$file || !flock($file, LOCK_EX)) {
            throw new HubException('rate_limit_unavailable', 503);
        }
        try {
            $now ??= microtime(true);
            $old = json_decode((string)stream_get_contents($file, 1024), true);
            $tokens = $old ? min($capacity, (float)$old['tokens'] + max(0, $now - (float)$old['time']) * $refill) : (float)$capacity;
            if ($tokens < 1) {
                throw new HubException('rate_limited', 429, ['retry_after' => (int)ceil((1 - $tokens) / $refill)]);
            }
            rewind($file);
            ftruncate($file, 0);
            fwrite($file, Support::json(['tokens' => $tokens - 1,'time' => $now]));
            fflush($file);
        } finally {
            flock($file, LOCK_UN);
            fclose($file);
        }
    }
}
