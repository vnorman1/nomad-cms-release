<?php
/**
 * NOMAD CMS — Bounded reverse relation index audit and repair.
 * Scans collection metadata in resumable row-ID batches, never collection blocks.
 * Repair serializes with writers and changes only derived index rows, not content/history.
 */
declare(strict_types=1);

namespace NomadCMS\Services;

use NomadCMS\Database\CollectionDatabase;
use NomadCMS\Services\Schema\SchemaValues;

final class RelationIndexService
{
    public static function page(string $key, int $after = 0, int $limit = 128, bool $repair = false): array
    {
        if ($after < 0 || $limit < 1 || $limit > 1000 || !CollectionDatabase::isRegistered($key)) {
            throw new \InvalidArgumentException('Invalid relation audit collection or batch.');
        }
        \NomadCMS\Services\Schema\SchemaProvider::lease($key);
        $work = static function (\PDO $db) use ($key, $after, $limit, $repair): array {
            $schema = RelationService::loadSchema();
            $definition = $schema['slots'][$key] ?? [];
            $s = $db->prepare('SELECT row_id,item_uid,data FROM collection_items WHERE slot_key=? AND row_id>? ORDER BY row_id LIMIT ?');
            $s->bindValue(1, $key);
            $s->bindValue(2, $after, \PDO::PARAM_INT);
            $s->bindValue(3, $limit, \PDO::PARAM_INT);
            $s->execute();
            $rows = $s->fetchAll();
            $read = $db->prepare('SELECT field_id,target_key,target_uid,sort_order FROM slot_relations WHERE source_key=? AND source_uid=? ORDER BY field_id,sort_order,target_key,target_uid');
            $insert = $db->prepare('INSERT INTO slot_relations(source_key,source_uid,field_id,target_key,target_uid,sort_order) VALUES(?,?,?,?,?,?)');
            $delete = $db->prepare('DELETE FROM slot_relations WHERE source_key=? AND source_uid=?');
            $mismatches = 0;
            foreach ($rows as $row) {
                $expected = [];
                $item = json_decode($row['data'], true, 512, JSON_THROW_ON_ERROR);
                foreach (RelationService::getRelationFields(SchemaValues::fields($db, $key, $row['item_uid'], $definition)) as $field) {
                    $raw = $item[$field['id']] ?? null;
                    foreach (is_array($raw) ? $raw : [$raw] as $order => $uid) {
                        if (is_string($uid) && $uid !== '') {
                            $expected[] = ['field_id' => $field['id'], 'target_key' => $field['target'], 'target_uid' => $uid, 'sort_order' => (int) $order];
                        }
                    }
                }
                usort($expected, static fn ($a, $b) => [$a['field_id'], $a['sort_order'], $a['target_key'], $a['target_uid']]
                    <=> [$b['field_id'], $b['sort_order'], $b['target_key'], $b['target_uid']]);
                $read->execute([$key, $row['item_uid']]);
                if ($expected !== $read->fetchAll()) {
                    $mismatches++;
                    if ($repair) {
                        $delete->execute([$key, $row['item_uid']]);
                        foreach ($expected as $relation) {
                            $insert->execute([$key, $row['item_uid'], ...array_values($relation)]);
                        }
                    }
                }
            }
            return ['scanned' => count($rows), 'mismatches' => $mismatches,
                'after' => $rows === [] ? $after : (int) $rows[array_key_last($rows)]['row_id'],
                'done' => count($rows) < $limit];
        };
        return $repair ? CollectionDatabase::transaction($work) : $work(CollectionDatabase::getInstance());
    }
}
