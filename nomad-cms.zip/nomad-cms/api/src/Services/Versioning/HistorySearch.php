<?php
/**
 * NOMAD CMS — Version history metadata search.
 * Matches literal terms without stop-word removal, including IDs and email addresses.
 * Normalizes Hungarian accents and includes both languages of generated summaries.
 */
declare(strict_types=1);

namespace NomadCMS\Services\Versioning;

final class HistorySearch
{
    /** Match every query term against visible metadata; SQL wildcards stay literal. */
    public static function matches(string $metadata, string $query): bool
    {
        $metadata = self::normalize($metadata);
        $aliases = [
            'modositva' => 'modified changed',
            'hozzaadva' => 'added',
            'torolve' => 'removed deleted',
            'tovabbi' => 'more',
            'elem' => 'items',
            'nincs valtozas' => 'no changes',
        ];
        foreach ($aliases as $stored => $translated) {
            if (str_contains($metadata, $stored)) {
                $metadata .= ' ' . $translated;
            }
            if (str_contains($metadata, $translated)) {
                $metadata .= ' ' . $stored;
            }
        }
        $terms = preg_split('/\s+/u', self::normalize(trim($query)), -1, PREG_SPLIT_NO_EMPTY);
        foreach ($terms ?: [] as $term) {
            if (!str_contains($metadata, $term)) {
                return false;
            }
        }
        return true;
    }

    private static function normalize(string $value): string
    {
        return strtr(mb_strtolower($value, 'UTF-8'), [
            'á' => 'a', 'é' => 'e', 'í' => 'i', 'ó' => 'o', 'ö' => 'o',
            'ő' => 'o', 'ú' => 'u', 'ü' => 'u', 'ű' => 'u',
        ]);
    }
}
