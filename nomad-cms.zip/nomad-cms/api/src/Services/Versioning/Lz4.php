<?php
/**
 * NOMAD CMS - Pure-PHP LZ4 Block Codec
 *
 * A dependency-free implementation of the LZ4 *block* format (compress + decompress),
 * so the CMS never depends on a server-installed C extension (ext-lz4 / kjdev/lz4).
 *
 * Byte-compatibility contract with the Rust/WASM side (lz4_flex::block):
 * - The LZ4 block format is fully specified; ANY spec-compliant decoder produces
 *   identical output for a given block. Therefore this decoder is byte-exact with
 *   blocks produced by Rust's lz4_flex compressor.
 * - LZ4 permits many valid encodings for the same input, so this compressor does NOT
 *   need to match Rust byte-for-byte — its output only needs to be decodable by any
 *   spec-compliant decoder (including lz4_flex::block::decompress). This is guaranteed
 *   by adhering to the block format below.
 *
 * ## LZ4 Block Format
 * A block is a series of "sequences". Each sequence:
 *   1. token (1 byte): high nibble = literal length (0-15), low nibble = match length - 4 (0-15)
 *   2. if literal length == 15: additional bytes, each 0-255, added until a byte < 255 (LSIC)
 *   3. <literalLength> literal bytes (copied verbatim)
 *   4. offset (2 bytes, little-endian) — distance back into output to copy the match from
 *   5. if (match length nibble) == 15: additional LSIC bytes for the extra match length
 *   The actual match length = 4 (MINMATCH) + low nibble + extra bytes.
 *   The match copies matchLength bytes from (currentPos - offset); overlapping copies
 *   are allowed and must be performed byte-by-byte.
 * The LAST sequence contains literals only (no offset / no match), and by spec the last
 * match cannot start within the final 12 bytes and the last 5 bytes are always literals.
 *
 * @see https://github.com/lz4/lz4/blob/dev/doc/lz4_Block_format.md
 */

declare(strict_types=1);

namespace NomadCMS\Services\Versioning;

final class Lz4
{
    private const MIN_MATCH = 4;
    private const LAST_LITERALS = 5;      // last 5 bytes are always literals
    private const MF_LIMIT = 12;          // no match may start within last 12 bytes
    private const HASH_LOG = 16;          // 64K-entry hash table
    private const HASH_SIZE = 1 << self::HASH_LOG;

    /**
     * Compress a raw byte string into an LZ4 block (no frame header).
     *
     * @param string $input Raw bytes.
     * @return string LZ4 block bytes.
     */
    public static function compressBlock(string $input): string
    {
        $inputLen = strlen($input);
        $output = '';

        // Trivially small input: everything is literals.
        if ($inputLen < self::MF_LIMIT + 1) {
            return self::emitLastLiterals($input, 0, $inputLen);
        }

        // Byte values as ints for fast access.
        $bytes = array_values(unpack('C*', $input)); // 0-indexed C-array of unsigned bytes

        $hashTable = array_fill(0, self::HASH_SIZE, -1);

        $anchor = 0;              // start of the pending literal run
        $ip = 0;                  // current input position
        $matchLimit = $inputLen - self::LAST_LITERALS;
        $mfLimit = $inputLen - self::MF_LIMIT;

        // We can only read a 4-byte sequence up to $inputLen - MIN_MATCH.
        while ($ip < $mfLimit) {
            // Compute hash of the 4 bytes at $ip.
            $seq = $bytes[$ip] | ($bytes[$ip + 1] << 8) | ($bytes[$ip + 2] << 16) | ($bytes[$ip + 3] << 24);
            $h = self::hash4($seq);
            $ref = $hashTable[$h];
            $hashTable[$h] = $ip;

            // A candidate match requires: valid ref, within 64KB window, and 4 bytes equal.
            if (
                $ref < 0
                || ($ip - $ref) > 0xFFFF
                || $bytes[$ref] !== $bytes[$ip]
                || $bytes[$ref + 1] !== $bytes[$ip + 1]
                || $bytes[$ref + 2] !== $bytes[$ip + 2]
                || $bytes[$ref + 3] !== $bytes[$ip + 3]
            ) {
                $ip++;
                continue;
            }

            // Found a match at $ref. Extend it forward.
            $matchStart = $ip;
            $offset = $ip - $ref;
            $mp = $ref + self::MIN_MATCH;
            $cp = $ip + self::MIN_MATCH;
            while ($cp < $matchLimit && $bytes[$cp] === $bytes[$mp]) {
                $cp++;
                $mp++;
            }
            $matchLength = $cp - $matchStart;              // total bytes matched (>= 4)
            $litLength = $matchStart - $anchor;             // pending literals before match
            $extraMatch = $matchLength - self::MIN_MATCH;   // encoded as (nibble + LSIC)

            // Build token.
            $token = (($litLength >= 15 ? 15 : $litLength) << 4) | ($extraMatch >= 15 ? 15 : $extraMatch);
            $output .= chr($token);

            // Literal length LSIC.
            if ($litLength >= 15) {
                $rem = $litLength - 15;
                while ($rem >= 255) {
                    $output .= "\xFF";
                    $rem -= 255;
                }
                $output .= chr($rem);
            }

            // Literals.
            if ($litLength > 0) {
                $output .= substr($input, $anchor, $litLength);
            }

            // Offset (little-endian u16).
            $output .= chr($offset & 0xFF) . chr(($offset >> 8) & 0xFF);

            // Match length LSIC.
            if ($extraMatch >= 15) {
                $rem = $extraMatch - 15;
                while ($rem >= 255) {
                    $output .= "\xFF";
                    $rem -= 255;
                }
                $output .= chr($rem);
            }

            // Advance past the match; reset anchor.
            $ip = $cp;
            $anchor = $ip;
        }

        // Trailing literals (from $anchor to end).
        $output .= self::emitLastLiterals($input, $anchor, $inputLen);

        return $output;
    }

    /**
     * Decompress an LZ4 block.
     *
     * @param string $input LZ4 block bytes (no frame header).
     * @param int $originalSize Expected decompressed size (from the NOMAD frame header).
     * @return string|false Decompressed bytes, or false on malformed input.
     */
    public static function decompressBlock(string $input, int $originalSize)
    {
        $inLen = strlen($input);
        if ($originalSize < 0) {
            return false;
        }
        if ($originalSize === 0) {
            return '';
        }

        $ip = 0;
        // Build output as an array of byte chunks, joined at the end for speed.
        $out = '';
        $outLen = 0;

        while ($ip < $inLen) {
            $token = ord($input[$ip++]);

            // ---- Literals ----
            $litLength = $token >> 4;
            if ($litLength === 15) {
                while (true) {
                    if ($ip >= $inLen) {
                        return false;
                    }
                    $b = ord($input[$ip++]);
                    $litLength += $b;
                    if ($b !== 255) {
                        break;
                    }
                }
            }

            if ($litLength > 0) {
                if ($ip + $litLength > $inLen) {
                    return false;
                }
                $out .= substr($input, $ip, $litLength);
                $outLen += $litLength;
                $ip += $litLength;
            }

            // End of block? The last sequence has only literals, no offset.
            if ($ip >= $inLen) {
                break;
            }

            // ---- Match ----
            if ($ip + 2 > $inLen) {
                return false;
            }
            $offset = ord($input[$ip]) | (ord($input[$ip + 1]) << 8);
            $ip += 2;
            if ($offset === 0 || $offset > $outLen) {
                // Invalid offset (would read before start of output).
                return false;
            }

            $matchLength = $token & 0x0F;
            if ($matchLength === 15) {
                while (true) {
                    if ($ip >= $inLen) {
                        return false;
                    }
                    $b = ord($input[$ip++]);
                    $matchLength += $b;
                    if ($b !== 255) {
                        break;
                    }
                }
            }
            $matchLength += self::MIN_MATCH;

            // Copy match from the already-decoded output. Overlapping copies must be
            // performed byte-by-byte (LZ4 relies on this for run-length expansion).
            $srcPos = $outLen - $offset;
            if ($offset >= $matchLength) {
                // Non-overlapping: bulk copy is safe.
                $out .= substr($out, $srcPos, $matchLength);
            } else {
                // Overlapping: copy byte-by-byte so newly written bytes feed the copy.
                for ($i = 0; $i < $matchLength; $i++) {
                    $out .= $out[$srcPos + $i];
                }
            }
            $outLen += $matchLength;
        }

        // Validate we produced exactly the expected size.
        if ($outLen !== $originalSize) {
            return false;
        }

        return $out;
    }

    /**
     * Emit the final literal run (last sequence): token + LSIC + literal bytes, no match.
     */
    private static function emitLastLiterals(string $input, int $anchor, int $inputLen): string
    {
        $litLength = $inputLen - $anchor;
        $out = '';
        $token = ($litLength >= 15 ? 15 : $litLength) << 4;
        $out .= chr($token);
        if ($litLength >= 15) {
            $rem = $litLength - 15;
            while ($rem >= 255) {
                $out .= "\xFF";
                $rem -= 255;
            }
            $out .= chr($rem);
        }
        if ($litLength > 0) {
            $out .= substr($input, $anchor, $litLength);
        }
        return $out;
    }

    /**
     * LZ4-style 4-byte hash into the hash table index space.
     * Exact hash function is irrelevant for correctness/interop (it only affects
     * compression ratio), so any good hash works. Implemented with 16-bit split
     * multiplication to stay strictly within PHP integer range (no float overflow).
     */
    private static function hash4(int $seq): int
    {
        $seq &= 0xFFFFFFFF;
        // Multiply by 2654435761 (Knuth) using 16-bit halves to avoid > 2^63 overflow.
        $lo = $seq & 0xFFFF;
        $hi = ($seq >> 16) & 0xFFFF;
        $constLo = 2654435761 & 0xFFFF;      // 0x9E37
        $constHi = (2654435761 >> 16) & 0xFFFF; // 0x9E37 -> high part 0x9E37...
        // product mod 2^32 = (lo*constLo + ((lo*constHi + hi*constLo) << 16)) mod 2^32
        $cross = (($lo * $constHi) + ($hi * $constLo)) & 0xFFFF;
        $h = (($lo * $constLo) + ($cross << 16)) & 0xFFFFFFFF;
        return $h >> (32 - self::HASH_LOG);
    }
}
