<?php
/**
 * NOMAD CMS - Diff Engine
 * 
 * JSON Patch RFC 6902 implementation for computing and applying diffs.
 * Extracted from VersioningService for modularity.
 */

declare(strict_types=1);

namespace NomadCMS\Services\Versioning;

use Exception;
use RuntimeException;

class DiffEngine
{
    /**
     * Compute diff between two JSON values
     * 
     * @param string $oldJson Source JSON
     * @param string $newJson Target JSON
     * @return array{success: bool, diff_forward: array, content_hash: string, change_summary: string, error?: string}
     */
    public function computeDiff(string $oldJson, string $newJson): array
    {
        try {
            $old = json_decode($oldJson, false, 512, JSON_THROW_ON_ERROR);
            $new = json_decode($newJson, false, 512, JSON_THROW_ON_ERROR);
            
            if (json_last_error() !== JSON_ERROR_NONE) {
                return ['success' => false, 'error' => 'Invalid JSON'];
            }
            
            // Compute forward diff only (old → new)
            $diffForward = $this->jsonDiff($old, $new, '');
            
            // Calculate SHA-256 hash of new content
            $contentHash = hash('sha256', $newJson);
            
            // Generate change summary
            $changeSummary = $this->generateChangeSummary($diffForward);
            
            return [
                'success' => true,
                'diff_forward' => $diffForward,
                'diff_backward' => [], // Computed on-demand when needed
                'content_hash' => $contentHash,
                'change_summary' => $changeSummary
            ];
            
        } catch (Exception $e) {
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }
    
    /**
     * Apply JSON patch (RFC 6902)
     */
    public function applyPatch(string $baseJson, array $patch): array
    {
        try {
            $data = json_decode($baseJson, false, 512, JSON_THROW_ON_ERROR);

            foreach ($patch as $operation) {
                $op = $operation['op'] ?? '';
                $path = $operation['path'] ?? '';
                $value = json_decode(json_encode($operation['value'] ?? null, JSON_THROW_ON_ERROR), false);
                
                switch ($op) {
                    case 'add':
                        $this->patchAdd($data, $path, $value);
                        break;
                    case 'remove':
                        $this->patchRemove($data, $path);
                        break;
                    case 'replace':
                        $this->patchReplace($data, $path, $value);
                        break;
                    case 'move':
                        $this->patchMove($data, $operation['from'] ?? '', $path);
                        break;
                    case 'copy':
                        $this->patchCopy($data, $operation['from'] ?? '', $path);
                        break;
                    case 'test':
                        if (!$this->patchTest($data, $path, $value)) {
                            return ['success' => false, 'error' => 'Test operation failed'];
                        }
                        break;
                    default:
                        throw new RuntimeException('Unsupported patch operation: ' . $op);
                }
            }
            
            return [
                'success' => true,
                'data' => json_decode(json_encode($data, JSON_THROW_ON_ERROR), true),
                'hash' => hash('sha256', json_encode($data, JSON_UNESCAPED_UNICODE))
            ];
            
        } catch (Exception $e) {
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }
    
    /**
     * Compute backward diff on-demand by inverting forward diff operations
     */
    public function computeBackwardDiff(string $forwardDiffJson): string
    {
        try {
            $forwardOps = json_decode($forwardDiffJson, true);
            if (!is_array($forwardOps)) {
                return '[]';
            }
            
            $backwardOps = [];
            
            foreach (array_reverse($forwardOps) as $op) {
                $path = $op['path'] ?? '';
                
                switch ($op['op'] ?? '') {
                    case 'add':
                        $backwardOps[] = ['op' => 'remove', 'path' => $path, 'value' => $op['value'] ?? null];
                        break;
                    case 'remove':
                        $backwardOps[] = ['op' => 'add', 'path' => $path, 'value' => $op['value'] ?? null];
                        break;
                    case 'replace':
                        $backwardOps[] = ['op' => 'replace', 'path' => $path, 'value' => array_key_exists('old_value', $op) ? $op['old_value'] : '[előző érték]'];
                        break;
                    case 'move':
                        $backwardOps[] = ['op' => 'move', 'from' => $path, 'path' => $op['from'] ?? ''];
                        break;
                    case 'copy':
                        $backwardOps[] = ['op' => 'remove', 'path' => $path];
                        break;
                }
            }
            
            return json_encode($backwardOps, JSON_UNESCAPED_UNICODE);
            
        } catch (Exception $e) {
            return '[]';
        }
    }
    
    /**
     * Generate human-readable change summary from a JSON Patch diff.
     *
     * FIELD-NAME-AWARE: groups operations by their TOP-LEVEL field name
     * (the first JSON pointer segment) instead of just counting op types,
     * so a user sees "title, leadText módosítva" instead of the previous
     * op-count-only "~2 modified". Falls back to the op-count format if a
     * pointer can't be parsed into a field name (e.g. root-level replace).
     *
     * Format: "<fields> módosítva; <field>: +N elem; <field> törölve"
     * - modified/added-inside-existing-field fields are grouped as "módosítva"
     * - a field that is wholesale added (op=add at top level) is "hozzáadva"
     * - a field that is wholesale removed (op=remove at top level) is "törölve"
     * - array-heavy fields (>= 2 ops within the same list) collapse to a
     *   "+N elem"/"-N elem" delta instead of listing every index
     *
     * Length-limited to keep the stored change_summary compact; overflow
     * fields are collapsed into "+N további".
     */
    public function generateChangeSummary(array $diff): string
    {
        if (empty($diff)) {
            return 'Nincs változás';
        }

        // Group ops by top-level field name (first JSON pointer segment).
        // Root-level replace (path === '/' or '') has no field name - bucket
        // it separately and fall back to op-count phrasing for it.
        $fieldOps = []; // fieldName => ['add' => n, 'remove' => n, 'replace' => n, 'move' => n, 'copy' => n]
        $rootLevelOps = 0;

        foreach ($diff as $op) {
            $path = $op['path'] ?? '';
            $opType = $op['op'] ?? '';

            $field = $this->extractTopLevelField($path);

            if ($field === null) {
                $rootLevelOps++;
                continue;
            }

            if (!isset($fieldOps[$field])) {
                $fieldOps[$field] = ['add' => 0, 'remove' => 0, 'replace' => 0, 'move' => 0, 'copy' => 0, 'total' => 0];
            }
            if (isset($fieldOps[$field][$opType])) {
                $fieldOps[$field][$opType]++;
            }
            $fieldOps[$field]['total']++;
        }

        if (empty($fieldOps) && $rootLevelOps > 0) {
            // Nothing parseable into field names - fall back to op-count format
            return $this->generateOpCountSummary($diff);
        }

        // Classify each field's dominant change type
        $modified = [];
        $added = [];
        $removed = [];
        $listDeltas = []; // "fieldName: +N elem" style entries

        foreach ($fieldOps as $field => $counts) {
            $isPureAdd = $counts['add'] > 0 && $counts['remove'] === 0 && $counts['replace'] === 0;
            $isPureRemove = $counts['remove'] > 0 && $counts['add'] === 0 && $counts['replace'] === 0;

            if ($counts['total'] >= 2 && ($counts['add'] > 0 || $counts['remove'] > 0)) {
                // Array-like field with multiple element-level ops: collapse to a delta
                $delta = $counts['add'] - $counts['remove'];
                if ($delta > 0) {
                    $listDeltas[] = "{$field}: +{$delta} elem";
                } elseif ($delta < 0) {
                    $listDeltas[] = "{$field}: " . $delta . " elem";
                } else {
                    $modified[] = $field;
                }
            } elseif ($isPureAdd && $counts['add'] === 1) {
                $added[] = $field;
            } elseif ($isPureRemove && $counts['remove'] === 1) {
                $removed[] = $field;
            } else {
                $modified[] = $field;
            }
        }

        $parts = [];

        // Length-limited: cap the number of field names actually listed per
        // bucket, collapsing the rest into a "+N további" suffix.
        $maxFieldsPerBucket = 4;

        if (!empty($modified)) {
            $parts[] = $this->joinFieldNames($modified, $maxFieldsPerBucket) . ' módosítva';
        }
        if (!empty($added)) {
            $parts[] = $this->joinFieldNames($added, $maxFieldsPerBucket) . ' hozzáadva';
        }
        if (!empty($removed)) {
            $parts[] = $this->joinFieldNames($removed, $maxFieldsPerBucket) . ' törölve';
        }
        foreach ($listDeltas as $delta) {
            $parts[] = $delta;
        }
        if ($rootLevelOps > 0 && empty($parts)) {
            $parts[] = $this->generateOpCountSummary($diff);
        }

        $summary = implode('; ', $parts);

        // Hard length limit on the final string (defensive, in case of many
        // long field names) - truncate and mark as such.
        $maxLength = 200;
        if (mb_strlen($summary) > $maxLength) {
            $summary = mb_substr($summary, 0, $maxLength - 1) . '…';
        }

        return $summary !== '' ? $summary : 'Nincs változás';
    }

    /**
     * Extract the top-level field name from a JSON pointer path.
     * "/title" -> "title", "/gallery/2/url" -> "gallery", "/" or "" -> null
     */
    private function extractTopLevelField(string $path): ?string
    {
        $trimmed = ltrim($path, '/');
        if ($trimmed === '') {
            return null;
        }
        $segments = explode('/', $trimmed);
        return $this->unescapeJsonPointer($segments[0]);
    }

    /**
     * Join field names with comma, capping the count and appending a
     * "+N további" marker if the list was truncated.
     */
    private function joinFieldNames(array $fields, int $max): string
    {
        $unique = array_values(array_unique($fields));
        if (count($unique) <= $max) {
            return implode(', ', $unique);
        }
        $shown = array_slice($unique, 0, $max);
        $remaining = count($unique) - $max;
        return implode(', ', $shown) . " (+{$remaining} további)";
    }

    /**
     * Legacy op-count-only summary format, used as a fallback when no
     * field name can be extracted from any operation's path (e.g. a
     * whole-content root replace).
     */
    private function generateOpCountSummary(array $diff): string
    {
        $counts = ['add' => 0, 'remove' => 0, 'replace' => 0, 'move' => 0, 'copy' => 0];
        
        foreach ($diff as $op) {
            $opType = $op['op'] ?? '';
            if (isset($counts[$opType])) {
                $counts[$opType]++;
            }
        }
        
        $parts = [];
        if ($counts['add'] > 0) $parts[] = "+{$counts['add']} added";
        if ($counts['remove'] > 0) $parts[] = "-{$counts['remove']} removed";
        if ($counts['replace'] > 0) $parts[] = "~{$counts['replace']} modified";
        if ($counts['move'] > 0) $parts[] = "↔{$counts['move']} moved";
        if ($counts['copy'] > 0) $parts[] = "⊕{$counts['copy']} copied";
        
        return empty($parts) ? 'No changes' : implode(', ', $parts);
    }
    
    // =========================================================================
    // PRIVATE HELPERS
    // =========================================================================
    
    /**
     * Compute JSON diff (RFC 6902 format)
     */
    private function jsonDiff(mixed $from, mixed $to, string $path): array
    {
        if (gettype($from) !== gettype($to)) return [['op'=>'replace','path'=>$path,'value'=>$to,'old_value'=>$from]];
        if (is_object($from) && is_object($to)) {
            $diff=[];
            foreach (get_object_vars($to) as $key=>$value) {
                $next=$path.'/'.$this->escapeJsonPointer((string)$key);
                if (!property_exists($from,(string)$key)) $diff[]=['op'=>'add','path'=>$next,'value'=>$value];
                else $diff=array_merge($diff,$this->jsonDiff($from->$key,$value,$next));
            }
            foreach (get_object_vars($from) as $key=>$value) if (!property_exists($to,(string)$key)) $diff[]=['op'=>'remove','path'=>$path.'/'.$this->escapeJsonPointer((string)$key),'value'=>$value];
            return $diff;
        }
        if (is_array($from) && is_array($to)) {
            $diff=[]; $working=$from;
            // Apply each identity move before calculating subsequent pointer indexes.
            $uids=function(array $items): ?array {
                $out=[]; $seen=[];
                foreach ($items as $item) {
                    $uid=is_object($item)?($item->_dndId??null):null;
                    if (!is_string($uid)||$uid===''||isset($seen['uid:'.$uid])) return null;
                    $seen['uid:'.$uid]=true; $out[]=$uid;
                }
                return $out;
            };
            $oldIds=$uids($from); $newIds=$uids($to);
            if ($oldIds!==null && $newIds!==null) {
                for ($i=count($working)-1;$i>=0;$i--) if (!in_array($oldIds[$i],$newIds,true)) {
                    $diff[]=['op'=>'remove','path'=>$path.'/'.$i,'value'=>$working[$i]];
                    array_splice($working,$i,1); array_splice($oldIds,$i,1);
                }
                foreach ($to as $i=>$value) {
                    $found=array_search($newIds[$i],$oldIds,true);
                    if ($found===false) {
                        $diff[]=['op'=>'add','path'=>$path.'/'.$i,'value'=>$value];
                        array_splice($working,$i,0,[$value]); array_splice($oldIds,$i,0,[$newIds[$i]]);
                    } else {
                        if ($found!==$i) {
                            $diff[]=['op'=>'move','from'=>$path.'/'.$found,'path'=>$path.'/'.$i];
                            $moved=$working[$found]; array_splice($working,$found,1); array_splice($working,$i,0,[$moved]);
                            array_splice($oldIds,$found,1); array_splice($oldIds,$i,0,[$newIds[$i]]);
                        }
                        $diff=array_merge($diff,$this->jsonDiff($working[$i],$value,$path.'/'.$i));
                        $working[$i]=$value;
                    }
                }
            } else {
                $common=min(count($from),count($to));
                for ($i=0;$i<$common;$i++) $diff=array_merge($diff,$this->jsonDiff($from[$i],$to[$i],$path.'/'.$i));
                for ($i=count($from)-1;$i>=count($to);$i--) $diff[]=['op'=>'remove','path'=>$path.'/'.$i,'value'=>$from[$i]];
                for ($i=$common;$i<count($to);$i++) $diff[]=['op'=>'add','path'=>$path.'/'.$i,'value'=>$to[$i]];
            }
            return $diff;
        }
        return $from!==$to ? [['op'=>'replace','path'=>$path,'value'=>$to,'old_value'=>$from]] : [];
    }

    private function getPointerParts(string $path): array
    {
        if ($path==='') return [];
        if (!str_starts_with($path,'/')) throw new RuntimeException('Invalid JSON pointer');
        return array_map(fn($p)=>$this->unescapeJsonPointer($p),explode('/',substr($path,1)));
    }

    private function escapeJsonPointer(string $str): string
    {
        return str_replace(['~', '/'], ['~0', '~1'], $str);
    }
    
    private function unescapeJsonPointer(string $str): string
    {
        return str_replace(['~1', '~0'], ['/', '~'], $str);
    }
    
    private function &getRef(mixed &$data, array $parts): mixed
    {
        $ref=&$data;
        foreach ($parts as $part) {
            if (is_object($ref) && property_exists($ref,$part)) $ref=&$ref->$part;
            elseif (is_array($ref) && preg_match('/^(0|[1-9][0-9]*)$/',$part) && array_key_exists((int)$part,$ref)) $ref=&$ref[(int)$part];
            else throw new RuntimeException('Path not found: '.$part);
        }
        return $ref;
    }

    private function patchAdd(mixed &$data, string $path, mixed $value): void
    {
        $parts=$this->getPointerParts($path);
        if (!$parts) { $data=$value; return; }
        $last=array_pop($parts); $ref=&$this->getRef($data,$parts);
        if (is_object($ref)) { $ref->$last=$value; return; }
        if (!is_array($ref)) throw new RuntimeException('Cannot add to scalar');
        if ($last==='-') $index=count($ref);
        elseif (preg_match('/^(0|[1-9][0-9]*)$/',$last)) $index=(int)$last;
        else throw new RuntimeException('Invalid array index');
        if ($index>count($ref)) throw new RuntimeException('Array index out of range');
        array_splice($ref,$index,0,[$value]);
    }

    private function patchRemove(mixed &$data, string $path): void
    {
        $parts=$this->getPointerParts($path);
        if (!$parts) { $data=null; return; }
        $last=array_pop($parts); $ref=&$this->getRef($data,$parts);
        if (is_object($ref) && property_exists($ref,$last)) { unset($ref->$last); return; }
        if (is_array($ref) && preg_match('/^(0|[1-9][0-9]*)$/',$last) && array_key_exists((int)$last,$ref)) { array_splice($ref,(int)$last,1); return; }
        throw new RuntimeException('Remove path not found');
    }

    private function patchReplace(mixed &$data, string $path, mixed $value): void
    {
        // Old Nomad history used '/' for root replacement. Preserve that legacy case.
        if ($path==='/' && !(is_object($data)&&property_exists($data,''))) { $data=$value; return; }
        $ref=&$this->getRef($data,$this->getPointerParts($path)); $ref=$value;
    }

    private function patchMove(mixed &$data, string $from, string $to): void
    {
        if ($from!==$to && str_starts_with($to,$from.'/')) throw new RuntimeException('Cannot move into a descendant');
        $value=$this->getRef($data,$this->getPointerParts($from));
        $this->patchRemove($data,$from); $this->patchAdd($data,$to,$value);
    }

    private function patchCopy(mixed &$data, string $from, string $to): void
    {
        $value=$this->getRef($data,$this->getPointerParts($from));
        $this->patchAdd($data,$to,json_decode(json_encode($value,JSON_THROW_ON_ERROR),false));
    }

    private function patchTest(mixed $data, string $path, mixed $value): bool
    {
        return json_encode($this->getRef($data,$this->getPointerParts($path)))===json_encode($value);
    }

    private function isAssociativeArray(array $arr): bool
    {
        return !empty($arr) && array_keys($arr) !== range(0, count($arr) - 1);
    }
    
    private function indexArrayById(array $arr): ?array
    {
        if (empty($arr)) return [];
        $first = $arr[0];
        if (!is_array($first)) return null;
        
        $idField = null;
        foreach (['_dndId', 'id', '_id'] as $field) {
            if (isset($first[$field]) && $first[$field] !== '') {
                $idField = $field;
                break;
            }
        }
        if ($idField === null) return null;
        
        $indexed = [];
        foreach ($arr as $index => $item) {
            if (!is_array($item) || !isset($item[$idField]) || $item[$idField] === '') return null;
            $id = (string) $item[$idField];
            if (isset($indexed[$id])) return null;
            $indexed[$id] = ['_index' => $index, 'item' => $item];
        }
        return $indexed;
    }
}
