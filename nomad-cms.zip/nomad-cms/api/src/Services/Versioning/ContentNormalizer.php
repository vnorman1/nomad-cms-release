<?php

/**
 * NOMAD CMS - Content Normalizer
 *
 * Canonicalizes content for SEMANTIC comparison and version-chain storage.
 *
 * PROBLEM: Raw JSON-identity comparison (sorted-key string equality) treats
 * `null`, `""`, missing key, `[]` and `{}` as four/five DIFFERENT values, so
 * clicking into an empty field and tabbing back out - or a schema change
 * that adds a new field defaulting to `''` - creates a "real" version even
 * though nothing the user would recognize as content actually changed.
 *
 * SOLUTION: This class defines an "emptiness" equivalence class and folds
 * all its members to a single canonical representation (empty keys are
 * dropped from objects) BEFORE diffing/hashing. The raw `slots.data` blob
 * is never touched by this - only the versioning subsystem's view of the
 * content is canonicalized, so the version chain is internally consistent
 * (every stored diff/snapshot/hash is computed from canonical content).
 *
 * @see VersionCreator::normalizeJson() - key-sorting only, still used for the
 *      raw byte-identity fast path. This class handles SEMANTIC identity.
 */

declare(strict_types=1);

namespace NomadCMS\Services\Versioning;

class ContentNormalizer
{
    /**
     * HTML tags that carry meaning even with no text content.
     * A string like "<img src=x>" or "<hr>" must NOT be treated as empty,
     * even though strip_tags() on it yields an empty string.
     */
    private const NON_EMPTY_HTML_TAGS = [
        'img', 'hr', 'iframe', 'video', 'audio', 'embed', 'source',
        'svg', 'canvas', 'table', 'input',
    ];

    /**
     * Check whether a scalar/array value is semantically "empty".
     *
     * Empty means: null, empty string, whitespace-only string, an
     * empty/whitespace-only HTML fragment (e.g. "<p></p>", "<p><br></p>",
     * "&nbsp;"), an empty array, or an empty associative array (object).
     *
     * NOT empty: 0, 0.0, false, "0" (meaningful falsy scalars), and any
     * string containing a tag from NON_EMPTY_HTML_TAGS regardless of
     * visible text (e.g. a caption-less image block).
     */
    public static function isEmptyValue(mixed $value): bool
    {
        if ($value === null) {
            return true;
        }

        if (is_string($value)) {
            return self::isEmptyString($value);
        }

        if (is_array($value)) {
            return empty($value);
        }

        // Meaningful scalars: 0, 0.0, false, "0" via is_string above, ints, etc.
        return false;
    }

    /**
     * String-specific emptiness check with HTML-awareness.
     */
    private static function isEmptyString(string $value): bool
    {
        if ($value === '') {
            return true;
        }

        // Fast path: pure whitespace (covers \t \n \r and regular spaces)
        if (trim($value) === '') {
            return true;
        }

        // Only worth doing the HTML analysis if the string actually looks
        // like markup - avoids strip_tags() overhead on typical plain text.
        if (!str_contains($value, '<') && !str_contains($value, '&')) {
            return false;
        }

        // If it contains a tag that carries meaning without text, it's not empty
        foreach (self::NON_EMPTY_HTML_TAGS as $tag) {
            // Word-boundary-ish check: <img, </img (n/a for void), <img/, <img>
            if (preg_match('/<' . $tag . '(\s|>|\/)/i', $value) === 1) {
                return false;
            }
        }

        // Strip tags, decode entities (handles &nbsp; -> \u{A0}), then trim
        // (including the non-breaking space, which trim() alone won't strip)
        $stripped = strip_tags($value);
        $decoded = html_entity_decode($stripped, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        $decoded = str_replace("\xC2\xA0", ' ', $decoded); // U+00A0 NBSP -> regular space
        $decoded = preg_replace('/[\x{200B}\x{FEFF}]/u', '', $decoded) ?? $decoded; // zero-width chars

        return trim($decoded) === '';
    }

    /**
     * Recursively canonicalize content for semantic comparison.
     *
     * Rules:
     * - Associative arrays (objects): keys whose value is semantically
     *   empty are DROPPED entirely (null ≡ "" ≡ missing key), remaining
     *   keys are canonicalized recursively, then sorted (ksort) for
     *   deterministic serialization.
     * - Sequential arrays (lists): NEVER drop elements or renumber -
     *   list identity/order/length must remain visible in the canonical
     *   form (dropping a "" element would silently shift every later
     *   index). Each element is canonicalized recursively; an empty
     *   element becomes `null` as its canonical placeholder.
     * - Scalars: returned as-is (0, false, "0" are preserved verbatim).
     *
     * Idempotent: canonicalize(canonicalize(x)) === canonicalize(x).
     */
    public static function canonicalize(mixed $content): mixed
    {
        if (is_array($content)) {
            $isList = array_keys($content) === range(0, count($content) - 1);

            if ($isList) {
                $result = [];
                foreach ($content as $item) {
                    $result[] = self::isEmptyValue($item) ? null : self::canonicalize($item);
                }
                return $result;
            }

            // Associative array (object): drop empty-valued keys
            $result = [];
            foreach ($content as $key => $value) {
                if (self::isEmptyValue($value)) {
                    continue;
                }
                $result[$key] = self::canonicalize($value);
            }
            ksort($result);
            return $result;
        }

        return $content;
    }

    /**
     * Canonicalize and JSON-encode content (sorted keys, unicode-safe).
     *
     * @return string|false JSON string, or false on encoding failure
     */
    public static function canonicalJson(mixed $content): string|false
    {
        $canonical = self::canonicalize($content);
        return json_encode($canonical, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    }

    /**
     * SHA-256 hash of the canonical JSON representation.
     * Returns null if the content cannot be encoded.
     */
    public static function canonicalHash(mixed $content): ?string
    {
        $json = self::canonicalJson($content);
        if ($json === false) {
            return null;
        }
        return hash('sha256', $json);
    }
}
