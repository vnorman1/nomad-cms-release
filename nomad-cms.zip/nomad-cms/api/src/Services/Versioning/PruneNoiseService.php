<?php

/**
 * NOMAD CMS - Prune Noise Service
 *
 * Cleans up ALREADY-ACCUMULATED noise versions from BEFORE the semantic-skip
 * feature existed (Task 2/3) - old commit rows whose canonical content is
 * identical to the version immediately before them (e.g. a null->"" edit
 * that got its own permanent commit under the old versioning behavior).
 *
 * This does NOT touch versions going forward (VersionCreator already skips
 * those at creation time) - it is a one-time (or occasional) retroactive
 * cleanup for content saved before this feature was deployed.
 *
 * SAFETY MODEL:
 * - dry_run is the ONLY mode that runs by default at the endpoint layer.
 * - A version is NEVER pruned if it is: the slot's current/latest version,
 *   a 'named' version (explicitly protected by the user), or if pruning it
 *   would leave the slot with zero versions.
 * - Pruning REWRITES the chain (recomputes forward diffs between the
 *   surviving versions) rather than leaving dangling diffs - each slot's
 *   rewrite runs in its own transaction, so a failure on one slot cannot
 *   corrupt another slot's history, and a failure mid-slot rolls back that
 *   slot's rewrite entirely (never leaves it half-migrated).
 * - snapshot_data / is_snapshot flags are recomputed on the survivors so
 *   the SNAPSHOT_INTERVAL invariant (every Nth version is a full snapshot)
 *   still holds after renumbering... except renumbering does NOT happen -
 *   version_number values on survivors are left as-is (gaps are fine, the
 *   chain reconstruction logic already tolerates gaps via getVersionsBetween
 *   returning only existing rows) to avoid rewriting foreign keys/history
 *   text like "Restored from v12" that reference specific numbers.
 */

declare(strict_types=1);

namespace NomadCMS\Services\Versioning;

use NomadCMS\Services\LoggerService;
use PDO;

class PruneNoiseService
{
    private PDO $db;
    private CompressionService $compression;
    private DiffEngine $diffEngine;
    private VersionRepository $repository;
    private SnapshotManager $snapshotManager;

    /** Full snapshot every N surviving versions (mirrors VersionCreator::SNAPSHOT_INTERVAL) */
    private const SNAPSHOT_INTERVAL = 10;

    public function __construct(
        PDO $db,
        CompressionService $compression,
        DiffEngine $diffEngine,
        VersionRepository $repository,
        SnapshotManager $snapshotManager
    ) {
        $this->db = $db;
        $this->compression = $compression;
        $this->diffEngine = $diffEngine;
        $this->repository = $repository;
        $this->snapshotManager = $snapshotManager;
    }

    /**
     * Analyze (dry_run=true) or execute (dry_run=false) noise pruning.
     *
     * @param array<int,string>|null $slotKeys Limit to specific slots, or all slots with versions if null
     * @return array{
     *   success: bool,
     *   dry_run: bool,
     *   slots_analyzed: int,
     *   slots_affected: int,
     *   versions_prunable: int,
     *   bytes_prunable: int,
     *   per_slot: array<int, array{slot_key: string, prunable_count: int, prunable_bytes: int, kept_count: int}>
     * }
     */
    public function run(bool $dryRun = true, ?array $slotKeys = null): array
    {
        $slots = $slotKeys ?? $this->repository->getDistinctSlotKeys();

        $perSlot = [];
        $totalPrunable = 0;
        $totalBytes = 0;
        $slotsAffected = 0;

        foreach ($slots as $slotKey) {
            $analysis = $this->analyzeSlot($slotKey);

            if ($analysis['prunable_count'] > 0) {
                $slotsAffected++;
                $totalPrunable += $analysis['prunable_count'];
                $totalBytes += $analysis['prunable_bytes'];

                if (!$dryRun) {
                    $this->pruneSlot($slotKey, $analysis['prunable_ids']);
                }
            }

            $perSlot[] = [
                'slot_key' => $slotKey,
                'prunable_count' => $analysis['prunable_count'],
                'prunable_bytes' => $analysis['prunable_bytes'],
                'kept_count' => $analysis['kept_count'],
            ];
        }

        if (!$dryRun && $slotsAffected > 0) {
            $this->repository->vacuum();
            LoggerService::info('PruneNoiseService: Noise pruning executed', [
                'slots_affected' => $slotsAffected,
                'versions_pruned' => $totalPrunable,
                'bytes_freed' => $totalBytes,
            ]);
        }

        return [
            'success' => true,
            'dry_run' => $dryRun,
            'slots_analyzed' => count($slots),
            'slots_affected' => $slotsAffected,
            'versions_prunable' => $totalPrunable,
            'bytes_prunable' => $totalBytes,
            'per_slot' => array_values(array_filter($perSlot, fn($s) => $s['prunable_count'] > 0)),
        ];
    }

    /**
     * Determine which versions of a slot are safe to prune, WITHOUT
     * modifying anything. Walks the chain in version order, reconstructing
     * canonical content for each version and comparing it to the canonical
     * content of the last KEPT version (not the last version, since a
     * chain of consecutive noise versions must all compare against the
     * same real baseline).
     *
     * @return array{prunable_count: int, prunable_bytes: int, kept_count: int, prunable_ids: array<int,int>}
     */
    private function analyzeSlot(string $slotKey): array
    {
        $stmt = $this->db->prepare("
            SELECT id, version_number, version_type, diff_size,
                   LENGTH(COALESCE(snapshot_data, '')) as snapshot_bytes
            FROM slot_versions
            WHERE slot_key = ?
            ORDER BY version_number ASC
        ");
        $stmt->execute([$slotKey]);
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

        if (count($rows) <= 1) {
            // Nothing to compare against, or already empty - never prune
            // a slot down to zero versions.
            return ['prunable_count' => 0, 'prunable_bytes' => 0, 'kept_count' => count($rows), 'prunable_ids' => []];
        }

        $maxVersionNumber = (int) $rows[array_key_last($rows)]['version_number'];

        $prunableIds = [];
        $prunableBytes = 0;
        $keptCount = 0;
        $lastKeptCanonicalHash = null;

        foreach ($rows as $row) {
            $versionNumber = (int) $row['version_number'];
            $isLatest = $versionNumber === $maxVersionNumber;
            $isNamed = $row['version_type'] === VersionRepository::TYPE_NAMED;

            $reconstructed = $this->snapshotManager->reconstructVersion($slotKey, $versionNumber);
            if (!$reconstructed['success']) {
                // Can't safely analyze this version (corrupt/missing chain
                // data) - treat as kept, never guess-prune something we
                // can't verify.
                LoggerService::warning('PruneNoiseService: Could not reconstruct version during analysis, keeping it', [
                    'slot_key' => $slotKey,
                    'version_number' => $versionNumber,
                ]);
                $keptCount++;
                $lastKeptCanonicalHash = null; // force next comparison to keep too (safe default)
                continue;
            }

            $canonicalHash = ContentNormalizer::canonicalHash($reconstructed['content']);

            $isDuplicateOfPrevKept = $lastKeptCanonicalHash !== null
                && $canonicalHash !== null
                && hash_equals($lastKeptCanonicalHash, $canonicalHash);

            $isPrunable = $isDuplicateOfPrevKept && !$isLatest && !$isNamed;

            if ($isPrunable) {
                $prunableIds[] = (int) $row['id'];
                $prunableBytes += (int) $row['diff_size'] + (int) $row['snapshot_bytes'];
            } else {
                $keptCount++;
                $lastKeptCanonicalHash = $canonicalHash;
            }
        }

        return [
            'prunable_count' => count($prunableIds),
            'prunable_bytes' => $prunableBytes,
            'kept_count' => $keptCount,
            'prunable_ids' => $prunableIds,
        ];
    }

    /**
     * Rewrite a slot's version chain, removing the given prunable version
     * IDs and recomputing forward diffs for the surviving versions so every
     * remaining diff is relative to its new (possibly different) predecessor.
     *
     * Runs entirely inside one transaction per slot: either the whole
     * rewrite succeeds, or the slot is left completely untouched.
     */
    private function pruneSlot(string $slotKey, array $prunableIds): void
    {
        if (empty($prunableIds)) {
            return;
        }

        $this->db->beginTransaction();

        try {
            // Reconstruct canonical content for every SURVIVING version
            // BEFORE deleting anything, so reconstruction always sees the
            // complete original chain.
            $stmt = $this->db->prepare("
                SELECT id, version_number, version_type, version_name, changed_by, changed_at
                FROM slot_versions
                WHERE slot_key = ?
                ORDER BY version_number ASC
            ");
            $stmt->execute([$slotKey]);
            $allRows = $stmt->fetchAll(PDO::FETCH_ASSOC);

            $prunableIdSet = array_fill_keys($prunableIds, true);
            $survivors = [];

            foreach ($allRows as $row) {
                if (isset($prunableIdSet[(int) $row['id']])) {
                    continue;
                }

                $reconstructed = $this->snapshotManager->reconstructVersion($slotKey, (int) $row['version_number']);
                if (!$reconstructed['success']) {
                    throw new \RuntimeException(
                        "Failed to reconstruct surviving version {$row['version_number']} for slot {$slotKey} during prune - aborting to avoid data loss"
                    );
                }

                $survivors[] = [
                    'id' => (int) $row['id'],
                    'version_number' => (int) $row['version_number'],
                    'version_type' => $row['version_type'],
                    'version_name' => $row['version_name'],
                    'changed_by' => $row['changed_by'],
                    'changed_at' => $row['changed_at'],
                    'canonical_content' => $reconstructed['content'],
                ];
            }

            // Delete the prunable rows
            $placeholders = implode(',', array_fill(0, count($prunableIds), '?'));
            $deleteStmt = $this->db->prepare("DELETE FROM slot_versions WHERE id IN ($placeholders)");
            $deleteStmt->execute($prunableIds);

            // Recompute forward diff + snapshot_hash + content_size + HMAC
            // for each survivor, relative to the PREVIOUS survivor (or null
            // baseline for the first one).
            $previousCanonicalJson = 'null';

            foreach ($survivors as $index => $survivor) {
                $canonicalJson = ContentNormalizer::canonicalJson($survivor['canonical_content']);
                if ($canonicalJson === false) {
                    throw new \RuntimeException(
                        "Failed to canonicalize surviving version {$survivor['version_number']} for slot {$slotKey} during prune"
                    );
                }

                $diffResult = $this->diffEngine->computeDiff($previousCanonicalJson, $canonicalJson);
                if (!$diffResult['success']) {
                    throw new \RuntimeException(
                        "Failed to recompute diff for surviving version {$survivor['version_number']} for slot {$slotKey} during prune: "
                        . ($diffResult['error'] ?? 'unknown')
                    );
                }

                $diffForwardJson = json_encode($diffResult['diff_forward']);
                $compressedForward = $this->compression->compress($diffForwardJson);
                $emptyBackward = $this->compression->compress('[]');

                // Every SNAPSHOT_INTERVAL-th surviving version (1-indexed) or
                // the first survivor gets a full snapshot, mirroring
                // VersionCreator's own snapshot cadence.
                $survivorPosition = $index + 1;
                $isSnapshot = ($survivorPosition === 1 || $survivorPosition % self::SNAPSHOT_INTERVAL === 0);
                $compressedSnapshot = null;
                if ($isSnapshot) {
                    $snapshotResult = $this->compression->compress($canonicalJson);
                    $compressedSnapshot = $snapshotResult['data'];
                }

                $contentHash = hash('sha256', $canonicalJson);
                $dataToSign = $slotKey . $survivor['version_number'] . $contentHash;
                $hmacSignature = hash_hmac('sha256', $dataToSign, VersionRepository::getHmacSecret());

                $updateStmt = $this->db->prepare("
                    UPDATE slot_versions
                    SET diff_forward = ?,
                        diff_backward = ?,
                        diff_size = ?,
                        is_compressed = ?,
                        is_snapshot = ?,
                        snapshot_data = ?,
                        snapshot_hash = ?,
                        content_size = ?,
                        hmac_signature = ?
                    WHERE id = ?
                ");
                $updateStmt->execute([
                    $compressedForward['data'],
                    $emptyBackward['data'],
                    strlen($diffForwardJson),
                    $compressedForward['is_compressed'] ? 1 : 0,
                    $isSnapshot ? 1 : 0,
                    $compressedSnapshot,
                    $contentHash,
                    strlen($canonicalJson),
                    $hmacSignature,
                    $survivor['id'],
                ]);

                $previousCanonicalJson = $canonicalJson;
            }

            $this->db->commit();

            LoggerService::info('PruneNoiseService: Slot chain rewritten', [
                'slot_key' => $slotKey,
                'pruned_count' => count($prunableIds),
                'surviving_count' => count($survivors),
            ]);
        } catch (\Throwable $e) {
            $this->db->rollBack();
            LoggerService::error('PruneNoiseService: Prune failed, slot left untouched', [
                'slot_key' => $slotKey,
                'error' => $e->getMessage(),
            ]);
            throw $e;
        }
    }
}
