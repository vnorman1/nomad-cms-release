<?php

/**
 * NOMAD CMS - Transactional collection webhook outbox.
 *
 * Captures only the already-hydrated affected item inside its write transaction.
 * Relays bounded batches into the existing webhook queue without network I/O.
 * Cross-database receipts prevent duplicate fan-out after a process interruption;
 * source rows are acknowledged only after the destination transaction commits.
 */

declare(strict_types=1);

namespace NomadCMS\Services;

use NomadCMS\Database\CollectionDatabase;
use NomadCMS\Database\AuthDatabase;
use NomadCMS\Security\WebhookService;
use PDO;

final class CollectionWebhookOutbox
{
    /** Capture a content mutation; callers own the source transaction. */
    public static function record(
        PDO $db,
        string $key,
        string $operation,
        ?array $old,
        array $item,
        array $definition,
        int $version,
        ?string $actor,
        bool $explicitCreation = false
    ): void {
        $events = [];
        $draft = ($item['status'] ?? null) === 'draft' || ($item['isDraft'] ?? false) === true;
        if (!$draft || $operation === 'delete' || ($explicitCreation && $operation === 'create')) {
            $events[] = 'content.' . match ($operation) {
                'create' => 'created',
                'delete' => 'deleted',
                default => 'updated',
            };
        }
        if ($operation !== 'delete') {
            $wasPublished = $old !== null && PublicPayloadService::isItemPublished($definition, $old);
            $isPublished = PublicPayloadService::isItemPublished($definition, $item);
            if ($wasPublished !== $isPublished) {
                $events[] = $isPublished ? 'content.published' : 'content.unpublished';
            }
        }
        if ($events === []) {
            return;
        }
        $payload = $item;
        $payload['id'] = $item['id'] ?? $item['slug'] ?? $item['_dndId'];
        $payload['slot'] = $key;
        $payload['slot_type'] = 'collection';
        $payload['version'] = $version;
        $payload['timestamp'] = gmdate('c');
        $payload['content'] = $item;
        if ($actor !== null && $actor !== '') {
            $payload['author_id'] = $actor;
        }
        $json = json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR);
        // Keep the existing queue's size contract without failing content writes.
        if (strlen($json) > WebhookService::MAX_PAYLOAD_SIZE) {
            error_log('[CollectionWebhookOutbox] Payload exceeds webhook size limit for ' . $key);
            return;
        }
        WebhookQueuePolicy::insert($db, 'collection_webhook_outbox', [
            'event_id' => bin2hex(random_bytes(16)),
            'slot_key' => $key,
            'events' => json_encode($events, JSON_THROW_ON_ERROR),
            'payload' => $json,
            'priority' => max(array_map(WebhookQueuePolicy::priority(...), $events)),
            'item_key' => WebhookQueuePolicy::itemKey($key, $payload),
            'created_at' => time(),
        ], $events === ['content.updated']);
    }

    /** Relay at most 50 mutations, one payload at a time, within a short time budget. */
    public static function relay(int $limit = 50, ?float $deadline = null): int
    {
        $deadline = min($deadline ?? INF, microtime(true) + 1.0);
        if ($limit <= 0 || microtime(true) >= $deadline) {
            return 0;
        }
        $source = CollectionDatabase::getInstance();
        // Never expose uncommitted source mutations through another database.
        if ($source->inTransaction() || !$source->query("SELECT 1 FROM sqlite_master WHERE type='table' AND name='collection_webhook_outbox'")->fetchColumn()) {
            return 0;
        }
        WebhookQueuePolicy::maintain($source, 'collection_webhook_outbox');
        if (!$source->query('SELECT 1 FROM collection_webhook_outbox LIMIT 1')->fetchColumn()) {
            return 0;
        }
        $service = new WebhookService();
        $destination = AuthDatabase::getInstance();
        if ($destination->inTransaction()) {
            return 0;
        }
        $count = 0;
        while ($count < min(50, max(0, $limit)) && microtime(true) < $deadline) {
            $source->beginTransaction();
            try {
                // An outbox acknowledgement is not a content mutation: avoid running
                // collection SEO/cache after-commit hooks for every relayed event.
                $source->exec('UPDATE collection_webhook_outbox SET id=id WHERE 0');
                // The source write lock serializes relayers, including acknowledgement.
                $statement = $source->prepare("SELECT o.* FROM collection_webhook_outbox o
                    WHERE o.created_at>=? AND (o.item_key IS NULL OR NOT EXISTS (
                        SELECT 1 FROM collection_webhook_outbox earlier
                        WHERE earlier.item_key=o.item_key AND earlier.id<o.id AND earlier.created_at>=?
                    )) ORDER BY o.priority DESC,o.id LIMIT 1");
                $statement->execute([WebhookQueuePolicy::cutoff(), WebhookQueuePolicy::cutoff()]);
                $row = $statement->fetch(PDO::FETCH_ASSOC);
                $statement->closeCursor();
                if (!$row) {
                    $source->commit();
                    break;
                }
                $service->dispatchRecordedCollectionEvents(
                    $row['event_id'],
                    json_decode($row['events'], true, 512, JSON_THROW_ON_ERROR),
                    json_decode($row['payload'], true, 512, JSON_THROW_ON_ERROR),
                    $row['slot_key']
                );
                $source->prepare('DELETE FROM collection_webhook_outbox WHERE id=?')->execute([$row['id']]);
                $id = $row['event_id'];
                $source->commit();
            } catch (\Throwable $e) {
                if ($source->inTransaction()) {
                    $source->rollBack();
                }
                throw $e;
            }
            // Source acknowledgement is now durable; the receipt is no longer needed.
            $destination->prepare('DELETE FROM collection_webhook_receipts WHERE event_id=?')->execute([$id]);
            $count++;
        }
        // Recover orphan receipts left by a crash after source acknowledgement.
        $receipts = $destination->query('SELECT event_id FROM collection_webhook_receipts ORDER BY rowid LIMIT 50')->fetchAll(PDO::FETCH_COLUMN);
        $exists = $source->prepare('SELECT 1 FROM collection_webhook_outbox WHERE event_id=?');
        $delete = $destination->prepare('DELETE FROM collection_webhook_receipts WHERE event_id=?');
        foreach ($receipts as $id) {
            $exists->execute([$id]);
            if (!$exists->fetchColumn()) {
                $delete->execute([$id]);
            }
            $exists->closeCursor();
        }
        return $count;
    }
}
