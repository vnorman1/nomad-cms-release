<?php
/**
 * NOMAD CMS — Forge request admission and lossless JSON decoding.
 * Bounds encrypted payloads before allocation and scans depth/node density
 * before PHP expands JSON. Limits fit the configured memory budget, capped at
 * 64 MiB; this protocol intentionally does not stream sealed-box decryption.
 */
declare(strict_types=1);

namespace NomadCMS\Services;

final class ForgeImportLimits
{
    /** @return array<string, int> Limits persisted with the upload session. */
    public static function current(): array
    {
        $raw = trim((string) ini_get('memory_limit'));
        $memory = (int) $raw;
        $unit = strtolower(substr($raw, -1));
        if ($unit === 'g') {
            $memory *= 1024 * 1024 * 1024;
        } elseif ($unit === 'm') {
            $memory *= 1024 * 1024;
        } elseif ($unit === 'k') {
            $memory *= 1024;
        }
        $budget = min($memory > 0 ? $memory : 64 * 1024 * 1024, 64 * 1024 * 1024);
        $available = max(0, $budget - memory_get_usage(true) - 8 * 1024 * 1024);
        return [
            'maxPayloadBytes' => min(4 * 1024 * 1024, intdiv($available, 8)),
            'maxNodes' => min(50000, intdiv($available, 1024)),
            'maxDepth' => 64,
            'maxSourceBytes' => 25 * 1024 * 1024,
        ];
    }

    public static function encryptedCeiling(array $limits): int
    {
        return (int) (4 * ceil(($limits['maxPayloadBytes'] + SODIUM_CRYPTO_BOX_SEALBYTES) / 3));
    }

    /** Scan without allocating a PHP array for untrusted, potentially dense JSON. */
    public static function assertJson(string $json, array $limits): void
    {
        if (strlen($json) > $limits['maxPayloadBytes']) {
            throw new \LengthException('FORGE_PAYLOAD_LIMIT', 413);
        }
        $nodes = 0;
        $depth = 0;
        $quoted = false;
        $escaped = false;
        $primitive = false;
        $length = strlen($json);
        for ($index = 0; $index < $length; $index++) {
            $char = $json[$index];
            if ($quoted) {
                if ($escaped) {
                    $escaped = false;
                } elseif ($char === '\\') {
                    $escaped = true;
                } elseif ($char === '"') {
                    $quoted = false;
                }
                continue;
            }
            if ($char === '"') {
                $quoted = true;
                $primitive = false;
                $nodes++;
            } elseif ($char === '{' || $char === '[') {
                $depth++;
                $nodes++;
                $primitive = false;
            } elseif ($char === '}' || $char === ']') {
                $depth--;
                $primitive = false;
            } elseif ($char === ',' || $char === ':' || ctype_space($char)) {
                $primitive = false;
            } elseif (!$primitive) {
                $nodes++;
                $primitive = true;
            }
            if ($depth > $limits['maxDepth'] || $nodes > $limits['maxNodes']) {
                throw new \LengthException('FORGE_STRUCTURE_LIMIT', 413);
            }
        }
    }
}
