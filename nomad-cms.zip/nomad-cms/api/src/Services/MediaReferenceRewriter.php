<?php
/**
 * NOMAD CMS — exact local media reference rewriting.
 * Compiles filename/path matching once per conversion, preserves URL suffixes and
 * immutable item identities, and never rewrites uploads belonging to another origin.
 */
declare(strict_types=1);

namespace NomadCMS\Services;

/** Value-only rewriting shared by indexed candidates and legacy JSON fallbacks. */
final class MediaReferenceRewriter
{
    private string $pattern;
    private string $pathPattern;
    private string $barePattern;
    private array $origin;
    private array $needles;

    public function __construct(
        public readonly string $from,
        public readonly string $to,
        string $apiBase = ''
    ) {
        $this->origin = parse_url($apiBase) ?: [];
        $prefixes = ['/api/uploads/', '/uploads/'];
        if (!empty($this->origin['path'])) {
            $prefixes[] = rtrim($this->origin['path'], '/') . '/uploads/';
        }
        $encoded = rawurlencode($from);
        $lowerEncoded = preg_replace_callback('/%[0-9A-F]{2}/', static fn(array $m): string => strtolower($m[0]), $encoded);
        $names = array_unique([$from, $encoded, $lowerEncoded]);
        $paths = implode('|', array_map(static fn(string $prefix): string => preg_quote($prefix, '~'), array_unique($prefixes)));
        $encodedPattern = preg_replace('/%([0-9A-F]{2})/', '(?i:%$1)', preg_quote($encoded, '~'));
        $filenames = preg_quote($from, '~') . '|' . $encodedPattern;
        // Consume the authority as part of the match, so a foreign URL cannot be
        // retried as a relative /api/uploads/ substring after origin validation.
        $this->pathPattern = '~^(?:' . $paths . ')(?:' . $filenames . ')$~u';
        $this->barePattern = '~^(?:' . $filenames . ')(?=$|[?#])~u';
        $this->pattern = '~(?<![\p{L}\p{N}_./%:+-])(?:'
            . '(?:[a-zA-Z][a-zA-Z0-9+.-]*:)?//[^\s\'"<>()\[\]{}]+'
            . '|(?:' . $paths . ')(?:' . $filenames . ')(?=$|[?&#\s\'"<>(),;\]{}])'
            . '(?:[?#][^\s\'"<>()\[\]{}]*)?)~u';
        $this->needles = array_values(array_unique([
            ...$names,
            substr(json_encode($from, JSON_THROW_ON_ERROR), 1, -1),
        ]));
    }

    /** Raw, URL-encoded and JSON-escaped spellings for cheap SQL candidate filtering. */
    public function needles(): array
    {
        return $this->needles;
    }

    public function rewrite(mixed $value): mixed
    {
        if (is_array($value)) {
            foreach ($value as $key => $entry) {
                if ($key !== '_dndId') {
                    $value[$key] = $this->rewrite($entry);
                }
            }
            return $value;
        }
        if (!is_string($value)) {
            return $value;
        }
        if ($value === $this->from) {
            return $this->to;
        }
        // Bare filenames may also carry Media Library cache-busting suffixes.
        if (preg_match($this->barePattern, $value, $bare)) {
            return rawurlencode($this->to) . substr($value, strlen($bare[0]));
        }
        return preg_replace_callback($this->pattern, function (array $match): string {
            $url = rtrim($match[0], ',;');
            if (!preg_match('~^(?:[a-zA-Z][a-zA-Z0-9+.-]*:)?//~', $url)) {
                $length = strcspn($url, '?#');
                $path = substr($url, 0, $length);
                return substr($path, 0, strrpos($path, '/') + 1) . rawurlencode($this->to)
                    . substr($match[0], $length);
            }
            // parse_url() may classify individual UTF-8 bytes as controls under
            // non-UTF-8 locales. Parse an encoded copy while preserving the original prefix.
            $encodedUrl = preg_replace_callback('/[\x80-\xFF]/', static fn(array $m): string => rawurlencode($m[0]), $url);
            $reference = parse_url($encodedUrl);
            if ($reference === false || !isset($reference['host']) || isset($reference['user']) || isset($reference['pass'])) {
                return $match[0];
            }
            if (isset($reference['host'])) {
                $scheme = strtolower($reference['scheme'] ?? $this->origin['scheme'] ?? '');
                $baseScheme = strtolower($this->origin['scheme'] ?? '');
                $port = $reference['port'] ?? ($scheme === 'https' ? 443 : 80);
                $basePort = $this->origin['port'] ?? ($baseScheme === 'https' ? 443 : 80);
                if (!in_array($scheme, ['http', 'https'], true) || $scheme !== $baseScheme || $port !== $basePort
                    || strcasecmp($reference['host'], $this->origin['host'] ?? '') !== 0) {
                    return $match[0];
                }
            }
            $path = $reference['path'] ?? '';
            if (!preg_match($this->pathPattern, $path)) {
                return $match[0];
            }
            $start = strpos($url, '/', strpos($url, '//') + 2);
            $length = strcspn($url, '?#', $start);
            $rawPath = substr($url, $start, $length);
            return substr($url, 0, $start) . substr($rawPath, 0, strrpos($rawPath, '/') + 1) . rawurlencode($this->to)
                . substr($match[0], $start + $length);
        }, $value);
    }
}
