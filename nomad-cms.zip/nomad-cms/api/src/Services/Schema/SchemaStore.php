<?php
/**
 * NOMAD CMS — Durable schema registry.
 * Stores signed full revisions, drafts, migration journals and audit events.
 * Content stays in its native database; this store never rewrites source JSON.
 */

declare(strict_types=1);

namespace NomadCMS\Services\Schema;

use PDO;
use NomadCMS\Services\Versioning\CompressionService;

final class SchemaStore
{
    public readonly PDO $db;
    private string $secret;

    public function __construct(?PDO $db = null, ?string $secret = null)
    {
        $this->db = $db ?? new PDO('sqlite:' . self::path(), null, null, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC]);
        $this->db->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
        $this->db->exec('PRAGMA busy_timeout=3000');
        $this->db->exec('PRAGMA synchronous=FULL');
        $this->secret = $secret ?? ($_ENV['SCHEMA_SIGNING_KEY'] ?? $_ENV['PASSWORD_PEPPER'] ?? '');
        if ($this->secret === '') {
            throw new \RuntimeException('Persistent schema signing key is not configured.');
        }
        if (\NomadCMS\Security\PanicModeService::isReadOnlyRequest()) {
            $this->db->exec('PRAGMA query_only=ON');
            return;
        }
        $this->db->exec('CREATE TABLE IF NOT EXISTS schema_revisions (
            revision INTEGER PRIMARY KEY, parent_revision INTEGER, parent_hash TEXT NOT NULL,
            version TEXT NOT NULL, schema_hash TEXT NOT NULL, payload BLOB NOT NULL,
            compressed INTEGER NOT NULL, diff_json TEXT NOT NULL, signature TEXT NOT NULL,
            author TEXT NOT NULL, reason TEXT NOT NULL, created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS schema_head (id INTEGER PRIMARY KEY CHECK(id=1), revision INTEGER NOT NULL);
        CREATE TABLE IF NOT EXISTS schema_drafts (
            id TEXT PRIMARY KEY, base_revision INTEGER NOT NULL, schema_json TEXT NOT NULL,
            author TEXT NOT NULL, reason TEXT NOT NULL, status TEXT NOT NULL, report_json TEXT,
            approval_json TEXT, journal_json TEXT, updated_at TEXT NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_schema_drafts_status ON schema_drafts(status,updated_at);
        CREATE INDEX IF NOT EXISTS idx_schema_drafts_pending ON schema_drafts(updated_at DESC) WHERE status <> \'active\';
        CREATE TABLE IF NOT EXISTS schema_gates (slot_key TEXT PRIMARY KEY, draft_id TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS schema_archives (
            slot_key TEXT NOT NULL, field_id TEXT NOT NULL, definition_json TEXT NOT NULL,
            archived_revision INTEGER NOT NULL, PRIMARY KEY(slot_key,field_id)
        );
        CREATE TABLE IF NOT EXISTS schema_legacy_fields (
            slot_key TEXT NOT NULL, field_id TEXT NOT NULL, definition_json TEXT NOT NULL,
            PRIMARY KEY(slot_key,field_id)
        );
        CREATE TABLE IF NOT EXISTS schema_audit (
            id INTEGER PRIMARY KEY, actor TEXT NOT NULL, action TEXT NOT NULL, details_json TEXT NOT NULL, created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS schema_scan_jobs (
            slot_key TEXT PRIMARY KEY, revision INTEGER NOT NULL, cursor INTEGER NOT NULL DEFAULT 0,
            inspected INTEGER NOT NULL DEFAULT 0, issues INTEGER NOT NULL DEFAULT 0, status TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS schema_index_jobs (
            id TEXT PRIMARY KEY, slot_key TEXT NOT NULL, field_id TEXT NOT NULL, revision INTEGER NOT NULL,
            cursor INTEGER NOT NULL DEFAULT 0, status TEXT NOT NULL, approved_by TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS schema_index_values (
            job_id TEXT NOT NULL, item_id TEXT NOT NULL, text_value TEXT, number_value REAL,
            PRIMARY KEY(job_id,item_id)
        );
        CREATE INDEX IF NOT EXISTS idx_schema_scalar_text ON schema_index_values(job_id,text_value,item_id);
        CREATE INDEX IF NOT EXISTS idx_schema_scalar_number ON schema_index_values(job_id,number_value,item_id);');
        $this->db->exec('CREATE INDEX IF NOT EXISTS idx_schema_index_slot_status ON schema_index_jobs(slot_key,status);
            CREATE INDEX IF NOT EXISTS idx_schema_index_pending ON schema_index_jobs(status,id);
            CREATE INDEX IF NOT EXISTS idx_schema_scan_pending ON schema_scan_jobs(status,slot_key);');
    }

    public static function path(): string
    {
        return $_ENV['NOMAD_SCHEMA_DB'] ?? dirname(__DIR__, 3) . '/databases/schema.sqlite';
    }

    public function active(): ?array
    {
        $id = $this->db->query('SELECT revision FROM schema_head WHERE id=1')->fetchColumn();
        return $id === false ? null : $this->revision((int) $id);
    }

    /**
     * Read an authenticated revision or its lightweight history metadata.
     * Metadata authenticates the signed schema hash without loading its payload;
     * opening a full revision additionally verifies the actual payload hash.
     */
    public function revision(int $id, bool $includeSchema = true): array
    {
        $columns = $includeSchema ? '*' : 'revision,parent_revision,parent_hash,version,schema_hash,diff_json,signature,author,reason,created_at';
        $query = $this->db->prepare('SELECT ' . $columns . ' FROM schema_revisions WHERE revision=?');
        $query->execute([$id]);
        $row = $query->fetch();
        if (!$row) {
            throw new \OutOfBoundsException('Schema revision not found.', 404);
        }
        $json = $includeSchema ? (new CompressionService())->decompress($row['payload'], (bool) $row['compressed']) : null;
        if (($json !== null && !hash_equals($row['schema_hash'], hash('sha256', $json)))
            || !hash_equals($row['signature'], $this->signature($row))) {
            throw new \RuntimeException('Schema revision signature verification failed.');
        }
        if ($row['parent_revision'] !== null) {
            $query->execute([(int) $row['parent_revision']]);
            $parent = $query->fetch();
            if (!$parent || !hash_equals($row['parent_hash'], $parent['schema_hash']) || !hash_equals($parent['signature'], $this->signature($parent))) {
                throw new \RuntimeException('Schema parent integrity verification failed.');
            }
        }
        unset($row['payload'], $row['signature'], $row['compressed']);
        $row['revision'] = (int) $row['revision'];
        $row['parent_revision'] = $row['parent_revision'] === null ? null : (int) $row['parent_revision'];
        if ($json !== null) {
            $row['schema'] = json_decode($json, true, 512, JSON_THROW_ON_ERROR);
        }
        $row['changes'] = json_decode($row['diff_json'], true, 512, JSON_THROW_ON_ERROR);
        return $row;
    }

    /**
     * Load a bounded history page, optionally excluding full schema snapshots.
     * Revision cursors keep older history accessible without growing request memory.
     */
    public function history(bool $includeSchema = true, int $before = 0, int $limit = 50): array
    {
        $query = $this->db->prepare('SELECT revision FROM schema_revisions'
            . ($before > 0 ? ' WHERE revision < :before' : '')
            . ' ORDER BY revision DESC LIMIT :limit');
        if ($before > 0) {
            $query->bindValue(':before', $before, PDO::PARAM_INT);
        }
        $query->bindValue(':limit', max(1, min(100, $limit)), PDO::PARAM_INT);
        $query->execute();
        return array_map(fn ($id) => $this->revision((int) $id, $includeSchema), $query->fetchAll(PDO::FETCH_COLUMN));
    }

    public function append(array $schema, string $actor, string $reason, array $diff): array
    {
        $parent = $this->active();
        $id = ($parent['revision'] ?? 0) + 1;
        $schema['version'] = $parent ? SchemaDefinition::nextVersion($parent['version'], $diff['impact']) : '1.0.0';
        $schema['lastModified'] = gmdate('c');
        $json = SchemaDefinition::json($schema);
        $compressed = (new CompressionService())->compress($json);
        $row = [
            'revision' => $id, 'parent_revision' => $parent['revision'] ?? null,
            'parent_hash' => $parent['schema_hash'] ?? '', 'version' => $schema['version'],
            'schema_hash' => hash('sha256', $json), 'payload' => $compressed['data'],
            'compressed' => (int) $compressed['is_compressed'], 'diff_json' => SchemaDefinition::json($diff),
            'author' => $actor, 'reason' => $reason, 'created_at' => gmdate('c'),
        ];
        $row['signature'] = $this->signature($row);
        $query = $this->db->prepare('INSERT INTO schema_revisions (' . implode(',', array_keys($row)) . ') VALUES (' . implode(',', array_fill(0, count($row), '?')) . ')');
        $query->execute(array_values($row));
        $this->db->prepare('INSERT INTO schema_head VALUES(1,?) ON CONFLICT(id) DO UPDATE SET revision=excluded.revision')->execute([$id]);
        return $this->revision($id);
    }

    private function signature(array $row): string
    {
        $values = array_map(static fn (string $key): string => (string) ($row[$key] ?? ''), ['revision', 'parent_revision', 'parent_hash', 'version', 'schema_hash', 'diff_json', 'author', 'reason', 'created_at']);
        return hash_hmac('sha256', json_encode($values, JSON_THROW_ON_ERROR), $this->secret);
    }

    public function audit(string $actor, string $action, array $details): void
    {
        $this->db->prepare('INSERT INTO schema_audit(actor,action,details_json,created_at) VALUES(?,?,?,?)')->execute([$actor, $action, SchemaDefinition::json($details), gmdate('c')]);
    }

    public function transaction(callable $operation): mixed
    {
        $this->db->exec('BEGIN IMMEDIATE');
        try {
            $value = $operation();
            $this->db->exec('COMMIT');
            return $value;
        } catch (\Throwable $error) {
            $this->db->exec('ROLLBACK');
            throw $error;
        }
    }
}
