<?php
/**
 * NOMAD CMS — Value interpretation provenance.
 * Retains relation targets and localized/block layouts for unchanged legacy values.
 * Definitions are deduplicated; provenance commits beside native content writes.
 */

declare(strict_types=1);

namespace NomadCMS\Services\Schema;

use PDO;

final class SchemaValues
{
    private static array $ready = [];

    public static function defaultLanguage(): string
    {
        $i18n = SchemaProvider::schema()['i18n'] ?? [];
        $languages = is_array($i18n['languages'] ?? null) ? $i18n['languages'] : [];
        foreach ([$i18n['defaultLanguage'] ?? null, ...$languages, 'hu'] as $language) {
            if (is_string($language) && trim($language) !== '') {
                return trim($language);
            }
        }
        return 'hu';
    }

    /** Project editor values without rewriting raw rows or creating content revisions. */
    public static function editorItem(PDO $db, string $key, array $item, ?array $slot = null, ?string $uid = null): array
    {
        foreach (SchemaDefinition::fields($slot ?? SchemaProvider::slot($key) ?? []) as $field) {
            $id = $field['id'];
            if (($field['type'] ?? '') === 'blocks' && array_key_exists($id, $item)) {
                $repaired = self::repairMixedBlocks($item[$id]);
                if ($repaired !== null) {
                    $item[$id] = $repaired;
                    continue;
                }
            }
            if (empty($field['localized']) || !array_key_exists($id, $item)) {
                continue;
            }
            $origin = self::definition($db, $key, $uid ?? (string) ($item['_dndId'] ?? '__self__'), $field);
            if (empty($origin['localized'])) {
                $item[$id] = [self::defaultLanguage() => $item[$id]];
            }
        }
        return $item;
    }

    public static function editorPayload(PDO $db, string $key, mixed $data): mixed
    {
        if (!is_array($data) || !SchemaProvider::initialized()) {
            return $data;
        }
        return array_is_list($data)
            ? array_map(static fn (array $item): array => self::editorItem($db, $key, $item), $data)
            : self::editorItem($db, $key, $data);
    }

    /**
     * Retain hidden translations when localization is disabled. Both old and new
     * values use the same layout during validation, so unchanged legacy types
     * remain editable without accepting invalid new values.
     */
    public static function prepareWrite(PDO $db, string $key, array $item, ?array $old, array $slot, ?string $uid = null): array
    {
        $comparison = $old;
        $default = self::defaultLanguage();
        foreach ($slot['fields'] ?? [] as $index => $field) {
            $id = $field['id'];
            if ($old === null || !array_key_exists($id, $old)) {
                continue;
            }
            $oldBlocks = ($field['type'] ?? '') === 'blocks' ? self::repairMixedBlocks($old[$id]) : null;
            if ($oldBlocks !== null) {
                // Old editors mixed unlocalized numeric blocks with hidden locale arrays.
                // Project them consistently on both sides; edited blocks still undergo validation.
                $comparison[$id] = $oldBlocks;
                $slot['fields'][$index]['localized'] = true;
                if (array_key_exists($id, $item)) {
                    $incoming = self::repairMixedBlocks($item[$id]) ?? $item[$id];
                    $isMap = is_array($incoming) && !array_is_list($incoming)
                        && count(array_filter(array_keys($incoming), static fn ($locale): bool =>
                            preg_match('/^[a-z]{2}(?:[-_][A-Za-z0-9]{2,8})*$/D', (string) $locale) === 1
                        )) === count($incoming);
                    $item[$id] = $isMap ? $incoming + $oldBlocks : array_replace($oldBlocks, [$default => $incoming]);
                }
                continue;
            }
            $origin = self::definition($db, $key, $uid ?? (string) ($item['_dndId'] ?? '__self__'), $field);
            if (!empty($field['localized']) && empty($origin['localized'])) {
                $comparison[$id] = [$default => $old[$id]];
                if (array_key_exists($id, $item) && $item[$id] === $old[$id]) {
                    $item[$id] = $comparison[$id];
                }
            } elseif (empty($field['localized']) && !empty($origin['localized']) && is_array($old[$id])) {
                // The stored map keeps its locale partition even with one visible editor.
                $slot['fields'][$index]['localized'] = true;
                if (array_key_exists($id, $item)) {
                    $incoming = $item[$id];
                    $isMap = is_array($incoming) && !array_is_list($incoming)
                        && count(array_filter(array_keys($incoming), static fn ($locale): bool =>
                            array_key_exists($locale, $old[$id]) || preg_match('/^[a-z]{2}(?:[-_][A-Za-z0-9]{2,8})*$/D', (string) $locale) === 1
                        )) === count($incoming);
                    $item[$id] = $isMap
                        ? $incoming + $old[$id]
                        : array_replace($old[$id], [$default => $incoming]);
                }
            }
        }
        return [$item, $comparison, $slot];
    }

    /** Compatibility scans use the same lossless layouts as editor writes. */
    public static function issues(PDO $db, string $key, string $uid, array $item, array $slot): array
    {
        [$projected, , $validationSlot] = self::prepareWrite($db, $key, $item, $item, $slot, $uid);
        return SchemaDefinition::issues($projected, $validationSlot);
    }

    public static function ensure(PDO $db): void
    {
        $id = spl_object_id($db);
        if (isset(self::$ready[$id])) {
            return;
        }
        $db->exec('CREATE TABLE IF NOT EXISTS schema_value_definitions(hash TEXT PRIMARY KEY,definition_json TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS schema_value_provenance(slot_key TEXT NOT NULL,item_uid TEXT NOT NULL,field_id TEXT NOT NULL,definition_hash TEXT NOT NULL,PRIMARY KEY(slot_key,item_uid,field_id));');
        self::$ready[$id] = true;
    }

    public static function record(PDO $db, string $key, string $uid, array $item, ?array $old): void
    {
        if (!SchemaProvider::initialized()) {
            return;
        }
        self::ensure($db);
        foreach (SchemaDefinition::fields(SchemaProvider::slot($key) ?? []) as $field) {
            $id = $field['id'];
            $structural = in_array($field['type'], ['relation', 'relation_many', 'blocks'], true) || !empty($field['localized']);
            if (!array_key_exists($id, $item) || ($old !== null && array_key_exists($id, $old) && $old[$id] === $item[$id])) {
                continue;
            }
            if (!$structural && !self::interpretationChanged(self::definition($db, $key, $uid, $field), $field)) {
                continue;
            }
            if (($field['type'] ?? '') === 'blocks' && $old !== null
                && self::repairMixedBlocks($old[$id] ?? null) !== null) {
                $field['localized'] = true;
            }
            $origin = self::definition($db, $key, $uid, $field);
            if ($old !== null && array_key_exists($id, $old)) {
                if (!empty($origin['localized']) && empty($field['localized']) && is_array($item[$id])) {
                    $field['localized'] = true;
                } elseif (empty($origin['localized']) && !empty($field['localized'])
                    && $item[$id] === [self::defaultLanguage() => $old[$id]]) {
                    // A layout-only save must not reclassify an unchanged legacy type/target.
                    $field = $origin;
                    $field['localized'] = true;
                }
            }
            $json = SchemaDefinition::json($field);
            $hash = hash('sha256', $json);
            $db->prepare('INSERT OR IGNORE INTO schema_value_definitions VALUES(?,?)')->execute([$hash, $json]);
            $db->prepare('INSERT INTO schema_value_provenance VALUES(?,?,?,?) ON CONFLICT(slot_key,item_uid,field_id) DO UPDATE SET definition_hash=excluded.definition_hash')->execute([$key, $uid, $id, $hash]);
        }
    }

    /**
     * Repair only the unambiguous legacy mixture of numeric blocks and locale arrays.
     * All blocks and translations survive; arbitrary malformed objects are never accepted.
     */
    public static function repairMixedBlocks(mixed $value): ?array
    {
        if (!is_array($value) || array_is_list($value)) {
            return null;
        }
        $blocks = [];
        $locales = [];
        foreach ($value as $key => $entry) {
            if ((is_int($key) && $key >= 0) || (is_string($key) && ctype_digit($key) && (string) (int) $key === $key)) {
                if (!is_array($entry) || !is_string($entry['type'] ?? null) || trim($entry['type']) === '') {
                    return null;
                }
                $blocks[(int) $key] = $entry;
            } elseif (preg_match('/^[a-z]{2}(?:[-_][A-Za-z0-9]{2,8})*$/D', (string) $key) === 1
                && is_array($entry) && array_is_list($entry)) {
                foreach ($entry as $block) {
                    if (!is_array($block) || !is_string($block['type'] ?? null) || trim($block['type']) === '') {
                        return null;
                    }
                }
                $locales[$key] = $entry;
            } else {
                return null;
            }
        }
        if ($blocks === [] || $locales === []) {
            return null;
        }
        ksort($blocks, SORT_NUMERIC);
        $default = self::defaultLanguage();
        $locales[$default] = array_merge(array_values($blocks), $locales[$default] ?? []);
        return $locales;
    }

    /** Copy interpretation metadata so unchanged legacy values retain their layouts and relation targets. */
    public static function inheritCopy(PDO $db, string $key, string $sourceUid, string $uid, array $source, array $slot): void
    {
        if (!SchemaProvider::initialized()) {
            return;
        }
        self::ensure($db);
        foreach (self::fields($db, $key, $sourceUid, $slot) as $field) {
            if (!array_key_exists($field['id'], $source)) {
                continue;
            }
            $json = SchemaDefinition::json($field);
            $hash = hash('sha256', $json);
            $db->prepare('INSERT OR IGNORE INTO schema_value_definitions VALUES(?,?)')->execute([$hash, $json]);
            $db->prepare('INSERT INTO schema_value_provenance VALUES(?,?,?,?)')->execute([$key, $uid, $field['id'], $hash]);
        }
    }

    public static function definition(PDO $db, string $key, string $uid, array $field): array
    {
        if (!SchemaProvider::initialized()) {
            return $field;
        }
        $table = $db->query("SELECT 1 FROM sqlite_master WHERE name='schema_value_provenance'")->fetchColumn();
        if ($table) {
            $query = $db->prepare('SELECT d.definition_json FROM schema_value_provenance p JOIN schema_value_definitions d ON d.hash=p.definition_hash WHERE p.slot_key=? AND p.item_uid=? AND p.field_id=?');
            $query->execute([$key, $uid, $field['id']]);
            $json = $query->fetchColumn();
            if ($json !== false) {
                return json_decode($json, true, 512, JSON_THROW_ON_ERROR);
            }
        }
        $query = SchemaProvider::store()->db->prepare('SELECT definition_json FROM schema_legacy_fields WHERE slot_key=? AND field_id=?');
        $query->execute([$key, $field['id']]);
        $json = $query->fetchColumn();
        $current = array_column(SchemaDefinition::fields(SchemaProvider::slot($key) ?? []), null, 'id');
        return $json === false ? ($current[$field['id']] ?? $field) : json_decode($json, true, 512, JSON_THROW_ON_ERROR);
    }

    /** Native indexes must retain the interpretation of archived and unchanged legacy fields. */
    public static function fields(PDO $db, string $key, string $uid, array $slot): array
    {
        $fields = array_column(SchemaDefinition::fields($slot), null, 'id');
        if (SchemaProvider::initialized()) {
            $query = SchemaProvider::store()->db->prepare("SELECT field_id,definition_json FROM schema_archives WHERE slot_key=? AND field_id<>''");
            $query->execute([$key]);
            foreach ($query as $row) {
                $fields[$row['field_id']] ??= json_decode($row['definition_json'], true, 512, JSON_THROW_ON_ERROR);
            }
        }
        return array_map(static fn (array $field): array => self::definition($db, $key, $uid, $field), array_values($fields));
    }

    public static function interpretationChanged(array $before, array $after): bool
    {
        foreach (['type', 'localized', 'target'] as $key) {
            if (($before[$key] ?? null) !== ($after[$key] ?? null)) {
                return true;
            }
        }
        return false;
    }
}
