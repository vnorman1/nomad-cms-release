<?php
/**
 * NOMAD CMS — Schema definitions and compatibility classification.
 * Validates structural contracts and existing values without coercing data.
 * Change classification separates editor presentation from public contracts.
 */

declare(strict_types=1);

namespace NomadCMS\Services\Schema;

final class SchemaDefinition
{
    public const TYPES = ['text', 'textarea', 'richtext', 'number', 'email', 'url', 'date', 'time', 'boolean', 'select', 'multiselect', 'image', 'gif', 'gallery', 'color', 'json', 'array', 'file', 'slug', 'map', 'iframe', 'blocks', 'video', 'audio', 'relation', 'relation_many'];
    private const PRESENTATION = ['label', 'description', 'icon', 'placeholder', 'helpText', 'hidden', 'disabled', 'readOnly', 'defaultValue', 'columnWidth', 'showInTable', 'blockRecommendations', 'quickCreateField'];
    private const PUBLICATION_SETTINGS = ['isSitemap', 'urlPattern', 'includeLastmod', 'lastmodField', 'isLlms', 'titleField', 'summaryField'];

    public static function fields(array $slot): array
    {
        return array_map(TemporalField::normalize(...), array_values($slot['fields'] ?? []));
    }

    public static function canonical(mixed $value): mixed
    {
        if (!is_array($value)) {
            return $value;
        }
        if (!array_is_list($value)) {
            ksort($value, SORT_STRING);
        }
        return array_map(self::canonical(...), $value);
    }

    public static function json(array $schema): string
    {
        $schema = self::canonical($schema);
        if (array_key_exists('slots', $schema)) {
            $schema['slots'] = (object) $schema['slots'];
        }
        return json_encode($schema, JSON_THROW_ON_ERROR | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    }

    public static function validate(array $schema): array
    {
        $errors = [];
        if (!isset($schema['slots']) || !is_array($schema['slots'])) {
            return [['path' => 'slots', 'message' => 'Slots object required.']];
        }
        foreach ($schema['slots'] as $key => $slot) {
            if (!preg_match('/^[a-zA-Z][a-zA-Z0-9_-]{0,99}$/D', (string) $key) || !is_array($slot)) {
                $errors[] = ['path' => "slots.$key", 'message' => 'Invalid slot identifier or definition.'];
                continue;
            }
            if (!in_array($slot['type'] ?? '', ['object', 'list', 'collection', 'massive'], true) || !is_string($slot['label'] ?? null) || !is_array($slot['fields'] ?? null)) {
                $errors[] = ['path' => "slots.$key", 'message' => 'Slot type, label and fields are required.'];
                continue;
            }
            $ids = [];
            if (array_key_exists('publicAccess', $slot) && (!is_bool($slot['publicAccess']) || ($slot['publicAccess'] && $slot['type'] !== 'list'))) {
                $errors[] = ['path' => "slots.$key.publicAccess", 'message' => 'Public access is a boolean setting for list slots only.'];
            }
            if (array_key_exists('quickCreateField', $slot)) {
                try {
                    self::quickCreateTemplate($slot);
                } catch (\InvalidArgumentException $error) {
                    $errors[] = ['path' => "slots.$key.quickCreateField", 'message' => $error->getMessage()];
                }
            }
            foreach (self::fields($slot) as $field) {
                $id = $field['id'] ?? '';
                if (!is_string($id) || !preg_match('/^[a-zA-Z][a-zA-Z0-9_-]{0,99}$/D', $id) || isset($ids[$id]) || !in_array($field['type'] ?? '', self::TYPES, true) || !is_string($field['label'] ?? null)) {
                    $errors[] = ['path' => "slots.$key.fields.$id", 'message' => 'Invalid or duplicate field definition.'];
                    continue;
                }
                $ids[$id] = true;
                if ($id === 'uid' && ($slot['publicAccess'] ?? false) === true) {
                    $errors[] = ['path' => "slots.$key.fields.uid", 'message' => 'uid is reserved for public list identity.'];
                }
                if (!TemporalField::validConfig($field)) {
                    $errors[] = ['path' => "slots.$key.fields.$id.granularity", 'message' => 'Granularity must match Date or Time.'];
                }
                foreach ($field['blockRecommendations'] ?? [] as $index => $recommendation) {
                    if (!TemporalField::validConfig($recommendation)) {
                        $errors[] = ['path' => "slots.$key.fields.$id.blockRecommendations.$index.granularity", 'message' => 'Granularity must match Date or Time.'];
                    }
                }
                foreach (['required', 'localized', 'searchable', 'sortable', 'filterable'] as $flag) {
                    if (isset($field[$flag]) && !is_bool($field[$flag])) {
                        $errors[] = ['path' => "slots.$key.$id.$flag", 'message' => 'Boolean required.'];
                    }
                }
                if (in_array($field['type'], ['relation', 'relation_many'], true) && !isset($schema['slots'][$field['target'] ?? ''])) {
                    $errors[] = ['path' => "slots.$key.$id.target", 'message' => 'Active relation target required.'];
                }
                $pattern = $field['validation']['pattern'] ?? null;
                if ($pattern !== null && (!is_string($pattern) || @preg_match('~' . str_replace('~', '\\~', $pattern) . '~u', '') === false)) {
                    $errors[] = ['path' => "slots.$key.$id.validation.pattern", 'message' => 'Invalid regular expression.'];
                }
            }
            foreach (['slugField', 'publishedField', 'lastmodField', 'titleField', 'summaryField'] as $binding) {
                if (!empty($slot[$binding]) && !isset($ids[$slot[$binding]])) {
                    $errors[] = ['path' => "slots.$key.$binding", 'message' => 'Binding must refer to an active field.'];
                }
            }
        }
        return $errors;
    }

    /** Defaults for an atomic quick-create operation; the name is validated at write time. */
    public static function quickCreateTemplate(array $slot): array
    {
        $id = $slot['quickCreateField'] ?? null;
        $fields = array_column(self::fields($slot), null, 'id');
        if (($slot['type'] ?? '') !== 'list' || !is_string($id) || !isset($fields[$id])
            || ($fields[$id]['type'] ?? '') !== 'text' || !empty($fields[$id]['localized'])
            || !empty($fields[$id]['readOnly']) || !empty($fields[$id]['disabled'])) {
            throw new \InvalidArgumentException('Quick create requires an editable, non-localized text field on a list.');
        }
        $defaults = [];
        unset($fields[$id]);
        foreach ($fields as $field) {
            if (array_key_exists('defaultValue', $field)) {
                $defaults[$field['id']] = $field['defaultValue'];
            }
        }
        if (self::issues($defaults, ['fields' => array_values($fields)]) !== []) {
            throw new \InvalidArgumentException('Other required fields need valid defaults for quick create.');
        }
        return $defaults;
    }

    public static function changes(array $before, array $after): array
    {
        $changes = [];
        $level = 'patch';
        $rank = ['patch' => 0, 'minor' => 1, 'major' => 2];
        $append = static function (string $path, string $operation, string $impact) use (&$changes, &$level, $rank): void {
            $changes[] = compact('path', 'operation', 'impact');
            if ($rank[$impact] > $rank[$level]) {
                $level = $impact;
            }
        };
        foreach (array_unique(array_merge(array_keys($before['slots'] ?? []), array_keys($after['slots'] ?? []))) as $key) {
            $old = $before['slots'][$key] ?? null;
            $new = $after['slots'][$key] ?? null;
            if (!$new) {
                $append("slots.$key", 'archive_slot', 'major');
                continue;
            }
            if (!$old) {
                $append("slots.$key", 'add_slot', 'minor');
                continue;
            }
            $oldFields = array_column(self::fields($old), null, 'id');
            $newFields = array_column(self::fields($new), null, 'id');
            foreach (array_unique(array_merge(array_keys($oldFields), array_keys($newFields))) as $id) {
                if (!isset($newFields[$id])) {
                    $append("slots.$key.fields.$id", 'archive_field', 'major');
                } elseif (!isset($oldFields[$id])) {
                    $append("slots.$key.fields.$id", 'add_field', !empty($newFields[$id]['required']) ? 'major' : 'minor');
                } elseif (self::canonical($oldFields[$id]) !== self::canonical($newFields[$id])) {
                    $properties = array_keys(array_filter($newFields[$id] + $oldFields[$id], static fn ($v, $p) => ($newFields[$id][$p] ?? null) !== ($oldFields[$id][$p] ?? null), ARRAY_FILTER_USE_BOTH));
                    $impact = array_diff($properties, self::PRESENTATION) ? 'major' : 'patch';
                    $append("slots.$key.fields.$id", 'modify_field', $impact);
                }
            }
            unset($old['fields'], $new['fields']);
            foreach (array_unique(array_merge(array_keys($old), array_keys($new))) as $property) {
                if ($property === 'publicAccess') {
                    if (($old[$property] ?? false) !== ($new[$property] ?? false)) {
                        $append("slots.$key.$property", 'modify_slot', ($new[$property] ?? false) ? 'minor' : 'major');
                    }
                    continue;
                }
                if (($old[$property] ?? null) !== ($new[$property] ?? null)) {
                    $presentation = in_array($property, [...self::PRESENTATION, ...self::PUBLICATION_SETTINGS], true);
                    $append("slots.$key.$property", 'modify_slot', $presentation ? 'patch' : 'major');
                }
            }
        }
        foreach (array_unique(array_merge(array_keys($before), array_keys($after))) as $property) {
            if (!in_array($property, ['slots', 'version', 'lastModified'], true) && ($before[$property] ?? null) !== ($after[$property] ?? null)) {
                $impact = in_array($property, ['$id', '$schema', 'description', 'logging', 'contentBatching', 'llms', 'staticPages'], true) ? 'patch' : 'major';
                if ($property === 'staticPages') {
                    $oldPaths = array_column($before['staticPages'] ?? [], 'path');
                    $newPaths = array_column($after['staticPages'] ?? [], 'path');
                    $impact = array_diff($newPaths, $oldPaths) !== [] ? 'minor' : 'patch';
                }
                $append($property, 'modify_config', $impact);
            }
        }
        return ['changes' => $changes, 'impact' => $level];
    }

    public static function nextVersion(string $version, string $impact): string
    {
        $parts = array_map('intval', explode('.', $version));
        [$major, $minor, $patch] = array_pad($parts, 3, 0);
        return match ($impact) {
            'major' => ($major + 1) . '.0.0',
            'minor' => "$major." . ($minor + 1) . '.0',
            default => "$major.$minor." . ($patch + 1),
        };
    }

    public static function issues(array $item, array $slot, ?array $old = null): array
    {
        $issues = [];
        foreach (self::fields($slot) as $field) {
            $id = $field['id'];
            if ($old !== null && array_key_exists($id, $item) === array_key_exists($id, $old)
                && ($item[$id] ?? null) === ($old[$id] ?? null)) {
                continue;
            }
            $value = $item[$id] ?? null;
            // Older editors initialize untouched localized fields as an empty string.
            // Treat only that empty draft as missing; non-empty scalars remain invalid.
            if (!empty($field['localized']) && $value === '') {
                $value = null;
            }
            if (!empty($field['localized']) && $value === [] && !empty($field['required'])) {
                $issues[] = ['path' => $id, 'message' => 'Required value missing.'];
                continue;
            }
            $values = !empty($field['localized']) ? $value : ['' => $value];
            if (!empty($field['localized']) && $value !== null && (!is_array($value) || (array_is_list($value) && $value !== []))) {
                $issues[] = ['path' => $id, 'message' => 'Localized map required.'];
                continue;
            }
            foreach ($values ?? ['' => null] as $locale => $entry) {
                // Changing one locale must not force conversion of another legacy value.
                if (!empty($field['localized']) && $old !== null && is_array($old[$id] ?? null)
                    && array_key_exists($locale, $old[$id]) && $old[$id][$locale] === $entry) {
                    continue;
                }
                $message = self::valueIssue($entry, $field);
                if ($message !== null) {
                    $issues[] = ['path' => $id . ($locale !== '' ? ".$locale" : ''), 'message' => $message];
                }
            }
        }
        return $issues;
    }

    private static function valueIssue(mixed $value, array $field): ?string
    {
        if ($value === null || $value === '' || $value === []) {
            return !empty($field['required']) ? 'Required value missing.' : null;
        }
        $type = $field['type'];
        $valid = match ($type) {
            'number' => is_int($value) || is_float($value),
            'boolean' => is_bool($value),
            'blocks', 'array', 'gallery', 'multiselect', 'relation_many' => is_array($value) && array_is_list($value),
            'json' => true,
            'image', 'gif', 'file', 'video', 'audio', 'map' => is_string($value) || is_array($value),
            default => is_string($value),
        };
        if (!$valid) {
            return "Invalid $type value.";
        }
        if ($type === 'blocks') {
            foreach ($value as $block) {
                if (!is_array($block) || !is_string($block['type'] ?? null) || $block['type'] === '') {
                    return 'Invalid block entry.';
                }
            }
        }
        if (TemporalField::isTemporal($field) && !TemporalField::validValue($value, $field)) {
            return 'Invalid temporal value for configured granularity.';
        }
        $rules = $field['validation'] ?? [];
        if (is_string($value)) {
            $length = function_exists('mb_strlen') ? mb_strlen($value) : strlen($value);
            if ((isset($rules['minLength']) && $length < $rules['minLength']) || (isset($rules['maxLength']) && $length > $rules['maxLength'])) {
                return 'Text length outside allowed range.';
            }
            if (!empty($rules['pattern']) && @preg_match('~' . str_replace('~', '\\~', $rules['pattern']) . '~u', $value) !== 1) {
                return 'Value does not match pattern.';
            }
            if ($type === 'email' && filter_var($value, FILTER_VALIDATE_EMAIL) === false) {
                return 'Invalid email.';
            }
            if ($type === 'url' && filter_var($value, FILTER_VALIDATE_URL) === false) {
                return 'Invalid URL.';
            }
        }
        if (is_int($value) || is_float($value)) {
            if ((isset($rules['min']) && $value < $rules['min']) || (isset($rules['max']) && $value > $rules['max'])) {
                return 'Number outside allowed range.';
            }
        }
        if (in_array($type, ['select', 'multiselect'], true)) {
            $allowed = array_column($field['options'] ?? [], 'value');
            foreach (is_array($value) ? $value : [$value] as $option) {
                if (!in_array($option, $allowed, true)) {
                    return 'Unknown selection.';
                }
            }
        }
        if ($type === 'relation_many' && count(array_filter($value, 'is_string')) !== count($value)) {
            return 'Relation identifiers must be strings.';
        }
        return null;
    }
}
