<?php
/**
 * NOMAD CMS — Intelligent schema migration coordinator.
 * Analyzes drafts, samples in isolated SQLite, journals short metadata cutovers,
 * and advances bounded compatibility/index jobs without rewriting content rows.
 */

declare(strict_types=1);

namespace NomadCMS\Services\Schema;

use PDO;
use NomadCMS\Database\CollectionDatabase;
use NomadCMS\Database\MassiveDatabase;
use NomadCMS\Database\MassiveEncryption;

final class SchemaEngine
{
    public function __construct(
        public readonly SchemaStore $store,
        private readonly ?PDO $content = null,
        private readonly ?PDO $massive = null,
        private readonly ?\Closure $authorizeApproval = null
    ) {
    }

    public function status(int $limit = 100, int $offset = 0): array
    {
        SchemaProvider::cleanupLegacyLocks();
        $active = $this->store->active();
        // Completed proposals are revisions in history, not live workspace jobs.
        $drafts = $this->store->db->query("SELECT id,base_revision,author,reason,status,updated_at FROM schema_drafts WHERE status <> 'active' ORDER BY updated_at DESC LIMIT 50")->fetchAll();
        $limit = max(1, min(200, $limit));
        $offset = max(0, $offset);
        $pages = [];
        $hasMore = [];
        foreach (['archives' => 'schema_archives', 'scans' => 'schema_scan_jobs', 'indexes' => 'schema_index_jobs', 'gates' => 'schema_gates'] as $name => $table) {
            $order = $name === 'indexes' ? 'id' : 'slot_key';
            if ($name === 'archives') {
                $order .= ',field_id';
            }
            $query = $this->store->db->prepare("SELECT * FROM $table ORDER BY $order LIMIT ? OFFSET ?");
            $query->execute([$limit + 1, $offset]);
            $rows = $query->fetchAll();
            $hasMore[$name] = count($rows) > $limit;
            $pages[$name] = array_slice($rows, 0, $limit);
        }
        return [
            'initialized' => $active !== null,
            'active' => $active,
            'baseline' => $active ? null : SchemaProvider::baseline(),
            'drafts' => $drafts,
            'pagination' => ['limit' => $limit, 'offset' => $offset, 'has_more' => $hasMore],
        ] + $pages;
    }

    public function draft(array $schema, int $base, string $actor, string $reason, ?int $restore = null): array
    {
        if (trim($reason) === '') {
            throw new \InvalidArgumentException('A change reason is required.', 422);
        }
        $errors = SchemaDefinition::validate($schema);
        if ($errors !== []) {
            throw new \InvalidArgumentException(json_encode($errors, JSON_THROW_ON_ERROR), 422);
        }
        $head = $this->store->active();
        if (($head['revision'] ?? 0) !== $base) {
            throw new \RuntimeException('SCHEMA_REVISION_CONFLICT', 409);
        }
        if ($restore !== null) {
            $schema = $this->store->revision($restore)['schema'];
        }
        unset($schema['_revision'], $schema['_schemaHash']);
        $id = bin2hex(random_bytes(16));
        $this->store->db->prepare('INSERT INTO schema_drafts(id,base_revision,schema_json,author,reason,status,updated_at,journal_json) VALUES(?,?,?,?,?,?,?,?)')->execute([
            $id, $base, SchemaDefinition::json($schema), $actor, trim($reason), 'draft', gmdate('c'),
            json_encode(['restore_from' => $restore], JSON_THROW_ON_ERROR),
        ]);
        $this->store->audit($actor, 'draft.created', ['id' => $id, 'base' => $base, 'restore_from' => $restore]);
        return $this->getDraft($id);
    }

    public function getDraft(string $id): array
    {
        $query = $this->store->db->prepare('SELECT * FROM schema_drafts WHERE id=?');
        $query->execute([$id]);
        $draft = $query->fetch();
        if (!$draft) {
            throw new \OutOfBoundsException('Draft not found.', 404);
        }
        foreach (['schema_json' => 'schema', 'report_json' => 'report', 'approval_json' => 'approval', 'journal_json' => 'journal'] as $column => $key) {
            $draft[$key] = $draft[$column] ? json_decode($draft[$column], true, 512, JSON_THROW_ON_ERROR) : null;
            unset($draft[$column]);
        }
        $draft['base_revision'] = (int) $draft['base_revision'];
        return $draft;
    }

    /** Delete an unactivated proposal under the same coordination lease as activation. */
    public function deleteDraft(string $id, string $actor): array
    {
        SchemaProvider::release();
        $mutex = fopen(SchemaProvider::lockPath(), 'c');
        if (!$mutex || !flock($mutex, LOCK_EX | LOCK_NB)) {
            if (is_resource($mutex)) {
                fclose($mutex);
            }
            throw new \RuntimeException('Another schema operation is running.', 409);
        }
        try {
            return $this->store->transaction(function () use ($id, $actor): array {
                $draft = $this->getDraft($id);
                $gates = $this->store->db->prepare('SELECT 1 FROM schema_gates WHERE draft_id=? LIMIT 1');
                $gates->execute([$id]);
                if (!in_array($draft['status'], ['draft', 'analysed', 'tested', 'approved', 'failed'], true)
                    || isset($draft['journal']['activated_revision']) || $gates->fetchColumn() !== false) {
                    throw new \RuntimeException('An activating or activated schema cannot be deleted.', 409);
                }
                $this->store->db->prepare('DELETE FROM schema_drafts WHERE id=?')->execute([$id]);
                $this->store->audit($actor, 'draft.deleted', [
                    'id' => $id,
                    'base_revision' => $draft['base_revision'],
                    'reason' => $draft['reason'],
                    'status' => $draft['status'],
                ]);
                return ['id' => $id, 'deleted' => true];
            });
        } finally {
            flock($mutex, LOCK_UN);
            fclose($mutex);
        }
    }

    public function analyse(string $id): array
    {
        $draft = $this->getDraft($id);
        if (!in_array($draft['status'], ['draft', 'analysed', 'tested'], true)) {
            throw new \RuntimeException('Draft cannot be analysed in its current state.', 409);
        }
        $report = $this->buildReport($draft);
        $this->update($id, 'analysed', ['report_json' => SchemaDefinition::json($report), 'approval_json' => null]);
        return $this->getDraft($id);
    }

    private function buildReport(array $draft): array
    {
        $active = $this->store->active();
        if (($active['revision'] ?? 0) !== $draft['base_revision']) {
            throw new \RuntimeException('SCHEMA_REVISION_CONFLICT', 409);
        }
        $old = $active['schema'] ?? SchemaProvider::baseline();
        $new = $draft['schema'];
        $diff = SchemaDefinition::changes($old, $new);
        $blockers = SchemaDefinition::validate($new);
        $affected = [];
        foreach ($diff['changes'] as $change) {
            if (preg_match('/^slots\.([^.]+)/', $change['path'], $match)) {
                $affected[$match[1]] = true;
            } else {
                foreach (array_keys($old['slots']) as $key) {
                    $affected[$key] = true;
                }
            }
        }
        if (!$active) {
            $affected = array_fill_keys(array_keys($new['slots']), true);
        }
        foreach ($old['slots'] as $key => $slot) {
            if (isset($new['slots'][$key]) && $new['slots'][$key]['type'] !== $slot['type']) {
                $blockers[] = ['path' => "slots.$key.type", 'message' => 'Existing slot types are immutable.'];
            }
            if (!isset($new['slots'][$key])) {
                $blockers = array_merge($blockers, $this->dependencies($key, $new));
            }
        }
        foreach ($this->store->db->query('SELECT * FROM schema_archives') as $archive) {
            $key = $archive['slot_key'];
            $field = $archive['field_id'];
            $restored = $field === '' ? isset($new['slots'][$key]) : isset(array_column(SchemaDefinition::fields($new['slots'][$key] ?? []), null, 'id')[$field]);
            if ($restored && empty($draft['journal']['restore_from'])) {
                $blockers[] = ['path' => "slots.$key.$field", 'message' => 'Archived identifiers may only return through an explicit rollback.'];
            }
        }
        $suggestions = [];
        foreach ($new['slots'] as $key => $slot) {
            if (!empty($slot['massive']['encrypted']) && !MassiveEncryption::isAvailable()) {
                $blockers[] = ['path' => "slots.$key.massive.encrypted", 'message' => 'Encryption key unavailable.'];
            }
            if (in_array($slot['type'], ['collection', 'massive'], true)) {
                foreach (SchemaDefinition::fields($slot) as $field) {
                    if (empty($field['localized']) && in_array($field['type'], ['text', 'number', 'date', 'time', 'datetime', 'boolean'], true)
                        && (!empty($field['sortable']) || !empty($field['filterable']))) {
                        $suggestions[] = ['slot' => $key, 'field' => $field['id'], 'reason' => 'Scalar filtering/sorting projection; separate approval required.'];
                    }
                }
            }
        }
        return $diff + [
            'base_revision' => $draft['base_revision'],
            'candidate_hash' => hash('sha256', SchemaDefinition::json($new)),
            'affected_slots' => array_keys($affected), 'blockers' => $blockers,
            'index_suggestions' => $suggestions, 'sampled' => 0, 'legacy_issues' => [],
            'coverage' => 'Not tested. A sample never certifies full compatibility.',
        ];
    }

    private function dependencies(string $target, array $schema): array
    {
        $blockers = [];
        foreach ($schema['slots'] as $key => $slot) {
            if ($key === $target) {
                continue;
            }
            $depends = in_array($target, $slot['dependencies'] ?? [], true);
            foreach (SchemaDefinition::fields($slot) as $field) {
                $depends = $depends || in_array($target, array_filter([$field['target'] ?? null, $field['referenceSlot'] ?? null, $field['sourceSlot'] ?? null]), true);
            }
            if ($depends) {
                $blockers[] = ['path' => "slots.$key", 'message' => "Active dependency on $target."];
            }
        }
        $db = $this->contentDb();
        if ($this->tableExists($db, 'slot_relations')) {
            $query = $db->prepare('SELECT DISTINCT source_key,field_id FROM slot_relations WHERE target_key=?');
            $query->execute([$target]);
            foreach ($query as $row) {
                $blockers[] = ['path' => $row['source_key'] . '.' . $row['field_id'], 'message' => 'Incoming record reference exists, including retained legacy values.'];
            }
        }
        // Mapping rules are persistent integration dependencies, independent of record counts.
        $systemPath = $_ENV['NOMAD_SCHEMA_SYSTEM_PATH'] ?? dirname(__DIR__, 3) . '/databases/' . ($_ENV['DB_SYSTEM_DATABASE'] ?? 'system.sqlite');
        if (is_file($systemPath)) {
            $system = new PDO('sqlite:file:' . $systemPath . '?mode=ro');
            foreach ($system->query("SELECT name FROM sqlite_master WHERE type='table' AND name LIKE '%mapping%'") as $table) {
                $name = $table['name'] ?? $table[0];
                $columns = $system->query('PRAGMA table_info("' . str_replace('"', '""', $name) . '")')->fetchAll(PDO::FETCH_ASSOC);
                if (in_array('target_key', array_column($columns, 'name'), true)) {
                    $query = $system->prepare('SELECT 1 FROM "' . str_replace('"', '""', $name) . '" WHERE target_key=? LIMIT 1');
                    $query->execute([$target]);
                    if ($query->fetchColumn()) {
                        $blockers[] = ['path' => $name, 'message' => 'Integration mapping targets this slot.'];
                    }
                }
            }
        }
        return $blockers;
    }

    public function test(string $id): array
    {
        $draft = $this->getDraft($id);
        if ($draft['status'] !== 'analysed') {
            throw new \RuntimeException('Analyse the draft before testing.', 409);
        }
        $report = $this->buildReport($draft);
        // Bounded samples stay in RAM: encrypted native rows never become plaintext files.
        $sandbox = new PDO('sqlite::memory:', null, null, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
        $sandbox->exec('CREATE TABLE samples(slot_key TEXT,item_id TEXT,data TEXT); PRAGMA temp_store=MEMORY');
        try {
            foreach ($report['affected_slots'] as $key) {
                $slot = $draft['schema']['slots'][$key] ?? null;
                if (!$slot) {
                    continue;
                }
                $sandbox->exec('DELETE FROM samples');
                foreach ($this->sampleRecords($key, $slot, 32) as $item) {
                    $sandbox->prepare('INSERT INTO samples VALUES(?,?,?)')->execute([$key, $item['id'], SchemaDefinition::json($item['data'])]);
                    $db = $slot['type'] === 'massive' ? $this->massiveDb() : $this->contentDb();
                    $uid = (string) ($item['data']['_dndId'] ?? ($slot['type'] === 'object' ? '__self__' : $item['id']));
                    $issues = SchemaValues::issues($db, $key, $uid, $item['data'], $slot);
                    if ($issues !== []) {
                        $report['legacy_issues'][] = ['slot' => $key, 'item' => $item['id'], 'issues' => $issues];
                    }
                    $report['sampled']++;
                }
            }
            $report['coverage'] = 'Up to 32 randomized records per affected slot. Full assessment runs after activation.';
            $report['tested_at'] = gmdate('c');
            $report['report_hash'] = hash('sha256', SchemaDefinition::json($report));
            $this->update($id, 'tested', ['report_json' => SchemaDefinition::json($report)]);
        } finally {
            $sandbox = null;
        }
        return $this->getDraft($id);
    }

    public function approve(string $id, string $actor, string $hash, bool $acceptLegacy): array
    {
        return $this->store->transaction(function () use ($id, $actor, $hash, $acceptLegacy): array {
            $draft = $this->getDraft($id);
            if ($draft['status'] !== 'tested' || !hash_equals($draft['report']['report_hash'], $hash)) {
                throw new \RuntimeException('A current tested report must be approved.', 409);
            }
            if ($draft['report']['blockers'] !== [] || (!$acceptLegacy && $draft['report']['legacy_issues'] !== [])) {
                throw new \RuntimeException('Resolve blockers and explicitly accept legacy differences.', 422);
            }
            $this->buildReport($draft);
            $approval = ['actor' => $actor, 'report_hash' => $hash, 'candidate_hash' => $draft['report']['candidate_hash'], 'accept_legacy' => $acceptLegacy, 'created_at' => gmdate('c')];
            $this->update($id, 'approved', ['approval_json' => SchemaDefinition::json($approval)]);
            $this->store->audit($actor, 'migration.approved', ['id' => $id, 'report_hash' => $hash]);
            return $this->getDraft($id);
        });
    }

    public function advance(string $id): array
    {
        $draft = $this->getDraft($id);
        if (in_array($draft['status'], ['active', 'failed'], true)) {
            return $draft;
        }
        if ($draft['status'] !== 'approved' && $draft['status'] !== 'activating') {
            throw new \RuntimeException('Approval required before activation.', 409);
        }
        SchemaProvider::release();
        $mutex = fopen(SchemaProvider::lockPath(), 'c');
        if (!$mutex || !flock($mutex, LOCK_EX | LOCK_NB)) {
            if (is_resource($mutex)) {
                fclose($mutex);
            }
            throw new \RuntimeException('Another schema operation is running.', 409);
        }
        try {
            $draft = $this->getDraft($id);
            if ($draft['status'] === 'activating') {
                return $this->recover($draft);
            }
            $authorized = $this->authorizeApproval ? ($this->authorizeApproval)($draft['approval']['actor']) : SchemaAccess::approvalStillValid($draft['approval']['actor']);
            if (!$authorized) {
                throw new \RuntimeException('Approval authority was revoked.', 403);
            }
            $report = $this->buildReport($draft);
            if ($report['blockers'] !== [] || !hash_equals($report['candidate_hash'], $draft['approval']['candidate_hash'])) {
                throw new \RuntimeException('Migration preconditions changed.', 409);
            }
            $keys = $report['affected_slots'];
            sort($keys, SORT_STRING);
            $old = $this->store->active()['schema'] ?? SchemaProvider::baseline();
            $journal = $draft['journal'] + ['old_schema' => $old, 'affected_slots' => $keys, 'phase' => 'gated'];
            $this->store->transaction(function () use ($keys, $id, $journal): void {
                foreach ($keys as $key) {
                    $this->store->db->prepare('INSERT INTO schema_gates VALUES(?,?)')->execute([$key, $id]);
                }
                $this->update($id, 'activating', ['journal_json' => SchemaDefinition::json($journal)]);
            });
            // Recheck under exclusive leases. No affected writer can race the cutover.
            $report = $this->buildReport($draft);
            if ($report['blockers'] !== []) {
                throw new \RuntimeException('A new blocking dependency appeared.', 409);
            }
            $this->project($draft['schema'], $keys);
            $this->store->transaction(function () use ($draft, $report, $old, $keys, $id): void {
                $revision = $this->store->append($draft['schema'], $draft['approval']['actor'], $draft['reason'], $report);
                $this->archiveDefinitions($old, $draft['schema'], $revision['revision']);
                $this->store->db->exec("UPDATE schema_index_jobs SET status='stale' WHERE status IN ('pending','ready')");
                foreach ($keys as $key) {
                    if (isset($draft['schema']['slots'][$key])) {
                        $this->store->db->prepare("INSERT INTO schema_scan_jobs(slot_key,revision,status) VALUES(?,?,'pending') ON CONFLICT(slot_key) DO UPDATE SET revision=excluded.revision,cursor=0,inspected=0,issues=0,status='pending'")->execute([$key, $revision['revision']]);
                    }
                }
                $journal = $draft['journal'] + ['affected_slots' => $keys];
                $journal['activated_revision'] = $revision['revision'];
                $journal['phase'] = 'committed';
                $this->update($id, 'activating', ['journal_json' => SchemaDefinition::json($journal)]);
                $this->store->audit($draft['approval']['actor'], 'migration.activated', ['id' => $id, 'revision' => $revision['revision']]);
            });
            return $this->finish($this->getDraft($id));
        } catch (\Throwable $error) {
            $current = $this->getDraft($id);
            if ($current['status'] === 'activating') {
                // Keep the gate durable. Recovery acquires the same exclusive leases.
                $journal = $current['journal'];
                $journal['last_error'] = $error->getMessage();
                $this->update($id, 'activating', ['journal_json' => SchemaDefinition::json($journal)]);
            }
            throw $error;
        } finally {
            flock($mutex, LOCK_UN);
            fclose($mutex);
            SchemaProvider::clear();
            if ($this->content === null) {
                // Readers can acquire leases only after the exclusive cutover
                // mutex is released. Purging happened before the gate opened.
                try {
                    $current = $this->getDraft($id);
                    if ($current['status'] === 'active') {
                        foreach ($current['journal']['affected_slots'] ?? [] as $key) {
                            if (($current['schema']['slots'][$key]['type'] ?? '') === 'list') {
                                \NomadCMS\Services\ListQuickCreateService::refreshCaches($key);
                            }
                        }
                    }
                } catch (\Throwable $error) {
                    error_log('[Schema] List cache refresh deferred: ' . $error->getMessage());
                }
            }
        }
    }

    private function recover(array $draft): array
    {
        // advance() already holds the exclusive registry coordination lease.
        if (($draft['journal']['phase'] ?? '') === 'committed') {
            return $this->finish($draft);
        }
        $this->project($draft['journal']['old_schema'], $draft['journal']['affected_slots']);
        $this->store->transaction(function () use ($draft): void {
            $this->store->db->prepare('DELETE FROM schema_gates WHERE draft_id=?')->execute([$draft['id']]);
            $this->update($draft['id'], 'approved');
            $this->store->audit('recovery', 'migration.compensated', ['id' => $draft['id']]);
        });
        return $this->getDraft($draft['id']);
    }

    private function finish(array $draft): array
    {
        $this->invalidate($draft);
        $this->store->transaction(function () use ($draft): void {
            $this->store->db->prepare('DELETE FROM schema_gates WHERE draft_id=?')->execute([$draft['id']]);
            $this->update($draft['id'], 'active');
        });
        return $this->getDraft($draft['id']);
    }

    private function project(array $schema, array $keys): void
    {
        $db = $this->contentDb();
        if (!$this->tableExists($db, 'collection_slots')) {
            return;
        }
        $db->exec('BEGIN IMMEDIATE');
        try {
            foreach ($keys as $key) {
                $definition = $schema['slots'][$key] ?? null;
                if (!$definition || $definition['type'] !== 'collection') {
                    continue;
                }
                $json = json_encode($definition, JSON_THROW_ON_ERROR | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
                $hash = hash('sha256', $json);
                $db->prepare('INSERT OR IGNORE INTO collection_schema_versions(schema_hash,schema_json,created_at) VALUES(?,?,?)')->execute([$hash, $json, gmdate('c')]);
                $db->prepare('UPDATE collection_slots SET schema_json=?,schema_hash=?,revision=revision+1 WHERE slot_key=? AND schema_hash<>?')->execute([$json, $hash, $key, $hash]);
            }
            $db->exec('COMMIT');
        } catch (\Throwable $error) {
            $db->exec('ROLLBACK');
            throw $error;
        }
    }

    private function archiveDefinitions(array $old, array $new, int $revision): void
    {
        $insert = $this->store->db->prepare('INSERT OR IGNORE INTO schema_archives VALUES(?,?,?,?)');
        $remove = $this->store->db->prepare('DELETE FROM schema_archives WHERE slot_key=? AND field_id=?');
        foreach ($old['slots'] as $key => $slot) {
            if (!isset($new['slots'][$key])) {
                $insert->execute([$key, '', SchemaDefinition::json($slot), $revision]);
            }
            $newFields = array_column(SchemaDefinition::fields($new['slots'][$key] ?? []), null, 'id');
            foreach (SchemaDefinition::fields($slot) as $field) {
                if (isset($newFields[$field['id']]) && SchemaValues::interpretationChanged($field, $newFields[$field['id']])) {
                    $this->store->db->prepare('INSERT OR IGNORE INTO schema_legacy_fields VALUES(?,?,?)')->execute([$key, $field['id'], SchemaDefinition::json($field)]);
                }
                if (!isset($newFields[$field['id']])) {
                    $insert->execute([$key, $field['id'], SchemaDefinition::json($field), $revision]);
                }
            }
        }
        foreach ($new['slots'] as $key => $slot) {
            $remove->execute([$key, '']);
            foreach (SchemaDefinition::fields($slot) as $field) {
                $remove->execute([$key, $field['id']]);
            }
        }
    }

    private function invalidate(array $draft): void
    {
        if ($this->content !== null) {
            return; // Injected isolated stores must not touch application cache files.
        }
        SchemaProvider::clear();
        \NomadCMS\Services\RelationService::clearCache();
        \NomadCMS\Services\DependencyGraphService::clearCache();
        \NomadCMS\Services\StaticCacheService::clearSchemaCache();
        foreach ($draft['journal']['affected_slots'] ?? [] as $key) {
            \NomadCMS\Services\StaticCacheService::invalidateSlot($key);
            if (isset($draft['schema']['slots'][$key]) && CollectionDatabase::isRegistered($key)) {
                CollectionDatabase::enqueue($key);
            }
        }
        foreach ($draft['journal']['affected_slots'] ?? [] as $key) {
            if (($draft['schema']['slots'][$key]['type'] ?? '') === 'list') {
                // Schema visibility changes also alter UID-bearing article embeds.
                CollectionDatabase::enqueueDependents($key);
                foreach (\NomadCMS\Services\RelationService::getDependentSlots($key) as $dependent) {
                    \NomadCMS\Services\StaticCacheService::invalidateSlot($dependent);
                }
            }
        }
        \NomadCMS\Services\StaticCacheService::generateManifest();
    }

    public function work(int $limit = 128): array
    {
        $pending = $this->store->db->query("SELECT id FROM schema_drafts WHERE status IN ('activating','approved') ORDER BY updated_at LIMIT 1")->fetchColumn();
        if ($pending !== false) {
            return ['migration' => $this->advance($pending)['status']];
        }
        $head = $this->store->active();
        if (!$head) {
            return ['processed' => 0];
        }
        $job = $this->store->db->query("SELECT * FROM schema_scan_jobs WHERE status='pending' LIMIT 1")->fetch();
        if ($job) {
            $slot = $head['schema']['slots'][$job['slot_key']] ?? null;
            if (!$slot || (int) $job['revision'] !== $head['revision']) {
                $this->store->db->prepare("UPDATE schema_scan_jobs SET status='stale' WHERE slot_key=?")->execute([$job['slot_key']]);
                return ['processed' => 0];
            }
            SchemaProvider::lease($job['slot_key']);
            $batch = $this->records($job['slot_key'], $slot, (int) $job['cursor'], min(128, max(1, $limit)));
            $issues = 0;
            foreach ($batch['items'] as $item) {
                $db = $slot['type'] === 'massive' ? $this->massiveDb() : $this->contentDb();
                $uid = (string) ($item['data']['_dndId'] ?? ($slot['type'] === 'object' ? '__self__' : $item['id']));
                $issues += count(SchemaValues::issues($db, $job['slot_key'], $uid, $item['data'], $slot));
            }
            $this->store->db->prepare('UPDATE schema_scan_jobs SET cursor=?,inspected=inspected+?,issues=issues+?,status=? WHERE slot_key=? AND revision=?')->execute([$batch['cursor'], count($batch['items']), $issues, $batch['done'] ? 'complete' : 'pending', $job['slot_key'], $job['revision']]);
            return ['processed' => count($batch['items'])];
        }
        return $this->indexWork($head, min(128, max(1, $limit)));
    }

    public function approveIndex(string $slot, string $field, string $actor): string
    {
        SchemaProvider::assertWritable($slot);
        $head = $this->store->active();
        $definition = $head['schema']['slots'][$slot] ?? null;
        $config = array_column(SchemaDefinition::fields($definition ?? []), null, 'id')[$field] ?? null;
        if (!$config || !in_array($definition['type'], ['collection', 'massive'], true) || !empty($config['localized'])
            || !in_array($config['type'], ['text', 'number', 'date', 'time', 'datetime', 'boolean'], true) || !empty($definition['massive']['encrypted'])) {
            throw new \InvalidArgumentException('This scalar projection is not supported.', 422);
        }
        if ($definition['type'] === 'massive' && !MassiveDatabase::encryptionCapabilities($slot)['contentQueries']) {
            throw new \InvalidArgumentException('Scalar indexes are unavailable for mixed/encrypted storage.', 422);
        }
        $id = bin2hex(random_bytes(16));
        $this->store->db->prepare("INSERT INTO schema_index_jobs(id,slot_key,field_id,revision,status,approved_by) VALUES(?,?,?,?,'pending',?)")->execute([$id, $slot, $field, $head['revision'], $actor]);
        $this->store->audit($actor, 'index.approved', ['id' => $id, 'slot' => $slot, 'field' => $field]);
        return $id;
    }

    private function indexWork(array $head, int $limit): array
    {
        $job = $this->store->db->query("SELECT * FROM schema_index_jobs WHERE status='pending' LIMIT 1")->fetch();
        if (!$job) {
            return ['processed' => 0];
        }
        if (!SchemaProvider::exclusiveLease($job['slot_key'])) {
            return ['processed' => 0];
        }
        try {
            $head = $this->store->active();
            $slot = $head['schema']['slots'][$job['slot_key']] ?? null;
            if (!$slot || (int) $job['revision'] !== $head['revision']
                || ($slot['type'] === 'massive' && (!empty($slot['massive']['encrypted']) || !MassiveDatabase::encryptionCapabilities($job['slot_key'])['contentQueries']))) {
                $this->store->db->prepare("UPDATE schema_index_jobs SET status='stale' WHERE id=?")->execute([$job['id']]);
                return ['processed' => 0];
            }
            $batch = $this->records($job['slot_key'], $slot, (int) $job['cursor'], $limit);
            $this->store->transaction(function () use ($job, $batch): void {
                $state = $this->store->db->prepare('SELECT status FROM schema_index_jobs WHERE id=?');
                $state->execute([$job['id']]);
                if ($state->fetchColumn() !== 'pending') {
                    return;
                }
                $insert = $this->store->db->prepare('INSERT INTO schema_index_values VALUES(?,?,?,?) ON CONFLICT(job_id,item_id) DO UPDATE SET text_value=excluded.text_value,number_value=excluded.number_value');
                foreach ($batch['items'] as $item) {
                    $value = $item['data'][$job['field_id']] ?? null;
                    if (is_scalar($value)) {
                        $insert->execute([$job['id'], (string) $item['id'], is_string($value) ? $value : null, is_numeric($value) || is_bool($value) ? (float) $value : null]);
                    }
                }
                $this->store->db->prepare('UPDATE schema_index_jobs SET cursor=?,status=? WHERE id=?')->execute([$batch['cursor'], $batch['done'] ? 'ready' : 'pending', $job['id']]);
            });
            return ['processed' => count($batch['items'])];
        } finally {
            SchemaProvider::release();
        }
    }

    /**
     * Samples native rows with bounded indexed probes; JSON lists use a reservoir.
     * Stratifying the ID range spreads probes beyond the oldest records. Exact
     * probes avoid gap bias when IDs are dense; sparse ranges fall back to seeks.
     * Sparse-ID sampling is approximate, not a uniform sample of surviving rows.
     * Native work is O(log N) for the fixed 32-row budget, with at most eight
     * exact probes per range and bounded payload memory. JSON takes O(N) time.
     */
    private function sampleRecords(string $key, array $slot, int $limit): array
    {
        $db = $slot['type'] === 'massive' ? $this->massiveDb() : $this->contentDb();
        if ($slot['type'] === 'collection' && $this->tableExists($db, 'collection_items')) {
            $rows = $this->sampleRows($db, 'collection_items', 'row_id', 'row_id,item_uid,data', $key, $limit);
            $hasBlocks = $this->tableExists($db, 'collection_blocks');
            return array_map(fn (array $row): array => $this->collectionRecord($db, $row, $hasBlocks), $rows);
        }
        if ($slot['type'] === 'massive') {
            $table = 'massive_' . preg_replace('/[^a-zA-Z0-9_]/', '_', $key);
            if (!$this->tableExists($db, $table)) {
                return [];
            }
            $rows = $this->sampleRows($db, $table, 'id', 'id,data', null, $limit);
            return array_map(static fn (array $row): array => [
                'id' => $row['id'],
                'data' => MassiveEncryption::isEncrypted($row['data'])
                    ? MassiveEncryption::decryptData($row['data'])
                    : json_decode($row['data'], true, 512, JSON_THROW_ON_ERROR),
            ], $rows);
        }
        if ($slot['type'] === 'object' || !$this->tableExists($db, 'slots')) {
            return $this->records($key, $slot, 0, $limit)['items'];
        }

        // Reservoir sampling keeps only the chosen payloads and gives each list
        // position an equal inclusion probability without sorting all elements.
        $query = $db->prepare('SELECT j.key,j.value,j.type FROM slots s,json_each(s.data) j WHERE s.key=?');
        $query->execute([$key]);
        $items = [];
        $seen = 0;
        foreach ($query as $row) {
            if ($row['type'] !== 'object') {
                throw new \RuntimeException('List items must be objects.');
            }
            $position = $seen < $limit ? $seen : random_int(0, $seen);
            $seen++;
            if ($position < $limit) {
                $item = json_decode($row['value'], true, 512, JSON_THROW_ON_ERROR);
                $items[$position] = ['id' => $item['_dndId'] ?? $row['key'], 'data' => $item];
            }
        }
        return $items;
    }

    /**
     * Table, ID and column expressions are internal constants or sanitized names.
     * No COUNT, OFFSET or random table sort is needed, even with deleted IDs.
     */
    private function sampleRows(PDO $db, string $table, string $id, string $columns, ?string $key, int $limit): array
    {
        // Keep bounds and random probes on one snapshot during concurrent edits.
        // An existing caller transaction remains under the caller's control.
        $ownsTransaction = !$db->inTransaction();
        if ($ownsTransaction) {
            $db->beginTransaction();
        }
        try {
            return $this->readSampleRows($db, $table, $id, $columns, $key, $limit);
        } finally {
            if ($ownsTransaction) {
                $db->rollBack();
            }
        }
    }

    private function readSampleRows(PDO $db, string $table, string $id, string $columns, ?string $key, int $limit): array
    {
        $filter = $key === null ? '' : 'slot_key=? AND ';
        $params = $key === null ? [] : [$key];
        $query = $db->prepare("SELECT $columns FROM $table WHERE {$filter}$id>0 ORDER BY $id LIMIT ?");
        $query->execute([...$params, $limit + 1]);
        $first = $query->fetchAll(PDO::FETCH_ASSOC);
        if (count($first) <= $limit) {
            return $first;
        }
        $minimum = (int) $first[0][$id];
        unset($first);
        $query = $db->prepare("SELECT $id FROM $table WHERE {$filter}$id>0 ORDER BY $id DESC LIMIT 1");
        $query->execute($params);
        $maximum = (int) $query->fetchColumn();
        $span = $maximum - $minimum + 1;
        $width = intdiv($span, $limit);
        $remainder = $span % $limit;
        $exact = $db->prepare("SELECT $columns FROM $table WHERE {$filter}$id=?");
        $forward = $db->prepare("SELECT $columns FROM $table WHERE {$filter}$id BETWEEN ? AND ? AND $id>=? ORDER BY $id LIMIT 1");
        $backward = $db->prepare("SELECT $columns FROM $table WHERE {$filter}$id BETWEEN ? AND ? AND $id<=? ORDER BY $id DESC LIMIT 1");
        $selected = [];
        $lower = $minimum;
        for ($range = 0; $range < $limit; $range++) {
            $upper = $lower + ($width - 1 + ($range < $remainder ? 1 : 0));
            $row = false;
            for ($attempt = 0; $attempt < 8; $attempt++) {
                $pivot = random_int($lower, $upper);
                $exact->execute([...$params, $pivot]);
                $row = $exact->fetch(PDO::FETCH_ASSOC);
                if ($row !== false) {
                    break;
                }
            }
            if ($row === false) {
                $directions = random_int(0, 1) === 0 ? [$forward, $backward] : [$backward, $forward];
                foreach ($directions as $seek) {
                    $seek->execute([...$params, $lower, $upper, $pivot]);
                    $row = $seek->fetch(PDO::FETCH_ASSOC);
                    if ($row !== false) {
                        break;
                    }
                }
            }
            if ($row !== false) {
                $selected[(int) $row[$id]] = $row;
            }
            if ($range + 1 < $limit) {
                $lower = $upper + 1;
            }
        }

        // Empty ID strata can occur after deletes or when other collections
        // interleave. Fill from new random pivots, skipping at most limit IDs.
        while (count($selected) < $limit) {
            $excluded = array_keys($selected);
            $placeholders = implode(',', array_fill(0, count($excluded), '?'));
            $exclusion = $excluded === [] ? '' : "AND $id NOT IN ($placeholders)";
            $pivot = random_int($minimum, $maximum);
            $directions = random_int(0, 1) === 0 ? ['ASC', 'DESC'] : ['DESC', 'ASC'];
            $row = false;
            foreach ($directions as $direction) {
                $comparison = $direction === 'ASC' ? '>=' : '<=';
                $seek = $db->prepare("SELECT $columns FROM $table WHERE {$filter}$id $comparison ? $exclusion ORDER BY $id $direction LIMIT 1");
                $seek->execute([...$params, $pivot, ...$excluded]);
                $row = $seek->fetch(PDO::FETCH_ASSOC);
                if ($row !== false) {
                    break;
                }
            }
            if ($row === false) {
                break;
            }
            $selected[(int) $row[$id]] = $row;
        }
        return array_values($selected);
    }

    private function collectionRecord(PDO $db, array $row, bool $hasBlocks): array
    {
        $item = json_decode($row['data'], true, 512, JSON_THROW_ON_ERROR);
        if ($hasBlocks) {
            $blocks = $db->prepare('SELECT field_id,locale,data FROM collection_blocks WHERE item_row_id=?');
            $blocks->execute([$row['row_id']]);
            foreach ($blocks as $block) {
                $value = json_decode($block['data'], true, 512, JSON_THROW_ON_ERROR);
                if ($block['locale'] === '') {
                    $item[$block['field_id']] = $value;
                } else {
                    $item[$block['field_id']][$block['locale']] = $value;
                }
            }
        }
        return ['id' => $row['item_uid'], 'data' => $item];
    }

    private function records(string $key, array $slot, int $cursor, int $limit): array
    {
        $db = $slot['type'] === 'massive' ? $this->massiveDb() : $this->contentDb();
        $items = [];
        if ($slot['type'] === 'collection' && $this->tableExists($db, 'collection_items')) {
            $query = $db->prepare('SELECT row_id,item_uid,data FROM collection_items WHERE slot_key=? AND row_id>? ORDER BY row_id LIMIT ?');
            $query->execute([$key, $cursor, $limit]);
            $hasBlocks = $this->tableExists($db, 'collection_blocks');
            foreach ($query as $row) {
                $items[] = $this->collectionRecord($db, $row, $hasBlocks);
                $cursor = (int) $row['row_id'];
            }
        } elseif ($slot['type'] === 'massive') {
            $table = 'massive_' . preg_replace('/[^a-zA-Z0-9_]/', '_', $key);
            if ($this->tableExists($db, $table)) {
                $query = $db->prepare("SELECT id,data FROM $table WHERE id>? ORDER BY id LIMIT ?");
                $query->execute([$cursor, $limit]);
                foreach ($query as $row) {
                    $item = MassiveEncryption::isEncrypted($row['data']) ? MassiveEncryption::decryptData($row['data']) : json_decode($row['data'], true, 512, JSON_THROW_ON_ERROR);
                    $items[] = ['id' => $row['id'], 'data' => $item];
                    $cursor = (int) $row['id'];
                }
            }
        } elseif ($this->tableExists($db, 'slots')) {
            // SQLite JSON iteration pages monolithic lists without decoding the whole slot in PHP.
            $query = $db->prepare($slot['type'] === 'object' ? 'SELECT data FROM slots WHERE key=?' : 'SELECT 1 FROM slots WHERE key=?');
            $query->execute([$key]);
            $json = $query->fetchColumn();
            if ($json === false) {
                return compact('items', 'cursor') + ['done' => true];
            }
            if ($slot['type'] === 'object') {
                if ($cursor === 0) {
                    $items[] = ['id' => '__self__', 'data' => json_decode($json, true, 512, JSON_THROW_ON_ERROR)];
                }
                return ['items' => $items, 'cursor' => 1, 'done' => true];
            }
            unset($json);
            $query = $db->prepare("SELECT CAST(j.key AS INTEGER) AS position,j.value,j.type FROM slots s,json_each(s.data) j WHERE s.key=? AND CAST(j.key AS INTEGER)>=? ORDER BY CAST(j.key AS INTEGER) LIMIT ?");
            $query->execute([$key, $cursor, $limit]);
            $read = 0;
            foreach ($query as $row) {
                $read++;
                $cursor = (int) $row['position'] + 1;
                if ($row['type'] === 'object') {
                    $item = json_decode($row['value'], true, 512, JSON_THROW_ON_ERROR);
                    $items[] = ['id' => $item['_dndId'] ?? $row['position'], 'data' => $item];
                } else {
                    throw new \RuntimeException('List items must be objects.');
                }
            }
            return compact('items', 'cursor') + ['done' => $read < $limit];
        }
        return compact('items', 'cursor') + ['done' => count($items) < $limit];
    }

    private function contentDb(): PDO
    {
        return $this->content ?? \NomadCMS\Database\ContentDatabase::getInstance();
    }

    private function massiveDb(): PDO
    {
        return $this->massive ?? MassiveDatabase::getInstance();
    }

    private function tableExists(PDO $db, string $table): bool
    {
        $query = $db->prepare("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?");
        $query->execute([$table]);
        return $query->fetchColumn() !== false;
    }

    private function update(string $id, string $status, array $columns = []): void
    {
        $columns = ['status' => $status, 'updated_at' => gmdate('c')] + $columns;
        $allowed = ['status', 'updated_at', 'report_json', 'approval_json', 'journal_json'];
        if (array_diff(array_keys($columns), $allowed)) {
            throw new \LogicException('Invalid draft update.');
        }
        $this->store->db->prepare('UPDATE schema_drafts SET ' . implode(',', array_map(static fn ($key) => "$key=?", array_keys($columns))) . ' WHERE id=?')->execute([...array_values($columns), $id]);
    }
}
