<?php
/**
 * NOMAD CMS — Active schema boundary and migration access gates.
 * Uses the signed registry after explicit initialization and a read-only baseline before it.
 * Shared slot leases drain in-flight operations before an exclusive cutover.
 * One persistent coordination inode bounds runtime files independently of slot count.
 */

declare(strict_types=1);

namespace NomadCMS\Services\Schema;

use PDO;

final class SchemaProvider
{
    private static ?array $active = null;
    private static ?SchemaStore $store = null;
    private static array $leases = [];

    public static function store(): SchemaStore
    {
        return self::$store ??= new SchemaStore();
    }

    public static function initialized(): bool
    {
        if (!is_file(SchemaStore::path())) {
            return false;
        }
        self::$active ??= self::store()->active();
        return self::$active !== null;
    }

    public static function baseline(): array
    {
        $path = $_ENV['NOMAD_SCHEMA_BASELINE'] ?? dirname(__DIR__, 3) . '/data/nomad.schema.json';
        $schema = is_file($path) ? json_decode(file_get_contents($path), true, 512, JSON_THROW_ON_ERROR) : ['version' => '1.0.0', 'slots' => []];
        $dbPath = $_ENV['NOMAD_SCHEMA_CONTENT_PATH'] ?? dirname(__DIR__, 3) . '/databases/' . ($_ENV['DB_CONTENT_DATABASE'] ?? 'database.sqlite');
        if (is_file($dbPath)) {
            $db = isset($_ENV['NOMAD_SCHEMA_CONTENT_PATH'])
                ? new PDO('sqlite:file:' . $dbPath . '?mode=ro')
                : \NomadCMS\Database\ContentDatabase::getInstance(false);
            if ($db->query("SELECT 1 FROM sqlite_master WHERE name='collection_slots'")->fetchColumn()) {
                foreach ($db->query('SELECT slot_key,schema_json FROM collection_slots') as $row) {
                    $schema['slots'][$row['slot_key']] = json_decode($row['schema_json'], true, 512, JSON_THROW_ON_ERROR);
                }
            }
        }
        return $schema;
    }

    public static function schema(): array
    {
        if (self::$active === null) {
            self::$active = is_file(SchemaStore::path()) ? self::store()->active() : null;
            if (self::$active === null) {
                return self::baseline();
            }
        }
        return self::$active['schema'] + ['_revision' => self::$active['revision'], '_schemaHash' => self::$active['schema_hash']];
    }

    public static function clear(): void
    {
        self::$active = null;
    }

    /** Release registry connections and cached authority before a full backup restore. */
    public static function resetStore(): void
    {
        self::release();
        self::$active = null;
        self::$store = null;
    }

    public static function slot(string $key): ?array
    {
        return self::schema()['slots'][$key] ?? null;
    }

    public static function lease(string $key): void
    {
        if (!is_file(SchemaStore::path())) {
            return;
        }
        $store = self::store();
        $gate = $store->db->prepare('SELECT draft_id FROM schema_gates WHERE slot_key=?');
        $gate->execute([$key]);
        if ($gate->fetchColumn() !== false) {
            throw new \RuntimeException('SCHEMA_MIGRATION_LOCKED', 503);
        }
        if (!isset(self::$leases['registry'])) {
            $handle = fopen(self::lockPath(), 'c');
            if (!$handle || !flock($handle, LOCK_SH | LOCK_NB)) {
                if (is_resource($handle)) {
                    fclose($handle);
                }
                throw new \RuntimeException('SCHEMA_MIGRATION_LOCKED', 503);
            }
            self::$leases['registry'] = $handle;
        }
        $gate->execute([$key]);
        if ($gate->fetchColumn() !== false) {
            throw new \RuntimeException('SCHEMA_MIGRATION_LOCKED', 503);
        }
        $head = $store->db->query('SELECT revision FROM schema_head WHERE id=1')->fetchColumn();
        if ($head !== false && (self::$active['revision'] ?? null) !== (int) $head) {
            self::clear();
        }
    }

    public static function lockPath(): string
    {
        return SchemaStore::path() . '.coordination.lock';
    }

    /** A bounded index batch must not race native writers holding shared leases. */
    public static function exclusiveLease(string $key): bool
    {
        self::lease($key);
        if (flock(self::$leases['registry'], LOCK_EX | LOCK_NB)) {
            return true;
        }
        self::release();
        return false;
    }

    /** Remove obsolete per-slot files only when their legacy holders have released them. */
    public static function cleanupLegacyLocks(): int
    {
        $coordinator = fopen(self::lockPath(), 'c');
        if (!$coordinator || !flock($coordinator, LOCK_EX | LOCK_NB)) {
            if (is_resource($coordinator)) {
                fclose($coordinator);
            }
            return 0;
        }
        $removed = 0;
        try {
            $files = glob(SchemaStore::path() . '.slot-*.lock') ?: [];
            $files[] = SchemaStore::path() . '.engine.lock';
            foreach ($files as $file) {
                if (!is_file($file)) {
                    continue;
                }
                $handle = fopen($file, 'r+');
                if (!$handle) {
                    continue;
                }
                try {
                    if (flock($handle, LOCK_EX | LOCK_NB) && unlink($file)) {
                        $removed++;
                    }
                } finally {
                    flock($handle, LOCK_UN);
                    fclose($handle);
                }
            }
        } finally {
            flock($coordinator, LOCK_UN);
            fclose($coordinator);
        }
        // Never unlink the shared coordinator: replacing its inode would split active locks.
        return $removed;
    }

    public static function release(): void
    {
        foreach (self::$leases as $handle) {
            flock($handle, LOCK_UN);
            fclose($handle);
        }
        self::$leases = [];
    }

    public static function assertClientRevision(): void
    {
        if (!self::initialized() || PHP_SAPI === 'cli') {
            return;
        }
        $expected = $_SERVER['HTTP_X_SCHEMA_REVISION'] ?? null;
        if ($expected === null || (string) $expected !== (string) self::schema()['_revision']) {
            throw new \RuntimeException('SCHEMA_REVISION_CONFLICT', 409);
        }
    }

    public static function validateWrite(string $key, array $item, ?array $old = null, bool $preserveOmitted = true, ?string $uid = null): array
    {
        self::assertWritable($key);
        if (!self::initialized()) {
            $slot = self::slot($key);
            if ($slot) {
                $temporalSlot = ['fields' => array_values(array_filter(SchemaDefinition::fields($slot), TemporalField::isTemporal(...)))];
                $issues = SchemaDefinition::issues($item, $temporalSlot, $old);
                if ($issues !== []) {
                    throw new \InvalidArgumentException('SCHEMA_VALIDATION_FAILED: ' . json_encode($issues, JSON_THROW_ON_ERROR), 422);
                }
            }
            return $item;
        }
        $slot = self::slot($key);
        if (!$slot) {
            throw new \RuntimeException('SCHEMA_SLOT_ARCHIVED', 410);
        }
        if ($old !== null && $preserveOmitted) {
            // PUT-style callers may omit archived/unknown fields. Preserve them.
            $item += $old;
        }
        if ($old !== null) {
            foreach (self::archivedFields($key) as $id) {
                if (array_key_exists($id, $old)) {
                    $item[$id] = $old[$id];
                }
            }
        }
        $db = ($slot['type'] ?? '') === 'massive'
            ? \NomadCMS\Database\MassiveDatabase::getInstance()
            : \NomadCMS\Database\ContentDatabase::getInstance();
        [$item, $comparison, $validationSlot] = SchemaValues::prepareWrite($db, $key, $item, $old, $slot, $uid);
        $issues = SchemaDefinition::issues($item, $validationSlot, $comparison);
        if ($issues !== []) {
            throw new \InvalidArgumentException('SCHEMA_VALIDATION_FAILED: ' . json_encode($issues, JSON_THROW_ON_ERROR), 422);
        }
        return $item;
    }

    /** Guard every mutation, including deletes and empty replacements. */
    public static function assertWritable(string $key): void
    {
        self::lease($key);
        if (self::initialized() && self::slot($key) === null) {
            throw new \RuntimeException('SCHEMA_SLOT_ARCHIVED', 410);
        }
    }

    /** Invalidate before native writes; failed writes conservatively leave indexes stale. */
    public static function invalidateIndexes(string $key): void
    {
        if (self::initialized()) {
            self::store()->db->prepare("UPDATE schema_index_jobs SET status='stale' WHERE slot_key=? AND status IN ('pending','ready')")->execute([$key]);
        }
    }

    public static function archivedFields(string $key): array
    {
        if (!self::initialized()) {
            return [];
        }
        $query = self::store()->db->prepare("SELECT field_id FROM schema_archives WHERE slot_key=? AND field_id<>''");
        $query->execute([$key]);
        return $query->fetchAll(PDO::FETCH_COLUMN);
    }
}
