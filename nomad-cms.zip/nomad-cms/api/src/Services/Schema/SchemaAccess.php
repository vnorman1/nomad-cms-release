<?php
/**
 * NOMAD CMS — Protected schema authority.
 * Resolves live role grants and confines delegation to super administrators.
 * General wildcards and API keys cannot acquire schema authority implicitly.
 */

declare(strict_types=1);

namespace NomadCMS\Services\Schema;

use NomadCMS\Database\AuthDatabase;
use NomadCMS\Database\RoleRepository;
use NomadCMS\Middleware\AuthMiddleware;

final class SchemaAccess
{
    public const PERMISSION = 'schema:manage:*';

    public static function isSuperAdmin(object|array|null $user): bool
    {
        $value = (array) $user;
        return ($value['source'] ?? '') !== 'api_key'
            && (($value['role_slug'] ?? '') === 'super_admin'
                || (empty($value['role_slug']) && !empty($value['is_admin'])));
    }

    public static function allowed(object|array|null $user): bool
    {
        if (!$user || (($user->source ?? ((array) $user)['source'] ?? '') === 'api_key')) {
            return false;
        }
        if (self::isSuperAdmin($user)) {
            return true;
        }
        $role = RoleRepository::findBySlug((string) (((array) $user)['role_slug'] ?? ''));
        return in_array(self::PERMISSION, $role['permissions'] ?? [], true);
    }

    public static function requireManager(): object
    {
        $user = AuthMiddleware::requireAuth();
        $fresh = self::freshUser($user);
        if (!$fresh || !self::allowed($fresh)) {
            throw new \RuntimeException('SCHEMA_PERMISSION_REQUIRED', 403);
        }
        return $user;
    }

    public static function requireDelegator(): void
    {
        $user = AuthMiddleware::getCurrentUser();
        if (!$user || !self::isSuperAdmin(self::freshUser($user))) {
            throw new \RuntimeException('Only super_admin may delegate schema authority.', 403);
        }
    }

    public static function protectPermissions(array $before, array $after): void
    {
        if (in_array(self::PERMISSION, $before, true) !== in_array(self::PERMISSION, $after, true)) {
            self::requireDelegator();
        }
    }

    public static function protectAssignment(?array $before, ?array $after): void
    {
        $protected = static fn (?array $role): bool => ($role['slug'] ?? '') === 'super_admin'
            || in_array(self::PERMISSION, $role['permissions'] ?? [], true);
        if (($before['slug'] ?? null) !== ($after['slug'] ?? null) && ($protected($before) || $protected($after))) {
            self::requireDelegator();
        }
    }

    public static function auditDelegation(string $action, array $details): void
    {
        $user = AuthMiddleware::getCurrentUser();
        (new SchemaStore())->audit((string) ($user->uuid ?? 'system'), $action, $details);
    }

    private static function freshUser(object|array $user): ?array
    {
        $value = (array) $user;
        if (($value['source'] ?? '') === 'api_key' || empty($value['uuid'])) {
            return null;
        }
        $query = AuthDatabase::getInstance()->prepare('SELECT * FROM users WHERE uuid=?');
        $query->execute([$value['uuid']]);
        $fresh = $query->fetch();
        if (!$fresh || !empty($fresh['is_new_user']) || (!empty($fresh['locked_until']) && strtotime($fresh['locked_until']) > time())) {
            return null;
        }
        return $fresh;
    }

    public static function approvalStillValid(string $uuid): bool
    {
        $query = AuthDatabase::getInstance()->prepare('SELECT * FROM users WHERE uuid = ?');
        $query->execute([$uuid]);
        $user = $query->fetch();
        return $user && empty($user['is_new_user'])
            && (empty($user['locked_until']) || strtotime($user['locked_until']) < time())
            && self::allowed($user);
    }
}
