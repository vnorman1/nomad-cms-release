<?php
/**
 * NOMAD CMS — Date and Time field contracts.
 * Validates local calendar/clock precision without timezone conversion or value
 * coercion. Legacy datetime definitions are projected as Date; data stays intact.
 */

declare(strict_types=1);

namespace NomadCMS\Services\Schema;

/** Shared temporal schema and value validation for content and Editorials. */
final class TemporalField
{
    public static function normalize(array $field): array
    {
        if (($field['type'] ?? '') === 'datetime') {
            $field['type'] = 'date';
        }
        if (isset($field['blockRecommendations']) && is_array($field['blockRecommendations'])) {
            $field['blockRecommendations'] = array_map(self::normalize(...), $field['blockRecommendations']);
        }
        return $field;
    }

    public static function isTemporal(array $field): bool
    {
        return in_array($field['type'] ?? '', ['date', 'time', 'datetime'], true);
    }

    public static function granularity(array $field): string
    {
        return $field['granularity'] ?? (($field['type'] ?? '') === 'time' ? 'minute' : 'day');
    }

    public static function validConfig(array $field): bool
    {
        if (!self::isTemporal($field)) {
            return true;
        }
        $own = ($field['type'] ?? '') === 'time' ? ['hour', 'minute', 'second'] : ['year', 'month', 'day'];
        $extra = ($field['type'] ?? '') === 'time' ? ['year', 'month', 'day'] : ['hour', 'minute', 'second'];
        return (!array_key_exists('granularity', $field) || in_array($field['granularity'], $own, true))
            && (!array_key_exists('extraGranularity', $field) || in_array($field['extraGranularity'], $extra, true));
    }

    public static function validValue(mixed $value, array $field): bool
    {
        if (!is_string($value) || !self::validConfig($field)) {
            return false;
        }
        $precision = self::granularity($field);
        if (isset($field['extraGranularity'])) {
            $parts = explode('T', $value);
            $isTime = ($field['type'] ?? '') === 'time';
            return count($parts) === 2
                && self::validValue($parts[0], ['type' => 'date', 'granularity' => $isTime ? $field['extraGranularity'] : $precision])
                && self::validValue($parts[1], ['type' => 'time', 'granularity' => $isTime ? $precision : $field['extraGranularity']]);
        }
        $patterns = [
            'year' => '/^(\d{4})$/D',
            'month' => '/^(\d{4})-(\d{2})$/D',
            'day' => '/^(\d{4})-(\d{2})-(\d{2})$/D',
            'hour' => '/^(\d{2})$/D',
            'minute' => '/^(\d{2}):(\d{2})$/D',
            'second' => '/^(\d{2}):(\d{2}):(\d{2})$/D',
        ];
        if (!preg_match($patterns[$precision], $value, $parts)) {
            return false;
        }
        if (($field['type'] ?? '') === 'time') {
            return (int) $parts[1] <= 23
                && (!isset($parts[2]) || (int) $parts[2] <= 59)
                && (!isset($parts[3]) || (int) $parts[3] <= 59);
        }
        $year = (int) $parts[1];
        $month = isset($parts[2]) ? (int) $parts[2] : 1;
        $day = isset($parts[3]) ? (int) $parts[3] : 1;
        return $year >= 1 && $year <= 9999 && checkdate($month, $day, $year);
    }

    public static function isLastmod(array $field): bool
    {
        return self::isTemporal($field) && (($field['type'] ?? '') === 'time'
            ? ($field['extraGranularity'] ?? null) === 'day' : self::granularity($field) === 'day');
    }
}
