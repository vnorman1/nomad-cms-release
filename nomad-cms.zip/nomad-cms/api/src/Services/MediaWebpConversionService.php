<?php
/**
 * NOMAD CMS — Creative Studio WebP upload validation.
 * Validates encoded WebP copies without GD decoding, resizing or recompression.
 * Keeps memory bounded and ensures file content agrees with its WebP extension.
 */
declare(strict_types=1);

namespace NomadCMS\Services;

use InvalidArgumentException;
use NomadCMS\Database\ContentDatabase;
use RuntimeException;

/**
 * Validates explicit Studio exports before the standard authenticated upload flow stores them.
 * Ownership, CSRF, rate limiting and unique filenames remain the upload controller's responsibility.
 */
final class MediaWebpConversionService
{
    /** Validate real WebP content and upload limits without allocating a decoded pixel buffer. */
    public static function validate(string $path): void
    {
        $size = is_file($path) ? filesize($path) : false;
        if ($size === false || $size < 12 || $size > 25 * 1024 * 1024) {
            throw new InvalidArgumentException('WebP export must be between 12 bytes and 25 MB.');
        }

        $header = file_get_contents($path, false, null, 0, 12);
        if ($header === false || substr($header, 0, 4) !== 'RIFF' || substr($header, 8, 4) !== 'WEBP'
            || unpack('Vsize', substr($header, 4, 4))['size'] !== $size - 8) {
            throw new InvalidArgumentException('The export has an invalid WebP container.');
        }

        $mime = (new \finfo(FILEINFO_MIME_TYPE))->file($path);
        $info = @getimagesize($path);
        if ($mime !== 'image/webp' || $info === false || ($info[2] ?? null) !== IMAGETYPE_WEBP) {
            throw new InvalidArgumentException('The export is not a valid WebP image.');
        }
        if ($info[0] <= 0 || $info[1] <= 0) {
            throw new InvalidArgumentException('The WebP image has invalid dimensions.');
        }
    }

    /** Replace a local source with the validated WebP bytes and atomically move its metadata identity. */
    public static function replace(string $filename, string $encodedPath, string $uploadDir, string $actor = 'system', ?string $massivePath = null): string
    {
        self::validate($encodedPath);
        if ($filename !== basename($filename) || str_contains($filename, '..')) {
            throw new InvalidArgumentException('Invalid local media filename.');
        }
        $target = pathinfo($filename, PATHINFO_FILENAME) . '.webp';
        if ($target === $filename) {
            throw new InvalidArgumentException('This image is already WebP.');
        }
        $uploadDir = rtrim($uploadDir, '/') . '/';
        $sourcePath = $uploadDir . $filename;
        $targetPath = $uploadDir . $target;
        $stage = $uploadDir . '.studio-webp-' . bin2hex(random_bytes(8));
        $backup = $uploadDir . '.studio-original-' . bin2hex(random_bytes(8));
        $lock = fopen($uploadDir . '.studio-webp.lock', 'c');
        if ($lock === false || !flock($lock, LOCK_EX)) {
            throw new RuntimeException('Could not lock WebP conversion.');
        }
        $db = ContentDatabase::getInstance();
        if ($db->inTransaction()) {
            flock($lock, LOCK_UN);
            fclose($lock);
            throw new RuntimeException('WebP conversion must own its transaction.');
        }
        $installed = false;
        $committed = false;
        $massiveAttached = false;
        try {
            if (!is_file($sourcePath) || is_link($sourcePath)) {
                throw new RuntimeException('The original image is unavailable.');
            }
            if (file_exists($targetPath) || is_link($targetPath) || ContentDatabase::mediaMetaExists($target)) {
                throw new InvalidArgumentException('A file with this WebP filename already exists.');
            }
            MediaAliasService::ensureSchema($db);
            if (!copy($encodedPath, $stage) || !chmod($stage, 0644)) {
                throw new RuntimeException('Could not stage the WebP image.');
            }
            $massiveAttached = MediaReferenceMigrationService::attachMassive($db, $massivePath);
            $db->beginTransaction();
            $metadata = ContentDatabase::getMediaMeta($filename);
            $dimensions = getimagesize($stage);
            if (!rename($stage, $targetPath)) {
                throw new RuntimeException('Could not install the WebP image.');
            }
            $installed = true;
            if (!ContentDatabase::saveMediaMeta(
                filename: $target,
                altTexts: $metadata['alt'] ?? [],
                title: $metadata['title'] ?? null,
                caption: $metadata['caption'] ?? null,
                tags: $metadata['tags'] ?? null,
                isExternal: 0,
                mediaType: 'image',
                dimensions: ['width' => $dimensions[0], 'height' => $dimensions[1]],
                mimeType: 'image/webp',
                uploadedBy: $metadata['uploaded_by'] ?? null
            )) {
                throw new RuntimeException('Could not migrate the media metadata.');
            }
            // Metadata identity moves; the media itself stays available to SEO, Hub and CMS references via the alias.
            $db->prepare('DELETE FROM media_meta WHERE filename=?')->execute([$filename]);
            MediaAliasService::register($filename, $target, $db);
            $changedSlots = MediaReferenceMigrationService::migrate($db, $filename, $target, $actor, $massiveAttached);
            if (!rename($sourcePath, $backup)) {
                throw new RuntimeException('Could not replace the original image.');
            }
            $db->commit();
            $committed = true;
            @unlink($backup);
            clearstatcache();
            // Publish filesystem side effects only after both databases have committed.
            foreach ($changedSlots as $key) {
                try {
                    StaticCacheService::invalidateSlot($key);
                } catch (\Throwable $error) {
                    error_log('[Media conversion] Cache invalidation failed for ' . $key . ': ' . $error->getMessage());
                }
            }
            \NomadCMS\Services\Seo\SeoModule::afterCommit($db);
            return $target;
        } finally {
            if (!$committed) {
                if ($db->inTransaction()) {
                    $db->rollBack();
                }
                if (is_file($backup)) {
                    rename($backup, $sourcePath);
                }
                if ($installed) {
                    @unlink($targetPath);
                }
            }
            if (is_file($stage)) {
                @unlink($stage);
            }
            if ($massiveAttached) {
                try {
                    $db->exec('DETACH DATABASE studio_massive');
                } catch (\Throwable $error) {
                    // Cleanup must neither mask the original failure nor report a committed conversion as failed.
                    error_log('[Media conversion] Database detach failed: ' . $error->getMessage());
                }
            }
            flock($lock, LOCK_UN);
            fclose($lock);
        }
    }

}
