<?php
/**
 * NOMAD CMS — shared backup format compatibility policy.
 * Legacy v1 packages remain readable with a warning. Storage epochs and minimum
 * reader versions are checked before any import or live database replacement.
 */
declare(strict_types=1);

namespace NomadCMS\Services;

use NomadCMS\Config\Version;

final class BackupCompatibility
{
    public static function metadata(): array
    {
        return [
            'name' => 'Nomad CMS', 'version' => Version::VERSION, 'build_id' => Version::BUILD_ID,
            'storage_epoch' => Version::STORAGE_EPOCH, 'min_compatible_version' => '1.0.0', 'backup_format' => 1,
        ];
    }

    public static function inspect(mixed $metadata): array
    {
        if ($metadata === null || (is_array($metadata) && !array_key_exists('storage_epoch', $metadata)
            && !array_key_exists('backup_format', $metadata) && !array_key_exists('min_compatible_version', $metadata))) {
            return ['status' => 'yellow', 'compatible' => true, 'message' => 'Legacy backup: compatibility metadata is incomplete.'];
        }
        if (!is_array($metadata) || !is_int($metadata['storage_epoch'] ?? null)
            || !is_int($metadata['backup_format'] ?? null) || $metadata['backup_format'] !== 1
            || !is_string($metadata['min_compatible_version'] ?? null)
            || !preg_match('~^\d+\.\d+\.\d+$~D', $metadata['min_compatible_version'])
            || $metadata['storage_epoch'] !== Version::STORAGE_EPOCH
            || version_compare(Version::VERSION, $metadata['min_compatible_version'], '<')) {
            return ['status' => 'red', 'compatible' => false, 'message' => 'Backup format is incompatible with this CMS. Use a compatible reader or migration tool.'];
        }
        return ['status' => 'green', 'compatible' => true, 'message' => 'Backup format is compatible.'];
    }

    public static function requireCompatible(mixed $metadata): array
    {
        $report = self::inspect($metadata);
        if (!$report['compatible']) {
            throw new \InvalidArgumentException($report['message']);
        }
        return $report;
    }
}
