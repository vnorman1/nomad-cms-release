<?php
/**
 * NOMAD CMS — Schema-directed Forge media traversal.
 * Visits localized image/gif/gallery values and native image/gallery blocks.
 * JSON strings and arbitrary keys are never guessed to be media references.
 * Rewrites leaves while retaining galleries, block identities and metadata.
 */
declare(strict_types=1);

namespace NomadCMS\Services;

final class ForgeMediaWalker
{
    /** @param callable(string):string $rewrite */
    public static function records(array $records, array $fields, callable $rewrite): array
    {
        foreach ($records as &$record) {
            foreach ($fields as $field) {
                $id = $field['id'] ?? '';
                $type = $field['type'] ?? '';
                if (!array_key_exists($id, $record) || !in_array($type, ['image', 'gif', 'gallery', 'blocks'], true)) {
                    continue;
                }
                $value = $record[$id];
                if (!empty($field['localized']) && (is_array($value) || is_object($value))) {
                    foreach ($value as &$locale) {
                        $locale = $type === 'blocks' ? self::blocks($locale, $rewrite) : self::media($locale, $rewrite);
                    }
                    unset($locale);
                } else {
                    $value = $type === 'blocks' ? self::blocks($value, $rewrite) : self::media($value, $rewrite);
                }
                $record[$id] = $value;
            }
        }
        unset($record);
        return $records;
    }

    private static function blocks(mixed $value, callable $rewrite): mixed
    {
        if (!is_array($value)) {
            return $value;
        }
        foreach ($value as &$block) {
            if (is_object($block)) {
                $block = get_object_vars($block);
            }
            if (is_array($block) && in_array($block['type'] ?? '', ['image', 'gif', 'gallery'], true)) {
                $block['data'] = self::media($block['data'] ?? null, $rewrite);
            }
        }
        unset($block);
        return $value;
    }

    private static function media(mixed $value, callable $rewrite): mixed
    {
        if (is_string($value)) {
            return $value === '' || str_starts_with($value, '/api/uploads/') ? $value : $rewrite($value);
        }
        if (is_array($value) && array_is_list($value)) {
            return array_map(static fn ($item) => self::media($item, $rewrite), $value);
        }
        if (is_array($value) || is_object($value)) {
            $object = is_object($value);
            $entry = $object ? get_object_vars($value) : $value;
            foreach (['src', 'url'] as $key) {
                if (isset($entry[$key]) && is_string($entry[$key])) {
                    $entry[$key] = self::media($entry[$key], $rewrite);
                    break;
                }
            }
            return $object ? (object) $entry : $entry;
        }
        return $value;
    }
}
