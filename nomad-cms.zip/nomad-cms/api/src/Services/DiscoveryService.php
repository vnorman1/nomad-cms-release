<?php
/**
 * NOMAD CMS — bounded, resumable public discovery generations.
 * A private SQLite spool deduplicates URLs and checkpoints input/output independently of SEO Studio.
 * Immutable files publish through one atomic manifest; clean reads never open a database.
 * Only 100 input/output rows and one document stream are held at once. No daemon is required.
 */
declare(strict_types=1);

namespace NomadCMS\Services;

use PDO;
use RuntimeException;

final class DiscoveryService
{
    public const MD_BYTES = 65536;
    public const MD_LINKS = 200;
    public const XML_BYTES = 52428800;
    public const XML_URLS = 50000;
    private const XML_HEADER = '<?xml version="1.0" encoding="UTF-8"?>' . "\n"
        . '<?xml-stylesheet type="text/xsl" href="/sitemap.xsl"?>' . "\n"
        . '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" xmlns:xhtml="http://www.w3.org/1999/xhtml">' . "\n";
    private const INDEX_HEADER = '<?xml version="1.0" encoding="UTF-8"?>' . "\n"
        . '<?xml-stylesheet type="text/xsl" href="/sitemap.xsl"?>' . "\n"
        . '<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . "\n";
    private ?PDO $db = null;
    private array $state = [];
    private string $directory = '';
    private mixed $stream = null;
    private array $limits;
    private float $deadline = 0.0;

    /** Loader and reader are lazy so cache hits and contended locks never bootstrap CMS storage. */
    public function __construct(
        private readonly string $cache,
        private readonly ?\Closure $loader = null,
        private readonly ?\Closure $reader = null,
        array $limits = []
    ) {
        $this->limits = $limits + ['mdBytes' => self::MD_BYTES, 'mdLinks' => self::MD_LINKS,
            'xmlBytes' => self::XML_BYTES, 'xmlUrls' => self::XML_URLS];
        if ($this->limits['mdLinks'] < 4 || $this->limits['mdBytes'] < 512
            || $this->limits['xmlUrls'] < 2 || $this->limits['xmlBytes'] < 512) {
            throw new RuntimeException('Discovery limits cannot hold a useful index');
        }
    }

    public static function production(?string $cache = null, ?\Closure $bootstrap = null): self
    {
        $cache ??= SitemapService::getCacheDir();
        return new self($cache, static function () use ($bootstrap): array {
            if ($bootstrap !== null) {
                $bootstrap();
            }
            $schema = \NomadCMS\Services\Schema\SchemaProvider::schema();
            return ['schema' => $schema, 'origin' => self::origin(), 'schemaDate' => gmdate('Y-m-d',
                (int) (@filemtime(dirname(__DIR__, 2) . '/data/nomad.schema.json') ?: time()))];
        }, static function (string $key, array $config, array $cursor): array {
            if (\NomadCMS\Database\CollectionDatabase::isRegistered($key)) {
                return \NomadCMS\Database\CollectionDatabase::discoveryBatch($key, $cursor);
            }
            // Massive storage may contain encrypted/private rows: discovery does not add a new public reader.
            if (($config['type'] ?? '') === 'massive') {
                return ['items' => [], 'done' => true];
            }
            $slot = \NomadCMS\Database\ContentDatabase::getSlot($key);
            $items = [];
            $offset = (int) ($cursor['offset'] ?? 0);
            $values = is_array($slot) ? $slot : [];
            $date = \NomadCMS\Database\ContentDatabase::getInstance(false)->prepare('SELECT updated_at FROM slots WHERE key=?');
            $date->execute([$key]);
            $updated = $date->fetchColumn() ?: null;
            $index = 0;
            foreach ($values as $item) {
                if ($index++ < $offset) {
                    continue;
                }
                if (is_array($item)) {
                    $item['_slotDate'] = $updated;
                    $items[] = ['item' => $item, 'cursor' => ['offset' => $index]];
                }
                if (count($items) === 100) {
                    break;
                }
            }
            return ['items' => $items, 'done' => $index >= count($values)];
        });
    }

    public static function origin(): string
    {
        foreach (['SITE_URL', 'APP_URL'] as $name) {
            $url = trim((string) ($_ENV[$name] ?? ''));
            if ($url !== '') {
                return rtrim($url, '/');
            }
        }
        $authority = strtolower((string) ($_SERVER['HTTP_HOST'] ?? ''));
        $parts = parse_url('http://' . $authority);
        $host = $parts['host'] ?? '';
        if (($host === 'localhost' || $host === '[::1]' || (filter_var($host, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4) !== false && str_starts_with($host, '127.')))
            && $authority === $host . (isset($parts['port']) ? ':' . $parts['port'] : '')) {
            $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || ($_SERVER['SERVER_PORT'] ?? '') === '443';
            return ($https ? 'https://' : 'http://') . $authority;
        }
        return 'https://yourdomain.com';
    }

    public function manifest(): ?array
    {
        $path = $this->cache . '/discovery/active.json';
        if (!is_file($path)) {
            return null;
        }
        $value = json_decode((string) file_get_contents($path), true);
        return is_array($value) ? $value : null;
    }

    private function tokens(): array
    {
        $tokens = [];
        foreach (['sitemap', 'llms'] as $kind) {
            $path = $this->cache . '/' . $kind . '.dirty';
            clearstatcache(true, $path);
            $tokens[$kind] = is_file($path) ? hash('sha256', (string) file_get_contents($path)) : null;
        }
        return $tokens;
    }

    public function dirty(): bool
    {
        $manifest = $this->manifest();
        return $manifest === null || $this->root('md') === null || $this->root('xml') === null
            || array_filter($this->tokens(), static fn ($token) => $token !== null) !== [];
    }

    /** Resolve only published manifest members; never use request input as an unchecked filesystem path. */
    public function file(string $generation, string $relative): ?string
    {
        if (!preg_match('/^[a-f0-9]{24}$/D', $generation)
            || !preg_match('~^(?:md|xml)/[a-zA-Z0-9_/-]+\.(?:md|xml)$~D', $relative)) {
            return null;
        }
        $directory = $this->cache . '/discovery/' . $generation;
        if (!is_file($directory . '/published.json')) {
            return null;
        }
        $member = $directory . '/members/' . hash('sha256', $relative);
        $path = $directory . '/files/' . $relative;
        return is_file($member) && file_get_contents($member) === $relative && is_file($path) ? $path : null;
    }

    public function root(string $kind, ?string $locale = null): ?string
    {
        $manifest = $this->manifest();
        $relative = $manifest['roots'][$kind . ':' . ($locale ?? '')] ?? null;
        return is_string($relative) ? $this->file($manifest['generation'], $relative) : null;
    }

    /** At most one builder advances; each transaction processes no more than 100 records. */
    public function work(float $seconds = 1.0, int $maxBatches = PHP_INT_MAX): array
    {
        self::directory($this->cache . '/discovery');
        $lock = @fopen($this->cache . '/sitemap.lock', 'c+');
        if ($lock === false) {
            throw new RuntimeException('Unable to open discovery lock');
        }
        if (!flock($lock, LOCK_EX | LOCK_NB)) {
            fclose($lock);
            return ['ready' => $this->manifest() !== null, 'busy' => true, 'batches' => 0];
        }
        $deadline = microtime(true) + max(0.001, min(10.0, $seconds));
        $this->deadline = $deadline;
        $batches = 0;
        try {
            $this->cleanup();
            if (!$this->dirty()) {
                return ['ready' => true, 'batches' => 0];
            }
            $this->openBuild();
            do {
                $this->db->beginTransaction();
                try {
                    if ($this->state['phase'] === 'input') {
                        $this->input();
                    } elseif ($this->state['phase'] === 'setup') {
                        $this->setup();
                    } elseif ($this->state['phase'] === 'render') {
                        $this->render();
                    } elseif ($this->state['phase'] === 'members') {
                        $this->members();
                    }
                    $this->save();
                    $this->closeStream();
                    $this->db->commit();
                } catch (\Throwable $error) {
                    $this->closeStream();
                    $this->db->rollBack();
                    throw $error;
                }
                $batches++;
                if ($this->state['phase'] === 'publish') {
                    $this->publish();
                    break;
                }
            } while ($batches < $maxBatches && microtime(true) < $deadline);
            return ['ready' => $this->manifest() !== null, 'batches' => $batches,
                'phase' => $this->state['phase'], 'generation' => $this->state['generation']];
        } catch (\Throwable $error) {
            if ($this->directory !== '') {
                @touch($this->directory . '/failed');
            }
            throw $error;
        } finally {
            $this->closeStream();
            $this->db = null;
            flock($lock, LOCK_UN);
            fclose($lock);
        }
    }

    private function openBuild(): void
    {
        $pointer = $this->cache . '/discovery/build.json';
        $generation = is_file($pointer) ? json_decode((string) file_get_contents($pointer), true)['generation'] ?? '' : '';
        if (!preg_match('/^[a-f0-9]{24}$/D', $generation)) {
            $generation = bin2hex(random_bytes(12));
            self::directory($this->cache . '/discovery/' . $generation);
            self::atomic($pointer, json_encode(['generation' => $generation], JSON_THROW_ON_ERROR));
        }
        $this->directory = $this->cache . '/discovery/' . $generation;
        self::directory($this->directory . '/files');
        self::directory($this->directory . '/members');
        $this->db = new PDO('sqlite:' . $this->directory . '/work.sqlite', null, null, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]);
        $this->db->exec('PRAGMA cache_size=-2048; PRAGMA temp_store=FILE; PRAGMA synchronous=FULL');
        $this->db->exec('CREATE TABLE IF NOT EXISTS state(data TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS entries(id INTEGER PRIMARY KEY,kind TEXT,grp TEXT,locale TEXT,title TEXT,loc TEXT,body TEXT,UNIQUE(kind,loc));
            CREATE INDEX IF NOT EXISTS entries_group ON entries(kind,grp,id);
            CREATE INDEX IF NOT EXISTS entries_locale ON entries(kind,locale,id);
            CREATE TABLE IF NOT EXISTS nodes(id INTEGER PRIMARY KEY,scope TEXT,level INTEGER,rel TEXT,title TEXT);
            CREATE INDEX IF NOT EXISTS nodes_scope ON nodes(scope,level,id);
            CREATE TABLE IF NOT EXISTS jobs(id INTEGER PRIMARY KEY,rank INTEGER,data TEXT,done INTEGER DEFAULT 0);
            CREATE TABLE IF NOT EXISTS files(id INTEGER PRIMARY KEY,rel TEXT UNIQUE);
            CREATE TABLE IF NOT EXISTS roots(name TEXT PRIMARY KEY,rel TEXT);');
        $saved = $this->db->query('SELECT data FROM state')->fetchColumn();
        if ($saved !== false) {
            $this->state = json_decode($saved, true, 512, JSON_THROW_ON_ERROR);
            $this->limits = $this->state['limits'];
            if (is_file($this->directory . '/failed') && $this->tokens() !== $this->state['tokens']) {
                // A corrected source/schema must not remain trapped behind permanently invalid spooled output.
                $this->db = null;
                self::atomic($this->directory . '/retired', (string) time());
                unlink($pointer);
                $this->openBuild();
                return;
            }
            // Load storage only for unfinished input. Rendering uses the private spool exclusively.
            if ($this->state['phase'] === 'input' && $this->loader !== null) {
                ($this->loader)();
            }
            return;
        }
        if ($this->loader === null) {
            throw new RuntimeException('Discovery input loader is required');
        }
        $tokens = $this->tokens();
        $config = ($this->loader)();
        $this->state = ['generation' => $generation, 'phase' => 'input', 'config' => $config,
            'limits' => $this->limits, 'tokens' => $tokens, 'slot' => -1, 'cursor' => [], 'member' => 0];
        $this->save();
    }

    private function save(): void
    {
        $this->db->exec('DELETE FROM state');
        $this->query('INSERT INTO state(data) VALUES (?)', [json_encode($this->state, JSON_THROW_ON_ERROR)]);
    }

    private function query(string $sql, array $params = []): \PDOStatement
    {
        $statement = $this->db->prepare($sql);
        $statement->execute($params);
        return $statement;
    }

    private function input(): void
    {
        $schema = $this->state['config']['schema'];
        $formatter = new DiscoveryFormat($schema, $this->state['config']['origin']);
        $keys = array_keys($schema['slots'] ?? []);
        $index = $this->state['slot'];
        if ($index >= count($keys)) {
            $this->state['phase'] = 'setup';
            return;
        }
        if ($index === -1) {
            $key = 'pages';
            $config = [];
            $pages = $schema['staticPages'] ?? [];
            $pages = $pages ?: [['path' => '/', 'priority' => '1.0', 'changefreq' => 'daily']];
            $offset = (int) ($this->state['cursor']['offset'] ?? 0);
            $items = [];
            foreach (array_slice($pages, $offset, 100) as $i => $page) {
                $page['_schemaDate'] = $this->state['config']['schemaDate'] ?? null;
                $items[] = ['item' => $page, 'cursor' => ['offset' => $offset + $i + 1]];
            }
            $batch = ['items' => $items, 'done' => $offset + count($items) >= count($pages)];
        } else {
            $key = (string) $keys[$index];
            $config = $schema['slots'][$key];
            $sitemap = !empty($config['isSitemap']);
            if (!in_array($config['type'] ?? '', ['collection', 'list', 'massive'], true)
                || (!$sitemap && !($config['isLlms'] ?? $sitemap))) {
                $this->state['slot']++;
                $this->state['cursor'] = [];
                return;
            }
            if ($this->reader === null) {
                throw new RuntimeException('Discovery row reader is required');
            }
            $batch = ($this->reader)($key, $config, $this->state['cursor']);
        }
        $processed = 0;
        foreach ($batch['items'] as $row) {
            foreach ($formatter->entries($key, $config, $row['item'], $index === -1) as $entry) {
                $this->query('INSERT OR IGNORE INTO entries(kind,grp,locale,title,loc,body) VALUES (?,?,?,?,?,?)', [
                    $entry['kind'], $entry['grp'], $entry['locale'], $entry['title'], $entry['loc'], $entry['body'],
                ]);
            }
            $this->state['cursor'] = $row['cursor'];
            $processed++;
            if (microtime(true) >= $this->deadline) {
                break;
            }
        }
        if ($batch['done'] && $processed === count($batch['items'])) {
            $this->state['slot']++;
            $this->state['cursor'] = [];
        }
    }

    private function mdHeader(): string
    {
        $schema = $this->state['config']['schema'];
        $title = DiscoveryFormat::label($schema['title'] ?? $schema['$id'] ?? 'NOMAD CMS', 120);
        $description = DiscoveryFormat::label($schema['description'] ?? '', 300);
        return '# ' . $title . "\n\n" . ($description !== '' ? '> ' . $description . "\n\n" : '');
    }

    private function footer(array $job): string
    {
        if (!isset($job['root'])) {
            return '';
        }
        $origin = $this->state['config']['origin'];
        $footer = "\n## Optional\n\n- [Sitemap](" . $origin . "/sitemap.xml): XML sitemap for search engines\n"
            . '- [Robots](' . $origin . "/robots.txt): Crawler rules and directives\n";
        if ($job['root'] === 'md:' && ($job['languages'] ?? false)) {
            $formatter = new DiscoveryFormat($this->state['config']['schema'], $origin);
            foreach ($formatter->languages() as $locale) {
                if ($locale !== '') {
                    $footer .= '- [LLMs (' . $locale . ')](' . $origin . '/llms.txt?lang=' . $locale . "): Language index\n";
                }
            }
        }
        return $footer;
    }

    private function fits(string $kind, ?string $locale = null): bool
    {
        $where = 'kind=?' . ($locale !== null ? ' AND locale=?' : '');
        $params = $locale === null ? [$kind] : [$kind, $locale];
        $totals = $this->query('SELECT COUNT(*) AS count,COALESCE(SUM(LENGTH(CAST(body AS BLOB))),0) AS bytes FROM entries WHERE ' . $where, $params)->fetch();
        if ($kind === 'xml') {
            return $totals['count'] <= $this->limits['xmlUrls']
                && $totals['bytes'] + strlen(self::XML_HEADER . '</urlset>') <= $this->limits['xmlBytes'];
        }
        $footer = $this->footer(['root' => 'md:' . ($locale ?? ''), 'languages' => $locale === null]);
        $bytes = strlen($this->mdHeader() . $footer) + (int) $totals['bytes'];
        foreach ($this->query('SELECT title,locale FROM entries WHERE ' . $where . ' GROUP BY grp ORDER BY MIN(id)', $params) as $group) {
            $bytes += strlen("\n## " . DiscoveryFormat::label($group['title']) . ($locale === null && $group['locale'] !== '' ? ' (' . $group['locale'] . ')' : '') . "\n\n");
        }
        return $totals['count'] + substr_count($footer, '](') <= $this->limits['mdLinks'] && $bytes <= $this->limits['mdBytes'];
    }

    private function job(array $job, int $rank): void
    {
        $job += ['cursor' => 0, 'part' => 1, 'count' => 0, 'bytes' => 0, 'level' => 0, 'outputs' => 0, 'section' => ''];
        $this->query('INSERT INTO jobs(rank,data) VALUES (?,?)', [$rank, json_encode($job, JSON_THROW_ON_ERROR)]);
    }

    private function setup(): void
    {
        // Setup traverses only distinct schema groups, never all item rows in memory.
        $globalSmall = $this->fits('md');
        $formatter = new DiscoveryFormat($this->state['config']['schema'], $this->state['config']['origin']);
        $languages = $formatter->languages();
        if ($globalSmall) {
            $this->job(['kind' => 'md', 'source' => 'entries', 'scope' => '*', 'prefix' => 'md/main',
                'canonical' => 'md/index.md', 'root' => 'md:', 'flat' => true, 'languages' => true], 0);
        }
        foreach ($languages as $locale) {
            $base = 'md/' . ($locale !== '' ? $locale . '/' : '');
            $small = $globalSmall || $this->fits('md', $locale);
            if ($locale !== '' && $small) {
                $this->job(['kind' => 'md', 'source' => 'entries', 'scope' => '@' . $locale,
                    'prefix' => $base . 'main', 'canonical' => $base . 'index.md', 'root' => 'md:' . $locale,
                    'flat' => true, 'parent' => $globalSmall ? '' : 'root', 'title' => strtoupper($locale)], 0);
            }
            if ($small) {
                continue;
            }
            $groups = $this->query("SELECT grp,title FROM entries WHERE kind='md' AND locale=? GROUP BY grp ORDER BY MIN(id)", [$locale]);
            foreach ($groups as $group) {
                $scope = 'group:' . $group['grp'];
                $path = 'md/' . $group['grp'];
                $this->job(['kind' => 'md', 'source' => 'entries', 'scope' => $group['grp'],
                    'prefix' => $path . '/part', 'parent' => $scope, 'title' => $group['title']], 0);
                $this->job(['kind' => 'md', 'source' => 'nodes', 'scope' => $scope,
                    'prefix' => $path . '/index', 'canonical' => $path . '/index.md',
                    'parent' => $locale !== '' ? 'lang:' . $locale : 'root', 'title' => $group['title']], 1);
            }
            if ($locale !== '') {
                $this->job(['kind' => 'md', 'source' => 'nodes', 'scope' => 'lang:' . $locale,
                    'prefix' => $base . 'index', 'canonical' => $base . 'index.md', 'root' => 'md:' . $locale,
                    'parent' => 'root', 'title' => strtoupper($locale)], 2);
            }
        }
        if (!$globalSmall) {
            $this->job(['kind' => 'md', 'source' => 'nodes', 'scope' => 'root', 'prefix' => 'md/index',
                'canonical' => 'md/index.md', 'root' => 'md:', 'title' => 'Contents'], 3);
        }
        if ($this->fits('xml')) {
            $this->job(['kind' => 'xml', 'source' => 'entries', 'scope' => '*', 'prefix' => 'xml/sitemap',
                'canonical' => 'xml/sitemap.xml', 'root' => 'xml:'], 0);
        } else {
            foreach ($this->query("SELECT grp FROM entries WHERE kind='xml' GROUP BY grp ORDER BY MIN(id)") as $group) {
                $this->job(['kind' => 'xml', 'source' => 'entries', 'scope' => $group['grp'],
                    'prefix' => 'xml/' . str_replace('/', '-', $group['grp']) . '-' . substr(hash('sha256', $group['grp']), 0, 24) . '-part', 'parent' => 'xml'], 0);
            }
            $this->job(['kind' => 'xml', 'source' => 'nodes', 'scope' => 'xml', 'prefix' => 'xml/sitemap-index', 'root' => 'xml:'], 3);
        }
        $this->state['phase'] = 'render';
    }

    private function rows(array $job): array
    {
        if ($job['source'] === 'nodes') {
            return $this->query('SELECT * FROM nodes WHERE scope=? AND level=? AND id>? ORDER BY id LIMIT 100',
                [$job['scope'], $job['level'], $job['cursor']])->fetchAll();
        }
        $where = 'kind=? AND id>?';
        $params = [$job['kind'], $job['cursor']];
        if (str_starts_with($job['scope'], '@')) {
            $where .= ' AND locale=?';
            $params[] = substr($job['scope'], 1);
        } elseif ($job['scope'] !== '*') {
            $where .= ' AND grp=?';
            $params[] = $job['scope'];
        }
        if ($job['flat'] ?? false) {
            // Flat documents are already proven small. Offset applies only inside this <=200-link path.
            $where = 'kind=?' . ($job['scope'] !== '*' ? ' AND locale=?' : '');
            $params = [$job['kind']];
            if ($job['scope'] !== '*') {
                $params[] = substr($job['scope'], 1);
            }
            $params[] = $job['cursor'];
            return $this->query('SELECT * FROM entries WHERE ' . $where
                . ' ORDER BY (SELECT MIN(e.id) FROM entries e WHERE e.kind=entries.kind AND e.grp=entries.grp),id '
                . 'LIMIT 100 OFFSET CAST(? AS INTEGER)', $params)->fetchAll();
        }
        return $this->query('SELECT * FROM entries WHERE ' . $where . ' ORDER BY id LIMIT 100', $params)->fetchAll();
    }

    private function relative(array $job): string
    {
        return $job['prefix'] . '-' . $job['level'] . '-' . sprintf('%06d', $job['part']) . '.' . $job['kind'];
    }

    private function header(array $job): string
    {
        if ($job['kind'] === 'xml') {
            return $job['source'] === 'nodes' ? self::INDEX_HEADER : self::XML_HEADER;
        }
        return $this->mdHeader() . ($job['source'] === 'nodes' ? "## Contents\n\n" : '');
    }

    private function ending(array $job): string
    {
        return $job['kind'] === 'xml' ? ($job['source'] === 'nodes' ? '</sitemapindex>' : '</urlset>') : $this->footer($job);
    }

    private function openStream(array &$job): void
    {
        if (is_resource($this->stream)) {
            return;
        }
        $path = $this->directory . '/files/' . $this->relative($job);
        self::directory(dirname($path));
        $this->stream = @fopen($path, 'c+b');
        if ($this->stream === false || !@ftruncate($this->stream, $job['bytes']) || @fseek($this->stream, $job['bytes']) !== 0) {
            throw new RuntimeException('Cannot restore discovery output checkpoint');
        }
        if ($job['bytes'] === 0) {
            $this->write($this->header($job));
            $job['bytes'] = strlen($this->header($job));
        }
    }

    private function write(string $bytes): void
    {
        $length = strlen($bytes);
        $position = 0;
        while ($position < $length) {
            $written = @fwrite($this->stream, substr($bytes, $position));
            if ($written === false || $written === 0) {
                throw new RuntimeException('Cannot write discovery output');
            }
            $position += $written;
        }
    }

    private function closeStream(): void
    {
        if (is_resource($this->stream)) {
            if (!@fflush($this->stream)) {
                fclose($this->stream);
                $this->stream = null;
                throw new RuntimeException('Cannot flush discovery output');
            }
            fclose($this->stream);
        }
        $this->stream = null;
    }

    private function registerFile(string $relative): void
    {
        $this->query('INSERT OR IGNORE INTO files(rel) VALUES (?)', [$relative]);
    }

    private function node(string $scope, int $level, string $relative, string $title): void
    {
        if ($scope !== '') {
            $this->query('INSERT INTO nodes(scope,level,rel,title) VALUES (?,?,?,?)', [$scope, $level, $relative, $title]);
        }
    }

    private function finishPart(array &$job): void
    {
        $this->openStream($job);
        $this->write($this->ending($job));
        $this->closeStream();
        $relative = $this->relative($job);
        $this->registerFile($relative);
        $job['last'] = $relative;
        $job['outputs']++;
        if ($job['source'] === 'entries' && !isset($job['canonical'])) {
            $this->node($job['parent'] ?? '', 0, $relative, ($job['title'] ?? 'Pages') . ' · ' . $job['part']);
        } elseif ($job['source'] === 'nodes' && $job['kind'] === 'md') {
            $this->node($job['scope'], $job['level'] + 1, $relative, ($job['title'] ?? 'Contents') . ' · ' . $job['part']);
        } elseif ($job['kind'] === 'xml' && $job['source'] === 'nodes') {
            $this->query('INSERT OR REPLACE INTO roots(name,rel) VALUES (?,?)', ['xml:' . ($job['part'] === 1 ? '' : $job['part']), $relative]);
        }
        $job['part']++;
        $job['count'] = 0;
        $job['bytes'] = 0;
        $job['section'] = '';
    }

    private function publicUrl(string $relative): string
    {
        $origin = $this->state['config']['origin'];
        $generation = $this->state['generation'];
        return $origin . ($relative[0] === 'm' ? '/llms-index/' . $generation . '/' . substr($relative, 3)
            : '/sitemap-' . $generation . '-' . substr($relative, 4));
    }

    private function body(array $job, array $row): array
    {
        if ($job['source'] === 'nodes') {
            $url = $this->publicUrl($row['rel']);
            return [$job['kind'] === 'md' ? '- [' . DiscoveryFormat::label($row['title']) . '](' . $url . ")\n"
                : '<sitemap><loc>' . DiscoveryFormat::xml($url) . "</loc></sitemap>\n", ''];
        }
        $heading = '';
        if ($job['kind'] === 'md' && $job['section'] !== $row['grp']) {
            $title = DiscoveryFormat::label($row['title']);
            if (($job['flat'] ?? false) && $job['scope'] === '*' && $row['locale'] !== '') {
                $title .= ' (' . $row['locale'] . ')';
            }
            $heading = "\n## " . $title . "\n\n";
        }
        return [$heading . $row['body'], $row['grp']];
    }

    private function render(): void
    {
        $record = $this->query('SELECT * FROM jobs WHERE done=0 ORDER BY rank,id LIMIT 1')->fetch();
        if (!$record) {
            $this->state['phase'] = 'members';
            return;
        }
        $job = json_decode($record['data'], true, 512, JSON_THROW_ON_ERROR);
        $rows = $this->rows($job);
        $processed = 0;
        foreach ($rows as $row) {
            $this->openStream($job);
            [$body, $section] = $this->body($job, $row);
            $countLimit = $this->limits[$job['kind'] === 'md' ? 'mdLinks' : 'xmlUrls'];
            $byteLimit = $this->limits[$job['kind'] === 'md' ? 'mdBytes' : 'xmlBytes'];
            $reserved = $job['kind'] === 'md' ? substr_count($this->footer($job), '](') : 0;
            if ($job['count'] + 1 + $reserved > $countLimit || $job['bytes'] + strlen($body . $this->ending($job)) > $byteLimit) {
                if ($job['count'] === 0 || isset($job['flat'])) {
                    throw new RuntimeException('A discovery entry exceeds the configured document limit');
                }
                $this->finishPart($job);
                $this->openStream($job);
                [$body, $section] = $this->body($job, $row);
                if ($job['bytes'] + strlen($body . $this->ending($job)) > $byteLimit) {
                    throw new RuntimeException('A discovery entry exceeds the configured document limit');
                }
            }
            $this->write($body);
            $job['bytes'] += strlen($body);
            $job['count']++;
            $job['cursor'] = ($job['flat'] ?? false) ? $job['cursor'] + 1 : $row['id'];
            $job['section'] = $section;
            $processed++;
            if (microtime(true) >= $this->deadline) {
                break;
            }
        }
        $done = count($rows) < 100 && $processed === count($rows);
        if ($done) {
            $this->finishPart($job);
            if ($job['source'] === 'nodes' && $job['kind'] === 'md' && $job['outputs'] > 1) {
                // Reduce another level. A sitemap index is never reduced into a nested sitemap index.
                $job['level']++;
                $job['cursor'] = 0;
                $job['part'] = 1;
                $job['outputs'] = 0;
                $done = false;
            } elseif (isset($job['canonical'])) {
                $canonical = $job['canonical'];
                self::directory(dirname($this->directory . '/files/' . $canonical));
                if (!@copy($this->directory . '/files/' . $job['last'], $this->directory . '/files/' . $canonical)) {
                    throw new RuntimeException('Cannot finalize discovery index');
                }
                $this->registerFile($canonical);
                $this->node($job['parent'] ?? '', 0, $canonical, $job['title'] ?? 'Contents');
                if (isset($job['root'])) {
                    $this->query('INSERT OR REPLACE INTO roots(name,rel) VALUES (?,?)', [$job['root'], $canonical]);
                }
            }
        }
        $this->query('UPDATE jobs SET data=?,done=? WHERE id=?', [json_encode($job, JSON_THROW_ON_ERROR), (int) $done, $record['id']]);
    }

    private function members(): void
    {
        $rows = $this->query('SELECT * FROM files WHERE id>? ORDER BY id LIMIT 100', [$this->state['member']])->fetchAll();
        foreach ($rows as $row) {
            self::atomic($this->directory . '/members/' . hash('sha256', $row['rel']), $row['rel']);
            $this->state['member'] = $row['id'];
        }
        if (count($rows) < 100) {
            $this->state['phase'] = 'publish';
        }
    }

    private function publish(): void
    {
        $roots = [];
        foreach ($this->db->query('SELECT * FROM roots') as $root) {
            $roots[$root['name']] = $root['rel'];
        }
        $manifest = ['generation' => $this->state['generation'], 'roots' => $roots,
            'origin' => $this->state['config']['origin'], 'published' => time()];
        $json = json_encode($manifest, JSON_THROW_ON_ERROR | JSON_UNESCAPED_SLASHES);
        self::atomic($this->directory . '/published.json', $json);
        // Compatibility cache paths are mirrors. Readers select the complete generation via active.json.
        foreach ($roots as $name => $relative) {
            $target = $name === 'xml:' ? 'sitemap.xml' : ($name === 'md:' ? 'llms.txt'
                : (str_starts_with($name, 'md:') ? 'llms-' . substr($name, 3) . '.txt' : null));
            if ($target !== null) {
                // A deterministic private temporary path also bounds leftovers after a killed process.
                $temporary = $this->directory . '/mirror-' . hash('sha256', $target);
                try {
                    if (!@copy($this->directory . '/files/' . $relative, $temporary)
                        || !@rename($temporary, $this->cache . '/' . $target)) {
                        throw new RuntimeException('Cannot publish compatibility cache');
                    }
                } finally {
                    if (is_file($temporary)) {
                        @unlink($temporary);
                    }
                }
            }
        }
        $invalidation = @fopen($this->cache . '/discovery-invalidation.lock', 'c+');
        if ($invalidation === false || !flock($invalidation, LOCK_EX)) {
            throw new RuntimeException('Cannot coordinate discovery invalidation');
        }
        try {
            $previous = $this->manifest();
            self::atomic($this->cache . '/discovery/active.json', $json);
            if ($previous && $previous['generation'] !== $manifest['generation']) {
                self::atomic($this->cache . '/discovery/' . $previous['generation'] . '/retired', (string) time());
            }
            foreach ($this->tokens() as $kind => $token) {
                if ($token !== null && $token === $this->state['tokens'][$kind]) {
                    unlink($this->cache . '/' . $kind . '.dirty');
                }
            }
            // Robots may now need to advertise additional top-level sitemap indexes.
            self::atomic($this->cache . '/robots.dirty', bin2hex(random_bytes(12)));
            unlink($this->cache . '/discovery/build.json');
            $this->state['phase'] = 'complete';
        } finally {
            flock($invalidation, LOCK_UN);
            fclose($invalidation);
        }
    }

    /** Delete at most 100 filesystem entries, after a full day from retirement, without following symlinks. */
    public function cleanup(int $now = 0): void
    {
        $now = $now ?: time();
        $root = $this->cache . '/discovery';
        if (!is_dir($root)) {
            return;
        }
        $active = $this->manifest()['generation'] ?? '';
        $buildPath = $root . '/build.json';
        $building = is_file($buildPath) ? (json_decode((string) file_get_contents($buildPath), true)['generation'] ?? '') : '';
        $remaining = 100;
        foreach (new \DirectoryIterator($root) as $entry) {
            $generation = $entry->getFilename();
            if (!$entry->isDir() || $entry->isLink() || !preg_match('/^[a-f0-9]{24}$/D', $generation)
                || $generation === $active || $generation === $building) {
                continue;
            }
            $directory = $entry->getPathname();
            $retired = $directory . '/retired';
            if (!is_file($retired) || (int) file_get_contents($retired) + 86400 > $now) {
                continue;
            }
            $iterator = new \RecursiveIteratorIterator(new \RecursiveDirectoryIterator($directory,
                \FilesystemIterator::SKIP_DOTS), \RecursiveIteratorIterator::CHILD_FIRST);
            foreach ($iterator as $file) {
                // Keep retirement metadata until all other entries have gone, so cleanup can resume.
                if ($file->getPathname() === $retired) {
                    continue;
                }
                if ($remaining-- <= 0) {
                    return;
                }
                $file->isDir() && !$file->isLink() ? rmdir($file->getPathname()) : unlink($file->getPathname());
            }
            if ($remaining < 2) {
                return;
            }
            unlink($retired);
            rmdir($directory);
            $remaining -= 2;
        }
    }

    private static function directory(string $path): void
    {
        if (!is_dir($path) && !@mkdir($path, 0700, true) && !is_dir($path)) {
            throw new RuntimeException('Cannot create discovery directory');
        }
    }

    public static function atomic(string $path, string $data): void
    {
        $temporary = $path . '.tmp.' . bin2hex(random_bytes(6));
        try {
            if (@file_put_contents($temporary, $data, LOCK_EX) !== strlen($data) || !@rename($temporary, $path)) {
                throw new RuntimeException('Cannot atomically write discovery state');
            }
        } finally {
            if (is_file($temporary)) {
                unlink($temporary);
            }
        }
    }
}
