<?php
/**
 * NOMAD CMS - Collection API Service
 * Authenticated REST controller service for collection CRUD, search, pagination, and batch operations
 * 
 * Capabilities:
 * - Bounded paginated listing with search, filtering, and ownership enforcement (RBAC/ABAC)
 * - Single item retrieval with on-demand Gutenberg block hydration
 * - Optimistic locking validation (expected_revision & expected_schema_revision)
 * - Batch operations: atomic multi-item create/update/delete and drag-and-drop reordering
 * - Automatic cache invalidation and dependent slot change propagation
 * 
 * Endpoints: Integrated via /api/endpoints/data.php
 */

declare(strict_types=1);
namespace NomadCMS\Services;

use NomadCMS\Database\CollectionDatabase;
use NomadCMS\Database\ContentDatabase;
use NomadCMS\Middleware\AuthMiddleware;
use NomadCMS\Services\Schema\SchemaValues;

final class CollectionApiService
{
    public static function read(string $key, array $query): array
    {
        AuthMiddleware::requireAuth();
        AuthMiddleware::requireSlotAccess($key);
        $all = AuthMiddleware::hasPermission("content:read:*", $key);
        if (!$all && !AuthMiddleware::hasGrantedScope("content:read:own")) {
            AuthMiddleware::requirePermission("content:read:*");
        }
        if (!CollectionDatabase::isRegistered($key)) {
            CollectionDatabase::initializeEmpty($key);
        }
        $options = [
            "limit" => $query["limit"] ?? 50,
            "offset" => $query["offset"] ?? 0,
            "search" => $query["search"] ?? "",
            "cursor" => $query["cursor"] ?? null,
        ];
        if (isset($query['filters'])) {
            if (!is_string($query['filters']) || strlen($query['filters']) > 8192) {
                throw new \InvalidArgumentException('Invalid collection filters');
            }
            try {
                $options['filters'] = json_decode($query['filters'], true, 16, JSON_THROW_ON_ERROR);
            } catch (\JsonException $error) {
                throw new \InvalidArgumentException('Invalid collection filters', 0, $error);
            }
        }
        if (isset($query["published"])) {
            $options["published"] = filter_var(
                $query["published"],
                FILTER_VALIDATE_BOOLEAN
            );
        }
        if (!$all) {
            $options["owner_uuid"] = AuthMiddleware::getCurrentUser()->uuid;
        }
        $state = CollectionDatabase::state($key);
        if (isset($query["item_dnd_id"]) || isset($query["item_identifier"])) {
            $uid = (string) ($query["item_dnd_id"] ?? "");
            if (isset($query["item_identifier"])) {
                $item = CollectionDatabase::findByIdentifier(
                    $key,
                    (string) $query["item_identifier"]
                );
                $uid = RelationService::uidOf($item ?? []) ?? "";
            }
            $row = CollectionDatabase::row($key, $uid);
            if (
                !$row ||
                (!$all &&
                    $row["owner_uuid"] !==
                        AuthMiddleware::getCurrentUser()->uuid)
            ) {
                throw new \OutOfBoundsException("Item not found");
            }
            return [
                "success" => true,
                "data" => RelationService::resolveForSlot(
                    $key,
                    SchemaValues::editorPayload(
                        ContentDatabase::getInstance(),
                        $key,
                        CollectionDatabase::getItem(
                            $key,
                            $row["item_uid"],
                            ($query["include_blocks"] ?? 1) != 0
                        )
                    ),
                    null,
                    ($query["include_blocks"] ?? 1) != 0
                ),
                "item_meta" => CollectionDatabase::metadata($row),
                "schema_revision" => $state["schema_hash"],
                "exists" => true,
            ];
        }
        $page = CollectionDatabase::page($key, $options);
        if ($all) $page['collection_total']=(int)$state['item_count'];
        else { $s=CollectionDatabase::getInstance()->prepare('SELECT COUNT(*) FROM collection_items WHERE slot_key=? AND owner_uuid=?'); $s->execute([$key,AuthMiddleware::getCurrentUser()->uuid]); $page['collection_total']=(int)$s->fetchColumn(); }
        $page["data"] = RelationService::resolveForSlot(
            $key,
            SchemaValues::editorPayload(ContentDatabase::getInstance(), $key, $page["items"]),
            null,
            false
        );
        unset($page["items"]);
        return [
            "success" => true,
            "exists" => true,
            "version" => $page["revision"],
            "hash" => "",
        ] + $page;
    }

    public static function write(
        string $key,
        array $body,
        bool $deferEffects = false,
        bool $skipWebhooks = false
    ): array {
        $uid = (string) ($body["item_dnd_id"] ?? "");
        $row = CollectionDatabase::row($key, $uid);
        $operation =
            $body["operation"] ??
            (!empty($body["item_delete"])
                ? "delete"
                : ($row
                    ? "update"
                    : "create"));
        $scope = $operation === "delete" ? "delete" : "update";
        if ($operation === "create") {
            if (
                !AuthMiddleware::hasPermission("content:create:*", $key) &&
                !AuthMiddleware::hasGrantedScope("content:create:own") &&
                !AuthMiddleware::hasPermission("content:update:*", $key) &&
                !AuthMiddleware::hasGrantedScope("content:update:own")
            ) {
                AuthMiddleware::requirePermission("content:create:*");
            }
        } elseif (
            !AuthMiddleware::hasPermission("content:" . $scope . ":*", $key)
        ) {
            if (
                !AuthMiddleware::hasGrantedScope(
                    "content:" . $scope . ":own"
                ) ||
                !$row ||
                $row["owner_uuid"] !== AuthMiddleware::getCurrentUser()->uuid
            ) {
                AuthMiddleware::requirePermission("content:" . $scope . ":*");
            }
        }
        if ($operation !== "delete" && !is_array($body["item_data"] ?? null)) {
            throw new \InvalidArgumentException("Missing item_data");
        }
        $options = [
            "owner_uuid" => AuthMiddleware::getCurrentUser()->uuid,
            "changed_by" => AuthMiddleware::getCurrentUser()->uuid,
            "skip_webhooks" => $skipWebhooks,
        ];
        foreach (
            ["expected_revision", "expected_schema_revision", "client_updated_at", "remove_fields", "precomputed_search"]
            as $name
        ) {
            if (isset($body[$name])) {
                $options[$name] = $body[$name];
            }
        }
        if (!isset($options["expected_schema_revision"])) {
            throw new \InvalidArgumentException(
                "expected_schema_revision is required for collection writes"
            );
        }
        if ($operation !== "create" && !isset($options["expected_revision"])) {
            throw new \InvalidArgumentException(
                "expected_revision is required for collection item updates"
            );
        }
        $patch = $body["item_data"] ?? [];
        if ($operation === "create" && isset($patch["_copySourceUid"])) {
            $sourceUid = (string) $patch["_copySourceUid"];
            unset($patch["_copySourceUid"]);
            $sourceRow = CollectionDatabase::row($key, $sourceUid);
            if (
                !$sourceRow ||
                (!AuthMiddleware::hasPermission("content:read:*", $key) &&
                    (!AuthMiddleware::hasGrantedScope("content:read:own") ||
                        $sourceRow["owner_uuid"] !==
                            AuthMiddleware::getCurrentUser()->uuid))
            ) {
                throw new \OutOfBoundsException("Copy source not found");
            }
            // Load and inherit the source inside the same transaction as the copy.
            $options['copy_source_uid'] = $sourceUid;
        }
        $result = CollectionDatabase::writeItem(
            $key,
            $uid ?: null,
            $patch,
            $operation,
            $options
        );
        if (!$deferEffects) {
            self::invalidate($key);
        }
        return $result + [
            "hash" => "",
            "schema_revision" => CollectionDatabase::state($key)["schema_hash"],
        ];
    }

    /**
     * Publish or unpublish the complete accessible collection in one transaction.
     *
     * @param array $body Target publication state and optimistic collection/schema revisions.
     * @return array Mutation count and resulting revision for the editor's next request.
     */
    public static function publishAll(string $key,array $body): array
    {
        AuthMiddleware::requireAuth(); AuthMiddleware::requireSlotAccess($key);
        $all=AuthMiddleware::hasPermission('content:update:*',$key);
        if (!$all&&!AuthMiddleware::hasGrantedScope('content:update:own')) AuthMiddleware::requirePermission('content:update:*');
        if (!is_bool($body['collection_bulk_publish']??null)) throw new \InvalidArgumentException('Publication state must be boolean');
        $options=['expected_version'=>$body['expected_version']??null,'expected_schema_revision'=>$body['expected_schema_revision']??null,'changed_by'=>AuthMiddleware::getCurrentUser()->uuid];
        if (!$all) $options['owner_uuid']=AuthMiddleware::getCurrentUser()->uuid;
        $result=CollectionDatabase::publishAll($key,$body['collection_bulk_publish'],$options);
        self::invalidate($key);
        return $result;
    }

    private static function invalidate(string $key): void
    {
        SitemapService::markDirty();
        StaticCacheService::markCollectionDirty($key);
        foreach (RelationService::getDependentSlots($key) as $dependent) {
            if (CollectionDatabase::isRegistered($dependent)) {
                CollectionDatabase::enqueue($dependent);
            }
            if (CollectionDatabase::isRegistered($dependent)) {
                StaticCacheService::markCollectionDirty($dependent);
            } else {
                StaticCacheService::invalidateSlot($dependent);
            }
        }
    }

    /** Run native cache/relation effects after an outer transaction commits its destination receipt. */
    public static function invalidateAfterCommit(string $key): void
    {
        self::invalidate($key);
    }

    public static function batch(string $key, array $body): array
    {
        $operations = $body["collection_operations"] ?? [];
        if (!is_array($operations) || count($operations) > 200) {
            throw new \InvalidArgumentException(
                "Maximum 200 collection operations"
            );
        }
        $results = CollectionDatabase::transaction(function () use (
            $key,
            $body,
            $operations
        ) {
            if (
                isset($body["collection_order"]) &&
                (int) ($body["expected_version"] ?? -1) !==
                    (int) CollectionDatabase::state($key)["revision"]
            ) {
                throw new \NomadCMS\Database\OptimisticLockException(
                    $key,
                    $body["expected_version"] ?? null,
                    (int) CollectionDatabase::state($key)["revision"]
                );
            }
            $results = [];
            // Routine editor batches stay silent. One explicit copy is a creation event;
            // multiple copies remain a bulk operation and must not fan out notifications.
            $copies = array_filter($operations, static fn (array $operation): bool =>
                ($operation['operation'] ?? '') === 'create'
                && isset($operation['item_data']['_copySourceUid'])
            );
            foreach ($operations as $operation) {
                $results[] = self::write(
                    $key,
                    $operation + [
                        "expected_schema_revision" =>
                            $body["expected_schema_revision"] ?? null,
                    ],
                    true,
                    !(count($copies) === 1
                        && ($operation['operation'] ?? '') === 'create'
                        && isset($operation['item_data']['_copySourceUid']))
                );
            }
            if (isset($body["collection_order"])) {
                $uids = $body["collection_order"];
                if (!is_array($uids) || count($uids) > 200) {
                    throw new \InvalidArgumentException(
                        "Invalid collection order"
                    );
                }
                foreach ($uids as $uid) {
                    $row = CollectionDatabase::row($key, (string) $uid);
                    if (
                        !$row ||
                        (!AuthMiddleware::hasPermission(
                            "content:update:*",
                            $key
                        ) &&
                            (!AuthMiddleware::hasGrantedScope(
                                "content:update:own"
                            ) ||
                                $row["owner_uuid"] !==
                                    AuthMiddleware::getCurrentUser()->uuid))
                    ) {
                        AuthMiddleware::requirePermission("content:update:*");
                    }
                }
                CollectionDatabase::reorder(
                    $key,
                    $uids,
                    (int) CollectionDatabase::state($key)["revision"]
                );
            }
            return $results;
        });
        self::invalidate($key);
        return [
            "success" => true,
            "results" => $results,
            "version" => (int) CollectionDatabase::state($key)["revision"],
            "hash" => "",
        ];
    }
}
