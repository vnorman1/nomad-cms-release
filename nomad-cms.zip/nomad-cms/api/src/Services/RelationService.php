<?php
/**
 * NOMAD CMS - Relation Service
 *
 * Handles `relation` (1-N) and `relation_many` (N-N) field resolution.
 *
 * =============================================================================
 * ITEM IDENTITY — THE SINGLE MOST IMPORTANT RULE
 * =============================================================================
 * Every item of a `list` / `collection` slot is identified by `_dndId`, a short
 * opaque string UID. It was originally introduced by the admin UI as a React
 * drag & drop key, but it is in fact the ONLY per-item identifier that has ever
 * been stable in this CMS, so it is now promoted to the canonical item UID:
 *
 *   - GUARANTEED: assigned server-side on every save when missing.
 *   - UNIQUE:     de-duplicated server-side on every save (this is what makes
 *                 "duplicate an item" safe — the copy always gets a fresh UID).
 *   - STABLE:     never derived from array position, never re-used.
 *   - INTERNAL:   used to correlate relation values with target rows WHILE DATA
 *                 STAYS INSIDE THE CMS. It never leaves the CMS: it is stripped
 *                 from every embed and from public output (API responses, the
 *                 static cache). Headless consumers only ever see the raw
 *                 relation value (the uid string/array) that already sits next
 *                 to the embed — that is enough to correlate without exposing
 *                 an internal editor identity.
 *
 * A user-defined `id` field (if the schema declares one) is ordinary content and
 * is NEVER used for relation resolution. That distinction is deliberate: user
 * `id` values are editable, frequently duplicated and often absent.
 *
 * =============================================================================
 * STORAGE MODEL — SINGLE SOURCE OF TRUTH
 * =============================================================================
 * Relation values live in the item JSON itself, for every slot type:
 *
 *   relation       (1-N):  "szerzo": "se9ln0m33"                (uid | null)
 *   relation_many  (N-N):  "cimkek": ["85f0upbm7", "urrjgbke4"] (uid[])
 *
 * The `slot_relations` table is a DERIVED REVERSE INDEX, rebuilt wholesale from
 * the item JSON on every save. It is only read for reverse lookups (cascade
 * cache invalidation, "what points at me"). It is never read during resolution,
 * so it can never desynchronise from the content.
 *
 * =============================================================================
 * READ PATH — no JOIN, shared-hosting friendly
 * =============================================================================
 *   1. Collect the referenced UIDs from the items in PHP.
 *   2. Load each target slot exactly once (one indexed row read per slot).
 *   3. Embed the resolved item under "_<fieldId>".
 *
 * Resolution is depth-1 by design: an embedded target item has its own relation
 * embeds and internal keys stripped, so the payload can never grow recursively
 * and circular relations (A -> B -> A) are safe.
 *
 *   {
 *     "szerzo":  "se9ln0m33",
 *     "_szerzo": { "nev": "Aladár Ferenc" },
 *     "cimkek":  ["85f0upbm7"],
 *     "_cimkek": [ { "nev": "tesztelek" } ]
 *   }
 *
 * The embed never carries `_dndId` (or any other underscore-prefixed key): the
 * raw uid next to it is what a consumer correlates against, and saves stay
 * idempotent because `normalizeItem()` strips the whole `_<fieldId>` embed
 * before persisting regardless of its shape.
 *
 * THE SHAPE ABOVE IS INTERNAL — it is what authenticated admin paths receive.
 * Everything that leaves the CMS goes through projectForPublic(), which merges
 * the embed onto the field's own name and removes every internal key, so a
 * public consumer sees no uid and no "_" key at all:
 *
 *   {
 *     "szerzo": { "nev": "Aladár Ferenc" },
 *     "cimkek": [ { "nev": "tesztelek" } ]
 *   }
 *
 * =============================================================================
 * PROJECTION — `embedFields`
 * =============================================================================
 * A relation field may declare which target fields the embed should carry:
 *
 *   { "id": "szerzo", "type": "relation", "target": "irok",
 *     "embedFields": ["nev", "evszam"] }
 *
 * Only those fields (plus the identity key, which is never optional) end up in
 * `_szerzo`. Omit `embedFields` to embed the whole target item.
 *
 * This matters because embeds are duplicated into every referencing item and into
 * the static cache: referencing an author with a full biography from 200 books
 * would copy that biography 200 times. Projection is declared in the schema and
 * enforced here, so the API response and the static cache can never disagree.
 *
 * `embedFields` (what is transferred) is independent from `displayFields` (what
 * the admin picker shows) — the picker reads the target slot directly.
 */

declare(strict_types=1);

namespace NomadCMS\Services;

use NomadCMS\Database\ContentDatabase;
use PDO;

final class RelationService
{
    /** Canonical per-item identity key. */
    public const UID_KEY = '_dndId';

    /** Field types handled by this service. */
    public const RELATION_TYPES = ['relation', 'relation_many'];

    /** Slot types whose items carry a UID. */
    private const ITEMISED_SLOT_TYPES = ['list', 'collection'];

    /**
     * Keys that must never survive into an embedded copy of a target item.
     * (Relation embeds are stripped separately, by field id.)
     */
    private const EMBED_STRIP_KEYS = [
        '_isPending', '_localId', '_dirty', '_selected', '_expanded', '_temp',
    ];

    /**
     * Per-request cache of target slot items: slotKey => (uid => item).
     * Prevents re-reading the same target slot for every field/item.
     */
    private static array $targetCache = [];

    /**
     * Per-request set of existing item UIDs per slot: slotKey => (uid => true).
     * Used to tell a real UID apart from a legacy numeric reference.
     */
    private static array $uidSetCache = [];

    /** Per-request cache of the parsed schema. */
    private static ?array $schemaCache = null;
    private static bool $includeTargetBlocks = true;
    private static bool $publicTargets = false;

    // =========================================================================
    // SCHEMA HELPERS
    // =========================================================================

    /**
     * Load and cache nomad.schema.json.
     */
    public static function loadSchema(): array
    {
        if (self::$schemaCache !== null) {
            return self::$schemaCache;
        }

        // Stored definitions are the active schema until a compatible transition is complete.
        // Registry activation now owns transitions; reads never synchronize schemas.
        self::$schemaCache = \NomadCMS\Services\Schema\SchemaProvider::schema();
        return self::$schemaCache;
    }

    /**
     * Drop all per-request caches. Call after a save that changed slot content,
     * or after the schema was rewritten.
     *
     * Passing a slot key clears every cached projection of that slot, since the
     * same slot may be cached once per distinct `embedFields` set.
     */
    public static function clearCache(?string $slotKey = null): void
    {
        if ($slotKey === null) {
            self::$targetCache = [];
            self::$uidSetCache = [];
            self::$schemaCache = null;
            return;
        }

        unset(self::$uidSetCache[$slotKey]);

        foreach (array_keys(self::$targetCache) as $cacheKey) {
            if ($cacheKey === $slotKey || str_starts_with((string) $cacheKey, $slotKey . '|')) {
                unset(self::$targetCache[$cacheKey]);
            }
        }
    }

    /**
     * Field definitions of a slot.
     */
    public static function getSlotFields(string $slotKey, ?array $schema = null): array
    {
        $schema = $schema ?? self::loadSchema();
        $fields = $schema['slots'][$slotKey]['fields'] ?? [];
        return is_array($fields) ? $fields : [];
    }

    /**
     * Declared type of a slot ('object' | 'list' | 'collection' | 'massive').
     */
    public static function getSlotType(string $slotKey, ?array $schema = null): string
    {
        $schema = $schema ?? self::loadSchema();
        $type = $schema['slots'][$slotKey]['type'] ?? null;
        return is_string($type) && $type !== '' ? $type : 'object';
    }

    /**
     * True when items of this slot must carry a UID.
     */
    public static function isItemisedSlot(string $slotKey, ?array $schema = null): bool
    {
        return in_array(self::getSlotType($slotKey, $schema), self::ITEMISED_SLOT_TYPES, true);
    }

    /**
     * Only the relation/relation_many fields of a schema field list.
     *
     * Fields without a usable `target` are dropped: an unconfigured relation
     * field must behave as inert rather than half-working.
     */
    public static function getRelationFields(array $schemaFields): array
    {
        $out = [];

        foreach ($schemaFields as $field) {
            if (!is_array($field)) {
                continue;
            }
            if (!in_array($field['type'] ?? '', self::RELATION_TYPES, true)) {
                continue;
            }
            $fieldId = $field['id'] ?? '';
            $target  = $field['target'] ?? '';
            if (!is_string($fieldId) || $fieldId === '' || !is_string($target) || $target === '') {
                continue;
            }
            $out[] = $field;
        }

        return $out;
    }

    public static function hasRelationFields(array $schemaFields): bool
    {
        return self::getRelationFields($schemaFields) !== [];
    }

    /**
     * Embed key for a relation field ("szerzo" => "_szerzo").
     */
    public static function embedKey(string $fieldId): string
    {
        return '_' . $fieldId;
    }

    /**
     * Projection declared by a relation field: which target fields the embed
     * should carry.
     *
     * @return string[] Field ids; empty means "embed everything".
     */
    public static function getEmbedFields(array $field): array
    {
        $raw = $field['embedFields'] ?? null;

        if (!is_array($raw)) {
            return [];
        }

        $out = [];
        foreach ($raw as $fieldId) {
            if (is_string($fieldId) && trim($fieldId) !== '') {
                $out[trim($fieldId)] = true;
            }
        }

        return array_keys($out);
    }

    // =========================================================================
    // IDENTITY
    // =========================================================================

    /**
     * Generate a fresh item UID.
     *
     * 10 hex chars from a CSPRNG, with at least one letter guaranteed. The letter
     * matters: a digit-only UID would be indistinguishable from a legacy numeric
     * reference (see legacyRefToUid) and could be silently discarded on save.
     *
     * The admin UI generates 9-char base36 values; both live in the same opaque
     * string space, so they are interchangeable.
     */
    public static function generateUid(): string
    {
        return \Ramsey\Uuid\Uuid::uuid4()->toString();
    }

    /**
     * Read the UID of an item, or null when absent/blank.
     */
    public static function uidOf(mixed $item): ?string
    {
        if (!is_array($item)) {
            return null;
        }
        $uid = $item[self::UID_KEY] ?? null;
        if (is_string($uid) && trim($uid) !== '') {
            return $uid;
        }
        // Tolerate numeric UIDs coming from imports.
        if (is_int($uid) || is_float($uid)) {
            return (string) $uid;
        }
        return null;
    }

    /**
     * Guarantee that every item in a list has a unique UID.
     *
     * This is the fix for "duplicating an item duplicates its id": a copied item
     * arrives carrying the UID of its source, the collision is detected here and
     * the later occurrence is re-issued a fresh UID.
     *
     * @param  array $items List of item arrays.
     * @return array{0: array, 1: bool} [items, changed]
     */
    public static function ensureItemUids(array $items): array
    {
        $seen    = [];
        $changed = false;

        foreach ($items as $idx => $item) {
            if (!is_array($item)) {
                continue;
            }

            $uid = self::uidOf($item);

            if ($uid === null || isset($seen[$uid])) {
                do {
                    $uid = self::generateUid();
                } while (isset($seen[$uid]));
                $items[$idx][self::UID_KEY] = $uid;
                $changed = true;
            } elseif (!is_string($item[self::UID_KEY])) {
                // Normalise numeric UIDs to string form.
                $items[$idx][self::UID_KEY] = $uid;
                $changed = true;
            }

            $seen[$uid] = true;
        }

        return [$items, $changed];
    }

    // =========================================================================
    // WRITE PATH
    // =========================================================================

    /**
     * Normalise a whole slot payload before it is persisted.
     *
     *   1. Strip resolved relation embeds (`_<fieldId>`) so denormalised copies
     *      never get written back into the content.
     *   2. Guarantee unique item UIDs for list/collection slots.
     *   3. Coerce relation values to their canonical shape (uid | uid[]),
     *      translating legacy numeric references on the way.
     *
     * Safe to call for any slot: without relation fields it only touches UIDs.
     *
     * @param  string $key    Slot key.
     * @param  mixed  $data   Raw payload (list of items, or a single object).
     * @param  array|null $schema Parsed schema (loaded on demand).
     * @return mixed  Normalised payload.
     */
    public static function normalizeForSave(string $key, mixed $data, ?array $schema = null): mixed
    {
        if (!is_array($data)) {
            return $data;
        }

        $schema         = $schema ?? self::loadSchema();
        $fields         = self::getSlotFields($key, $schema);
        $relationFields = self::getRelationFields($fields);
        $isList         = array_is_list($data);

        if ($isList) {
            if (self::isItemisedSlot($key, $schema)) {
                [$data] = self::ensureItemUids($data);
            }

            foreach ($data as $idx => $item) {
                if (is_array($item)) {
                    $data[$idx] = self::normalizeItem($item, $relationFields, $schema);
                }
            }

            return $data;
        }

        return self::normalizeItem($data, $relationFields, $schema);
    }

    /**
     * Strip embeds + coerce relation values on a single item.
     */
    public static function normalizeItem(array $item, array $relationFields, array $schema): array
    {
        foreach ($relationFields as $field) {
            $fieldId   = $field['id'];
            $targetKey = $field['target'];
            $isMany    = $field['type'] === 'relation_many';

            // 1. Drop the resolved embed — it is derived data, never input.
            unset($item[self::embedKey($fieldId)]);

            // 2. Nothing stored for this field: leave the item untouched so we
            //    do not invent keys the editor never sent.
            if (!array_key_exists($fieldId, $item)) {
                continue;
            }

            // Registry validation is strict; never coerce unchanged legacy values.
            if (\NomadCMS\Services\Schema\SchemaProvider::initialized()) {
                continue;
            }
            $item[$fieldId] = $isMany
                ? self::coerceUidList($item[$fieldId], $targetKey, $schema)
                : self::coerceUid($item[$fieldId], $targetKey, $schema);
        }

        return $item;
    }

    /**
     * Coerce a single relation value to a UID string or null.
     */
    private static function coerceUid(mixed $value, string $targetKey, array $schema): ?string
    {
        if ($value === null || $value === '' || $value === []) {
            return null;
        }

        if (is_array($value)) {
            // The editor may hand back the whole target item.
            $uid = self::uidOf($value);
            if ($uid !== null) {
                return $uid;
            }

            // A language-keyed map ({ hu: uid, en: uid }) arrives when a relation
            // field was marked localized by mistake. A reference is language
            // independent, so collapse it rather than discarding the reference:
            // dropping it would silently destroy the user's link.
            $unwrapped = self::unwrapLocalized($value, $schema);
            if ($unwrapped !== null) {
                return self::coerceUid($unwrapped, $targetKey, $schema);
            }

            return null;
        }

        if (is_string($value)) {
            $value = trim($value);
            if ($value === '') {
                return null;
            }
            // An existing UID always wins over the legacy interpretation. UIDs are
            // hex and may consist of digits only, so checking the target slot first
            // is what keeps such a UID from being mistaken for a positional
            // reference and discarded.
            if (self::targetHasUid($targetKey, $value, $schema)) {
                return $value;
            }
            // Numeric strings are legacy positional references.
            return ctype_digit($value)
                ? self::legacyRefToUid($targetKey, (int) $value, $schema)
                : $value;
        }

        if (is_int($value) || is_float($value)) {
            $asString = (string) $value;
            if (self::targetHasUid($targetKey, $asString, $schema)) {
                return $asString;
            }
            return self::legacyRefToUid($targetKey, (int) $value, $schema);
        }

        return null;
    }

    /**
     * Does the target slot contain an item with this exact UID?
     *
     * Memoised per slot: this runs for every relation value of every item.
     */
    private static function targetHasUid(string $targetKey, string $uid, array $schema): bool
    {
        if (\NomadCMS\Database\CollectionDatabase::isRegistered($targetKey)) {
            return \NomadCMS\Database\CollectionDatabase::row($targetKey, $uid) !== null;
        }
        if (!isset(self::$uidSetCache[$targetKey])) {
            $set = [];
            foreach (self::loadTargetList($targetKey, $schema) as $item) {
                $itemUid = self::uidOf($item);
                if ($itemUid !== null) {
                    $set[$itemUid] = true;
                }
            }
            self::$uidSetCache[$targetKey] = $set;
        }

        return isset(self::$uidSetCache[$targetKey][$uid]);
    }

    /**
     * Coerce a multi relation value to a de-duplicated list of UID strings.
     */
    private static function coerceUidList(mixed $value, string $targetKey, array $schema): array
    {
        if ($value === null || $value === '') {
            return [];
        }

        if (is_array($value) && !array_is_list($value)) {
            // Either a single target item, or a language-keyed map of lists.
            if (self::uidOf($value) === null) {
                $unwrapped = self::unwrapLocalized($value, $schema);
                if ($unwrapped !== null) {
                    $value = $unwrapped;
                }
            }
        }

        if (!is_array($value)) {
            $value = [$value];
        }

        // NOTE: a digit-only UID used as an array key would be cast to int by PHP
        // and its JSON type would flip from string to number. Dedupe via a
        // separate map and emit the original strings.
        $out  = [];
        $seen = [];
        foreach ($value as $entry) {
            $uid = self::coerceUid($entry, $targetKey, $schema);
            if ($uid !== null && !isset($seen[$uid])) {
                $seen[$uid] = true;
                $out[] = $uid;
            }
        }

        return $out;
    }

    /**
     * If $value is a language-keyed map, return the most meaningful entry.
     *
     * Prefers the schema's default language, then the first non-empty entry.
     * Returns null when the array is not a language map.
     */
    private static function unwrapLocalized(array $value, array $schema): mixed
    {
        if ($value === [] || array_is_list($value)) {
            return null;
        }

        $languages = $schema['i18n']['languages'] ?? [];
        if (!is_array($languages) || $languages === []) {
            return null;
        }

        foreach (array_keys($value) as $key) {
            if (!in_array($key, $languages, true)) {
                return null; // not a language map
            }
        }

        $defaultLang = $schema['i18n']['defaultLanguage'] ?? null;
        if ($defaultLang !== null && !empty($value[$defaultLang])) {
            return $value[$defaultLang];
        }

        foreach ($value as $entry) {
            if (!empty($entry)) {
                return $entry;
            }
        }

        return null;
    }

    /**
     * Translate a legacy numeric reference into a UID.
     *
     * Before UIDs existed the API exposed synthetic ids for list items: the
     * item's own unique `id` field when it had one, otherwise its 1-based array
     * position. Relation values recorded against those numbers are migrated here,
     * on the first save of the referencing slot — so no separate data migration
     * has to run.
     */
    private static function legacyRefToUid(string $targetKey, int $ref, array $schema): ?string
    {
        if ($ref <= 0) {
            return null;
        }

        if (\NomadCMS\Database\CollectionDatabase::isRegistered($targetKey)) {
            // A numeric legacy UID always wins over business ID and old array position.
            $item=\NomadCMS\Database\CollectionDatabase::findByIdentifier($targetKey,(string)$ref,false);
            if ($item) return self::uidOf($item);
            $s=ContentDatabase::getInstance()->prepare('SELECT item_uid FROM collection_items WHERE slot_key=? ORDER BY position,row_id LIMIT 1 OFFSET ?');
            $s->bindValue(1,$targetKey); $s->bindValue(2,$ref-1,PDO::PARAM_INT); $s->execute();
            return $s->fetchColumn() ?: null;
        }

        $items = self::loadTargetList($targetKey, $schema);
        if ($items === []) {
            return null;
        }

        // 1. Match a unique user-defined `id` field.
        $byId = [];
        foreach ($items as $item) {
            if (!is_array($item) || !isset($item['id'])) {
                continue;
            }
            $id = $item['id'];
            if (is_int($id) || (is_string($id) && ctype_digit($id))) {
                $id = (int) $id;
                $byId[$id] = isset($byId[$id]) ? null : $item; // null marks ambiguity
            }
        }
        if (isset($byId[$ref]) && is_array($byId[$ref])) {
            $uid = self::uidOf($byId[$ref]);
            if ($uid !== null) {
                return $uid;
            }
        }

        // 2. Fall back to the 1-based array position.
        $positional = $items[$ref - 1] ?? null;
        if (is_array($positional)) {
            $uid = self::uidOf($positional);
            if ($uid !== null) {
                error_log("[RelationService] Migrated legacy reference {$targetKey}#{$ref} -> {$uid}");
                return $uid;
            }
        }

        error_log("[RelationService] Dropped unresolvable legacy reference {$targetKey}#{$ref}");
        return null;
    }

    // =========================================================================
    // DERIVED REVERSE INDEX (slot_relations)
    // =========================================================================

    /**
     * Rebuild the reverse index for one slot from its persisted content.
     *
     * Wholesale rebuild (DELETE by source_key + bulk INSERT) rather than
     * per-item patching: removed items, removed fields and reordered values are
     * all handled by construction, so the index can never drift.
     *
     * @param string $key    Slot key.
     * @param mixed  $data   The payload that was just saved (already normalised).
     * @param array|null $schema
     */
    public static function syncRelations(string $key, mixed $data, ?array $schema = null): void
    {
        $schema         = $schema ?? self::loadSchema();
        $relationFields = self::getRelationFields(self::getSlotFields($key, $schema));

        // Nothing declared: still clear stale rows (the field may have just been
        // removed from the schema).
        // Registry archives and per-value provenance still contribute retained references.
        $db = ContentDatabase::getInstance();

        try {
            $rows = [];

            if (is_array($data)) {
                $items = array_is_list($data) ? $data : [$data];

                foreach ($items as $item) {
                    if (!is_array($item)) {
                        continue;
                    }

                    // Object slots have no per-item UID — a stable sentinel keeps
                    // the index shape uniform across slot types.
                    $sourceUid = self::uidOf($item) ?? '__self__';

                    foreach (\NomadCMS\Services\Schema\SchemaValues::fields($db, $key, $sourceUid, $schema['slots'][$key] ?? []) as $field) {
                        if (!in_array($field['type'], ['relation', 'relation_many'], true)) {
                            continue;
                        }
                        $fieldId = $field['id'];
                        $targets = self::valueToLookupKeys($item[$fieldId] ?? null, $schema);

                        // 1-N carries at most one reference.
                        if ($field['type'] !== 'relation_many') {
                            $targets = array_slice($targets, 0, 1);
                        }

                        $order = 0;
                        foreach ($targets as $targetUid) {
                            $rows[] = [$key, $sourceUid, $field['target'], $targetUid, $fieldId, $order++];
                        }
                    }
                }
            }

            // Nested transactions are not supported by PDO/SQLite. syncRelations
            // may be called from inside a caller's transaction (migrations, repair
            // tooling), so only manage one if we opened it.
            $ownTransaction = !$db->inTransaction();
            if ($ownTransaction) {
                $db->beginTransaction();
            }

            $del = $db->prepare("DELETE FROM slot_relations WHERE source_key = ?");
            $del->execute([$key]);

            if ($rows !== []) {
                $ins = $db->prepare("
                    INSERT INTO slot_relations
                        (source_key, source_uid, target_key, target_uid, field_id, sort_order)
                    VALUES (?, ?, ?, ?, ?, ?)
                ");
                foreach ($rows as $row) {
                    $ins->execute($row);
                }
            }

            if ($ownTransaction) {
                $db->commit();
            }
        } catch (\Throwable $e) {
            if (!empty($ownTransaction) && $db->inTransaction()) {
                $db->rollBack();
            }
            // The index is derived — a failure here must never break the save.
            if (\NomadCMS\Services\Schema\SchemaProvider::initialized()) {
                throw $e;
            }
            error_log("[RelationService] syncRelations failed for '{$key}': " . $e->getMessage());
        }
    }

    /**
     * Forget a slot entirely: drop the index rows where it is the source AND the
     * rows where it is the target.
     *
     * Call this when a slot is deleted. Clearing only the source rows would leave
     * other slots' rows pointing at a slot that no longer exists, and every
     * subsequent reverse lookup would keep naming it as a dependent.
     *
     * @return int Number of index rows removed.
     */
    public static function forgetSlot(string $key): int
    {
        try {
            $db = ContentDatabase::getInstance();
            $stmt = $db->prepare("DELETE FROM slot_relations WHERE source_key = ? OR target_key = ?");
            $stmt->execute([$key, $key]);
            $removed = $stmt->rowCount();

            self::clearCache($key);

            return $removed;
        } catch (\Throwable $e) {
            error_log("[RelationService] forgetSlot failed for '{$key}': " . $e->getMessage());
            return 0;
        }
    }

    /**
     * Source slots that currently reference $targetKey, per the reverse index.
     *
     * @return string[]
     */
    public static function getSourceSlotsByTarget(string $targetKey): array
    {
        try {
            $db = ContentDatabase::getInstance();
            $stmt = $db->prepare("SELECT DISTINCT source_key FROM slot_relations WHERE target_key = ?");
            $stmt->execute([$targetKey]);
            return $stmt->fetchAll(PDO::FETCH_COLUMN, 0) ?: [];
        } catch (\Throwable $e) {
            error_log("[RelationService] getSourceSlotsByTarget failed: " . $e->getMessage());
            return [];
        }
    }

    /**
     * Source slots that declare a relation to $targetKey in the schema.
     *
     * Complements the index-based lookup: covers slots that declare a relation
     * but have not stored any value yet.
     *
     * @return string[]
     */
    public static function getSourceSlotsByTargetFromSchema(string $targetKey, ?array $schema = null): array
    {
        $schema  = $schema ?? self::loadSchema();
        $sources = [];

        foreach (($schema['slots'] ?? []) as $slotKey => $slotDef) {
            if (!is_array($slotDef)) {
                continue;
            }
            foreach (self::getRelationFields($slotDef['fields'] ?? []) as $field) {
                if ($field['target'] === $targetKey) {
                    $sources[] = (string) $slotKey;
                    break;
                }
            }
        }

        return array_values(array_unique($sources));
    }

    /**
     * Every slot affected by a change in $targetKey (index + schema, minus self).
     *
     * @return string[]
     */
    public static function getDependentSlots(string $targetKey, ?array $schema = null): array
    {
        $merged = array_merge(
            self::getSourceSlotsByTarget($targetKey),
            self::getSourceSlotsByTargetFromSchema($targetKey, $schema)
        );

        return array_values(array_filter(
            array_unique($merged),
            fn($slot) => $slot !== $targetKey && $slot !== ''
        ));
    }

    // =========================================================================
    // READ PATH
    // =========================================================================

    /**
     * Resolve every relation field of a slot payload, in place.
     *
     * Handles both shapes (list of items / single object) so callers do not have
     * to branch. Returns the payload unchanged when the slot declares no
     * relations, so it is cheap to call unconditionally.
     *
     * @param  string $key  Slot key.
     * @param  mixed  $data Slot payload.
     * @param  array|null $schema
     * @return mixed  Payload with `_<fieldId>` embeds added.
     */
    public static function resolveForSlot(string $key, mixed $data, ?array $schema = null, bool $includeBlocks = true): mixed
    {
        if (!is_array($data)) {
            return $data;
        }

        $schema         = $schema ?? self::loadSchema();
        $relationFields = self::getRelationFields(self::getSlotFields($key, $schema));

        if ($relationFields === []) {
            return $data;
        }

        $previous = self::$includeTargetBlocks;
        self::$includeTargetBlocks = $includeBlocks;
        try {
            if (array_is_list($data)) return self::resolveItems($data, $relationFields, $schema);
            $wrapped = self::resolveItems([$data], $relationFields, $schema);
            return $wrapped[0] ?? $data;
        } finally { self::$includeTargetBlocks = $previous; }
    }

    // =========================================================================
    // PUBLIC PROJECTION — what is allowed to leave the CMS
    // =========================================================================

    /**
     * Project a slot payload into its PUBLIC shape.
     *
     * This is the single gate every outgoing (public) path must go through:
     * the static cache generator and the public read branch of data.php. It is
     * what guarantees that no internal editor identity ever reaches a consumer
     * of this headless CMS.
     *
     * Three things happen, in this order:
     *
     *   1. RESOLVE   — relations are resolved exactly as for the admin path.
     *   2. MERGE     — the resolved embed replaces the raw uid IN PLACE, under
     *                  the field's own name. `_<fieldId>` disappears:
     *
     *                    internal: "szerzo": "aeb90b6207",
     *                              "_szerzo": { "nev": "..." }
     *                    public:   "szerzo": { "nev": "..." }
     *
     *                  An unresolvable reference becomes null (1-N) or drops out
     *                  of the list (N-N), so a declared field is always present
     *                  with a predictable type.
     *   3. STRIP     — `_dndId` and every other underscore-prefixed key are
     *                  removed recursively, at every depth.
     *
     * Why merge instead of keeping both: the raw uid IS the internal identity.
     * Keeping it next to the embed would defeat the whole purpose — it is the
     * value ("7cf80234db") that must not be published, not just the key name.
     *
     * NOTE ON EMBEDDED ITEMS: resolution is depth-1, so a relation field of an
     * embedded target item can never be resolved. Rather than publish its raw
     * uid, such a field is removed from the embed entirely. This is the one
     * deliberate exception to "a declared field is always present": at depth 2
     * no data could ever be provided for it.
     *
     * NOT AN INPUT FORMAT: the result is lossy on purpose — the uid is gone, so
     * feeding it back into normalizeForSave() would null every relation. Any code
     * that reads in order to write must use resolveForSlot() (the internal shape,
     * served by data.php?admin=1), never this.
     *
     * @param  string     $key    Slot key.
     * @param  mixed      $data   Slot payload (list of items, or single object).
     * @param  array|null $schema Parsed schema (loaded on demand).
     * @return mixed      Public payload.
     */
    public static function projectForPublic(string $key, mixed $data, ?array $schema = null, bool $includeBlocks = true): mixed
    {
        if (!is_array($data)) {
            return $data;
        }

        $schema         = $schema ?? self::loadSchema();
        $relationFields = self::getRelationFields(self::getSlotFields($key, $schema));

        if (\NomadCMS\Services\Schema\SchemaProvider::initialized()) {
            $archived = \NomadCMS\Services\Schema\SchemaProvider::archivedFields($key);
            $stripArchived = static function (array $item) use ($archived): array {
                foreach ($archived as $id) {
                    unset($item[$id]);
                }
                return $item;
            };
            $data = array_is_list($data) ? array_map($stripArchived, $data) : $stripArchived($data);
        }

        // Public list identity is derived, never accepted from a content field.
        // Keep the internal handle until resolution finishes, then strip it as usual.
        if (self::isPublicList($key, $schema)) {
            $project = static function (array $item) use ($key, $schema): array {
                $uid = self::uidOf($item);
                $item = array_intersect_key($item, array_fill_keys(
                    [...array_column(self::getSlotFields($key, $schema), 'id'), self::UID_KEY], true
                ));
                if ($uid !== null) {
                    $item['uid'] = $uid;
                }
                return $item;
            };
            $data = array_is_list($data) ? array_map($project, $data) : $project($data);
        }

        // 1. RESOLVE (no-op when the slot declares no relations).
        $previous = self::$publicTargets;
        self::$publicTargets = true;
        try { $data = self::resolveForSlot($key, $data, $schema, $includeBlocks); }
        finally { self::$publicTargets = $previous; }

        // 2. MERGE, per item.
        if (is_array($data) && $relationFields !== []) {
            if (array_is_list($data)) {
                foreach ($data as $idx => $item) {
                    if (is_array($item)) {
                        $data[$idx] = self::mergeEmbedsIntoFields($item, $relationFields, $schema, $key);
                    }
                }
            } else {
                $data = self::mergeEmbedsIntoFields($data, $relationFields, $schema, $key);
            }
        }

        // 3. STRIP every internal key that survived, at any depth.
        return self::stripInternalKeys($data);
    }

    /** Direct list access is opt-in; internal lists can still be embedded as before. */
    public static function isPublicList(string $key, ?array $schema = null): bool
    {
        $slot = ($schema ?? self::loadSchema())['slots'][$key] ?? [];
        return ($slot['type'] ?? '') === 'list' && ($slot['publicAccess'] ?? false) === true;
    }

    /**
     * Move each `_<fieldId>` embed onto `<fieldId>`, replacing the raw uid.
     *
     * @param array $item
     * @param array $relationFields Relation fields of the item's own slot.
     * @param array $schema
     */
    private static function mergeEmbedsIntoFields(array $item, array $relationFields, array $schema, string $key): array
    {
        foreach ($relationFields as $field) {
            $origin = \NomadCMS\Services\Schema\SchemaValues::definition(ContentDatabase::getInstance(), $key, self::uidOf($item) ?? '__self__', $field);
            if (\NomadCMS\Services\Schema\SchemaValues::interpretationChanged($origin, $field)) {
                unset($item[self::embedKey($field['id'])]);
                continue;
            }

            $fieldId  = $field['id'];
            $embedKey = self::embedKey($fieldId);
            $isMany   = $field['type'] === 'relation_many';

            // The embed is authoritative: resolveItems() always sets it for a
            // declared field (null / [] when nothing resolved).
            if (array_key_exists($embedKey, $item)) {
                $resolved = $item[$embedKey];
                unset($item[$embedKey]);
            } else {
                $resolved = $isMany ? [] : null;
            }

            if ($isMany) {
                $resolved = is_array($resolved) ? array_values($resolved) : [];
            }

            // Strip the relation fields of the EMBEDDED slot: at depth-1 they
            // hold nothing but unresolvable uids.
            $targetFields = self::getRelationFields(self::getSlotFields($field['target'], $schema));
            if ($targetFields !== []) {
                if ($isMany) {
                    foreach ($resolved as $i => $embedded) {
                        if (is_array($embedded)) {
                            $resolved[$i] = self::stripRelationFields($embedded, $targetFields);
                        }
                    }
                } elseif (is_array($resolved)) {
                    $resolved = self::stripRelationFields($resolved, $targetFields);
                }
            }

            $item[$fieldId] = $resolved;
        }

        return $item;
    }

    /**
     * Remove the given relation fields (raw value and embed) from an item.
     */
    private static function stripRelationFields(array $item, array $relationFields): array
    {
        foreach ($relationFields as $field) {
            unset($item[$field['id']], $item[self::embedKey($field['id'])]);
        }

        return $item;
    }

    /**
     * Recursively drop every underscore-prefixed key.
     *
     * Covers `_dndId`, leftover `_<fieldId>` embeds from slots whose schema has
     * since changed, and any editor-only flag (`_isPending`, `_dirty`, ...).
     * Nothing prefixed with "_" is public, so this needs no allow-list.
     */
    private static function stripInternalKeys(mixed $data): mixed
    {
        if (!is_array($data)) {
            return $data;
        }

        if (array_is_list($data)) {
            return array_map([self::class, 'stripInternalKeys'], $data);
        }

        $out = [];
        foreach ($data as $key => $value) {
            if (is_string($key) && str_starts_with($key, '_') && strlen($key) > 1) {
                continue;
            }
            $out[$key] = self::stripInternalKeys($value);
        }

        return $out;
    }

    /**
     * Embed resolved relation data into a list of items.
     *
     * One target-slot read per relation field (memoised per request), regardless
     * of how many items reference it — no JOIN, no N+1.
     *
     * @param  array $items          List of item arrays.
     * @param  array $relationFields Already validated relation field defs.
     * @return array
     */
    public static function resolveItems(array $items, array $relationFields, ?array $schema = null): array
    {
        if ($items === [] || $relationFields === []) {
            return $items;
        }

        $schema = $schema ?? self::loadSchema();

        foreach ($relationFields as $field) {
            $fieldId     = $field['id'];
            $targetKey   = $field['target'];
            $isMany      = $field['type'] === 'relation_many';
            $embedKey    = self::embedKey($fieldId);
            $embedFields = self::getEmbedFields($field);

            $requested = [];
            foreach ($items as $item) if (is_array($item)) {
                foreach (self::valueToLookupKeys($item[$fieldId] ?? null, $schema) as $uid) $requested[] = $uid;
            }
            $targetMap = self::loadTargetMap($targetKey, $schema, $embedFields, $requested);

            foreach ($items as $idx => $item) {
                if (!is_array($item)) {
                    continue;
                }

                $raw = $item[$fieldId] ?? null;

                if ($isMany) {
                    $resolved = [];
                    foreach (self::valueToLookupKeys($raw, $schema) as $uid) {
                        if (isset($targetMap[$uid])) {
                            $resolved[] = $targetMap[$uid];
                        }
                    }
                    $items[$idx][$embedKey] = $resolved;
                    continue;
                }

                $uid = self::valueToLookupKeys($raw, $schema)[0] ?? null;
                if ($uid !== null && isset($targetMap[$uid])) {
                    $items[$idx][$embedKey] = $targetMap[$uid];
                } else {
                    // Explicit null instead of a missing key: consumers can rely
                    // on the embed always being present for a declared field.
                    $items[$idx][$embedKey] = null;
                }
            }
        }

        return $items;
    }

    /**
     * Flatten any stored relation value into a list of lookup keys.
     *
     * Read-tolerant on purpose: content that predates the current write path may
     * still hold a single value, a legacy numeric reference, a whole target item,
     * or a language-keyed map (from a relation field wrongly marked localized).
     * All of those must still resolve, so they display correctly and the user can
     * re-save them into canonical shape.
     *
     * @return string[]
     */
    private static function valueToLookupKeys(mixed $raw, array $schema): array
    {
        if ($raw === null || $raw === '' || $raw === []) {
            return [];
        }

        if (is_array($raw)) {
            // A whole target item.
            $uid = self::uidOf($raw);
            if ($uid !== null) {
                return [$uid];
            }

            if (!array_is_list($raw)) {
                $unwrapped = self::unwrapLocalized($raw, $schema);
                return $unwrapped !== null ? self::valueToLookupKeys($unwrapped, $schema) : [];
            }

            $out  = [];
            $seen = [];
            foreach ($raw as $entry) {
                foreach (self::valueToLookupKeys($entry, $schema) as $key) {
                    if (!isset($seen[$key])) {
                        $seen[$key] = true;
                        $out[] = $key;
                    }
                }
            }
            return $out;
        }

        $key = self::normaliseLookupKey($raw);
        return $key !== null ? [$key] : [];
    }

    /**
     * Cast a stored relation value into a target-map lookup key.
     */
    private static function normaliseLookupKey(mixed $value): ?string
    {
        if (is_string($value)) {
            $value = trim($value);
            return $value === '' ? null : $value;
        }
        if (is_int($value) || is_float($value)) {
            return (string) $value;
        }
        if (is_array($value)) {
            return self::uidOf($value);
        }
        return null;
    }

    // =========================================================================
    // TARGET LOADING
    // =========================================================================

    /**
     * Raw item list of a target slot (no UID guarantees, no cleaning).
     *
     * @return array List of item arrays; empty when the slot is missing or is
     *               not an itemised slot.
     */
    private static function loadTargetList(string $slotKey, array $schema): array
    {
        try {
            $data = ContentDatabase::getSlot($slotKey);
        } catch (\Throwable $e) {
            if (in_array($e->getCode(), [409, 410, 503], true)) {
                throw $e;
            }
            error_log("[RelationService] Failed to load target slot '{$slotKey}': " . $e->getMessage());
            return [];
        }

        if (!is_array($data) || !array_is_list($data)) {
            return [];
        }

        return $data;
    }

    /**
     * Lookup map of a target slot: uid => embeddable item.
     *
     * Items are cleaned for embedding (internal keys and their own relation
     * embeds removed) which is what keeps resolution depth-1 and makes circular
     * relations safe. Legacy aliases (unique `id`, 1-based position) are added
     * so content that has not been re-saved yet still resolves.
     *
     * @param  string   $slotKey
     * @param  array    $schema
     * @param  string[] $embedFields Projection; empty means all fields.
     * @return array<string, array>
     */
    private static function loadTargetMap(string $slotKey, array $schema, array $embedFields = [], array $requested = []): array
    {
        if (\NomadCMS\Database\CollectionDatabase::isRegistered($slotKey)) {
            $map = [];
            $targets = \NomadCMS\Database\CollectionDatabase::getMany($slotKey, $requested, self::$includeTargetBlocks);
            $fields = self::getRelationFields(self::getSlotFields($slotKey, $schema));
            foreach ($requested as $uid) {
                $item = $targets['uid:' . $uid] ?? null;
                if (!$item && ctype_digit((string)$uid)) $item = \NomadCMS\Database\CollectionDatabase::findByIdentifier($slotKey, (string)$uid, self::$includeTargetBlocks);
                if (!$item || (self::$publicTargets && !PublicPayloadService::isItemPublished($schema['slots'][$slotKey] ?? [], $item))) continue;
                if (self::$publicTargets) $item = array_intersect_key($item, array_fill_keys(array_column(self::getSlotFields($slotKey, $schema),'id'), true));
                $map[$uid] = self::cleanForEmbed($item, $fields, $embedFields);
            }
            return $map;
        }
        // The projection is part of the cache identity: the same slot may be
        // referenced by two fields asking for different subsets.
        $cacheKey = $embedFields === []
            ? $slotKey
            : $slotKey . '|' . implode(',', $embedFields);
        $cacheKey .= '|' . (int)self::$publicTargets . '|' . (int)self::$includeTargetBlocks;

        if (isset(self::$targetCache[$cacheKey])) {
            return self::$targetCache[$cacheKey];
        }

        $items          = self::loadTargetList($slotKey, $schema);
        $relationFields = self::getRelationFields(self::getSlotFields($slotKey, $schema));

        $map        = [];
        $idAliases  = [];
        $posAliases = [];

        foreach ($items as $idx => $item) {
            if (!is_array($item)) {
                continue;
            }

            if (self::$publicTargets && !PublicPayloadService::isItemPublished($schema['slots'][$slotKey] ?? [], $item)) continue;
            // Capture identity before public field filtering; it is needed to
            // resolve opaque references even though it must not leave the CMS.
            $uid = self::uidOf($item);
            if (self::$publicTargets) $item = array_intersect_key($item, array_fill_keys(array_column(self::getSlotFields($slotKey, $schema),'id'), true));

            if (!self::$includeTargetBlocks) foreach (self::getSlotFields($slotKey,$schema) as $field) if (in_array($field['type']??'', ['blocks','gutenberg'],true)) unset($item[$field['id']]);
            $clean = self::cleanForEmbed($item, $relationFields, $embedFields);
            if (self::$publicTargets && self::isPublicList($slotKey, $schema) && $uid !== null) {
                $clean['uid'] = $uid;
            }

            if ($uid !== null) {
                $map[$uid] = $clean;
            }

            // Legacy alias: unique numeric `id` field.
            if (isset($item['id'])) {
                $id = $item['id'];
                if (is_int($id) || (is_string($id) && ctype_digit($id))) {
                    $id = (string) (int) $id;
                    $idAliases[$id] = array_key_exists($id, $idAliases) ? null : $clean;
                }
            }

            // Legacy alias: 1-based array position.
            $posAliases[(string) ($idx + 1)] = $clean;
        }

        // Aliases must never shadow a real UID.
        foreach ([$idAliases, $posAliases] as $aliases) {
            foreach ($aliases as $alias => $clean) {
                if (is_array($clean) && !isset($map[$alias])) {
                    $map[$alias] = $clean;
                }
            }
        }

        return self::$targetCache[$cacheKey] = $map;
    }

    /**
     * Prepare a target item for embedding: keep its identity and the requested
     * content, drop UI state and its own relation embeds.
     *
     * @param array    $item
     * @param array    $relationFields Relation fields of the *target* slot.
     * @param string[] $embedFields    Projection; empty means all fields.
     */
    private static function cleanForEmbed(array $item, array $relationFields, array $embedFields = []): array
    {
        // Projection first — it is the cheapest filter and makes the rest a no-op
        // for anything it already excluded.
        //
        // NOTE: the item's own UID (_dndId) is intentionally NOT carried into the
        // embed. It is an internal CMS identity used to correlate relation values
        // (e.g. "szerzo": "<uid>") with the target row while data stays inside the
        // CMS. Once content is embedded into an API response or the static cache
        // — i.e. the moment it can leave the CMS — that identity is bloat/leakage
        // for a headless consumer and must not be present. Callers correlate via
        // the raw relation value that already sits next to the embed.
        if ($embedFields !== []) {
            $projected = [];

            foreach ($embedFields as $fieldId) {
                if (array_key_exists($fieldId, $item)) {
                    $projected[$fieldId] = $item[$fieldId];
                }
            }

            $item = $projected;
        }

        foreach ($relationFields as $field) {
            unset($item[self::embedKey($field['id'])]);
        }

        foreach (self::EMBED_STRIP_KEYS as $key) {
            unset($item[$key]);
        }

        // Strip the item's own identity — never leaves the CMS.
        unset($item[self::UID_KEY]);

        // Defensive: remove any other underscore-prefixed / internal-looking key
        // that a previous version of this service (or the editor) may have
        // persisted into the content. Nothing prefixed with "_" is public.
        foreach (array_keys($item) as $key) {
            if (is_string($key) && str_starts_with($key, '_') && strlen($key) > 1) {
                unset($item[$key]);
            }
        }

        return $item;
    }

    // =========================================================================
    // DIAGNOSTICS
    // =========================================================================

    /**
     * Audit every relation in the schema and report what is inconsistent.
     *
     * Read-only. Deliberately reports rather than repairs: a dangling reference is
     * usually the symptom of a deletion the editor may want to undo, and silently
     * erasing the link would destroy the only evidence of intent.
     *
     * Checks:
     *   missing_target     relation points at a slot that is not in the schema
     *   bad_target_type    target slot has no per-item identity (object/massive)
     *   missing_uid        list/collection item without an identity
     *   duplicate_uid      two items in one slot share an identity
     *   dangling           reference to an item that no longer exists
     *   index_drift        reverse index disagrees with the stored content
     *   self_link          item references itself (legal, but usually unintended)
     *
     * @return array{issues: array<int, array>, counts: array<string, int>, ok: bool}
     */
    public static function diagnose(?array $schema = null): array
    {
        $schema = $schema ?? self::loadSchema();
        $slots  = $schema['slots'] ?? [];
        $issues = [];

        $add = function (string $type, string $slot, string $detail, array $extra = []) use (&$issues): void {
            $issues[] = array_merge(['type' => $type, 'slot' => $slot, 'detail' => $detail], $extra);
        };

        // --- identity integrity, per slot -----------------------------------
        foreach ($slots as $slotKey => $slotDef) {
            $slotKey = (string) $slotKey;
            if (!is_array($slotDef) || !self::isItemisedSlot($slotKey, $schema)) {
                continue;
            }

            try {
                $data = ContentDatabase::getSlot($slotKey);
            } catch (\Throwable $e) {
                $add('unreadable', $slotKey, 'slot could not be read: ' . $e->getMessage());
                continue;
            }
            if (!is_array($data) || !array_is_list($data)) {
                continue;
            }

            $seen = [];
            foreach ($data as $idx => $item) {
                if (!is_array($item)) {
                    continue;
                }
                $uid = self::uidOf($item);
                if ($uid === null) {
                    $add('missing_uid', $slotKey, "item #{$idx} has no " . self::UID_KEY, ['index' => $idx]);
                    continue;
                }
                if (isset($seen[$uid])) {
                    $add('duplicate_uid', $slotKey, "item #{$idx} reuses uid {$uid}", ['index' => $idx, 'uid' => $uid]);
                }
                $seen[$uid] = true;
            }
        }

        // --- relation integrity ---------------------------------------------
        $expectedIndex = [];

        foreach ($slots as $slotKey => $slotDef) {
            $slotKey        = (string) $slotKey;
            $relationFields = self::getRelationFields($slotDef['fields'] ?? []);
            if ($relationFields === []) {
                continue;
            }

            try {
                $data = ContentDatabase::getSlot($slotKey);
            } catch (\Throwable) {
                continue;
            }
            if (!is_array($data)) {
                continue;
            }

            $items = array_is_list($data) ? $data : [$data];

            foreach ($relationFields as $field) {
                $fieldId   = $field['id'];
                $targetKey = $field['target'];

                if (!isset($slots[$targetKey])) {
                    $add('missing_target', $slotKey, "{$fieldId} → '{$targetKey}' is not in the schema", [
                        'field' => $fieldId, 'target' => $targetKey,
                    ]);
                    continue;
                }
                if (!self::isItemisedSlot($targetKey, $schema)) {
                    $add('bad_target_type', $slotKey, "{$fieldId} → '{$targetKey}' is "
                        . self::getSlotType($targetKey, $schema) . ", which has no per-item identity", [
                        'field' => $fieldId, 'target' => $targetKey,
                    ]);
                    continue;
                }

                $targetMap = self::loadTargetMap($targetKey, $schema);

                foreach ($items as $item) {
                    if (!is_array($item)) {
                        continue;
                    }
                    $sourceUid = self::uidOf($item) ?? '__self__';

                    foreach (self::valueToLookupKeys($item[$fieldId] ?? null, $schema) as $targetUid) {
                        // The index records what the CONTENT says, whether or not the
                        // target still exists — so a dangling reference must be
                        // counted as expected here. Otherwise every deletion would
                        // also be reported as index drift, and the two findings
                        // would be indistinguishable.
                        $expectedIndex["{$slotKey}\0{$sourceUid}\0{$fieldId}\0{$targetUid}"] = true;

                        if (!isset($targetMap[$targetUid])) {
                            $add('dangling', $slotKey, "{$fieldId} → {$targetKey}:{$targetUid} no longer exists", [
                                'field' => $fieldId, 'target' => $targetKey,
                                'source_uid' => $sourceUid, 'target_uid' => $targetUid,
                            ]);
                            continue;
                        }
                        if ($targetKey === $slotKey && $targetUid === $sourceUid) {
                            $add('self_link', $slotKey, "{$fieldId} on {$sourceUid} references itself", [
                                'field' => $fieldId, 'source_uid' => $sourceUid,
                            ]);
                        }
                    }
                }
            }
        }

        // --- reverse index drift --------------------------------------------
        try {
            $db = ContentDatabase::getInstance();
            $actual = [];
            $stmt = $db->query("SELECT source_key, source_uid, field_id, target_uid FROM slot_relations");
            foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
                $actual["{$row['source_key']}\0{$row['source_uid']}\0{$row['field_id']}\0{$row['target_uid']}"] = $row;
            }

            foreach (array_diff_key($actual, $expectedIndex) as $row) {
                $add('index_drift', $row['source_key'],
                    "index has {$row['field_id']} → {$row['target_uid']} but the content does not", [
                        'field' => $row['field_id'], 'target_uid' => $row['target_uid'], 'direction' => 'stale',
                    ]);
            }
            foreach (array_keys(array_diff_key($expectedIndex, $actual)) as $composite) {
                [$src, $srcUid, $fieldId, $tgtUid] = explode("\0", $composite);
                $add('index_drift', $src,
                    "content has {$fieldId} → {$tgtUid} but the index does not", [
                        'field' => $fieldId, 'target_uid' => $tgtUid, 'direction' => 'missing',
                    ]);
            }
        } catch (\Throwable $e) {
            $add('unreadable', '-', 'reverse index could not be read: ' . $e->getMessage());
        }

        $counts = [];
        foreach ($issues as $issue) {
            $counts[$issue['type']] = ($counts[$issue['type']] ?? 0) + 1;
        }

        // A self link is legal; it never makes the system inconsistent.
        $blocking = array_diff_key($counts, ['self_link' => true]);

        return ['issues' => $issues, 'counts' => $counts, 'ok' => $blocking === []];
    }

    /**
     * Re-derive what can be re-derived: item identities and the reverse index.
     *
     * Does NOT delete dangling references — use pruneDanglingReferences() for that,
     * as an explicit, separate decision.
     *
     * @return array{slots_resaved: string[], index_rebuilt: string[]}
     */
    public static function repair(?array $schema = null): array
    {
        $schema = $schema ?? self::loadSchema();
        $slots  = $schema['slots'] ?? [];

        $resaved = [];
        $rebuilt = [];

        foreach ($slots as $slotKey => $slotDef) {
            $slotKey = (string) $slotKey;
            $type    = $slotDef['type'] ?? 'object';
            if ($type === 'massive') {
                continue;
            }

            try {
                $before = ContentDatabase::getSlot($slotKey);
            } catch (\Throwable) {
                continue;
            }
            if (!is_array($before)) {
                continue;
            }

            $after = self::normalizeForSave($slotKey, $before, $schema);

            if ($after !== $before) {
                try {
                    ContentDatabase::saveSlot($slotKey, $after, [
                        'skip_versioning' => true,
                        'bypass_lock'     => true,
                        'slot_type'       => $type,
                        'changed_by'      => 'relation-repair',
                    ]);
                    $resaved[] = $slotKey;
                } catch (\Throwable $e) {
                    error_log("[RelationService] repair save failed for '{$slotKey}': " . $e->getMessage());
                    continue;
                }
            }

            self::clearCache($slotKey);
            self::syncRelations($slotKey, $after, $schema);
            $rebuilt[] = $slotKey;
        }

        // Index rows belonging to slots that are no longer in the schema.
        try {
            $db = ContentDatabase::getInstance();
            $known = array_map('strval', array_keys($slots));
            $rows = $db->query("SELECT DISTINCT source_key FROM slot_relations")->fetchAll(PDO::FETCH_COLUMN, 0);
            foreach ($rows as $orphanKey) {
                if (!in_array((string) $orphanKey, $known, true)) {
                    self::forgetSlot((string) $orphanKey);
                }
            }
        } catch (\Throwable $e) {
            error_log("[RelationService] repair orphan sweep failed: " . $e->getMessage());
        }

        self::clearCache();

        return ['slots_resaved' => $resaved, 'index_rebuilt' => $rebuilt];
    }

    // =========================================================================
    // MAINTENANCE
    // =========================================================================

    /**
     * Remove references to items that no longer exist, across all slots.
     *
     * Resolution already skips dangling UIDs, so this is housekeeping rather
     * than a correctness requirement. Returns a per-slot report of the pruned
     * reference counts.
     *
     * @param  bool  $apply  When false, only report what would change.
     * @return array<string, int>
     */
    public static function pruneDanglingReferences(bool $apply = true): array
    {
        $schema = self::loadSchema();
        $report = [];

        foreach (($schema['slots'] ?? []) as $slotKey => $slotDef) {
            $slotKey        = (string) $slotKey;
            $relationFields = self::getRelationFields($slotDef['fields'] ?? []);
            if ($relationFields === []) {
                continue;
            }

            try {
                $data = ContentDatabase::getSlot($slotKey);
            } catch (\Throwable) {
                continue;
            }
            if (!is_array($data)) {
                continue;
            }

            $isList  = array_is_list($data);
            $items   = $isList ? $data : [$data];
            $pruned  = 0;

            foreach ($items as $idx => $item) {
                if (!is_array($item)) {
                    continue;
                }

                foreach ($relationFields as $field) {
                    $fieldId = $field['id'];
                    if (!array_key_exists($fieldId, $item)) {
                        continue;
                    }

                    $targetMap = self::loadTargetMap($field['target'], $schema);

                    if ($field['type'] === 'relation_many') {
                        $before = is_array($item[$fieldId]) ? $item[$fieldId] : [];
                        $after  = array_values(array_filter(
                            $before,
                            fn($uid) => is_string($uid) && isset($targetMap[$uid])
                        ));
                        if (count($after) !== count($before)) {
                            $pruned += count($before) - count($after);
                            $items[$idx][$fieldId] = $after;
                        }
                        continue;
                    }

                    $uid = $item[$fieldId] ?? null;
                    if ($uid !== null && $uid !== '' && !(is_string($uid) && isset($targetMap[$uid]))) {
                        $pruned++;
                        $items[$idx][$fieldId] = null;
                    }
                }
            }

            if ($pruned > 0) {
                $report[$slotKey] = $pruned;

                if ($apply) {
                    $payload = $isList ? $items : ($items[0] ?? $data);
                    try {
                        ContentDatabase::saveSlot($slotKey, $payload, [
                            'skip_versioning' => true,
                            'bypass_lock'     => true,
                            'changed_by'      => 'relation-prune',
                        ]);
                        self::clearCache($slotKey);
                        self::syncRelations($slotKey, $payload, $schema);
                    } catch (\Throwable $e) {
                        error_log("[RelationService] Prune failed for '{$slotKey}': " . $e->getMessage());
                    }
                }
            }
        }

        return $report;
    }
}
