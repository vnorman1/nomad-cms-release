<?php
/**
 * NOMAD CMS - Installer Service
 * Handles secure one-click installation with atomic operations
 * 
 * Security Features:
 * - Cryptographically secure key generation (256-bit hex keys)
 * - Defuse Crypto for ENCRYPTION_KEY
 * - Argon2id password hashing via UserRepository
 * - SHA256 lock file integrity verification
 * - No credentials stored in .env
 */

declare(strict_types=1);

namespace NomadCMS\Installer;

use NomadCMS\Database\UserRepository;
use NomadCMS\Database\AuthDatabase;
use Defuse\Crypto\Key;

final class InstallerService
{
    /**
     * Lock file name - placed in api/ root
     */
    private const LOCK_FILE = 'nomad-install.lock';
    
    /**
     * Required environment variables for a fresh install
     */
    private const REQUIRED_ENV_VARS = [
        'APP_ENV',
        'APP_DEBUG',
        'APP_URL',
        'JWT_SECRET',
        'JWT_ALGORITHM',
        'ENCRYPTION_KEY',
        'PASSWORD_PEPPER',
        'SALT_PREFIX',
        'VERSIONING_HMAC_SECRET',
    ];

    /**
     * Check if installation is required
     * Returns true if NOT installed (needs installation)
     */
    public static function isInstalled(): bool
    {
        $lockPath = self::getLockFilePath();
        
        if (!file_exists($lockPath)) {
            return false;
        }
        
        // Validate lock file integrity
        return self::validateLockFile();
    }

    /**
     * Get the lock file path
     */
    private static function getLockFilePath(): string
    {
        return dirname(__DIR__, 2) . '/' . self::LOCK_FILE;
    }

    /**
     * Get lock file data if exists
     */
    public static function getLockFileData(): ?array
    {
        $lockPath = self::getLockFilePath();
        
        if (!file_exists($lockPath)) {
            return null;
        }
        
        $content = file_get_contents($lockPath);
        if ($content === false) {
            return null;
        }
        
        return json_decode($content, true);
    }

    /**
     * Generate cryptographically secure .env file
     */
    public static function generateEnvironmentFile(array $config): bool
    {
        $envPath = dirname(__DIR__, 2) . '/.env';
        
        // Get user entropy if provided (already SHA-256 hashed client-side)
        $userEntropy = $config['user_entropy'] ?? null;

        // Analytics module install-time choice (optional install wizard step -
        // see InstallPage.tsx's Analytics toggle). Defaults match the module's
        // own hard defaults (AnalyticsSchema::DEFAULT_RETENTION_DAILY_DAYS=0,
        // enabled=true) so an install that skips the wizard step entirely still
        // gets a sensible, privacy-respecting configuration.
        $analyticsEnabled = ($config['analytics_enabled'] ?? true) ? 'true' : 'false';
        $analyticsRetentionDailyDays = max(
            \NomadCMS\Services\Analytics\AnalyticsSchema::MIN_RETENTION_DAILY_DAYS,
            min(
                \NomadCMS\Services\Analytics\AnalyticsSchema::MAX_RETENTION_DAILY_DAYS,
                (int) ($config['analytics_retention_daily_days'] ?? \NomadCMS\Services\Analytics\AnalyticsSchema::DEFAULT_RETENTION_DAILY_DAYS)
            )
        );

        // Cloudflare proxy toggle (defaults to false for fresh installations unless explicitly enabled)
        $cloudflareProxy = (!empty($config['cloudflare_proxy']) && filter_var($config['cloudflare_proxy'], FILTER_VALIDATE_BOOLEAN)) ? 'true' : 'false';
        
        // Generate RSA key pair for asymmetric JWT (RS256)
        if (!self::generateRSAKeyPair()) {
            error_log('[Install] Failed to generate RSA key pair');
            return false;
        }
        
        // Generate secure random keys with optional user entropy mixing
        $jwtSecret = self::generateEntropyMixedSecret(32, $userEntropy); // 256-bit hex (64 chars)
        $passwordPepper = self::generateEntropyMixedSecret(32, $userEntropy); // 256-bit hex
        $saltPrefix = self::generateEntropyMixedSecret(16, $userEntropy); // 128-bit hex
        $sessionSecret = self::generateEntropyMixedSecret(32, $userEntropy); // For session encryption
        $ipHashSecret = self::generateEntropyMixedSecret(32, $userEntropy); // For IP hashing (HMAC)
        $versioningHmacSecret = self::generateEntropyMixedSecret(32, $userEntropy); // For versioning HMAC
        $updateProgressSecret = self::generateEntropyMixedSecret(32, $userEntropy); // For update progress HMAC
        
        // Generate Defuse encryption key (uses its own secure random generation)
        $encryptionKey = Key::createNewRandomKey()->saveToAsciiSafeString();
        
        // Generate Blind Index Key (32 bytes hex) for searchable encryption
        $blindIndexKey = self::generateEntropyMixedSecret(32, $userEntropy);
        
        // Build .env content
        $siteUrl = !empty($config['site_url']) ? $config['site_url'] : ($config['app_url'] ?? 'http://localhost');
        $envContent = <<<ENV
# ============================================
# NOMAD CMS - Production Environment
# ============================================
# Generated: {$config['timestamp']}
# WARNING: Keep this file secure and never commit to version control!

# ----------------
# Application
# ----------------
APP_ENV=production
APP_DEBUG=false
APP_URL={$config['app_url']}
SITE_URL={$siteUrl}
# Where the React admin UI is served from. Used by the e-mail configuration
# confirmation link to redirect back to /mails after a successful verification,
# and by form-submission notification e-mails to link back to the form's inbox
# (see MailUrlResolver::adminBaseUrl()).
#
# Mandatory since this was collected explicitly during installation - the CMS
# always knows its own admin route this way, regardless of whether it lives on
# the same origin as the API or on its own domain/subdomain. Only absolute
# http(s) URLs are accepted, so a typo here cannot become an open redirect: an
# unparseable value is ignored rather than followed.
ADMIN_URL={$config['admin_url']}
ALLOW_SVG_UPLOAD=true

# ----------------
# JWT Configuration (RS256 - Asymmetric)
# ----------------
JWT_ALGORITHM=RS256
JWT_PRIVATE_KEY_PATH=keys/private.pem
JWT_PUBLIC_KEY_PATH=keys/public.pem
JWT_SECRET={$jwtSecret}
JWT_ACCESS_TOKEN_TTL=900
JWT_REFRESH_TOKEN_TTL=604800
JWT_ISSUER=nomad-cms
JWT_AUDIENCE=nomad-cms-frontend

# ----------------
# WebAuthn (FIDO2)
# ----------------
WEBAUTHN_RP_NAME="NOMAD CMS"
WEBAUTHN_RP_ID={$config['webauthn_rp_id']}
WEBAUTHN_RP_ORIGIN={$config['webauthn_rp_origin']}
WEBAUTHN_TIMEOUT=60000
WEBAUTHN_USER_VERIFICATION=preferred

# ----------------
# TOTP (2FA)
# ----------------
TOTP_ISSUER="NOMAD CMS"
TOTP_DIGITS=6
TOTP_PERIOD=30
TOTP_ALGORITHM=sha256

# ----------------
# Encryption (Defuse Crypto)
# ----------------
ENCRYPTION_KEY={$encryptionKey}
# BLIND_INDEX_KEY is used for searchable encryption (Massive Data, Forms)
# It allows searching encrypted data without decrypting it
BLIND_INDEX_KEY={$blindIndexKey}

# ----------------
# Database (Split Architecture)
# ----------------
DB_CONNECTION=sqlite
DB_SYSTEM_DATABASE=system.sqlite
DB_CONTENT_DATABASE=database.sqlite
DB_MASSIVE_DATABASE=massive.sqlite

# ----------------
# Password Security
# ----------------
PASSWORD_PEPPER={$passwordPepper}
PASSWORD_SALT_PREFIX={$saltPrefix}
IP_HASH_SECRET={$ipHashSecret}
PASSWORD_MEMORY_COST=65536
PASSWORD_TIME_COST=4
PASSWORD_THREADS=3

# ----------------
# Account Security
# ----------------
ACCOUNT_MAX_FAILED_ATTEMPTS=5
ACCOUNT_LOCK_DURATION=900

# ----------------
# Session Security
# ----------------
SESSION_LIFETIME=7200
SESSION_SECURE_COOKIE=true
SESSION_HTTP_ONLY=true
SESSION_SAME_SITE=Strict
SESSION_SECRET={$sessionSecret}
# IP binding mode: subnet (default, /24 IPv4 or /48 IPv6), disabled (roaming/NAT/SaaS), strict (exact IP)
AUTH_IP_BINDING=subnet

# ----------------
# CORS Configuration
# ----------------
CORS_ALLOWED_ORIGINS={$config['cors_origins']}
CORS_ALLOWED_METHODS=GET,POST,PUT,DELETE,OPTIONS
CORS_ALLOWED_HEADERS=Content-Type,Authorization,X-ADMIN-TOKEN,X-CSRF-TOKEN,X-API-KEY
CORS_MAX_AGE=86400

# ----------------
# Rate Limiting
# ----------------
RATE_LIMIT_ENABLED=true
RATE_LIMIT_MAX_REQUESTS=300
RATE_LIMIT_WINDOW_SECONDS=60
TRUSTED_PROXIES=
CLOUDFLARE_PROXY={$cloudflareProxy}

# ----------------
# Public API Rate Limits (generous defaults for public-facing endpoints)
# ----------------
PUBLIC_API_RATE_LIMIT_MAX=200
PUBLIC_API_RATE_LIMIT_WINDOW=60
STATIC_SERVE_RATE_LIMIT_MAX=300
STATIC_SERVE_RATE_LIMIT_WINDOW=60

# ----------------
# Auth Rate Limits
# ----------------
AUTH_RATE_LIMIT_LOGIN=10
AUTH_RATE_LIMIT_LOGIN_WINDOW=300
AUTH_RATE_LIMIT_TOTP=5
AUTH_RATE_LIMIT_TOTP_WINDOW=60
AUTH_RATE_LIMIT_PASSWORD_RESET=3
AUTH_RATE_LIMIT_PASSWORD_RESET_WINDOW=3600
AUTH_RATE_LIMIT_REGISTRATION=5
AUTH_RATE_LIMIT_REGISTRATION_WINDOW=3600
AUTH_RATE_LIMIT_MAGIC_LINK=30
AUTH_RATE_LIMIT_MAGIC_LINK_WINDOW=300

# ----------------
# Feature Toggles
# ----------------
AUTH_TOTP_ENABLED=true
AUTH_WEBAUTHN_ENABLED=true
AUTH_PASSWORD_ENABLED=true
AUTH_REGISTRATION_ENABLED=false
AUTH_REQUIRE_EMAIL_VERIFICATION=false

# ----------------
# File Storage
# ----------------
# Directories are resolved automatically by the API relative to installation root
MAX_UPLOAD_SIZE_MB=100
MAX_UPLOAD_WIDTH=5000
WEBP_QUALITY=90

# ----------------
# Logging
# ----------------
LOG_CHANNEL=file
LOG_LEVEL=warning
LOG_MAX_SIZE=3

# Webhooks (HMAC-Secured)
# ----------------
# Enable outgoing webhooks (CMS → external services)
WEBHOOKS_OUTGOING_ENABLED=true
# Enable incoming webhooks (external services → CMS)
WEBHOOKS_INCOMING_ENABLED=true
# HMAC signature tolerance window (seconds, for replay protection)
# Default: 300 (5 minutes) - matches industry standard
WEBHOOK_SIGNATURE_TOLERANCE=300
# Max retry attempts for failed webhook deliveries
WEBHOOK_MAX_RETRIES=3
# Retry delay multiplier (exponential backoff: 2^attempts * 60 seconds)
WEBHOOK_RETRY_DELAY_MULTIPLIER=2
# Enable piggyback delivery of queued webhooks (processes pending deliveries on
# regular API requests instead of needing cron/daemon access) - same mechanism
# as FORGE_PIGGYBACK_PROCESSING and FORMS_PIGGYBACK_PROCESSING below.
WEBHOOK_PIGGYBACK_PROCESSING=true

# ----------------
# Versioning (Git-like History)
# ----------------
# HMAC secret for versioning integrity verification
# Used to sign version records and prevent tampering
VERSIONING_HMAC_SECRET={$versioningHmacSecret}
# Note: maxVersions and retentionDays are managed via Admin UI (CacheTab)
# and stored in the versioning_settings database table

# ----------------
# Update System Security
# ----------------
# HMAC secret for update progress file integrity
UPDATE_PROGRESS_SECRET={$updateProgressSecret}
# Require GPG signature verification for updates (recommended: true in production)
UPDATE_REQUIRE_GPG_SIGNATURE=true
# Path to GPG public key for verifying update signatures
UPDATE_GPG_PUBLIC_KEY=keys/update-signing.pub
# Path to update audit log
UPDATE_AUDIT_LOG=logs/update-audit.log

# ----------------
# Forge Import (Optimized for Shared Hosting)
# ----------------
# Sync threshold: images ≤ this count are processed immediately
# Higher = more sync (faster for small imports), lower = more async
FORGE_SYNC_IMAGE_THRESHOLD=10
# Enable async processing for large image batches (>threshold)
FORGE_ASYNC_IMAGES=true
# Enable piggyback queue processing (processes 1-2 images on every API request)
# Essential for shared hosting without cron/daemon access
FORGE_PIGGYBACK_PROCESSING=true
# Enable optimistic locking for concurrent import protection
FORGE_OPTIMISTIC_LOCKING=true

# ----------------
# Mail (SMTP profiles)
# ----------------
# There is nothing to configure here: SMTP profiles (host, port, encryption,
# credentials, sender identity) live in system.sqlite and are managed on the
# /mails admin page - the password has to be encrypted at rest, which a .env
# value cannot be.
#
# A profile only sends after an admin has opened the confirmation link that was
# delivered THROUGH it: arrival of that message is the proof the configuration
# works. Until then every e-mail feature stays off, which is why nothing below
# needs to be switched on manually.
#
# Allow loopback / link-local SMTP hosts (MailHog, Mailpit, a local Postfix).
# Off by default: saving a profile makes the server dial an admin-supplied
# host:port and report a distinguishable error per outcome, so without this
# restriction the save endpoint doubles as a port scanner against the CMS host
# itself. Combined with the port whitelist (25/465/587/2525) that capability is
# removed without blocking any legitimate setup - a mail relay on the LAN
# (10.x, 192.168.x) still works.
MAIL_ALLOW_LOCAL=false

# ----------------
# Forms (Form Builder & Submissions)
# ----------------
# Notification e-mail for new submissions goes through the mail subsystem above,
# so it requires a verified default SMTP profile - NOT this flag. Proof of
# delivery is better evidence than an env switch, and it means e-mail turns
# itself on the moment the configuration is confirmed.
#
# This is now only a KILL SWITCH: set it to false to force ALL sending off
# regardless of configuration. Absent or true both mean "respect the profile".
# NOTE: for an ENCRYPTED form the e-mail never contains the submitted values -
# only the fact that a submission arrived - so mail cannot undo the encryption.
FORMS_MAIL_ENABLED=true
# No longer used. The envelope sender comes from the SMTP profile, because a From
# address the SMTP account is not authorised to use (SPF/DKIM, or the provider's
# own ownership check) is one of the most common reasons a send is rejected
# outright. Kept only so an existing value does not read as a live setting.
FORMS_MAIL_FROM=

# Retention sweep (GDPR storage limitation): deletes submissions past their
# form's retention window. Piggybacks on regular HTTP requests instead of
# needing cron - sampled (~2% of requests) and hard-capped per run, executed
# after the response has already been flushed to the visitor.
FORMS_PIGGYBACK_PROCESSING=true

# ----------------
# Analytics (0-PII, privacy-first - no cookies, no consent banner needed)
# ----------------
# Master kill switch. false disables the public beacon endpoint, the ingest/
# aggregation pipeline, and the admin dashboard's data - a hard "module off".
ANALYTICS_ENABLED={$analyticsEnabled}

# How long raw events survive AFTER a day is finalized (aggregated + spool
# backlog drained), NOT after midnight. Grace window for admins to still
# inspect raw data shortly after rollup, before it is purged for good.
# Bounds: 1-168 hours (1 week).
ANALYTICS_RETENTION_RAW_HOURS=48

# How long AGGREGATED (0-PII) daily stats are kept. 0 = forever - the default,
# since daily_totals/daily_facts contain no personal data at all, this is a
# pure storage-size choice, never a privacy requirement.
ANALYTICS_RETENTION_DAILY_DAYS={$analyticsRetentionDailyDays}

# Reject known bot/crawler/monitoring User-Agents at the beacon.
ANALYTICS_BOT_FILTER_ENABLED=true

# Respect DNT:1 / Sec-GPC:1 by dropping the event entirely - what keeps the
# module consent-banner-free even for visitors who opted out of tracking.
ANALYTICS_RESPECT_DNT=true

# Comma-separated list of hosts the beacon accepts events for. Empty (default)
# = accept any host, correct for the common "one install = one website" case.
ANALYTICS_DOMAIN_ALLOWLIST=

# Per-dimension-per-day cardinality cap before values fold into "(other)" in
# daily_facts. Bounds: 10-5000.
ANALYTICS_CARDINALITY_CAP=500

# Abuse ceiling: max events accepted into the raw buffer per day, enforced at
# ingest time (not on the beacon hot path). Bounds: 100-5000000.
ANALYTICS_DAILY_EVENT_CAP=200000

# Ingest + aggregation + retention sweep piggybacks on regular requests instead
# of needing cron - sampled (~2% of requests) and hard-capped per run. A
# deployment WITH cron access can instead run
# `php api/bin/process-analytics.php --ingest` on a schedule and turn this off.
ANALYTICS_PIGGYBACK_PROCESSING=true

# Encryption keys used by the Forms module (generated above):
#   ENCRYPTION_KEY   - envelope encryption of submission values (Defuse/AES-256)
#   BLIND_INDEX_KEY  - deterministic tokens enabling EXACT-match search over
#                      encrypted submissions without decrypting them
#   IP_HASH_SECRET   - submission IPs are stored as a keyed hash, never raw
# WARNING: losing ENCRYPTION_KEY makes every encrypted submission permanently
# unreadable. This file is NOT part of the SQLite backup - back it up separately.
ENV;

        // Write atomically using temp file
        $tempPath = $envPath . '.tmp';
        
        if (file_put_contents($tempPath, $envContent) === false) {
            return false;
        }
        
        // Secure file permissions (owner read/write only)
        chmod($tempPath, 0600);
        
        // Atomic rename
        if (!rename($tempPath, $envPath)) {
            unlink($tempPath);
            return false;
        }
        
        return true;
    }

    /**
     * Create super admin user
     * Uses existing UserRepository with Argon2id hashing
     *
     * @param string|null $firstName Optional - names are not forced at install
     *        time (the operator may just want to get in), but they can be filled
     *        in later under Settings -> General.
     */
    public static function createSuperAdmin(
        string $email,
        string $password,
        ?string $firstName = null,
        ?string $lastName = null
    ): array {
        // Validate email format
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            throw new \InvalidArgumentException('Invalid email format');
        }
        
        // Validate password strength
        $passwordErrors = self::validatePasswordStrength($password);
        if (!empty($passwordErrors)) {
            throw new \InvalidArgumentException(implode(', ', $passwordErrors));
        }
        
        // Initialize database if needed
        self::initializeDatabase();
        
        // Create or update admin user via UserRepository (handles Argon2id hashing)
        $existing = UserRepository::findByEmail($email);
        if ($existing) {
            UserRepository::updatePassword((int) $existing['id'], $password);
            $db = AuthDatabase::getInstance();
            $stmt = $db->prepare("UPDATE users SET is_admin = 1, is_new_user = 0, role = 'admin', first_name = ?, last_name = ?, updated_at = datetime('now') WHERE id = ?");
            $stmt->execute([
                $firstName ?? $existing['first_name'],
                $lastName ?? $existing['last_name'],
                (int) $existing['id']
            ]);
            $user = UserRepository::findById((int) $existing['id']);
        } else {
            // Pass false for is_new_user to avoid forced password change on first login
            $user = UserRepository::create($email, $password, true, false, null, $firstName, $lastName);
        }
        
        if (!$user) {
            throw new \RuntimeException('Failed to create admin user');
        }
        
        // Extended RBAC: explicitly persist role_slug='super_admin' in the database.
        // Without this, the user's role only resolves to super_admin at RUNTIME via
        // RoleRepository::getUserRole()'s legacy is_admin fallback - the role_slug
        // column itself stays NULL, which breaks any UI that reads role_slug directly
        // (e.g. the Users edit modal defaulting to "Viewer" instead of showing the
        // real assigned role).
        try {
            \NomadCMS\Database\RoleRepository::assignToUser((int) $user['id'], 'super_admin');
            $user = UserRepository::findById((int) $user['id']);
        } catch (\Exception $e) {
            error_log('[Installer] Failed to explicitly assign super_admin role_slug: ' . $e->getMessage());
        }
        
        return [
            'uuid' => $user['uuid'],
            'email' => $user['email'],
            'first_name' => $user['first_name'] ?? null,
            'last_name' => $user['last_name'] ?? null,
            'is_admin' => (bool) $user['is_admin'],
        ];
    }

    /**
     * Validate password strength
     *
     * Delegates to PasswordPolicy so the installer, the magic-link onboarding
     * flow and any future password-setting surface enforce identical rules
     * from a single source of truth.
     *
     * @return array<int, string>
     */
    private static function validatePasswordStrength(string $password): array
    {
        return \NomadCMS\Auth\PasswordPolicy::validate($password);
    }

    /**
     * Initialize the database schema if needed
     */
    private static function initializeDatabase(): void
    {
        // Get database instance (this will create the file and schema)
        AuthDatabase::getInstance();
    }

    /**
     * Create lock file with SHA256 integrity hash
     */
    public static function createLockFile(): bool
    {
        $lockPath = self::getLockFilePath();
        
        // Generate unique installation data
        $timestamp = date('c');
        $serverUniqueId = self::generateServerUniqueId();
        
        // Create integrity hash: SHA256(timestamp + server_unique_id + random_salt)
        $randomSalt = bin2hex(random_bytes(32));
        $integrityData = $timestamp . $serverUniqueId . $randomSalt;
        $integrityHash = hash('sha256', $integrityData);
        
        $lockData = [
            'installed_at' => $timestamp,
            'integrity_hash' => $integrityHash,
            'salt' => $randomSalt,
            'version' => \NomadCMS\Config\Version::VERSION,
        ];
        
        // Write atomically
        $tempPath = $lockPath . '.tmp';
        
        if (file_put_contents($tempPath, json_encode($lockData, JSON_PRETTY_PRINT)) === false) {
            return false;
        }
        
        // Secure file permissions
        chmod($tempPath, 0644);
        
        // Atomic rename
        if (!rename($tempPath, $lockPath)) {
            unlink($tempPath);
            return false;
        }
        
        return true;
    }

    /**
     * Generate cryptographically secure secret with optional user entropy mixing
     * Combines random_bytes with user-provided entropy (SHA-256 hashed client-side)
     * for additional unpredictability
     * 
     * @param int $length Number of bytes (output will be 2x in hex)
     * @param string|null $userEntropy User-provided SHA-256 hashed entropy
     * @return string Hex-encoded secret
     */
    private static function generateEntropyMixedSecret(int $length, ?string $userEntropy = null): string
    {
        // Always start with cryptographically secure random bytes
        $randomBytes = random_bytes($length);
        
        // If user entropy is provided, mix it in
        if ($userEntropy !== null && strlen($userEntropy) > 0) {
            // User entropy is already SHA-256 hashed (64 hex chars = 32 bytes when decoded)
            $entropyBytes = hex2bin($userEntropy) ?: '';
            
            // Add server-side entropy (microtime, random, process id)
            $serverEntropy = microtime(true) . getmypid() . bin2hex(random_bytes(8));
            
            // Combine all sources and hash
            $combined = $randomBytes . $entropyBytes . $serverEntropy;
            
            // Use HKDF to derive the final key material
            // This cryptographically mixes all entropy sources
            $derived = hash_hkdf('sha256', $combined, $length, 'nomad-cms-secret-derivation');
            
            return bin2hex($derived);
        }
        
        // Without user entropy, just use random_bytes
        return bin2hex($randomBytes);
    }

    /**
     * Generate RSA key pair for asymmetric JWT signing (RS256)
     * Creates private.pem and public.pem in the keys directory
     * 
     * @param int $keyBits Key size in bits (default 4096 for security)
     * @return bool Success status
     */
    private static function generateRSAKeyPair(int $keyBits = 4096): bool
    {
        $keysDir = dirname(__DIR__, 2) . '/keys';
        $privateKeyPath = $keysDir . '/private.pem';
        $publicKeyPath = $keysDir . '/public.pem';
        
        // Create keys directory if it doesn't exist
        if (!is_dir($keysDir)) {
            if (!mkdir($keysDir, 0700, true)) {
                error_log('[Install] Failed to create keys directory');
                return false;
            }
        }

        // SECURITY: private.pem (RS256 JWT signing key) and vault.key (Forge
        // encryption) must never be reachable over HTTP. api/.htaccess blocks
        // *.pem by extension, but not vault.key, and a package that ends up
        // being served by a misconfigured vhost (or one missing api/.htaccess
        // entirely, e.g. nginx without an equivalent block) would otherwise
        // hand out the private key directly. Written/repaired on every call,
        // same self-healing pattern as FormFileStorage's files/forms/.htaccess.
        self::ensureKeysDenyFile($keysDir);
        
        // Check if keys already exist (don't overwrite)
        if (file_exists($privateKeyPath) && file_exists($publicKeyPath)) {
            error_log('[Install] RSA key pair already exists, skipping generation');
            return true;
        }
        
        // Generate RSA key pair
        $config = [
            'private_key_bits' => $keyBits,
            'private_key_type' => OPENSSL_KEYTYPE_RSA,
            'digest_alg' => 'sha256',
        ];
        
        $keyPair = openssl_pkey_new($config);
        if ($keyPair === false) {
            error_log('[Install] Failed to generate RSA key pair: ' . openssl_error_string());
            return false;
        }
        
        // Export private key
        if (!openssl_pkey_export($keyPair, $privateKey)) {
            error_log('[Install] Failed to export private key: ' . openssl_error_string());
            return false;
        }
        
        // Export public key
        $keyDetails = openssl_pkey_get_details($keyPair);
        if ($keyDetails === false) {
            error_log('[Install] Failed to get key details: ' . openssl_error_string());
            return false;
        }
        $publicKey = $keyDetails['key'];
        
        // Write private key with secure permissions (600 = owner read/write only)
        $privateKeyTmp = $privateKeyPath . '.tmp';
        if (file_put_contents($privateKeyTmp, $privateKey) === false) {
            error_log('[Install] Failed to write private key');
            return false;
        }
        chmod($privateKeyTmp, 0600);
        if (!rename($privateKeyTmp, $privateKeyPath)) {
            unlink($privateKeyTmp);
            return false;
        }
        
        // Write public key (644 = owner read/write, others read)
        $publicKeyTmp = $publicKeyPath . '.tmp';
        if (file_put_contents($publicKeyTmp, $publicKey) === false) {
            error_log('[Install] Failed to write public key');
            return false;
        }
        chmod($publicKeyTmp, 0644);
        if (!rename($publicKeyTmp, $publicKeyPath)) {
            unlink($publicKeyTmp);
            return false;
        }
        
        error_log('[Install] RSA key pair generated successfully (' . $keyBits . ' bits)');
        return true;
    }

    /**
     * Write (or repair) the .htaccess that blocks direct HTTP access to
     * keys/. Idempotent - only touches disk when the content differs, so a
     * later request can heal a missing/tampered file without re-running the
     * installer.
     *
     * Public: also called from bootstrap.php on a sampled basis so an
     * ALREADY-installed instance (whose keys/ predates this protection, or
     * whose .htaccess was lost in a redeploy) heals itself without a
     * reinstall.
     */
    public static function ensureKeysDenyFile(string $keysDir): void
    {
        $path = $keysDir . '/.htaccess';
        $expected = self::keysDenyFileContents();

        $current = is_file($path) ? @file_get_contents($path) : false;
        if ($current === $expected) {
            return;
        }

        if (@file_put_contents($path, $expected) === false) {
            error_log('[Install] FIGYELEM: a keys/ .htaccess-e nem irhato: ' . $path);
            return;
        }

        @chmod($path, 0644);
    }

    /**
     * Deny rules covering both Apache 2.2 and 2.4, same shape as
     * FormFileStorage::denyFileContents() for files/forms/.
     */
    private static function keysDenyFileContents(): string
    {
        return <<<'HTACCESS'
# ═══════════════════════════════════════════════════════════════════════════
# NOMAD CMS - keys/: NO DIRECT WEB ACCESS
# ═══════════════════════════════════════════════════════════════════════════
#
# Generated automatically by InstallerService. Do not edit - it is rewritten
# whenever it differs from the expected contents.
#
# Holds the RS256 JWT signing key pair (private.pem, public.pem) and, when
# Forge is configured, vault.key. api/.htaccess denies *.pem by extension, but
# NOT vault.key - and this rule must also hold on any deployment where
# api/.htaccess is missing or a non-Apache server ignores it. The parent
# api/.htaccess serves any existing file before the router runs, so without
# the rules below this directory would be a direct download of the private
# signing key.

# Apache 2.4+
<IfModule mod_authz_core.c>
    Require all denied
</IfModule>

# Apache 2.2
<IfModule !mod_authz_core.c>
    Order allow,deny
    Deny from all
</IfModule>

# Never hand these to a handler, even if a rule above is missing.
<IfModule mod_php.c>
    php_flag engine off
</IfModule>
<IfModule mod_php7.c>
    php_flag engine off
</IfModule>
<IfModule mod_php8.c>
    php_flag engine off
</IfModule>

# Strip any inherited rewrite that might expose the directory.
<IfModule mod_rewrite.c>
    RewriteEngine On
    RewriteRule ^ - [F,L]
</IfModule>
HTACCESS;
    }

    /**
     * Generate a unique server identifier
     */
    private static function generateServerUniqueId(): string
    {
        $parts = [
            $_SERVER['SERVER_NAME'] ?? 'localhost',
            $_SERVER['DOCUMENT_ROOT'] ?? __DIR__,
            php_uname('n'),
        ];
        
        return hash('sha256', implode('|', $parts));
    }

    /**
     * Validate lock file integrity
     */
    public static function validateLockFile(): bool
    {
        $lockData = self::getLockFileData();
        
        if (!$lockData) {
            return false;
        }
        
        // Check required fields
        $requiredFields = ['installed_at', 'integrity_hash', 'salt', 'version'];
        foreach ($requiredFields as $field) {
            if (!isset($lockData[$field])) {
                return false;
            }
        }
        
        // Verify integrity hash format (SHA256 = 64 hex chars)
        if (!preg_match('/^[a-f0-9]{64}$/i', $lockData['integrity_hash'])) {
            return false;
        }
        
        // Recalculate and verify hash
        $serverUniqueId = self::generateServerUniqueId();
        $expectedHash = hash('sha256', $lockData['installed_at'] . $serverUniqueId . $lockData['salt']);
        
        return hash_equals($expectedHash, $lockData['integrity_hash']);
    }

    /** The standalone setup ownership claim also protects administrator creation. */
    public static function requireSetupClaim(): void
    {
        $path = dirname(__DIR__, 2) . '/storage/updates/setup-claim.json';
        if (!is_file($path)) {
            return; // Existing/manual installations retain their established flow.
        }
        $claim = json_decode((string) file_get_contents($path), true, 8, JSON_THROW_ON_ERROR);
        $token = $_COOKIE['nomad_setup_claim'] ?? '';
        if (!is_string($token) || ($claim['expires'] ?? 0) < time()
            || !hash_equals($claim['hash'] ?? '', hash('sha256', $token))) {
            throw new \RuntimeException('The installation ownership session is unavailable. Use the original browser, or ask the server owner to recover the setup claim through the hosting file manager.');
        }
    }

    /**
     * Execute full installation atomically
     * 
     * @param string $email Admin email
     * @param string $password Admin password
     * @param array $config Optional configuration overrides
     * @return array Installation result
     */
    public static function install(string $email, string $password, array $config = [], ?string $userEntropy = null): array
    {
        self::requireSetupClaim();

        // Check if already installed
        if (self::isInstalled()) {
            throw new \RuntimeException('Installation already completed');
        }

        // ADMIN_URL is mandatory (see execute.php, which validates and
        // normalises it before this is ever called) - re-checked here too,
        // defensively, since generateEnvironmentFile() interpolates it
        // directly into the .env template and an absent key would otherwise
        // write the literal string "ADMIN_URL=" with no value at all.
        if (empty($config['admin_url']) || !is_string($config['admin_url'])) {
            throw new \InvalidArgumentException('admin_url is required');
        }
        
        // Determine scheme and host with safe fallbacks
        $isHttps = ($_SERVER['REQUEST_SCHEME'] ?? '') === 'https' 
                || (($_SERVER['HTTPS'] ?? 'off') !== 'off')
                || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https');
        $scheme = $isHttps ? 'https' : 'http';
        $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
        
        // Merge default config with provided config
        $defaultConfig = [
            'app_url' => $scheme . '://' . $host,
            'site_url' => $scheme . '://' . $host,
            'webauthn_rp_id' => $host,
            'webauthn_rp_origin' => $scheme . '://' . $host,
            'cors_origins' => $scheme . '://' . $host,
            'timestamp' => date('c'),
            'user_entropy' => $userEntropy, // Pass user entropy to env generation
        ];
        
        $finalConfig = array_merge($defaultConfig, $config);
        if (empty($finalConfig['site_url'])) {
            $finalConfig['site_url'] = $finalConfig['app_url'];
        }
        
        try {
            // Step 1: Generate secure environment file
            if (!self::generateEnvironmentFile($finalConfig)) {
                throw new \RuntimeException('Failed to generate environment file');
            }
            
            // Reload environment for the new values
            self::reloadEnvironment();
            
            // Step 2: Create super admin user.
            // Names are optional here (config keys are absent when the operator
            // left the fields empty) and can be set later in the admin panel.
            $adminUser = self::createSuperAdmin(
                $email,
                $password,
                $finalConfig['first_name'] ?? null,
                $finalConfig['last_name'] ?? null
            );
            
            // Initialize the internal Hub explicitly, rather than writing schema on polling requests.
            \NomadCMS\Services\EditorialsHub\EditorialsHubModule::install();
            \NomadCMS\Services\NotificationService\NotificationModule::install();
            \NomadCMS\Services\Seo\SeoModule::install();

            // Step 3: Create lock file
            if (!self::createLockFile()) {
                throw new \RuntimeException('Failed to create lock file');
            }

            $claimFile = dirname(__DIR__, 2) . '/storage/updates/setup-claim.json';
            if (is_file($claimFile)) {
                unlink($claimFile);
            }

            // Step 4: Generate the static analytics beacon snippet
            // (api/static/nomad.js). Best-effort: a failure here should
            // not fail the whole install - the admin can always regenerate it
            // later from the Analytics settings panel or the CLI, and the
            // module works fine without it (it only means the snippet embed
            // code has nothing to serve yet).
            try {
                \NomadCMS\Services\Analytics\AnalyticsScriptGenerator::generate();
            } catch (\Throwable $e) {
                error_log('[Install] Failed to generate nomad.js: ' . $e->getMessage());
            }

            return [
                'success' => true,
                'message' => 'Installation complete',
                'admin' => [
                    'uuid' => $adminUser['uuid'],
                    'email' => $adminUser['email'],
                    'first_name' => $adminUser['first_name'],
                    'last_name' => $adminUser['last_name'],
                ],
                'redirect' => '/nomad/login',
            ];
            
        } catch (\Exception $e) {
            // Cleanup on failure
            self::cleanupFailedInstall();
            
            throw $e;
        }
    }

    /**
     * Reload environment variables from newly created .env
     */
    private static function reloadEnvironment(): void
    {
        $envPath = dirname(__DIR__, 2) . '/.env';
        
        if (file_exists($envPath)) {
            $dotenv = \Dotenv\Dotenv::createImmutable(dirname(__DIR__, 2), '.env');
            $dotenv->load();
        }
    }

    /**
     * Cleanup after a failed installation
     */
    private static function cleanupFailedInstall(): void
    {
        // Remove generated files if they exist
        $envPath = dirname(__DIR__, 2) . '/.env';
        $lockPath = self::getLockFilePath();
        $keysDir = dirname(__DIR__, 2) . '/keys';
        
        if (file_exists($envPath)) {
            unlink($envPath);
        }
        
        if (file_exists($lockPath)) {
            unlink($lockPath);
        }
        
        // Remove RSA keys if they were just generated
        $privateKeyPath = $keysDir . '/private.pem';
        $publicKeyPath = $keysDir . '/public.pem';
        
        if (file_exists($privateKeyPath)) {
            unlink($privateKeyPath);
        }
        if (file_exists($publicKeyPath)) {
            unlink($publicKeyPath);
        }
    }

    /**
     * Get installation status info
     */
    public static function getStatus(): array
    {
        $isInstalled = self::isInstalled();
        $lockData = self::getLockFileData();
        
        if ($isInstalled && $lockData) {
            return [
                'installed' => true,
                'locked_at' => $lockData['installed_at'] ?? null,
                'version' => $lockData['version'] ?? '1.0.0',
            ];
        }
        
        return [
            'installed' => false,
            'requires_setup' => true,
        ];
    }
}
