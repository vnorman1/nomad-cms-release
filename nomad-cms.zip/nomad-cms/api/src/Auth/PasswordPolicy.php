<?php
/**
 * NOMAD CMS - Password Policy
 *
 * Single source of truth for STRONG password requirements (min. 12 chars +
 * upper/lower/digit/special). Extracted from InstallerService so the installer,
 * the magic-link onboarding flow and any future password-setting surface all
 * enforce the exact same rules instead of drifting apart.
 *
 * NOTE: this is deliberately NOT applied to auth/settings.php's existing
 * "change my password" path, which keeps its historical min. 8 rule so
 * already-onboarded users are not locked out of updating their password.
 */

declare(strict_types=1);

namespace NomadCMS\Auth;

final class PasswordPolicy
{
    /** Minimum length for a strong password */
    public const MIN_LENGTH = 12;

    /** Hard upper bound - protects the Argon2id hasher from DoS via huge inputs */
    public const MAX_LENGTH = 128;

    /**
     * Validate a password against the strong policy.
     *
     * @return array<int, string> List of human-readable violations; empty when valid.
     */
    public static function validate(string $password): array
    {
        $errors = [];

        if (strlen($password) < self::MIN_LENGTH) {
            $errors[] = 'Password must be at least ' . self::MIN_LENGTH . ' characters';
        }

        if (strlen($password) > self::MAX_LENGTH) {
            $errors[] = 'Password must be at most ' . self::MAX_LENGTH . ' characters';
        }

        if (!preg_match('/[A-Z]/', $password)) {
            $errors[] = 'Password must contain at least one uppercase letter';
        }

        if (!preg_match('/[a-z]/', $password)) {
            $errors[] = 'Password must contain at least one lowercase letter';
        }

        if (!preg_match('/[0-9]/', $password)) {
            $errors[] = 'Password must contain at least one number';
        }

        if (!preg_match('/[!@#$%^&*()_+\-=\[\]{};\':\"\\\\|,.<>\/?]/', $password)) {
            $errors[] = 'Password must contain at least one special character';
        }

        return $errors;
    }

    /**
     * Same rules, Hungarian messages - used by user-facing endpoints
     * (the installer keeps the original English strings).
     *
     * @return array<int, string>
     */
    public static function validateLocalized(string $password): array
    {
        $errors = [];

        if (strlen($password) < self::MIN_LENGTH) {
            $errors[] = 'A jelszó legalább ' . self::MIN_LENGTH . ' karakter hosszú legyen';
        }

        if (strlen($password) > self::MAX_LENGTH) {
            $errors[] = 'A jelszó legfeljebb ' . self::MAX_LENGTH . ' karakter lehet';
        }

        if (!preg_match('/[A-Z]/', $password)) {
            $errors[] = 'A jelszó tartalmazzon nagybetűt';
        }

        if (!preg_match('/[a-z]/', $password)) {
            $errors[] = 'A jelszó tartalmazzon kisbetűt';
        }

        if (!preg_match('/[0-9]/', $password)) {
            $errors[] = 'A jelszó tartalmazzon számot';
        }

        if (!preg_match('/[!@#$%^&*()_+\-=\[\]{};\':\"\\\\|,.<>\/?]/', $password)) {
            $errors[] = 'A jelszó tartalmazzon speciális karaktert';
        }

        return $errors;
    }

    /**
     * Convenience boolean check.
     */
    public static function isStrong(string $password): bool
    {
        return self::validate($password) === [];
    }
}
