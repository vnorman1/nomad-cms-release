<?php
/**
 * NOMAD CMS - Magic Link Service
 *
 * Issues and validates one-time onboarding links ("magic links") that let an
 * admin invite a user without ever knowing that user's password.
 *
 * ─────────────────────────────────────────────────────────────────────────────
 * TOKEN FORMAT - split token ("selector + verifier")
 * ─────────────────────────────────────────────────────────────────────────────
 *   raw token = "<selector>.<verifier>"
 *     selector : 8 random bytes, hex  (16 chars) - PUBLIC, indexed lookup key
 *     verifier : 32 random bytes, hex (64 chars) - the actual secret
 *
 * Only SHA-256(verifier) is stored (`token_hash`); the verifier itself never
 * touches the database. Validation is a single indexed lookup on `selector`
 * followed by a constant-time hash_equals() comparison. This gives us:
 *   - no full-table scan per validation attempt
 *   - no timing side channel that would leak whether a token prefix is valid
 *   - a DB dump alone cannot be turned back into working links
 *
 * The raw token is returned exactly ONCE, at creation time. The admin copies it
 * and passes it to the user out-of-band; the system never e-mails it.
 *
 * ─────────────────────────────────────────────────────────────────────────────
 * LIFECYCLE
 * ─────────────────────────────────────────────────────────────────────────────
 *   first_used_at : stamped on the first successful redemption (audit only)
 *   consumed_at   : stamped ONLY when onboarding actually completes (password
 *                   set). Until then the link stays usable until it expires,
 *                   so a user who closes the browser mid-onboarding can simply
 *                   re-open the same link.
 *   revoked_at    : stamped when the admin regenerates or revokes the link.
 *                   create() revokes any previous active invitation, so a user
 *                   has AT MOST ONE usable link at any time.
 */

declare(strict_types=1);

namespace NomadCMS\Auth;

use NomadCMS\Database\AuthDatabase;
use PDO;

final class MagicLinkService
{
    /** Invitation for a brand-new user (created without a password) */
    public const PURPOSE_INVITE = 'invite';

    /** Link generated for an EXISTING user - their current password stays valid until redemption */
    public const PURPOSE_RESET = 'reset';

    /** Bytes of entropy in the public selector */
    private const SELECTOR_BYTES = 8;

    /** Bytes of entropy in the secret verifier */
    private const VERIFIER_BYTES = 32;

    /** Whitelisted link lifetimes, in seconds: 1 hour / 24 hours / 7 days */
    public const ALLOWED_TTLS = [3600, 86400, 604800];

    /** Default lifetime when the caller does not specify one */
    public const DEFAULT_TTL = 86400;

    /**
     * Fixed lifetime for self-service ("forgot password") reset links, in
     * seconds: 15 minutes.
     *
     * Deliberately NOT configurable via .env and NOT part of ALLOWED_TTLS: an
     * admin-generated link is handed out by someone who has already verified
     * the recipient out-of-band, but a self-service link is issued to whoever
     * merely typed an e-mail address into a public form. Keeping the window
     * short bounds the damage if that mailbox is compromised, without needing
     * a deploy-time knob that could be loosened by mistake.
     */
    public const SELF_SERVICE_RESET_TTL = 900;

    /**
     * Convert a database timestamp (stored as UTC, 'Y-m-d H:i:s') into an
     * unambiguous ISO-8601 UTC string for API responses.
     *
     * WHY THIS EXISTS: SQLite's datetime('now') is UTC while PHP runs in
     * Europe/Budapest, so bare 'Y-m-d H:i:s' strings are ambiguous - reading one
     * back with strtotime() would silently shift it by the UTC offset. Every
     * timestamp this service writes is UTC, and every timestamp it hands out is
     * ISO-8601 with an explicit 'Z', so neither PHP nor the browser can
     * misinterpret it.
     */
    public static function toIso(?string $utcSqlTimestamp): ?string
    {
        if ($utcSqlTimestamp === null || $utcSqlTimestamp === '') {
            return null;
        }

        $ts = strtotime($utcSqlTimestamp . ' UTC');
        if ($ts === false) {
            return null;
        }

        return gmdate('Y-m-d\TH:i:s\Z', $ts);
    }

    /**
     * Whether a stored (UTC) expiry timestamp is in the past.
     */
    private static function isExpired(?string $utcSqlTimestamp): bool
    {
        if ($utcSqlTimestamp === null || $utcSqlTimestamp === '') {
            return true;
        }

        return strtotime($utcSqlTimestamp . ' UTC') <= time();
    }

    /**
     * Normalize a requested TTL against the whitelist.
     *
     * @throws \InvalidArgumentException when the value is not one of ALLOWED_TTLS
     */
    public static function normalizeTtl(mixed $ttl): int
    {
        if ($ttl === null || $ttl === '') {
            return self::DEFAULT_TTL;
        }

        if (!is_int($ttl) && !(is_string($ttl) && ctype_digit($ttl))) {
            throw new \InvalidArgumentException('Érvénytelen lejárati idő.');
        }

        $seconds = (int) $ttl;

        if (!in_array($seconds, self::ALLOWED_TTLS, true)) {
            throw new \InvalidArgumentException('Érvénytelen lejárati idő. Engedélyezett: 3600, 86400, 604800 másodperc.');
        }

        return $seconds;
    }

    /**
     * Validate a purpose string.
     *
     * @throws \InvalidArgumentException
     */
    public static function normalizePurpose(mixed $purpose): string
    {
        if ($purpose === null || $purpose === '') {
            return self::PURPOSE_INVITE;
        }

        if (!is_string($purpose) || !in_array($purpose, [self::PURPOSE_INVITE, self::PURPOSE_RESET], true)) {
            throw new \InvalidArgumentException('Érvénytelen meghívás típus.');
        }

        return $purpose;
    }

    /**
     * Create a fresh magic link for a user, revoking any previous active one.
     *
     * IMPORTANT: this does NOT modify the user record. In particular it never
     * clears the user's password - an existing user keeps being able to log in
     * with their current password until the link is actually redeemed.
     *
     * @return array{token:string, expires_at:string, purpose:string, invitation_id:int}
     */
    public static function create(
        int $userId,
        int $ttlSeconds = self::DEFAULT_TTL,
        string $purpose = self::PURPOSE_INVITE,
        ?int $createdBy = null
    ): array {
        $ttlSeconds = self::normalizeTtl($ttlSeconds);
        $purpose = self::normalizePurpose($purpose);

        return self::issue($userId, $ttlSeconds, $purpose, $createdBy);
    }

    /**
     * Create a self-service ("forgot password") reset link for an existing
     * user, with a FIXED 15-minute lifetime.
     *
     * This intentionally bypasses normalizeTtl()/ALLOWED_TTLS: the short
     * window is a hardcoded security property of the self-service flow, not a
     * caller-selectable option. Anyone who merely knows a user's e-mail
     * address can trigger this path (see auth/ar-request.php), unlike the
     * admin-issued links in create(), so it gets the shortest lifetime in the
     * system and can never be lengthened by a request parameter or .env value.
     *
     * Same single-active-link invariant as create(): issuing this revokes any
     * other outstanding invitation for the user, admin-issued or not.
     *
     * @return array{token:string, expires_at:string, purpose:string, invitation_id:int}
     */
    public static function createSelfServiceReset(int $userId): array
    {
        return self::issue($userId, self::SELF_SERVICE_RESET_TTL, self::PURPOSE_RESET, null);
    }

    /**
     * Shared insertion logic behind create() and createSelfServiceReset().
     *
     * Callers are responsible for validating/choosing $ttlSeconds and
     * $purpose before reaching here - this method trusts its arguments.
     *
     * @return array{token:string, expires_at:string, purpose:string, invitation_id:int}
     */
    private static function issue(
        int $userId,
        int $ttlSeconds,
        string $purpose,
        ?int $createdBy
    ): array {
        $db = AuthDatabase::getInstance();

        // At most one usable link per user
        self::revokeAllForUser($userId);

        $selector = bin2hex(random_bytes(self::SELECTOR_BYTES));
        $verifier = bin2hex(random_bytes(self::VERIFIER_BYTES));
        $tokenHash = hash('sha256', $verifier);

        // Stored in UTC to match SQLite's datetime('now'), which the "is this
        // link still alive?" SQL comparisons use.
        $expiresAtUtc = gmdate('Y-m-d H:i:s', time() + $ttlSeconds);

        $stmt = $db->prepare("
            INSERT INTO user_invitations
                (user_id, selector, token_hash, purpose, created_by, expires_at, ip_address)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ");

        $stmt->execute([
            $userId,
            $selector,
            $tokenHash,
            $purpose,
            $createdBy,
            $expiresAtUtc,
            \NomadCMS\Security\IpHashService::hash($_SERVER['REMOTE_ADDR'] ?? ''),
        ]);

        return [
            'token' => $selector . '.' . $verifier,
            // ISO-8601 UTC, safe to hand straight to the API/browser
            'expires_at' => self::toIso($expiresAtUtc),
            'purpose' => $purpose,
            'invitation_id' => (int) $db->lastInsertId(),
        ];
    }

    /**
     * Resolve a raw token to its (still usable) invitation row.
     *
     * Returns null for every failure mode - unknown selector, wrong verifier,
     * malformed input, revoked, already consumed, or expired - so callers
     * cannot distinguish them and probe for valid tokens.
     */
    public static function findActiveByToken(string $token): ?array
    {
        $parts = explode('.', $token);
        if (count($parts) !== 2) {
            return null;
        }

        [$selector, $verifier] = $parts;

        // Cheap structural validation before touching the DB
        if (
            strlen($selector) !== self::SELECTOR_BYTES * 2
            || strlen($verifier) !== self::VERIFIER_BYTES * 2
            || !ctype_xdigit($selector)
            || !ctype_xdigit($verifier)
        ) {
            return null;
        }

        $db = AuthDatabase::getInstance();
        $stmt = $db->prepare("SELECT * FROM user_invitations WHERE selector = ?");
        $stmt->execute([$selector]);
        $row = $stmt->fetch();

        if (!$row) {
            return null;
        }

        // Constant-time secret comparison
        if (!hash_equals((string) $row['token_hash'], hash('sha256', $verifier))) {
            return null;
        }

        if (!empty($row['revoked_at']) || !empty($row['consumed_at'])) {
            return null;
        }

        if (self::isExpired($row['expires_at'] ?? null)) {
            return null;
        }

        return $row;
    }

    /**
     * Stamp the first redemption of an invitation (audit trail).
     * Idempotent: a later redemption does not overwrite the original timestamp.
     */
    public static function markFirstUse(int $invitationId): void
    {
        $db = AuthDatabase::getInstance();
        $stmt = $db->prepare("
            UPDATE user_invitations
            SET first_used_at = datetime('now')
            WHERE id = ? AND first_used_at IS NULL
        ");
        $stmt->execute([$invitationId]);
    }

    /**
     * Permanently consume an invitation - called ONLY when onboarding completes.
     */
    public static function consume(int $invitationId): void
    {
        $db = AuthDatabase::getInstance();
        $stmt = $db->prepare("
            UPDATE user_invitations
            SET consumed_at = datetime('now')
            WHERE id = ? AND consumed_at IS NULL
        ");
        $stmt->execute([$invitationId]);
    }

    /**
     * Consume whichever invitation is currently active for a user (if any).
     * Used by the onboarding endpoint, which knows the user but not the token.
     */
    public static function consumeActiveForUser(int $userId): void
    {
        $active = self::findActiveForUser($userId);
        if ($active !== null) {
            self::consume((int) $active['id']);
        }
    }

    /**
     * Revoke every not-yet-consumed invitation of a user.
     *
     * @return int Number of invitations revoked
     */
    public static function revokeAllForUser(int $userId): int
    {
        $db = AuthDatabase::getInstance();
        $stmt = $db->prepare("
            UPDATE user_invitations
            SET revoked_at = datetime('now')
            WHERE user_id = ? AND revoked_at IS NULL AND consumed_at IS NULL
        ");
        $stmt->execute([$userId]);

        return $stmt->rowCount();
    }

    /**
     * The user's currently usable invitation, or null.
     */
    public static function findActiveForUser(int $userId): ?array
    {
        $db = AuthDatabase::getInstance();
        $stmt = $db->prepare("
            SELECT * FROM user_invitations
            WHERE user_id = ?
              AND revoked_at IS NULL
              AND consumed_at IS NULL
              AND expires_at > datetime('now')
            ORDER BY id DESC
            LIMIT 1
        ");
        $stmt->execute([$userId]);

        return $stmt->fetch() ?: null;
    }

    /**
     * Invitation status for the admin UI.
     *
     * @return array{status:string, expires_at:?string, purpose:?string, first_used_at:?string}
     *         status is one of: 'none' | 'pending' | 'expired'
     */
    public static function getStatusForUser(int $userId): array
    {
        $db = AuthDatabase::getInstance();

        // Most recent invitation that was neither revoked nor consumed:
        // it is either still pending, or it expired unused.
        $stmt = $db->prepare("
            SELECT expires_at, purpose, first_used_at
            FROM user_invitations
            WHERE user_id = ?
              AND revoked_at IS NULL
              AND consumed_at IS NULL
            ORDER BY id DESC
            LIMIT 1
        ");
        $stmt->execute([$userId]);
        $row = $stmt->fetch();

        if (!$row) {
            return ['status' => 'none', 'expires_at' => null, 'purpose' => null, 'first_used_at' => null];
        }

        $isExpired = self::isExpired($row['expires_at'] ?? null);

        return [
            'status' => $isExpired ? 'expired' : 'pending',
            'expires_at' => self::toIso($row['expires_at'] ?? null),
            'purpose' => $row['purpose'],
            'first_used_at' => self::toIso($row['first_used_at'] ?? null),
        ];
    }

    /**
     * Batch variant of getStatusForUser() for the users list endpoint -
     * one query instead of N.
     *
     * @param array<int, int> $userIds
     * @return array<int, array{status:string, expires_at:?string, purpose:?string, first_used_at:?string}>
     *         Keyed by user_id. Users with no invitation are omitted.
     */
    public static function getStatusMap(array $userIds): array
    {
        $userIds = array_values(array_unique(array_map('intval', $userIds)));
        if ($userIds === []) {
            return [];
        }

        $db = AuthDatabase::getInstance();
        $placeholders = implode(',', array_fill(0, count($userIds), '?'));

        // Pick the newest non-revoked, non-consumed invitation per user
        $stmt = $db->prepare("
            SELECT i.user_id, i.expires_at, i.purpose, i.first_used_at
            FROM user_invitations i
            INNER JOIN (
                SELECT user_id, MAX(id) AS max_id
                FROM user_invitations
                WHERE revoked_at IS NULL AND consumed_at IS NULL
                  AND user_id IN ($placeholders)
                GROUP BY user_id
            ) latest ON latest.max_id = i.id
        ");
        $stmt->execute($userIds);

        $map = [];
        foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
            $isExpired = self::isExpired($row['expires_at'] ?? null);
            $map[(int) $row['user_id']] = [
                'status' => $isExpired ? 'expired' : 'pending',
                'expires_at' => self::toIso($row['expires_at'] ?? null),
                'purpose' => $row['purpose'],
                'first_used_at' => self::toIso($row['first_used_at'] ?? null),
            ];
        }

        return $map;
    }
}
