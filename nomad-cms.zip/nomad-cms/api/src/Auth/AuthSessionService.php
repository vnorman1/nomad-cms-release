<?php
/**
 * NOMAD CMS — Revocable JWT sessions and refresh-token rotation.
 * SQLite owns scope, credential method and revocation state. Refresh rotation
 * reads and consumes a token under one writer lock; tokens are stored hashed.
 * User authentication generations invalidate every old JWT after a reset.
 */

declare(strict_types=1);

namespace NomadCMS\Auth;

use NomadCMS\Config\Security;
use NomadCMS\Database\AuthDatabase;
use NomadCMS\Database\UserRepository;
use NomadCMS\Security\ClientIpResolver;
use NomadCMS\Security\IpHashService;
use Ramsey\Uuid\Uuid;

final class AuthSessionService
{
    public static function assertUser(array $user, ?string $method = null): void
    {
        if (UserRepository::isLocked($user)) {
            throw new AuthException('ACCOUNT_LOCKED', 'Account is locked.', 423);
        }
        if (($method === 'password' && !UserRepository::canUsePassword($user))
            || ($method === 'webauthn' && !UserRepository::canUseWebAuthn($user))) {
            throw new AuthException('AUTH_METHOD_DISABLED', 'Authentication method is disabled.', 403);
        }
    }

    public static function accessSession(array $user, bool $onboarding, ?string $id = null): array
    {
        $db = AuthDatabase::getInstance();
        if ($id !== null) {
            $stmt = $db->prepare('SELECT * FROM auth_sessions WHERE id=? AND user_id=?');
            $stmt->execute([$id, $user['id']]);
            $session = $stmt->fetch();
            if (!$session || $session['revoked_at'] !== null || (int) $session['expires_at'] <= time()
                || (int) $session['auth_version'] !== (int) $user['auth_version']) {
                throw new AuthException('SESSION_REVOKED', 'Session revoked. Please sign in again.');
            }
            return $session;
        }
        $id = Uuid::uuid4()->toString();
        $expires = time() + (int) ($_ENV['JWT_ACCESS_TOKEN_TTL'] ?? Security::JWT_ACCESS_TTL);
        $stmt = $db->prepare('INSERT INTO auth_sessions(id,user_id,auth_version,scope,auth_method,expires_at) VALUES(?,?,?,?,?,?)');
        $stmt->execute([$id, $user['id'], $user['auth_version'], $onboarding ? 'onboarding' : 'full', 'internal', $expires]);
        return self::accessSession($user, $onboarding, $id);
    }

    public static function issue(array $user, string $method, bool $onboarding = false, ?int $invitationId = null): array
    {
        return AuthTransaction::run(function ($db) use ($user, $method, $onboarding, $invitationId): array {
            $current = UserRepository::findById((int) $user['id']);
            if (!$current) {
                throw new AuthException('ACCOUNT_NOT_FOUND', 'Account is unavailable.');
            }
            self::assertUser($current, $method);
            $id = Uuid::uuid4()->toString();
            $refresh = JWTService::generateRefreshToken((int) $current['id']);
            $expires = strtotime($refresh['expires_at'] . ' UTC');
            $stmt = $db->prepare('INSERT INTO auth_sessions(id,user_id,auth_version,scope,auth_method,invitation_id,expires_at) VALUES(?,?,?,?,?,?,?)');
            $stmt->execute([$id, $current['id'], $current['auth_version'], $onboarding || !empty($current['is_new_user']) ? 'onboarding' : 'full', $method, $invitationId, $expires]);
            $refresh['family'] = $id;
            self::storeRefresh($refresh, $id);
            $current['_auth_session_id'] = $id;
            return ['access_token' => JWTService::generateAccessToken($current, $onboarding, true), 'refresh' => $refresh];
        });
    }

    private static function storeRefresh(array $refresh, string $sessionId): void
    {
        $stmt = AuthDatabase::getInstance()->prepare('INSERT INTO refresh_tokens(user_id,token_hash,family,expires_at,ip_address,user_agent,auth_session_id) VALUES(?,?,?,?,?,?,?)');
        $stmt->execute([
            $refresh['user_id'], $refresh['token_hash'], $sessionId, $refresh['expires_at'],
            IpHashService::hashForBinding(ClientIpResolver::resolve()) ?? '',
            substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 500), $sessionId,
        ]);
    }

    public static function rotate(string $plainToken): array
    {
        $result = AuthTransaction::run(function ($db) use ($plainToken): array|AuthException {
            $stmt = $db->prepare('SELECT * FROM refresh_tokens WHERE token_hash=?');
            $stmt->execute([hash('sha256', $plainToken)]);
            $old = $stmt->fetch();
            if (!$old || empty($old['auth_session_id'])) {
                return new AuthException('INVALID_REFRESH_TOKEN', 'Invalid refresh token.');
            }
            if ($old['revoked']) {
                self::revokeSession($old['auth_session_id']);
                return new AuthException('TOKEN_REUSE_DETECTED', 'Token reuse detected. Please sign in again.');
            }
            if (strtotime($old['expires_at'] . ' UTC') <= time()) {
                return new AuthException('TOKEN_EXPIRED', 'Refresh token expired.');
            }
            $user = UserRepository::findById((int) $old['user_id']);
            if (!$user) {
                return new AuthException('ACCOUNT_NOT_FOUND', 'Account is unavailable.');
            }
            $session = self::accessSession($user, false, $old['auth_session_id']);
            self::assertUser($user, $session['auth_method']);
            self::assertInvitation($session);
            if (!IpHashService::verifyBinding(ClientIpResolver::resolve(), $old['ip_address'])
                || (!empty($old['user_agent']) && $old['user_agent'] !== substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 500))) {
                self::revokeSession($session['id']);
                return new AuthException('SESSION_HIJACK_DETECTED', 'Session security violation.');
            }
            // The predicate also protects callers should transaction ownership change.
            $stmt = $db->prepare("UPDATE refresh_tokens SET revoked=1,revoked_at=datetime('now') WHERE id=? AND revoked=0");
            $stmt->execute([$old['id']]);
            if ($stmt->rowCount() !== 1) {
                return new AuthException('TOKEN_REUSE_DETECTED', 'Token already consumed.');
            }
            $refresh = JWTService::generateRefreshToken((int) $user['id']);
            $refresh['family'] = $session['id'];
            self::storeRefresh($refresh, $session['id']);
            $db->prepare('UPDATE auth_sessions SET expires_at=? WHERE id=?')->execute([strtotime($refresh['expires_at'] . ' UTC'), $session['id']]);
            $user['_auth_session_id'] = $session['id'];
            return ['access_token' => JWTService::generateAccessToken($user, $session['scope'] === 'onboarding'), 'refresh' => $refresh];
        });
        if ($result instanceof AuthException) {
            throw $result; // Commit replay revocation before returning the failure.
        }
        return $result;
    }

    public static function validate(object $token): array
    {
        $user = UserRepository::findByUuid($token->sub);
        if (!$user || (int) $user['id'] !== $token->user->id
            || (int) $user['auth_version'] !== $token->auth_version) {
            throw new AuthException('SESSION_REVOKED', 'Session revoked. Please sign in again.');
        }
        self::assertUser($user);
        if (!empty($token->panic_recovery)) {
            return $user;
        }
        $session = self::accessSession($user, false, $token->sid);
        self::assertUser($user, $session['auth_method']);
        self::assertInvitation($session);
        if (($session['scope'] === 'onboarding') !== $token->user->onboarding) {
            throw new AuthException('SESSION_SCOPE_MISMATCH', 'Invalid session scope.');
        }
        return $user;
    }

    private static function assertInvitation(array $session): void
    {
        if ($session['invitation_id'] === null) {
            return;
        }
        $stmt = AuthDatabase::getInstance()->prepare("SELECT 1 FROM user_invitations WHERE id=? AND user_id=? AND revoked_at IS NULL AND consumed_at IS NULL AND expires_at>datetime('now')");
        $stmt->execute([$session['invitation_id'], $session['user_id']]);
        if (!$stmt->fetchColumn()) {
            throw new AuthException('INVALID_MAGIC_LINK', 'Invitation expired or revoked.');
        }
    }

    public static function revokeSession(string $id): void
    {
        $db = AuthDatabase::getInstance();
        $db->prepare('UPDATE auth_sessions SET revoked_at=? WHERE id=? AND revoked_at IS NULL')->execute([time(), $id]);
        $db->prepare("UPDATE refresh_tokens SET revoked=1,revoked_at=datetime('now') WHERE auth_session_id=?")->execute([$id]);
    }

    public static function revokeUser(int $userId): int
    {
        return AuthTransaction::run(function ($db) use ($userId): int {
            $db->prepare('UPDATE users SET auth_version=auth_version+1 WHERE id=?')->execute([$userId]);
            $stmt = $db->prepare('UPDATE auth_sessions SET revoked_at=? WHERE user_id=? AND revoked_at IS NULL');
            $stmt->execute([time(), $userId]);
            $db->prepare("UPDATE refresh_tokens SET revoked=1,revoked_at=datetime('now') WHERE user_id=?")->execute([$userId]);
            $db->prepare('DELETE FROM sessions WHERE user_id=?')->execute([$userId]);
            return $stmt->rowCount();
        });
    }

    public static function currentSession(object $identity): array
    {
        $user = UserRepository::findById((int) $identity->id);
        return self::accessSession($user, false, $identity->session_id);
    }

    public static function recoveryMethods(array $user): array
    {
        $methods = [];
        if (!empty($user['totp_enabled'])) {
            $methods[] = 'totp'; // An existing factor cannot be removed by a feature toggle.
        }
        if (UserRepository::canUseWebAuthn($user)) {
            $stmt = AuthDatabase::getInstance()->prepare('SELECT 1 FROM webauthn_credentials WHERE user_id=? LIMIT 1');
            $stmt->execute([$user['id']]);
            if ($stmt->fetchColumn()) {
                $methods[] = 'webauthn';
            }
        }
        return $methods;
    }
}
