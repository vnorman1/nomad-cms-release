<?php
/**
 * NOMAD CMS - JWT Service
 * Token generation, validation, and refresh handling
 */

declare(strict_types=1);

namespace NomadCMS\Auth;

use Firebase\JWT\JWT;
use Firebase\JWT\Key;
use Firebase\JWT\ExpiredException;
use Firebase\JWT\SignatureInvalidException;
use NomadCMS\Config\Security;
use Ramsey\Uuid\Uuid;

final class JWTService
{
    /**
     * Generate access token for authenticated user
     *
     * @param bool $onboarding When true, marks the token as an ONBOARDING-SCOPED
     *        session (issued by auth/magic-login.php). Such a token is rejected by
     *        AuthMiddleware::requireAuth() on every endpoint that does not
     *        explicitly opt in, so redeeming a magic link grants exactly enough
     *        access to finish onboarding - and nothing else.
     */
    public static function generateAccessToken(array $user, bool $onboarding = false, bool $freshAuthentication = false): string
    {
        $current = \NomadCMS\Database\UserRepository::findByUuid($user['uuid']);
        if (!$current) {
            throw new AuthException('ACCOUNT_NOT_FOUND', 'Account is unavailable.');
        }
        $current['_auth_session_id'] = $user['_auth_session_id'] ?? null;
        $user = $current;
        AuthSessionService::assertUser($user);
        $now = time();
        $ttl = (int) ($_ENV['JWT_ACCESS_TOKEN_TTL'] ?? Security::JWT_ACCESS_TTL);
        $controlClaims = \NomadCMS\Security\PanicModeService::tokenClaims($user, $freshAuthentication);
        if (!empty($controlClaims['panic_recovery'])) {
            $ttl = 300;
        }
        $session = !empty($controlClaims['panic_recovery']) ? null : AuthSessionService::accessSession(
            $user,
            $onboarding || !empty($user['is_new_user']),
            $user['_auth_session_id']
        );
        $onboarding = $session !== null ? $session['scope'] === 'onboarding' : $onboarding;
        
        // Determine role - use explicit role if set, otherwise derive from is_admin
        $role = $user['role'] ?? ($user['is_admin'] ? 'admin' : 'viewer');
        
        // Extended RBAC: resolve role_slug (custom roles system).
        //
        // SAFETY: if the caller passed an incomplete user array (no role_slug),
        // re-read the authoritative value from the database instead of guessing.
        // Guessing here previously demoted every non-admin user to 'viewer' on
        // token refresh, silently stripping their permissions until re-login.
        $roleSlug = $user['role_slug'] ?? null;
        if (!$roleSlug && !empty($user['uuid'])) {
            try {
                $db = \NomadCMS\Database\AuthDatabase::getInstance();
                $stmt = $db->prepare("SELECT role_slug, role FROM users WHERE uuid = ?");
                $stmt->execute([$user['uuid']]);
                if ($row = $stmt->fetch()) {
                    $roleSlug = $row['role_slug'] ?: null;
                    if (empty($user['role']) && !empty($row['role'])) {
                        $role = $row['role'];
                    }
                }
            } catch (\Exception $e) {
                error_log('[JWTService] role_slug DB lookup failed: ' . $e->getMessage());
            }
        }
        
        // Last-resort legacy derivation (pre-RBAC users with no role_slug row)
        if (!$roleSlug) {
            $roleSlug = !empty($user['is_admin']) ? 'super_admin' : ($role === 'editor' ? 'editor' : 'viewer');
        }
        
        // Compact summaries for the JWT payload (full permission list is NOT
        // embedded in the token - fetched from /auth/me.php when needed)
        $resourceSummary = [];
        $slotAccess = [];
        try {
            $resourceSummary = \NomadCMS\Services\RBACService::getResourceSummary($roleSlug);
            $slotAccess = \NomadCMS\Services\RBACService::getSlotAccess($roleSlug);
        } catch (\Exception $e) {
            // Roles table may not exist yet during install/migration - fail gracefully
            error_log('[JWTService] RBAC summary lookup failed: ' . $e->getMessage());
        }
        
        $clientIp = \NomadCMS\Security\ClientIpResolver::resolve();
        $ipBindingHash = \NomadCMS\Security\IpHashService::hashForBinding($clientIp);
        
        $payload = [
            'iss' => $_ENV['JWT_ISSUER'] ?? 'nomad-cms',
            'aud' => $_ENV['JWT_AUDIENCE'] ?? 'nomad-cms-frontend',
            'iat' => $now,
            'nbf' => $now,
            'exp' => $now + $ttl,
            'sub' => $user['uuid'],
            'jti' => Uuid::uuid4()->toString(),
            'sid' => $session['id'] ?? null,
            'auth_version' => (int) $user['auth_version'],
            'ip_hash' => $ipBindingHash,
            'user' => [
                'id' => $user['id'],
                'uuid' => $user['uuid'],
                'session_id' => $session['id'] ?? null,
                'auth_method' => $session['auth_method'] ?? 'recovery',
                'email' => $user['email'],
                'role' => $role,  // Legacy RBAC: admin, editor, viewer
                'role_slug' => $roleSlug, // Extended RBAC: custom role slug
                'permissions' => $resourceSummary, // Resource-level summary only
                'slot_access' => $slotAccess, // Wildcard slot patterns
                'is_admin' => (bool) ($user['is_admin'] ?? false),
                'is_new_user' => (bool) ($user['is_new_user'] ?? false),
                // Onboarding-scoped session marker (magic-link redemption).
                // Enforced by AuthMiddleware alongside is_new_user.
                'onboarding' => $onboarding,
            ],
        ];
        
        $payload += $controlClaims;

        return JWT::encode(
            $payload,
            Security::getJwtSigningKey(),
            Security::getJwtAlgorithm()
        );
    }
    
    /**
     * Generate refresh token
     * 
     * Returns both the plain token (to send to client) and its hash (to store in DB)
     * 
     * SECURITY NOTES:
     * - plain_token: Cryptographically secure random (512 bits entropy)
     * - token_hash: SHA-256 hash stored in DB (token never stored in plaintext)
     * - Even if DB is compromised, hashes cannot be reversed to get tokens
     * - Client stores token in:
     *   1. httpOnly cookie (PRIMARY - XSS immune)
     *   2. AES-256-GCM encrypted localStorage (FALLBACK)
     * 
     * @return array{plain_token: string, token_hash: string, family: string, expires_at: string, user_id: int}
     */
    public static function generateRefreshToken(int $userId): array
    {
        // Generate 64 bytes (512 bits) of cryptographically secure random data
        $plainToken = bin2hex(random_bytes(Security::REFRESH_TOKEN_LENGTH));
        
        // Only the hash is stored in DB - never the plain token
        $tokenHash = hash('sha256', $plainToken);
        
        // Token family for refresh rotation tracking
        $family = Uuid::uuid4()->toString();
        
        $ttl = (int) ($_ENV['JWT_REFRESH_TOKEN_TTL'] ?? Security::JWT_REFRESH_TTL);
        $expiresAt = gmdate('Y-m-d H:i:s', time() + $ttl);
        
        return [
            'plain_token' => $plainToken,
            'token_hash' => $tokenHash,
            'family' => $family,
            'expires_at' => $expiresAt,
            'user_id' => $userId,
        ];
    }
    
    /**
     * Validate access token and return payload
     * 
     * @throws \Exception on invalid token
     */
    public static function validateAccessToken(string $token): object
    {
        // SECURITY: Pre-validate token structure to prevent algorithm attacks
        if (strlen($token) > 32768) {
            throw new AuthException('INVALID_TOKEN', 'Invalid token format.');
        }
        $parts = explode('.', $token);
        if (count($parts) !== 3) {
            throw new \Exception('Invalid token format', 401);
        }
        
        // Decode header to check algorithm BEFORE verification
        $headerJson = base64_decode(strtr($parts[0], '-_', '+/'), true);
        if ($headerJson === false) {
            throw new \Exception('Invalid token header encoding', 401);
        }
        
        $header = json_decode($headerJson, true);
        if (!is_array($header) || !isset($header['alg']) || !is_string($header['alg'])) {
            throw new \Exception('Invalid token header', 401);
        }
        
        // CRITICAL: Reject "none" algorithm and any algorithm mismatch
        $allowedAlgorithm = Security::getJwtAlgorithm();
        $tokenAlgorithm = strtoupper($header['alg']);
        
        if ($tokenAlgorithm === 'NONE' || $tokenAlgorithm === '') {
            throw new \Exception('Algorithm "none" is not allowed', 401);
        }
        
        if ($tokenAlgorithm !== strtoupper($allowedAlgorithm)) {
            throw new \Exception('Algorithm mismatch: expected ' . $allowedAlgorithm, 401);
        }
        
        try {
            $decoded = JWT::decode(
                $token,
                new Key(Security::getJwtVerificationKey(), $allowedAlgorithm)
            );
            
            // SECURITY: Additional expiry check (defense in depth)
            if (!isset($decoded->exp) || $decoded->exp < time()) {
                throw new \Exception('Token expired', 401);
            }
            
            // Verify required claims exist
            if (!isset($decoded->sub, $decoded->user, $decoded->auth_version, $decoded->iss, $decoded->aud, $decoded->iat, $decoded->nbf)
                || !is_string($decoded->sub) || !is_object($decoded->user)
                || !is_int($decoded->auth_version) || !is_int($decoded->exp)
                || !is_int($decoded->iat) || !is_int($decoded->nbf)
                || $decoded->iss !== ($_ENV['JWT_ISSUER'] ?? 'nomad-cms')
                || $decoded->aud !== ($_ENV['JWT_AUDIENCE'] ?? 'nomad-cms-frontend')
                || !isset($decoded->user->id, $decoded->user->uuid, $decoded->user->onboarding)
                || !is_int($decoded->user->id) || $decoded->user->id < 1
                || $decoded->user->uuid !== $decoded->sub || !is_bool($decoded->user->onboarding)
                || (empty($decoded->panic_recovery) && (!isset($decoded->sid, $decoded->user->session_id)
                    || !is_string($decoded->sid) || $decoded->sid !== $decoded->user->session_id))) {
                throw new \Exception('Token missing required claims', 401);
            }

            \NomadCMS\Security\PanicModeService::validateTokenClaims($decoded);
            AuthSessionService::validate($decoded);
            if (!empty($decoded->ip_hash) && (!is_string($decoded->ip_hash)
                || !\NomadCMS\Security\IpHashService::verifyBinding(\NomadCMS\Security\ClientIpResolver::resolve(), $decoded->ip_hash))) {
                throw new AuthException('SESSION_IP_MISMATCH', 'Session IP mismatch. Please sign in again.');
            }
            
            return $decoded;
            
        } catch (\NomadCMS\Security\PanicModeException $e) {
            throw $e;
        } catch (AuthException $e) {
            throw $e;
        } catch (ExpiredException $e) {
            throw new \Exception('Token expired', 401);
        } catch (SignatureInvalidException $e) {
            throw new \Exception('Invalid token signature', 401);
        } catch (\Throwable $e) {
            // Re-throw our own exceptions
            if ($e->getCode() === 401) {
                throw $e;
            }
            throw new \Exception('Invalid token: ' . $e->getMessage(), 401);
        }
    }
    
    /**
     * Extract token from Authorization header
     */
    public static function extractBearerToken(): ?string
    {
        // Get headers - use global function with fallback for different PHP SAPIs
        $headers = [];
        
        if (\function_exists('getallheaders')) {
            $headers = \getallheaders();
        }
        
        // Also check $_SERVER for HTTP_AUTHORIZATION (works in all environments)
        // This is the most reliable method for PHP built-in server and proxies
        if (isset($_SERVER['HTTP_AUTHORIZATION'])) {
            $authHeader = $_SERVER['HTTP_AUTHORIZATION'];
        } elseif (isset($_SERVER['REDIRECT_HTTP_AUTHORIZATION'])) {
            // Apache with mod_rewrite sometimes uses this
            $authHeader = $_SERVER['REDIRECT_HTTP_AUTHORIZATION'];
        } else {
            // Fallback to getallheaders result (case-insensitive search)
            $authHeader = '';
            foreach ($headers as $key => $value) {
                if (strtolower($key) === 'authorization') {
                    $authHeader = $value;
                    break;
                }
            }
        }
        
        if (preg_match('/^Bearer\s+(.+)$/i', $authHeader, $matches)) {
            return $matches[1];
        }
        
        return null;
    }
    
    /**
     * Verify refresh token hash
     */
    public static function verifyRefreshToken(string $plainToken, string $storedHash): bool
    {
        return hash_equals($storedHash, hash('sha256', $plainToken));
    }
    
    /**
     * Get remaining time until token expires (in seconds)
     */
    public static function getTokenRemainingTime(object $decoded): int
    {
        return max(0, $decoded->exp - time());
    }
    
    /**
     * Check if token needs refresh (less than 5 minutes remaining)
     */
    public static function shouldRefreshToken(object $decoded): bool
    {
        return self::getTokenRemainingTime($decoded) < 300;
    }
}
