<?php
/**
 * NOMAD CMS — Additive authentication security migration.
 * Legacy secrets retain SHA-1 until re-enrollment. Existing refresh tokens
 * are revoked once because they have no trustworthy session scope metadata.
 * No deprecated columns are removed; normal reads perform no DDL.
 */

declare(strict_types=1);

namespace NomadCMS\Auth;

use PDO;

final class AuthSchema
{
    public static function ensure(PDO $db): void
    {
        if ($db->query("SELECT 1 FROM sqlite_master WHERE type='table' AND name='auth_security_schema'")->fetchColumn()) {
            return;
        }
        $owns = !$db->inTransaction();
        if ($owns) {
            $db->exec('BEGIN IMMEDIATE');
        }
        try {
            if ($db->query("SELECT 1 FROM sqlite_master WHERE type='table' AND name='auth_security_schema'")->fetchColumn()) {
                if ($owns) {
                    $db->exec('COMMIT');
                }
                return;
            }
            $columns = array_column($db->query('PRAGMA table_info(users)')->fetchAll(PDO::FETCH_ASSOC), 'name');
            foreach ([
                'auth_version' => 'INTEGER NOT NULL DEFAULT 1',
                'totp_algorithm' => "TEXT NOT NULL DEFAULT 'sha1'",
                'totp_last_step' => 'INTEGER NOT NULL DEFAULT -1',
            ] as $name => $definition) {
                if (!in_array($name, $columns, true)) {
                    $db->exec('ALTER TABLE users ADD COLUMN ' . $name . ' ' . $definition);
                }
            }
            $columns = array_column($db->query('PRAGMA table_info(refresh_tokens)')->fetchAll(PDO::FETCH_ASSOC), 'name');
            if (!in_array('auth_session_id', $columns, true)) {
                $db->exec('ALTER TABLE refresh_tokens ADD COLUMN auth_session_id TEXT DEFAULT NULL');
            }
            $db->exec("CREATE TABLE auth_sessions (
                id TEXT PRIMARY KEY,
                user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
                auth_version INTEGER NOT NULL,
                scope TEXT NOT NULL CHECK(scope IN ('full','onboarding')),
                auth_method TEXT NOT NULL CHECK(auth_method IN ('password','webauthn','magic','internal')),
                invitation_id INTEGER DEFAULT NULL,
                expires_at INTEGER NOT NULL,
                revoked_at INTEGER DEFAULT NULL
            )");
            $db->exec('CREATE INDEX idx_auth_sessions_user ON auth_sessions(user_id)');
            $db->exec('CREATE INDEX idx_auth_sessions_expiry ON auth_sessions(expires_at)');
            $db->exec('CREATE INDEX idx_refresh_tokens_session ON refresh_tokens(auth_session_id)');
            $db->exec("UPDATE refresh_tokens SET revoked=1,revoked_at=datetime('now') WHERE revoked=0");
            $db->exec('CREATE TABLE auth_security_schema(version INTEGER NOT NULL)');
            $db->exec('INSERT INTO auth_security_schema VALUES(1)');
            if ($owns) {
                $db->exec('COMMIT');
            }
        } catch (\Throwable $e) {
            if ($owns) {
                $db->exec('ROLLBACK');
            }
            throw $e;
        }
    }
}
