<?php
/**
 * NOMAD CMS — Bounded SQLite authentication transactions.
 * Acquires the writer lock before reading consumable authentication state.
 * Savepoints preserve callers' existing transactions and support nested work.
 */

declare(strict_types=1);

namespace NomadCMS\Auth;

use NomadCMS\Database\AuthDatabase;

final class AuthTransaction
{
    private static int $depth = 0;

    public static function run(callable $operation): mixed
    {
        $db = AuthDatabase::getInstance();
        $owns = self::$depth === 0 && !$db->inTransaction();
        $savepoint = 'auth_' . self::$depth;
        $db->exec($owns ? 'BEGIN IMMEDIATE' : 'SAVEPOINT ' . $savepoint);
        self::$depth++;
        try {
            $result = $operation($db);
            $db->exec($owns ? 'COMMIT' : 'RELEASE SAVEPOINT ' . $savepoint);
            return $result;
        } catch (\Throwable $e) {
            $db->exec($owns ? 'ROLLBACK' : 'ROLLBACK TO SAVEPOINT ' . $savepoint);
            if (!$owns) {
                $db->exec('RELEASE SAVEPOINT ' . $savepoint);
            }
            throw $e;
        } finally {
            self::$depth--;
        }
    }
}
