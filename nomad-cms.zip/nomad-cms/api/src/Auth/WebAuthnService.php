<?php
/**
 * NOMAD CMS - WebAuthn Service
 * Passkey/Biometric authentication using FIDO2
 */

declare(strict_types=1);

namespace NomadCMS\Auth;

use lbuchs\WebAuthn\WebAuthn;
use lbuchs\WebAuthn\Binary\ByteBuffer;
use NomadCMS\Config\Security;
use NomadCMS\Database\AuthDatabase;
use Ramsey\Uuid\Uuid;

final class WebAuthnService
{
    private static ?WebAuthn $webAuthn = null;
    
    /**
     * Get WebAuthn instance
     */
    private static function getInstance(): WebAuthn
    {
        if (self::$webAuthn === null) {
            $config = Security::getWebAuthnConfig();
            
            self::$webAuthn = new WebAuthn(
                $config['rp_name'],
                $config['rp_id'],
                ['none']  // attestation: none, indirect, or direct
            );
            
            // Attestation 'none' accepts privacy-preserving authenticators without
            // manufacturer roots. Origin and UV are verified by the server.
        }
        
        return self::$webAuthn;
    }
    
    /**
     * Helper to decode Base64URL encoded strings safely
     */
    private static function base64url_decode(string $data): string
    {
        $b64 = strtr($data, '-_', '+/');
        $padLength = strlen($b64) % 4;
        if ($padLength !== 0) {
            $b64 .= str_repeat('=', 4 - $padLength);
        }
        if (strlen($data) > 65536 || !preg_match('/^[A-Za-z0-9_+\/=-]*$/D', $data)) {
            throw new AuthException('INVALID_WEBAUTHN_DATA', 'Invalid credential encoding.', 400);
        }
        $decoded = base64_decode($b64, true);
        if ($decoded === false) {
            throw new AuthException('INVALID_WEBAUTHN_DATA', 'Invalid credential encoding.', 400);
        }
        return $decoded;
    }
    
    /**
     * Generate registration options (credential creation)
     * Call this to start passkey registration flow
     */
    public static function getRegistrationOptions(array $user, array $excludeCredentialIds = []): array
    {
        $webAuthn = self::getInstance();
        $config = Security::getWebAuthnConfig();
        
        // User handle is the unique identifier for WebAuthn
        $userHandle = self::userHandle($user['uuid']);
        
        // Prepare excluded credentials (already registered passkeys)
        $excludeCredentials = [];
        foreach ($excludeCredentialIds as $credId) {
            $excludeCredentials[] = new ByteBuffer(self::base64url_decode($credId));
        }
        
        // Generate creation options
        $createArgs = $webAuthn->getCreateArgs(
            $userHandle,                    // User ID
            $user['email'],                 // User name (display)
            $user['email'],                 // User display name
            max(1, (int) ceil($config['timeout'] / 1000)), // Library expects seconds
            true,                           // Require resident key (discoverable)
            'required',                    // Standalone passkeys require PIN/biometrics
            null,                          // Any authenticator attachment
            $excludeCredentials             // Already registered credentials
        );
        
        // Store challenge in session for verification
        self::rememberChallenge('register', (int) $user['id'], $user['_auth_session_id'] ?? null, []);
        
        return [
            'options' => $createArgs,
            'challenge' => $webAuthn->getChallenge()->getHex(),
        ];
    }
    
    /**
     * Verify registration response and store credential
     */
    public static function verifyRegistration(string $clientDataJSON, string $attestationObject, int $expectedUserId, ?string $friendlyName = null, ?string $sessionId = null): array
    {
        $webAuthn = self::getInstance();
        
        // Consume before verification: failed or replayed ceremonies must restart.
        $context = self::consumeChallenge('register', $expectedUserId, $sessionId);
        $challenge = $context['challenge'];
        $userId = $context['user_id'];
        self::assertOrigin($clientDataJSON);
        $user = \NomadCMS\Database\UserRepository::findById($userId);
        AuthSessionService::assertUser($user, 'webauthn');

        // Process the response
        $data = $webAuthn->processCreate(
            self::base64url_decode($clientDataJSON),
            self::base64url_decode($attestationObject),
            new ByteBuffer(hex2bin($challenge)),
            true,   // Require user verification
            true,   // Require user presence
            false   // No attestation root requirement; origin was checked above
        );
        
        // Store credential in database
        // Handle different return types from processCreate()
        $credentialIdRaw = $data->credentialId;
        if ($credentialIdRaw instanceof ByteBuffer) {
            $credentialId = base64_encode($credentialIdRaw->getBinaryString());
        } else {
            // Already a string (base64 encoded or binary)
            $credentialId = is_string($credentialIdRaw) ? base64_encode($credentialIdRaw) : base64_encode((string)$credentialIdRaw);
        }
        $publicKey = base64_encode($data->credentialPublicKey);
        
        $db = AuthDatabase::getInstance();
        $stmt = $db->prepare("
            INSERT INTO webauthn_credentials 
            (user_id, credential_id, public_key, attestation_type, transports, sign_count, user_handle, friendly_name)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ");
        
        // SECURITY FIX: Use prepared statement to prevent SQL injection
        $uuidStmt = $db->prepare("SELECT uuid FROM users WHERE id = ?");
        $uuidStmt->execute([$userId]);
        $userUuid = $uuidStmt->fetchColumn();
        
        $stmt->execute([
            $userId,
            $credentialId,
            $publicKey,
            $data->attestationFormat ?? 'none',
            json_encode(['internal', 'hybrid']), // Common transports
            $data->signatureCounter ?? 0,
            $userUuid,
            $friendlyName ?? 'Passkey ' . date('Y-m-d'),
        ]);
        
        return [
            'credential_id' => $credentialId,
            'message' => 'Passkey registered successfully',
        ];
    }
    
    /**
     * Generate authentication options (assertion)
     * Call this to start passkey login flow
     */
    public static function getAuthenticationOptions(?string $email = null, string $purpose = 'login', ?int $expectedUserId = null, ?string $sessionId = null): array
    {
        $webAuthn = self::getInstance();
        $config = Security::getWebAuthnConfig();
        
        if (!in_array($purpose, ['login', 'onboarding'], true)) {
            throw new AuthException('INVALID_WEBAUTHN_PURPOSE', 'Invalid credential operation.', 400);
        }
        if ($email !== null) {
            $target = \NomadCMS\Database\UserRepository::findByEmail($email);
            $expectedUserId = $target ? (int) $target['id'] : -1;
        }
        // Get allowed credentials for user (if email provided)
        $allowCredentials = [];
        if ($email) {
            $db = AuthDatabase::getInstance();
            $stmt = $db->prepare("
                SELECT wc.credential_id 
                FROM webauthn_credentials wc
                JOIN users u ON wc.user_id = u.id
                WHERE u.email = ?
                LIMIT 100
            ");
            $stmt->execute([$email]);
            
            while ($row = $stmt->fetch()) {
                $allowCredentials[] = new ByteBuffer(self::base64url_decode($row['credential_id']));
            }
        }
        
        // Generate get args
        $getArgs = $webAuthn->getGetArgs(
            $allowCredentials,
            max(1, (int) ceil($config['timeout'] / 1000)),
            true, true, true, true, true,
            'required'
        );

        // Store ceremony type, owner, allowed IDs, session and bounded lifetime.
        self::rememberChallenge($purpose, $expectedUserId, $sessionId, array_map(
            static fn(ByteBuffer $id): string => base64_encode($id->getBinaryString()),
            $allowCredentials
        ));

        return [
            'options' => $getArgs,
            'challenge' => $webAuthn->getChallenge()->getHex(),
        ];
    }
    
    /**
     * Verify authentication response
     * Returns user data if successful
     */
    public static function verifyAuthentication(
        string $credentialId,
        string $clientDataJSON,
        string $authenticatorData,
        string $signature,
        ?string $userHandle = null,
        string $purpose = 'login',
        ?int $expectedUserId = null,
        ?string $sessionId = null
    ): array {
        $webAuthn = self::getInstance();
        
        // A registration challenge cannot authenticate, and vice versa.
        $context = self::consumeChallenge($purpose, $expectedUserId, $sessionId);
        $challenge = $context['challenge'];
        self::assertOrigin($clientDataJSON);

        // Find credential in database
        $db = AuthDatabase::getInstance();
        // Normalize incoming credentialId to standard Base64 for DB lookup
        $decodedCredId = base64_encode(self::base64url_decode($credentialId));
        
        $stmt = $db->prepare("
            SELECT wc.*, u.id as user_id, u.uuid, u.email, u.is_admin,
                   u.role_slug, u.role
            FROM webauthn_credentials wc
            JOIN users u ON wc.user_id = u.id
            WHERE wc.credential_id = ?
        ");
        $stmt->execute([$decodedCredId]);
        $credential = $stmt->fetch();
        
        if (!$credential) {
            throw new \Exception('Credential not found');
        }
        
        $user = \NomadCMS\Database\UserRepository::findById((int) $credential['user_id']);
        AuthSessionService::assertUser($user, 'webauthn');
        if (($context['user_id'] !== null && $context['user_id'] !== (int) $credential['user_id'])
            || ($context['allowed_ids'] !== [] && !in_array($decodedCredId, $context['allowed_ids'], true))) {
            throw new AuthException('WEBAUTHN_OWNER_MISMATCH', 'Credential does not belong to this ceremony.');
        }
        if ($userHandle !== null) {
            $handle = self::base64url_decode($userHandle);
            // Existing registrations used the UUID's ASCII hex as the handle.
            if (!hash_equals(self::userHandle($credential['uuid']), $handle)
                && !hash_equals(str_replace('-', '', $credential['uuid']), $handle)) {
                throw new AuthException('WEBAUTHN_OWNER_MISMATCH', 'Credential user handle mismatch.');
            }
        } elseif ($context['user_id'] === null) {
            throw new AuthException('WEBAUTHN_OWNER_MISMATCH', 'Discoverable credentials require a user handle.');
        }

        // Verify the assertion
        $webAuthn->processGet(
            self::base64url_decode($clientDataJSON),
            self::base64url_decode($authenticatorData),
            self::base64url_decode($signature),
            self::base64url_decode($credential['public_key']),
            new ByteBuffer(hex2bin($challenge)),
            (int) $credential['sign_count'], // Previous counter, including zero
            true,  // Require user verification
            true   // Require user presence
        );
        
        // Update sign count (replay protection)
        $stmt = $db->prepare("
            UPDATE webauthn_credentials 
            SET sign_count = ?, last_used_at = datetime('now')
            WHERE credential_id = ? AND sign_count = ?
        ");
        $stmt->execute([$webAuthn->getSignatureCounter() ?? 0, $decodedCredId, $credential['sign_count']]);
        
        if ($stmt->rowCount() !== 1) {
            throw new AuthException('WEBAUTHN_COUNTER_CHANGED', 'Credential state changed. Restart authentication.');
        }

        // Extended RBAC: carry the authoritative role through so callers minting
        // tokens never fall back to a guessed viewer role. All account status
        // and authentication-method settings are returned with the user row.
        return \NomadCMS\Database\UserRepository::findById((int) $credential['user_id']);

    }
    
    private static function userHandle(string $uuid): string
    {
        $hex = str_replace('-', '', $uuid);
        if (!preg_match('/^[a-f0-9]{32}$/iD', $hex)) {
            throw new AuthException('INVALID_USER_HANDLE', 'Invalid credential owner.', 400);
        }
        return hex2bin($hex);
    }

    private static function rememberChallenge(string $purpose, ?int $userId, ?string $sessionId, array $ids): void
    {
        unset($_SESSION['webauthn_challenge'], $_SESSION['webauthn_user_id']);
        $_SESSION['webauthn_ceremony'] = [
            'purpose' => $purpose, 'challenge' => self::getInstance()->getChallenge()->getHex(),
            'user_id' => $userId, 'session_id' => $sessionId,
            'allowed_ids' => $ids, 'expires_at' => time() + 120,
        ];
    }

    private static function consumeChallenge(string $purpose, ?int $userId, ?string $sessionId): array
    {
        $context = $_SESSION['webauthn_ceremony'] ?? null;
        unset($_SESSION['webauthn_ceremony']);
        if (!is_array($context) || $context['purpose'] !== $purpose || $context['expires_at'] <= time()
            || ($userId !== null && $context['user_id'] !== $userId)
            || $context['session_id'] !== $sessionId) {
            throw new AuthException('INVALID_WEBAUTHN_CHALLENGE', 'Credential challenge expired or mismatched.');
        }
        return $context;
    }

    private static function assertOrigin(string $clientDataJSON): void
    {
        $client = json_decode(self::base64url_decode($clientDataJSON), true, 16);
        $origin = Security::getWebAuthnConfig()['rp_origin'];
        if (!is_array($client) || ($client['origin'] ?? null) !== $origin
            || ($client['crossOrigin'] ?? false) !== false) {
            throw new AuthException('WEBAUTHN_ORIGIN_MISMATCH', 'Credential origin is not allowed.');
        }
    }

    /**
     * Get user's registered credentials
     */
    public static function getUserCredentials(int $userId): array
    {
        $db = AuthDatabase::getInstance();
        $stmt = $db->prepare("
            SELECT id, credential_id, friendly_name, created_at, last_used_at
            FROM webauthn_credentials
            WHERE user_id = ?
            ORDER BY created_at DESC
        ");
        $stmt->execute([$userId]);
        
        return $stmt->fetchAll();
    }
    
    /**
     * Delete a credential
     */
    public static function deleteCredential(int $userId, int $credentialDbId): bool
    {
        $db = AuthDatabase::getInstance();
        $stmt = $db->prepare("DELETE FROM webauthn_credentials WHERE id = ? AND user_id = ?");
        $stmt->execute([$credentialDbId, $userId]);
        return $stmt->rowCount() === 1;
    }
}
