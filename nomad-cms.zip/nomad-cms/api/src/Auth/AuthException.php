<?php
/**
 * NOMAD CMS — Authentication boundary failures.
 * Carries a stable public error code without exposing credentials or storage
 * details. Authentication endpoints render these failures consistently.
 */

declare(strict_types=1);

namespace NomadCMS\Auth;

final class AuthException extends \RuntimeException
{
    public function __construct(public readonly string $errorCode, string $message, int $status = 401)
    {
        parent::__construct($message, $status);
    }
}
