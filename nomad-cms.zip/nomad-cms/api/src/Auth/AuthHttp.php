<?php
/**
 * NOMAD CMS — Authentication HTTP input and error boundary.
 * Bounds JSON bodies, rejects wrong field types, validates browser origins
 * for cookie operations, and never returns internal exception details.
 */

declare(strict_types=1);

namespace NomadCMS\Auth;

final class AuthHttp
{
    public static function body(): array
    {
        $raw = file_get_contents('php://input', false, null, 0, 65537);
        if ($raw === false || strlen($raw) > 65536) {
            self::respond(new AuthException('INVALID_BODY', 'Invalid request body.', 400));
        }
        if ($raw === '') {
            return [];
        }
        $body = json_decode($raw, true, 16);
        if (!is_array($body) || !str_starts_with(ltrim($raw), '{') || json_last_error() !== JSON_ERROR_NONE) {
            self::respond(new AuthException('INVALID_BODY', 'A JSON object is required.', 400));
        }
        return $body;
    }

    public static function string(array $body, string $field, int $max = 4096, string $default = ''): string
    {
        $value = $body[$field] ?? $default;
        if (!is_string($value) || strlen($value) > $max) {
            self::respond(new AuthException('INVALID_INPUT', 'Invalid ' . $field . '.', 400));
        }
        return $value;
    }

    public static function checkOrigin(): void
    {
        $origin = $_SERVER['HTTP_ORIGIN'] ?? null;
        if ($origin === null) {
            return; // Non-browser clients do not attach ambient browser cookies.
        }
        $allowed = array_filter(array_map('trim', explode(',', $_ENV['CORS_ALLOWED_ORIGINS'] ?? '')));
        foreach (['ADMIN_URL', 'SITE_URL', 'WEBAUTHN_RP_ORIGIN'] as $key) {
            $url = parse_url($_ENV[$key] ?? '');
            if (isset($url['scheme'], $url['host'])) {
                $allowed[] = $url['scheme'] . '://' . $url['host'] . (isset($url['port']) ? ':' . $url['port'] : '');
            }
        }
        $scheme = !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' ? 'https' : 'http';
        $allowed[] = $scheme . '://' . ($_SERVER['HTTP_HOST'] ?? '');
        if (!is_string($origin) || !in_array($origin, $allowed, true)) {
            throw new AuthException('ORIGIN_REJECTED', 'Request origin is not allowed.', 403);
        }
    }

    public static function respond(AuthException $e): never
    {
        http_response_code($e->getCode());
        header('Content-Type: application/json');
        header('Cache-Control: no-store');
        echo json_encode(['success' => false, 'error' => $e->getMessage(), 'code' => $e->errorCode]);
        exit;
    }
}
