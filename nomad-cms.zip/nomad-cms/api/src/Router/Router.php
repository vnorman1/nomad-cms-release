<?php
/**
 * NOMAD CMS - Path-based Router
 * 
 * Enables clean RESTful URLs while maintaining backward compatibility
 * with query parameter-based endpoints.
 * 
 * URL Mapping (high-level; see registerRoutes() for the exact, exhaustive list):
 *   /api/data/{slot}          → endpoints/data.php?key={slot}
 *   /api/static/{slot}        → endpoints/static-serve.php?slot={slot}
 *   /api/massive/{slot}       → endpoints/massive.php?slot={slot}
 *   /api/forms/{slug}         → endpoints/public/forms.php?slug={slug}  (public, no auth)
 *   /api/schema               → endpoints/schema.php
 *   /api/search               → endpoints/search.php
 *   /api/media                → endpoints/media.php
 *   /api/upload               → endpoints/upload.php
 *   /api/auth/{action}        → endpoints/auth/{action}.php
 *   /api/admin/{action}       → endpoints/admin/{action}.php
 *   /api/versions/{slot}      → endpoints/versions.php?slot_key={slot}
 *   /api/sitemap              → endpoints/sitemap.php
 *   /api/batch                → endpoints/batch-content.php
 *   /api/forge/{action}       → endpoints/forge/{action}.php
 *   /api/public/{action}      → endpoints/public/{action}.php
 *   /api/system/{action}      → endpoints/system/{action}.php
 *   /api/install/{action}     → endpoints/install/{action}.php
 * 
 * Legacy URLs (still work):
 *   /api/endpoints/data.php?key=hero  → Direct PHP execution
 *
 * KEEPING THIS ROUTER HONEST:
 * Every route here must point to a file that actually exists, and every
 * frontend-callable endpoint file should have a route here (or be in the
 * DYNAMIC_CATALOG_FILES/IGNORED_ENDPOINT_FILES allowlist in
 * frontend/scripts/verify-api-catalog.mjs). Run `npm run verify:api` in
 * frontend/ after adding, removing, or renaming a route or endpoint file —
 * it cross-checks this file against the API Playground's catalog and
 * against api/endpoints/** on disk.
 * 
 * @package NomadCMS
 * @since 2.0.0
 */

declare(strict_types=1);

namespace NomadCMS\Router;

class Router
{
    /**
     * Base path for API (e.g., '/api')
     */
    private string $basePath;

    /**
     * Endpoints directory path
     */
    private string $endpointsDir;

    /**
     * Route definitions: pattern => [file, paramMappings]
     * Pattern uses {param} syntax for path parameters
     */
    private array $routes = [];

    /**
     * Initialize router
     */
    public function __construct(string $basePath = '/api', ?string $endpointsDir = null)
    {
        $this->basePath = rtrim($basePath, '/');
        $this->endpointsDir = $endpointsDir ?? dirname(__DIR__, 2) . '/endpoints';
        $this->registerRoutes();
    }

    /**
     * Register all API routes
     */
    private function registerRoutes(): void
    {
        // SEO Studio: fixed actions precede identifiers and cannot be overridden by query parameters.
        $this->addRoute('seo/meta', 'seo.php', ['_seo_action' => 'meta']);
        $this->addRoute('seo/og/{target}.png', 'seo.php', ['target' => 'id', '_seo_action' => 'og']);
        $this->addRoute('seo/sitemap/{part}.xml', 'seo.php', ['part' => 'part', '_seo_action' => 'sitemap']);
        $seoRoutes = [
            'sitemap/rebuild' => 'sitemap_rebuild', 'overview' => 'overview', 'health' => 'health', 'targets/resolve' => 'resolve',
            'capabilities' => 'capabilities', 'settings' => 'settings', 'slots/{slot}' => 'slot',
            'routes' => 'routes', 'routes/{id}' => 'route', 'targets' => 'targets',
            'targets/{id}/metadata' => 'metadata', 'targets/{id}/audit' => 'audit',
            'targets/{id}/og/preview' => 'target_og_preview', 'targets/{id}/audit-runs' => 'target_run',
            'targets/{id}/preview' => 'preview', 'preview/{id}' => 'preview',
            'fonts' => 'fonts', 'fonts/{id}/file' => 'font_file', 'fonts/{id}' => 'font',
            'assets/{id}/file' => 'asset_file', 'templates/{id}/usages' => 'template_usages',
            'assets' => 'assets', 'assets/{id}' => 'asset', 'templates' => 'templates',
            'templates/{id}/clone' => 'clone', 'templates/{id}/activate' => 'activate',
            'templates/{id}' => 'template', 'og/preview' => 'og_preview', 'og/context' => 'og_context',
            'targets/{id}/og/regenerate' => 'regenerate', 'audit-runs' => 'audit_runs',
            'audit-runs/{id}/cancel' => 'cancel_run', 'audit-runs/{id}' => 'audit_run',
            'social-stats' => 'social_stats', 'spa-gateway/package' => 'gateway_package',
            'spa-gateway/check' => 'gateway_check', 'robots/test' => 'robots_test',
        ];
        foreach ($seoRoutes as $path => $action) {
            $parameters = ['_seo_action' => $action];
            foreach (['id', 'slot'] as $parameter) {
                if (str_contains($path, '{' . $parameter . '}')) {
                    $parameters[$parameter] = $parameter;
                }
            }
            $this->addRoute('admin/seo/' . $path, 'admin/seo.php', $parameters);
        }
        // Central notifications: fixed actions precede variable notification identifiers.
        $this->addRoute('notifications', 'notifications.php', ['_notification_action' => 'inbox']);
        $this->addRoute('notifications/unread-count', 'notifications.php', ['_notification_action' => 'unread_count']);
        $this->addRoute('notifications/updates', 'notifications.php', ['_notification_action' => 'updates']);
        $this->addRoute('notifications/read-all', 'notifications.php', ['_notification_action' => 'read_all']);
        $this->addRoute('notifications/{notification}/read', 'notifications.php', ['notification' => 'notification_id', '_notification_action' => 'read']);
        $this->addRoute('notifications/{notification}/archive', 'notifications.php', ['notification' => 'notification_id', '_notification_action' => 'archive']);
        $this->addRoute('notifications/{notification}/target', 'notifications.php', ['notification' => 'notification_id', '_notification_action' => 'target']);
        $this->addRoute('notifications/{notification}', 'notifications.php', ['notification' => 'notification_id', '_notification_action' => 'item']);
        $this->addRoute('notification-preferences', 'notification-preferences.php', ['_notification_action' => 'preferences']);
        $this->addRoute('admin/notifications/capabilities', 'admin/notifications.php', ['_notification_action' => 'capabilities']);
        $this->addRoute('admin/notifications/recipients', 'admin/notifications.php', ['_notification_action' => 'recipients']);
        $this->addRoute('admin/notifications/preview', 'admin/notifications.php', ['_notification_action' => 'preview']);
        $this->addRoute('admin/notifications', 'admin/notifications.php', ['_notification_action' => 'announcements']);
        $this->addRoute('admin/notifications/{notification}', 'admin/notifications.php', ['notification' => 'notification_id', '_notification_action' => 'announcement']);
        $this->addRoute('admin/event-rules/preview', 'admin/event-rules.php', ['_notification_action' => 'rule_preview']);
        $this->addRoute('admin/event-rules', 'admin/event-rules.php', ['_notification_action' => 'rules']);
        $this->addRoute('admin/event-rules/{notification}', 'admin/event-rules.php', ['notification' => 'notification_id', '_notification_action' => 'rule']);
        $this->addRoute('admin/event-destinations', 'admin/event-destinations.php', ['_notification_action' => 'destinations']);
        $this->addRoute('admin/event-destinations/{notification}', 'admin/event-destinations.php', ['notification' => 'notification_id', '_notification_action' => 'destination']);
        $this->addRoute('admin/event-deliveries', 'admin/event-deliveries.php', ['_notification_action' => 'deliveries']);
        $this->addRoute('admin/event-deliveries/{notification}/retry', 'admin/event-deliveries.php', ['notification' => 'notification_id', '_notification_action' => 'retry']);
        $this->addRoute('admin/events/catalog', 'admin/events.php', ['_notification_action' => 'catalog']);
        $this->addRoute('admin/events/webhook-options', 'admin/events.php', ['_notification_action' => 'webhook_options']);
        $this->addRoute('admin/events/status', 'admin/events.php', ['_notification_action' => 'status']);

        // Internal Editorials Hub: fixed dispatch actions override query-string guesses.
        $this->addRoute('admin/editorials/boards', 'admin/editorials/boards.php', ['_eh_action'=>'boards']);
        $this->addRoute('admin/editorials/boards/{board}', 'admin/editorials/boards.php', ['board'=>'board','_eh_action'=>'board']);
        $this->addRoute('admin/editorials/boards/{board}/members', 'admin/editorials/boards.php', ['board'=>'board','_eh_action'=>'members']);
        $this->addRoute('admin/editorials/boards/{board}/statuses', 'admin/editorials/boards.php', ['board'=>'board','_eh_action'=>'statuses']);
        $this->addRoute('admin/editorials/boards/{board}/items', 'admin/editorials/items.php', ['board'=>'board','_eh_action'=>'items']);
        $this->addRoute('admin/editorials/boards/{board}/viewport', 'admin/editorials/items.php', ['board'=>'board','_eh_action'=>'viewport']);
        $this->addRoute('admin/editorials/boards/{board}/tickets', 'admin/editorials/items.php', ['board'=>'board','_eh_action'=>'tickets']);
        $this->addRoute('admin/editorials/boards/{board}/tickets/move', 'admin/editorials/items.php', ['board'=>'board','_eh_action'=>'ticket_move']);
        $this->addRoute('admin/editorials/boards/{board}/geometry', 'admin/editorials/items.php', ['board'=>'board','_eh_action'=>'geometry']);
        $this->addRoute('admin/editorials/boards/{board}/connectors', 'admin/editorials/items.php', ['board'=>'board','_eh_action'=>'connectors']);
        $this->addRoute('admin/editorials/boards/{board}/connectors/{connector}', 'admin/editorials/items.php', ['board'=>'board','connector'=>'connector','_eh_action'=>'connector']);
        $this->addRoute('admin/editorials/items/{item}', 'admin/editorials/items.php', ['item'=>'item','_eh_action'=>'item']);
        $this->addRoute('admin/editorials/items/{item}/threads', 'admin/editorials/threads.php', ['item'=>'item','_eh_action'=>'threads']);
        $this->addRoute('admin/editorials/items/{item}/annotations', 'admin/editorials/annotations.php', ['item'=>'item','_eh_action'=>'annotations']);
        $this->addRoute('admin/editorials/boards/{board}/annotations', 'admin/editorials/annotations.php', ['board'=>'board','_eh_action'=>'board_annotations']);
        $this->addRoute('admin/editorials/targets/annotations', 'admin/editorials/annotations.php', ['_eh_action'=>'target_annotations']);
        $this->addRoute('admin/editorials/annotations/{annotation}', 'admin/editorials/annotations.php', ['annotation'=>'annotation','_eh_action'=>'annotation']);
        $this->addRoute('admin/editorials/threads/{thread}', 'admin/editorials/threads.php', ['thread'=>'thread','_eh_action'=>'thread']);
        $this->addRoute('admin/editorials/threads/{thread}/messages', 'admin/editorials/threads.php', ['thread'=>'thread','_eh_action'=>'messages']);
        $this->addRoute('admin/editorials/messages/{message}', 'admin/editorials/threads.php', ['message'=>'message','_eh_action'=>'message']);
        $this->addRoute('admin/editorials/boards/{board}/changes', 'admin/editorials/sync.php', ['board'=>'board','_eh_action'=>'changes']);
        $this->addRoute('admin/editorials/boards/{board}/presence', 'admin/editorials/sync.php', ['board'=>'board','_eh_action'=>'presence']);
        $this->addRoute('admin/editorials/notes/{note}/updates', 'admin/editorials/sync.php', ['note'=>'note','_eh_action'=>'updates']);
        $this->addRoute('admin/editorials/notes/{note}/checkpoint', 'admin/editorials/sync.php', ['note'=>'note','_eh_action'=>'checkpoint']);
        $this->addRoute('admin/editorials/notes/{note}/projection', 'admin/editorials/sync.php', ['note'=>'note','_eh_action'=>'projection']);
        $this->addRoute('admin/editorials/targets/suggest', 'admin/editorials/targets.php', ['_eh_action'=>'suggest']);
        $this->addRoute('admin/editorials/users/suggest', 'admin/editorials/targets.php', ['_eh_action'=>'users']);
        $this->addRoute('admin/editorials/references', 'admin/editorials/targets.php', ['_eh_action'=>'references']);
        $this->addRoute('admin/editorials/references/{reference}', 'admin/editorials/targets.php', ['reference'=>'reference','_eh_action'=>'reference']);
        $this->addRoute('admin/editorials/proposals', 'admin/editorials/targets.php', ['_eh_action'=>'proposals']);
        $this->addRoute('admin/editorials/proposals/{proposal}', 'admin/editorials/targets.php', ['proposal'=>'proposal','_eh_action'=>'proposal']);
        $this->addRoute('admin/editorials/transfers/preview', 'admin/editorials/transfers.php', ['_eh_action'=>'preview']);
        $this->addRoute('admin/editorials/transfers/apply', 'admin/editorials/transfers.php', ['_eh_action'=>'apply']);
        $this->addRoute('admin/editorials/boards/{board}/attachments', 'admin/editorials/attachments.php', ['board'=>'board','_eh_action'=>'attachments']);
        $this->addRoute('admin/editorials/attachments/{attachment}/content', 'admin/editorials/attachments.php', ['attachment'=>'attachment','_eh_action'=>'content']);

        // ═══════════════════════════════════════════════════════════════════
        // CONTENT DATA ROUTES
        // ═══════════════════════════════════════════════════════════════════
        
        // GET/POST/DELETE /api/data/{slot}
        $this->addRoute('data/{slot}', 'data.php', ['slot' => 'key']);
        
        // GET /api/data/{slot}/{item} - Single item from collection slot
        $this->addRoute('data/{slot}/{item}', 'data.php', ['slot' => 'key', 'item' => 'item']);
        
        // GET /api/static/{slot} - Cached static content (full slot)
        $this->addRoute('static/{slot}', 'static-serve.php', ['slot' => 'slot']);
        
        // GET /api/static/{slot}/{item} - Cached static content (single item)
        $this->addRoute('static/{slot}/{item}', 'static-serve.php', ['slot' => 'slot', 'item' => 'item']);

        // GET /api/data/{slot}/chunk_{chunk} and /api/data/{slot}/chunk_{chunk}.json - Dynamic chunk endpoints
        $this->addRoute('data/{slot}/chunk_{chunk}', 'data.php', ['slot' => 'key', 'chunk' => 'chunk']);
        $this->addRoute('data/{slot}/chunk_{chunk}.json', 'data.php', ['slot' => 'key', 'chunk' => 'chunk']);

        // GET /api/static/content/{slot}/manifest.json - Static manifest compatibility endpoint
        $this->addRoute('static/content/{slot}/manifest.json', 'data.php', ['slot' => 'key']);

        // GET /api/static/content/{slot}/chunk_{chunk}.json - Static chunk compatibility endpoint
        $this->addRoute('static/content/{slot}/chunk_{chunk}.json', 'data.php', ['slot' => 'key', 'chunk' => 'chunk']);

        // GET /api/static/content/{slot}/{item}.json - Static item compatibility endpoint
        $this->addRoute('static/content/{slot}/{item}.json', 'data.php', ['slot' => 'key', 'item' => 'item']);
        
        // GET/POST/PUT/DELETE /api/massive/{slot} - Large dataset operations
        $this->addRoute('massive/{slot}', 'massive.php', ['slot' => 'slot']);
        $this->addRoute('massive/{slot}/{id}', 'massive.php', ['slot' => 'slot', 'id' => 'id']);
        
        // ═══════════════════════════════════════════════════════════════════
        // SCHEMA & SYSTEM ROUTES
        // ═══════════════════════════════════════════════════════════════════
        
        // GET /api/schema - Full CMS schema
        $this->addRoute('schema', 'schema.php');
        $this->addRoute('admin/schema', 'admin/schema.php');
        
        // GET /api/search - Content search
        $this->addRoute('search', 'search.php');
        
        // GET /api/sitemap - XML sitemap
        $this->addRoute('sitemap', 'sitemap.php');
        $this->addRoute('sitemap.xml', 'sitemap.php');
        
        // Generation members use the same zero-bootstrap handler as the public root aliases.
        $this->addRoute('sitemaps/{generation}/{file}.xml', 'sitemap.php', [
            'generation' => 'generation', 'file' => 'index_a', 'discovery_kind' => 'xml',
        ]);
        $this->addRoute('llms-index/{generation}/{a}/{b}/{c}/{d}.md', 'sitemap.php', [
            'generation' => 'generation', 'a' => 'index_a', 'b' => 'index_b',
            'c' => 'index_c', 'd' => 'index_d', 'discovery_kind' => 'md',
        ]);
        $this->addRoute('llms-index/{generation}/{a}/{b}/{c}.md', 'sitemap.php', [
            'generation' => 'generation', 'a' => 'index_a', 'b' => 'index_b', 'c' => 'index_c', 'discovery_kind' => 'md',
        ]);
        $this->addRoute('llms-index/{generation}/{a}/{b}.md', 'sitemap.php', [
            'generation' => 'generation', 'a' => 'index_a', 'b' => 'index_b', 'discovery_kind' => 'md',
        ]);
        $this->addRoute('llms-index/{generation}/{a}.md', 'sitemap.php', [
            'generation' => 'generation', 'a' => 'index_a', 'discovery_kind' => 'md',
        ]);

        // GET /api/robots - Robots.txt
        $this->addRoute('robots', 'sitemap.php', ['robots' => '1']);
        $this->addRoute('robots.txt', 'sitemap.php', ['robots' => '1']);
        
        // GET /api/llms - LLMs.txt (supports ?lang=xx query param)
        $this->addRoute('llms', 'sitemap.php', ['llms' => '1']);
        $this->addRoute('llms.txt', 'sitemap.php', ['llms' => '1']);
        
        // GET /api/llms/{slot}/{slug} and /api/llms/{lang}/{slot}/{slug} - Dynamic LLM Markdown item
        $this->addRoute('llms/{lang}/{slot}/{slug}', 'llms-item.php', ['lang' => 'lang', 'slot' => 'slot', 'slug' => 'slug']);
        $this->addRoute('llms/{slot}/{slug}', 'llms-item.php', ['slot' => 'slot', 'slug' => 'slug']);
        $this->addRoute('llms/{lang}/{slot}', 'llms-item.php', ['lang' => 'lang', 'slot' => 'slot']);
        $this->addRoute('llms/{slot}', 'llms-item.php', ['slot' => 'slot']);
        
        // GET /api/versions/{slot} - Version history
        //
        // NOTE: versions.php reads the slot query param as `slot_key`
        // (not `slot`) — this mapping used to be wrong (mapped to `slot`,
        // which the endpoint never reads), silently breaking every
        // path-mode version request. Fixed here.
        $this->addRoute('versions/{slot}', 'versions.php', ['slot' => 'slot_key']);
        $this->addRoute('versions', 'versions.php');
        
        // POST/DELETE /api/presence - Active editor presence heartbeat & soft collision warning
        $this->addRoute('presence', 'presence.php');
        $this->addRoute('presence/{slot}', 'presence.php', ['slot' => 'slot_key']);
        $this->addRoute('presence/{slot}/{item}', 'presence.php', ['slot' => 'slot_key', 'item' => 'item_id']);
        
        // ═══════════════════════════════════════════════════════════════════
        // MEDIA ROUTES
        // ═══════════════════════════════════════════════════════════════════
        
        // POST /api/upload - File upload
        $this->addRoute('upload', 'upload.php');
        
        // GET/DELETE /api/media - Media library
        // NOTE: media.php identifies a file by name via ?file=, not a numeric
        // id — {id} here is really "the filename" despite the segment name.
        $this->addRoute('media', 'media.php');
        $this->addRoute('media/{id}', 'media.php', ['id' => 'file']);
        
        // POST /api/audio-upload
        $this->addRoute('audio-upload', 'audio-upload.php');
        
        // POST /api/video-upload
        $this->addRoute('video-upload', 'video-upload.php');
        
        // GET /api/file/{id} - Pretty-URL file server
        // NOTE: file-serve.php reads the pretty-URL path directly from
        // REQUEST_URI (see its own path-stripping logic), not from a query
        // param — so no param mapping is registered here. The ?path= query
        // param it also supports is a direct-call fallback, unrelated to this
        // path-mode route.
        $this->addRoute('file/{id}', 'file-serve.php');
        
        // GET /api/file-download/{id} - File download (including secure/decrypt)
        // NOTE: file-download.php identifies the file by name via ?file=.
        $this->addRoute('file-download/{id}', 'file-download.php', ['id' => 'file']);
        
        // POST/DELETE /api/delete - legacy image delete (superseded by /media DELETE
        // for new integrations, kept for backwards compatibility)
        $this->addRoute('delete', 'delete.php');
        
        // GET /api/signed-url
        $this->addRoute('signed-url', 'get-signed-url.php');
        
        // ═══════════════════════════════════════════════════════════════════
        // AUTH ROUTES
        // ═══════════════════════════════════════════════════════════════════
        
        // POST /api/auth/login
        $this->addRoute('auth/login', 'auth/login.php');
        
        // POST /api/auth/logout
        $this->addRoute('auth/logout', 'auth/logout.php');
        
        // POST /api/auth/refresh
        $this->addRoute('auth/refresh', 'auth/refresh.php');
        
        // GET /api/auth/me
        $this->addRoute('auth/me', 'auth/me.php');
        
        // POST /api/auth/register
        $this->addRoute('auth/register', 'auth/register.php');
        
        // GET/PUT /api/auth/preferences
        $this->addRoute('auth/preferences', 'auth/preferences.php');
        
        // PUT /api/auth/settings - update email/password/auth method
        $this->addRoute('auth/settings', 'auth/settings.php');
        
        // GET/POST /api/auth/totp-setup - enable/disable 2FA
        $this->addRoute('auth/totp-setup', 'auth/totp-setup.php');
        
        // GET (?action=options) / POST /api/auth/webauthn-register - passkey registration
        $this->addRoute('auth/webauthn-register', 'auth/webauthn-register.php');
        
        // POST /api/auth/webauthn-login - passkey authentication
        $this->addRoute('auth/webauthn-login', 'auth/webauthn-login.php');
        
        // POST /api/auth/magic-login - redeem a magic link into an onboarding session
        $this->addRoute('auth/magic-login', 'auth/magic-login.php');
        
        // POST /api/auth/onboarding - finish onboarding (set own password)
        $this->addRoute('auth/onboarding', 'auth/onboarding.php');
        
        // POST /api/auth/ar-request - self-service password recovery request
        $this->addRoute('auth/ar-request', 'auth/ar-request.php');
        
        // ═══════════════════════════════════════════════════════════════════
        // ADMIN ROUTES
        // ═══════════════════════════════════════════════════════════════════
        
        // GET/POST /api/admin/users
        $this->addRoute('admin/users', 'admin/users.php');
        
        // PUT/DELETE/PATCH /api/admin/user-actions - update/delete/lock-toggle
        $this->addRoute('admin/user-actions', 'admin/user-actions.php');
        
        // GET/POST/DELETE /api/admin/user-invitations - magic link management
        $this->addRoute('admin/user-invitations', 'admin/user-invitations.php');
        
        // GET/POST/PUT/DELETE /api/admin/roles
        $this->addRoute('admin/roles', 'admin/roles.php');
        
        // PUT /api/admin/role-assignments
        $this->addRoute('admin/role-assignments', 'admin/role-assignments.php');
        
        // GET/POST /api/admin/api-keys
        $this->addRoute('admin/api-keys', 'admin/api-keys.php');
        
        // GET/POST /api/admin/panic - panic (read-only) mode status/toggle
        $this->addRoute('admin/panic', 'admin/panic.php');
        
        // GET/POST /api/admin/backup - zero-knowledge backup download/restore
        $this->addRoute('admin/backup', 'admin/backup.php');
        
        // GET/POST /api/admin/slot-backup - granular single-slot JSON export/inspect/import
        $this->addRoute('admin/slot-backup', 'admin/slot-backup.php');
        
        // POST /api/admin/cache-rebuild - rebuild/purge static cache
        $this->addRoute('admin/cache-rebuild', 'admin/cache-rebuild.php');
        
        // GET/POST /api/admin/cache-settings
        $this->addRoute('admin/cache-settings', 'admin/cache-settings.php');
        
        // GET/POST /api/admin/media-settings
        $this->addRoute('admin/media-settings', 'admin/media-settings.php');
        
        // GET/POST/PUT/DELETE /api/admin/webhooks - outgoing webhooks + incoming endpoints
        $this->addRoute('admin/webhooks', 'admin/webhooks.php');
        
        // GET/POST/PUT/PATCH/DELETE /api/admin/webhook-actions - action chains/providers
        $this->addRoute('admin/webhook-actions', 'webhook-actions.php');
        
        // GET/POST/DELETE /api/admin/webhook-mapping - automapper: incoming field
        // discovery, target catalog, heuristic suggestions, rule CRUD
        $this->addRoute('admin/webhook-mapping', 'admin/webhook-mapping.php');
        
        // GET/POST /api/admin/webhook-events - raw event inbox + replay
        $this->addRoute('admin/webhook-events', 'admin/webhook-events.php');
        
        // POST /api/webhooks/{slug} - INCOMING webhook ingest (public, no auth;
        // authenticity comes from the endpoint's HMAC signature, not a session).
        //
        // This is a pretty-URL alias for the long-standing
        // webhook-receiver.php?endpoint=KEY form, which keeps working: a user
        // who already pasted the query-string URL into Stripe/Cal.com must not
        // have their integration broken by this addition. Both spellings hit
        // the same script and therefore the same signature/mode policy.
        $this->addRoute('webhooks/{slug}', 'webhook-receiver.php', ['slug' => 'endpoint']);
        
        // GET/POST/PUT/DELETE /api/admin/forms - form definitions
        $this->addRoute('admin/forms', 'admin/forms.php');

        // GET/POST /api/admin/analytics - 0-PII dashboard: overview/explore/export/settings/aggregate/purge
        $this->addRoute('admin/analytics', 'admin/analytics.php');
        
        // GET/POST/DELETE /api/admin/form-submissions - submission inbox
        $this->addRoute('admin/form-submissions', 'admin/form-submissions.php');

        // GET/DELETE /api/admin/form-files - attachment library + downloads
        $this->addRoute('admin/form-files', 'admin/form-files.php');

        // GET/POST /api/admin/form-captcha - per-form + global captcha config
        $this->addRoute('admin/form-captcha', 'admin/form-captcha.php');

        // GET /api/admin/form-mail-profiles - verified SMTP profiles for the form picker
        $this->addRoute('admin/form-mail-profiles', 'admin/form-mail-profiles.php');

        // GET /api/admin/form-notification-suggestions - recipient autocomplete
        $this->addRoute('admin/form-notification-suggestions', 'admin/form-notification-suggestions.php');

        // GET/POST /api/admin/mail-settings - SMTP profiles (masked reads, CRUD)
        $this->addRoute('admin/mail-settings', 'admin/mail-settings.php');

        // GET /api/admin/mail/verify?token=... - confirmation link from the
        // verification e-mail. Unauthenticated by design (it is opened from a
        // mail client); see endpoints/admin/mail-verify.php for the full
        // reasoning and the compensating controls.
        //
        // The e-mail itself links to the physical path
        // /endpoints/admin/mail-verify.php, not to this pretty route, because a
        // link baked into a message cannot be retried with a different URL shape
        // if rewrites are unavailable. Both work.
        $this->addRoute('admin/mail/verify', 'admin/mail-verify.php');


        // ═══════════════════════════════════════════════════════════════════
        // PUBLIC FORM ENDPOINT (Formspree-style, NO AUTH)
        // ═══════════════════════════════════════════════════════════════════
        
        // GET  /api/forms/{slug} - public schema (for dynamic rendering)
        // POST /api/forms/{slug} - submit (JSON or classic HTML form)
        //
        // This is the URL that gets embedded into third-party pages, so it is
        // deliberately short and stable. The same file is also reachable
        // directly as /api/endpoints/public/forms.php?slug={slug}, which keeps
        // embedded forms working on hosts where rewrite rules are unavailable.
        $this->addRoute('forms/{slug}', 'public/forms.php', ['slug' => 'slug']);
        
        // GET /api/public/capabilities - opaque client capability flags (no auth)
        $this->addRoute('public/capabilities', 'public/capabilities.php');

        // ═══════════════════════════════════════════════════════════════════
        // ANALYTICS BEACON (0-PII, NO AUTH)
        // ═══════════════════════════════════════════════════════════════════

        // POST /api/collect - page-view beacon sent by the self-discovering
        // snippet (see endpoints/public/analytics-script.php). Deliberately
        // short and stable, same reasoning as /api/forms/{slug}.
        $this->addRoute('collect', 'public/collect.php');

        // GET /api/nomad.js - bootstrap-free FALLBACK server for the
        // static beacon snippet, reached only when the deployment has no
        // nginx/Apache alias serving api/static/nomad.js directly (see
        // AnalyticsScriptGenerator's docblock for the zero-overhead path).
        $this->addRoute('nomad.js', 'public/analytics-script.php');
        

        // ═══════════════════════════════════════════════════════════════════
        // FORGE (SCHEMA BUILDER) ROUTES
        // ═══════════════════════════════════════════════════════════════════
        
        // GET /api/forge/handshake - X25519 public key for sealed-box encryption
        $this->addRoute('forge/handshake', 'forge/handshake.php');
        
        // POST /api/forge/upload-chunk - receive one encrypted import chunk
        $this->addRoute('forge/upload-chunk', 'forge/upload-chunk.php');
        
        // POST /api/forge/finalize - assemble chunks, decrypt, import into slot
        $this->addRoute('forge/finalize', 'forge/finalize.php');
        
        // ═══════════════════════════════════════════════════════════════════
        // SYSTEM ROUTES
        // ═══════════════════════════════════════════════════════════════════
        
        $this->addRoute('system/logs', 'system/logs.php');
        $this->addRoute('system/version', 'system/version.php');
        $this->addRoute('system/updates', 'system/updates.php');
        $this->addRoute('system/security-alert', 'system/security-alert.php');
        $this->addRoute('system/queue-process', 'system/queue-process.php');
        $this->addRoute('cron', 'system/cron.php');
        $this->addRoute('system/cron', 'system/cron.php');
        $this->addRoute('system/cron-status', 'system/cron-status.php');
        $this->addRoute('system/cron-tokens', 'system/cron-tokens.php');
        
        // Batch operations
        $this->addRoute('batch', 'batch-content.php');
        
        // Webhooks
        $this->addRoute('webhook', 'webhook-receiver.php');
        
        // Install
        $this->addRoute('install/status', 'install/status.php');
        $this->addRoute('install/execute', 'install/execute.php');
    }

    /**
     * Add a route definition
     * 
     * @param string $pattern Route pattern with {param} placeholders
     * @param string $file PHP file to execute (relative to endpoints dir)
     * @param array $paramMap Map path params to query params: ['pathParam' => 'queryParam']
     */
    public function addRoute(string $pattern, string $file, array $paramMap = []): void
    {
        $this->routes[$pattern] = [
            'file' => $file,
            'params' => $paramMap,
        ];
    }

    /**
     * Dispatch the current request
     * Returns true if route was matched, false otherwise
     */
    public function dispatch(): bool
    {
        $uri = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH);
        $uri = rawurldecode($uri);
        
        // Remove base path prefix
        if (str_starts_with($uri, $this->basePath)) {
            $path = substr($uri, strlen($this->basePath));
            $path = ltrim($path, '/');
        } else {
            // Not an API request, don't handle
            return false;
        }
        
        // Legacy support: if path contains 'endpoints/', let it pass through
        if (str_starts_with($path, 'endpoints/')) {
            return false;
        }
        
        // Try to match a route
        foreach ($this->routes as $pattern => $config) {
            $params = $this->matchRoute($pattern, $path);
            
            if ($params !== null) {
                // Map path parameters to query parameters
                foreach ($config['params'] as $pathParam => $queryParam) {
                    if (isset($params[$pathParam])) {
                        $_GET[$queryParam] = $params[$pathParam];
                    } else {
                        $_GET[$pathParam] = $queryParam;
                    }
                }
                
                // Execute the endpoint file
                $file = $this->endpointsDir . '/' . $config['file'];
                
                if (file_exists($file)) {
                    // Trusted endpoint identity for cross-cutting security policy.
                    $_SERVER['NOMAD_ENDPOINT_FILE'] = $config['file'];
                    require $file;
                    return true;
                } else {
                    $this->sendError(404, "Endpoint file not found: {$config['file']}");
                    return true;
                }
            }
        }
        
        // No route matched
        return false;
    }

    /**
     * Match a route pattern against a path
     * Returns extracted parameters or null if no match
     */
    private function matchRoute(string $pattern, string $path): ?array
    {
        // Convert pattern to regex
        $regex = preg_quote($pattern, '#');
        $regex = preg_replace_callback(
            '/\\\\\{([a-zA-Z_][a-zA-Z0-9_]*)\\\\\}/',
            fn($m) => '(?P<' . $m[1] . '>[^/]+)',
            $regex
        );
        $regex = '#^' . $regex . '$#';
        
        if (preg_match($regex, $path, $matches)) {
            // Extract named parameters only
            $params = [];
            foreach ($matches as $key => $value) {
                if (is_string($key)) {
                    $params[$key] = $value;
                }
            }
            return $params;
        }
        
        return null;
    }

    /**
     * Send JSON error response
     */
    private function sendError(int $status, string $message): void
    {
        http_response_code($status);
        header('Content-Type: application/json');
        echo json_encode([
            'success' => false,
            'error' => $message,
            'status' => $status,
        ]);
    }

    /**
     * Get all registered routes (for documentation/debugging)
     */
    public function getRoutes(): array
    {
        $routes = [];
        foreach ($this->routes as $pattern => $config) {
            $routes[] = [
                'pattern' => $this->basePath . '/' . $pattern,
                'file' => $config['file'],
                'params' => $config['params'],
            ];
        }
        return $routes;
    }
}
