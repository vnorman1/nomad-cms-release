<?php
/**
 * NOMAD CMS - Request Logger Middleware
 * Comprehensive HTTP request/response logging with auth context
 */

declare(strict_types=1);

namespace NomadCMS\Middleware;

require_once dirname(__DIR__) . '/Services/LoggerService.php';

use NomadCMS\Services\LoggerService;

final class RequestLoggerMiddleware
{
    private static float $startTime;
    private static string $requestId;
    private static bool $initialized = false;
    
    /**
     * CRITICAL: Cache for php://input stream
     * The stream can only be read ONCE, so we must cache it at startup
     */
    private static ?string $rawBody = null;
    private static bool $bodyRead = false;
    /** Hub notes/files are metadata-only logs and must never be buffered. */
    private static bool $metadataOnly = false;
    
    /**
     * Sensitive fields to mask in logs
     */
    private const SENSITIVE_FIELDS = [
        'password', 'password_confirmation', 'current_password', 'new_password',
        'token', 'access_token', 'refresh_token', 'api_key', 'secret',
        'authorization', 'x-api-key', 'cookie', 'set-cookie',
        'private_key', 'encryption_key', 'pepper', 'salt',
    ];
    
    /**
     * Paths to exclude from logging (to prevent recursive logging or reduce noise)
     */
    private const EXCLUDED_PATHS = [
        // System
        '/endpoints/system/logs.php',
        '/system/logs',
        // Public endpoints - GDPR: visitor IP + lekért tartalom/séma = azonosítható böngészési adat
        '/endpoints/data.php',
        '/endpoints/schema.php',
        '/endpoints/sitemap.php',
        '/endpoints/batch-content.php',
        '/api/data',
        '/api/schema',
        '/api/sitemap',
        '/api/batch-content',
        '/api/batch',
        '/endpoints/search.php',
        '/api/search',
        '/endpoints/llms-item.php',
        '/api/llms',
        '/api/robots',
        '/endpoints/seo.php',
        '/api/seo/',
        // Analytics beacon & script - GDPR: IP + oldal URL naplózása hozzájárulás nélkül tilos
        '/endpoints/public/collect.php',
        '/endpoints/public/analytics-script.php',
        '/api/collect',
        '/api/nomad.js',
        // Noisy routine auth endpoints
        '/endpoints/auth/me.php',
        '/endpoints/auth/preferences.php',
        '/endpoints/auth/settings.php',
        '/endpoints/auth/refresh.php',
        '/api/auth/me',
        '/api/auth/preferences',
        '/api/auth/settings',
        '/api/auth/refresh',
        // Noisy routine presence polling & collision warning
        '/endpoints/presence.php',
        '/api/presence',
        '/presence',
        // Public static content server - GDPR: request URI reveals visitor browsing patterns (slot/item params)
        '/endpoints/static-serve.php',
        '/api/static',
        '/static',
        // Noisy routine cron background runs & status polling (dedicated logging in system_cron_logs)
        '/endpoints/system/cron.php',
        '/endpoints/system/cron-status.php',
        '/endpoints/system/cron-tokens.php',
        '/api/cron',
        '/api/system/cron',
        '/cron',
        // Repeated media queue processing and Editorials binary sync/presence.
        '/endpoints/system/queue-process.php',
        '/api/system/queue-process',
        '/endpoints/admin/editorials/sync.php',
    ];

    /**
     * High-frequency pretty routes. Match complete segments so notification
     * administration and Editorials content mutations keep their audit trail.
     */
    private const EXCLUDED_ROUTE_PATTERNS = [
        '~(?:^|/)(?:api/)?notifications/(?:unread-count|updates)/?$~D',
        '~(?:^|/)(?:api/)?admin/editorials/boards/[^/]+/(?:changes|presence|viewport|geometry)/?$~D',
        '~(?:^|/)(?:api/)?admin/editorials/notes/[^/]+/(?:updates|checkpoint|projection)/?$~D',
    ];

    /**
     * Paths whose REQUEST BODY must never be written to the log, while the
     * request itself is still logged (method, status, timing, IP).
     *
     * The public form endpoint accepts arbitrary visitor input - names, e-mail
     * addresses, free-text messages. Logging that body would copy every
     * submission into a plaintext log file, which for an ENCRYPTED form silently
     * defeats the encryption it promises: the database would hold ciphertext
     * while app.log holds the same data in the clear.
     *
     * Excluding the path entirely (as EXCLUDED_PATHS does) would also hide the
     * status codes that make abuse visible - 429 rate limits, 403 origin
     * rejections - so the body alone is dropped.
     */
    private const BODY_REDACTED_PATHS = [
        '/endpoints/public/forms.php',
        '/api/forms/',
        '/forms/',
    ];
    
    /**
     * Start request logging
     * Call this early in bootstrap.php
     */
    public static function start(): void
    {
        if (self::$initialized) {
            return;
        }

        // Do not buffer or log CLI executions
        if (PHP_SAPI === 'cli') {
            self::$initialized = true;
            return;
        }
        
        // Check if this request should be excluded from logging
        $uri = $_SERVER['REQUEST_URI'] ?? '';
        $path = parse_url($uri, PHP_URL_PATH) ?? $uri;
        
        if (self::isExcludedRequest($path)) {
            // Don't log this request, but still initialize to prevent double-init
            self::$initialized = true;
            return;
        }
        
        self::$initialized = true;
        self::$startTime = microtime(true);
        self::$requestId = substr(bin2hex(random_bytes(4)), 0, 8);
        self::$metadataOnly = \NomadCMS\Services\EditorialsHub\HttpPaths::isHub($uri)
            || \NomadCMS\Services\NotificationService\BackgroundRunner::isNotificationRequest($uri);
        
        // CRITICAL: Cache php://input NOW before any other code can consume it
        // This stream can only be read ONCE!
        if (!self::$metadataOnly && !self::$bodyRead) {
            self::$rawBody = file_get_contents('php://input');
            self::$bodyRead = true;
        }
        
        // Start output buffering to capture response
        if (!self::$metadataOnly) { ob_start(); }
        
        // Register shutdown function to log after response is complete
        register_shutdown_function([self::class, 'finish']);
    }

    /**
     * Resolve noisy requests before buffering bodies or registering shutdown logs.
     * Direct endpoint calls need their action checked because they share scripts
     * with business operations; pretty routes are identified by the path alone.
     */
    private static function isExcludedRequest(string $path): bool
    {
        foreach (self::EXCLUDED_PATHS as $excluded) {
            if (str_contains($path, $excluded)) {
                return true;
            }
        }

        foreach (self::EXCLUDED_ROUTE_PATTERNS as $pattern) {
            if (preg_match($pattern, $path) === 1) {
                return true;
            }
        }

        if (str_ends_with($path, '/endpoints/notifications.php')) {
            return in_array($_GET['_notification_action'] ?? '', ['unread_count', 'updates'], true);
        }

        if (str_ends_with($path, '/endpoints/admin/editorials/items.php')) {
            return in_array($_GET['_eh_action'] ?? '', ['viewport', 'geometry'], true);
        }

        return false;
    }
    
    /**
     * Get the cached raw request body
     * 
     * IMPORTANT: Use this instead of file_get_contents('php://input')
     * because the stream can only be read once!
     * 
     * @return string|null The raw body content, or null if not yet captured
     */
    public static function getRawBody(): ?string
    {
        // If not yet read (e.g., logger was disabled), read it now
        if (!self::$bodyRead) {
            self::$rawBody = file_get_contents('php://input');
            self::$bodyRead = true;
        }
        return self::$rawBody;
    }
    
    /**
     * Complete request logging (called on shutdown)
     */
    public static function finish(): void
    {
        if (!self::$initialized) {
            return;
        }
        
        $executionTime = round((microtime(true) - self::$startTime) * 1000);
        $responseBody = self::$metadataOnly ? '' : (string) ob_get_contents();
        
        // Get response code
        $statusCode = http_response_code();
        if ($statusCode === false) {
            $statusCode = 200;
        }
        
        $method = $_SERVER['REQUEST_METHOD'] ?? 'UNKNOWN';
        
        // NOISE REDUCTION: successful (2xx/3xx) GET requests are by far the
        // highest-volume traffic (every page load, every media/asset fetch,
        // every polling request) and carry little diagnostic value once they
        // succeed. Skip logging them entirely so the rotating app.log isn't
        // dominated by routine reads. Failed GETs (4xx/5xx) still need to be
        // visible for abuse/error detection, and every non-GET method is
        // unaffected.
        $skipSuccessfulGet = filter_var($_ENV['LOG_SKIP_SUCCESSFUL_GET'] ?? true, FILTER_VALIDATE_BOOLEAN);

        if ($skipSuccessfulGet && $method === 'GET' && $statusCode < 400) {
            if (!self::$metadataOnly) { ob_end_flush(); }
            return;
        }

        try {
            // Build log entry
            $logData = self::buildLogData($responseBody, $statusCode, $executionTime);

            // Determine log level based on status code
            $level = match(true) {
                $statusCode >= 500 => 'error',
                $statusCode >= 400 => 'warning',
                default => 'info',
            };

            // Format the message
            $uri = $_SERVER['REQUEST_URI'] ?? '/';
            $authType = $logData['auth_type'] ?? 'none';

            // Dynamic label based on auth type
            $authLabel = match($authType) {
                'api_key' => '[API-KEY]',
                'jwt' => '[ADMIN]',
                default => '[HTTP]',
            };

            $message = sprintf(
                '%s %s %s %d (%dms)',
                $authLabel,
                $method,
                parse_url($uri, PHP_URL_PATH) ?? $uri,
                $statusCode,
                $executionTime
            );

            // Log it
            LoggerService::$level($message, $logData);

        } catch (\Throwable $e) {
            // Logging is secondary to the committed operation. A disk/encoding
            // error must not turn a successful panic transition into HTTP 500.
            error_log('[RequestLogger] request_log_unavailable');
        }

        // Flush the buffer
        if (!self::$metadataOnly) { ob_end_flush(); }
    }

    /**
     * Build structured log data
     */
    private static function buildLogData(string $responseBody, int $statusCode, float $executionTime): array
    {
        $data = [
            'request_id' => self::$requestId,
            'method' => $_SERVER['REQUEST_METHOD'] ?? 'UNKNOWN',
            'uri' => $_SERVER['REQUEST_URI'] ?? '/',
            'status' => $statusCode,
            'time_ms' => $executionTime,
            'ip' => self::getClientIp(),
        ];
        if (self::$metadataOnly) { $data['uri'] = parse_url($data['uri'], PHP_URL_PATH); }
        
        // Add auth context
        $authContext = self::getAuthContext();
        if ($authContext) {
            $data = array_merge($data, $authContext);
        }
        
        // Add request data (sanitized)
        $requestData = self::getRequestData();
        if (!empty($requestData)) {
            $data['request'] = $requestData;
        }
        
        // Add response summary (sanitized and truncated)
        $responseSummary = self::getResponseSummary($responseBody);
        if (!empty($responseSummary)) {
            $data['response'] = $responseSummary;
        }
        
        return $data;
    }
    
    /**
     * Get authentication context from AuthMiddleware
     */
    private static function getAuthContext(): ?array
    {
        // Check if AuthMiddleware was used
        if (!class_exists(AuthMiddleware::class)) {
            return null;
        }
        
        $user = AuthMiddleware::getCurrentUser();
        if (!$user) {
            return ['auth_type' => 'none'];
        }
        
        // Check if it's API key auth
        if (isset($user->source) && $user->source === 'api_key') {
            return [
                'auth_type' => 'api_key',
                'key_id' => $user->key_id ?? null,
                'user_id' => $user->id ?? null,
                'email' => self::maskEmail($user->email ?? ''),
                'permissions' => $user->permissions ?? [],
            ];
        }
        
        // JWT auth
        return [
            'auth_type' => 'jwt',
            'user_id' => $user->id ?? null,
            'email' => self::maskEmail($user->email ?? ''),
            'is_admin' => $user->is_admin ?? false,
        ];
    }
    
    /**
     * Mask email address for privacy (e.g. "admin@cms.local" -> "a***@cms.local")
     */
    private static function maskEmail(string $email): string
    {
        if (empty($email) || !str_contains($email, '@')) {
            return $email;
        }
        
        [$local, $domain] = explode('@', $email, 2);
        
        if (strlen($local) <= 1) {
            return $local . '***@' . $domain;
        }
        
        return $local[0] . '***@' . $domain;
    }
    
    /**
     * Get sanitized request data
     */
    private static function getRequestData(): array
    {
        if (self::$metadataOnly) { return []; }
        $data = [];
        
        // Query params
        if (!empty($_GET)) {
            $data['query'] = self::sanitize($_GET);
        }
        
        // Body redaction for endpoints that receive third-party personal data.
        // Checked before the body is touched at all, so nothing can slip through
        // a later truncation step.
        if (self::isBodyRedacted()) {
            $hasBody = !empty($_POST) || !empty(self::$rawBody);
            if ($hasBody) {
                $data['body'] = '[REDACTED: publikus űrlap beküldés - személyes adat nem naplózható]';
            }

            return self::truncateData($data, 500);
        }

        // Request body (using cached version)
        $contentType = $_SERVER['CONTENT_TYPE'] ?? '';
        
        if (str_contains($contentType, 'application/json')) {
            // Use cached body instead of reading php://input again!
            $body = self::$rawBody;
            if ($body) {
                $decoded = json_decode($body, true);
                if (is_array($decoded)) {
                    $data['body'] = self::sanitize($decoded);
                }
            }
        } elseif (!empty($_POST)) {
            $data['body'] = self::sanitize($_POST);
        }
        
        // Limit size
        return self::truncateData($data, 500);
    }

    /**
     * Whether the current request path is body-redacted.
     */
    private static function isBodyRedacted(): bool
    {
        $uri = $_SERVER['REQUEST_URI'] ?? '';
        $path = parse_url($uri, PHP_URL_PATH) ?? $uri;

        foreach (self::BODY_REDACTED_PATHS as $redacted) {
            if (str_contains($path, $redacted)) {
                return true;
            }
        }

        return false;
    }
    
    /**
     * Get sanitized response summary
     */
    private static function getResponseSummary(string $responseBody): array
    {
        if (empty($responseBody)) {
            return [];
        }
        
        // Try to parse as JSON
        $decoded = json_decode($responseBody, true);
        
        if (is_array($decoded)) {
            // Sanitize and summarize
            $summary = self::sanitize($decoded);
            
            // Keep only key info
            $result = [];
            
            if (isset($summary['success'])) {
                $result['success'] = $summary['success'];
            }
            if (isset($summary['error'])) {
                $result['error'] = self::truncateString($summary['error'], 100);
            }
            if (isset($summary['message'])) {
                $result['message'] = self::truncateString($summary['message'], 100);
            }
            if (isset($summary['code'])) {
                $result['code'] = $summary['code'];
            }
            
            // Count arrays
            foreach ($decoded as $key => $value) {
                if (is_array($value) && !in_array($key, ['success', 'error', 'message', 'code'])) {
                    $result[$key . '_count'] = count($value);
                }
            }
            
            return $result;
        }
        
        // Non-JSON response
        return [
            'type' => 'raw',
            'size' => strlen($responseBody),
        ];
    }
    
    /**
     * Sanitize data by masking sensitive fields
     */
    private static function sanitize(array $data): array
    {
        $result = [];
        
        foreach ($data as $key => $value) {
            // Cast key to string to handle numeric array keys
            $lowerKey = strtolower((string) $key);
            
            // Check if this is a sensitive field
            $isSensitive = false;
            foreach (self::SENSITIVE_FIELDS as $sensitiveField) {
                if (str_contains($lowerKey, $sensitiveField)) {
                    $isSensitive = true;
                    break;
                }
            }
            
            if ($isSensitive) {
                $result[$key] = '[REDACTED]';
            } elseif (is_array($value)) {
                $result[$key] = self::sanitize($value);
            } elseif (is_string($value) && strlen($value) > 200) {
                $result[$key] = self::truncateString($value, 200);
            } else {
                $result[$key] = $value;
            }
        }
        
        return $result;
    }
    
    /**
     * Truncate data structure to max size
     */
    private static function truncateData(array $data, int $maxChars): array
    {
        $json = json_encode($data, JSON_INVALID_UTF8_SUBSTITUTE);
        if ($json !== false && strlen($json) <= $maxChars) {
            return $data;
        }
        
        // Simplify the data
        return array_map(function($value) {
            if (is_array($value)) {
                $count = count($value);
                return "[array:$count]";
            }
            if (is_string($value) && strlen($value) > 50) {
                return self::truncateString($value, 50);
            }
            return $value;
        }, $data);
    }
    
    /**
     * Truncate string with ellipsis
     */
    private static function truncateString(string $str, int $max): string
    {
        if (strlen($str) <= $max) {
            return $str;
        }
        // Keep the byte budget without splitting a multibyte character. Invalid
        // incoming bytes are substituted when the sanitized log is encoded.
        return mb_strcut($str, 0, max(0, $max - 3), 'UTF-8') . '...';
    }
    
    /**
     * Get client IP address
     * SECURITY: Only trusts proxy headers when connection is from a trusted
     * proxy (see ClientIpResolver). Forwarded headers are attacker-controlled
     * and must never be trusted unconditionally, or a client can spoof its
     * logged IP address.
     */
    private static function getClientIp(): string
    {
        return \NomadCMS\Security\ClientIpResolver::resolve();
    }
}
