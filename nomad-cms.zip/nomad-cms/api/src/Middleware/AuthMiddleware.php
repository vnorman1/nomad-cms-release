<?php
/**
 * NOMAD CMS - Auth Middleware
 * JWT Bearer token validation and user context injection
 */

declare(strict_types=1);

namespace NomadCMS\Middleware;

use NomadCMS\Auth\JWTService;
use NomadCMS\Security\ApiKeyService;

final class AuthMiddleware
{
    private static ?object $currentUser = null;
    private static ?array $apiKeyData = null;
    
    /**
     * Require authenticated user
     * Call at the beginning of protected endpoints
     *
     * @param bool $allowForcedPasswordChange If true, allows users who must change password to access this endpoint
     * @throws \Exception if not authenticated
     */
    public static function requireAuth(bool $allowForcedPasswordChange = false): object
    {
        // Public read delivery during panic is anonymous-only. A public route
        // that switches to draft/internal/private mode must still hit this gate.
        if (\NomadCMS\Security\PanicModeService::isReadOnlyRequest()) {
            \NomadCMS\Middleware\PanicModeMiddleware::respond(new \NomadCMS\Security\PanicModeException(
                'PANIC_MODE_ACTIVE', 'Private and draft access is suspended during emergency lockdown.'
            ));
        }
        $token = JWTService::extractBearerToken();
        $apiKey = $_SERVER['HTTP_X_API_KEY'] ?? null;
        
        // Also check query params and cookie for API key (draft preview support)
        if (empty($apiKey)) {
            $apiKey = $_GET['api_key'] ?? $_GET['draftkey'] ?? $_COOKIE['nomad_draft'] ?? null;
        }
        
        $errors = [];
        
        // If Bearer token starts with an API key prefix, route it directly to API key authentication
        $isBearerApiKey = $token !== null && (str_starts_with($token, 'nmk_') || str_starts_with($token, 'nmk_pro_'));
        if ($isBearerApiKey && empty($apiKey)) {
            $apiKey = $token;
            $token = null;
        }
        
        // 1. Try JWT first (preferred for user sessions)
        if ($token) {
            try {
                $decoded = JWTService::validateAccessToken($token);
                
                // SECURITY: Validate IP binding if present in token
                if (!empty($decoded->ip_hash)) {
                    $currentIp = \NomadCMS\Security\ClientIpResolver::resolve();
                    
                    if (!\NomadCMS\Security\IpHashService::verifyBinding($currentIp, $decoded->ip_hash)) {
                        self::sendUnauthorized('Session IP mismatch. Please login again.');
                    }
                }
                
                self::$currentUser = $decoded->user;
                self::$currentUser->panic_recovery = !empty($decoded->panic_recovery);
                
                // SECURITY / CORRECTNESS: the JWT carries a SNAPSHOT of the
                // user's role taken at token-issue time. Trusting it means role
                // changes (and privilege revocations) only take effect once the
                // token expires or the user logs in again. Re-resolve the
                // authoritative role fields from the database on every request.
                self::refreshAuthoritativeRole();
                
                // SECURITY: Check if Panic Mode is active (read-only mode)
                // Non-GET requests from non-admins are blocked during panic
                if (self::isPanicModeBlockingRequest()) {
                    self::sendServiceUnavailable('System is in emergency read-only mode');
                }
                
                // Check if user is forced to change password
                if (!self::checkForcedPasswordChange($allowForcedPasswordChange)) {
                     self::sendForbidden('Password change required', 'FORCE_PASSWORD_CHANGE');
                }

                return self::$currentUser;
            } catch (\NomadCMS\Auth\AuthException $e) {
                \NomadCMS\Auth\AuthHttp::respond($e);
            } catch (\NomadCMS\Security\PanicModeException $e) {
                \NomadCMS\Middleware\PanicModeMiddleware::respond($e);
            } catch (\Exception $e) {
                $errors[] = "JWT: " . $e->getMessage();
            }
        }
        
        // 2. Try API Key (for external integrations)
        if ($apiKey) {
            try {
                $apiKeyService = new ApiKeyService();
                $keyData = $apiKeyService->validateKey($apiKey);
                
                if ($keyData) {
                    // Store API key data for permission checks
                    self::$apiKeyData = $keyData;
                    
                    $isDraftOnly = !empty($keyData['is_draft_only']);
                    
                    // Construct synthetic user object for compatibility
                    self::$currentUser = (object) [
                        'id' => $keyData['user_id'],
                        'uuid' => $keyData['user_uuid'],
                        'email' => $keyData['user_email'],
                        'role' => $keyData['is_admin'] ? 'admin' : 'editor',
                        'is_admin' => $keyData['is_admin'] || $keyData['user_is_admin'],
                        'source' => 'api_key',
                        'key_id' => $keyData['key_id'],
                        'permissions' => $keyData['permissions'],
                        'can_read' => $keyData['can_read'],
                        'can_write' => $keyData['can_write'],
                        'is_draft_only' => $isDraftOnly,
                    ];
                    
                    // SECURITY: Draft-only keys cannot perform any mutations
                    if ($isDraftOnly) {
                        $method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
                        if (!in_array($method, ['GET', 'HEAD', 'OPTIONS'], true)) {
                            self::sendForbidden(
                                'Draft-only keys cannot modify content. This key is restricted to read-only draft preview access.',
                                'FORBIDDEN_DRAFT_KEY_MUTATION'
                            );
                        }
                    }
                    
                    return self::$currentUser;
                } else {
                    $errors[] = "API Key: Invalid or expired key";
                }
            } catch (\Exception $e) {
                $errors[] = "API Key: " . $e->getMessage();
            }
        }
        
        // 3. Failed - no valid authentication
        $msg = 'Unauthorized';
        if (!empty($errors)) {
            $msg .= ' (' . implode(', ', $errors) . ')';
        } else {
            $msg .= ' (No token or API key provided)';
        }
        
        self::sendUnauthorized($msg);
    }

    /** Personal credentials may only be managed by an interactive JWT identity. */
    public static function requireInteractiveAuth(bool $allowOnboarding = false): object
    {
        $token = JWTService::extractBearerToken();
        if ($token === null || str_starts_with($token, 'nmk_')) {
            \NomadCMS\Auth\AuthHttp::respond(new \NomadCMS\Auth\AuthException(
                'INTERACTIVE_AUTH_REQUIRED', 'An interactive user session is required.', 403
            ));
        }
        $user = self::requireAuth($allowOnboarding);
        if (($user->source ?? '') === 'api_key') {
            \NomadCMS\Auth\AuthHttp::respond(new \NomadCMS\Auth\AuthException(
                'INTERACTIVE_AUTH_REQUIRED', 'An interactive user session is required.', 403
            ));
        }
        return $user;
    }
    
    /**
     * Re-read the authoritative role fields (role_slug, is_admin, role) for the
     * currently authenticated JWT user from the database, overriding the
     * snapshot embedded in the token.
     *
     * WHY: JWTs are immutable once issued, so a role change or privilege
     * revocation performed by an admin would otherwise not take effect until
     * the access token expired (or the user re-logged in). RBAC decisions must
     * reflect the CURRENT state of the user record, not a stale snapshot.
     *
     * If the user record no longer exists, the session is rejected (401) - a
     * deleted user must not keep operating on a still-valid token.
     */
    private static function refreshAuthoritativeRole(): void
    {
        $uuid = self::$currentUser->uuid ?? null;
        if (!$uuid) {
            return;
        }

        try {
            $db = \NomadCMS\Database\AuthDatabase::getInstance();
            $stmt = $db->prepare("SELECT role_slug, role, is_admin, is_new_user FROM users WHERE uuid = ?");
            $stmt->execute([$uuid]);
            $row = $stmt->fetch();
        } catch (\Exception $e) {
            // Infrastructure failure cannot restore a stale role snapshot.
            error_log('[AuthMiddleware] Authoritative role lookup failed: ' . $e->getMessage());
            throw new \NomadCMS\Auth\AuthException('AUTH_STATE_UNAVAILABLE', 'Authentication storage is unavailable.', 503);
        }

        if (!$row) {
            self::sendUnauthorized('User account no longer exists. Please login again.');
        }

        if (!empty($row['role_slug'])) {
            self::$currentUser->role_slug = $row['role_slug'];
        }
        if (!empty($row['role'])) {
            self::$currentUser->role = $row['role'];
        }
        self::$currentUser->is_admin = (bool) $row['is_admin'];

        // The onboarding gate must also be authoritative, not a token snapshot.
        // WHY: when an admin generates a magic link and the user redeems it, the
        // user row flips to is_new_user = 1. Any full-access token issued BEFORE
        // that moment would otherwise keep working until it expired, letting the
        // account bypass the mandatory password step for up to one token TTL.
        self::$currentUser->is_new_user = (bool) $row['is_new_user'];
    }

    /**
     * Check if the session is restricted to finishing onboarding.
     *
     * Two independent signals put a session behind this gate:
     *   1. users.is_new_user = 1 - the user has not completed onboarding yet
     *   2. the JWT's `onboarding` claim - the session was created by redeeming
     *      a magic link (auth/magic-login.php)
     *
     * Signal 2 matters even where signal 1 would be enough today: it is bound to
     * the TOKEN rather than the user row, so a magic-link session can never be
     * silently upgraded to a full session by a concurrent change to the user
     * record. Endpoints that legitimately need to run during onboarding pass
     * $allowForcedPasswordChange = true (auth/me.php, auth/settings.php,
     * auth/onboarding.php).
     */
    private static function checkForcedPasswordChange(bool $allowForcedPasswordChange): bool 
    {
        if (!self::$currentUser) return false;
        
        // If it's an API Key, we generally assume it's a service account or programmatic access, 
        // which might not be subject to interactive password reset, BUT if the underlying user 
        // is new, maybe we should block? For now, let's assume API keys are fine or handled separately.
        // Actually, let's enforce it for consistency if we have the user data.
        // However, the `is_new_user` flag might strictly be for the interactive UI flow. 
        // Let's check the flag on the user object.
        
        $isNewUser = isset(self::$currentUser->is_new_user) && (
            self::$currentUser->is_new_user === true || 
            self::$currentUser->is_new_user === 1 ||
            self::$currentUser->is_new_user === '1'
        );
        
        $isOnboardingSession = isset(self::$currentUser->onboarding) && (
            self::$currentUser->onboarding === true ||
            self::$currentUser->onboarding === 1 ||
            self::$currentUser->onboarding === '1'
        );
        
        if (($isNewUser || $isOnboardingSession) && !$allowForcedPasswordChange) {
            return false;
        }
        
        return true;
    }
    
    /**
     * Require admin role
     * Must be called after requireAuth()
     */
    public static function requireAdmin(): void
    {
        if (!self::$currentUser) {
            self::requireAuth();
        }
        
        if (!self::$currentUser->is_admin) {
            self::sendForbidden(
                "Nincs jogosultságod a művelet végrehajtásához.",
                'FORBIDDEN_ACTION',
                'system:admin:*',
                null
            );
        }
    }
    
    /**
     * Require specific permission (Extended RBAC/ABAC-hybrid)
     *
     * Permission string format: "resource:action:scope", e.g.:
     *   - "content:update:*"   - update any content
     *   - "content:update:own" - update only own content (requires $slotKey to verify ownership)
     *   - "users:manage:*"     - full user management
     *
     * Backward compatible shorthand: legacy calls with 'read'/'write'/'admin'
     * are mapped to their RBAC equivalents for API-key auth AND JWT auth.
     *
     * @param string $permission Full "resource:action:scope" string, or legacy shorthand
     * @param string|null $slotKey Slot key, required for 'own'-scoped content checks
     * @param string|null $itemUid Item `_dndId` for list/collection item-level ownership checks
     */
    public static function requirePermission(string $permission, ?string $slotKey = null, ?string $itemUid = null): void
    {
        if (!self::$currentUser) {
            self::requireAuth();
        }

        if (str_starts_with($permission, 'schema:')) {
            if (!\NomadCMS\Services\Schema\SchemaAccess::allowed(self::$currentUser)) {
                self::sendForbidden('Schema authority required.', 'FORBIDDEN_ACTION', $permission, null);
            }
            return;
        }

        // API Key auth: legacy shorthand bitmask permissions still apply as-is
        if (isset(self::$currentUser->source) && self::$currentUser->source === 'api_key') {
            $allowed = match ($permission) {
                'read' => self::$currentUser->can_read ?? false,
                'write' => self::$currentUser->can_write ?? false,
                'admin' => self::$currentUser->is_admin ?? false,
                default => \NomadCMS\Services\RBACService::hasPermission(self::$currentUser, $permission, $slotKey, $itemUid),
            };

            if (!$allowed) {
                self::sendForbidden(
                    "Nincs jogosultságod a művelet végrehajtásához.",
                    'FORBIDDEN_ACTION',
                    $permission,
                    $slotKey
                );
            }
            return;
        }

        // Legacy shorthand -> RBAC permission mapping for JWT users
        $resolved = match ($permission) {
            'read' => 'content:read:*',
            'write' => 'content:update:*',
            'admin' => 'system:admin:*',
            default => $permission,
        };

        // Super admin (is_admin flag) always passes - fast path, also covers
        // legacy users not yet migrated to role_slug
        if (!empty(self::$currentUser->is_admin)) {
            return;
        }

        if (!\NomadCMS\Services\RBACService::hasPermission(self::$currentUser, $resolved, $slotKey, $itemUid)) {
            self::sendForbidden(
                "Nincs jogosultságod a művelet végrehajtásához.",
                'FORBIDDEN_ACTION',
                $resolved,
                $slotKey
            );
        }
    }

    /**
     * Require at least ONE of the given permissions (logical OR).
     *
     * Useful when a single action can be legitimately authorized by more
     * than one permission string, e.g. media uploads should be allowed for
     * users with either "media:upload:*" (dedicated upload permission) OR
     * "media:create:*" (general content-creation permission covering media).
     *
     * @param array<int, string> $permissions Candidate permission strings; passes if ANY match
     * @param string|null $slotKey Slot key, required for 'own'-scoped content checks
     * @param string|null $itemUid Item `_dndId` for list/collection item-level ownership checks
     */
    public static function requireAnyPermission(array $permissions, ?string $slotKey = null, ?string $itemUid = null): void
    {
        if (!self::$currentUser) {
            self::requireAuth();
        }

        // Super admin always passes
        if (!empty(self::$currentUser->is_admin)) {
            return;
        }

        foreach ($permissions as $permission) {
            if (self::hasPermission($permission, $slotKey, $itemUid)) {
                return;
            }
        }

        self::sendForbidden(
            "Nincs jogosultságod a művelet végrehajtásához.",
            'FORBIDDEN_ACTION',
            implode(' OR ', $permissions),
            $slotKey
        );
    }

    /**
     * Require that the caller has been GRANTED at least one of the given
     * permissions, WITHOUT performing any ownership verification.
     *
     * This is the requireAnyPermission() counterpart for resources whose
     * ownership model lives outside ContentDatabase::isOwnedBy() - media
     * (media_meta.uploaded_by), file-based logs, massive rows (owner_uuid),
     * API keys (WHERE user_id = ?). For those, hasPermission() on an ':own'
     * grant is fail-closed whenever no $slotKey is supplied (it cannot verify
     * content-slot ownership), which would make every ':own' grant on a
     * non-content resource permit nothing at all.
     *
     * Endpoints using this MUST perform their own domain-specific ownership
     * check afterwards (e.g. compare media_meta.uploaded_by, or filter a query
     * by user_id) - this call only answers "does the role hold such a grant?".
     *
     * @param array<int, string> $permissions e.g. ['media:update:*', 'media:update:own']
     */
    public static function requireAnyGrantedScope(array $permissions): void
    {
        if (!self::$currentUser) {
            self::requireAuth();
        }

        // Super admin always passes
        if (!empty(self::$currentUser->is_admin)) {
            return;
        }

        foreach ($permissions as $permission) {
            if (self::hasGrantedScope($permission)) {
                return;
            }
        }

        self::sendForbidden(
            "Nincs jogosultságod a művelet végrehajtásához.",
            'FORBIDDEN_ACTION',
            implode(' OR ', $permissions),
            null
        );
    }

    /**
     * Require access to a specific slot key, based on the current user's role
     * slot_access wildcard patterns. Must be called after requireAuth().
     *
     * Admins (is_admin) always pass.
     */
    public static function requireSlotAccess(string $slotKey): void
    {
        if (!self::$currentUser) {
            self::requireAuth();
        }

        if (!empty(self::$currentUser->is_admin)) {
            return;
        }

        if (!\NomadCMS\Services\RBACService::canAccessSlot(self::$currentUser, $slotKey)) {
            self::sendForbidden(
                "Nincs jogosultságod a '{$slotKey}' tartalomhoz.",
                'SLOT_ACCESS_DENIED',
                null,
                $slotKey
            );
        }
    }
    
    /**
     * Check if current auth is via API key
     */
    public static function isApiKeyAuth(): bool
    {
        return isset(self::$currentUser->source) && self::$currentUser->source === 'api_key';
    }
    
    /**
     * Get API key data (only available for API key auth)
     */
    public static function getApiKeyData(): ?array
    {
        return self::$apiKeyData;
    }
    
    /**
     * Check if current auth is via a draft-only API key
     */
    public static function isDraftOnlyKey(): bool
    {
        return self::isApiKeyAuth() && !empty(self::$currentUser->is_draft_only);
    }
    
    /**
     * Optional authentication
     * Returns user if token present and valid, null otherwise
     *
     * SECURITY: "optional" means only that the ABSENCE of a token is not an
     * error. It does NOT mean the checks requireAuth() performs are optional.
     * A token that is cryptographically valid can still be unfit to identify a
     * caller, and this method must reach the same verdict requireAuth() would:
     *
     *   1. The role/is_admin claims in a JWT are a SNAPSHOT from issue time.
     *      Without re-reading them from the database, an admin demoted (or
     *      deleted) mid-session keeps their privileges here for up to one
     *      access-token TTL, even though requireAuth() would already reject
     *      them. See refreshAuthoritativeRole().
     *
     *   2. An ONBOARDING-SCOPED session (issued by redeeming a magic link, or
     *      belonging to a user with is_new_user = 1) is deliberately confined
     *      to the onboarding endpoints. requireAuth() enforces that via
     *      checkForcedPasswordChange(); if this method ignored it, any endpoint
     *      using optionalAuth() would become a hole in that confinement.
     *
     * Unlike requireAuth(), an unfit token is treated as ANONYMOUS (null)
     * rather than answered with 401/403. That keeps the contract of this
     * method - "a caller I can identify, or nobody" - so callers do not have to
     * distinguish "no token" from "token I must not honour"; both mean the
     * request has no authenticated identity.
     *
     * @param bool $allowOnboarding Set by endpoints that must keep working
     *        during onboarding (auth/logout.php - finishing onboarding must not
     *        be a prerequisite for logging out).
     */
    public static function optionalAuth(bool $allowOnboarding = false): ?object
    {
        if (\NomadCMS\Security\PanicModeService::isReadOnlyRequest()) {
            self::$currentUser = null;
            self::$apiKeyData = null;
            return null;
        }
        $token = JWTService::extractBearerToken();
        $apiKey = $_SERVER['HTTP_X_API_KEY'] ?? null;
        
        // Also check query params and cookie for API key (draft preview support)
        if (empty($apiKey)) {
            $apiKey = $_GET['api_key'] ?? $_GET['draftkey'] ?? $_COOKIE['nomad_draft'] ?? null;
        }
        
        // If Bearer token starts with an API key prefix, route it directly to API key authentication
        $isBearerApiKey = $token !== null && (str_starts_with($token, 'nmk_') || str_starts_with($token, 'nmk_pro_'));
        if ($isBearerApiKey && empty($apiKey)) {
            $apiKey = $token;
            $token = null;
        }
        
        // Try JWT first
        if ($token) {
            try {
                $decoded = JWTService::validateAccessToken($token);
                self::$currentUser = $decoded->user;
                self::$currentUser->panic_recovery = !empty($decoded->panic_recovery);

                // Authoritative role re-resolution (see note 1 above).
                // refreshAuthoritativeRole() exits with 401 if the user record
                // is gone, which is the correct outcome for a deleted account
                // on any code path.
                self::refreshAuthoritativeRole();

                // Onboarding confinement (see note 2 above). Treated as
                // anonymous rather than an error, per this method's contract.
                if (!$allowOnboarding && !self::checkForcedPasswordChange(false)) {
                    self::$currentUser = null;
                    return null;
                }

                return self::$currentUser;
            } catch (\Exception $e) {
                // Continue to try API key
                self::$currentUser = null;
                self::$apiKeyData = null;
            }
        }
        
        // Try API key
        if ($apiKey) {
            try {
                $apiKeyService = new ApiKeyService();
                $keyData = $apiKeyService->validateKey($apiKey);
                
                if ($keyData) {
                    self::$apiKeyData = $keyData;
                    $isDraftOnly = !empty($keyData['is_draft_only']);
                    self::$currentUser = (object) [
                        'id' => $keyData['user_id'],
                        'uuid' => $keyData['user_uuid'],
                        'email' => $keyData['user_email'],
                        'role' => $keyData['is_admin'] ? 'admin' : 'editor',
                        'is_admin' => $keyData['is_admin'] || $keyData['user_is_admin'],
                        'source' => 'api_key',
                        'key_id' => $keyData['key_id'],
                        'permissions' => $keyData['permissions'],
                        'can_read' => $keyData['can_read'],
                        'can_write' => $keyData['can_write'],
                        'is_draft_only' => $isDraftOnly,
                    ];
                    return self::$currentUser;
                }
            } catch (\Exception $e) {
                // Continue
            }
        }
        
        return null;
    }
    
    /**
     * Check if the authenticated caller can read draft / preview content.
     * Returns true if user has admin/content:read permission, or if API key has read/admin permission.
     */
    public static function canReadDrafts(): bool
    {
        if (!self::$currentUser) {
            return false;
        }

        // Draft-only keys always have draft read access (that's their sole purpose)
        if (self::isDraftOnlyKey()) {
            return true;
        }

        if (self::isApiKeyAuth()) {
            return !empty(self::$currentUser->can_read) || !empty(self::$apiKeyData['is_admin']);
        }

        if (!empty(self::$currentUser->is_admin)) {
            return true;
        }

        return self::hasPermission('content:read:*');
    }
    
    /**
     * Get current authenticated user
     */
    public static function getCurrentUser(): ?object
    {
        return self::$currentUser;
    }
    
    /**
     * Check if current user has specific permission
     *
     * @param string $permission "resource:action:scope" RBAC permission string
     * @param string|null $slotKey Required for 'own'-scoped checks
     * @param string|null $itemUid Item `_dndId` for list/collection item-level checks
     */
    public static function hasPermission(string $permission, ?string $slotKey = null, ?string $itemUid = null): bool
    {
        if (!self::$currentUser) {
            return false;
        }
        
        if (str_starts_with($permission, 'schema:')) {
            return $permission === \NomadCMS\Services\Schema\SchemaAccess::PERMISSION
                && \NomadCMS\Services\Schema\SchemaAccess::allowed(self::$currentUser);
        }

        // Admin has all permissions
        if (!empty(self::$currentUser->is_admin)) {
            return true;
        }
        
        return \NomadCMS\Services\RBACService::hasPermission(self::$currentUser, $permission, $slotKey, $itemUid);
    }

    /**
     * Check whether the current user's role has been GRANTED a given scope
     * for a permission string, WITHOUT performing content-slot ownership
     * verification (unlike hasPermission()). Use this for resources whose
     * ownership model lives outside ContentDatabase::isOwnedBy() - e.g. media
     * uploads (media_meta.uploaded_by) or file-based logs (user_id embedded
     * in log context) - where the endpoint itself performs the actual
     * domain-specific ownership check after confirming the grant exists.
     *
     * @param string $permission e.g. "media:read:own"
     */
    public static function hasGrantedScope(string $permission): bool
    {
        if (!self::$currentUser) {
            return false;
        }

        if (str_starts_with($permission, 'schema:')) {
            return $permission === \NomadCMS\Services\Schema\SchemaAccess::PERMISSION
                && \NomadCMS\Services\Schema\SchemaAccess::allowed(self::$currentUser);
        }

        // Admin has all permissions
        if (!empty(self::$currentUser->is_admin)) {
            return true;
        }

        return \NomadCMS\Services\RBACService::hasGrantedScope(self::$currentUser, $permission);
    }
    
    /**
     * Send 401 Unauthorized response and exit
     */
    private static function sendUnauthorized(string $message): never
    {
        http_response_code(401);
        header('Content-Type: application/json');
        header('WWW-Authenticate: Bearer');
        
        echo json_encode([
            'success' => false,
            'error' => $message,
            'code' => 'UNAUTHORIZED',
        ]);
        
        exit;
    }
    
    /**
     * Send 403 Forbidden response and exit
     *
     * @param string $message Human-readable error message
     * @param string $code Machine-readable error code (e.g. FORBIDDEN_ACTION, SLOT_ACCESS_DENIED)
     * @param string|null $requiredPermission The RBAC permission string that was missing
     * @param string|null $targetSlot The slot key that was being accessed (if applicable)
     */
    private static function sendForbidden(
        string $message,
        string $code = 'FORBIDDEN',
        ?string $requiredPermission = null,
        ?string $targetSlot = null
    ): never {
        http_response_code(403);
        header('Content-Type: application/json');
        
        $payload = [
            'success' => false,
            'error' => $message,
            'code' => $code,
        ];

        if ($requiredPermission !== null) {
            $payload['required_permission'] = $requiredPermission;
        }

        if ($targetSlot !== null) {
            $payload['target_slot'] = $targetSlot;
        }
        
        echo json_encode($payload);
        
        exit;
    }
    
    /**
     * Check if Panic Mode should block the current request
     * Normal operations are blocked regardless of administrator status
     * 
     * @return bool True if request should be blocked
     */
    private static function isPanicModeBlockingRequest(): bool
    {
        // Recovery exceptions use the same resolved endpoint policy as bootstrap.
        // Administrators cannot bypass normal writes during lockdown.
        if (\NomadCMS\Security\PanicModePolicy::allowsRecoveryToken()) {
            return false;
        }
        return !\NomadCMS\Security\PanicModePolicy::isPublicRead()
            && \NomadCMS\Security\PanicModeService::isActive();
    }
    
    /**
     * Send 503 Service Unavailable response and exit (for Panic Mode)
     */
    private static function sendServiceUnavailable(string $message): never
    {
        http_response_code(503);
        header('Content-Type: application/json');
        header('Retry-After: 300'); // Suggest retry after 5 minutes
        
        echo json_encode([
            'success' => false,
            'error' => $message,
            'code' => 'PANIC_MODE_ACTIVE',
            'message' => '🚨 A rendszer jelenleg vészhelyzeti üzemmódban van. Írási műveletek ideiglenesen letiltva.',
        ]);
        
        exit;
    }
}
