<?php
/**
 * NOMAD CMS - Panic Mode Middleware 🚨
 * 
 * Blocks operations outside published reads and scoped recovery during panic.
 * Think of it as the bouncer at the club, but for endpoint operations.
 * 
 * "You shall not POST!" - Gandalf, probably
 */

declare(strict_types=1);

namespace NomadCMS\Middleware;

use NomadCMS\Security\PanicModeService;
use NomadCMS\Security\PanicModePolicy;
use NomadCMS\Security\PanicModeException;
use NomadCMS\Security\PanicMutationGuard;

final class PanicModeMiddleware
{
    /**
     * Enforce operation policy after CORS and before endpoint processing.
     * We need to be able to disable panic mode somehow: only the resolved
     * recovery endpoints are exempt, and they authenticate their own callers.
     */
    public static function check(): void
    {
        if (PHP_SAPI === 'cli' || ($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'OPTIONS') {
            return;
        }
        if (!is_file(dirname(__DIR__, 2) . '/.env') && !is_file(\NomadCMS\Database\AuthDatabase::path())) {
            return; // The installer initializes state before serving normal work.
        }
        register_shutdown_function(PanicMutationGuard::releaseRequest(...));
        $public = PanicModePolicy::isPublicRead();
        $active = PanicModeService::isActive();
        if ($public && $active) {
            PanicModeService::setReadOnlyRequest(true);
            self::addStatusHeader();
            return;
        }
        if (PanicModePolicy::isControl()) {
            return; // Control acquires its own exclusive lease; never upgrade SH.
        }
        $recovery = PanicModePolicy::isRecoveryAuthentication() || PanicModePolicy::allowsRecoveryToken();
        if ($active && !$recovery) {
            self::respond(new PanicModeException('PANIC_MODE_ACTIVE', 'System is in emergency read-only mode.'));
        }
        try {
            PanicMutationGuard::beginRequest($recovery);
        } catch (PanicModeException $e) {
            if ($public && PanicModeService::isActive()) {
                PanicModeService::setReadOnlyRequest(true);
                self::addStatusHeader();
                return;
            }
            self::respond($e);
        }
    }

    /** Stable errors are cache-protected and never expose infrastructure details. */
    public static function respond(PanicModeException $e): never
    {
        http_response_code($e->httpStatus);
        header('Content-Type: application/json; charset=utf-8');
        header('Cache-Control: no-store');
        if ($e->httpStatus === 503) {
            header('Retry-After: 300');
        }
        echo json_encode(['success' => false, 'error' => $e->getMessage(), 'code' => $e->errorCode], JSON_THROW_ON_ERROR);
        exit;
    }

    /** Add panic mode header to response (for debugging/info). */
    public static function addStatusHeader(): void
    {
        if (PanicModeService::isActive()) {
            header('X-Panic-Mode: active');
        }
    }
}
