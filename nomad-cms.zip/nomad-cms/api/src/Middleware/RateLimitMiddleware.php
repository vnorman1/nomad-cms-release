<?php
/**
 * NOMAD CMS - Rate Limit Middleware
 * IP and user-based rate limiting for brute-force protection
 */

declare(strict_types=1);

namespace NomadCMS\Middleware;

use NomadCMS\Config\Security;
use RateLimit\Rate;
use RateLimit\RedisRateLimiter;
use RateLimit\InMemoryRateLimiter;

final class RateLimitMiddleware
{
    private static array $requestCounts = [];
    private static ?string $cacheDir = null;
    
    /**
     * Check rate limit for current request
     * Uses file-based storage for SQLite compatibility
     * 
     * @param string $key Unique identifier (IP, user ID, endpoint)
     * @param int $maxRequests Maximum requests allowed
     * @param int $windowSeconds Time window in seconds
     */
    public static function check(
        ?string $key = null,
        ?int $maxRequests = null,
        ?int $windowSeconds = null
    ): void {
        if (($_ENV['RATE_LIMIT_ENABLED'] ?? 'true') !== 'true') {
            return;
        }
        
        $settings = Security::getRateLimitSettings()['general'];
        $key = $key ?? self::getDefaultKey();
        $maxRequests = $maxRequests ?? $settings['max'];
        $windowSeconds = $windowSeconds ?? $settings['window'];
        
        if (!self::reserve($key, $maxRequests, $windowSeconds)) {
            self::sendRateLimitError($maxRequests, $windowSeconds);
        }
    }
    
    /**
     * Special rate limit for authentication endpoints
     * Uses dynamic settings from .env
     */
    public static function checkAuth(): void
    {
        $settings = Security::getRateLimitSettings()['login'];
        self::check(
            key: 'auth:' . self::getClientIp(),
            maxRequests: $settings['max'],
            windowSeconds: $settings['window']
        );
    }
    
    /**
     * Very strict limit for password reset
     */
    public static function checkPasswordReset(): void
    {
        $settings = Security::getRateLimitSettings()['password_reset'];
        self::check(
            key: 'reset:' . self::getClientIp(),
            maxRequests: $settings['max'],
            windowSeconds: $settings['window']
        );
    }
    
    /**
     * Limit for TOTP verification
     */
    public static function checkTOTP(?int $userId = null): void
    {
        $settings = Security::getRateLimitSettings()['totp'];
        self::check(
            key: 'totp:' . self::getClientIp(),
            maxRequests: $settings['max'],
            windowSeconds: $settings['window']
        );
        if ($userId !== null) {
            self::check('totp-user:' . $userId, $settings['max'], $settings['window']);
        }
    }

    /** Check and increment under the same exclusive lock; never fail open. */
    private static function reserve(string $key, int $limit, int $window): bool
    {
        $file = self::getCacheFile($key);
        $registry = self::registry(LOCK_SH);
        $handle = fopen($file, 'c+');
        if ($handle === false) {
            flock($registry, LOCK_UN);
            fclose($registry);
            throw new \NomadCMS\Auth\AuthException('RATE_LIMIT_UNAVAILABLE', 'Request protection is unavailable.', 503);
        }
        try {
            if (!flock($handle, LOCK_EX)) {
                throw new \NomadCMS\Auth\AuthException('RATE_LIMIT_UNAVAILABLE', 'Request protection is unavailable.', 503);
            }
            $raw = stream_get_contents($handle, 4096);
            $data = json_decode($raw ?: '{}', true);
            $now = time();
            $count = is_array($data) && ($data['expires_at'] ?? 0) > $now ? (int) ($data['count'] ?? 0) : 0;
            if ($count >= $limit) {
                return false;
            }
            $expires = $count > 0 ? (int) $data['expires_at'] : $now + $window;
            $encoded = json_encode(['count' => $count + 1, 'expires_at' => $expires]);
            rewind($handle);
            if (!ftruncate($handle, 0) || fwrite($handle, $encoded) !== strlen($encoded) || !fflush($handle)) {
                throw new \NomadCMS\Auth\AuthException('RATE_LIMIT_UNAVAILABLE', 'Request protection is unavailable.', 503);
            }
            return true;
        } finally {
            flock($handle, LOCK_UN);
            fclose($handle);
            flock($registry, LOCK_UN);
            fclose($registry);
        }
    }
    
    /**
     * Limit for registration
     */
    public static function checkRegistration(): void
    {
        $settings = Security::getRateLimitSettings()['registration'];
        self::check(
            key: 'register:' . self::getClientIp(),
            maxRequests: $settings['max'],
            windowSeconds: $settings['window']
        );
    }
    
    /**
     * Limit for magic-link (onboarding invitation) redemption.
     *
     * A magic link is a bearer secret travelling in a URL, so redemption
     * attempts get their own strict bucket - independent of the login bucket,
     * so magic-link probing cannot be used to lock legitimate logins out
     * (and vice versa).
     */
    public static function checkMagicLink(): void
    {
        $settings = Security::getRateLimitSettings()['magic_link'];
        self::check(
            key: 'magiclink:' . self::getClientIp(),
            maxRequests: $settings['max'],
            windowSeconds: $settings['window']
        );
    }
    
    /**
     * Get current count for key
     * Uses file locking to prevent race conditions
     */
    private static function getCurrentCount(string $key, int $windowSeconds): int
    {
        $cacheFile = self::getCacheFile($key);
        
        if (!file_exists($cacheFile)) {
            return 0;
        }
        
        // Use exclusive lock to prevent race condition
        $fp = fopen($cacheFile, 'r');
        if (!$fp) {
            return 0;
        }
        
        flock($fp, LOCK_SH); // Shared lock for reading
        $content = stream_get_contents($fp);
        flock($fp, LOCK_UN);
        fclose($fp);
        
        $data = json_decode($content, true);
        
        if (!$data || !isset($data['expires_at']) || $data['expires_at'] < time()) {
            return 0;
        }
        
        return $data['count'] ?? 0;
    }
    
    /**
     * Increment request count
     * Uses exclusive file locking to prevent race conditions
     */
    private static function incrementCount(string $key, int $windowSeconds): void
    {
        $cacheFile = self::getCacheFile($key);
        $now = time();
        
        // Use exclusive lock for atomic read-modify-write
        $fp = fopen($cacheFile, 'c+');
        if (!$fp) {
            return;
        }
        
        flock($fp, LOCK_EX); // Exclusive lock
        
        $content = stream_get_contents($fp);
        $data = $content ? json_decode($content, true) : null;
        
        if ($data && isset($data['expires_at']) && $data['expires_at'] >= $now) {
            $data['count'] = ($data['count'] ?? 0) + 1;
        } else {
            $data = [
                'count' => 1,
                'expires_at' => $now + $windowSeconds,
            ];
        }
        
        // Rewind and truncate before writing
        ftruncate($fp, 0);
        rewind($fp);
        fwrite($fp, json_encode($data));
        fflush($fp);
        
        flock($fp, LOCK_UN);
        fclose($fp);
    }
    
    /**
     * Get cache file path for key
     */
    private static function getCacheFile(string $key): string
    {
        if (!self::$cacheDir) {
            self::$cacheDir = sys_get_temp_dir() . '/nomad_ratelimit-' . substr(hash('sha256', \NomadCMS\Database\AuthDatabase::path()), 0, 16);
            
            if (!is_dir(self::$cacheDir)) {
                mkdir(self::$cacheDir, 0700, true);
            }
        }
        
        $hash = md5($key);
        return self::$cacheDir . '/' . $hash . '.json';
    }
    
    /**
     * Get default rate limit key (IP + endpoint)
     */
    private static function getDefaultKey(): string
    {
        $ip = self::getClientIp();
        $endpoint = $_SERVER['REQUEST_URI'] ?? '/';
        
        return "ip:{$ip}:endpoint:{$endpoint}";
    }
    
    /**
     * Get client IP address
     * SECURITY: Only trusts proxy headers when connection is from a trusted proxy
     */
    private static function getClientIp(): string
    {
        // Delegates to ClientIpResolver (single source of truth, shared with
        // RequestLoggerMiddleware / InstallationMiddleware / WebhookMiddleware).
        return \NomadCMS\Security\ClientIpResolver::resolve();
    }
    
    /**
     * Reset rate limit for key
     * Use after successful authentication
     */
    public static function reset(string $key): void
    {
        $cacheFile = self::getCacheFile($key);
        $registry = self::registry(LOCK_EX);
        try {
            if (file_exists($cacheFile)) {
                unlink($cacheFile);
            }
        } finally {
            flock($registry, LOCK_UN);
            fclose($registry);
        }
    }

    /** Stable registry lock prevents unlink/open races during cache cleanup. */
    private static function registry(int $operation): mixed
    {
        $handle = fopen(self::$cacheDir . '/registry.lock', 'c');
        if ($handle === false || !flock($handle, $operation)) {
            if (is_resource($handle)) {
                fclose($handle);
            }
            throw new \NomadCMS\Auth\AuthException('RATE_LIMIT_UNAVAILABLE', 'Request protection is unavailable.', 503);
        }
        return $handle;
    }

    /**
     * Get remaining requests for current client
     */
    public static function getRemaining(?string $key = null): int
    {
        $key = $key ?? self::getDefaultKey();
        $settings = Security::getRateLimitSettings()['general'];
        
        $current = self::getCurrentCount($key, $settings['window']);
        
        return max(0, $settings['max'] - $current);
    }
    
    /**
     * Send rate limit exceeded error
     */
    private static function sendRateLimitError(int $limit, int $window): never
    {
        http_response_code(429);
        header('Content-Type: application/json');
        header("Retry-After: $window");
        header("X-RateLimit-Limit: $limit");
        header('X-RateLimit-Remaining: 0');
        
        echo json_encode([
            'success' => false,
            'error' => 'Too many requests. Please try again later.',
            'code' => 'RATE_LIMIT_EXCEEDED',
            'retry_after' => $window,
        ]);
        
        exit;
    }
    
    /**
     * Cleanup old cache files (call periodically)
     */
    public static function cleanup(): int
    {
        if (!self::$cacheDir || !is_dir(self::$cacheDir)) {
            return 0;
        }
        
        $cleaned = 0;
        $now = time();
        
        $registry = self::registry(LOCK_EX);
        try {
            $visited = 0;
            foreach (new \DirectoryIterator(self::$cacheDir) as $entry) {
                if (!$entry->isFile() || $entry->getExtension() !== 'json') {
                    continue;
                }
                if (++$visited > 1000) {
                    break; // Keep housekeeping bounded on shared hosting.
                }
                $data = json_decode(file_get_contents($entry->getPathname()), true);
                if (!$data || !isset($data['expires_at']) || $data['expires_at'] <= $now) {
                    unlink($entry->getPathname());
                    $cleaned++;
                }
            }
        } finally {
            flock($registry, LOCK_UN);
            fclose($registry);
        }

        return $cleaned;
    }
}
