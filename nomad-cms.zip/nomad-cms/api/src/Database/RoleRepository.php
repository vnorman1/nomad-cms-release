<?php
/**
 * NOMAD CMS - Role Repository
 * Database operations for custom roles & permissions (Extended RBAC/ABAC-hybrid)
 */

declare(strict_types=1);

namespace NomadCMS\Database;

final class RoleRepository
{
    // Built-in system role slugs - protected from deletion / slug changes
    public const SYSTEM_ROLES = ['super_admin', 'editor', 'viewer'];

    // Fallback role assigned to users when their role is deleted
    public const FALLBACK_ROLE = 'viewer';

    /**
     * Find all roles, optionally including their permissions and user counts.
     *
     * @return array<int, array{id:int, slug:string, name:string, description:?string, is_system:bool, priority:int, slot_access:array, permissions:array, user_count:int, created_at:string, updated_at:string}>
     */
    public static function findAll(): array
    {
        $db = AuthDatabase::getInstance();

        $roles = $db->query("SELECT * FROM roles ORDER BY priority DESC, name ASC")->fetchAll();

        $result = [];
        foreach ($roles as $role) {
            $result[] = self::hydrate($role, $db);
        }

        return $result;
    }

    /**
     * Find a single role by slug.
     */
    public static function findBySlug(string $slug): ?array
    {
        $db = AuthDatabase::getInstance();
        $stmt = $db->prepare("SELECT * FROM roles WHERE slug = ?");
        $stmt->execute([$slug]);
        $role = $stmt->fetch();

        return $role ? self::hydrate($role, $db) : null;
    }

    /**
     * Find a single role by id.
     */
    public static function findById(int $id): ?array
    {
        $db = AuthDatabase::getInstance();
        $stmt = $db->prepare("SELECT * FROM roles WHERE id = ?");
        $stmt->execute([$id]);
        $role = $stmt->fetch();

        return $role ? self::hydrate($role, $db) : null;
    }

    /**
     * Create a new custom role.
     *
     * @param string $slug Unique identifier (lowercase, underscores)
     * @param string $name Display name
     * @param string|null $description
     * @param array<int, string> $permissions List of 'resource:action:scope' strings
     * @param array<int, string> $slotAccess List of slot key wildcard patterns (e.g. ["cikk*", "fooldal"])
     * @param int $priority Hierarchy priority (higher = more authoritative in conflicts)
     * @throws \Exception if slug already exists or is reserved
     */
    public static function create(
        string $slug,
        string $name,
        ?string $description,
        array $permissions,
        array $slotAccess,
        int $priority = 100
    ): array {
        \NomadCMS\Services\Schema\SchemaAccess::protectPermissions([], $permissions);
        $slug = self::normalizeSlug($slug);

        if (in_array($slug, self::SYSTEM_ROLES, true)) {
            throw new \Exception("A '{$slug}' egy rendszer szerepkör, foglalt azonosító.");
        }

        $db = AuthDatabase::getInstance();

        $stmt = $db->prepare("SELECT id FROM roles WHERE slug = ?");
        $stmt->execute([$slug]);
        if ($stmt->fetch()) {
            throw new \Exception("A '{$slug}' szerepkör már létezik.");
        }

        $db->beginTransaction();
        try {
            $insert = $db->prepare("
                INSERT INTO roles (slug, name, description, is_system, priority, slot_access, updated_at)
                VALUES (?, ?, ?, 0, ?, ?, datetime('now'))
            ");
            $insert->execute([$slug, $name, $description, $priority, json_encode(array_values($slotAccess))]);

            $roleId = (int) $db->lastInsertId();
            self::replacePermissions($roleId, $permissions, $db);

            $db->commit();
        } catch (\Exception $e) {
            $db->rollBack();
            throw $e;
        }

        if (in_array(\NomadCMS\Services\Schema\SchemaAccess::PERMISSION, $permissions, true)) {
            \NomadCMS\Services\Schema\SchemaAccess::auditDelegation('schema.grant.created', ['role' => $slug]);
        }
        return self::findBySlug($slug);
    }

    /**
     * Update an existing role.
     *
     * System roles (super_admin) cannot be modified at all. editor/viewer
     * (also system roles) may have their permissions/slot_access edited by an
     * admin, but their slug/is_system flag can never change and they can't be deleted.
     *
     * @param array{name?:string, description?:string, permissions?:array, slot_access?:array, priority?:int} $data
     */
    public static function update(string $slug, array $data): array
    {
        $slug = self::normalizeSlug($slug);
        $role = self::findBySlug($slug);

        if (!$role) {
            throw new \Exception("Szerepkör nem található: {$slug}");
        }

        if (isset($data['permissions'])) {
            \NomadCMS\Services\Schema\SchemaAccess::protectPermissions($role['permissions'], $data['permissions']);
        }

        if ($slug === 'super_admin') {
            throw new \Exception('A super_admin szerepkör nem módosítható.');
        }

        $db = AuthDatabase::getInstance();
        $db->beginTransaction();

        try {
            $fields = [];
            $params = [];

            if (isset($data['name'])) {
                $fields[] = 'name = ?';
                $params[] = $data['name'];
            }
            if (array_key_exists('description', $data)) {
                $fields[] = 'description = ?';
                $params[] = $data['description'];
            }
            if (isset($data['priority']) && !$role['is_system']) {
                // Priority for system roles (editor/viewer) is fixed to preserve hierarchy guarantees
                $fields[] = 'priority = ?';
                $params[] = (int) $data['priority'];
            }
            if (isset($data['slot_access'])) {
                $fields[] = 'slot_access = ?';
                $params[] = json_encode(array_values($data['slot_access']));
            }

            if (!empty($fields)) {
                $fields[] = "updated_at = datetime('now')";
                $sql = "UPDATE roles SET " . implode(', ', $fields) . " WHERE id = ?";
                $params[] = $role['id'];
                $db->prepare($sql)->execute($params);
            }

            if (isset($data['permissions'])) {
                self::replacePermissions($role['id'], $data['permissions'], $db);
            }

            $db->commit();
        } catch (\Exception $e) {
            $db->rollBack();
            throw $e;
        }

        if (isset($data['permissions']) && in_array(\NomadCMS\Services\Schema\SchemaAccess::PERMISSION, $role['permissions'], true) !== in_array(\NomadCMS\Services\Schema\SchemaAccess::PERMISSION, $data['permissions'], true)) {
            \NomadCMS\Services\Schema\SchemaAccess::auditDelegation('schema.grant.changed', ['role' => $slug, 'granted' => in_array(\NomadCMS\Services\Schema\SchemaAccess::PERMISSION, $data['permissions'], true)]);
        }
        return self::findBySlug($slug);
    }

    /**
     * Delete a custom role. System roles cannot be deleted.
     * Users assigned to the deleted role fall back to the 'viewer' role.
     *
     * @return int Number of affected users reassigned to fallback role
     */
    public static function delete(string $slug): int
    {
        $slug = self::normalizeSlug($slug);

        if (in_array($slug, self::SYSTEM_ROLES, true)) {
            throw new \Exception("A '{$slug}' rendszer szerepkör nem törölhető.");
        }

        $role = self::findBySlug($slug);
        if (!$role) {
            throw new \Exception("Szerepkör nem található: {$slug}");
        }

        \NomadCMS\Services\Schema\SchemaAccess::protectPermissions($role['permissions'], []);
        $db = AuthDatabase::getInstance();
        $db->beginTransaction();

        try {
            // Reassign affected users to fallback role BEFORE deleting the role
            $stmt = $db->prepare("UPDATE users SET role_slug = ? WHERE role_slug = ?");
            $stmt->execute([self::FALLBACK_ROLE, $slug]);
            $affected = $stmt->rowCount();

            $db->prepare("DELETE FROM roles WHERE id = ?")->execute([$role['id']]);

            $db->commit();
            if (in_array(\NomadCMS\Services\Schema\SchemaAccess::PERMISSION, $role['permissions'], true)) {
                \NomadCMS\Services\Schema\SchemaAccess::auditDelegation('schema.grant.revoked', ['role' => $slug, 'affected_users' => $affected]);
            }
            return $affected;
        } catch (\Exception $e) {
            $db->rollBack();
            throw $e;
        }
    }

    /**
     * Assign a role to a user by their user id.
     *
     * SAFETY: Refuses to demote the LAST active (non-locked) super_admin user
     * away from super_admin, to prevent the system from becoming permanently
     * unmanageable (no user left with users:manage:* / system:admin:* access).
     */
    public static function assignToUser(int $userId, string $roleSlug): bool
    {
        $roleSlug = self::normalizeSlug($roleSlug);
        $role = self::findBySlug($roleSlug);

        if (!$role) {
            throw new \Exception("Szerepkör nem található: {$roleSlug}");
        }

        $db = AuthDatabase::getInstance();

        $targetUser = UserRepository::findById($userId);
        $beforeRole = $targetUser ? self::getUserRole($targetUser) : null;
        \NomadCMS\Services\Schema\SchemaAccess::protectAssignment($beforeRole, $role);

        if ($roleSlug !== 'super_admin') {
            $currentSlugStmt = $db->prepare("SELECT role_slug, is_admin FROM users WHERE id = ?");
            $currentSlugStmt->execute([$userId]);
            $currentUser = $currentSlugStmt->fetch();

            $isCurrentlySuperAdmin = $currentUser && (
                $currentUser['role_slug'] === 'super_admin' ||
                (empty($currentUser['role_slug']) && !empty($currentUser['is_admin']))
            );

            if ($isCurrentlySuperAdmin && self::countActiveSuperAdmins($db, excludeUserId: $userId) === 0) {
                throw new \Exception('Nem lehet lefokozni az utolsó aktív Super Admin felhasználót - a rendszer zárolása ellen védve.');
            }
        }

        $stmt = $db->prepare("UPDATE users SET role_slug = ?, updated_at = datetime('now') WHERE id = ?");
        $result = $stmt->execute([$roleSlug, $userId]);
        if ($result && ($beforeRole['slug'] ?? null) !== $roleSlug && (\NomadCMS\Services\Schema\SchemaAccess::isSuperAdmin(['role_slug' => $roleSlug]) || in_array(\NomadCMS\Services\Schema\SchemaAccess::PERMISSION, array_merge($beforeRole['permissions'] ?? [], $role['permissions']), true))) {
            \NomadCMS\Services\Schema\SchemaAccess::auditDelegation('schema.authority.assigned', ['user_id' => $userId, 'from' => $beforeRole['slug'] ?? null, 'to' => $roleSlug]);
        }
        return $result;
    }

    /**
     * Count active (non-locked) super_admin users, optionally excluding one user id.
     * Considers both explicit role_slug='super_admin' AND legacy is_admin=1
     * users whose role_slug hasn't been backfilled yet.
     */
    public static function countActiveSuperAdmins(\PDO $db, ?int $excludeUserId = null): int
    {
        $sql = "
            SELECT COUNT(*) FROM users
            WHERE (role_slug = 'super_admin' OR (role_slug IS NULL AND is_admin = 1))
              AND (locked_until IS NULL OR locked_until < datetime('now'))
        ";
        $params = [];

        if ($excludeUserId !== null) {
            $sql .= " AND id != ?";
            $params[] = $excludeUserId;
        }

        $stmt = $db->prepare($sql);
        $stmt->execute($params);
        return (int) $stmt->fetchColumn();
    }

    /**
     * Get the role assigned to a user (by role_slug). Falls back to deriving
     * from the legacy `is_admin` / `role` columns if role_slug is not set
     * (pre-migration users).
     */
    public static function getUserRole(array $user): ?array
    {
        if (!empty($user['role_slug'])) {
            $role = self::findBySlug($user['role_slug']);
            if ($role) {
                return $role;
            }
        }

        // Legacy fallback: derive from is_admin / role columns
        if (!empty($user['is_admin'])) {
            return self::findBySlug('super_admin');
        }

        $legacyRole = $user['role'] ?? null;
        if ($legacyRole === 'editor') {
            return self::findBySlug('editor');
        }

        return self::findBySlug(self::FALLBACK_ROLE);
    }

    /**
     * Get permission strings for a role id.
     *
     * @return array<int, string>
     */
    public static function getPermissions(int $roleId): array
    {
        $db = AuthDatabase::getInstance();
        $stmt = $db->prepare("SELECT permission FROM role_permissions WHERE role_id = ?");
        $stmt->execute([$roleId]);
        return array_column($stmt->fetchAll(), 'permission');
    }

    /**
     * Replace all permissions for a role (delete + re-insert).
     *
     * @param array<int, string> $permissions
     */
    private static function replacePermissions(int $roleId, array $permissions, \PDO $db): void
    {
        $db->prepare("DELETE FROM role_permissions WHERE role_id = ?")->execute([$roleId]);

        $stmt = $db->prepare("INSERT INTO role_permissions (role_id, permission) VALUES (?, ?)");
        foreach (array_unique($permissions) as $permission) {
            $permission = trim((string) $permission);
            if ($permission === '') {
                continue;
            }
            $stmt->execute([$roleId, $permission]);
        }
    }

    /**
     * Hydrate a raw role DB row with decoded slot_access, permissions, and user_count.
     */
    private static function hydrate(array $role, \PDO $db): array
    {
        $countStmt = $db->prepare("SELECT COUNT(*) FROM users WHERE role_slug = ?");
        $countStmt->execute([$role['slug']]);

        return [
            'id' => (int) $role['id'],
            'slug' => $role['slug'],
            'name' => $role['name'],
            'description' => $role['description'],
            'is_system' => (bool) $role['is_system'],
            'priority' => (int) $role['priority'],
            'slot_access' => json_decode($role['slot_access'] ?? '[]', true) ?: [],
            'permissions' => self::getPermissions((int) $role['id']),
            'user_count' => (int) $countStmt->fetchColumn(),
            'created_at' => $role['created_at'],
            'updated_at' => $role['updated_at'],
        ];
    }

    /**
     * Normalize a role slug: lowercase, spaces -> underscores, strip invalid chars.
     */
    public static function normalizeSlug(string $slug): string
    {
        $slug = strtolower(trim($slug));
        $slug = preg_replace('/[^a-z0-9_]+/', '_', $slug) ?? $slug;
        $slug = trim($slug, '_');

        if ($slug === '') {
            throw new \Exception('Érvénytelen szerepkör azonosító.');
        }

        return $slug;
    }
}
