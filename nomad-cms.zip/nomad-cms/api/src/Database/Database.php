<?php
/**
 * NOMAD CMS - Database Facade
 * Unified access point for database connections across split architectures
 */

declare(strict_types=1);

namespace NomadCMS\Database;

use PDO;

final class Database
{
    private const SYSTEM_SETTINGS_MIGRATION_KEY = 'split_system_settings_v1';
    private static bool $systemSettingsMigrationChecked = false;
    private static bool $systemSettingsMigrationRunning = false;

    /**
     * Get system SQLite PDO connection (system.sqlite: users, auth, presence, system settings)
     */
    public static function getSystemConnection(): PDO
    {
        $db = AuthDatabase::getInstance();
        self::migrateLegacySystemSettings($db);
        return $db;
    }

    /**
     * One-time compatibility path for installs that still have system settings in database.sqlite.
     */
    private static function migrateLegacySystemSettings(PDO $systemDb): void
    {
        if (self::$systemSettingsMigrationChecked || self::$systemSettingsMigrationRunning) {
            return;
        }

        self::$systemSettingsMigrationRunning = true;
        try {
            $systemDb->exec("CREATE TABLE IF NOT EXISTS system_settings_migrations (
                name TEXT PRIMARY KEY,
                applied_at TEXT NOT NULL DEFAULT (datetime('now'))
            )");
            $marker = $systemDb->prepare('SELECT 1 FROM system_settings_migrations WHERE name = ?');
            $marker->execute([self::SYSTEM_SETTINGS_MIGRATION_KEY]);
            $alreadyMigrated = (bool) $marker->fetchColumn();
            $marker->closeCursor();
            if ($alreadyMigrated) {
                self::$systemSettingsMigrationChecked = true;
                return;
            }

            $tables = ['cache_settings', 'media_settings', 'versioning_settings'];
            foreach ($tables as $table) {
                $systemDb->exec("CREATE TABLE IF NOT EXISTS {$table} (
                    key TEXT PRIMARY KEY,
                    value TEXT NOT NULL,
                    updated_at TEXT DEFAULT (datetime('now'))
                )");
            }

            $contentDb = ContentDatabase::getInstance();
            $legacyTables = [];
            foreach ($tables as $table) {
                $stmt = $contentDb->prepare("SELECT 1 FROM sqlite_master WHERE type = 'table' AND name = ?");
                $stmt->execute([$table]);
                $exists = (bool) $stmt->fetchColumn();
                $stmt->closeCursor();
                if ($exists) {
                    $legacyTables[] = $table;
                }
            }

            if ($legacyTables !== []) {
                $systemDb->beginTransaction();
                try {
                    foreach ($legacyTables as $table) {
                        $rows = $contentDb->query("SELECT key, value, updated_at FROM {$table}")->fetchAll(PDO::FETCH_ASSOC);
                        $insert = $systemDb->prepare("INSERT OR IGNORE INTO {$table} (key, value, updated_at) VALUES (?, ?, ?)");
                        foreach ($rows as $row) {
                            $insert->execute([$row['key'], $row['value'], $row['updated_at'] ?? null]);
                        }
                    }
                    $systemDb->commit();
                } catch (\Throwable $e) {
                    if ($systemDb->inTransaction()) {
                        $systemDb->rollBack();
                    }
                    throw $e;
                }

                foreach ($legacyTables as $table) {
                    $contentDb->exec("DROP TABLE IF EXISTS {$table}");
                }
            }

            $mark = $systemDb->prepare('INSERT OR IGNORE INTO system_settings_migrations (name) VALUES (?)');
            $mark->execute([self::SYSTEM_SETTINGS_MIGRATION_KEY]);
            self::$systemSettingsMigrationChecked = true;
        } finally {
            self::$systemSettingsMigrationRunning = false;
        }
    }

    /**
     * Get content SQLite PDO connection (database.sqlite: content, slots, media meta)
     */
    public static function getContentConnection(): PDO
    {
        return ContentDatabase::getInstance();
    }

    /**
     * Get massive SQLite PDO connection (massive.sqlite: datasets, form submissions)
     */
    public static function getMassiveConnection(): PDO
    {
        return MassiveDatabase::getInstance();
    }
}
