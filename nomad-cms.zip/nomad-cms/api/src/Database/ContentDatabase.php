<?php
/**
 * NOMAD CMS - Content Database
 * CMS content data (slots, media, versions, etc.)
 * 
 * Split Architecture:
 * - system.sqlite: users, auth, sessions (AuthDatabase)
 * - database.sqlite: CMS content, slots, media, versions (THIS FILE)
 * 
 * ARCHITECTURE FIX (2026-01-05):
 * - Versioning is NOW AUTOMATIC at the database layer
 * - All saves go through createVersionedSlot() for guaranteed history
 * - No more client-side opt-in versioning
 * - OPTIMISTIC LOCKING with expected_version parameter
 */

declare(strict_types=1);

namespace NomadCMS\Database;

use PDO;
use PDOException;
use NomadCMS\Services\VersioningService;

/**
 * Exception thrown when optimistic locking fails (concurrent modification)
 * 
 * ENTERPRISE OPTIMISTIC LOCKING:
 * Supports both version-based and hash-based locking:
 * - Version: Sequential number (simpler but can fail on history prune)
 * - Hash: SHA-256 of content (TRUE content identity, recommended)
 */
class OptimisticLockException extends \RuntimeException
{
    public function __construct(
        public readonly string $slotKey,
        public readonly ?int $expectedVersion = null,
        public readonly ?int $actualVersion = null,
        public readonly ?string $expectedHash = null,
        public readonly ?string $actualHash = null,
        public readonly string $lockType = 'version'  // 'version' or 'hash'
    ) {
        if ($lockType === 'hash') {
            $message = "Content hash mismatch for slot '{$slotKey}': " .
                "expected hash " . substr($expectedHash ?? '', 0, 16) . "..., " .
                "but current hash is " . substr($actualHash ?? '', 0, 16) . "... " .
                "Content was modified by another user/process.";
        } else {
            $message = "Version mismatch for slot '{$slotKey}': " .
                "expected version {$expectedVersion}, but current version is {$actualVersion}. " .
                "Content was modified by another user/process.";
        }
        parent::__construct($message);
    }
}

final class ContentDatabase
{
    private static ?PDO $instance = null;
    
    /**
     * Slot types that should skip auto-versioning (high-frequency saves)
     * Can be overridden by explicit versioning request
     */
    private const SKIP_VERSIONING_TYPES = ['draft', 'autosave', 'temp'];
    
    /**
     * Get singleton database instance
     */
    public static function getInstance(bool $initialize = true): PDO
    {
        if (self::$instance === null) {
            $dbFile = $_ENV['DB_CONTENT_DATABASE'] ?? 'database.sqlite';
            $dbPath = str_starts_with($dbFile, '/') ? $dbFile : __DIR__ . '/../../databases/' . $dbFile;
            
            try {
                $readOnly = \NomadCMS\Security\PanicModeService::isReadOnlyRequest();
                if ($readOnly && !is_file($dbPath)) {
                    throw new \RuntimeException('Content storage is unavailable.');
                }
                self::$instance = new PDO($readOnly ? 'sqlite:file:' . rawurlencode($dbPath) . '?mode=ro' : "sqlite:$dbPath", null, null, [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES => false,
                    PDO::ATTR_TIMEOUT => 5,
                ]);
                
                // Initialize schema if needed
                if ($readOnly) {
                    self::$instance->exec('PRAGMA query_only=ON; PRAGMA busy_timeout=500; PRAGMA cache_size=-2048; PRAGMA foreign_keys=ON');
                } elseif ($initialize) {
                    self::initializeSchema();
                } else {
                    // Installed Hub target reads reuse this connection without schema writes.
                    self::$instance->exec('PRAGMA busy_timeout=500; PRAGMA foreign_keys=ON; PRAGMA cache_size=-2048');
                }
                
            } catch (PDOException $e) {
                throw new \RuntimeException("Content database connection failed: " . $e->getMessage());
            }
        }
        
        return self::$instance;
    }
    
    /**
     * Initialize database schema
     */
    private static function initializeSchema(): void
    {
        $db = self::$instance;
        
        // Set busy timeout to 5s to prevent immediate SQLITE_BUSY locking errors on concurrent access
        // CRITICAL CONCURRENCY: Must be executed FIRST before any query or pragma!
        $db->exec('PRAGMA busy_timeout=5000');

        // Try WAL mode for better concurrency, fallback to DELETE for shared hosting
        try {
            $result = $db->query('PRAGMA journal_mode=WAL')->fetchColumn();
            if (strtoupper($result) === 'WAL') {
                // WAL mode successful - use NORMAL sync (safe with WAL)
                $db->exec('PRAGMA synchronous=NORMAL');
            } else {
                // WAL failed (e.g., NFS/shared hosting) - use DELETE mode
                $db->exec('PRAGMA journal_mode=DELETE');
                $db->exec('PRAGMA synchronous=FULL');
            }
        } catch (\Exception $e) {
            // Fallback to DELETE mode on any error
            $db->exec('PRAGMA journal_mode=DELETE');
            $db->exec('PRAGMA synchronous=FULL');
        }
        // 5MB cache for better read performance
        $db->exec('PRAGMA cache_size=-5000');
        // Temp tables in memory for faster JOINs
        $db->exec('PRAGMA temp_store=MEMORY');
        // Enable foreign keys for referential integrity
        $db->exec('PRAGMA foreign_keys=ON');
        // Auto-vacuum for long-term file size optimization
        $db->exec('PRAGMA auto_vacuum=INCREMENTAL');
        
        // Slots table (CMS content)
        $db->exec("
            CREATE TABLE IF NOT EXISTS slots (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                key TEXT UNIQUE NOT NULL,
                data TEXT NOT NULL,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
        ");
        
        // Media table
        $db->exec("
            CREATE TABLE IF NOT EXISTS media (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                filename TEXT NOT NULL,
                original_name TEXT NOT NULL,
                mime_type TEXT NOT NULL,
                size INTEGER NOT NULL,
                path TEXT NOT NULL,
                uploaded_by INTEGER DEFAULT NULL,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
        ");
        
        // =========================================================================
        // Extended RBAC: Slot / Item Ownership (ABAC 'own' scope support)
        // =========================================================================
        //
        // Ownership granularity:
        // - Object-type slots: one row with item_uid = NULL -> owns the whole slot
        // - List/Collection-type slots: one row PER ITEM, item_uid = the item's
        //   `_dndId` -> owns just that item
        //
        // Policy: first-writer-wins. Ownership is recorded once, on first save,
        // and never silently overwritten by later saves from other users.
        $db->exec("
            CREATE TABLE IF NOT EXISTS slot_ownership (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                slot_key TEXT NOT NULL,
                item_uid TEXT DEFAULT NULL,
                owner_uuid TEXT NOT NULL,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(slot_key, item_uid)
            )
        ");
        
        $db->exec("CREATE INDEX IF NOT EXISTS idx_ownership_slot ON slot_ownership(slot_key)");
        $db->exec("CREATE INDEX IF NOT EXISTS idx_ownership_owner ON slot_ownership(owner_uuid)");
        $db->exec("CREATE INDEX IF NOT EXISTS idx_ownership_slot_item ON slot_ownership(slot_key, item_uid)");
        
        self::ensureMediaMetaSchema($db);
        self::ensureRelationSchema($db);
        \NomadCMS\Services\MediaService::ensureSchema($db);
        
        // Create indexes
        $db->exec("CREATE INDEX IF NOT EXISTS idx_slots_key ON slots(key)");
        $db->exec("CREATE INDEX IF NOT EXISTS idx_media_filename ON media(filename)");
        $db->exec("CREATE INDEX IF NOT EXISTS idx_media_meta_filename ON media_meta(filename)");
        $db->exec("CREATE INDEX IF NOT EXISTS idx_media_meta_external ON media_meta(is_external)");
        CollectionDatabase::ensureSchema();
    }

    /**
     * Migration: the `slot_relations` reverse index used by the relation system.
     *
     * IMPORTANT: this table is a DERIVED INDEX. Relation values are stored in the
     * item JSON (`slots.data`), which is the single source of truth; this table is
     * rebuilt from it on every save by RelationService::syncRelations(). It only
     * exists to answer reverse questions cheaply ("which slots point at me?") for
     * cascade cache invalidation.
     *
     * Because it is derived, it is always safe to drop and rebuild — which is what
     * happens when a pre-UID layout (integer source_id/target_id) is detected.
     *
     * Safe to call repeatedly on existing databases.
     */
    public static function ensureRelationSchema(?\PDO $db = null): void
    {
        $db = $db ?? self::getInstance();

        try {
            // Detect and discard the pre-UID layout. Item identity is a string
            // UID (`_dndId`), so integer columns cannot represent the index.
            //
            // NOTE: every statement is fully consumed / closed before the DDL runs.
            // An open cursor keeps a read lock on the connection and SQLite would
            // reject the DROP with "database table is locked".
            $needsRebuild = false;
            $exists = false;

            $stmt = $db->query("SELECT name FROM sqlite_master WHERE type='table' AND name='slot_relations'");
            if ($stmt) {
                $exists = (bool) $stmt->fetchAll(\PDO::FETCH_COLUMN, 0);
                $stmt->closeCursor();
            }

            if ($exists) {
                $cols = [];
                $info = $db->query("PRAGMA table_info(slot_relations)");
                if ($info) {
                    foreach ($info->fetchAll(\PDO::FETCH_ASSOC) as $col) {
                        $cols[] = $col['name'] ?? '';
                    }
                    $info->closeCursor();
                }
                $needsRebuild = !in_array('source_uid', $cols, true)
                    || !in_array('target_uid', $cols, true);
            }

            if ($needsRebuild) {
                $db->exec("DROP TABLE IF EXISTS slot_relations");
                error_log("[ContentDatabase] Rebuilt slot_relations for UID-based item identity");
            }

            $db->exec("
                CREATE TABLE IF NOT EXISTS slot_relations (
                    id          INTEGER PRIMARY KEY AUTOINCREMENT,
                    source_key  TEXT NOT NULL,
                    source_uid  TEXT NOT NULL,
                    target_key  TEXT NOT NULL,
                    target_uid  TEXT NOT NULL,
                    field_id    TEXT NOT NULL,
                    sort_order  INTEGER DEFAULT 0,
                    created_at  TEXT DEFAULT CURRENT_TIMESTAMP
                )
            ");
            $db->exec("CREATE INDEX IF NOT EXISTS idx_relations_source ON slot_relations(source_key, source_uid, field_id)");
            $db->exec("CREATE INDEX IF NOT EXISTS idx_relations_target ON slot_relations(target_key, target_uid)");
            $db->exec("CREATE INDEX IF NOT EXISTS idx_relations_filter ON slot_relations(source_key, field_id, target_key, target_uid, source_uid)");
        } catch (\Throwable $e) {
            error_log("[ContentDatabase] ensureRelationSchema failed: " . $e->getMessage());
        }
    }
    
    /**
     * Compute content hash for optimistic locking
     * Uses SHA-256 for collision resistance
     */
    public static function computeContentHash(mixed $data): string
    {
        $json = json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        return hash('sha256', $json);
    }

    /**
     * Automatikus séma-migráció a media_meta táblához (meglévő adatbázisokon is lefut)
     */
    public static function ensureMediaMetaSchema(?\PDO $db = null): void
    {
        $db = $db ?? self::getInstance();
        try {
            // Tábla létrehozása ha nem létezne
            $db->exec("
                CREATE TABLE IF NOT EXISTS media_meta (
                    filename TEXT PRIMARY KEY,
                    alt_texts TEXT DEFAULT '{}',
                    title TEXT DEFAULT '',
                    caption TEXT DEFAULT '',
                    tags TEXT DEFAULT '[]',
                    is_external INTEGER DEFAULT 0,
                    media_type TEXT DEFAULT 'image',
                    dimensions TEXT DEFAULT NULL,
                    mime_type TEXT DEFAULT NULL,
                    updated_at TEXT DEFAULT CURRENT_TIMESTAMP
                )
            ");

            // Meglévő oszlopok lekérdezése
            $stmt = $db->query("PRAGMA table_info(media_meta)");
            $cols = [];
            if ($stmt) {
                while ($col = $stmt->fetch(\PDO::FETCH_ASSOC)) {
                    if (!empty($col['name'])) {
                        $cols[] = $col['name'];
                    }
                }
            }

            // Hiányzó oszlopok hozzáadása a meglévő táblához
            if (!in_array('is_external', $cols, true)) {
                $db->exec("ALTER TABLE media_meta ADD COLUMN is_external INTEGER DEFAULT 0");
            }
            if (!in_array('media_type', $cols, true)) {
                $db->exec("ALTER TABLE media_meta ADD COLUMN media_type TEXT DEFAULT 'image'");
            }
            if (!in_array('dimensions', $cols, true)) {
                $db->exec("ALTER TABLE media_meta ADD COLUMN dimensions TEXT DEFAULT NULL");
            }
            if (!in_array('mime_type', $cols, true)) {
                $db->exec("ALTER TABLE media_meta ADD COLUMN mime_type TEXT DEFAULT NULL");
            }
            // Extended RBAC: track who uploaded/registered each media item, so
            // 'media:read:own' / 'media:delete:own' can filter to the current
            // user's own uploads (ABAC 'own' scope support, mirrors slot_ownership).
            if (!in_array('uploaded_by', $cols, true)) {
                $db->exec("ALTER TABLE media_meta ADD COLUMN uploaded_by TEXT DEFAULT NULL");
            }

            $db->exec("CREATE INDEX IF NOT EXISTS idx_media_meta_filename ON media_meta(filename)");
            $db->exec("CREATE INDEX IF NOT EXISTS idx_media_meta_external ON media_meta(is_external)");
            $db->exec("CREATE INDEX IF NOT EXISTS idx_media_meta_uploaded_by ON media_meta(uploaded_by)");
        } catch (\Throwable $e) {
            // Migrációs hiba elnyelése
        }
    }
    
    /**
     * Get data from a slot
     * 
     * SECURITY: Validates JSON decoding and logs errors
     */
    public static function getSlot(string $key): mixed
    {
        \NomadCMS\Services\Schema\SchemaProvider::lease($key);
        $db = self::getInstance();
        if (CollectionDatabase::isRegistered($key)) return CollectionDatabase::exportAll($key);
        $stmt = $db->prepare("SELECT data FROM slots WHERE key = ?");
        $stmt->execute([$key]);
        $row = $stmt->fetch();
        
        if ($row) {
            $decoded = json_decode($row['data'], true);
            
            // Check for JSON decode errors
            if ($decoded === null && $row['data'] !== 'null') {
                $error = json_last_error_msg();
                error_log("[ContentDatabase] JSON decode failed for slot '{$key}': {$error}");
                error_log("[ContentDatabase] Raw data (first 500 chars): " . substr($row['data'], 0, 500));
                // Return null but don't throw - allows graceful handling
            }
            
            return $decoded;
        }
        
        return null;
    }

    /**
     * Get lightweight metadata and item counts for a set of slot keys
     *
     * Ultra-fast: uses SQLite length(), json_type() and json_array_length() without decoding
     * large payloads into PHP memory.
     *
     * @param array<string> $keys
     * @return array<string, array{count: int, size: int, exists: bool, type: string}>
     */
    public static function getSlotSummaries(array $keys): array
    {
        if (empty($keys)) {
            return [];
        }

        $db = self::getInstance();
        $placeholders = implode(',', array_fill(0, count($keys), '?'));
        
        $sql = "
            SELECT 
                key,
                length(data) as size,
                json_type(data) as json_type,
                CASE 
                    WHEN json_valid(data) AND json_type(data) = 'array' THEN json_array_length(data)
                    WHEN json_valid(data) AND json_type(data) = 'object' THEN 1
                    ELSE 0
                END as item_count
            FROM slots 
            WHERE key IN ($placeholders)
        ";

        $stmt = $db->prepare($sql);
        $stmt->execute(array_values($keys));
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $results = [];
        foreach ($rows as $row) {
            $results[$row['key']] = [
                'count' => (int)($row['item_count'] ?? 0),
                'size' => (int)($row['size'] ?? 0),
                'exists' => true,
                'type' => $row['json_type'] === 'array' ? 'list' : 'object',
            ];
        }

        // Fill in missing keys
        foreach ($keys as $k) {
            if ($state = CollectionDatabase::state($k)) {
                $results[$k] = ['count' => (int)$state['item_count'], 'size' => 0, 'exists' => true, 'type' => 'collection'];
            }
            if (!isset($results[$k])) {
                $results[$k] = [
                    'count' => 0,
                    'size' => 0,
                    'exists' => false,
                    'type' => 'unknown',
                ];
            }
        }

        return $results;
    }

    /**
     * Get slot with version AND hash info for optimistic locking
     * 
     * ENTERPRISE OPTIMISTIC LOCKING:
     * - 'version' = sequential number (can be reset if history pruned)
     * - 'hash' = SHA-256 of content (TRUE content identity)
     * 
     * Use 'expected_hash' for robust locking (recommended)
     * Use 'expected_version' for simpler locking (may fail on history prune)
     * 
     * @param string $key Slot key
     * @return array{data: mixed, version: int, hash: string}|null
     */
    public static function getSlotWithVersion(string $key): ?array
    {
        \NomadCMS\Services\Schema\SchemaProvider::lease($key);
        $db = self::getInstance();
        if ($state = CollectionDatabase::state($key)) {
            $data = CollectionDatabase::exportAll($key);
            return ['data' => $data, 'version' => (int)$state['revision'], 'hash' => self::computeContentHash($data)];
        }
        $stmt = $db->prepare("SELECT data FROM slots WHERE key = ?");
        $stmt->execute([$key]);
        $row = $stmt->fetch();
        
        if (!$row) {
            return null;
        }
        
        $decoded = json_decode($row['data'], true);
        
        // Compute content hash for optimistic locking
        $contentHash = self::computeContentHash($decoded);
        
        // Get current version from versioning service
        try {
            $versioning = VersioningService::getInstance();
            $version = $versioning->getVersionCount($key);
        } catch (\Exception $e) {
            $version = 0;
        }
        
        return [
            'data' => $decoded,
            'version' => $version,
            'hash' => $contentHash  // SHA-256 for TRUE content identity
        ];
    }

    /**
     * Save data to a slot WITH AUTOMATIC VERSIONING AND OPTIMISTIC LOCKING
     * 
     * ARCHITECTURE: This is the SINGLE SOURCE OF TRUTH for content saves.
     * Versioning is GUARANTEED at the database layer, not opt-in.
     * 
     * ENTERPRISE OPTIMISTIC LOCKING (2026-01-05):
     * Two locking strategies available (hash recommended):
     * 
     * 1. HASH-BASED (recommended): Pass 'expected_hash' - compares SHA-256 of content
     *    - TRUE content identity check
     *    - Works even if version history is pruned
     *    - Detects ANY content change
     * 
     * 2. VERSION-BASED (simpler): Pass 'expected_version' - compares version number
     *    - May fail if version history is pruned/reset
     *    - Simpler to implement on client side
     * 
     * @param string $key Slot key
     * @param mixed $data Data to save
     * @param array $options Optional settings:
     *   - 'expected_hash' => string - SHA-256 hash for robust locking (RECOMMENDED)
     *   - 'expected_version' => int - Version number for simple locking
     *   - 'skip_versioning' => bool - Skip versioning (for system operations)
     *   - 'changed_by' => string - User identifier for version history
     *   - 'slot_type' => string - Slot type (object, list, collection, etc.)
     *   - 'force_version' => bool - Force versioning even for skipped types
     *   - 'bypass_lock' => bool - DANGER: Skip optimistic lock check (for migrations only)
     *   - 'precomputed_version' => array - Precomputed version data from WASM (offloads server)
     * @return bool Success status
     * 
     * @throws OptimisticLockException If expected hash/version doesn't match current
     * @security Validates JSON encoding to prevent data loss
     */
    public static function saveSlot(string $key, mixed $data, array $options = []): bool
    {
        $result = self::saveSlotInternal($key, $data, $options);
        return $result['success'];
    }

    /**
     * Internal implementation of saveSlot() that also returns versioning
     * outcome details (version_created, skip_reason, version_type) instead
     * of discarding them. saveSlot() keeps its original bool signature for
     * backward compatibility with every existing caller; saveSlotWithResult()
     * uses this method directly so the API response can surface WHETHER a
     * new version was actually created (needed for the shadow/commit UX -
     * a semantically-empty edit still saves the content, but shouldn't look
     * like it produced a new history entry when it didn't).
     *
     * @return array{success: bool, version_created: bool, skip_reason: ?string, version: ?int, version_type: ?string}
     */
    private static function saveSlotInternal(string $key, mixed $data, array $options = []): array
    {
        \NomadCMS\Services\Schema\SchemaProvider::assertWritable($key);
        \NomadCMS\Services\Schema\SchemaProvider::invalidateIndexes($key);
        $db = self::getInstance();
        $schemaType = \NomadCMS\Services\RelationService::getSlotType($key);
        if (CollectionDatabase::isRegistered($key) || $schemaType === 'collection' || ($schemaType===null && ($options['slot_type'] ?? null) === 'collection')) {
            if (!is_array($data)) throw new \InvalidArgumentException('Collection must be a list');
            return CollectionDatabase::replaceAll($key, $data, $options);
        }
        
        if (\NomadCMS\Services\Schema\SchemaProvider::initialized()) {
            $old = self::getSlot($key);
            if ($schemaType === 'object' && is_array($data)) {
                $data = \NomadCMS\Services\Schema\SchemaProvider::validateWrite($key, $data, is_array($old) ? $old : null, empty($options['replace']));
            } elseif ($schemaType === 'list' && is_array($data)) {
                $oldItems = is_array($old) ? array_column($old, null, '_dndId') : [];
                foreach ($data as $index => $item) {
                    if (!is_array($item)) {
                        throw new \InvalidArgumentException('List items must be objects.', 422);
                    }
                    $previous = isset($item['_dndId']) ? ($oldItems[$item['_dndId']] ?? null) : null;
                    $data[$index] = \NomadCMS\Services\Schema\SchemaProvider::validateWrite($key, $item, $previous);
                }
            } else {
                throw new \InvalidArgumentException('Slot shape must follow the active schema.', 422);
            }
        }

        // JSON encode with flags for proper Unicode handling
        $json = json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE);
        
        // CRITICAL: Check if JSON encoding failed
        if ($json === false) {
            $error = json_last_error_msg();
            error_log("[ContentDatabase] JSON encode failed for slot '{$key}': {$error}");
            throw new \RuntimeException("Failed to encode data as JSON: {$error}");
        }
        
        // Verify it's not empty (defensive check)
        if (empty($json) || $json === 'null') {
            error_log("[ContentDatabase] Warning: Saving null/empty data to slot '{$key}'");
        }
        
        // Extract options
        $skipVersioning = $options['skip_versioning'] ?? false;
        $forceVersion = $options['force_version'] ?? false;
        $slotType = $options['slot_type'] ?? null;
        $changedBy = $options['changed_by'] ?? 'system';
        $ownerUuid = $options['owner_uuid'] ?? null;
        $expectedVersion = $options['expected_version'] ?? null;
        $expectedHash = $options['expected_hash'] ?? null;
        $bypassLock = $options['bypass_lock'] ?? false;
        $precomputedVersion = $options['precomputed_version'] ?? null;
        
        // Skip versioning for certain slot types unless forced
        if (!$forceVersion && $slotType && in_array($slotType, self::SKIP_VERSIONING_TYPES, true)) {
            $skipVersioning = true;
        }
        
        // Start transaction FIRST (fix for transaction gap bug)
        $nested = $db->inTransaction();
        $savepoint = 'slot_' . bin2hex(random_bytes(6));
        if ($nested) { $db->exec('SAVEPOINT ' . $savepoint); }
        else { $db->beginTransaction(); }
        $transactionFinished = false;
        $rollback = static function () use ($db, $nested, $savepoint, &$transactionFinished): void {
            if ($transactionFinished) { return; }
            if ($nested) { $db->exec('ROLLBACK TO SAVEPOINT ' . $savepoint); $db->exec('RELEASE SAVEPOINT ' . $savepoint); }
            elseif ($db->inTransaction()) { $db->rollBack(); }
            $transactionFinished = true;
        };
        
        try {
            // Get existing data INSIDE transaction for proper isolation
            $existingData = null;
            $currentVersion = 0;
            $currentHash = null;
            
            if (!$skipVersioning || $expectedHash !== null) {
                try {
                    $existingData = self::getSlot($key);
                    if ($existingData !== null) {
                        $currentHash = self::computeContentHash($existingData);
                    }
                    $versioning = VersioningService::getInstance();
                    $currentVersion = $versioning->getVersionCount($key);
                } catch (\Exception $e) {
                    error_log("[ContentDatabase] Failed to get existing data for versioning: " . $e->getMessage());
                }
            }
            
            // ═══════════════════════════════════════════════════════════════
            // OPTIMISTIC LOCKING CHECK - Prevents "Lost Update" bug
            // Priority: hash-based > version-based (hash is more robust)
            // ═══════════════════════════════════════════════════════════════
            if (!$bypassLock) {
                // HASH-BASED LOCKING (RECOMMENDED - TRUE content identity)
                if ($expectedHash !== null) {
                    if ($currentHash === null && !empty($options['require_existing'])) {
                        $rollback();
                        throw new OptimisticLockException(slotKey: $key, expectedHash: $expectedHash, actualHash: null, lockType: 'hash');
                    }
                    // For new content, current hash is null
                    if ($currentHash !== null && !hash_equals($expectedHash, $currentHash)) {
                        $rollback();
                        throw new OptimisticLockException(
                            slotKey: $key,
                            expectedHash: $expectedHash,
                            actualHash: $currentHash,
                            lockType: 'hash'
                        );
                    }
                }
                // VERSION-BASED LOCKING (FALLBACK - simpler but less robust)
                elseif ($expectedVersion !== null) {
                    if ($currentVersion !== $expectedVersion) {
                        $rollback();
                        throw new OptimisticLockException(
                            slotKey: $key,
                            expectedVersion: $expectedVersion,
                            actualVersion: $currentVersion,
                            lockType: 'version'
                        );
                    }
                }
            }
            
            // Save the slot data
            $stmt = $db->prepare("
                INSERT OR REPLACE INTO slots (key, data, updated_at) 
                VALUES (?, ?, datetime('now'))
            ");
            
            $saveResult = $stmt->execute([$key, $json]);
            
            if (!$saveResult) {
                throw new \RuntimeException("Failed to save slot data");
            }
            \NomadCMS\Services\Seo\SeoModule::changed($db, $key);
            if (is_array($data) && \NomadCMS\Services\Schema\SchemaProvider::initialized()) {
                $items = $schemaType === 'list' ? $data : [$data];
                foreach ($items as $item) {
                    $uid = $item['_dndId'] ?? '__self__';
                    $previous = $schemaType === 'list' ? ($oldItems[$uid] ?? null) : (is_array($old) ? $old : null);
                    \NomadCMS\Services\Schema\SchemaValues::record($db, $key, $uid, $item, $previous);
                }
            }
            \NomadCMS\Services\RelationService::syncRelations($key, $data);
            CollectionDatabase::enqueueDependents($key);
            
            // Sync inverted media usages index for this slot
            try {
                \NomadCMS\Services\MediaService::syncSlotMediaUsages($key, $json, $db);
            } catch (\Throwable $e) {
                error_log("[ContentDatabase] Media usages sync warning for '{$key}': " . $e->getMessage());
            }
            
            // RBAC/ABAC: Record ownership (first-writer-wins, non-blocking on failure)
            if ($ownerUuid) {
                try {
                    self::recordOwnership($key, $slotType, $data, $ownerUuid, $db);
                } catch (\Exception $e) {
                    error_log("[ContentDatabase] Ownership recording failed for '{$key}': " . $e->getMessage());
                }
            }
            
            // Create version if versioning is enabled and not skipped
            // OR if forceVersion is set (e.g., single object explicit save with create_version flag)
            $newVersion = $currentVersion;
            $shouldCreateVersion = !$skipVersioning || $forceVersion;
            
            $versionCreated = false;
            $skipReason = null;
            $versionType = null;
            
            if ($shouldCreateVersion) {
                try {
                    $versioning = VersioningService::getInstance();
                    if ($versioning->isEnabled()) {
                        // Pass precomputed version data if available (WASM optimization)
                        // version_intent controls shadow (autosave) vs commit (explicit save) -
                        // see VersioningSettings/Task 7 for the intent -> version_type mapping.
                        $versionIntent = $options['version_intent'] ?? 'manual';
                        $intentOptions = self::resolveVersionIntentOptions($versionIntent, $versioning);
                        
                        $versionResult = $versioning->createVersion(
                            $key,
                            $existingData,
                            $data,
                            $changedBy,
                            $precomputedVersion,  // Client-side precomputed data
                            $intentOptions
                        );
                        
                        if ($versionResult['success']) {
                            $versionCreated = $versionResult['version_created'] ?? (($versionResult['version'] ?? null) !== null);
                            $skipReason = $versionResult['skip_reason'] ?? null;
                            $versionType = $versionResult['version_type'] ?? null;
                            if ($versionCreated) {
                                $newVersion = $versionResult['version'] ?? ($currentVersion + 1);
                            }
                        } elseif (!($versionResult['skipped'] ?? false)) {
                            error_log("[ContentDatabase] Version creation warning for '{$key}': " . ($versionResult['error'] ?? 'unknown'));
                        }
                    }
                } catch (\Exception $e) {
                    error_log("[ContentDatabase] Versioning error for '{$key}': " . $e->getMessage());
                    // Don't fail the save, versioning is non-blocking
                }
            }
            
            if ($nested) { $db->exec('RELEASE SAVEPOINT ' . $savepoint); }
            else { $db->commit(); }
            $transactionFinished = true;
            \NomadCMS\Services\Seo\SeoModule::afterCommit($db);
            if (!($options['defer_effects'] ?? $nested)) {
                \NomadCMS\Services\SitemapService::markDirty();
            }
            return [
                'success' => true,
                'version_created' => $versionCreated,
                'skip_reason' => $skipReason,
                'version' => $newVersion,
                'version_type' => $versionType,
            ];
            
        } catch (OptimisticLockException $e) {
            // Re-throw lock exceptions (already rolled back above)
            $rollback();
            throw $e;
        } catch (\Throwable $e) {
            $rollback();
            error_log("[ContentDatabase] Transaction failed for '{$key}': " . $e->getMessage());
            throw $e;
        }
    }
    
    /**
     * Map a version_intent ('auto'|'manual'|'system') to VersionCreator options.
     *
     * - 'manual' (default): explicit user save -> permanent 'commit' version,
     *   no debounce. This is the pre-existing behavior for every caller that
     *   doesn't pass version_intent, so default-changing nothing retroactively.
     * - 'auto': editor autosave -> 'shadow' version, debounced within the
     *   configured window (merges rapid keystroke-driven saves into one row).
     * - 'system': programmatic writers (webhooks, Forge import, relation
     *   cascade saves, mapping executor) -> same as 'manual' (commit, no
     *   debounce) so their version history is unaffected by this feature.
     */
    private static function resolveVersionIntentOptions(string $versionIntent, VersioningService $versioning): array
    {
        if ($versionIntent === 'auto') {
            $settings = $versioning->getSettings();
            return [
                'version_type' => \NomadCMS\Services\Versioning\VersionRepository::TYPE_SHADOW,
                'debounce' => true,
                'debounce_window' => $settings->getDebounceWindowSeconds(),
            ];
        }
        
        // 'manual' and 'system' (and any unrecognized value) behave identically:
        // permanent commit version, no debounce.
        return ['version_type' => 'commit', 'debounce' => false];
    }
    
    /**
     * Save slot and return version + hash for API responses
     * 
     * ENTERPRISE RESPONSE:
     * Returns both version and hash for client-side optimistic locking, plus
     * versioning outcome details so callers (and the frontend) can tell a
     * genuine save with a new history entry apart from a semantically-empty
     * save that still updated the content but created no version.
     * 
     * @return array{success: bool, version: int, hash: string, version_created?: bool, skip_reason?: ?string, version_type?: ?string, error?: string}
     */
    public static function saveSlotWithResult(string $key, mixed $data, array $options = []): array
    {
        try {
            $internalResult = self::saveSlotInternal($key, $data, $options);
            
            // Compute new hash for optimistic locking
            $newHash = self::computeContentHash($data);
            
            // Prefer the version number returned directly by the save (reflects
            // the ACTUAL row touched, including shadow versions which
            // getVersionCount() excludes by default) - fall back to a fresh
            // count only if that's somehow unavailable.
            $newVersion = $internalResult['version'];
            if ($newVersion === null) {
                $versioning = VersioningService::getInstance();
                $newVersion = $versioning->getVersionCount($key);
            }
            
            return [
                'success' => true,
                'version' => $newVersion,
                'hash' => $newHash,  // For next save's optimistic lock
                'version_created' => $internalResult['version_created'],
                'skip_reason' => $internalResult['skip_reason'],
                'version_type' => $internalResult['version_type'],
            ];
        } catch (OptimisticLockException $e) {
            return [
                'success' => false,
                'error' => 'CONFLICT',
                'lock_type' => $e->lockType,
                'message' => $e->getMessage(),
                'expected_version' => $e->expectedVersion,
                'actual_version' => $e->actualVersion,
                'expected_hash' => $e->expectedHash,
                'actual_hash' => $e->actualHash
            ];
        } catch (\Exception $e) {
            return [
                'success' => false,
                'error' => $e->getMessage()
            ];
        }
    }

    /**
     * Delete a slot
     */
    public static function deleteSlot(string $key): bool
    {
        \NomadCMS\Services\Schema\SchemaProvider::assertWritable($key);
        \NomadCMS\Services\Schema\SchemaProvider::invalidateIndexes($key);
        $db = self::getInstance();
        if (CollectionDatabase::isRegistered($key)) {
            CollectionDatabase::transaction(function(PDO $db) use($key) {
                CollectionDatabase::replaceAll($key, []);
                $db->prepare('DELETE FROM collection_slots WHERE slot_key=?')->execute([$key]);
                $db->prepare('DELETE FROM collection_jobs WHERE slot_key=?')->execute([$key]);
                $db->prepare('DELETE FROM collection_dirty_items WHERE slot_key=?')->execute([$key]);
                $db->prepare('DELETE FROM collection_cache_entries WHERE slot_key=?')->execute([$key]);
                $db->prepare('DELETE FROM slots WHERE key=?')->execute([$key]);
            });
            \NomadCMS\Services\StaticCacheService::invalidateSlot($key);
            \NomadCMS\Services\SitemapService::markDirty();
            return true;
        }
        $result = \NomadCMS\Services\Seo\Support::transaction($db, static function () use ($db, $key): bool {
            $stmt = $db->prepare("DELETE FROM slots WHERE key = ?");
            $deleted = $stmt->execute([$key]);
            \NomadCMS\Services\Seo\SeoModule::changed($db, $key);
            return $deleted;
        });
        \NomadCMS\Services\Seo\SeoModule::afterCommit($db);
        if ($result) {
            \NomadCMS\Services\MediaService::deleteSlotMediaUsages($key, $db);
            \NomadCMS\Services\SitemapService::markDirty();
        }
        return $result;
    }

    // =========================================================================
    // Extended RBAC: Slot / Item Ownership (ABAC 'own' scope support)
    // =========================================================================

    /**
     * Record ownership for a slot (object-type) or its items (list/collection-type).
     *
     * Policy: FIRST-WRITER-WINS. Uses INSERT OR IGNORE so an existing ownership
     * record is never overwritten by a later save from a different user.
     *
     * - object slots: single row with item_uid = NULL
     * - list/collection slots: one row per item, keyed by the item's `_dndId`
     *   (items without a `_dndId` are skipped - they have no stable identity yet)
     */
    private static function recordOwnership(string $slotKey, ?string $slotType, mixed $data, string $ownerUuid, PDO $db): void
    {
        $stmt = $db->prepare("
            INSERT OR IGNORE INTO slot_ownership (slot_key, item_uid, owner_uuid)
            VALUES (?, ?, ?)
        ");

        // Determine whether this payload should be treated as a list of items
        // (item-level ownership) or a single object (slot-level ownership).
        //
        // BUG-FIX: `is_array($data)` is ALWAYS true for decoded JSON payloads
        // (both JSON objects and JSON arrays decode to PHP arrays), so it can't
        // be used to distinguish "object slot" from "list slot". Instead:
        // - if slot_type explicitly says list/collection, honor that
        // - otherwise, only treat it as a list if it's actually a sequential
        //   array (array_is_list) - an object-type slot's data is an
        //   associative array and must never fall into the item-level branch.
        $isListLike = in_array($slotType, ['list', 'collection'], true)
            || (is_array($data) && array_is_list($data) && $slotType === null);

        if ($isListLike && is_array($data)) {
            foreach ($data as $item) {
                if (is_array($item) && !empty($item['_dndId']) && is_string($item['_dndId'])) {
                    $stmt->execute([$slotKey, $item['_dndId'], $ownerUuid]);
                }
            }
            return;
        }

        // Object-type slot (or list type but non-array payload): slot-level ownership
        $stmt->execute([$slotKey, null, $ownerUuid]);
    }

    /**
     * Get the owner UUID for a slot (object-level) or a specific item within a
     * list/collection slot.
     *
     * @param string $slotKey Slot key
     * @param string|null $itemUid Item `_dndId` for list/collection slots, null for object slots
     * @return string|null Owner UUID, or null if no ownership record exists
     */
    public static function getOwner(string $slotKey, ?string $itemUid = null): ?string
    {
        $db = self::getInstance();

        $stmt = $db->prepare(
            $itemUid === null
                ? "SELECT owner_uuid FROM slot_ownership WHERE slot_key = ? AND item_uid IS NULL"
                : "SELECT owner_uuid FROM slot_ownership WHERE slot_key = ? AND item_uid = ?"
        );

        if ($itemUid === null) {
            $stmt->execute([$slotKey]);
        } else {
            $stmt->execute([$slotKey, $itemUid]);
        }

        $row = $stmt->fetch();
        return $row ? $row['owner_uuid'] : null;
    }

    /**
     * Check whether the given user UUID owns a slot (or specific item within it).
     *
     * If no ownership record exists at all (legacy data created before this
     * feature existed), ownership checks are permissive by default - callers
     * relying on 'own' scope enforcement should treat "no record" as handled
     * by RBACService (which falls back to role-level rules).
     */
    public static function isOwnedBy(string $slotKey, string $userUuid, ?string $itemUid = null): bool
    {
        $owner = self::getOwner($slotKey, $itemUid);
        return $owner !== null && hash_equals($owner, $userUuid);
    }

    /**
     * Get all ownership records for a slot (list/collection: multiple rows).
     *
     * @return array<int, array{item_uid: string|null, owner_uuid: string}>
     */
    public static function getSlotOwnership(string $slotKey): array
    {
        $db = self::getInstance();
        $stmt = $db->prepare("SELECT item_uid, owner_uuid FROM slot_ownership WHERE slot_key = ?");
        $stmt->execute([$slotKey]);
        return $stmt->fetchAll();
    }

    /**
     * Get all slot keys
     */
    public static function getAllSlots(): array
    {
        $db = self::getInstance();
        $stmt = $db->query("SELECT key, updated_at FROM slots ORDER BY key");
        return $stmt->fetchAll();
    }

    /**
     * Get metadata for a specific media file
     */
    public static function getMediaMeta(string $filename): array
    {
        $db = self::getInstance();
        $filename = \NomadCMS\Services\MediaAliasService::resolve($filename, $db);
        self::ensureMediaMetaSchema($db);
        $stmt = $db->prepare("SELECT * FROM media_meta WHERE filename = ?");
        $stmt->execute([$filename]);
        $row = $stmt->fetch();

        if ($row) {
            return [
                'filename' => $row['filename'],
                'alt' => json_decode($row['alt_texts'] ?? '{}', true) ?: [],
                'title' => $row['title'] ?? '',
                'caption' => $row['caption'] ?? '',
                'tags' => json_decode($row['tags'] ?? '[]', true) ?: [],
                'is_external' => (int)($row['is_external'] ?? 0),
                'media_type' => $row['media_type'] ?? 'image',
                'dimensions' => json_decode($row['dimensions'] ?? 'null', true),
                'mime_type' => $row['mime_type'] ?? null,
                'uploaded_by' => $row['uploaded_by'] ?? null,
                'updated_at' => $row['updated_at']
            ];
        }

        return [
            'filename' => $filename,
            'alt' => [],
            'title' => '',
            'caption' => '',
            'tags' => [],
            'is_external' => (str_starts_with($filename, 'http://') || str_starts_with($filename, 'https://')) ? 1 : 0,
            'media_type' => 'image',
            'dimensions' => null,
            'mime_type' => null,
            'uploaded_by' => null,
            'updated_at' => null
        ];
    }

    /**
     * Get all media metadata indexed by filename
     */
    public static function getAllMediaMeta(): array
    {
        $db = self::getInstance();
        self::ensureMediaMetaSchema($db);
        $stmt = $db->query("SELECT * FROM media_meta");
        $rows = $stmt->fetchAll();

        $metaMap = [];
        foreach ($rows as $row) {
            $metaMap[$row['filename']] = [
                'alt' => json_decode($row['alt_texts'] ?? '{}', true) ?: [],
                'title' => $row['title'] ?? '',
                'caption' => $row['caption'] ?? '',
                'tags' => json_decode($row['tags'] ?? '[]', true) ?: [],
                'is_external' => (int)($row['is_external'] ?? 0),
                'media_type' => $row['media_type'] ?? 'image',
                'dimensions' => json_decode($row['dimensions'] ?? 'null', true),
                'mime_type' => $row['mime_type'] ?? null,
                'uploaded_by' => $row['uploaded_by'] ?? null,
                'updated_at' => $row['updated_at']
            ];
        }

        return $metaMap;
    }

    /**
     * Get all external (CDN) media items
     */
    public static function getAllExternalMedia(): array
    {
        $db = self::getInstance();
        self::ensureMediaMetaSchema($db);

        try {
            $stmt = $db->query("SELECT * FROM media_meta WHERE is_external = 1 ORDER BY updated_at DESC");
            if (!$stmt) {
                return [];
            }
            $rows = $stmt->fetchAll(\PDO::FETCH_ASSOC);

            $items = [];
            foreach ($rows as $row) {
                $items[] = [
                    'filename' => $row['filename'],
                    'url' => $row['filename'],
                    'alt' => json_decode($row['alt_texts'] ?? '{}', true) ?: [],
                    'title' => $row['title'] ?? '',
                    'caption' => $row['caption'] ?? '',
                    'tags' => json_decode($row['tags'] ?? '[]', true) ?: [],
                    'is_external' => 1,
                    'media_type' => $row['media_type'] ?? 'image',
                    'dimensions' => json_decode($row['dimensions'] ?? 'null', true),
                    'mime_type' => $row['mime_type'] ?? null,
                    'uploaded_by' => $row['uploaded_by'] ?? null,
                    'updated_at' => $row['updated_at'] ?? date('c')
                ];
            }

            return $items;
        } catch (\Throwable $e) {
            return [];
        }
    }

    /**
     * Check whether a media_meta row actually EXISTS for a filename / URL.
     *
     * This is deliberately separate from getMediaMeta(), which never returns
     * null - for an unknown filename it synthesises a default row (empty alt/
     * title/tags, uploaded_by = null) so callers can render a media item
     * without special-casing missing metadata. That makes getMediaMeta()
     * unusable for answering "does this item exist yet?", which authorisation
     * code needs in order to tell a CREATE (registering a new external/CDN
     * item) apart from an UPDATE (editing an existing item's metadata) - the
     * two require different permissions.
     */
    public static function mediaMetaExists(string $filename): bool
    {
        $db = self::getInstance();
        self::ensureMediaMetaSchema($db);

        try {
            $stmt = $db->prepare("SELECT 1 FROM media_meta WHERE filename = ? LIMIT 1");
            $stmt->execute([$filename]);
            return $stmt->fetchColumn() !== false;
        } catch (\Throwable $e) {
            // Fail-closed for authorisation purposes: if we cannot confirm the
            // row is absent, treat it as existing so the stricter UPDATE path
            // (ownership required) applies rather than the CREATE path.
            return true;
        }
    }

    /**
     * Delete media meta by filename / URL
     */
    public static function deleteMediaMeta(string $filename): bool
    {
        $db = self::getInstance();
        self::ensureMediaMetaSchema($db);
        if (\NomadCMS\Services\Seo\SeoModule::mediaUsages($db, $filename) !== []) {
            return false;
        }

        try {
            $stmt = $db->prepare("DELETE FROM media_meta WHERE filename = ?");
            return $stmt->execute([$filename]);
        } catch (\Throwable $e) {
            return false;
        }
    }

    /**
     * Save/upsert metadata for a media file (including multi-language ALT texts and external CDN info)
     *
     * @param string|null $uploadedBy Owner UUID (ABAC 'own' scope). FIRST-WRITER-WINS:
     *                                 once set, later saves never overwrite it (mirrors
     *                                 slot_ownership policy), so re-registering/updating an
     *                                 existing file's metadata can't reassign ownership.
     */
    public static function saveMediaMeta(
        string $filename,
        array $altTexts,
        ?string $title = null,
        ?string $caption = null,
        ?array $tags = null,
        ?int $isExternal = null,
        ?string $mediaType = null,
        ?array $dimensions = null,
        ?string $mimeType = null,
        ?string $uploadedBy = null
    ): bool {
        $db = self::getInstance();
        self::ensureMediaMetaSchema($db);

        $existing = self::getMediaMeta($filename);
        $mergedAlt = array_merge($existing['alt'] ?? [], $altTexts);

        $finalTitle = $title !== null ? $title : ($existing['title'] ?? '');
        $finalCaption = $caption !== null ? $caption : ($existing['caption'] ?? '');
        $finalTags = $tags !== null ? $tags : ($existing['tags'] ?? []);

        $finalIsExternal = $isExternal !== null
            ? $isExternal
            : (!empty($existing['is_external']) || str_starts_with($filename, 'http://') || str_starts_with($filename, 'https://') ? 1 : 0);

        $finalMediaType = $mediaType !== null ? $mediaType : ($existing['media_type'] ?? 'image');
        $finalDimensions = $dimensions !== null
            ? json_encode($dimensions, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)
            : (!empty($existing['dimensions']) ? json_encode($existing['dimensions'], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) : null);
        $finalMimeType = $mimeType !== null ? $mimeType : ($existing['mime_type'] ?? null);
        // First-writer-wins: keep the existing owner if one is already recorded.
        $finalUploadedBy = $existing['uploaded_by'] ?? $uploadedBy;

        $nowIso = date('c');

        try {
            $stmt = $db->prepare("
                INSERT INTO media_meta (filename, alt_texts, title, caption, tags, is_external, media_type, dimensions, mime_type, uploaded_by, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(filename) DO UPDATE SET
                    alt_texts = excluded.alt_texts,
                    title = excluded.title,
                    caption = excluded.caption,
                    tags = excluded.tags,
                    is_external = excluded.is_external,
                    media_type = excluded.media_type,
                    dimensions = excluded.dimensions,
                    mime_type = excluded.mime_type,
                    uploaded_by = excluded.uploaded_by,
                    updated_at = excluded.updated_at
            ");

            return $stmt->execute([
                $filename,
                json_encode($mergedAlt, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
                $finalTitle,
                $finalCaption,
                json_encode($finalTags, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
                $finalIsExternal,
                $finalMediaType,
                $finalDimensions,
                $finalMimeType,
                $finalUploadedBy,
                $nowIso
            ]);
        } catch (\Throwable $e) {
            error_log("[ContentDatabase::saveMediaMeta] Error: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Close database connection
     */
    public static function close(): void
    {
        self::$instance = null;
    }
}
