<?php
/**
 * NOMAD CMS - User Repository
 * Database operations for users
 */

declare(strict_types=1);

namespace NomadCMS\Database;

use NomadCMS\Config\Security;
use NomadCMS\Security\EncryptionService;
use Ramsey\Uuid\Uuid;

final class UserRepository
{
    // RBAC Role constants
    public const ROLE_ADMIN = 'admin';
    public const ROLE_EDITOR = 'editor';
    public const ROLE_VIEWER = 'viewer';
    
    /**
     * Create new user
     *
     * @param string|null $password Plaintext password, or NULL to create a
     *        PASSWORDLESS account. Passwordless users are created by the
     *        magic-link invitation flow: they have no password_hash at all and
     *        can only get in by redeeming their invitation link, where they set
     *        their own password. This way the admin never knows the user's password.
     * @param string $role Role: admin, editor, or viewer (default: viewer, or admin if isAdmin)
     * @param string|null $firstName Given name (optional at install time, required via the admin panel)
     * @param string|null $lastName Family name
     */
    public static function create(
        string $email,
        ?string $password,
        bool $isAdmin = false,
        bool $isNewUser = true,
        ?string $role = null,
        ?string $firstName = null,
        ?string $lastName = null
    ): ?array {
        $db = AuthDatabase::getInstance();
        if ($isAdmin && self::count() > 0) {
            \NomadCMS\Services\Schema\SchemaAccess::requireDelegator();
        }
        
        // Check if email already exists
        $stmt = $db->prepare("SELECT id FROM users WHERE email = ?");
        $stmt->execute([$email]);
        
        if ($stmt->fetch()) {
            throw new \Exception('Email already registered');
        }
        
        // Determine role - explicit role takes precedence, otherwise derive from isAdmin
        $userRole = $role ?? ($isAdmin ? self::ROLE_ADMIN : self::ROLE_VIEWER);
        
        // Generate UUID and hash password with pepper.
        // A null password means "no password at all" (magic-link onboarding),
        // NOT "empty password" - password_hash stays NULL so verifyPassword()
        // can never succeed for this account.
        $uuid = str_replace('-', '', Uuid::uuid4()->toString());
        $passwordHash = $password === null ? null : self::hashPassword($password);
        
        $stmt = $db->prepare("
            INSERT INTO users (uuid, email, password_hash, is_admin, is_new_user, role, first_name, last_name)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ");
        
        $params = [
            $uuid,
            $email,
            $passwordHash,
            $isAdmin ? 1 : 0,
            $isNewUser ? 1 : 0,
            $userRole,
            $firstName,
            $lastName,
        ];
        
        if ($stmt->execute($params)) {
            return self::findById((int) $db->lastInsertId());
        }
        
        return null;
    }
    
    /**
     * Hash password with pepper
     */
    public static function hashPassword(string $password): string
    {
        $pepper = Security::getPasswordPepper();
        $saltPrefix = Security::getSaltPrefix();
        
        // Combine password with pepper before hashing
        $pepperedPassword = hash_hmac('sha256', $password, $pepper);
        
        return password_hash(
            $saltPrefix . $pepperedPassword,
            PASSWORD_ARGON2ID,
            Security::getPasswordOptions()
        );
    }
    
    /**
     * Verify user password with pepper
     * 
     * DISASTER RECOVERY: If standard verification fails, tries legacy pepper
     * and auto-migrates password to new pepper on successful legacy verification
     */
    public static function verifyPassword(array $user, string $password): bool
    {
        if (empty($user['password_hash']) || !is_string($user['password_hash'])) {
            return false;
        }
        $pepper = Security::getPasswordPepper();
        $saltPrefix = Security::getSaltPrefix();
        
        // Apply same pepper transformation
        $pepperedPassword = hash_hmac('sha256', $password, $pepper);
        
        // Try standard verification first
        if (password_verify($saltPrefix . $pepperedPassword, $user['password_hash'])) {
            return true;
        }
        
        // DISASTER RECOVERY: Try legacy pepper if exists
        $legacyPepper = \NomadCMS\Services\RecoveryService::getLegacyPepper();
        if ($legacyPepper) {
            $legacyPepperedPassword = hash_hmac('sha256', $password, $legacyPepper);
            
            if (password_verify($saltPrefix . $legacyPepperedPassword, $user['password_hash'])) {
                // Auto-migrate: Rehash with new pepper
                $newHash = self::hashPassword($password);
                $db = AuthDatabase::getInstance();
                $stmt = $db->prepare("UPDATE users SET password_hash = ?, updated_at = datetime('now') WHERE id = ?");
                $stmt->execute([$newHash, $user['id']]);
                
                error_log("Password migrated for user ID: {$user['id']} (legacy pepper to current)");
                return true;
            }
        }
        
        return false;
    }
    
    /**
     * Find user by ID
     */
    public static function findById(int $id): ?array
    {
        $db = AuthDatabase::getInstance();
        $stmt = $db->prepare("SELECT * FROM users WHERE id = ?");
        $stmt->execute([$id]);
        
        return $stmt->fetch() ?: null;
    }
    
    /**
     * Find user by UUID
     */
    public static function findByUuid(string $uuid): ?array
    {
        $db = AuthDatabase::getInstance();
        $stmt = $db->prepare("SELECT * FROM users WHERE uuid = ?");
        $stmt->execute([$uuid]);
        
        return $stmt->fetch() ?: null;
    }
    
    /**
     * Find user by email
     */
    public static function findByEmail(string $email): ?array
    {
        $db = AuthDatabase::getInstance();
        $stmt = $db->prepare("SELECT * FROM users WHERE email = ?");
        $stmt->execute([$email]);
        
        return $stmt->fetch() ?: null;
    }
    
    /**
     * Get decrypted TOTP secret for a user
     * Returns null if TOTP is not enabled or decryption fails
     */
    public static function getTotpSecret(array $user): ?string
    {
        if (empty($user['totp_secret']) || !$user['totp_enabled']) {
            return null;
        }
        
        $secret = $user['totp_secret'];
        
        // Check if already encrypted (Defuse format starts with "def")
        if (EncryptionService::isEncrypted($secret)) {
            try {
                return EncryptionService::decrypt($secret);
            } catch (\Exception $e) {
                // Log error but don't expose details
                error_log('TOTP decryption failed for user ID: ' . ($user['id'] ?? 'unknown'));
                return null;
            }
        }
        
        // Legacy: plaintext secret (migrate on next enable)
        return $secret;
    }
    
    /**
     * Update password
     */
    public static function updatePassword(int $userId, string $newPassword): bool
    {
        $db = AuthDatabase::getInstance();
        $hash = self::hashPassword($newPassword);
        
        return \NomadCMS\Auth\AuthTransaction::run(function ($db) use ($hash, $userId): bool {
            $stmt = $db->prepare("UPDATE users SET password_hash = ?, is_new_user = 0, updated_at = datetime('now') WHERE id = ?");
            $result = $stmt->execute([$hash, $userId]);
            \NomadCMS\Auth\AuthSessionService::revokeUser($userId);
            return $result;
        });
    }
    
    /**
     * Enable TOTP for user
     * Secret is encrypted at rest using ENCRYPTION_KEY
     */
    public static function enableTotp(int $userId, string $secret, ?string $algorithm = null, int $lastStep = -1): bool
    {
        $db = AuthDatabase::getInstance();
        
        // Encrypt TOTP secret at rest
        $encryptedSecret = EncryptionService::encrypt($secret);
        
        $stmt = $db->prepare("
            UPDATE users 
            SET totp_secret = ?, totp_enabled = 1, totp_algorithm = ?, totp_last_step = ?, updated_at = datetime('now')
            WHERE id = ?
        ");
        
        return $stmt->execute([$encryptedSecret, $algorithm ?? Security::getTotpConfig()['algorithm'], $lastStep, $userId]);
    }
    
    /**
     * Disable TOTP for user
     */
    public static function disableTotp(int $userId): bool
    {
        $db = AuthDatabase::getInstance();
        
        $stmt = $db->prepare("
            UPDATE users 
            SET totp_secret = NULL, totp_enabled = 0, backup_codes = NULL, totp_last_step = -1, updated_at = datetime('now')
            WHERE id = ?
        ");
        
        return $stmt->execute([$userId]);
    }
    
    /**
     * Record failed login attempt with dynamic lock settings
     */
    public static function recordFailedLogin(int $userId): void
    {
        $db = AuthDatabase::getInstance();
        $lockSettings = Security::getAccountLockSettings();
        
        $stmt = $db->prepare("
            UPDATE users 
            SET failed_login_attempts = failed_login_attempts + 1
            WHERE id = ?
        ");
        $stmt->execute([$userId]);
        
        // Check if should lock account
        $user = self::findById($userId);
        if ($user && $user['failed_login_attempts'] >= $lockSettings['max_attempts']) {
            $lockUntil = date('Y-m-d H:i:s', time() + $lockSettings['lock_duration']);
            $stmt = $db->prepare("UPDATE users SET locked_until = ? WHERE id = ?");
            $stmt->execute([$lockUntil, $userId]);
        }
    }
    
    /**
     * Reset failed login attempts (on successful login)
     */
    public static function resetFailedLogins(int $userId): void
    {
        $db = AuthDatabase::getInstance();
        
        $stmt = $db->prepare("
            UPDATE users 
            SET failed_login_attempts = 0, locked_until = NULL, last_login_at = datetime('now')
            WHERE id = ?
        ");
        $stmt->execute([$userId]);
    }
    
    /**
     * Check if account is locked
     */
    public static function isLocked(array $user): bool
    {
        if (empty($user['locked_until'])) {
            return false;
        }
        
        return strtotime($user['locked_until']) > time();
    }
    
    /**
     * Get remaining lockout time in seconds
     * Returns 0 if not locked
     */
    public static function getLockoutRemaining(array $user): int
    {
        if (empty($user['locked_until'])) {
            return 0;
        }
        
        $lockUntil = strtotime($user['locked_until']);
        $remaining = $lockUntil - time();
        
        return max(0, $remaining);
    }
    
    /**
     * Log login attempt (for security audit)
     */
    public static function logLoginAttempt(string $email, bool $success, ?string $reason = null): void
    {
        $db = AuthDatabase::getInstance();
        
        $stmt = $db->prepare("
            INSERT INTO login_attempts (email, ip_address, user_agent, success, failure_reason)
            VALUES (?, ?, ?, ?, ?)
        ");
        
        $stmt->execute([
            $email,
            $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0',
            substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 500),
            $success ? 1 : 0,
            $reason,
        ]);
    }
    
    // ==========================================
    // USER-LEVEL AUTH SETTINGS
    // ==========================================
    
    /**
     * Update user's auth method preferences
     * Allows each user to enable/disable their own auth methods
     */
    public static function updateAuthSettings(int $userId, array $settings): bool
    {
        $db = AuthDatabase::getInstance();
        $user = self::findById($userId);
        $future = array_replace($user, $settings);
        $passwordAvailable = self::canUsePassword($future) && !empty($future['password_hash'])
            && (empty($future['totp_enabled']) || self::canUseTotp($future));
        $credentials = $db->prepare('SELECT 1 FROM webauthn_credentials WHERE user_id=? LIMIT 1');
        $credentials->execute([$userId]);
        $passkeyAvailable = self::canUseWebAuthn($future) && $credentials->fetchColumn();
        if (!$passwordAvailable && !$passkeyAvailable) {
            throw new \NomadCMS\Auth\AuthException('LAST_AUTH_METHOD', 'At least one working login method is required.', 400);
        }
        
        $allowed = ['totp_allowed', 'webauthn_allowed', 'password_allowed'];
        $updates = [];
        $params = [];
        
        foreach ($allowed as $field) {
            if (isset($settings[$field])) {
                $updates[] = "$field = ?";
                $params[] = $settings[$field] ? 1 : 0;
            }
        }
        
        if (empty($updates)) {
            return false;
        }
        
        $params[] = $userId;
        $sql = "UPDATE users SET " . implode(', ', $updates) . ", updated_at = datetime('now') WHERE id = ?";
        
        return $db->prepare($sql)->execute($params);
    }
    
    /**
     * Save backup codes for user (hashed)
     */
    public static function setBackupCodes(int $userId, array $hashedCodes): bool
    {
        $db = AuthDatabase::getInstance();
        
        $codesJson = json_encode($hashedCodes);
        
        $stmt = $db->prepare("UPDATE users SET backup_codes = ?, updated_at = datetime('now') WHERE id = ?");
        return $stmt->execute([$codesJson, $userId]);
    }
    
    /**
     * Get user's backup codes
     */
    public static function getBackupCodes(int $userId): array
    {
        $user = self::findById($userId);
        
        if (!$user || empty($user['backup_codes'])) {
            return [];
        }
        
        return json_decode($user['backup_codes'], true) ?? [];
    }
    
    /**
     * Verify and consume a backup code
     */
    public static function verifyBackupCode(int $userId, string $code): bool
    {
        $user = self::findById($userId);
        if (!$user || empty($user['totp_enabled']) || !is_string($user['backup_codes'])
            || !preg_match('/^[A-F0-9]{8}$/iD', $code)) {
            return false;
        }
        $snapshot = $user['backup_codes'];
        $codes = json_decode($snapshot, true);
        if (!is_array($codes) || count($codes) > 10) {
            return false;
        }
        
        foreach ($codes as $index => $hashedCode) {
            if (is_string($hashedCode) && password_verify(strtoupper($code), $hashedCode)) {
                // Remove used code
                unset($codes[$index]);
                $stmt = AuthDatabase::getInstance()->prepare("UPDATE users SET backup_codes=?,updated_at=datetime('now') WHERE id=? AND backup_codes=? AND totp_enabled=1");
                $stmt->execute([json_encode(array_values($codes)), $userId, $snapshot]);
                return $stmt->rowCount() === 1;
            }
        }
        
        return false;
    }
    
    /**
     * Update user's email address
     */
    public static function updateEmail(int $userId, string $newEmail): bool
    {
        $db = AuthDatabase::getInstance();
        
        $stmt = $db->prepare("UPDATE users SET email = ?, updated_at = datetime('now') WHERE id = ?");
        return $stmt->execute([$newEmail, $userId]);
    }
    
    /**
     * Set recovery email for user
     */
    public static function setRecoveryEmail(int $userId, ?string $email): bool
    {
        $db = AuthDatabase::getInstance();
        
        $stmt = $db->prepare("UPDATE users SET recovery_email = ?, updated_at = datetime('now') WHERE id = ?");
        return $stmt->execute([$email, $userId]);
    }
    
    /**
     * Check if user can use TOTP (respects user-level AND global settings)
     */
    public static function canUseTotp(array $user): bool
    {
        // Check global setting first
        if (!Security::isFeatureEnabled('totp')) {
            return false;
        }
        
        // Then check user-level permission
        return (bool) ($user['totp_allowed'] ?? true);
    }
    
    /**
     * Check if user can use WebAuthn (respects user-level AND global settings)
     */
    public static function canUseWebAuthn(array $user): bool
    {
        // Check global setting first
        if (!Security::isFeatureEnabled('webauthn')) {
            return false;
        }
        
        // Then check user-level permission
        return (bool) ($user['webauthn_allowed'] ?? true);
    }
    
    /**
     * Check if user can use password auth (respects user-level AND global settings)
     */
    public static function canUsePassword(array $user): bool
    {
        // Check global setting first
        if (!Security::isFeatureEnabled('password')) {
            return false;
        }
        
        // Then check user-level permission
        return (bool) ($user['password_allowed'] ?? true);
    }
    
    /**
     * Get available auth methods for a user
     */
    public static function getAvailableAuthMethods(array $user): array
    {
        $methods = [];
        
        if (self::canUsePassword($user) && !empty($user['password_hash'])) {
            $methods[] = 'password';
        }
        
        if (self::canUseTotp($user) && !empty($user['totp_enabled'])) {
            $methods[] = 'totp';
        }
        
        if (self::canUseWebAuthn($user)) {
            // Check if user has any webauthn credentials
            $db = AuthDatabase::getInstance();
            $stmt = $db->prepare("SELECT COUNT(*) FROM webauthn_credentials WHERE user_id = ?");
            $stmt->execute([$user['id']]);
            
            if ($stmt->fetchColumn() > 0) {
                $methods[] = 'webauthn';
            }
        }
        
        return $methods;
    }
    
    /**
     * Count total registered users
     */
    public static function count(): int
    {
        $db = AuthDatabase::getInstance();
        return (int) $db->query("SELECT COUNT(*) FROM users")->fetchColumn();
    }

    /**
     * Find ALL users (for Admin dashboard)
     */
    public static function findAll(): array
    {
        $db = AuthDatabase::getInstance();
        $stmt = $db->query("
            SELECT 
                id, uuid, email, first_name, last_name, is_admin, role_slug,
                created_at, updated_at, last_login_at,
                failed_login_attempts, locked_until,
                totp_enabled, is_new_user,
                (password_hash IS NOT NULL) AS has_password
            FROM users 
            ORDER BY created_at DESC
        ");
        
        return $stmt->fetchAll();
    }

    /**
     * Find all users assigned to a given role_slug (for the RolesPage user list).
     * Excludes sensitive fields (password_hash, totp_secret, backup_codes).
     */
    public static function findByRoleSlug(string $roleSlug): array
    {
        $db = AuthDatabase::getInstance();
        $stmt = $db->prepare("
            SELECT 
                id, uuid, email, first_name, last_name, is_admin, role_slug,
                created_at, last_login_at, locked_until
            FROM users 
            WHERE role_slug = ?
            ORDER BY email ASC
        ");
        $stmt->execute([$roleSlug]);

        return $stmt->fetchAll();
    }

    /**
     * Update user details
     * 
     * Uses strict whitelist approach for SQL injection prevention:
     * - Only predefined field names are allowed
     * - All values go through prepared statements
     * - Input is pre-sanitized by InputSanitizer
     */
    public static function update(int $id, array $data): bool
    {
        $before = self::findById($id);
        if (array_key_exists('is_admin', $data) && (bool) ($before['is_admin'] ?? false) !== (bool) $data['is_admin']) {
            \NomadCMS\Services\Schema\SchemaAccess::requireDelegator();
        }
        $db = AuthDatabase::getInstance();
        
        // WHITELIST: Only these fields can be updated
        // This prevents any SQL injection through field names
        $allowedFields = [
            'email' => 'email = ?',
            'is_admin' => 'is_admin = ?',
            'password' => 'password_hash = ?',
            'first_name' => 'first_name = ?',
            'last_name' => 'last_name = ?',
        ];
        
        $fields = [];
        $params = [];
        
        foreach ($allowedFields as $dataKey => $sqlFragment) {
            if (!isset($data[$dataKey])) {
                continue;
            }
            
            switch ($dataKey) {
                case 'email':
                    // Email should already be sanitized, but double-check
                    $email = filter_var($data['email'], FILTER_VALIDATE_EMAIL);
                    if ($email) {
                        $fields[] = $sqlFragment;
                        $params[] = $email;
                    }
                    break;
                    
                case 'is_admin':
                    $fields[] = $sqlFragment;
                    $params[] = $data['is_admin'] ? 1 : 0;
                    break;
                    
                case 'password':
                    if (!empty($data['password']) && is_string($data['password'])) {
                        $fields[] = $sqlFragment;
                        $params[] = self::hashPassword($data['password']);
                    }
                    break;
                    
                case 'first_name':
                case 'last_name':
                    // Already sanitized by InputSanitizer::personName().
                    // An empty string is normalized to NULL so "cleared" reads
                    // consistently everywhere (name-or-email fallbacks).
                    $value = is_string($data[$dataKey]) ? trim($data[$dataKey]) : null;
                    $fields[] = $sqlFragment;
                    $params[] = ($value === null || $value === '') ? null : $value;
                    break;
            }
        }
        
        if (empty($fields)) {
            return false;
        }
        
        if (isset($data['password']) && is_string($data['password']) && $data['password'] !== '') {
            $fields[] = 'auth_version = auth_version + 1';
        }

        // Add updated_at - this is safe as it's hardcoded
        $fields[] = "updated_at = datetime('now')";
        
        // Build SQL with only whitelisted field names
        $sql = "UPDATE users SET " . implode(', ', $fields) . " WHERE id = ?";
        $params[] = $id;
        
        return $db->prepare($sql)->execute($params);
    }

    /**
     * Delete user
     */
    public static function delete(int $id): bool
    {
        $before = self::findById($id);
        \NomadCMS\Services\Schema\SchemaAccess::protectAssignment($before ? RoleRepository::getUserRole($before) : null, null);
        $db = AuthDatabase::getInstance();
        $stmt = $db->prepare("DELETE FROM users WHERE id = ?");
        return $stmt->execute([$id]);
    }

    /**
     * Lock or Unlock user (Deactivate/Activate)
     */
    public static function toggleLock(int $id, bool $lock): bool
    {
        $db = AuthDatabase::getInstance();
        
        if ($lock) {
            // Lock for 100 years (effectively permanent)
            $lockedUntil = date('Y-m-d H:i:s', strtotime('+100 years'));
            $sql = "UPDATE users SET locked_until = ? WHERE id = ?";
            return $db->prepare($sql)->execute([$lockedUntil, $id]);
        } else {
            // Unlock
            $sql = "UPDATE users SET locked_until = NULL, failed_login_attempts = 0 WHERE id = ?";
            return $db->prepare($sql)->execute([$id]);
        }
    }
}

