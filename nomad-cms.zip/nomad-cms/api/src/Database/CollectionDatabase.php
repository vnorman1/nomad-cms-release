<?php
/**
 * NOMAD CMS - Collection Database Engine
 * High-performance, relational row-backed storage engine for massive collections
 * 
 * Architecture & Features:
 * - Row-backed collection storage eliminating monolithic JSON bottlenecks
 * - O(1) B-tree lookup by unique (slot_key, item_uid) covering index
 * - TOAST-like content separation: Gutenberg blocks moved to collection_blocks
 * - Lightweight metadata and fast pagination (LIMIT/OFFSET & Keyset iteration)
 * - Full-Text Search integration via SQLite FTS5 with diacritics removal
 * - Two-tier optimistic locking: slot schema revision & item revision
 * - Isolated nested transactions using SQLite SAVEPOINTs
 * - Granular versioning with HMAC-SHA256 signature verification
 * - Sentinel-backed compatibility with legacy ContentDatabase
 * 
 * Storage:
 * - collection_slots: Schema definitions, revisions, item counts
 * - collection_items: Core metadata, slugs, publish flags, positions
 * - collection_blocks: Heavy Gutenberg/blocks data per locale
 * - collection_fts: FTS5 virtual table for full-text search
 * - collection_item_versions: Immutable version history
 */

declare(strict_types=1);

namespace NomadCMS\Database;

use PDO;
use NomadCMS\Services\RelationService;
use NomadCMS\Services\PublicPayloadService;
use NomadCMS\Services\Versioning\VersionRepository;
use NomadCMS\Services\Versioning\VersioningSettings;

final class CollectionDatabase
{
    public const SENTINEL = '{"__storage":"collection_rows"}';
    private const SEARCH_PROFILE = 'collection-search/v1';
    private const MAX_PRECOMPUTED_SEARCH_BYTES = 262144;
    private static ?PDO $schemaConnection = null;
    private static ?PDO $versioningSettingsConnection = null;
    private static bool $useSystemVersioningSettings = true;

    public static function getInstance(): PDO
    {
        return ContentDatabase::getInstance();
    }

    public static function ensureSchema(?PDO $db = null): void
    {
        $usesInjectedConnection = $db !== null;
        $db ??= self::getInstance();
        if (\NomadCMS\Security\PanicModeService::isReadOnlyRequest()) {
            self::$schemaConnection = $db;
            return;
        }
        if ($usesInjectedConnection) {
            self::$versioningSettingsConnection = $db;
            self::$useSystemVersioningSettings = false;
        } elseif (self::$versioningSettingsConnection === null) {
            self::$useSystemVersioningSettings = true;
        }
        $migrateHistoryReferences = !$db->query("SELECT 1 FROM sqlite_master WHERE type='table' AND name='collection_history_block_refs'")->fetchColumn();
        $db->exec("CREATE TABLE IF NOT EXISTS collection_slots (
            slot_key TEXT PRIMARY KEY COLLATE BINARY, schema_json TEXT NOT NULL,
            schema_hash TEXT NOT NULL, revision INTEGER NOT NULL DEFAULT 0,
            item_count INTEGER NOT NULL DEFAULT 0, created_at TEXT NOT NULL, updated_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS collection_items (
            row_id INTEGER PRIMARY KEY, slot_key TEXT NOT NULL REFERENCES collection_slots(slot_key) ON DELETE CASCADE,
            item_uid TEXT NOT NULL COLLATE BINARY, position INTEGER NOT NULL, data TEXT NOT NULL,
            content_hash TEXT NOT NULL, public_hash TEXT NOT NULL DEFAULT '', search_source_hash TEXT NOT NULL DEFAULT '', slug TEXT, business_id TEXT, published INTEGER NOT NULL,
            owner_uuid TEXT, revision INTEGER NOT NULL DEFAULT 1,
            created_at TEXT NOT NULL, updated_at TEXT NOT NULL, public_updated_at TEXT NOT NULL,
            UNIQUE(slot_key,item_uid)
        );
        CREATE INDEX IF NOT EXISTS idx_collection_created ON collection_items(slot_key,created_at DESC,row_id DESC);
        CREATE INDEX IF NOT EXISTS idx_collection_owner_created ON collection_items(slot_key,owner_uuid,created_at DESC,row_id DESC);
        CREATE INDEX IF NOT EXISTS idx_collection_published_created ON collection_items(slot_key,published,created_at DESC,row_id DESC);
        CREATE INDEX IF NOT EXISTS idx_collection_order ON collection_items(slot_key,position,row_id);
        CREATE INDEX IF NOT EXISTS idx_collection_row_id ON collection_items(slot_key,row_id);
        CREATE INDEX IF NOT EXISTS idx_collection_slug ON collection_items(slot_key,slug);
        CREATE INDEX IF NOT EXISTS idx_collection_business ON collection_items(slot_key,business_id);
        CREATE INDEX IF NOT EXISTS idx_collection_public ON collection_items(slot_key,published,position,row_id);
        CREATE INDEX IF NOT EXISTS idx_collection_owner ON collection_items(slot_key,owner_uuid,position,row_id);
        CREATE TABLE IF NOT EXISTS collection_blocks (
            item_row_id INTEGER NOT NULL REFERENCES collection_items(row_id) ON DELETE CASCADE,
            field_id TEXT NOT NULL, locale TEXT NOT NULL DEFAULT '', data TEXT NOT NULL,
            PRIMARY KEY(item_row_id,field_id,locale)
        );
        CREATE TABLE IF NOT EXISTS collection_item_versions (
            id INTEGER PRIMARY KEY, slot_key TEXT NOT NULL, item_uid TEXT NOT NULL,
            revision INTEGER NOT NULL, operation TEXT NOT NULL, schema_hash TEXT NOT NULL,
            data TEXT NOT NULL, content_hash TEXT NOT NULL, signature TEXT NOT NULL,
            changed_by TEXT NOT NULL, created_at TEXT NOT NULL,
            change_summary TEXT NOT NULL DEFAULT '', item_label TEXT NOT NULL DEFAULT '',
            version_type TEXT NOT NULL DEFAULT 'commit', version_name TEXT
        );
        CREATE TABLE IF NOT EXISTS collection_history_blocks(hash TEXT PRIMARY KEY,data TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS collection_history_block_refs (
            history_id INTEGER NOT NULL REFERENCES collection_item_versions(id) ON DELETE CASCADE,
            hash TEXT NOT NULL REFERENCES collection_history_blocks(hash),
            PRIMARY KEY(history_id,hash)
        );
        CREATE INDEX IF NOT EXISTS idx_collection_history_block_hash ON collection_history_block_refs(hash);
        CREATE INDEX IF NOT EXISTS idx_collection_history ON collection_item_versions(slot_key,item_uid,id);
        CREATE INDEX IF NOT EXISTS idx_collection_history_feed ON collection_item_versions(slot_key,id DESC);
        CREATE TABLE IF NOT EXISTS collection_media_usages (
            slot_key TEXT NOT NULL, item_uid TEXT NOT NULL, field_id TEXT NOT NULL,
            media_ref TEXT NOT NULL, count INTEGER NOT NULL,
            PRIMARY KEY(slot_key,item_uid,field_id,media_ref)
        );
        CREATE INDEX IF NOT EXISTS idx_collection_media_ref ON collection_media_usages(media_ref,slot_key,item_uid);
        CREATE TABLE IF NOT EXISTS collection_jobs (
            slot_key TEXT PRIMARY KEY, revision INTEGER NOT NULL, queued_at TEXT NOT NULL,
            attempts INTEGER NOT NULL DEFAULT 0, last_error TEXT
        );
        CREATE TABLE IF NOT EXISTS collection_webhook_outbox (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            event_id TEXT NOT NULL UNIQUE,
            slot_key TEXT NOT NULL,
            events TEXT NOT NULL,
            payload TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS collection_dirty_items (
            slot_key TEXT NOT NULL,item_uid TEXT NOT NULL,PRIMARY KEY(slot_key,item_uid)
        );
        CREATE TABLE IF NOT EXISTS collection_cache_entries (
            slot_key TEXT NOT NULL,item_uid TEXT NOT NULL,identifier TEXT NOT NULL,
            chunk_id INTEGER NOT NULL,entry_json TEXT NOT NULL,item_hash TEXT NOT NULL,
            PRIMARY KEY(slot_key,item_uid),UNIQUE(slot_key,identifier)
        );
        CREATE INDEX IF NOT EXISTS idx_collection_cache_chunk ON collection_cache_entries(slot_key,chunk_id);
        CREATE TABLE IF NOT EXISTS collection_identifiers (
            slot_key TEXT NOT NULL,value TEXT NOT NULL,item_row_id INTEGER NOT NULL REFERENCES collection_items(row_id) ON DELETE CASCADE,
            kind TEXT NOT NULL,locale TEXT NOT NULL DEFAULT '',PRIMARY KEY(slot_key,value,item_row_id,kind,locale)
        );
        CREATE INDEX IF NOT EXISTS idx_collection_identifier ON collection_identifiers(slot_key,value);
        CREATE TABLE IF NOT EXISTS collection_migration_archives (
            slot_key TEXT PRIMARY KEY, data TEXT NOT NULL, checksum TEXT NOT NULL,
            migrated_at TEXT NOT NULL, source_updated_at TEXT
        );
        CREATE TABLE IF NOT EXISTS collection_schema_versions (
            schema_hash TEXT PRIMARY KEY, schema_json TEXT NOT NULL, created_at TEXT NOT NULL
        )");
        \NomadCMS\Services\WebhookQueuePolicy::ensureSchema($db, 'collection_webhook_outbox');
        // Failing here is intentional: a partially installed search engine must not accept writes.
        $db->exec(
            "CREATE VIRTUAL TABLE IF NOT EXISTS collection_fts USING fts5(text, tokenize='unicode61 remove_diacritics 2', prefix='2 3')"
        );
        $itemColumns = $db->query('PRAGMA table_info(collection_items)')->fetchAll(PDO::FETCH_COLUMN, 1);
        if (!in_array('search_source_hash', $itemColumns, true)) {
            $db->exec("ALTER TABLE collection_items ADD COLUMN search_source_hash TEXT NOT NULL DEFAULT ''");
        }
        $columns=$db->query('PRAGMA table_info(collection_item_versions)')->fetchAll(PDO::FETCH_COLUMN,1);
        foreach (['change_summary'=>"TEXT NOT NULL DEFAULT ''",'item_label'=>"TEXT NOT NULL DEFAULT ''",'version_type'=>"TEXT NOT NULL DEFAULT 'commit'",'version_name'=>'TEXT'] as $column=>$type) if (!in_array($column,$columns,true)) $db->exec("ALTER TABLE collection_item_versions ADD COLUMN $column $type");
        if ($migrateHistoryReferences) {
            $db->exec("INSERT OR IGNORE INTO collection_history_block_refs(history_id,hash)
                SELECT v.id,json_extract(b.value,'$.hash') FROM collection_item_versions v,json_each(v.data,'$.blocks') b");
        }
        self::$schemaConnection = $db;
    }

    /** Return system settings in production, or the injected test database when explicitly configured. */
    public static function getVersioningSettings(): VersioningSettings
    {
        if (!self::$useSystemVersioningSettings && self::$versioningSettingsConnection !== null) {
            return new VersioningSettings(self::$versioningSettingsConnection);
        }
        return new VersioningSettings();
    }

    /**
     * Enforce the shared per-slot version cap on collection snapshots atomically.
     * Only blocks referenced by pruned snapshots are considered for reclamation.
     *
     * @param string $key Collection slot key.
     * @param int|null $maximum Override used by the shared settings/cleanup workflow.
     * @param PDO|null $db Explicit connection for shared versioning service/test instances.
     * @return int Number of removed historical snapshots.
     */
    public static function enforceHistoryLimit(string $key, ?int $maximum = null, ?PDO $db = null): int
    {
        return self::transaction(function (PDO $db) use ($key, $maximum): int {
            $maximum ??= self::getVersioningSettings()->getMaxVersions();
            $boundary = $db->prepare('SELECT id FROM collection_item_versions WHERE slot_key=? ORDER BY id DESC LIMIT 1 OFFSET ?');
            $boundary->bindValue(1, $key);
            $boundary->bindValue(2, max(0, $maximum), PDO::PARAM_INT);
            $boundary->execute();
            $lastToRemove = $boundary->fetchColumn();
            $boundary->closeCursor();
            if ($lastToRemove === false) return 0;

            $db->exec('CREATE TEMP TABLE IF NOT EXISTS collection_pruned_block_hashes(hash TEXT PRIMARY KEY)');
            $db->exec('DELETE FROM collection_pruned_block_hashes');
            $db->prepare('INSERT OR IGNORE INTO collection_pruned_block_hashes(hash)
                SELECT r.hash FROM collection_history_block_refs r JOIN collection_item_versions v ON v.id=r.history_id
                WHERE v.slot_key=? AND v.id<=?')->execute([$key, $lastToRemove]);
            $delete = $db->prepare('DELETE FROM collection_item_versions WHERE slot_key=? AND id<=?');
            $delete->execute([$key, $lastToRemove]);
            $deleted = $delete->rowCount();
            $db->exec('DELETE FROM collection_history_blocks WHERE hash IN (SELECT hash FROM collection_pruned_block_hashes)
                AND NOT EXISTS(SELECT 1 FROM collection_history_block_refs r WHERE r.hash=collection_history_blocks.hash)');
            $db->exec('DELETE FROM collection_pruned_block_hashes');
            return $deleted;
        }, $db);
    }

    /**
     * Apply the current shared version limit to every registered collection.
     *
     * @param PDO|null $db Explicit connection for shared versioning service/test instances.
     * @return array{deleted: int, slots_processed: int} Cleanup totals for the settings UI.
     */
    public static function enforceAllHistoryLimits(?PDO $db = null): array
    {
        $db ??= self::getInstance();
        if (!$db->query("SELECT 1 FROM sqlite_master WHERE type='table' AND name='collection_slots'")->fetchColumn()) {
            return ['deleted' => 0, 'slots_processed' => 0];
        }
        if (self::$schemaConnection !== $db) self::ensureSchema($db);
        $maximum = self::getVersioningSettings()->getMaxVersions();
        $keys = $db->query('SELECT slot_key FROM collection_slots')->fetchAll(PDO::FETCH_COLUMN);
        $deleted = 0;
        foreach ($keys as $key) $deleted += self::enforceHistoryLimit($key, $maximum, $db);
        return ['deleted' => $deleted, 'slots_processed' => count($keys)];
    }

    private static function json(mixed $value): string
    {
        return json_encode(
            $value,
            JSON_THROW_ON_ERROR |
                JSON_UNESCAPED_UNICODE |
                JSON_UNESCAPED_SLASHES
        );
    }

    private static function now(): string
    {
        return gmdate("Y-m-d\TH:i:s\Z");
    }

    private static function canonical(mixed $value): mixed
    {
        if (!is_array($value)) {
            return $value;
        }
        foreach ($value as &$child) {
            $child = self::canonical($child);
        }
        unset($child);
        if (!array_is_list($value)) {
            ksort($value);
        }
        return $value;
    }

    private static function publicHash(
        string $key,
        array $item,
        array $definition
    ): string {
        $public = PublicPayloadService::isItemPublished($definition, $item)
            ? PublicPayloadService::projectSlot(
                $key,
                RelationService::projectForPublic($key, $item)
            )
            : null;
        return hash("sha256", self::json(self::canonical($public)));
    }

    /** Savepoints make bulk import/restore atomic without nesting PDO transactions. */
    public static function transaction(callable $work, ?PDO $db = null): mixed
    {
        $db ??= self::getInstance();
        $nested = $db->inTransaction();
        $point = "collection_" . bin2hex(random_bytes(6));
        if ($nested) {
            $db->exec("SAVEPOINT $point");
        } else {
            $db->beginTransaction();
        }
        try {
            // Acquire the write lock before reading revisions.
            $db->exec("UPDATE collection_slots SET revision=revision WHERE 0");
            $result = $work($db);
            if ($nested) {
                $db->exec("RELEASE SAVEPOINT $point");
            } else {
                $db->commit();
                \NomadCMS\Services\Seo\SeoModule::afterCommit($db);
            }
            return $result;
        } catch (\Throwable $e) {
            if ($nested) {
                $db->exec("ROLLBACK TO SAVEPOINT $point");
                $db->exec("RELEASE SAVEPOINT $point");
            } elseif ($db->inTransaction()) {
                $db->rollBack();
            }
            throw $e;
        }
    }

    public static function isRegistered(string $key): bool
    {
        $db = self::getInstance();
        if (self::$schemaConnection !== $db || \NomadCMS\Security\PanicModeService::isReadOnlyRequest()) {
            if (
                !$db
                    ->query(
                        "SELECT 1 FROM sqlite_master WHERE type='table' AND name='collection_slots'"
                    )
                    ->fetchColumn()
            ) {
                return false;
            }
        }
        $s = self::getInstance()->prepare(
            "SELECT 1 FROM collection_slots WHERE slot_key=?"
        );
        $s->execute([$key]);
        return (bool) $s->fetchColumn();
    }

    /** Identify empty collections without reading or converting populated legacy blobs. */
    public static function canInitializeEmpty(string $key): bool
    {
        if ((\NomadCMS\Services\Schema\SchemaProvider::slot($key)['type'] ?? null) !== 'collection') {
            return false;
        }
        $query = self::getInstance()->prepare("SELECT 1 FROM slots WHERE key=? AND data NOT IN ('[]','null') LIMIT 1");
        $query->execute([$key]);
        return $query->fetchColumn() === false;
    }

    /** Allocate row-backed storage only for an empty, authoritative collection. */
    public static function initializeEmpty(string $key): void
    {
        \NomadCMS\Services\Schema\SchemaProvider::assertWritable($key);
        $definition = \NomadCMS\Services\Schema\SchemaProvider::slot($key);
        if (($definition['type'] ?? null) !== 'collection') {
            throw new \InvalidArgumentException('Active collection schema required', 422);
        }
        self::ensureSchema();
        self::transaction(function (PDO $db) use ($key, $definition): void {
            if (self::isRegistered($key)) {
                return;
            }
            $query = $db->prepare("SELECT 1 FROM slots WHERE key=? AND data NOT IN ('[]','null') LIMIT 1");
            $query->execute([$key]);
            if ($query->fetchColumn() !== false) {
                throw new \RuntimeException('Collection storage migration required before editing', 409);
            }
            self::register($key, $definition);
        });
    }

    public static function state(string $key): ?array
    {
        if (!self::isRegistered($key)) {
            return null;
        }
        $s = self::getInstance()->prepare(
            "SELECT * FROM collection_slots WHERE slot_key=?"
        );
        $s->execute([$key]);
        return $s->fetch() ?: null;
    }

    public static function register(string $key, array $definition): void
    {
        $json = self::json($definition);
        $hash = hash("sha256", $json);
        $now = self::now();
        $db = self::getInstance();
        $db->prepare(
            "INSERT OR IGNORE INTO collection_schema_versions VALUES (?,?,?)"
        )->execute([$hash, $json, $now]);
        $db->prepare(
            "INSERT OR IGNORE INTO collection_slots(slot_key,schema_json,schema_hash,created_at,updated_at) VALUES (?,?,?,?,?)"
        )->execute([$key, $json, $hash, $now, $now]);
        $db->prepare(
            "INSERT INTO slots(key,data) VALUES (?,?) ON CONFLICT(key) DO UPDATE SET data=excluded.data"
        )->execute([$key, self::SENTINEL]);
    }

    /** Safe additive/removal schema changes; structural changes require the migration CLI. */
    public static function syncSchema(
        string $key,
        array $definition,
        bool $allowTransform = false
    ): void {
        if (\NomadCMS\Services\Schema\SchemaProvider::initialized()) {
            $activeDefinition = \NomadCMS\Services\Schema\SchemaProvider::slot($key);
            if (\NomadCMS\Services\Schema\SchemaDefinition::canonical($activeDefinition) !== \NomadCMS\Services\Schema\SchemaDefinition::canonical($definition)) {
                throw new \DomainException('Schema changes require a migration proposal.');
            }
        }
        $state = self::state($key);
        if (!$state) {
            self::register($key, $definition);
            return;
        }
        $json = self::json($definition);
        $hash = hash("sha256", $json);
        if ($state["schema_hash"] === $hash) {
            return;
        }
        if (($definition["type"] ?? "") !== "collection") {
            throw new \DomainException(
                "Collection type changes require an explicit migration"
            );
        }
        $old = json_decode(
            $state["schema_json"],
            true,
            512,
            JSON_THROW_ON_ERROR
        );
        $newFields = array_column($definition["fields"] ?? [], null, "id");
        foreach ($old["fields"] ?? [] as $field) {
            $new = $newFields[$field["id"]] ?? null;
            if (!$new) {
                continue;
            }
            foreach (["type", "localized", "target"] as $property) {
                if (
                    ($field[$property] ??
                        ($property === "localized" ? false : null)) !==
                        ($new[$property] ??
                            ($property === "localized" ? false : null)) &&
                    !$allowTransform
                ) {
                    throw new \DomainException(
                        "Schema migration required for $key.{$field["id"]} ($property)"
                    );
                }
            }
        }
        $oldFields = array_column($old["fields"] ?? [], null, "id");
        $additive = array_diff_key($oldFields, $newFields) === [];
        foreach ($oldFields as $id => $field) {
            if (($newFields[$id] ?? null) !== $field) {
                $additive = false;
            }
        }
        foreach (
            ["publishedField", "slugField", "publicPayload", "publicFields"]
            as $property
        ) {
            if (
                ($old[$property] ?? null) !==
                ($definition[$property] ?? null)
            ) {
                $additive = false;
            }
        }
        self::transaction(function (PDO $db) use (
            $key,
            $definition,
            $json,
            $hash,
            $additive,
            $allowTransform
        ) {
            $db->prepare(
                "INSERT OR IGNORE INTO collection_schema_versions VALUES (?,?,?)"
            )->execute([$hash, $json, self::now()]);
            $db->prepare(
                "UPDATE collection_slots SET schema_json=?,schema_hash=?,revision=revision+1 WHERE slot_key=?"
            )->execute([$json, $hash, $key]);
            // Re-index in bounded batches; removed values remain in raw content/blocks.
            if (!$additive && !$allowTransform) {
                foreach (self::iterate($key, true) as $item) {
                    self::writeItem(
                        $key,
                        RelationService::uidOf($item),
                        $item,
                        "update",
                        ["skip_versioning" => true, "reindex" => true]
                    );
                };
            }
            // A new field does not alter stored items. Existing unknown values can become public/searchable.
            if ($additive || $allowTransform) {
                $db->prepare(
                    "INSERT OR IGNORE INTO collection_dirty_items SELECT slot_key,item_uid FROM collection_items WHERE slot_key=?"
                )->execute([$key]);
            }
            self::enqueue($key);
        });
        PublicPayloadService::clearCaches();
    }

    public static function row(string $key, string $uid): ?array
    {
        \NomadCMS\Services\Schema\SchemaProvider::lease($key);
        $s = self::getInstance()->prepare(
            "SELECT * FROM collection_items WHERE slot_key=? AND item_uid=?"
        );
        $s->execute([$key, $uid]);
        return $s->fetch() ?: null;
    }

    private static function hydrate(array $row, bool $blocks): array
    {
        $item = json_decode($row["data"], true, 512, JSON_THROW_ON_ERROR);
        $item["_dndId"] = $row["item_uid"];
        if ($blocks) {
            $s = self::getInstance()->prepare(
                "SELECT field_id,locale,data FROM collection_blocks WHERE item_row_id=? ORDER BY field_id,locale"
            );
            $s->execute([$row["row_id"]]);
            while ($b = $s->fetch()) {
                $value = json_decode(
                    $b["data"],
                    true,
                    512,
                    JSON_THROW_ON_ERROR
                );
                if ($b["locale"] === "") {
                    $item[$b["field_id"]] = $value;
                } else {
                    $item[$b["field_id"]][$b["locale"]] = $value;
                }
            }
        }
        return $item;
    }

    public static function getItem(
        string $key,
        string $uid,
        bool $blocks = true
    ): ?array {
        $row = self::row($key, $uid);
        return $row ? self::hydrate($row, $blocks) : null;
    }

    public static function ensureReady(string $key): void
    {
        if (!self::isRegistered($key)) {
            if (\NomadCMS\Security\PanicModeService::isReadOnlyRequest()) {
                throw new \NomadCMS\Security\PanicModeException('PANIC_MODE_ACTIVE', 'Collection migration is suspended during lockdown.');
            }
            self::migrate(
                $key,
                RelationService::loadSchema()["slots"][$key] ?? [
                    "type" => "collection",
                    "fields" => [],
                ],
                false
            );
        }
    }

    public static function findByField(
        string $key,
        string $field,
        mixed $value
    ): ?array {
        if ($field === "_dndId") {
            return self::getItem($key, (string) $value);
        }
        if (!is_scalar($value)) {
            throw new \InvalidArgumentException(
                "Collection match value must be scalar"
            );
        }
        if ($field === 'id' || $field === 'slug') {
            // Match the requested identifier kind; a slug must never match another item's ID.
            $column = $field === 'id' ? 'business_id' : 'slug';
            $s = self::getInstance()->prepare(
                'SELECT * FROM collection_items WHERE slot_key=? AND ' . $column . '=? LIMIT 2'
            );
            $s->execute([$key, (string) $value]);
        } else {
            $path = '$';
            foreach (explode(".", $field) as $part) {
                $path .= "." . json_encode($part, JSON_THROW_ON_ERROR);
            }
            $s = self::getInstance()->prepare(
                "SELECT * FROM collection_items WHERE slot_key=? AND json_extract(data,?)=? LIMIT 2"
            );
            $s->execute([$key, $path, $value]);
        }
        $rows = $s->fetchAll();
        if (count($rows) > 1) {
            throw new \InvalidArgumentException("Ambiguous collection match");
        }
        return $rows ? self::hydrate($rows[0], true) : null;
    }

    public static function getMany(
        string $key,
        array $uids,
        bool $blocks = true
    ): array {
        $result = [];
        foreach (
            array_chunk(array_values(array_unique($uids)), 400)
            as $chunk
        ) {
            if (!$chunk) {
                continue;
            }
            $s = self::getInstance()->prepare(
                "SELECT * FROM collection_items WHERE slot_key=? AND item_uid IN (" .
                    implode(",", array_fill(0, count($chunk), "?")) .
                    ")"
            );
            $s->execute([$key, ...$chunk]);
            while ($row = $s->fetch()) {
                $result["uid:" . $row["item_uid"]] = self::hydrate(
                    $row,
                    $blocks
                );
            }
        }
        return $result;
    }

    /** Metadata iteration is keyset-paginated; no live long-lived SQLite cursor during writes. */
    public static function iterate(
        string $key,
        bool $blocks = false,
        bool $metadata = false
    ): \Generator {
        \NomadCMS\Services\Schema\SchemaProvider::lease($key);
        $position = -1;
        $id = 0;
        do {
            $s = self::getInstance()->prepare(
                "SELECT * FROM collection_items WHERE slot_key=? AND (position>? OR (position=? AND row_id>?)) ORDER BY position,row_id LIMIT 100"
            );
            $s->execute([$key, $position, $position, $id]);
            $rows = $s->fetchAll();
            $s->closeCursor();
            foreach ($rows as $row) {
                $position = (int) $row["position"];
                $id = (int) $row["row_id"];
                $item = self::hydrate($row, $blocks);
                if ($metadata) {
                    $item["_collectionMeta"] = self::metadata($row);
                }
                yield $item;
            }
        } while (count($rows) === 100);
    }

    /**
     * Read one resumable discovery batch using idx_collection_order.
     * Blocks stay in their separate store; the cursor survives cron/request boundaries.
     * @return array{items: array, done: bool}
     */
    public static function discoveryBatch(string $key, array $cursor = []): array
    {
        \NomadCMS\Services\Schema\SchemaProvider::lease($key);
        $position = (int) ($cursor['position'] ?? -1);
        $id = (int) ($cursor['id'] ?? 0);
        $statement = self::getInstance()->prepare(
            'SELECT * FROM collection_items WHERE slot_key=? AND (position,row_id)>(?,?) '
            . 'ORDER BY position,row_id LIMIT 100'
        );
        $statement->execute([$key, $position, $id]);
        $rows = $statement->fetchAll(\PDO::FETCH_ASSOC);
        $statement->closeCursor();
        $items = [];
        foreach ($rows as $row) {
            $item = self::hydrate($row, false);
            $item['_collectionMeta'] = self::metadata($row);
            $items[] = [
                'item' => $item,
                'cursor' => ['position' => (int) $row['position'], 'id' => (int) $row['row_id']],
            ];
        }
        return ['items' => $items, 'done' => count($rows) < 100];
    }

    public static function exportAll(string $key): array
    {
        return iterator_to_array(self::iterate($key, true), false);
    }

    public static function findByIdentifier(
        string $key,
        string $value,
        bool $blocks = true
    ): ?array {
        \NomadCMS\Services\Schema\SchemaProvider::lease($key);
        if ($item = self::getItem($key, $value, $blocks)) {
            return $item;
        }
        $s = self::getInstance()->prepare(
            "SELECT DISTINCT i.* FROM collection_items i JOIN collection_identifiers a ON a.item_row_id=i.row_id WHERE a.slot_key=? AND a.value=? LIMIT 2"
        );
        $s->execute([$key, $value]);
        $rows = $s->fetchAll();
        if (!$rows) {
            $s = self::getInstance()->prepare(
                "SELECT i.* FROM collection_items i JOIN collection_cache_entries c ON c.slot_key=i.slot_key AND c.item_uid=i.item_uid WHERE c.slot_key=? AND c.identifier=?"
            );
            $s->execute([$key, $value]);
            $rows = $s->fetchAll();
        }
        return count($rows) === 1 ? self::hydrate($rows[0], $blocks) : null;
    }

    public static function page(string $key, array $options = []): array
    {
        \NomadCMS\Services\Schema\SchemaProvider::lease($key);
        $limit = max(1, min(100, (int) ($options["limit"] ?? 50)));
        $offset = max(0, (int) ($options["offset"] ?? 0));
        $where = ["i.slot_key=?"];
        $params = [$key];
        $join = "";
        [$filterWhere, $filterParams] = \NomadCMS\Services\CollectionFilters::compile(
            $options['filters'] ?? [],
            json_decode(self::state($key)['schema_json'] ?? '{}', true, 512, JSON_THROW_ON_ERROR)
        );
        $where = array_merge($where, $filterWhere);
        $params = array_merge($params, $filterParams);
        if (isset($options["owner_uuid"])) {
            $where[] = "i.owner_uuid=?";
            $params[] = $options["owner_uuid"];
        }
        if (isset($options["published"])) {
            $where[] = "i.published=?";
            $params[] = (int) (bool) $options["published"];
        } elseif (!empty($options["published_only"])) {
            $where[] = "i.published=1";
        }
        if (trim((string) ($options["search"] ?? "")) !== "") {
            $join = " JOIN collection_fts ON collection_fts.rowid=i.row_id";
            preg_match_all(
                "/[\p{L}\p{N}]+/u",
                mb_substr((string) $options["search"], 0, 500),
                $words
            );
            if (!$words[0]) {
                return [
                    "items" => [],
                    "item_meta" => [],
                    "next_cursor" => null,
                    "total" => 0,
                    "offset" => $offset,
                    "limit" => $limit,
                    "revision" => (int) (self::state($key)["revision"] ?? 0),
                    "schema_revision" => self::state($key)["schema_hash"] ?? null,
                ];
            }
            $where[] = "collection_fts MATCH ?";
            $params[] = implode(
                " AND ",
                array_map(
                    fn($w) => '"' . str_replace('"', '""', $w) . '"*',
                    array_slice($words[0], 0, 20)
                )
            );
        }
        $sql =
            " FROM collection_items i" .
            $join .
            " WHERE " .
            implode(" AND ", $where);
        $s = self::getInstance()->prepare("SELECT COUNT(*)" . $sql);
        $s->execute($params);
        $total = (int) $s->fetchColumn();
        $cursor=$options['cursor']??null;
        if ($cursor) {
            $decoded=json_decode(base64_decode((string)$cursor,true)?:'',true);
            if (!is_array($decoded)||!is_string($decoded[0]??null)||!is_int($decoded[1]??null)) throw new \InvalidArgumentException('Invalid collection cursor');
            $sql.=' AND (i.created_at<? OR (i.created_at=? AND i.row_id<?))';
            array_push($params,$decoded[0],$decoded[0],$decoded[1]); $offset=0;
        }
        $s=self::getInstance()->prepare('SELECT i.*'.$sql.' ORDER BY i.created_at DESC,i.row_id DESC LIMIT '.$limit.' OFFSET '.$offset); $s->execute($params);
        $items=[]; $meta=[]; $last=null;
        while($row=$s->fetch()) { $items[]=self::hydrate($row,!empty($options['include_blocks'])); $meta['uid:'.$row['item_uid']]=self::metadata($row); $last=$row; }
        $next=count($items)===$limit&&$last ? base64_encode(self::json([$last['created_at'],(int)$last['row_id']])) : null;
        $state = self::state($key);
        return [
            "items" => $items,
            "next_cursor" => $next,
            "item_meta" => $meta,
            "total" => $total,
            "offset" => $offset,
            "limit" => $limit,
            "revision" => (int) ($state["revision"] ?? 0),
            "schema_revision" => $state["schema_hash"] ?? null,
        ];
    }

    /**
     * Every status change and its indexes/history commit together; memory stays batch-sized.
     *
     * @param array $options Collection/schema revisions, actor and optional ownership scope.
     * @return array Atomic mutation result with the resulting collection revision.
     */
    public static function publishAll(string $key,bool $published,array $options): array
    {
        \NomadCMS\Services\Schema\SchemaProvider::lease($key);
        return self::transaction(function(PDO $db) use($key,$published,$options) {
            $state=self::state($key);
            if (!$state) throw new \OutOfBoundsException('Collection not found');
            if (($options['expected_schema_revision']??null)!==$state['schema_hash']) throw new OptimisticLockException($key,lockType:'hash',expectedHash:$options['expected_schema_revision']??'',actualHash:$state['schema_hash']);
            if (!isset($options['expected_version'])||(int)$options['expected_version']!==(int)$state['revision']) throw new OptimisticLockException($key,$options['expected_version']??null,(int)$state['revision']);
            $definition=json_decode($state['schema_json'],true,512,JSON_THROW_ON_ERROR);
            $field=$definition['publishedField']??null;
            if (!is_string($field)||$field==='') throw new \InvalidArgumentException('Collection has no publication field');
            $cursor=0; $updated=0;
            do {
                $where='slot_key=? AND row_id>? AND published<>?'; $params=[$key,$cursor,(int)$published];
                if (isset($options['owner_uuid'])) { $where.=' AND owner_uuid=?'; $params[]=$options['owner_uuid']; }
                $s=$db->prepare('SELECT row_id,item_uid,revision,updated_at FROM collection_items WHERE '.$where.' ORDER BY row_id LIMIT 100'); $s->execute($params); $rows=$s->fetchAll(); $s->closeCursor();
                foreach ($rows as $row) {
                    $cursor=(int)$row['row_id'];
                    self::writeItem($key,$row['item_uid'],[$field=>$published],'update',['expected_revision'=>(int)$row['revision'],'client_updated_at'=>$row['updated_at'],'expected_schema_revision'=>$state['schema_hash'],'changed_by'=>$options['changed_by']??'system','skip_webhooks'=>true]);
                    $updated++;
                }
            } while (count($rows)===100);
            return ['success'=>true,'updated'=>$updated,'version'=>(int)self::state($key)['revision'],'schema_revision'=>$state['schema_hash']];
        });
    }

    public static function metadata(array $row): array
    {
        return array_intersect_key(
            $row,
            array_flip([
                "item_uid",
                "revision",
                "created_at",
                "updated_at",
                "public_updated_at",
                "owner_uuid",
            ])
        );
    }

    private static function splitBlocks(
        array $item,
        array $definition,
        ?int $rowId
    ): array {
        $fields = [];
        foreach ($definition["fields"] ?? [] as $field) {
            if (in_array($field["type"] ?? "", ["blocks", "gutenberg"], true)) {
                if (is_array($item[$field["id"]] ?? null)) {
                    $fields[$field["id"]] = true;
                }
            }
        }
        // Preserve removed block fields in their original separate storage.
        if ($rowId) {
            $s = self::getInstance()->prepare(
                "SELECT DISTINCT field_id FROM collection_blocks WHERE item_row_id=?"
            );
            $s->execute([$rowId]);
            foreach ($s->fetchAll(PDO::FETCH_COLUMN) as $field) {
                $fields[$field] = true;
            }
        }
        $blocks = [];
        foreach (array_keys($fields) as $field) {
            if (!array_key_exists($field, $item)) {
                continue;
            }
            $value = $item[$field];
            unset($item[$field]);
            if (is_array($value) && !array_is_list($value) && $value !== []) {
                foreach ($value as $locale => $data) {
                    $blocks[] = [$field, (string) $locale, self::json($data)];
                };
            } else {
                $blocks[] = [$field, "", self::json($value)];
            }
        }
        return [$item, $blocks];
    }

    private static function searchText(array $item, array $definition): string
    {
        $texts = [];
        foreach (self::searchSource($item, $definition) as $v) {
            $text = trim(html_entity_decode(strip_tags($v), ENT_QUOTES | ENT_HTML5, "UTF-8"));
            if ($text !== '') {
                $texts[] = $text;
            }
        }
        return implode("\n", $texts);
    }

    /** Yield searchable raw strings in their original schema/content order without copying the item. */
    private static function searchSource(array $item, array $definition): \Generator
    {
        $walk = function (mixed $v) use (&$walk): \Generator {
            if (is_string($v)) {
                yield $v;
            } elseif (is_array($v)) {
                foreach ($v as $k => $child) {
                    if (
                        !is_string($k) ||
                        !in_array(
                            $k,
                            [
                                "id",
                                "type",
                                "label",
                                "className",
                                "url",
                                "src",
                                "href",
                                "_dndId",
                                "_recommendation",
                            ],
                            true
                        )
                    ) {
                        yield from $walk($child);
                    }
                };
            }
        };
        foreach ($definition["fields"] ?? [] as $field) {
            if (
                in_array(
                    $field["type"] ?? "",
                    [
                        "relation",
                        "relation_many",
                        "image",
                        "gallery",
                        "video",
                        "audio",
                        "file",
                        "boolean",
                        "number",
                    ],
                    true
                )
            ) {
                continue;
            }
            if (
                in_array(
                    $field["id"] ?? "",
                    [
                        "id",
                        "slug",
                        "_dndId",
                        $definition["publishedField"] ?? "",
                    ],
                    true
                )
            ) {
                continue;
            }
            if (array_key_exists($field["id"], $item)) {
                yield from $walk($item[$field["id"]]);
            }
        }
    }

    /** Length framing prevents distinct string boundaries from producing the same hash input. */
    private static function searchSourceHash(array $item, array $definition, string $schemaHash): string
    {
        $context = hash_init('sha256');
        foreach ([self::SEARCH_PROFILE, $schemaHash] as $value) {
            hash_update($context, strlen($value) . ':');
            hash_update($context, $value);
        }
        foreach (self::searchSource($item, $definition) as $value) {
            hash_update($context, strlen($value) . ':');
            hash_update($context, $value);
        }
        return hash_final($context);
    }

    /**
     * Verify optional browser work against authoritative PHP text, then atomically update derived search data.
     * Callers hold the item transaction. A client hash cannot prove a search projection is correct.
     */
    private static function updateSearchIndex(
        PDO $db,
        int $rowId,
        array $item,
        array $definition,
        string $schemaHash,
        string $previousHash,
        mixed $precomputed = null,
        bool $force = false
    ): void {
        $sourceHash = self::searchSourceHash($item, $definition, $schemaHash);
        if (!$force && $previousHash !== '' && hash_equals($previousHash, $sourceHash)) {
            $existing = $db->prepare('SELECT 1 FROM collection_fts WHERE rowid=?');
            $existing->execute([$rowId]);
            if ($existing->fetchColumn() !== false) {
                return;
            }
        }

        $text = self::searchText($item, $definition);
        if ($precomputed !== null) {
            $reason = null;
            if (!is_array($precomputed) || ($precomputed['profile'] ?? null) !== self::SEARCH_PROFILE) {
                $reason = 'invalid_profile';
            } elseif (!is_string($precomputed['text'] ?? null)) {
                $reason = 'invalid_text';
            } elseif (strlen($precomputed['text']) > self::MAX_PRECOMPUTED_SEARCH_BYTES) {
                $reason = 'oversized_text';
            } elseif (!mb_check_encoding($precomputed['text'], 'UTF-8')) {
                $reason = 'invalid_utf8';
            } elseif ($precomputed['text'] !== $text) {
                $reason = 'text_mismatch';
            } else {
                $text = $precomputed['text'];
            }
            if ($reason !== null) {
                \NomadCMS\Services\LoggerService::debug('Collection search precomputation rejected', [
                    'row_id' => $rowId,
                    'reason' => $reason,
                ]);
            }
        }
        $db->prepare('DELETE FROM collection_fts WHERE rowid=?')->execute([$rowId]);
        $db->prepare('INSERT INTO collection_fts(rowid,text) VALUES (?,?)')->execute([$rowId, $text]);
        $db->prepare('UPDATE collection_items SET search_source_hash=? WHERE row_id=?')->execute([$sourceHash, $rowId]);
    }

    public static function writeItem(
        string $key,
        ?string $uid,
        array $patch,
        string $operation,
        array $options = []
    ): array {
        \NomadCMS\Services\Schema\SchemaProvider::assertWritable($key);
        \NomadCMS\Services\Schema\SchemaProvider::invalidateIndexes($key);
        if (!in_array($operation, ["create", "update", "delete"], true)) {
            throw new \InvalidArgumentException("Invalid collection operation");
        }
        $uid ??= RelationService::generateUid();
        if ($uid === "" || trim($uid) === "") {
            throw new \InvalidArgumentException("Blank item UID");
        }
        return self::transaction(function (PDO $db) use (
            $key,
            $uid,
            $patch,
            $operation,
            $options
        ) {
            $state = self::state($key);
            if (!$state) {
                throw new \RuntimeException(
                    "Collection must be migrated/registered before item writes"
                );
            }
            if (
                isset($options["expected_schema_revision"]) &&
                $state["schema_hash"] !== $options["expected_schema_revision"]
            ) {
                throw new OptimisticLockException(
                    $key,
                    lockType: "hash",
                    expectedHash: $options["expected_schema_revision"],
                    actualHash: $state["schema_hash"]
                );
            }
            $row = self::row($key, $uid);
            if ($operation === "create" && $row) {
                throw new OptimisticLockException(
                    $key,
                    actualVersion: (int) $row["revision"]
                );
            }
            if ($operation !== "create" && !$row) {
                throw new \OutOfBoundsException("Item not found");
            }
            if (
                $row &&
                isset($options["expected_revision"]) &&
                (int) $options["expected_revision"] !== (int) $row["revision"]
            ) {
                throw new OptimisticLockException(
                    $key,
                    (int) $options["expected_revision"],
                    (int) $row["revision"]
                );
            }
            if ($row && isset($options['client_updated_at']) && $options['client_updated_at'] !== $row['updated_at']) {
                throw new OptimisticLockException(
                    $key,
                    $options['expected_revision'] ?? null,
                    (int) $row['revision']
                );
            }
            if (isset($patch["_dndId"]) && (string) $patch["_dndId"] !== $uid) {
                throw new \InvalidArgumentException("Item UID is immutable");
            }
            $old = $row ? self::hydrate($row, true) : null;
            $now = self::now();
            $definition = json_decode(
                $state["schema_json"],
                true,
                512,
                JSON_THROW_ON_ERROR
            );
            $copySource = null;
            if ($operation === 'create' && isset($options['copy_source_uid'])) {
                $copySource = self::getItem($key, (string) $options['copy_source_uid']);
                if ($copySource === null) {
                    throw new \OutOfBoundsException('Copy source not found');
                }
                \NomadCMS\Services\Schema\SchemaValues::inheritCopy(
                    $db, $key, (string) $options['copy_source_uid'], $uid, $copySource, $definition
                );
                $patch = array_replace($copySource, $patch);
            }
            $item =
                $operation === "delete"
                    ? $old
                    : (!empty($options["replace"])
                        ? $patch
                        : array_replace($old ?? [], $patch));
            foreach ($options["remove_fields"] ?? [] as $field) {
                if ($field === "_dndId") {
                    throw new \InvalidArgumentException("Cannot remove UID");
                }
                unset($item[$field]);
            }
            $item["_dndId"] = $uid;
            if ($operation !== "delete") {
                $item = \NomadCMS\Services\Schema\SchemaProvider::validateWrite($key, $item, $old ?? $copySource, false, $uid);
            }
            if ($copySource !== null) {
                // Changed fields use today's schema; untouched fields keep the source interpretation.
                \NomadCMS\Services\Schema\SchemaValues::record($db, $key, $uid, $item, $copySource);
            }
            $item = RelationService::normalizeItem(
                $item,
                RelationService::getRelationFields(
                    $copySource !== null
                        ? \NomadCMS\Services\Schema\SchemaValues::fields($db, $key, $uid, $definition)
                        : ($definition["fields"] ?? [])
                ),
                RelationService::loadSchema()
            );
            $json = self::json($item);
            $hash = hash("sha256", self::json(self::canonical($item)));
            if (
                $row &&
                $operation === "update" &&
                $row["content_hash"] === $hash &&
                empty($options["reindex"]) &&
                (!isset($options["position"]) ||
                    (int) $options["position"] === (int) $row["position"])
            ) {
                return [
                    "success" => true,
                    "item" => $old,
                    "item_meta" => self::metadata($row),
                    "version_created" => false,
                    "version" => (int) $state["revision"],
                ];
            }
            $changed =
                !$row ||
                $row["content_hash"] !== $hash ||
                $operation === "delete";
            $publicHash =
                $operation === "delete"
                    ? ""
                    : self::publicHash($key, $item, $definition);
            $publicChanged = !$row || $row["public_hash"] !== $publicHash;
            $revision = $row ? (int) $row["revision"] + ($changed ? 1 : 0) : 1;
            if (!$row) {
                $s = $db->prepare(
                    "SELECT COALESCE(MAX(revision),0)+1 FROM collection_item_versions WHERE slot_key=? AND item_uid=?"
                );
                $s->execute([$key, $uid]);
                $revision = (int) $s->fetchColumn();
            }
            [$historyShort, $historyBlocks] = self::splitBlocks(
                $item,
                $definition,
                $row ? (int) $row["row_id"] : null
            );
            if ($operation === "delete") {
                $db->prepare(
                    "DELETE FROM collection_fts WHERE rowid=?"
                )->execute([$row["row_id"]]);
                $db->prepare(
                    "DELETE FROM collection_items WHERE row_id=?"
                )->execute([$row["row_id"]]);
            } else {
                [$short, $blocks] = self::splitBlocks(
                    $item,
                    $definition,
                    $row ? (int) $row["row_id"] : null
                );
                $slugField = $definition["slugField"] ?? "slug";
                $slug = is_scalar($item[$slugField] ?? null)
                    ? (string) $item[$slugField]
                    : null;
                $business = is_scalar($item["id"] ?? null)
                    ? (string) $item["id"]
                    : null;
                $published = (int) PublicPayloadService::isItemPublished(
                    $definition,
                    $item
                );
                if ($row) {
                    $position = $options["position"] ?? $row["position"];
                    $db->prepare(
                        "UPDATE collection_items SET data=?,content_hash=?,public_hash=?,slug=?,business_id=?,published=?,revision=?,updated_at=?,public_updated_at=?,position=? WHERE row_id=?"
                    )->execute([
                        self::json($short),
                        $hash,
                        $publicHash,
                        $slug,
                        $business,
                        $published,
                        $revision,
                        $changed ? $now : $row["updated_at"],
                        $publicChanged ? $now : $row["public_updated_at"],
                        $position,
                        $row["row_id"],
                    ]);
                    $id = (int) $row["row_id"];
                } else {
                    $s = $db->prepare(
                        "SELECT COALESCE(MAX(position),-1024)+1024 FROM collection_items WHERE slot_key=?"
                    );
                    $s->execute([$key]);
                    $position = $options["position"] ?? (int) $s->fetchColumn();
                    $owner =
                        ContentDatabase::getOwner($key, $uid) ??
                        ($options["owner_uuid"] ?? null);
                    $created = $options["created_at"] ?? $now;
                    $updated = $options["updated_at"] ?? $now;
                    $db->prepare(
                        "INSERT INTO collection_items(slot_key,item_uid,position,data,content_hash,public_hash,slug,business_id,published,owner_uuid,revision,created_at,updated_at,public_updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)"
                    )->execute([
                        $key,
                        $uid,
                        $position,
                        self::json($short),
                        $hash,
                        $publicHash,
                        $slug,
                        $business,
                        $published,
                        $owner,
                        $revision,
                        $created,
                        $updated,
                        $updated,
                    ]);
                    $id = (int) $db->lastInsertId();
                    if ($owner) {
                        $db->prepare(
                            "INSERT OR IGNORE INTO slot_ownership(slot_key,item_uid,owner_uuid) VALUES (?,?,?)"
                        )->execute([$key, $uid, $owner]);
                    }
                }
                $db->prepare(
                    "DELETE FROM collection_blocks WHERE item_row_id=?"
                )->execute([$id]);
                $s = $db->prepare(
                    "INSERT INTO collection_blocks(item_row_id,field_id,locale,data) VALUES (?,?,?,?)"
                );
                foreach ($blocks as $block) {
                    $s->execute([$id, ...$block]);
                }
                self::updateSearchIndex(
                    $db, $id, $item, $definition, $state['schema_hash'],
                    $row['search_source_hash'] ?? '', $options['precomputed_search'] ?? null,
                    !empty($options['reindex'])
                );
                $db->prepare(
                    "DELETE FROM collection_identifiers WHERE item_row_id=?"
                )->execute([$id]);
                $s = $db->prepare(
                    "INSERT OR IGNORE INTO collection_identifiers VALUES (?,?,?,?,?)"
                );
                foreach (
                    [$slugField => "slug", "id" => "id"]
                    as $field => $kind
                ) {
                    $values = $item[$field] ?? null;
                    foreach (
                        is_array($values) ? $values : ["" => $values]
                        as $locale => $value
                    ) {
                        if (is_scalar($value)) {
                            $s->execute([
                                $key,
                                (string) $value,
                                $id,
                                $kind,
                                (string) $locale,
                            ]);
                            $clean = \NomadCMS\Services\StaticCacheService::sanitizeForIdentifier(
                                $value
                            );
                            if ($clean !== (string) $value) {
                                $s->execute([
                                    $key,
                                    $clean,
                                    $id,
                                    $kind,
                                    (string) $locale,
                                ]);
                            }
                        }
                    }
                }
            }
            if ($operation !== 'delete') {
                \NomadCMS\Services\Schema\SchemaValues::record($db, $key, $uid, $item, $old ?? $copySource);
            }
            self::syncIndexes(
                $key,
                $uid,
                $operation === "delete" ? null : $item,
                $definition
            );
            $semanticChanged =
                $operation === "delete" ||
                !$old ||
                \NomadCMS\Services\Versioning\ContentNormalizer::canonicalJson(
                    $old
                ) !==
                    \NomadCMS\Services\Versioning\ContentNormalizer::canonicalJson(
                        $item
                    );
            $publishedField = $definition['publishedField'] ?? null;
            $publicationOnly = false;
            if ($operation === 'update' && $old && is_string($publishedField) && $publishedField !== '') {
                $oldContent = $old;
                $newContent = $item;
                unset($oldContent[$publishedField], $newContent[$publishedField]);
                $publicationOnly = \NomadCMS\Services\Versioning\ContentNormalizer::canonicalJson($oldContent)
                    === \NomadCMS\Services\Versioning\ContentNormalizer::canonicalJson($newContent);
            }
            // Publication-only writes still advance item/collection revisions and invalidate caches.
            // They deliberately do not create historical snapshots, including the global bulk path.
            $settings = self::getVersioningSettings();
            $versionCreated = $semanticChanged && !$publicationOnly && empty($options['skip_versioning']) && $settings->isEnabled();
            if ($versionCreated) {
                $references = [];
                foreach ($historyBlocks as [$field, $locale, $blockJson]) {
                    $blockHash = hash("sha256", $blockJson);
                    $db->prepare(
                        "INSERT OR IGNORE INTO collection_history_blocks VALUES (?,?)"
                    )->execute([$blockHash, $blockJson]);
                    $references[] = [
                        "field" => $field,
                        "locale" => $locale,
                        "hash" => $blockHash,
                    ];
                }
                $json = self::json([
                    "_format" => "collection-item/v1",
                    "item" => $historyShort,
                    "blocks" => $references,
                ]);
                $historyHash = hash("sha256", $json);
                $signed = self::json([
                    $key,
                    $uid,
                    $revision,
                    $operation,
                    $state["schema_hash"],
                    $historyHash,
                ]);
                $signature = hash_hmac(
                    "sha256",
                    $signed,
                    VersionRepository::getHmacSecret()
                );
                $db->prepare(
                    "INSERT INTO collection_item_versions(slot_key,item_uid,revision,operation,schema_hash,data,content_hash,signature,changed_by,created_at) VALUES (?,?,?,?,?,?,?,?,?,?)"
                )->execute([
                    $key,
                    $uid,
                    $revision,
                    $operation,
                    $state["schema_hash"],
                    $json,
                    $historyHash,
                    $signature,
                    $options["changed_by"] ?? "system",
                    $now,
                ]);
                $versionId=(int)$db->lastInsertId();
                $blockReference = $db->prepare('INSERT OR IGNORE INTO collection_history_block_refs(history_id,hash) VALUES (?,?)');
                foreach ($references as $reference) $blockReference->execute([$versionId, $reference['hash']]);
                $diff=(new \NomadCMS\Services\Versioning\DiffEngine())->computeDiff(self::json($old??(object)[]),self::json($operation==='delete'?(object)[]:$item));
                $label=$item['title']??$item['name']??$item['slug']??'';
                if (is_array($label)) $label=reset($label)?:'';
                $db->prepare('UPDATE collection_item_versions SET change_summary=?,item_label=? WHERE id=?')->execute([$diff['change_summary']??$operation,is_scalar($label)?(string)$label:'',$versionId]);

            }
            self::enforceHistoryLimit($key, $settings->getMaxVersions());
            $delta =
                $operation === "create"
                    ? 1
                    : ($operation === "delete"
                        ? -1
                        : 0);
            $db->prepare(
                "UPDATE collection_slots SET item_count=item_count+?,revision=revision+1,updated_at=? WHERE slot_key=?"
            )->execute([$delta, $now, $key]);
            $db->prepare("UPDATE slots SET updated_at=? WHERE key=?")->execute([
                $now,
                $key,
            ]);
            self::enqueue($key);
            if (empty($options["reindex"]) || $publicChanged) {
                self::markItemDirty($key, $uid);
            }
            if ($changed) {
                self::enqueueDependents($key, $uid);
                if (empty($options['reindex']) && empty($options['skip_webhooks'])) {
                    \NomadCMS\Services\CollectionWebhookOutbox::record(
                        $db,
                        $key,
                        $operation,
                        $old,
                        $item,
                        $definition,
                        (int) $state['revision'] + 1,
                        $options['changed_by'] ?? null,
                        $operation === 'create' && isset($options['copy_source_uid'])
                    );
                }
            }
            RelationService::clearCache($key);
            $current = self::row($key, $uid);
            \NomadCMS\Services\Seo\SeoModule::changed($db, $key, $uid);
            return [
                "success" => true,
                "item" => $operation === "delete" ? null : $item,
                "item_meta" => $current ? self::metadata($current) : null,
                "version_created" => $versionCreated,
                "version" => (int) self::state($key)["revision"],
                "version_type" => "commit",
            ];
        });
    }

    private static function syncIndexes(
        string $key,
        string $uid,
        ?array $item,
        array $definition
    ): void {
        $db = self::getInstance();
        $db->prepare(
            "DELETE FROM slot_relations WHERE source_key=? AND source_uid=?"
        )->execute([$key, $uid]);
        $db->prepare(
            "DELETE FROM collection_media_usages WHERE slot_key=? AND item_uid=?"
        )->execute([$key, $uid]);
        if (!$item) {
            return;
        }
        $s = $db->prepare(
            "INSERT INTO slot_relations(source_key,source_uid,target_key,target_uid,field_id,sort_order) VALUES (?,?,?,?,?,?)"
        );
        foreach (
            RelationService::getRelationFields(\NomadCMS\Services\Schema\SchemaValues::fields($db, $key, $uid, $definition))
            as $field
        ) {
            $raw = $item[$field["id"]] ?? null;
            $values = is_array($raw) ? $raw : [$raw];
            foreach ($values as $order => $target) {
                if (is_string($target) && $target !== "") {
                    $s->execute([
                        $key,
                        $uid,
                        $field["target"],
                        $target,
                        $field["id"],
                        (int) $order,
                    ]);
                }
            }
        }
        $s = $db->prepare(
            "INSERT INTO collection_media_usages VALUES (?,?,?,?,?)"
        );
        foreach ($item as $field => $value) {
            $json = self::json($value);
            $refs = [];
            preg_match_all("~/api/uploads/([a-zA-Z0-9_.-]+)~", $json, $m);
            foreach ($m[1] as $ref) {
                $refs[$ref] = ($refs[$ref] ?? 0) + 1;
            }
            preg_match_all('~https?://[^"\s<>]+~', $json, $m);
            foreach ($m[0] as $ref) {
                $ref = rtrim($ref, ",.;:!?");
                $refs[$ref] = ($refs[$ref] ?? 0) + 1;
            }
            foreach ($refs as $ref => $count) {
                $s->execute([$key, $uid, $field, $ref, $count]);
            }
        }
    }

    public static function enqueue(string $key): void
    {
        self::getInstance()
            ->prepare(
                "INSERT INTO collection_jobs(slot_key,revision,queued_at) SELECT slot_key,revision,? FROM collection_slots WHERE slot_key=? ON CONFLICT(slot_key) DO UPDATE SET revision=excluded.revision,queued_at=excluded.queued_at"
            )
            ->execute([self::now(), $key]);
    }

    public static function markItemDirty(string $key, string $uid): void
    {
        self::getInstance()
            ->prepare(
                "INSERT OR IGNORE INTO collection_dirty_items VALUES (?,?)"
            )
            ->execute([$key, $uid]);
    }

    public static function enqueueDependents(
        string $key,
        ?string $uid = null
    ): void {
        $db = self::getInstance();
        $s = $db->prepare(
            "SELECT DISTINCT r.source_key,r.source_uid FROM slot_relations r JOIN collection_slots c ON c.slot_key=r.source_key WHERE r.target_key=?" .
                ($uid !== null ? " AND r.target_uid=?" : "")
        );
        $s->execute($uid !== null ? [$key, $uid] : [$key]);
        $slots = [];
        foreach ($s as $source) {
            self::markItemDirty($source["source_key"], $source["source_uid"]);
            $slots[$source["source_key"]] = true;
        }
        foreach (array_keys($slots) as $source) {
            $db->prepare(
                "UPDATE collection_slots SET revision=revision+1 WHERE slot_key=?"
            )->execute([$source]);
            self::enqueue($source);
        }
    }

    /** Derived data can be rebuilt after schema extension without changing content revisions. */
    public static function reindexDerived(
        string $key,
        string $uid,
        array $item
    ): void {
        self::transaction(function (PDO $db) use ($key, $uid, $item): void {
            $row = self::row($key, $uid);
            if (!$row) {
                return;
            }
            $state = self::state($key);
            $definition = json_decode($state['schema_json'], true, 512, JSON_THROW_ON_ERROR);
            self::updateSearchIndex(
                $db, (int) $row['row_id'], $item, $definition, $state['schema_hash'],
                $row['search_source_hash'] ?? ''
            );
            self::syncIndexes($key, $uid, $item, $definition);
        });
    }

    public static function refreshPublicMetadata(
        string $key,
        string $uid,
        array $item
    ): void {
        $state = self::state($key);
        $definition = json_decode($state["schema_json"], true);
        $hash = self::publicHash($key, $item, $definition);
        self::getInstance()
            ->prepare(
                "UPDATE collection_items SET public_hash=?,public_updated_at=? WHERE slot_key=? AND item_uid=? AND public_hash<>?"
            )
            ->execute([$hash, self::now(), $key, $uid, $hash]);
    }

    /** Reorder only these loaded items, retaining every unseen item's position and dates. */
    public static function reorder(
        string $key,
        array $uids,
        ?int $expectedRevision
    ): void {
        \NomadCMS\Services\Schema\SchemaProvider::assertWritable($key);
        \NomadCMS\Services\Schema\SchemaProvider::invalidateIndexes($key);
        self::transaction(function (PDO $db) use (
            $key,
            $uids,
            $expectedRevision
        ) {
            $state = self::state($key);
            if (
                $expectedRevision === null ||
                (int) $state["revision"] !== $expectedRevision
            ) {
                throw new OptimisticLockException(
                    $key,
                    $expectedRevision,
                    (int) $state["revision"]
                );
            }
            if (count($uids) !== count(array_unique($uids))) {
                throw new \InvalidArgumentException("Duplicate reorder UID");
            }
            $positions = [];
            foreach ($uids as $uid) {
                $row = self::row($key, (string) $uid);
                if (!$row) {
                    throw new \OutOfBoundsException("Reorder item not found");
                }
                $positions[] = (int) $row["position"];
            }
            sort($positions, SORT_NUMERIC);
            $s = $db->prepare(
                "UPDATE collection_items SET position=? WHERE slot_key=? AND item_uid=?"
            );
            foreach ($uids as $i => $uid) {
                $s->execute([$positions[$i], $key, $uid]);
                $db->prepare(
                    "UPDATE collection_cache_entries SET chunk_id=? WHERE slot_key=? AND item_uid=?"
                )->execute([
                    (int) floor(
                        $positions[$i] /
                            1024 /
                            \NomadCMS\Services\StaticCacheService::getChunkSize()
                    ),
                    $key,
                    $uid,
                ]);
            }
            $db->prepare(
                "UPDATE collection_slots SET revision=revision+1 WHERE slot_key=?"
            )->execute([$key]);
            self::enqueue($key);
        });
    }

    public static function replaceAll(
        string $key,
        array $items,
        array $options = []
    ): array {
        if (!array_is_list($items)) {
            throw new \InvalidArgumentException(
                "Collection payload must be a list"
            );
        }
        return self::replaceIterable($key, $items, $options);
    }

    /** Full replacement is reserved for explicit import/restore, never a list page. */
    public static function replaceIterable(
        string $key,
        iterable $items,
        array $options = []
    ): array {
        // Explicit imports/full replacements are batch operations, never webhook bursts.
        $options['skip_webhooks'] = true;
        \NomadCMS\Services\Schema\SchemaProvider::assertWritable($key);
        \NomadCMS\Services\Schema\SchemaProvider::invalidateIndexes($key);
        return self::transaction(function (PDO $db) use (
            $key,
            $items,
            $options
        ) {
            if (!self::isRegistered($key)) {
                self::register(
                    $key,
                    RelationService::loadSchema()["slots"][$key] ?? [
                        "type" => "collection",
                        "fields" => [],
                    ]
                );
            }
            $state = self::state($key);
            if (
                isset($options["expected_version"]) &&
                (int) $options["expected_version"] !== (int) $state["revision"]
            ) {
                throw new OptimisticLockException(
                    $key,
                    (int) $options["expected_version"],
                    (int) $state["revision"]
                );
            }
            if (
                isset($options["expected_hash"]) &&
                !hash_equals(
                    $options["expected_hash"],
                    ContentDatabase::computeContentHash(self::exportAll($key))
                )
            ) {
                throw new OptimisticLockException($key, lockType: "hash");
            }
            $db->exec(
                "CREATE TEMP TABLE IF NOT EXISTS collection_incoming_uids(uid TEXT PRIMARY KEY)"
            );
            $db->exec("DELETE FROM collection_incoming_uids");
            $changed = false;
            $position = 0;
            foreach ($items as $item) {
                if (!is_array($item) || array_is_list($item)) {
                    throw new \InvalidArgumentException(
                        "Collection item must be an object"
                    );
                }
                $uid =
                    RelationService::uidOf($item) ??
                    RelationService::generateUid();
                $item["_dndId"] = $uid;
                $s = $db->prepare(
                    "INSERT OR IGNORE INTO collection_incoming_uids VALUES (?)"
                );
                $s->execute([$uid]);
                if (!$s->rowCount()) {
                    throw new \InvalidArgumentException(
                        "Duplicate item UID: " . $uid
                    );
                }
                $r = self::writeItem(
                    $key,
                    $uid,
                    $item,
                    self::row($key, $uid) ? "update" : "create",
                    $options + [
                        "position" => $position++ * 1024,
                        "replace" => true,
                    ]
                );
                $changed = $changed || $r["version_created"];
            }
            do {
                $s = $db->prepare(
                    "SELECT item_uid FROM collection_items WHERE slot_key=? AND item_uid NOT IN (SELECT uid FROM collection_incoming_uids) LIMIT 100"
                );
                $s->execute([$key]);
                $deleted = $s->fetchAll(PDO::FETCH_COLUMN);
                $s->closeCursor();
                foreach ($deleted as $uid) {
                    self::writeItem($key, $uid, [], "delete", $options);
                    $changed = true;
                }
            } while ($deleted);
            self::enqueue($key);
            return [
                "success" => true,
                "version_created" => $changed,
                "skip_reason" => $changed ? null : "identical_content",
                "version" => (int) self::state($key)["revision"],
                "version_type" => "commit",
            ];
        });
    }

    public static function restoreItem(
        int $historyId,
        array $options = []
    ): array {
        $v = self::historyItem($historyId);
        return self::writeItem(
            $v["slot_key"],
            $v["item_uid"],
            $v["item"],
            self::row($v["slot_key"], $v["item_uid"]) ? "update" : "create",
            $options + ["replace" => true]
        );
    }

    public static function historyItem(int $historyId): array
    {
        $s = self::getInstance()->prepare(
            "SELECT * FROM collection_item_versions WHERE id=?"
        );
        $s->execute([$historyId]);
        $v = $s->fetch();
        if (!$v) {
            throw new \OutOfBoundsException("Version not found");
        }
        $signed = self::json([
            $v["slot_key"],
            $v["item_uid"],
            (int) $v["revision"],
            $v["operation"],
            $v["schema_hash"],
            $v["content_hash"],
        ]);
        if (
            !hash_equals($v["content_hash"], hash("sha256", $v["data"])) ||
            !hash_equals(
                $v["signature"],
                hash_hmac("sha256", $signed, VersionRepository::getHmacSecret())
            )
        ) {
            throw new \RuntimeException("Collection version integrity failure");
        }
        $payload = json_decode($v["data"], true, 512, JSON_THROW_ON_ERROR);
        if (($payload["_format"] ?? "") === "collection-item/v1") {
            $item = $payload["item"];
            foreach ($payload["blocks"] as $block) {
                $s = self::getInstance()->prepare(
                    "SELECT data FROM collection_history_blocks WHERE hash=?"
                );
                $s->execute([$block["hash"]]);
                $json = $s->fetchColumn();
                if (
                    $json === false ||
                    !hash_equals($block["hash"], hash("sha256", $json))
                ) {
                    throw new \RuntimeException(
                        "Collection history block integrity failure"
                    );
                }
                $value = json_decode($json, true, 512, JSON_THROW_ON_ERROR);
                if ($block["locale"] === "") {
                    $item[$block["field"]] = $value;
                } else {
                    $item[$block["field"]][$block["locale"]] = $value;
                }
            }
        } else {
            $item = $payload;
        }
        $v["item"] = $item;
        unset($v["data"], $v["signature"]);
        return $v;
    }

    public static function migrate(
        string $key,
        array $definition,
        bool $dryRun = true
    ): array {
        $db = self::getInstance();
        $s = $db->prepare("SELECT data,updated_at FROM slots WHERE key=?");
        $s->execute([$key]);
        $source = $s->fetch();
        if (self::isRegistered($key)) {
            return [
                "slot" => $key,
                "status" => "already_migrated",
                "count" => (int) self::state($key)["item_count"],
            ];
        }
        $items = $source
            ? json_decode($source["data"], true, 512, JSON_THROW_ON_ERROR)
            : [];
        if (!is_array($items) || !array_is_list($items)) {
            throw new \InvalidArgumentException("$key: source is not an array");
        }
        $seen = [];
        $missing = 0;
        foreach ($items as $item) {
            if (!is_array($item) || array_is_list($item)) {
                throw new \InvalidArgumentException(
                    "$key: non-object source item"
                );
            }
            $uid = RelationService::uidOf($item);
            if ($uid === null) {
                $missing++;
                continue;
            }
            if (isset($seen["uid:" . $uid])) {
                throw new \InvalidArgumentException(
                    "$key: ambiguous duplicate UID $uid; explicit mapping required"
                );
            }
            $seen["uid:" . $uid] = true;
        }
        $s = $db->prepare(
            "SELECT name FROM sqlite_master WHERE type='table' AND name=?"
        );
        $s->execute(["collection_" . $key]);
        $legacy = $s->fetchColumn() ?: null;
        $report = [
            "slot" => $key,
            "status" => $dryRun ? "dry_run" : "migrated",
            "count" => count($items),
            "missing_uids" => $missing,
            "unused_legacy_table" => $legacy,
            "source_checksum" => hash("sha256", $source["data"] ?? "[]"),
        ];
        if ($dryRun) {
            return $report;
        }
        self::transaction(function (PDO $db) use (
            $key,
            $definition,
            $items,
            $source
        ) {
            $s = $db->prepare("SELECT data FROM slots WHERE key=?");
            $s->execute([$key]);
            $current = $s->fetchColumn();
            if (($source["data"] ?? false) !== $current) {
                throw new \RuntimeException(
                    "Source changed during migration; retry"
                );
            }
            if ($source) {
                $db->prepare(
                    "INSERT OR IGNORE INTO collection_migration_archives VALUES (?,?,?,?,?)"
                )->execute([
                    $key,
                    $source["data"],
                    hash("sha256", $source["data"]),
                    self::now(),
                    $source["updated_at"],
                ]);
            }
            self::register($key, $definition);
            $date = $source["updated_at"] ?? self::now();
            foreach ($items as $index => $item) {
                self::writeItem(
                    $key,
                    RelationService::uidOf($item),
                    $item,
                    "create",
                    [
                        "position" => $index * 1024,
                        "created_at" => $date,
                        "updated_at" => $date,
                        "skip_versioning" => true,
                        "skip_webhooks" => true,
                    ]
                );
            }
            if ((int) self::state($key)["item_count"] !== count($items)) {
                throw new \RuntimeException("Migration count mismatch");
            }
            $db->exec(
                "INSERT INTO collection_fts(collection_fts) VALUES ('integrity-check')"
            );
            // Preserve the original version chain; migration creates no synthetic item history.
            $db->prepare("DELETE FROM media_usages WHERE slot_key=?")->execute([
                $key,
            ]);
        });
        return $report;
    }

    public static function rollbackMigration(string $key): void
    {
        self::transaction(function (PDO $db) use ($key) {
            $s = $db->prepare(
                "SELECT * FROM collection_migration_archives WHERE slot_key=?"
            );
            $s->execute([$key]);
            $archive = $s->fetch();
            if (
                !$archive ||
                !hash_equals(
                    $archive["checksum"],
                    hash("sha256", $archive["data"])
                )
            ) {
                throw new \RuntimeException("No valid migration archive");
            }
            $state = self::state($key);
            if (
                $state &&
                (int) $state["revision"] !== (int) $state["item_count"]
            ) {
                throw new \RuntimeException(
                    "Collection was edited after migration; export current content before rollback"
                );
            }
            self::replaceAll($key, [], ["skip_versioning" => true]);
            $db->prepare(
                "DELETE FROM collection_slots WHERE slot_key=?"
            )->execute([$key]);
            $db->prepare(
                "UPDATE slots SET data=?,updated_at=? WHERE key=?"
            )->execute([$archive["data"], $archive["source_updated_at"], $key]);
            $db->prepare(
                "DELETE FROM collection_jobs WHERE slot_key=?"
            )->execute([$key]);
            RelationService::syncRelations(
                $key,
                json_decode($archive["data"], true)
            );
            \NomadCMS\Services\MediaService::syncSlotMediaUsages(
                $key,
                $archive["data"],
                $db
            );
        });
    }
}
