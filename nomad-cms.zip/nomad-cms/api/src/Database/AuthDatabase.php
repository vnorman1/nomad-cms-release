<?php
/**
 * NOMAD CMS - System Database (Auth)
 * Elkülönített adatbázis a biztonsági adatoknak (system.sqlite)
 * 
 * Split Architecture:
 * - system.sqlite: users, auth, sessions (THIS FILE)
 * - database.sqlite: CMS content, slots, media, versions
 */

declare(strict_types=1);

namespace NomadCMS\Database;

use PDO;
use PDOException;

final class AuthDatabase
{
    private static ?PDO $instance = null;

    /** Shared path resolver for installation, panic control and isolated tests. */
    public static function path(): string
    {
        $file = $_ENV['DB_SYSTEM_DATABASE'] ?? 'system.sqlite';
        return str_starts_with($file, '/') ? $file : __DIR__ . '/../../databases/' . $file;
    }
    
    /**
     * Get singleton database instance
     */
    public static function getInstance(bool $initialize = true): PDO
    {
        if (self::$instance === null) {
            $dbPath = self::path();
            $newDatabase = !is_file($dbPath);
            
            try {
                self::$instance = new PDO("sqlite:$dbPath", null, null, [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES => false,
                    PDO::ATTR_TIMEOUT => 5,
                ]);
                
                // Initialize schema if needed
                if ($newDatabase || ($initialize && !\NomadCMS\Security\PanicModeService::isReadOnlyRequest()
                    && !\NomadCMS\Security\PanicModeService::isActive())) {
                    self::initializeSchema();
                } else {
                    // Installed Hub hot paths only: no DDL, seeding or journal-mode transition.
                    self::$instance->exec('PRAGMA busy_timeout=500; PRAGMA foreign_keys=ON; PRAGMA cache_size=-2048');
                }
                
            } catch (PDOException $e) {
                throw new \RuntimeException("System database connection failed: " . $e->getMessage());
            }
        }
        
        return self::$instance;
    }
    
    /**
     * Get system SQLite database connection alias
     */
    public static function getSystemConnection(): PDO
    {
        return self::getInstance();
    }
    
    /**
     * Initialize database schema
     */
    private static function initializeSchema(): void
    {
        $db = self::$instance;
        
        // Wait (instead of failing instantly) when another connection holds a
        // write lock. SQLite's default busy timeout is 0, which surfaces as a
        // hard "database is locked" error under even brief concurrency - e.g.
        // two simultaneous requests on shared hosting, or a background job
        // running alongside a normal request.
        // CRITICAL CONCURRENCY: Must be executed FIRST before any query or pragma!
        $db->exec('PRAGMA busy_timeout=5000');

        // Try WAL mode for better concurrency, fallback to DELETE for shared hosting
        try {
            $result = $db->query('PRAGMA journal_mode=WAL')->fetchColumn();
            if (strtoupper($result) === 'WAL') {
                // WAL mode successful - use NORMAL sync (safe with WAL)
                $db->exec('PRAGMA synchronous=NORMAL');
            } else {
                // WAL failed (e.g., NFS/shared hosting) - use DELETE mode
                $db->exec('PRAGMA journal_mode=DELETE');
                $db->exec('PRAGMA synchronous=FULL');
            }
        } catch (\Exception $e) {
            // Fallback to DELETE mode on any error
            $db->exec('PRAGMA journal_mode=DELETE');
            $db->exec('PRAGMA synchronous=FULL');
        }
        // 5MB cache for better read performance
        $db->exec('PRAGMA cache_size=-5000');
        // Temp tables in memory for faster JOINs
        $db->exec('PRAGMA temp_store=MEMORY');
        // Enable foreign keys
        $db->exec('PRAGMA foreign_keys=ON');
        // Auto-vacuum for long-term file size optimization
        $db->exec('PRAGMA auto_vacuum=INCREMENTAL');
        
        // Users table with USER-LEVEL auth settings
        $db->exec("
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                uuid TEXT UNIQUE NOT NULL,
                email TEXT UNIQUE NOT NULL,
                password_hash TEXT DEFAULT NULL,
                
                -- Personal name (optional at install time, required when an
                -- admin creates a user from the admin panel)
                first_name TEXT DEFAULT NULL,
                last_name TEXT DEFAULT NULL,
                
                -- User-level auth settings (user can manage their own)
                totp_secret TEXT DEFAULT NULL,
                totp_enabled INTEGER DEFAULT 0,
                totp_allowed INTEGER DEFAULT 1,
                webauthn_allowed INTEGER DEFAULT 1,
                password_allowed INTEGER DEFAULT 1,
                backup_codes TEXT DEFAULT NULL,
                
                -- Account status
                email_verified INTEGER DEFAULT 0,
                is_admin INTEGER DEFAULT 0,
                is_new_user INTEGER DEFAULT 1,
                role TEXT DEFAULT NULL,
                failed_login_attempts INTEGER DEFAULT 0,
                locked_until TEXT DEFAULT NULL,
                
                -- Recovery settings
                recovery_email TEXT DEFAULT NULL,
                recovery_phone TEXT DEFAULT NULL,
                
                -- User preferences (JSON: theme, language, etc.)
                preferences TEXT DEFAULT NULL,
                
                -- Timestamps
                last_login_at TEXT DEFAULT NULL,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
        ");
        
        // Migration: Add is_new_user column if it doesn't exist
        try {
            $db->exec("ALTER TABLE users ADD COLUMN is_new_user INTEGER DEFAULT 1");
        } catch (\PDOException $e) {
            // Column already exists, ignore
        }
        
        // Migration: Add preferences column for user settings (theme, language, etc.)
        try {
            $db->exec("ALTER TABLE users ADD COLUMN preferences TEXT DEFAULT NULL");
        } catch (\PDOException $e) {
            // Column already exists, ignore
        }
        
        // Migration: Add role column for RBAC (admin, editor, viewer)
        try {
            $db->exec("ALTER TABLE users ADD COLUMN role TEXT DEFAULT NULL");
        } catch (\PDOException $e) {
            // Column already exists, ignore
        }
        
        // Migration: Add role_slug column for extended RBAC (FK -> roles.slug)
        try {
            $db->exec("ALTER TABLE users ADD COLUMN role_slug TEXT DEFAULT NULL");
        } catch (\PDOException $e) {
            // Column already exists, ignore
        }
        
        // Migration: Add first_name / last_name for human-readable identification
        // (used by the admin panel, the /welcome onboarding greeting and the
        // Settings -> General tab). Nullable so pre-existing accounts keep working.
        try {
            $db->exec("ALTER TABLE users ADD COLUMN first_name TEXT DEFAULT NULL");
        } catch (\PDOException $e) {
            // Column already exists, ignore
        }
        
        try {
            $db->exec("ALTER TABLE users ADD COLUMN last_name TEXT DEFAULT NULL");
        } catch (\PDOException $e) {
            // Column already exists, ignore
        }
        
        // =========================================================================
        // Magic Link Onboarding: user invitations
        // =========================================================================
        //
        // SECURITY MODEL (split token / "selector + verifier"):
        //   The raw token handed to the admin has the form "<selector>.<verifier>":
        //     - selector: 8 random bytes (hex) - a PUBLIC lookup key, indexed
        //     - verifier: 32 random bytes (hex) - the actual secret
        //   Only SHA-256(verifier) is persisted in token_hash, never the verifier
        //   itself. Lookup is a single indexed query on `selector`, followed by a
        //   constant-time hash_equals() comparison - so there is neither a full
        //   table scan nor a timing side channel that could leak valid tokens.
        //
        // LIFECYCLE:
        //   first_used_at - set when the link is first redeemed (audit only)
        //   consumed_at   - set ONLY when onboarding actually completes (password
        //                   set). Until then the same link stays usable until it
        //                   expires, so an abandoned onboarding is recoverable.
        //   revoked_at    - set when the admin regenerates or revokes the link.
        //                   Each user has at most ONE active invitation.
        $db->exec("
            CREATE TABLE IF NOT EXISTS user_invitations (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                selector TEXT UNIQUE NOT NULL,
                token_hash TEXT UNIQUE NOT NULL,
                purpose TEXT NOT NULL DEFAULT 'invite',
                created_by INTEGER DEFAULT NULL,
                expires_at TEXT NOT NULL,
                first_used_at TEXT DEFAULT NULL,
                consumed_at TEXT DEFAULT NULL,
                revoked_at TEXT DEFAULT NULL,
                ip_address TEXT DEFAULT NULL,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
            )
        ");
        
        $db->exec("CREATE INDEX IF NOT EXISTS idx_user_invitations_selector ON user_invitations(selector)");
        $db->exec("CREATE INDEX IF NOT EXISTS idx_user_invitations_user_id ON user_invitations(user_id)");
        $db->exec("CREATE INDEX IF NOT EXISTS idx_user_invitations_expires_at ON user_invitations(expires_at)");
        
        // =========================================================================
        // Extended RBAC: Roles & Permissions (2026 RBAC/ABAC-hybrid)
        // =========================================================================
        
        // Roles table - custom + built-in system roles
        $db->exec("
            CREATE TABLE IF NOT EXISTS roles (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                slug TEXT UNIQUE NOT NULL,
                name TEXT NOT NULL,
                description TEXT DEFAULT NULL,
                is_system INTEGER DEFAULT 0,
                priority INTEGER DEFAULT 100,
                slot_access TEXT NOT NULL DEFAULT '[]',
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
        ");
        
        // Role permissions - each row is a single 'resource:action:scope' string
        $db->exec("
            CREATE TABLE IF NOT EXISTS role_permissions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                role_id INTEGER NOT NULL,
                permission TEXT NOT NULL,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (role_id) REFERENCES roles(id) ON DELETE CASCADE,
                UNIQUE(role_id, permission)
            )
        ");
        
        $db->exec("CREATE INDEX IF NOT EXISTS idx_roles_slug ON roles(slug)");
        $db->exec("CREATE INDEX IF NOT EXISTS idx_role_permissions_role_id ON role_permissions(role_id)");
        $db->exec("CREATE INDEX IF NOT EXISTS idx_users_role_slug ON users(role_slug)");
        
        // Seed built-in system roles (idempotent)
        self::seedSystemRoles($db);
        
        // Backfill: assign role_slug to legacy users created before the
        // Extended RBAC migration (e.g. the initial installer super admin,
        // or any user whose role_slug is still NULL). Idempotent - only
        // touches rows where role_slug IS NULL.
        self::backfillLegacyRoleSlugs($db);
        
        // WebAuthn credentials table
        $db->exec("
            CREATE TABLE IF NOT EXISTS webauthn_credentials (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                credential_id TEXT UNIQUE NOT NULL,
                public_key TEXT NOT NULL,
                attestation_type TEXT NOT NULL,
                transports TEXT DEFAULT NULL,
                sign_count INTEGER DEFAULT 0,
                user_handle TEXT NOT NULL,
                friendly_name TEXT DEFAULT NULL,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                last_used_at TEXT DEFAULT NULL,
                FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
            )
        ");
        
        // Refresh tokens table
        $db->exec("
            CREATE TABLE IF NOT EXISTS refresh_tokens (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                token_hash TEXT UNIQUE NOT NULL,
                family TEXT NOT NULL,
                expires_at TEXT NOT NULL,
                revoked INTEGER DEFAULT 0,
                revoked_at TEXT DEFAULT NULL,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                ip_address TEXT DEFAULT NULL,
                user_agent TEXT DEFAULT NULL,
                FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
            )
        ");
        
        // Sessions table for tracking active sessions
        $db->exec("
            CREATE TABLE IF NOT EXISTS sessions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                session_id TEXT UNIQUE NOT NULL,
                ip_address TEXT DEFAULT NULL,
                user_agent TEXT DEFAULT NULL,
                last_activity_at TEXT DEFAULT CURRENT_TIMESTAMP,
                expires_at TEXT NOT NULL,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
            )
        ");
        
        // Login attempts for security auditing
        $db->exec("
            CREATE TABLE IF NOT EXISTS login_attempts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                email TEXT NOT NULL,
                ip_address TEXT NOT NULL,
                user_agent TEXT DEFAULT NULL,
                success INTEGER NOT NULL,
                failure_reason TEXT DEFAULT NULL,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
        ");
        
        // System settings table (key-value store for disaster recovery, etc.)
        $db->exec("
            CREATE TABLE IF NOT EXISTS system_settings (
                key TEXT PRIMARY KEY,
                value TEXT NOT NULL,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
        ");

        // Installation creates both the panic tables and the initial singleton.
        // Existing installations import legacy JSON exactly once; schema init
        // must never reset an existing lockdown or silently recreate a lost row.
        \NomadCMS\Security\PanicModeSchema::ensure($db);
        \NomadCMS\Auth\AuthSchema::ensure($db);
        
        // =========================================================================
        // Webhook Tables
        // =========================================================================
        
        // Outgoing webhook configurations
        $db->exec("
            CREATE TABLE IF NOT EXISTS webhooks (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                name TEXT NOT NULL,
                url TEXT NOT NULL,
                secret TEXT NOT NULL,
                events TEXT NOT NULL,
                payload_fields TEXT DEFAULT NULL,
                slot_filters TEXT DEFAULT NULL,
                slot_type_filters TEXT DEFAULT NULL,
                headers TEXT DEFAULT NULL,
                payload_shape TEXT DEFAULT 'nomad',
                signature_standard TEXT DEFAULT 'nomad',
                forms_batch_mode TEXT DEFAULT 'off',
                is_active INTEGER DEFAULT 1,
                retry_count INTEGER DEFAULT 3,
                timeout_seconds INTEGER DEFAULT 30,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
            )
        ");
        
        // Add payload_fields column if not exists (migration for old databases)
        try {
            $db->exec("ALTER TABLE webhooks ADD COLUMN payload_fields TEXT DEFAULT NULL");
        } catch (\PDOException $e) {
            // Column already exists, ignore
        }
        
        // Add slot_filters column if not exists (migration for old databases)
        try {
            $db->exec("ALTER TABLE webhooks ADD COLUMN slot_filters TEXT DEFAULT NULL");
        } catch (\PDOException $e) {
            // Column already exists, ignore
        }
        
        // Add slot_type_filters column if not exists (migration for old databases)
        try {
            $db->exec("ALTER TABLE webhooks ADD COLUMN slot_type_filters TEXT DEFAULT NULL");
        } catch (\PDOException $e) {
            // Column already exists, ignore
        }
        
        // Add headers column if not exists (migration for old databases)
        try {
            $db->exec("ALTER TABLE webhooks ADD COLUMN headers TEXT DEFAULT NULL");
        } catch (\PDOException $e) {
            // Column already exists, ignore
        }
        
        try {
            $db->exec("ALTER TABLE webhooks ADD COLUMN social_config TEXT");
        } catch (\PDOException $e) {
            if (!str_contains($e->getMessage(), 'duplicate column name')) {
                throw $e;
            }
        }

        // Social message language follows the UI language selected at creation.
        try {
            $db->exec("ALTER TABLE webhooks ADD COLUMN social_locale TEXT NOT NULL DEFAULT 'hu'");
        } catch (\PDOException $e) {
            if (!str_contains($e->getMessage(), 'duplicate column name')) {
                throw $e;
            }
        }

        // Add payload_shape column if not exists (migration for old databases).
        //
        // WHY THIS COLUMN EXISTS: the outgoing body has always been Nomad's own
        // envelope, {event, timestamp, data}. That is correct for a subscriber we
        // control, but Discord REQUIRES `content` or `embeds` at the top level and
        // Slack requires `text` - both answer 400 to anything else. So "send our
        // content events to a Slack channel", which is the single most requested
        // use of an outgoing webhook, was impossible without a proxy.
        //
        // Defaults to 'nomad', so every existing webhook keeps its exact current
        // body byte-for-byte.
        try {
            $db->exec("ALTER TABLE webhooks ADD COLUMN payload_shape TEXT DEFAULT 'nomad'");
        } catch (\PDOException $e) {
            // Column already exists, ignore
        }

        // Add signature_standard column if not exists (migration for old databases).
        // Defaults to 'nomad' (Stripe/Nomad format). Can be set to 'standard' (Standard Webhooks / Svix).
        try {
            $db->exec("ALTER TABLE webhooks ADD COLUMN signature_standard TEXT DEFAULT 'nomad'");
        } catch (\PDOException $e) {
            // Column already exists, ignore
        }

        // Add forms_batch_mode column if not exists (migration for old databases).
        //
        // WHY THIS COLUMN EXISTS: without it, a burst of form.submitted events
        // (a re-shared embed link, a mass-test) dispatches one webhook delivery
        // PER submission. 'off' (the default) keeps that exact current
        // behaviour for every existing webhook. 'global' collects ALL forms'
        // submissions into one shared batch; 'per_form' keeps one batch window
        // per form slug. See FormWebhookBatchService for the adaptive window.
        try {
            $db->exec("ALTER TABLE webhooks ADD COLUMN forms_batch_mode TEXT DEFAULT 'off'");
        } catch (\PDOException $e) {
            // Column already exists, ignore
        }
        
        // Webhook delivery log (for debugging and audit)
        $db->exec("
            CREATE TABLE IF NOT EXISTS webhook_deliveries (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                webhook_id INTEGER NOT NULL,
                event TEXT NOT NULL,
                payload TEXT NOT NULL,
                response_status INTEGER,
                response_body TEXT,
                attempts INTEGER DEFAULT 1,
                delivered_at TEXT,
                failed_at TEXT,
                next_retry_at TEXT,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (webhook_id) REFERENCES webhooks(id) ON DELETE CASCADE
            )
        ");
        
        // Incoming webhook endpoints (external services calling CMS)
        $db->exec("
            CREATE TABLE IF NOT EXISTS webhook_endpoints (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                name TEXT NOT NULL,
                endpoint_key TEXT UNIQUE NOT NULL,
                secret TEXT NOT NULL,
                handler TEXT NOT NULL,
                is_active INTEGER DEFAULT 1,
                signature_header TEXT DEFAULT 'X-Webhook-Signature',
                timestamp_header TEXT,
                signature_format TEXT DEFAULT 'auto',
                ingest_mode TEXT DEFAULT 'learning',
                auth_mode TEXT DEFAULT 'signature',
                target_kind TEXT,
                target_key TEXT,
                learning_expires_at TEXT,
                last_called_at TEXT,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
            )
        ");
        
        // Migration: Add signature config columns if they don't exist
        try {
            $db->exec("ALTER TABLE webhook_endpoints ADD COLUMN signature_header TEXT DEFAULT 'X-Webhook-Signature'");
        } catch (\Exception $e) { /* Column exists */ }
        try {
            $db->exec("ALTER TABLE webhook_endpoints ADD COLUMN timestamp_header TEXT");
        } catch (\Exception $e) { /* Column exists */ }
        try {
            $db->exec("ALTER TABLE webhook_endpoints ADD COLUMN signature_format TEXT DEFAULT 'auto'");
        } catch (\Exception $e) { /* Column exists */ }
        
        // Migration: Webhook automapper columns.
        //
        // ingest_mode gates whether a verified event may write into the CMS:
        //   'learning' (DEFAULT for new endpoints) accepts unsigned requests and
        //              stores them as webhook_events.status='unverified' so the
        //              mapper UI can show the user which fields arrived, but it
        //              NEVER writes to content. This is what makes "connect a
        //              webhook in 3 clicks" possible without the user first
        //              having to configure a shared secret.
        //   'live'     requires a valid signature and runs the mapping.
        //
        // Defaulting to 'learning' is deliberate and safe precisely BECAUSE it
        // cannot write: an unauthenticated endpoint that only appends to a
        // retention-swept event table has a far smaller blast radius than one
        // that inserts into live content. learning_expires_at additionally
        // closes the window automatically (see WebhookEventsSchema).
        //
        // target_kind/target_key hold the two-level target selection
        // ('form'|'massive'|'content' + the concrete form slug / slot key).
        // They live on the ENDPOINT, not on each rule, because one endpoint
        // maps into one destination - that is the whole simplification the
        // non-technical UI is built on.
        try {
            $db->exec("ALTER TABLE webhook_endpoints ADD COLUMN ingest_mode TEXT DEFAULT 'learning'");
        } catch (\Exception $e) { /* Column exists */ }
        try {
            $db->exec("ALTER TABLE webhook_endpoints ADD COLUMN target_kind TEXT");
        } catch (\Exception $e) { /* Column exists */ }
        try {
            $db->exec("ALTER TABLE webhook_endpoints ADD COLUMN target_key TEXT");
        } catch (\Exception $e) { /* Column exists */ }
        try {
            $db->exec("ALTER TABLE webhook_endpoints ADD COLUMN learning_expires_at TEXT");
        } catch (\Exception $e) { /* Column exists */ }
        
        // Migration: how an incoming request proves it is legitimate.
        //
        //   'signature'  HMAC over the body, verified against the shared secret.
        //                Required for Stripe/GitHub, and the ONLY option before
        //                this column existed.
        //   'url_token'  The endpoint URL itself is the credential, because its
        //                path segment is high-entropy and unguessable. This is
        //                how Discord, Slack and Zapier authenticate their own
        //                incoming webhooks, and it removes the single hardest
        //                step of setting one up: knowing which header and hash
        //                construction the sender uses.
        //
        // Defaults to 'signature' deliberately. Every endpoint that existed
        // before this column was created was built on the assumption that a valid
        // signature is mandatory; silently relaxing that during an upgrade would
        // turn each of them into an endpoint anyone who knows the slug can post
        // to - and those slugs are human-chosen and guessable ("stripe-payments").
        try {
            $db->exec("ALTER TABLE webhook_endpoints ADD COLUMN auth_mode TEXT DEFAULT 'signature'");
        } catch (\Exception $e) { /* Column exists */ }
        
        // Pending webhooks for debouncing (collection/list slot types)
        $db->exec("
            CREATE TABLE IF NOT EXISTS webhook_pending (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                debounce_key TEXT NOT NULL,
                event TEXT NOT NULL,
                payload TEXT NOT NULL,
                slot_key TEXT,
                slot_type TEXT,
                execute_at INTEGER NOT NULL,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
        ");
        
        // =========================================================================
        // Webhook Queue (Async Processing) - Phase 1
        // =========================================================================
        
        // Outgoing webhook queue for async delivery
        $db->exec("
            CREATE TABLE IF NOT EXISTS webhook_queue (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                webhook_id INTEGER NOT NULL,
                event TEXT NOT NULL,
                payload TEXT NOT NULL,
                slot_key TEXT,
                slot_type TEXT,
                status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'processing', 'completed', 'failed')),
                attempts INTEGER DEFAULT 0,
                max_attempts INTEGER DEFAULT 3,
                next_attempt_at INTEGER,
                created_at INTEGER NOT NULL,
                completed_at INTEGER,
                last_error TEXT,
                FOREIGN KEY (webhook_id) REFERENCES webhooks(id) ON DELETE CASCADE
            )
        ");
        
        // Durable cross-database collection fan-out receipts, independent of queue retention.
        $db->exec("CREATE TABLE IF NOT EXISTS collection_webhook_receipts (event_id TEXT PRIMARY KEY)");
        $db->exec("CREATE TABLE IF NOT EXISTS webhook_background_runs (id INTEGER PRIMARY KEY CHECK(id=1), last_run INTEGER NOT NULL)");
        \NomadCMS\Services\WebhookQueuePolicy::ensureSchema($db, 'webhook_queue');

        // Processed events for idempotency (incoming webhooks) - Phase 2
        $db->exec("
            CREATE TABLE IF NOT EXISTS webhook_processed_events (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                endpoint_key TEXT NOT NULL,
                event_id TEXT NOT NULL,
                event_hash TEXT NOT NULL,
                processed_at INTEGER NOT NULL,
                result TEXT DEFAULT 'success',
                UNIQUE(endpoint_key, event_id)
            )
        ");
        
        // =========================================================================
        // Webhook Actions System 2.0 - User-defined automation
        // =========================================================================
        
        // Webhook Actions - Define what happens when a webhook arrives
        $db->exec("
            CREATE TABLE IF NOT EXISTS webhook_actions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                endpoint_id INTEGER NOT NULL,
                name TEXT NOT NULL,
                description TEXT,
                
                -- Trigger conditions (when to fire)
                event_filter TEXT,
                condition_expression TEXT,
                
                -- Action configuration
                action_type TEXT NOT NULL,
                action_config TEXT NOT NULL,
                
                -- Payload transformation
                payload_mapping TEXT,
                
                -- Execution control
                priority INTEGER DEFAULT 0,
                is_active INTEGER DEFAULT 1,
                run_async INTEGER DEFAULT 0,
                timeout_seconds INTEGER DEFAULT 30,
                
                -- Statistics
                last_triggered_at TEXT,
                trigger_count INTEGER DEFAULT 0,
                success_count INTEGER DEFAULT 0,
                failure_count INTEGER DEFAULT 0,
                
                -- Timestamps
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
                
                FOREIGN KEY (endpoint_id) REFERENCES webhook_endpoints(id) ON DELETE CASCADE
            )
        ");
        
        // Webhook Action Execution Logs - Track every action run
        $db->exec("
            CREATE TABLE IF NOT EXISTS webhook_action_logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                action_id INTEGER NOT NULL,
                endpoint_id INTEGER NOT NULL,
                
                -- Input/Output
                input_payload TEXT,
                mapped_payload TEXT,
                output_result TEXT,
                
                -- Status
                status TEXT NOT NULL CHECK (status IN ('success', 'failed', 'skipped', 'timeout')),
                error_message TEXT,
                execution_time_ms INTEGER,
                
                -- Context
                trigger_event TEXT,
                client_ip TEXT,
                
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                
                FOREIGN KEY (action_id) REFERENCES webhook_actions(id) ON DELETE CASCADE,
                FOREIGN KEY (endpoint_id) REFERENCES webhook_endpoints(id) ON DELETE CASCADE
            )
        ");
        
        // Provider Configurations - Store API keys/tokens for external services
        $db->exec("
            CREATE TABLE IF NOT EXISTS webhook_provider_configs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                provider TEXT NOT NULL,
                name TEXT NOT NULL,
                
                -- Encrypted config (bot tokens, API keys, etc.)
                config_encrypted TEXT NOT NULL,
                
                -- Status
                is_active INTEGER DEFAULT 1,
                is_verified INTEGER DEFAULT 0,
                last_verified_at TEXT,
                
                -- Timestamps
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
                
                FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
            )
        ");
        
        // Action Templates - Pre-built and user-created templates
        $db->exec("
            CREATE TABLE IF NOT EXISTS webhook_action_templates (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                description TEXT,
                provider TEXT,
                
                -- Template definition
                action_type TEXT NOT NULL,
                action_config_template TEXT NOT NULL,
                payload_mapping_template TEXT,
                default_condition TEXT,
                
                -- Metadata
                icon TEXT,
                category TEXT,
                tags TEXT,
                is_system INTEGER DEFAULT 0,
                is_public INTEGER DEFAULT 1,
                user_id INTEGER,
                
                -- Usage stats
                usage_count INTEGER DEFAULT 0,
                
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
                
                FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
            )
        ");
        
        // Action Chains - Group actions into sequences
        $db->exec("
            CREATE TABLE IF NOT EXISTS webhook_action_chains (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                endpoint_id INTEGER NOT NULL,
                name TEXT NOT NULL,
                description TEXT,
                
                -- Chain configuration
                execution_mode TEXT DEFAULT 'sequential' CHECK (execution_mode IN ('sequential', 'parallel', 'conditional')),
                stop_on_failure INTEGER DEFAULT 1,
                
                -- Trigger conditions
                event_filter TEXT,
                condition_expression TEXT,
                
                -- Status
                is_active INTEGER DEFAULT 1,
                priority INTEGER DEFAULT 0,
                
                -- Statistics
                last_triggered_at TEXT,
                trigger_count INTEGER DEFAULT 0,
                
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
                
                FOREIGN KEY (endpoint_id) REFERENCES webhook_endpoints(id) ON DELETE CASCADE
            )
        ");
        
        // Chain Members - Actions within a chain
        $db->exec("
            CREATE TABLE IF NOT EXISTS webhook_chain_members (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                chain_id INTEGER NOT NULL,
                action_id INTEGER NOT NULL,
                
                -- Order and conditions
                position INTEGER NOT NULL,
                condition_expression TEXT,
                
                -- Input mapping (use output from previous action)
                input_from_previous INTEGER DEFAULT 0,
                input_mapping TEXT,
                
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                
                FOREIGN KEY (chain_id) REFERENCES webhook_action_chains(id) ON DELETE CASCADE,
                FOREIGN KEY (action_id) REFERENCES webhook_actions(id) ON DELETE CASCADE
            )
        ");
        
        // Create indexes for performance
        $db->exec("CREATE INDEX IF NOT EXISTS idx_users_email ON users(email)");
        $db->exec("CREATE INDEX IF NOT EXISTS idx_webhooks_user_id ON webhooks(user_id)");
        $db->exec("CREATE INDEX IF NOT EXISTS idx_webhooks_is_active ON webhooks(is_active)");
        $db->exec("CREATE INDEX IF NOT EXISTS idx_webhook_deliveries_webhook_id ON webhook_deliveries(webhook_id)");
        $db->exec("CREATE INDEX IF NOT EXISTS idx_webhook_deliveries_next_retry ON webhook_deliveries(next_retry_at)");
        $db->exec("CREATE INDEX IF NOT EXISTS idx_webhook_endpoints_key ON webhook_endpoints(endpoint_key)");
        $db->exec("CREATE INDEX IF NOT EXISTS idx_webhook_pending_execute ON webhook_pending(execute_at)");
        $db->exec("CREATE INDEX IF NOT EXISTS idx_users_uuid ON users(uuid)");
        $db->exec("CREATE INDEX IF NOT EXISTS idx_webauthn_user_id ON webauthn_credentials(user_id)");
        $db->exec("CREATE INDEX IF NOT EXISTS idx_webauthn_credential_id ON webauthn_credentials(credential_id)");
        $db->exec("CREATE INDEX IF NOT EXISTS idx_refresh_tokens_user_id ON refresh_tokens(user_id)");
        $db->exec("CREATE INDEX IF NOT EXISTS idx_refresh_tokens_hash ON refresh_tokens(token_hash)");
        $db->exec("CREATE INDEX IF NOT EXISTS idx_sessions_user_id ON sessions(user_id)");
        $db->exec("CREATE INDEX IF NOT EXISTS idx_login_attempts_email ON login_attempts(email)");
        $db->exec("CREATE INDEX IF NOT EXISTS idx_login_attempts_ip ON login_attempts(ip_address)");
        
        // Webhook queue indexes
        $db->exec("CREATE INDEX IF NOT EXISTS idx_webhook_queue_status ON webhook_queue(status, next_attempt_at)");
        $db->exec("CREATE INDEX IF NOT EXISTS idx_webhook_queue_webhook ON webhook_queue(webhook_id)");
        $db->exec("CREATE INDEX IF NOT EXISTS idx_processed_events_cleanup ON webhook_processed_events(processed_at)");
        
        // Webhook Actions 2.0 indexes
        $db->exec("CREATE INDEX IF NOT EXISTS idx_webhook_actions_endpoint ON webhook_actions(endpoint_id)");
        $db->exec("CREATE INDEX IF NOT EXISTS idx_webhook_actions_active ON webhook_actions(is_active)");
        $db->exec("CREATE INDEX IF NOT EXISTS idx_webhook_actions_type ON webhook_actions(action_type)");
        $db->exec("CREATE INDEX IF NOT EXISTS idx_webhook_action_logs_action ON webhook_action_logs(action_id)");
        $db->exec("CREATE INDEX IF NOT EXISTS idx_webhook_action_logs_endpoint ON webhook_action_logs(endpoint_id)");
        $db->exec("CREATE INDEX IF NOT EXISTS idx_webhook_action_logs_status ON webhook_action_logs(status)");
        $db->exec("CREATE INDEX IF NOT EXISTS idx_webhook_action_logs_created ON webhook_action_logs(created_at)");
        $db->exec("CREATE INDEX IF NOT EXISTS idx_webhook_provider_configs_user ON webhook_provider_configs(user_id)");
        $db->exec("CREATE INDEX IF NOT EXISTS idx_webhook_provider_configs_provider ON webhook_provider_configs(provider)");
        $db->exec("CREATE INDEX IF NOT EXISTS idx_webhook_action_templates_category ON webhook_action_templates(category)");
        $db->exec("CREATE INDEX IF NOT EXISTS idx_webhook_action_templates_provider ON webhook_action_templates(provider)");
        $db->exec("CREATE INDEX IF NOT EXISTS idx_webhook_action_chains_endpoint ON webhook_action_chains(endpoint_id)");
        $db->exec("CREATE INDEX IF NOT EXISTS idx_webhook_chain_members_chain ON webhook_chain_members(chain_id)");
        $db->exec("CREATE INDEX IF NOT EXISTS idx_webhook_chain_members_position ON webhook_chain_members(chain_id, position)");

        // =========================================================================
        // Forms: Captcha Configuration (moved off api/external/captcha.json)
        // =========================================================================
        //
        // Previously stored in a flat-file (api/external/captcha.json) that was
        // never wholesale-serialized into an API response, specifically so a
        // secret could never leak through a "return the whole form definition"
        // endpoint. Moved into system.sqlite for write concurrency (SQLite's
        // WAL mode + busy_timeout handles concurrent reads/writes far better
        // than a lock-file-less read-modify-write JSON file did). The
        // no-wholesale-serialization guarantee is preserved in code: only
        // CaptchaConfigStore ever queries these tables, and only ever returns
        // masked projections to API responses (see maskedProvider() /
        // maskedFormConfig()). Secrets remain Defuse-encrypted at rest.

        // Global provider key pairs (one row per real provider: turnstile,
        // recaptcha_v2, recaptcha_v3).
        $db->exec("
            CREATE TABLE IF NOT EXISTS form_captcha_providers (
                provider TEXT PRIMARY KEY,
                site_key TEXT DEFAULT NULL,
                secret_key_enc TEXT DEFAULT NULL,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
        ");

        // Per-form captcha override. A row only exists for a form that has an
        // active (non-'none') provider override - mirrors the old file's
        // 'forms' map, where the absence of a key meant provider=none.
        $db->exec("
            CREATE TABLE IF NOT EXISTS form_captcha_forms (
                slug TEXT PRIMARY KEY,
                provider TEXT NOT NULL,
                use_custom_keys INTEGER NOT NULL DEFAULT 0,
                site_key TEXT DEFAULT NULL,
                secret_key_enc TEXT DEFAULT NULL,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
        ");

        $db->exec("CREATE INDEX IF NOT EXISTS idx_form_captcha_forms_provider ON form_captcha_forms(provider)");

        // Initialize Cron & Background Worker schema
        \NomadCMS\Cron\CronSchema::ensureTables();
    }
    
    /**
     * Close database connection
     */
    public static function close(): void
    {
        self::$instance = null;
        \NomadCMS\Security\PanicModeService::reset();
    }

    // =========================================================================
    // Extended RBAC: Built-in System Roles Seeding
    // =========================================================================

    /**
     * Seed the 3 built-in system roles if they do not already exist.
     *
     * - super_admin: full, unrestricted access (is_system, cannot be deleted/edited)
     * - editor: content/media/versions management on all slots
     * - viewer: read-only access on all slots
     *
     * Idempotent: safe to call on every schema init. Existing roles (matched by
     * slug) are left untouched so admin customizations to editor/viewer are preserved.
     */
    private static function seedSystemRoles(PDO $db): void
    {
        $definitions = [
            'super_admin' => [
                'name' => 'Super Admin',
                'description' => 'Teljes, korlátlan hozzáférés minden erőforráshoz és slothoz. Rendszer szerepkör, nem törölhető és nem módosítható.',
                'priority' => 1000,
                'slot_access' => ['*'],
                'permissions' => ['*:*:*'],
            ],
            'editor' => [
                'name' => 'Szerkesztő',
                'description' => 'Tartalom és média teljes kezelése minden slothoz.',
                'priority' => 500,
                'slot_access' => ['*'],
                'permissions' => [
                    'content:create:*',
                    'content:read:*',
                    'content:update:*',
                    'content:delete:*',
                    'content:list:*',
                    'media:create:*',
                    'media:read:*',
                    'media:update:*',
                    'media:delete:*',
                    'media:list:*',
                    'versions:read:*',
                    'versions:list:*',
                    'versions:restore:*',
                    // Forms: full administration, but NOT 'forms:decrypt:*'.
                    // An editor manages the forms; reading the personal data
                    // inside encrypted submissions stays a separate, explicit
                    // grant (see the RBACService docblock).
                    'forms:create:*',
                    'forms:read:*',
                    'forms:update:*',
                    'forms:delete:*',
                    'forms:list:*',
                    'forms:export:*',
                    // Analytics: view + export dashboard data, but NOT
                    // 'analytics:manage:*' (settings/manual purge/aggregate
                    // triggers stay admin-only - see viewer/editor split below).
                    'analytics:read:*',
                    'analytics:list:*',
                    'analytics:export:*',
                ],
            ],
            'viewer' => [
                'name' => 'Megfigyelő',
                'description' => 'Csak olvasási jogosultság minden slothoz.',
                'priority' => 100,
                'slot_access' => ['*'],
                'permissions' => [
                    'content:read:*',
                    'content:list:*',
                    'media:read:*',
                    'media:list:*',
                    'versions:read:*',
                    'versions:list:*',
                    // Sees that submissions exist and their metadata; the values
                    // of encrypted submissions stay masked.
                    'forms:read:*',
                    'forms:list:*',
                    // Read-only dashboard access - no export, no settings.
                    'analytics:read:*',
                    'analytics:list:*',
                ],
            ],
        ];

        foreach ($definitions as $slug => $def) {
            $stmt = $db->prepare("SELECT id FROM roles WHERE slug = ?");
            $stmt->execute([$slug]);
            $existing = $stmt->fetch();

            if ($existing) {
                continue; // Already seeded - do not overwrite admin customizations
            }

            $insert = $db->prepare("
                INSERT INTO roles (slug, name, description, is_system, priority, slot_access)
                VALUES (?, ?, ?, 1, ?, ?)
            ");
            $insert->execute([
                $slug,
                $def['name'],
                $def['description'],
                $def['priority'],
                json_encode($def['slot_access']),
            ]);

            $roleId = (int) $db->lastInsertId();

            $permStmt = $db->prepare("
                INSERT INTO role_permissions (role_id, permission) VALUES (?, ?)
            ");
            foreach ($def['permissions'] as $permission) {
                $permStmt->execute([$roleId, $permission]);
            }
        }
    }

    /**
     * Backfill role_slug for legacy users created before the Extended RBAC
     * migration (e.g. the initial installer super admin, or users created
     * via UserRepository::create() without an explicit role).
     *
     * Idempotent: only touches rows where role_slug IS NULL, using the exact
     * same precedence rules as RoleRepository::getUserRole()'s runtime fallback:
     *   1. is_admin = 1        -> 'super_admin'
     *   2. legacy role = 'editor' -> 'editor'
     *   3. otherwise            -> 'viewer'
     *
     * This ensures role_slug (used directly by UI components like the Users
     * edit modal) always reflects the same role the backend actually enforces,
     * instead of relying on a runtime-only fallback that never touches the DB.
     */
    private static function backfillLegacyRoleSlugs(PDO $db): void
    {
        $db->exec("UPDATE users SET role_slug = 'super_admin' WHERE role_slug IS NULL AND is_admin = 1");
        $db->exec("UPDATE users SET role_slug = 'editor' WHERE role_slug IS NULL AND role = 'editor'");
        $db->exec("UPDATE users SET role_slug = 'viewer' WHERE role_slug IS NULL");
    }

    /**
     * Garbage Collection: Delete old tokens
     * Deletes tokens expired more than 30 days ago to prevent database bloat
     */
    public static function cleanupTokens(): int
    {
        $db = AuthDatabase::getInstance();
        
        // Delete tokens expired or revoked more than 30 days ago
        $stmt = $db->prepare("
            DELETE FROM refresh_tokens 
            WHERE expires_at < datetime('now', '-30 days')
               OR (revoked = 1 AND revoked_at < datetime('now', '-30 days'))
        ");
        
        $stmt->execute();
        return $stmt->rowCount();
    }
    
    /**
     * Garbage Collection: Delete expired sessions
     * Deletes sessions expired more than 7 days ago to prevent database bloat
     */
    public static function cleanupSessions(): int
    {
        $db = AuthDatabase::getInstance();
        
        // Delete sessions expired more than 7 days ago
        $stmt = $db->prepare("
            DELETE FROM sessions 
            WHERE expires_at < datetime('now', '-7 days')
        ");
        
        $stmt->execute();
        $count = $stmt->rowCount();
        $stmt = $db->prepare('DELETE FROM auth_sessions WHERE expires_at<?');
        $stmt->execute([time() - 2592000]);
        return $count + $stmt->rowCount();
    }
    
    /**
     * Garbage Collection: Delete stale user invitations
     *
     * Removes invitations that expired, were revoked or were consumed more
     * than 30 days ago. Recent rows are kept so the admin UI can still show
     * "invitation expired" and so the audit trail (first_used_at / consumed_at)
     * survives long enough to be useful.
     */
    public static function cleanupInvitations(): int
    {
        $db = AuthDatabase::getInstance();

        $stmt = $db->prepare("
            DELETE FROM user_invitations
            WHERE expires_at < datetime('now', '-30 days')
               OR (revoked_at IS NOT NULL AND revoked_at < datetime('now', '-30 days'))
               OR (consumed_at IS NOT NULL AND consumed_at < datetime('now', '-30 days'))
        ");

        $stmt->execute();
        return $stmt->rowCount();
    }
    
    // =========================================================================
    // System Settings (Key-Value Store)
    // =========================================================================
    
    /**
     * Get a system setting by key
     * 
     * @param string $key Setting key
     * @return string|null Setting value or null if not found
     */
    public static function getSetting(string $key): ?string
    {
        $db = self::getInstance();
        $stmt = $db->prepare("SELECT value FROM system_settings WHERE key = ?");
        $stmt->execute([$key]);
        $result = $stmt->fetch();
        return $result ? $result['value'] : null;
    }
    
    /**
     * Set a system setting (upsert)
     * 
     * @param string $key Setting key
     * @param string $value Setting value
     * @return bool Success
     */
    public static function setSetting(string $key, string $value): bool
    {
        $db = self::getInstance();
        $stmt = $db->prepare("
            INSERT INTO system_settings (key, value, updated_at) 
            VALUES (?, ?, datetime('now'))
            ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = datetime('now')
        ");
        return $stmt->execute([$key, $value]);
    }
    
    /**
     * Delete a system setting
     * 
     * @param string $key Setting key
     * @return bool Success
     */
    public static function deleteSetting(string $key): bool
    {
        $db = self::getInstance();
        $stmt = $db->prepare("DELETE FROM system_settings WHERE key = ?");
        return $stmt->execute([$key]);
    }
}
