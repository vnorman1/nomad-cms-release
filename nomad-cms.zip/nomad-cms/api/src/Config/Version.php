<?php
/**
 * NOMAD CMS - Version Configuration
 * Centralized version information for the CMS
 * 
 * Generated compatibility facade for the root version.json source of truth.
 * All UI components should fetch this from the API.
 */

declare(strict_types=1);

namespace NomadCMS\Config;

final class Version
{
    // Current CMS Version - INCREMENT THIS FOR NEW RELEASES
    public const VERSION = '1.0.0';
    
    // Build information
    public const BUILD_DATE = '2026-10-14';
    public const CODENAME = 'Genesis';
    public const BUILD_ID = '8454a5e6352b583b6324fed5c44847e59250b851';
    public const STORAGE_EPOCH = 1;
    
    // Minimum requirements
    public const MIN_PHP_VERSION = '8.2.0';
    public const MIN_NODE_VERSION = '18.0.0';
    
    /**
     * Get full version information
     */
    public static function getInfo(): array
    {
        return [
            'version' => self::VERSION,
            'buildDate' => self::BUILD_DATE,
            'codename' => self::CODENAME,
            'php' => PHP_VERSION,
            'buildId' => self::BUILD_ID,
            'storageEpoch' => self::STORAGE_EPOCH,
            'requirements' => [
                'php' => self::MIN_PHP_VERSION,
                'node' => self::MIN_NODE_VERSION,
            ],
        ];
    }
    
    /**
     * Get version as semver parts
     */
    public static function getParts(): array
    {
        $parts = explode('.', self::VERSION);
        return [
            'major' => (int) ($parts[0] ?? 0),
            'minor' => (int) ($parts[1] ?? 0),
            'patch' => (int) ($parts[2] ?? 0),
        ];
    }
    
    /**
     * Compare version with another (returns -1, 0, or 1)
     */
    public static function compare(string $other): int
    {
        return version_compare(self::VERSION, $other);
    }
}
