<?php
/**
 * NOMAD CMS - Security Configuration
 * Centralized security constants and settings (all from .env)
 */

declare(strict_types=1);

namespace NomadCMS\Config;

final class Security
{
    // JWT Settings (defaults)
    // SECURITY: default algorithm is RS256 (asymmetric). If JWT_ALGORITHM is
    // ever missing/unset in the environment, the system must not silently
    // fall back to a symmetric algorithm (HS256) - RS256 requires a private
    // key that only the issuing server holds, which is a safer failure mode
    // than falling back to a shared secret that may also be present in the
    // environment for legacy/migration reasons (see getJwtSecret() below).
    public const JWT_ALGORITHM = 'RS256';
    public const JWT_ACCESS_TTL = 900;
    public const JWT_REFRESH_TTL = 604800;
    
    // Token lengths
    public const REFRESH_TOKEN_LENGTH = 64;
    public const CSRF_TOKEN_LENGTH = 32;
    
    /**
     * Get JWT secret from environment
     *
     * SECURITY: this secret is only meaningful for symmetric algorithms
     * (HS256/HS384/HS512). When an asymmetric algorithm (RS/ES/PS) is
     * configured, this value is unused by getJwtSigningKey()/
     * getJwtVerificationKey() - having it present in the environment is
     * unnecessary attack surface (a leaked JWT_SECRET would be immediately
     * exploitable if the algorithm were ever misconfigured back to HS256).
     * We do not silently ignore this risk: log a warning so operators can
     * remove the unused secret from their environment.
     */
    public static function getJwtSecret(): string
    {
        $secret = $_ENV['JWT_SECRET'] ?? throw new \RuntimeException('JWT_SECRET not configured');
        
        if (self::isAsymmetricJwt()) {
            error_log(
                '[Security] JWT_SECRET is set but JWT_ALGORITHM is asymmetric (' . self::getJwtAlgorithm() . '). ' .
                'JWT_SECRET is unused in this mode and should be removed from the environment to reduce attack surface.'
            );
        }
        
        return $secret;
    }
    
    /**
     * Get JWT algorithm from environment or default
     */
    public static function getJwtAlgorithm(): string
    {
        return $_ENV['JWT_ALGORITHM'] ?? self::JWT_ALGORITHM;
    }
    
    /**
     * Check if using asymmetric algorithm (RS256, RS384, RS512, ES256, etc.)
     */
    public static function isAsymmetricJwt(): bool
    {
        $algo = self::getJwtAlgorithm();
        return str_starts_with($algo, 'RS') || str_starts_with($algo, 'ES') || str_starts_with($algo, 'PS');
    }
    
    /**
     * Get JWT private key for RS256 signing
     */
    public static function getJwtPrivateKey(): string
    {
        $keyPath = $_ENV['JWT_PRIVATE_KEY_PATH'] ?? 'keys/private.pem';
        $fullPath = __DIR__ . '/../../' . $keyPath;
        
        if (!file_exists($fullPath)) {
            throw new \RuntimeException("JWT private key not found at: $keyPath");
        }
        
        $key = file_get_contents($fullPath);
        if ($key === false) {
            throw new \RuntimeException("Failed to read JWT private key");
        }
        
        return $key;
    }
    
    /**
     * Get JWT public key for RS256 verification
     */
    public static function getJwtPublicKey(): string
    {
        $keyPath = $_ENV['JWT_PUBLIC_KEY_PATH'] ?? 'keys/public.pem';
        $fullPath = __DIR__ . '/../../' . $keyPath;
        
        if (!file_exists($fullPath)) {
            throw new \RuntimeException("JWT public key not found at: $keyPath");
        }
        
        $key = file_get_contents($fullPath);
        if ($key === false) {
            throw new \RuntimeException("Failed to read JWT public key");
        }
        
        return $key;
    }
    
    /**
     * Get the appropriate JWT key for signing (private key for RS256, secret for HS256)
     */
    public static function getJwtSigningKey(): string
    {
        return self::isAsymmetricJwt() ? self::getJwtPrivateKey() : self::getJwtSecret();
    }
    
    /**
     * Get the appropriate JWT key for verification (public key for RS256, secret for HS256)
     */
    public static function getJwtVerificationKey(): string
    {
        return self::isAsymmetricJwt() ? self::getJwtPublicKey() : self::getJwtSecret();
    }
    
    /**
     * Get password pepper (server-side secret)
     */
    public static function getPasswordPepper(): string
    {
        $pepper = $_ENV['PASSWORD_PEPPER'] ?? '';
        if (empty($pepper) || strpos($pepper, 'CHANGE_ME') !== false) {
            throw new \RuntimeException('PASSWORD_PEPPER not configured properly');
        }
        return $pepper;
    }
    
    /**
     * Get password salt prefix
     */
    public static function getSaltPrefix(): string
    {
        return $_ENV['PASSWORD_SALT_PREFIX'] ?? '';
    }
    
    /**
     * Get Argon2ID password hashing options from .env
     */
    public static function getPasswordOptions(): array
    {
        return [
            'memory_cost' => (int) ($_ENV['PASSWORD_MEMORY_COST'] ?? 65536),
            'time_cost' => (int) ($_ENV['PASSWORD_TIME_COST'] ?? 4),
            'threads' => (int) ($_ENV['PASSWORD_THREADS'] ?? 3),
        ];
    }
    
    /**
     * Get account lock settings
     */
    public static function getAccountLockSettings(): array
    {
        return [
            'max_attempts' => (int) ($_ENV['ACCOUNT_MAX_FAILED_ATTEMPTS'] ?? 5),
            'lock_duration' => (int) ($_ENV['ACCOUNT_LOCK_DURATION'] ?? 900),
        ];
    }
    
    /**
     * Get rate limit settings from .env
     */
    public static function getRateLimitSettings(): array
    {
        return [
            'general' => [
                'max' => (int) ($_ENV['RATE_LIMIT_MAX_REQUESTS'] ?? 300),
                'window' => (int) ($_ENV['RATE_LIMIT_WINDOW_SECONDS'] ?? 60),
            ],
            'login' => [
                'max' => (int) ($_ENV['AUTH_RATE_LIMIT_LOGIN'] ?? 10),
                'window' => (int) ($_ENV['AUTH_RATE_LIMIT_LOGIN_WINDOW'] ?? 300),
            ],
            'totp' => [
                'max' => (int) ($_ENV['AUTH_RATE_LIMIT_TOTP'] ?? 5),
                'window' => (int) ($_ENV['AUTH_RATE_LIMIT_TOTP_WINDOW'] ?? 60),
            ],
            'password_reset' => [
                'max' => (int) ($_ENV['AUTH_RATE_LIMIT_PASSWORD_RESET'] ?? 3),
                'window' => (int) ($_ENV['AUTH_RATE_LIMIT_PASSWORD_RESET_WINDOW'] ?? 3600),
            ],
            'registration' => [
                'max' => (int) ($_ENV['AUTH_RATE_LIMIT_REGISTRATION'] ?? 5),
                'window' => (int) ($_ENV['AUTH_RATE_LIMIT_REGISTRATION_WINDOW'] ?? 3600),
            ],
            // Magic-link (onboarding invitation) redemption. Deliberately
            // stricter than login: a magic link is a bearer secret in a URL, so
            // brute-forcing selectors must stay expensive.
            'magic_link' => [
                'max' => (int) ($_ENV['AUTH_RATE_LIMIT_MAGIC_LINK'] ?? 30),
                'window' => (int) ($_ENV['AUTH_RATE_LIMIT_MAGIC_LINK_WINDOW'] ?? 300),
            ],
            'public_api' => [
                'max' => (int) ($_ENV['PUBLIC_API_RATE_LIMIT_MAX'] ?? 200),
                'window' => (int) ($_ENV['PUBLIC_API_RATE_LIMIT_WINDOW'] ?? 60),
            ],
            'static_serve' => [
                'max' => (int) ($_ENV['STATIC_SERVE_RATE_LIMIT_MAX'] ?? 300),
                'window' => (int) ($_ENV['STATIC_SERVE_RATE_LIMIT_WINDOW'] ?? 60),
            ],
        ];
    }
    
    /**
     * Get WebAuthn Relying Party configuration
     */
    public static function getWebAuthnConfig(): array
    {
        return [
            'enabled' => ($_ENV['AUTH_WEBAUTHN_ENABLED'] ?? 'true') === 'true',
            'rp_name' => $_ENV['WEBAUTHN_RP_NAME'] ?? 'NOMAD CMS',
            'rp_id' => $_ENV['WEBAUTHN_RP_ID'] ?? 'localhost',
            'rp_origin' => $_ENV['WEBAUTHN_RP_ORIGIN'] ?? 'http://localhost:3000',
            'timeout' => (int) ($_ENV['WEBAUTHN_TIMEOUT'] ?? 60000),
            'user_verification' => $_ENV['WEBAUTHN_USER_VERIFICATION'] ?? 'preferred',
        ];
    }
    
    /**
     * Get TOTP configuration
     */
    public static function getTotpConfig(): array
    {
        return [
            'enabled' => ($_ENV['AUTH_TOTP_ENABLED'] ?? 'true') === 'true',
            'issuer' => $_ENV['TOTP_ISSUER'] ?? 'NOMAD CMS',
            'digits' => (int) ($_ENV['TOTP_DIGITS'] ?? 6),
            'period' => (int) ($_ENV['TOTP_PERIOD'] ?? 30),
            'algorithm' => $_ENV['TOTP_ALGORITHM'] ?? 'sha256',
        ];
    }
    
    /**
     * Check if feature is enabled
     */
    public static function isFeatureEnabled(string $feature): bool
    {
        return match ($feature) {
            'totp' => ($_ENV['AUTH_TOTP_ENABLED'] ?? 'true') === 'true',
            'webauthn' => ($_ENV['AUTH_WEBAUTHN_ENABLED'] ?? 'true') === 'true',
            'password' => ($_ENV['AUTH_PASSWORD_ENABLED'] ?? 'true') === 'true',
            'registration' => ($_ENV['AUTH_REGISTRATION_ENABLED'] ?? 'true') === 'true',
            'email_verification' => ($_ENV['AUTH_REQUIRE_EMAIL_VERIFICATION'] ?? 'false') === 'true',
            default => false,
        };
    }

    /**
     * Get IP binding mode
     * 
     * Options:
     * - 'subnet' (default): Binds to /24 (IPv4) or /48 (IPv6). Tolerates egress NAT pools (e.g. universities).
     * - 'disabled': Disables IP binding completely. Ideal for high mobility environments.
     * - 'strict': Full IP match. Requires identical IP on every request.
     */
    public static function getIpBindingMode(): string
    {
        $mode = strtolower(trim($_ENV['AUTH_IP_BINDING'] ?? 'subnet'));
        return match ($mode) {
            'disabled', 'false', 'none', 'off', '0' => 'disabled',
            'strict', 'true', 'full', 'exact', '1' => 'strict',
            default => 'subnet',
        };
    }

    /**
     * Check if IP binding is enabled (either subnet or strict mode)
     */
    public static function isIpBindingEnabled(): bool
    {
        return self::getIpBindingMode() !== 'disabled';
    }
}

