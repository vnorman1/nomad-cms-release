<?php
/**
 * NOMAD CMS — Installation and one-time migration of panic control state.
 * Seeds the singleton when system.sqlite is created, preserving legacy
 * lockdowns. An existing table with a missing row is never silently reseeded.
 * Runtime state is typed SQLite data; the old JSON is migration input only.
 */

declare(strict_types=1);

namespace NomadCMS\Security;

use PDO;

final class PanicModeSchema
{
    public static function ensure(PDO $db, ?string $legacyPath = null, bool $repair = false): void
    {
        if (!$repair && $db->query("SELECT 1 FROM sqlite_master WHERE type='table' AND name='panic_state'")->fetchColumn()) {
            return;
        }
        if (!$repair && $db->query("SELECT 1 FROM sqlite_master WHERE type='table' AND name='panic_schema_marker'")->fetchColumn()) {
            throw new PanicModeException('PANIC_STATE_UNAVAILABLE', 'Previously installed panic state is missing.');
        }

        $ownsTransaction = !$db->inTransaction();
        if ($ownsTransaction) {
            $db->exec('BEGIN IMMEDIATE');
        }
        try {
            // Recheck under the SQLite writer lock: concurrent first requests
            // must not import the JSON twice or overwrite a completed transition.
            if ($repair || !$db->query("SELECT 1 FROM sqlite_master WHERE type='table' AND name='panic_state'")->fetchColumn()) {
                $db->exec('CREATE TABLE IF NOT EXISTS panic_schema_marker(id INTEGER PRIMARY KEY CHECK(id=1))');
                $db->exec('INSERT OR IGNORE INTO panic_schema_marker VALUES(1)');
                $db->exec("CREATE TABLE IF NOT EXISTS panic_state (
                    id INTEGER PRIMARY KEY CHECK(id=1),
                    enabled INTEGER NOT NULL CHECK(enabled IN(0,1)),
                    revision INTEGER NOT NULL CHECK(revision>=0),
                    auth_epoch INTEGER NOT NULL CHECK(auth_epoch>=1),
                    instance_id TEXT NOT NULL,
                    activated_at TEXT,
                    activated_by INTEGER,
                    reason TEXT,
                    sessions_revoked INTEGER NOT NULL DEFAULT 0 CHECK(sessions_revoked>=0),
                    deactivated_at TEXT,
                    deactivated_by INTEGER,
                    updated_at TEXT NOT NULL
                )");
                $db->exec("CREATE TABLE IF NOT EXISTS panic_audit (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    revision INTEGER NOT NULL,
                    action TEXT NOT NULL,
                    admin_id INTEGER,
                    reason TEXT,
                    sessions_revoked INTEGER NOT NULL DEFAULT 0,
                    created_at TEXT NOT NULL
                )");
                $db->exec("CREATE TABLE IF NOT EXISTS panic_outbox (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    revision INTEGER NOT NULL UNIQUE,
                    event TEXT NOT NULL,
                    payload TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    delivered_at TEXT
                )");
                $db->exec('CREATE INDEX IF NOT EXISTS idx_panic_outbox_pending ON panic_outbox(id) WHERE delivered_at IS NULL');

                $legacyPath ??= $_ENV['NOMAD_PANIC_LEGACY_FILE'] ?? dirname(__DIR__, 2) . '/data/panic_mode.json';
                $legacy = self::legacy($legacyPath);
                $now = gmdate('c');
                $revision = 0;
                if ($repair) {
                    $revision = max(
                        (int) $db->query('SELECT COALESCE(MAX(revision),0) FROM panic_state')->fetchColumn(),
                        (int) $db->query('SELECT COALESCE(MAX(revision),0) FROM panic_audit')->fetchColumn()
                    ) + 1;
                    $db->exec('DELETE FROM panic_state');
                    $legacy = ['enabled' => true, 'activated_at' => $now, 'activated_by' => null,
                        'reason' => 'Control state repaired by the hosting operator', 'sessions_revoked' => 0, 'migrated' => false];
                }
                // Legacy refresh cookies must not silently mint new-generation
                // JWTs after this migration. Fresh installations have no rows.
                if ($db->query("SELECT 1 FROM sqlite_master WHERE type='table' AND name='refresh_tokens'")->fetchColumn()) {
                    $db->exec("UPDATE refresh_tokens SET revoked=1,revoked_at=datetime('now') WHERE revoked=0");
                }
                if ($db->query("SELECT 1 FROM sqlite_master WHERE type='table' AND name='sessions'")->fetchColumn()) {
                    $db->exec('DELETE FROM sessions');
                }
                $insert = $db->prepare('INSERT INTO panic_state
                    (id,enabled,revision,auth_epoch,instance_id,activated_at,activated_by,reason,sessions_revoked,updated_at)
                    VALUES(1,?,?,1,?,?,?,?,?,?)');
                $insert->execute([
                    $legacy['enabled'] ? 1 : 0,
                    $revision,
                    bin2hex(random_bytes(16)),
                    $legacy['activated_at'],
                    $legacy['activated_by'],
                    $legacy['reason'],
                    $legacy['sessions_revoked'],
                    $now,
                ]);
                $audit = $db->prepare('INSERT INTO panic_audit(revision,action,reason,created_at) VALUES(?,?,?,?)');
                $audit->execute([$revision, $repair ? 'REPAIRED' : ($legacy['migrated'] ? 'MIGRATED' : 'INITIALIZED'), $legacy['reason'], $now]);
            }
            if ($ownsTransaction) {
                $db->exec('COMMIT');
            }
        } catch (\Throwable $e) {
            if ($ownsTransaction && $db->inTransaction()) {
                $db->exec('ROLLBACK');
            }
            throw $e;
        }
    }

    /** A restored backup must never revive credentials from its old epoch. */
    public static function renewAfterRestore(PDO $db): void
    {
        self::ensure($db);
        $db->exec('PRAGMA synchronous=FULL');
        $db->exec('BEGIN IMMEDIATE');
        try {
            $now = gmdate('c');
            $db->prepare('UPDATE panic_state SET instance_id=?,auth_epoch=auth_epoch+1,revision=revision+1,updated_at=? WHERE id=1')
                ->execute([bin2hex(random_bytes(16)), $now]);
            $db->exec("UPDATE refresh_tokens SET revoked=1,revoked_at=datetime('now') WHERE revoked=0");
            $db->exec('DELETE FROM sessions');
            $db->prepare("INSERT INTO panic_audit(revision,action,reason,created_at) SELECT revision,'RESTORED','Credentials invalidated after backup restore',? FROM panic_state WHERE id=1")
                ->execute([$now]);
            $db->exec('COMMIT');
        } catch (\Throwable $e) {
            if ($db->inTransaction()) {
                $db->exec('ROLLBACK');
            }
            throw $e;
        }
    }

    private static function legacy(string $path): array
    {
        $result = ['enabled' => false, 'activated_at' => null, 'activated_by' => null,
            'reason' => null, 'sessions_revoked' => 0, 'migrated' => false];
        if (!file_exists($path)) {
            return $result;
        }
        $result['migrated'] = true;
        try {
            // Migration input is bounded; unreadable or malformed existing
            // state means lockdown, never an implicit all-clear.
            if (!is_readable($path) || filesize($path) > 65536) {
                throw new \RuntimeException('Invalid legacy panic state');
            }
            $raw = file_get_contents($path);
            if ($raw === false) {
                throw new \RuntimeException('Unreadable legacy panic state');
            }
            $data = json_decode($raw, true, 32, JSON_THROW_ON_ERROR);
            if (!is_array($data) || !isset($data['enabled']) || !is_bool($data['enabled'])) {
                throw new \RuntimeException('Invalid legacy panic state');
            }
            $result['enabled'] = $data['enabled'];
            if ($result['enabled']) {
                $result['activated_at'] = is_string($data['activated_at'] ?? null) ? $data['activated_at'] : gmdate('c');
                $result['activated_by'] = is_int($data['activated_by'] ?? null) ? $data['activated_by'] : null;
                $result['reason'] = is_string($data['reason'] ?? null) ? $data['reason'] : 'Imported legacy lockdown';
                $result['sessions_revoked'] = is_int($data['sessions_revoked'] ?? null)
                    ? max(0, $data['sessions_revoked']) : 0;
            }
        } catch (\Throwable) {
            $result['enabled'] = true;
            $result['activated_at'] = gmdate('c');
            $result['reason'] = 'Legacy panic state could not be verified; recovery required';
        }
        return $result;
    }
}
