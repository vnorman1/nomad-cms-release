<?php
/**
 * NOMAD CMS - Client IP Resolver
 *
 * Single source of truth for resolving the "real" client IP address behind
 * a reverse proxy / CDN, used by rate limiting, request logging, webhook
 * signature/rate-limit checks, and the installer.
 *
 * SECURITY MODEL:
 * - Forwarded-IP headers (X-Forwarded-For, X-Real-IP, CF-Connecting-IP) are
 *   ONLY trusted when the actual TCP peer (REMOTE_ADDR) is itself a
 *   configured trusted proxy (TRUSTED_PROXIES env, comma-separated IPs
 *   and/or CIDR ranges). Any client can send these headers directly -
 *   trusting them unconditionally lets an attacker spoof their IP to bypass
 *   rate limiting, IP allowlists, or pollute audit logs with a fake address.
 * - When TRUSTED_PROXIES is not configured, or REMOTE_ADDR is not in it,
 *   REMOTE_ADDR (the actual TCP peer) is always returned - forwarded headers
 *   are never consulted in that case.
 * - This intentionally mirrors RateLimitMiddleware's pre-existing
 *   TRUSTED_PROXIES-based logic (the correct implementation already used
 *   for rate limiting) rather than the unconditional-trust variant that
 *   RequestLoggerMiddleware and InstallationMiddleware used to have.
 */

declare(strict_types=1);

namespace NomadCMS\Security;

final class ClientIpResolver
{
    /**
     * Official Cloudflare IPv4 CIDR blocks
     * @see https://www.cloudflare.com/ips-v4
     */
    public const CLOUDFLARE_IPV4_RANGES = [
        '173.245.48.0/20',
        '103.21.244.0/22',
        '103.22.200.0/22',
        '103.31.4.0/22',
        '141.101.64.0/18',
        '108.162.192.0/18',
        '190.93.240.0/20',
        '188.114.96.0/20',
        '197.234.240.0/22',
        '198.41.128.0/17',
        '162.158.0.0/15',
        '104.16.0.0/13',
        '104.24.0.0/14',
        '172.64.0.0/13',
        '131.0.72.0/22',
    ];

    /**
     * Official Cloudflare IPv6 CIDR blocks
     * @see https://www.cloudflare.com/ips-v6
     */
    public const CLOUDFLARE_IPV6_RANGES = [
        '2400:cb00::/32',
        '2606:4700::/32',
        '2803:f800::/32',
        '2405:b500::/32',
        '2405:8100::/32',
        '2a06:98c0::/29',
        '2c0f:f248::/32',
    ];

    /**
     * Forwarded-IP headers to check, in priority order, once the direct
     * peer has been confirmed to be a trusted proxy.
     */
    private const FORWARDED_HEADERS = [
        'HTTP_CF_CONNECTING_IP', // Cloudflare (highest priority)
        'HTTP_X_FORWARDED_FOR',  // Standard proxy
        'HTTP_X_REAL_IP',        // Nginx
    ];

    /**
     * Resolve the client IP address for the current request.
     */
    public static function resolve(): string
    {
        $directIp = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';

        $cfExplicitOff = in_array(
            strtolower(trim((string) ($_ENV['CLOUDFLARE_PROXY'] ?? ''))),
            ['false', '0', 'off', 'no'],
            true
        );

        // Fast-path: if CF-Connecting-IP is provided and direct peer is a verified Cloudflare edge IP,
        // safely extract the client IP (unless CLOUDFLARE_PROXY is explicitly disabled).
        if (!$cfExplicitOff && !empty($_SERVER['HTTP_CF_CONNECTING_IP']) && self::isCloudflareIp($directIp)) {
            $ip = trim(explode(',', (string) $_SERVER['HTTP_CF_CONNECTING_IP'])[0]);
            if (filter_var($ip, FILTER_VALIDATE_IP)) {
                return $ip;
            }
        }

        $trustedProxies = self::getTrustedProxies();

        // No trusted proxies configured, or the direct peer isn't one of
        // them: never consult forwarded headers, they are attacker-controlled.
        if (empty($trustedProxies) || !self::isIpInRanges($directIp, $trustedProxies)) {
            return $directIp;
        }

        foreach (self::FORWARDED_HEADERS as $header) {
            if (!empty($_SERVER[$header])) {
                // X-Forwarded-For may contain multiple IPs; the first is the
                // original client.
                $ip = trim(explode(',', (string) $_SERVER[$header])[0]);

                if (filter_var($ip, FILTER_VALIDATE_IP)) {
                    return $ip;
                }
            }
        }

        return $directIp;
    }

    /**
     * Check if an IP address belongs to official Cloudflare edge IP ranges.
     */
    public static function isCloudflareIp(string $ip): bool
    {
        return self::isIpInRanges($ip, self::CLOUDFLARE_IPV4_RANGES)
            || self::isIpInRanges($ip, self::CLOUDFLARE_IPV6_RANGES);
    }

    /**
     * Get list of all configured and expanded trusted proxies.
     *
     * @return array<string>
     */
    public static function getTrustedProxies(): array
    {
        $rawProxies = array_filter(
            array_map('trim', explode(',', $_ENV['TRUSTED_PROXIES'] ?? ''))
        );

        $expanded = [];
        $hasCloudflare = false;

        $cfSetting = strtolower(trim((string) ($_ENV['CLOUDFLARE_PROXY'] ?? $_ENV['CLOUDFLARE_ENABLED'] ?? '')));
        if (in_array($cfSetting, ['true', '1', 'on', 'yes'], true)) {
            $hasCloudflare = true;
        }

        foreach ($rawProxies as $proxy) {
            $lower = strtolower($proxy);
            if ($lower === 'cloudflare' || $lower === 'cf') {
                $hasCloudflare = true;
            } else {
                $expanded[] = $proxy;
            }
        }

        if ($hasCloudflare) {
            $expanded = array_merge($expanded, self::CLOUDFLARE_IPV4_RANGES, self::CLOUDFLARE_IPV6_RANGES);
        }

        return array_values(array_unique($expanded));
    }

    /**
     * Check if an IP is within any of the given CIDR ranges / exact IPs.
     *
     * @param array<string> $ranges
     */
    public static function isIpInRanges(string $ip, array $ranges): bool
    {
        foreach ($ranges as $range) {
            if (self::isIpInCidr($ip, $range)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Check if an IP is within a CIDR range (or equals it, if no CIDR suffix).
     * Supports both IPv4 (0-32 bits) and IPv6 (0-128 bits).
     */
    public static function isIpInCidr(string $ip, string $cidr): bool
    {
        if (str_contains($cidr, '/')) {
            [$subnet, $bitsStr] = explode('/', $cidr, 2);
            $bits = is_numeric($bitsStr) ? (int) $bitsStr : -1;
        } else {
            $subnet = $cidr;
            $bits = null;
        }

        // IPv4 evaluation
        if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
            if (!filter_var($subnet, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
                return false;
            }
            if ($bits === null) {
                return $ip === $subnet;
            }
            if ($bits < 0 || $bits > 32) {
                return false;
            }
            if ($bits === 0) {
                return true;
            }

            $ipLong = ip2long($ip);
            $subnetLong = ip2long($subnet);
            if ($ipLong === false || $subnetLong === false) {
                return false;
            }

            $mask = -1 << (32 - $bits);
            return ($ipLong & $mask) === ($subnetLong & $mask);
        }

        // IPv6 evaluation
        if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6)) {
            if (!filter_var($subnet, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6)) {
                return false;
            }
            $ipPacked = inet_pton($ip);
            $subnetPacked = inet_pton($subnet);
            if ($ipPacked === false || $subnetPacked === false) {
                return false;
            }

            if ($bits === null) {
                return $ipPacked === $subnetPacked;
            }
            if ($bits < 0 || $bits > 128) {
                return false;
            }
            if ($bits === 0) {
                return true;
            }

            $bytes = (int) ($bits / 8);
            $remainderBits = $bits % 8;
            $mask = str_repeat("\xff", $bytes);
            if ($remainderBits > 0) {
                $mask .= chr((0xff << (8 - $remainderBits)) & 0xff);
            }
            $mask = str_pad($mask, 16, "\x00");

            return ($ipPacked & $mask) === ($subnetPacked & $mask);
        }

        return false;
    }
}
