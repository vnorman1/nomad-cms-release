<?php
/**
 * NOMAD CMS — Typed panic control failures.
 * Keeps infrastructure errors out of HTTP responses and distinguishes a
 * rejected transition from an incomplete transition that must stay closed.
 */

declare(strict_types=1);

namespace NomadCMS\Security;

final class PanicModeException extends \RuntimeException
{
    public function __construct(
        public readonly string $errorCode,
        string $message,
        public readonly int $httpStatus = 503
    ) {
        parent::__construct($message, $httpStatus);
    }
}
