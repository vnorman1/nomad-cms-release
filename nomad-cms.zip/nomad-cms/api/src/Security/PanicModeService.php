<?php
/**
 * NOMAD CMS - Panic Mode Service 🚨
 * 
 * "Don't Panic!" - The Hitchhiker's Guide to the Galaxy
 * 
 * Emergency read-only mode for when things get... interesting.
 * When enabled:
 * - Published anonymous reads and scoped administrator recovery are allowed
 * - All active sessions are revoked
 * - The entire system goes into lockdown mode
 * 
 * Perfect for:
 * - Suspected security breaches
 * - Database maintenance
 * - When your coffee hasn't kicked in yet
 * - Mercury retrograde
 */

declare(strict_types=1);

namespace NomadCMS\Security;

use NomadCMS\Database\AuthDatabase;
use NomadCMS\Services\RBACService;

/** SQLite owns the state; the marker is an independent emergency stop. */
final class PanicModeService
{
    private static ?PanicStateStore $stateStore = null;
    private static bool $readOnlyRequest = false;

    public static function store(): PanicStateStore
    {
        return self::$stateStore ??= new PanicStateStore();
    }

    /** Release the dedicated handle before replacing a system.sqlite inode. */
    public static function reset(): void
    {
        self::$stateStore = null;
        self::$readOnlyRequest = false;
    }

    public static function isActive(): bool
    {
        return self::store()->isActive();
    }

    /** Public status deliberately excludes token-generation identifiers. */
    public static function getStatus(): array
    {
        $state = self::store()->status();
        $state['enabled'] = $state['enabled'] || self::store()->hasMarker();
        unset($state['auth_epoch'], $state['instance_id'], $state['id']);
        $state['funny_message'] = self::getFunnyMessage($state['enabled']);
        return $state;
    }

    public static function setReadOnlyRequest(bool $readOnly): void
    {
        self::$readOnlyRequest = $readOnly;
    }

    public static function isReadOnlyRequest(): bool
    {
        return self::$readOnlyRequest;
    }

    /** Enable panic mode only after existing mutation leases have drained. */
    public static function enable(int $adminId, ?string $reason = null, ?int $expectedRevision = null): array
    {
        $result = self::store()->transition(true, $adminId, $reason, $expectedRevision);
        return $result + ['success' => true, 'message' => 'Emergency read-only mode activated.',
            'funny_message' => self::getFunnyMessage(true)];
    }

    /** An explicit revision prevents stale recovery screens from reopening work. */
    public static function disable(int $adminId, ?int $expectedRevision = null): array
    {
        $result = self::store()->transition(false, $adminId, null, $expectedRevision);
        return $result + ['success' => true, 'message' => 'Emergency read-only mode deactivated. Please sign in again.',
            'funny_message' => self::getFunnyMessage(false)];
    }

    /** Resolve recovery permission from the current user row, never token claims. */
    public static function requireRecoveryAdmin(array $user): void
    {
        $db = AuthDatabase::getInstance(false);
        $stmt = $db->prepare('SELECT * FROM users WHERE id=? AND uuid=?');
        $stmt->execute([$user['id'] ?? 0, $user['uuid'] ?? '']);
        $current = $stmt->fetch();
        if (!$current || !empty($current['is_new_user'])
            || (!empty($current['locked_until']) && strtotime($current['locked_until']) > time())
            || (empty($current['is_admin']) && !RBACService::hasPermission($current, 'system:admin:*'))) {
            throw new PanicModeException('PANIC_RECOVERY_FORBIDDEN', 'Recovery requires a current system administrator.', 403);
        }
    }

    /** Bind a newly authenticated session to the current revocation generation. */
    public static function tokenClaims(array $user, bool $freshAuthentication): array
    {
        $state = self::store()->state();
        $claims = ['auth_epoch' => $state['auth_epoch'], 'auth_instance' => $state['instance_id']];
        if (self::isActive()) {
            if (!$freshAuthentication) {
                throw new PanicModeException('PANIC_MODE_ACTIVE', 'A fresh administrator login is required.');
            }
            self::requireRecoveryAdmin($user);
            $claims['panic_recovery'] = true;
            $claims['auth_time'] = time();
        }
        return $claims;
    }

    /** Central enforcement also covers endpoints that decode JWTs directly. */
    public static function validateTokenClaims(object $token): void
    {
        try {
            $state = self::store()->state();
        } catch (\Throwable) {
            throw new PanicModeException('PANIC_STATE_UNAVAILABLE', 'Session control storage is unavailable.');
        }
        if (!isset($token->auth_epoch, $token->auth_instance)
            || !is_int($token->auth_epoch) || $token->auth_epoch !== $state['auth_epoch']
            || !is_string($token->auth_instance) || !hash_equals($state['instance_id'], $token->auth_instance)) {
            throw new PanicModeException('SESSION_REVOKED', 'Session revoked. Please sign in again.', 401);
        }
        if (!empty($token->panic_recovery)) {
            if ($token->panic_recovery !== true || !self::isActive()
                || !isset($token->auth_time) || !is_int($token->auth_time)
                || $token->auth_time > time() || $token->auth_time < time() - 300
                || !PanicModePolicy::allowsRecoveryToken()) {
                throw new PanicModeException('PANIC_RECOVERY_SCOPE', 'Recovery sessions can only manage emergency lockdown.', 403);
            }
            self::requireRecoveryAdmin((array) $token->user);
        } elseif (self::isActive()) {
            throw new PanicModeException('SESSION_REVOKED', 'A fresh administrator login is required.', 401);
        }
    }

    /**
     * Get a funny message based on panic state
     */
    private static function getFunnyMessage(bool $isPanicking): string
    {
        if ($isPanicking) {
            $messages = [
                "🔴 RED ALERT! Only reading allowed. Writing is so last century anyway.",
                "🚨 Panic mode ON! The system is now in witness protection program.",
                "⚠️ Emergency lockdown! Even the database is holding its breath.",
                "🔒 Read-only mode activated. Think of it as a museum - look but don't touch!",
                "🛑 HALT! System frozen like a deer in headlights. Only GET requests allowed.",
                "🆘 Mayday mayday! All write operations have been... written off.",
                "🚫 The 'write' in read/write has left the building. Elvis style.",
            ];
        } else {
            $messages = [
                "✅ All clear! The towel is no longer needed.",
                "🟢 Back to normal! Write operations welcome home.",
                "☀️ Crisis averted! The database is doing a happy dance.",
                "🎉 Panic over! Feel free to CREATE, UPDATE, DELETE with reckless abandon!",
                "👍 Systems nominal. You may now resume your regularly scheduled programming.",
                "🌈 The storm has passed! Full functionality restored.",
                "🦸 Hero admin saved the day! Normal operations resume.",
            ];
        }
        
        return $messages[array_rand($messages)];
    }
    
}
