<?php

/**
 * NOMAD CMS - Deadline-bound recursive DNS client.
 * Uses only explicitly configured or operating-system numeric nameservers, with
 * nonblocking UDP/TCP and bounded RFC 1035 parsing; never invokes blocking libc DNS.
 * Wire format: https://www.rfc-editor.org/rfc/rfc1035#section-4.1
 */

declare(strict_types=1);

namespace NomadCMS\Security;

/** Small per-attempt resolver for notification transports with a shared deadline. */
final class DeadlineDns
{
    public static function resolve(string $host, float $deadline): string
    {
        if (microtime(true) >= $deadline) {
            throw new \RuntimeException('dns_timeout');
        }
        $host = strtolower(rtrim(trim($host, '[]'), '.'));
        if (filter_var($host, FILTER_VALIDATE_IP)) {
            return $host;
        }
        if ($host === 'localhost') {
            return '127.0.0.1';
        }
        if (strlen($host) > 253 || !preg_match('/^[a-z0-9-]+(?:\.[a-z0-9-]+)*$/D', $host)) {
            throw new \RuntimeException('dns_invalid_host');
        }
        $hosts = @file_get_contents('/etc/hosts', false, null, 0, 16384);
        foreach (explode("\n", $hosts ?: '') as $line) {
            $fields = preg_split('/\s+/', trim(explode('#', $line, 2)[0]));
            $address = array_shift($fields);
            if (filter_var($address, FILTER_VALIDATE_IP) && in_array($host, array_map('strtolower', $fields), true)) {
                return $address;
            }
        }
        $servers = self::servers();
        foreach ([1, 28] as $type) {
            $name = $host;
            for ($hop = 0; $hop < 5; $hop++) {
                $answer = null;
                foreach ($servers as $server) {
                    $budget = min($deadline, microtime(true) + 1.5);
                    if ($budget <= microtime(true)) {
                        throw new \RuntimeException('dns_timeout');
                    }
                    try {
                        $answer = self::query($server, $name, $type, $budget);
                        break;
                    } catch (\RuntimeException) {
                        // Try another configured recursive server within the same total budget.
                    }
                }
                if (!$answer) {
                    break;
                }
                if ($answer['addresses']) {
                    return $answer['addresses'][0];
                }
                if (!$answer['canonical'] || $answer['canonical'] === $name) {
                    break;
                }
                $name = $answer['canonical'];
            }
        }
        throw new \RuntimeException('dns_resolution_failed');
    }

    private static function servers(): array
    {
        $configured = trim((string) ($_ENV['NOTIFICATION_DNS_SERVERS'] ?? ''));
        $servers = $configured !== '' ? preg_split('/[\s,]+/', $configured) : [];
        if (!$servers) {
            $configuration = @file_get_contents('/etc/resolv.conf', false, null, 0, 16384);
            preg_match_all('/^\s*nameserver\s+([^\s#]+)/m', $configuration ?: '', $matches);
            $servers = $matches[1];
        }
        $servers = array_slice(array_values(array_filter($servers, static fn(string $ip): bool => filter_var($ip, FILTER_VALIDATE_IP) !== false)), 0, 3);
        if (!$servers) {
            throw new \RuntimeException('dns_resolver_unavailable');
        }
        return $servers;
    }

    private static function query(string $server, string $name, int $type, float $deadline): array
    {
        $question = '';
        foreach (explode('.', $name) as $label) {
            if (strlen($label) > 63) {
                throw new \RuntimeException('dns_invalid_host');
            }
            $question .= chr(strlen($label)) . $label;
        }
        $question .= "\0" . pack('nn', $type, 1);
        $id = random_int(0, 65535);
        $request = pack('nnnnnn', $id, 0x0100, 1, 0, 0, 0) . $question;
        $address = str_contains($server, ':') ? '[' . $server . ']' : $server;
        $port = max(1, min(65535, (int) ($_ENV['NOTIFICATION_DNS_PORT'] ?? 53)));
        $stream = @stream_socket_client('udp://' . $address . ':' . $port, $errno, $error, max(0.001, $deadline - microtime(true)));
        if (!$stream) {
            throw new \RuntimeException('dns_connection_failed');
        }
        try {
            stream_set_blocking($stream, false);
            self::write($stream, $request, $deadline);
            self::ready($stream, true, $deadline);
            $packet = (string) fread($stream, 65535);
        } finally {
            fclose($stream);
        }
        if (strlen($packet) >= 12 && (unpack('n', substr($packet, 2, 2))[1] & 0x0200)) {
            $stream = @stream_socket_client('tcp://' . $address . ':' . $port, $errno, $error, max(0.001, $deadline - microtime(true)));
            if (!$stream) {
                throw new \RuntimeException('dns_connection_failed');
            }
            try {
                stream_set_blocking($stream, false);
                self::write($stream, pack('n', strlen($request)) . $request, $deadline);
                $size = unpack('n', self::read($stream, 2, $deadline))[1];
                $packet = self::read($stream, $size, $deadline);
            } finally {
                fclose($stream);
            }
        }
        return self::answer($packet, $id, $name, $type);
    }

    private static function ready($stream, bool $reading, float $deadline): void
    {
        $remaining = $deadline - microtime(true);
        if ($remaining <= 0) {
            throw new \RuntimeException('dns_timeout');
        }
        $read = $reading ? [$stream] : [];
        $write = $reading ? [] : [$stream];
        $except = [];
        if (@stream_select($read, $write, $except, (int) $remaining, (int) (($remaining - (int) $remaining) * 1000000)) !== 1) {
            throw new \RuntimeException('dns_timeout');
        }
    }

    private static function write($stream, string $data, float $deadline): void
    {
        while ($data !== '') {
            self::ready($stream, false, $deadline);
            $length = fwrite($stream, $data);
            if (!$length) {
                throw new \RuntimeException('dns_connection_failed');
            }
            $data = substr($data, $length);
        }
    }

    private static function read($stream, int $length, float $deadline): string
    {
        $data = '';
        while (strlen($data) < $length) {
            self::ready($stream, true, $deadline);
            $part = fread($stream, $length - strlen($data));
            if ($part === false || ($part === '' && feof($stream))) {
                throw new \RuntimeException('dns_connection_failed');
            }
            $data .= $part;
        }
        return $data;
    }

    /** Parse only the answer section and the queried owner/CNAME chain, never unrelated glue. */
    private static function answer(string $packet, int $id, string $host, int $type): array
    {
        if (strlen($packet) < 12) {
            throw new \RuntimeException('dns_invalid_response');
        }
        $header = unpack('nid/nflags/nquestions/nanswers/nauthority/nadditional', substr($packet, 0, 12));
        if ($header['id'] !== $id || ($header['flags'] & 0xFA0F) !== 0x8000 || $header['questions'] !== 1 || $header['answers'] > 128) {
            throw new \RuntimeException('dns_invalid_response');
        }
        $offset = 12;
        $question = self::name($packet, $offset);
        if ($question !== $host || strlen($packet) < $offset + 4 || substr($packet, $offset, 4) !== pack('nn', $type, 1)) {
            throw new \RuntimeException('dns_invalid_response');
        }
        $offset += 4;
        $records = [];
        $aliases = [];
        for ($i = 0; $i < $header['answers']; $i++) {
            $owner = self::name($packet, $offset);
            if (strlen($packet) < $offset + 10) {
                throw new \RuntimeException('dns_invalid_response');
            }
            $record = unpack('ntype/nclass/Nttl/nlength', substr($packet, $offset, 10));
            $offset += 10;
            $end = $offset + $record['length'];
            if ($end > strlen($packet)) {
                throw new \RuntimeException('dns_invalid_response');
            }
            if ($record['class'] === 1 && $record['type'] === 5) {
                $position = $offset;
                $aliases[$owner] = self::name($packet, $position);
                if ($position > $end) {
                    throw new \RuntimeException('dns_invalid_response');
                }
            } elseif ($record['class'] === 1 && $record['type'] === $type && $record['length'] === ($type === 1 ? 4 : 16)) {
                $records[$owner][] = inet_ntop(substr($packet, $offset, $record['length']));
            }
            $offset = $end;
        }
        $canonical = $host;
        for ($hop = 0; isset($aliases[$canonical]) && $hop < 5; $hop++) {
            $canonical = $aliases[$canonical];
        }
        return ['addresses' => $records[$canonical] ?? [], 'canonical' => $canonical === $host ? null : $canonical];
    }

    private static function name(string $packet, int &$offset): string
    {
        $position = $offset;
        $end = null;
        $labels = [];
        for ($steps = 0; $steps < 128; $steps++) {
            if ($position >= strlen($packet)) {
                break;
            }
            $length = ord($packet[$position++]);
            if ($length === 0) {
                $offset = $end ?? $position;
                $name = strtolower(implode('.', $labels));
                if (strlen($name) > 253) {
                    break;
                }
                return $name;
            }
            if (($length & 0xC0) === 0xC0 && $position < strlen($packet)) {
                $pointer = (($length & 0x3F) << 8) | ord($packet[$position++]);
                if ($pointer >= $position - 2) {
                    break;
                }
                $end ??= $position;
                $position = $pointer;
            } elseif ($length <= 63 && $position + $length <= strlen($packet)) {
                $label = substr($packet, $position, $length);
                if (!preg_match('/^[a-z0-9_-]+$/iD', $label)) {
                    break;
                }
                $labels[] = $label;
                $position += $length;
            } else {
                break;
            }
        }
        throw new \RuntimeException('dns_invalid_response');
    }
}
