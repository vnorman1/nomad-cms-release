<?php
/**
 * NOMAD CMS - API Key Service
 *
 * Manages API keys for external integrations (webhooks, email services, etc.)
 * Keys are only viewable once on creation (zero-knowledge principle).
 *
 * Permissions:
 * - read: Can read content data
 * - write: Can create/update content data
 * - admin: Full access (rarely granted)
 */

declare(strict_types=1);

namespace NomadCMS\Security;

use NomadCMS\Database\AuthDatabase;
use PDO;
use RuntimeException;

final class ApiKeyService
{
    private PDO $db;

    // Key prefix for easy identification
    private const KEY_PREFIX = 'nmk_';

    // Enhanced key prefix (longer for identification)
    private const ENHANCED_KEY_PREFIX = 'nmk_pro_';

    // Permissions bitmask
    public const PERM_READ = 1;
    public const PERM_WRITE = 2;
    public const PERM_ADMIN = 4;

    // New permissions for encrypted data
    public const PERM_ENCRYPTED_READ = 8;   // Can read encrypted slot data
    public const PERM_ENCRYPTED_WRITE = 16; // Can write encrypted slot data

    // Draft-only preview key (restricts key exclusively to draft preview reads)
    public const PERM_DRAFT_ONLY = 32;

    public function __construct()
    {
        $this->db = AuthDatabase::getInstance();
        if (!PanicModeService::isReadOnlyRequest() && !PanicModeService::isActive()) {
            $this->ensureTable();
        }
    }

    /**
     * Ensure api_keys table exists
     */
    private function ensureTable(): void
    {
        $this->db->exec("
            CREATE TABLE IF NOT EXISTS api_keys (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                name TEXT NOT NULL,
                key_hash TEXT NOT NULL,
                key_prefix TEXT NOT NULL,
                permissions INTEGER NOT NULL DEFAULT 1,
                last_used_at TEXT DEFAULT NULL,
                usage_count INTEGER DEFAULT 0,
                expires_at TEXT DEFAULT NULL,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                revoked_at TEXT DEFAULT NULL,
                FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
            )
        ");

        // Add usage_count column if it doesn't exist (migration for existing tables)
        try {
            $this->db->exec("ALTER TABLE api_keys ADD COLUMN usage_count INTEGER DEFAULT 0");
        } catch (\PDOException $e) {
            // Column already exists, ignore
        }

        // Add key_type column for enhanced keys (migration for existing tables)
        try {
            $this->db->exec("ALTER TABLE api_keys ADD COLUMN key_type TEXT DEFAULT 'standard'");
        } catch (\PDOException $e) {
            // Column already exists, ignore
        }

        // Add is_draft_only column for draft preview keys (migration for existing tables)
        try {
            $this->db->exec("ALTER TABLE api_keys ADD COLUMN is_draft_only INTEGER DEFAULT 0");
        } catch (\PDOException $e) {
            // Column already exists, ignore
        }

        // Add raw_key column for draft keys so they can be copied anytime (migration for existing tables)
        try {
            $this->db->exec("ALTER TABLE api_keys ADD COLUMN raw_key TEXT DEFAULT NULL");
        } catch (\PDOException $e) {
            // Column already exists, ignore
        }

        // SECURITY INVARIANT: Clean up any invalid raw_key values that may have been set on non-draft or PRO keys
        try {
            $this->db->exec("UPDATE api_keys SET raw_key = NULL WHERE is_draft_only != 1 OR key_type != 'standard' OR (permissions & 30) != 0");
        } catch (\Throwable $e) {
            // Ignore during initial bootstrap
        }

        // Migrate any unencrypted raw_key values to Defuse AES-256 encrypted format at rest
        if (class_exists(EncryptionService::class) && EncryptionService::isConfigured()) {
            try {
                $stmt = $this->db->query("SELECT id, raw_key FROM api_keys WHERE raw_key IS NOT NULL AND raw_key != ''");
                if ($stmt) {
                    $updateStmt = $this->db->prepare("UPDATE api_keys SET raw_key = ? WHERE id = ?");
                    while ($row = $stmt->fetch(\PDO::FETCH_ASSOC)) {
                        $migrated = EncryptionService::migrateToEncrypted((string) $row['raw_key']);
                        if ($migrated !== null) {
                            $updateStmt->execute([$migrated, $row['id']]);
                        }
                    }
                }
            } catch (\Throwable $e) {
                // Ignore migration errors
            }
        }

        // DATABASE-LEVEL SECURITY TRIGGERS:
        // Physically prevent SQLite from storing raw_key for standard or PRO keys,
        // and strictly require Defuse ciphertext (def...) for draft keys.
        // It is mathematically and architecturally impossible to store unencrypted keys or keys for non-draft types.
        try {
            $this->db->exec("
                CREATE TRIGGER IF NOT EXISTS trg_api_keys_strict_raw_key_insert
                BEFORE INSERT ON api_keys
                FOR EACH ROW
                WHEN NEW.raw_key IS NOT NULL AND (
                    NEW.is_draft_only != 1
                    OR NEW.key_type != 'standard'
                    OR (NEW.permissions & 30) != 0
                    OR NEW.raw_key NOT LIKE 'def%'
                )
                BEGIN
                    SELECT RAISE(ABORT, 'SECURITY VIOLATION: raw_key can ONLY be stored as Defuse ciphertext (def...) for read-only standard draft keys. Standard and PRO keys can NEVER store raw_key.');
                END;
            ");

            $this->db->exec("
                CREATE TRIGGER IF NOT EXISTS trg_api_keys_strict_raw_key_update
                BEFORE UPDATE ON api_keys
                FOR EACH ROW
                WHEN NEW.raw_key IS NOT NULL AND (
                    NEW.is_draft_only != 1
                    OR NEW.key_type != 'standard'
                    OR (NEW.permissions & 30) != 0
                    OR NEW.raw_key NOT LIKE 'def%'
                )
                BEGIN
                    SELECT RAISE(ABORT, 'SECURITY VIOLATION: raw_key can ONLY be stored as Defuse ciphertext (def...) for read-only standard draft keys. Standard and PRO keys can NEVER store raw_key.');
                END;
            ");
        } catch (\Throwable $e) {
            // Ignore trigger creation if sqlite version does not support triggers
        }

        $this->db->exec("CREATE INDEX IF NOT EXISTS idx_api_keys_user ON api_keys(user_id)");
        $this->db->exec("CREATE INDEX IF NOT EXISTS idx_api_keys_hash ON api_keys(key_hash)");
    }

    /**
     * Create a new API key
     * Returns the full key (only viewable once!)
     *
     * Note: Input should be pre-sanitized by InputSanitizer at the endpoint level.
     * This method performs additional validation as a safety net.
     */
    public function createKey(
        int $userId,
        string $name,
        array $permissions = ['read'],
        ?string $expiresAt = null,
        bool $isDraftOnly = false
    ): array {
        // Final validation (input should already be sanitized)
        $name = trim($name);
        if (empty($name) || strlen($name) > 100) {
            throw new RuntimeException('Key name must be 1-100 characters');
        }

        // Whitelist permissions
        $validPermissions = ['read', 'write', 'admin'];
        $permissions = array_values(array_intersect($permissions, $validPermissions));
        if (empty($permissions)) {
            $permissions = ['read'];
        }

        // Rate limit: max 10 active keys per user
        $stmt = $this->db->prepare("
            SELECT COUNT(*) FROM api_keys
            WHERE user_id = ? AND revoked_at IS NULL
        ");
        $stmt->execute([$userId]);
        $activeCount = (int) $stmt->fetchColumn();
        $stmt->closeCursor();

        if ($activeCount >= 10) {
            throw new RuntimeException('Maximum 10 active API keys allowed per user');
        }

        // Calculate permissions bitmask
        $permBits = 0;

        // Draft-only keys are strictly read + draft_only, no mutations allowed
        if ($isDraftOnly) {
            $permBits = self::PERM_READ | self::PERM_DRAFT_ONLY;
        } else {
            foreach ($permissions as $perm) {
                $permBits |= match($perm) {
                    'read' => self::PERM_READ,
                    'write' => self::PERM_WRITE,
                    'admin' => self::PERM_ADMIN,
                    default => 0,
                };
            }
        }

        if ($permBits === 0) {
            $permBits = self::PERM_READ; // Default to read-only
        }

        // Generate secure random key with additional entropy
        $rawKey = bin2hex(random_bytes(32)); // 64 chars
        $fullKey = self::KEY_PREFIX . $rawKey;

        // Store only the hash (zero-knowledge) using password_hash for extra security
        $keyHash = hash('sha256', $fullKey);
        $keyPrefix = substr($fullKey, 0, 12); // nmk_xxxxxxxx visible prefix

        $rawKeyToStore = null;
        if ($isDraftOnly) {
            // STRICT SECURITY GUARANTEE: Draft keys MUST be encrypted at rest.
            // Plaintext fallback is strictly prohibited under all circumstances.
            if (!class_exists(EncryptionService::class) || !EncryptionService::isConfigured()) {
                throw new \RuntimeException('Cannot create draft preview key: EncryptionService is not configured. Nomad CMS strictly prohibits storing unencrypted API keys.');
            }

            $encryptedKey = EncryptionService::encrypt($fullKey);
            if (!EncryptionService::isEncrypted($encryptedKey)) {
                throw new \RuntimeException('Security integrity failure: Encrypted draft key format validation failed.');
            }
            $rawKeyToStore = $encryptedKey;
        } else {
            // Standard API keys NEVER have raw_key stored (always strictly NULL)
            $rawKeyToStore = null;
        }

        $stmt = $this->db->prepare("
            INSERT INTO api_keys (user_id, name, key_hash, key_prefix, permissions, expires_at, key_type, is_draft_only, raw_key)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");

        $stmt->execute([
            $userId,
            $name,
            $keyHash,
            $keyPrefix,
            $permBits,
            $expiresAt,
            'standard',
            $isDraftOnly ? 1 : 0,
            $rawKeyToStore,
        ]);

        $keyId = (int) $this->db->lastInsertId();

        $result = [
            'id' => $keyId,
            'name' => $name,
            'key' => $fullKey, // Returned at creation
            'key_prefix' => $keyPrefix,
            'permissions' => $this->permissionsToArray($permBits),
            'expires_at' => $expiresAt,
            'created_at' => date('c'),
            'key_type' => 'standard',
        ];

        if ($isDraftOnly) {
            $result['is_draft_only'] = true;
            $result['raw_key'] = $fullKey;
        }

        return $result;
    }

    /**
     * Create a new Enhanced (PRO) API key with extra security
     * Returns the full key (only viewable once!)
     * Enhanced keys are 3x longer (96 bytes = 192 hex chars)
     *
     * Note: Input should be pre-sanitized by InputSanitizer at the endpoint level.
     */
    public function createEnhancedKey(
        int $userId,
        string $name,
        array $permissions = ['read'],
        array $encryptedPermissions = [],
        ?string $expiresAt = null
    ): array {
        // Final validation (input should already be sanitized)
        $name = trim($name);
        if (empty($name) || strlen($name) > 100) {
            throw new RuntimeException('Key name must be 1-100 characters');
        }

        // Whitelist standard permissions
        $validPermissions = ['read', 'write', 'admin'];
        $permissions = array_values(array_intersect($permissions, $validPermissions));
        if (empty($permissions)) {
            $permissions = ['read'];
        }

        // Whitelist encrypted permissions
        $validEncryptedPerms = ['encrypted_read', 'encrypted_write'];
        $encryptedPermissions = array_values(array_intersect($encryptedPermissions, $validEncryptedPerms));

        // Rate limit: max 10 active keys per user
        $stmt = $this->db->prepare("
            SELECT COUNT(*) FROM api_keys
            WHERE user_id = ? AND revoked_at IS NULL
        ");
        $stmt->execute([$userId]);
        $activeCount = (int) $stmt->fetchColumn();
        $stmt->closeCursor();

        if ($activeCount >= 10) {
            throw new RuntimeException('Maximum 10 active API keys allowed per user');
        }

        // Calculate permissions bitmask (standard permissions)
        $permBits = 0;
        foreach ($permissions as $perm) {
            $permBits |= match($perm) {
                'read' => self::PERM_READ,
                'write' => self::PERM_WRITE,
                'admin' => self::PERM_ADMIN,
                default => 0,
            };
        }

        // Add encrypted permissions
        foreach ($encryptedPermissions as $perm) {
            $permBits |= match($perm) {
                'encrypted_read' => self::PERM_ENCRYPTED_READ,
                'encrypted_write' => self::PERM_ENCRYPTED_WRITE,
                default => 0,
            };
        }

        if ($permBits === 0) {
            $permBits = self::PERM_READ; // Default to read-only
        }

        // Generate enhanced secure random key (3x longer: 96 bytes = 192 hex chars)
        $rawKey = bin2hex(random_bytes(96)); // 192 hex chars
        $fullKey = self::ENHANCED_KEY_PREFIX . $rawKey; // nmk_pro_ + 192 = 200 chars

        // Store only the hash (zero-knowledge) using SHA-256
        $keyHash = hash('sha256', $fullKey);
        $keyPrefix = substr($fullKey, 0, 16); // nmk_pro_xxxxxxxx visible prefix

        // Enhanced (PRO) keys NEVER store raw keys under any circumstance (raw_key is explicitly NULL, is_draft_only is 0)
        $stmt = $this->db->prepare("
            INSERT INTO api_keys (user_id, name, key_hash, key_prefix, permissions, expires_at, key_type, is_draft_only, raw_key)
            VALUES (?, ?, ?, ?, ?, ?, 'enhanced', 0, NULL)
        ");

        $stmt->execute([
            $userId,
            $name,
            $keyHash,
            $keyPrefix,
            $permBits,
            $expiresAt,
        ]);

        $keyId = (int) $this->db->lastInsertId();

        return [
            'id' => $keyId,
            'name' => $name,
            'key' => $fullKey, // Only returned once! 200 chars total
            'key_prefix' => $keyPrefix,
            'permissions' => $this->permissionsToArray($permBits),
            'encrypted_permissions' => $this->encryptedPermissionsToArray($permBits),
            'expires_at' => $expiresAt,
            'created_at' => date('c'),
            'key_type' => 'enhanced',
        ];
    }

    /**
     * List all API keys for a user (without full key)
     */
    public function listKeys(int $userId): array
    {
        // Cleanup old revoked keys first
        $this->cleanupRevokedKeys();

        $stmt = $this->db->prepare("
            SELECT id, name, key_prefix, permissions, last_used_at, usage_count, expires_at, created_at, revoked_at, key_type, raw_key, is_draft_only
            FROM api_keys
            WHERE user_id = ?
            ORDER BY created_at DESC
        ");
        $stmt->execute([$userId]);
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

        return array_map(function($row) {
            $permBits = (int) $row['permissions'];
            $keyType = $row['key_type'] ?? 'standard';
            $isDraftOnly = ($permBits & self::PERM_DRAFT_ONLY) !== 0 || !empty($row['is_draft_only']);

            $result = [
                'id' => (int) $row['id'],
                'name' => $row['name'],
                'key_prefix' => $row['key_prefix'],
                'permissions' => $this->permissionsToArray($permBits),
                'last_used_at' => $row['last_used_at'],
                'usage_count' => (int) ($row['usage_count'] ?? 0),
                'expires_at' => $row['expires_at'],
                'created_at' => $row['created_at'],
                'is_active' => $row['revoked_at'] === null && !$this->isExpired($row['expires_at']),
                'key_type' => $keyType,
                'is_draft_only' => $isDraftOnly,
            ];

            // STRICT DEFENSE-IN-DEPTH:
            // 1. Only standard keys ($keyType === 'standard') - NEVER enhanced / PRO keys
            // 2. Only draft keys ($isDraftOnly === true) - NEVER normal/standard API keys
            // 3. No mutation or admin permissions: (permBits & 30) === 0 (no write, no admin, no encrypted perms)
            // 4. Must have ciphertext starting with 'def' (Defuse format) - plaintext values are strictly rejected
            // 5. Decrypted key must start with 'nmk_' (standard key prefix)
            if ($isDraftOnly && !empty($row['raw_key']) && ($permBits & 30) === 0 && $keyType === 'standard') {
                $rawVal = $row['raw_key'];
                if (EncryptionService::isEncrypted($rawVal) && EncryptionService::isConfigured()) {
                    try {
                        $rawVal = EncryptionService::decrypt($rawVal);
                    } catch (\Throwable $e) {
                        $rawVal = null;
                    }
                } else {
                    $rawVal = null; // Plaintext or corrupted raw_key is strictly rejected
                }
                if ($rawVal !== null && str_starts_with($rawVal, self::KEY_PREFIX)) {
                    $result['raw_key'] = $rawVal;
                    $result['key'] = $rawVal;
                }
            }

            // Add encrypted permissions for enhanced keys
            if ($keyType === 'enhanced') {
                $result['encrypted_permissions'] = $this->encryptedPermissionsToArray($permBits);
            }

            return $result;
        }, $rows);
    }

    /**
     * Revoke an API key
     */
    public function revokeKey(int $userId, int $keyId): bool
    {
        $stmt = $this->db->prepare("
            UPDATE api_keys
            SET revoked_at = datetime('now')
            WHERE id = ? AND user_id = ? AND revoked_at IS NULL
        ");
        $stmt->execute([$keyId, $userId]);

        // Cleanup old revoked keys
        $this->cleanupRevokedKeys();

        return $stmt->rowCount() > 0;
    }

    /**
     * Delete revoked keys older than 12 hours
     */
    public function cleanupRevokedKeys(): int
    {
        $stmt = $this->db->prepare("
            DELETE FROM api_keys
            WHERE revoked_at IS NOT NULL
            AND datetime(revoked_at, '+12 hours') < datetime('now')
        ");
        $stmt->execute();

        return $stmt->rowCount();
    }

    /**
     * Validate an API key and return associated data
     */
    public function validateKey(string $key): ?array
    {
        // Check format (standard or enhanced)
        $isEnhanced = str_starts_with($key, self::ENHANCED_KEY_PREFIX);
        $isStandard = !$isEnhanced && str_starts_with($key, self::KEY_PREFIX);

        if (!$isStandard && !$isEnhanced) {
            return null;
        }

        $keyHash = hash('sha256', $key);

        $stmt = $this->db->prepare("
            SELECT ak.id, ak.user_id, ak.name, ak.permissions, ak.expires_at, ak.revoked_at, ak.key_type,
                   u.uuid, u.email, u.is_admin, u.locked_until, u.is_new_user
            FROM api_keys ak
            JOIN users u ON ak.user_id = u.id
            WHERE ak.key_hash = ?
        ");
        $stmt->execute([$keyHash]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$row) {
            return null;
        }
        if (!empty($row['is_new_user']) || \NomadCMS\Database\UserRepository::isLocked($row)) {
            return null;
        }

        // Check if revoked
        if ($row['revoked_at'] !== null) {
            return null;
        }

        // Check if expired
        if ($this->isExpired($row['expires_at'])) {
            return null;
        }

        // Update last used timestamp and increment usage count
        if (!PanicModeService::isReadOnlyRequest() && !PanicModeService::isActive()) {
            $this->db->prepare("
                UPDATE api_keys
                SET last_used_at = datetime('now'), usage_count = COALESCE(usage_count, 0) + 1
                WHERE id = ?
            ")->execute([$row['id']]);

        }

        $permBits = (int) $row['permissions'];
        $keyType = $row['key_type'] ?? 'standard';

        $isDraftOnly = ($permBits & self::PERM_DRAFT_ONLY) !== 0;

        $result = [
            'key_id' => (int) $row['id'],
            'user_id' => (int) $row['user_id'],
            'user_uuid' => $row['uuid'],
            'user_email' => $row['email'],
            'user_is_admin' => (bool) $row['is_admin'],
            'permissions' => $this->permissionsToArray($permBits),
            'can_read' => ($permBits & self::PERM_READ) !== 0,
            'can_write' => !$isDraftOnly && ($permBits & self::PERM_WRITE) !== 0,
            'is_admin' => !$isDraftOnly && ($permBits & self::PERM_ADMIN) !== 0,
            'is_draft_only' => $isDraftOnly,
            'key_type' => $keyType,
        ];

        // Add encrypted permissions for enhanced keys
        if ($keyType === 'enhanced') {
            $result['can_encrypted_read'] = ($permBits & self::PERM_ENCRYPTED_READ) !== 0;
            $result['can_encrypted_write'] = ($permBits & self::PERM_ENCRYPTED_WRITE) !== 0;
            $result['encrypted_permissions'] = $this->encryptedPermissionsToArray($permBits);
        }

        return $result;
    }

    /**
     * Check if key has specific permission
     */
    public function hasPermission(array $keyData, string $permission): bool
    {
        return match($permission) {
            'read' => $keyData['can_read'] ?? false,
            'write' => $keyData['can_write'] ?? false,
            'admin' => $keyData['is_admin'] ?? false,
            'encrypted_read' => $keyData['can_encrypted_read'] ?? false,
            'encrypted_write' => $keyData['can_encrypted_write'] ?? false,
            default => false,
        };
    }

    /**
     * Convert permissions bitmask to array
     */
    private function permissionsToArray(int $bits): array
    {
        $perms = [];
        if ($bits & self::PERM_READ) $perms[] = 'read';
        if ($bits & self::PERM_WRITE) $perms[] = 'write';
        if ($bits & self::PERM_ADMIN) $perms[] = 'admin';
        return $perms;
    }

    /**
     * Convert encrypted permissions bitmask to array
     */
    private function encryptedPermissionsToArray(int $bits): array
    {
        $perms = [];
        if ($bits & self::PERM_ENCRYPTED_READ) $perms[] = 'encrypted_read';
        if ($bits & self::PERM_ENCRYPTED_WRITE) $perms[] = 'encrypted_write';
        return $perms;
    }

    /**
     * Check if a date is expired
     */
    private function isExpired(?string $expiresAt): bool
    {
        if ($expiresAt === null) return false;
        return strtotime($expiresAt) < time();
    }
}
