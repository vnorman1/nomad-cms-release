<?php
/**
 * NOMAD CMS — Canonical panic request policy.
 * The router supplies the resolved endpoint file; direct scripts are resolved
 * from SCRIPT_FILENAME. User-controlled paths and query strings never grant
 * a recovery exception. Public reads remain available without background work.
 */

declare(strict_types=1);

namespace NomadCMS\Security;

final class PanicModePolicy
{
    private const PUBLIC_READS = [
        'data.php', 'schema.php', 'static-serve.php', 'batch-content.php',
        'search.php', 'sitemap.php', 'llms-item.php', 'seo.php',
        'public/capabilities.php', 'public/analytics-script.php',
        'install/status.php',
    ];

    public static function endpoint(): string
    {
        if (isset($_SERVER['NOMAD_ENDPOINT_FILE'])) {
            return (string) $_SERVER['NOMAD_ENDPOINT_FILE'];
        }
        $root = realpath(dirname(__DIR__, 2) . '/endpoints');
        $script = realpath($_SERVER['SCRIPT_FILENAME'] ?? '');
        return $root && $script && str_starts_with($script, $root . '/')
            ? substr($script, strlen($root) + 1) : '';
    }

    public static function isPublicRead(): bool
    {
        return in_array($_SERVER['REQUEST_METHOD'] ?? 'GET', ['GET', 'HEAD'], true)
            && in_array(self::endpoint(), self::PUBLIC_READS, true);
    }

    public static function isRecoveryAuthentication(): bool
    {
        return (self::endpoint() === 'auth/login.php' && ($_SERVER['REQUEST_METHOD'] ?? '') === 'POST')
            || (self::endpoint() === 'auth/webauthn-login.php'
                && in_array($_SERVER['REQUEST_METHOD'] ?? '', ['GET', 'POST'], true));
    }

    public static function isControl(): bool
    {
        return self::endpoint() === 'admin/panic.php'
            && in_array($_SERVER['REQUEST_METHOD'] ?? '', ['GET', 'POST'], true);
    }

    public static function allowsRecoveryToken(): bool
    {
        return self::isControl()
            || (self::endpoint() === 'auth/me.php' && ($_SERVER['REQUEST_METHOD'] ?? '') === 'GET')
            || (self::endpoint() === 'auth/logout.php' && ($_SERVER['REQUEST_METHOD'] ?? '') === 'POST');
    }
}
