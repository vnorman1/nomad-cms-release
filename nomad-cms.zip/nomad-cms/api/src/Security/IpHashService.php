<?php
/**
 * NOMAD CMS - IP Hash Service
 * Handles secure HMAC-SHA256 hashing of IP addresses for storage and binding
 */

declare(strict_types=1);

namespace NomadCMS\Security;

use NomadCMS\Config\Security;

final class IpHashService
{
    /**
     * Generate a secure hash of an IP address
     * Uses HMAC-SHA256 with a secret key
     * 
     * @throws \RuntimeException if IP_HASH_SECRET is not configured
     */
    public static function hash(string $ip): string
    {
        $secret = $_ENV['IP_HASH_SECRET'] ?? null;
        
        if (empty($secret)) {
            throw new \RuntimeException(
                'IP_HASH_SECRET not configured. Generate with: php -r "echo bin2hex(random_bytes(32));"'
            );
        }
        
        return hash_hmac('sha256', $ip, $secret);
    }
    
    /**
     * Verify if an IP address matches a stored hash
     */
    public static function verify(string $ip, string $storedHash): bool
    {
        return hash_equals($storedHash, self::hash($ip));
    }

    /**
     * Mask an IP address according to the binding mode
     * 
     * - 'disabled': returns empty string
     * - 'strict': returns exact IP
     * - 'subnet': masks IPv4 to /24 and IPv6 to /48
     */
    public static function getMaskedIp(string $ip, ?string $mode = null): string
    {
        $mode = $mode ?? Security::getIpBindingMode();

        if ($mode === 'disabled') {
            return '';
        }

        if ($mode === 'strict') {
            return $ip;
        }

        // Subnet mode
        if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
            $parts = explode('.', $ip);
            return $parts[0] . '.' . $parts[1] . '.' . $parts[2] . '.0/24';
        }

        if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6)) {
            $packed = inet_pton($ip);
            if ($packed !== false) {
                // /48 prefix: keep first 6 bytes (48 bits), zero out the remaining 10 bytes (80 bits)
                $mask = str_repeat("\xff", 6) . str_repeat("\x00", 10);
                $maskedBinary = $packed & $mask;
                return (inet_ntop($maskedBinary) ?: $ip) . '/48';
            }
        }

        return $ip;
    }

    /**
     * Generate hash for session / token IP binding
     * 
     * Returns null if IP binding is disabled.
     */
    public static function hashForBinding(string $ip, ?string $mode = null): ?string
    {
        $mode = $mode ?? Security::getIpBindingMode();

        if ($mode === 'disabled') {
            return null;
        }

        $masked = self::getMaskedIp($ip, $mode);
        return self::hash($masked);
    }

    /**
     * Verify if the current client IP satisfies the stored binding hash
     * 
     * Tolerates /24 (IPv4) or /48 (IPv6) rotations in 'subnet' mode.
     * Always passes in 'disabled' mode.
     */
    public static function verifyBinding(string $currentIp, ?string $storedHash, ?string $mode = null): bool
    {
        $mode = $mode ?? Security::getIpBindingMode();

        if ($mode === 'disabled' || empty($storedHash)) {
            return true;
        }

        $bindingHash = self::hashForBinding($currentIp, $mode);
        if ($bindingHash !== null && hash_equals($storedHash, $bindingHash)) {
            return true;
        }

        // Backwards compatibility: if stored hash was created as raw IP (strict)
        // and the client is currently on the exact same IP, accept it.
        if ($mode === 'subnet') {
            try {
                $rawHash = self::hash($currentIp);
                if (hash_equals($storedHash, $rawHash)) {
                    return true;
                }
            } catch (\Exception) {
                // Ignore hash failure
            }
        }

        return false;
    }
}
