<?php
/**
 * NOMAD CMS — Durable panic state and transition coordination.
 * Uses a small dedicated SQLite connection with FULL durability for control
 * commits. A separate persistent marker closes writes before draining workers;
 * crashes and failed marker removal cannot implicitly reopen the installation.
 * Lock inodes are persistent and shared by HTTP requests and CLI processors.
 */

declare(strict_types=1);

namespace NomadCMS\Security;

use NomadCMS\Database\AuthDatabase;
use PDO;

final class PanicStateStore
{
    private ?PDO $db;
    private string $databasePath;
    private string $directory;

    public function __construct(?PDO $db = null, ?string $databasePath = null)
    {
        $this->db = $db;
        $this->databasePath = $databasePath ?? AuthDatabase::path();
        $this->directory = $this->databasePath . '.panic';
    }

    public function markerPath(): string
    {
        return $this->directory . '/lockdown';
    }

    public function hasMarker(): bool
    {
        clearstatcache(true, $this->markerPath());
        return file_exists($this->markerPath()) || is_link($this->markerPath());
    }

    /** The normal reader never creates a missing installed system database. */
    public function connection(): PDO
    {
        if ($this->db === null) {
            if (!is_file($this->databasePath)) {
                throw new PanicModeException('PANIC_STATE_UNAVAILABLE', 'System control storage is unavailable.');
            }
            $this->db = new PDO('sqlite:file:' . rawurlencode($this->databasePath) . '?mode=rw', null, null, [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_TIMEOUT => 1,
            ]);
            $this->db->exec('PRAGMA busy_timeout=1000; PRAGMA synchronous=FULL; PRAGMA cache_size=-512; PRAGMA foreign_keys=ON');
            // Existing installations get the same one-time migration as install.
            // This runs DDL only when the control table has never been installed.
            PanicModeSchema::ensure($this->db);
        }
        return $this->db;
    }

    public function state(): array
    {
        $row = $this->connection()->query('SELECT * FROM panic_state WHERE id=1')->fetch(PDO::FETCH_ASSOC);
        if (!$row || !in_array($row['enabled'], [0, 1, '0', '1'], true)
            || filter_var($row['revision'], FILTER_VALIDATE_INT) === false || (int) $row['revision'] < 0
            || filter_var($row['auth_epoch'], FILTER_VALIDATE_INT) === false || (int) $row['auth_epoch'] < 1
            || !is_string($row['instance_id']) || !preg_match('/^[a-f0-9]{32}$/D', $row['instance_id'])) {
            throw new PanicModeException('PANIC_STATE_UNAVAILABLE', 'System control state could not be verified.');
        }
        $row['enabled'] = (bool) $row['enabled'];
        foreach (['revision', 'auth_epoch', 'sessions_revoked'] as $field) {
            $row[$field] = (int) $row[$field];
        }
        foreach (['activated_by', 'deactivated_by'] as $field) {
            $row[$field] = $row[$field] !== null ? (int) $row[$field] : null;
        }
        return $row;
    }

    public function status(): array
    {
        try {
            $state = $this->state();
            $marker = $this->hasMarker();
            return $state + [
                'storage_health' => 'healthy',
                'effective_source' => $marker ? 'marker' : 'sqlite',
                'transition_state' => $marker && !$state['enabled'] ? 'transition_incomplete' : 'complete',
            ];
        } catch (\Throwable $e) {
            error_log('[PanicMode] control_state_unavailable: ' . $e->getMessage());
            return ['enabled' => true, 'revision' => null, 'auth_epoch' => null, 'instance_id' => null,
                'activated_at' => null, 'activated_by' => null, 'reason' => null,
                'sessions_revoked' => 0, 'deactivated_at' => null, 'deactivated_by' => null,
                'storage_health' => 'degraded', 'effective_source' => 'storage_error',
                'transition_state' => 'transition_incomplete'];
        }
    }

    public function isActive(): bool
    {
        return $this->hasMarker() || $this->status()['enabled'];
    }

    /** Acquire the stable mutation inode, bounded to avoid exhausted PHP workers. */
    public function lock(string $name, int $operation, float $timeout = 5.0): mixed
    {
        if (!is_dir($this->directory) && !@mkdir($this->directory, 0700, true) && !is_dir($this->directory)) {
            throw new PanicModeException('PANIC_LOCK_UNAVAILABLE', 'System coordination storage is unavailable.');
        }
        $oldMask = umask(0077);
        try {
            $handle = @fopen($this->directory . '/' . $name . '.lock', 'c');
        } finally {
            umask($oldMask);
        }
        if ($handle === false) {
            throw new PanicModeException('PANIC_LOCK_UNAVAILABLE', 'System coordination lock is unavailable.');
        }
        $deadline = hrtime(true) + (int) ($timeout * 1e9);
        do {
            if (flock($handle, $operation | LOCK_NB)) {
                return $handle;
            }
            usleep(10000);
        } while (hrtime(true) < $deadline);
        fclose($handle);
        throw new PanicModeException('PANIC_TRANSITION_INCOMPLETE', 'The system remains restricted; an operation is still running.');
    }

    public static function unlock(mixed $handle): void
    {
        if (is_resource($handle)) {
            flock($handle, LOCK_UN);
            fclose($handle);
        }
    }

    /** A marker can also be created by the hosting operator without SQLite. */
    public function createMarker(): void
    {
        if ($this->hasMarker()) {
            return;
        }
        $coordination = $this->lock('marker', LOCK_EX);
        try {
            if ($this->hasMarker()) {
                return;
            }
            $oldMask = umask(0077);
            try {
                $handle = @fopen($this->markerPath(), 'x');
            } finally {
                umask($oldMask);
            }
            if ($handle === false) {
                throw new PanicModeException('PANIC_MARKER_UNAVAILABLE', 'Emergency lockdown could not be persisted.');
            }
            try {
                if (fwrite($handle, "NOMAD lockdown\n") !== 15 || !fflush($handle) || !fsync($handle)) {
                    throw new PanicModeException('PANIC_TRANSITION_INCOMPLETE', 'Lockdown persistence could not be confirmed.');
                }
            } finally {
                fclose($handle);
            }
        } finally {
            self::unlock($coordination);
        }
    }

    public function transition(bool $enable, int $adminId, ?string $reason, ?int $expectedRevision): array
    {
        if ($adminId < 1 || ($reason !== null && (!preg_match('//u', $reason) || strlen($reason) > 2000))) {
            throw new PanicModeException('INVALID_PANIC_INPUT', 'Invalid panic control input.', 400);
        }
        $control = $this->lock('control', LOCK_EX);
        $mutation = null;
        try {
            try {
                $state = $this->state();
            } catch (\Throwable $e) {
                if ($enable) {
                    $this->createMarker();
                }
                throw $e;
            }
            if (($expectedRevision !== null || !$enable) && $expectedRevision !== $state['revision']) {
                throw new PanicModeException('PANIC_REVISION_CONFLICT', 'Panic status changed. Refresh it before unlocking.', 409);
            }
            if ($enable && $state['enabled']) {
                return ['changed' => false, 'sessions_revoked' => $state['sessions_revoked']];
            }
            if (!$enable && !$state['enabled'] && !$this->hasMarker()) {
                return ['changed' => false, 'sessions_revoked' => 0];
            }

            // Close new work FIRST. Existing shared mutation leases may finish,
            // but no successful transition is reported until they have drained.
            $this->createMarker();
            $mutation = $this->lock('mutations', LOCK_EX);
            $db = $this->connection();
            $db->exec('PRAGMA synchronous=FULL');
            $db->exec('BEGIN IMMEDIATE');
            try {
                $state = $this->state();
                if (!$enable && $expectedRevision !== $state['revision']) {
                    throw new PanicModeException('PANIC_REVISION_CONFLICT', 'Panic status changed. Refresh it before unlocking.', 409);
                }
                $revoke = $db->prepare("UPDATE refresh_tokens SET revoked=1,revoked_at=datetime('now') WHERE revoked=0");
                $revoke->execute();
                $revoked = $revoke->rowCount();
                $db->exec('DELETE FROM sessions');
                $now = gmdate('c');
                $revision = $state['revision'] + 1;
                $sql = $enable
                    ? 'UPDATE panic_state SET enabled=1,revision=?,auth_epoch=auth_epoch+1,activated_at=?,activated_by=?,reason=?,sessions_revoked=?,updated_at=? WHERE id=1'
                    : 'UPDATE panic_state SET enabled=0,revision=?,auth_epoch=auth_epoch+1,deactivated_at=?,deactivated_by=?,updated_at=? WHERE id=1';
                $update = $db->prepare($sql);
                $update->execute($enable
                    ? [$revision, $now, $adminId, $reason, $revoked, $now]
                    : [$revision, $now, $adminId, $now]);
                $action = $enable ? 'ENABLED' : 'DISABLED';
                $audit = $db->prepare('INSERT INTO panic_audit(revision,action,admin_id,reason,sessions_revoked,created_at) VALUES(?,?,?,?,?,?)');
                $audit->execute([$revision, $action, $adminId, $reason, $revoked, $now]);
                $payload = json_encode(['id' => 'panic_mode', 'revision' => $revision, 'reason' => $reason,
                    'admin_id' => $adminId, 'sessions_revoked' => $revoked, 'timestamp' => $now], JSON_THROW_ON_ERROR);
                $db->prepare('INSERT INTO panic_outbox(revision,event,payload,created_at) VALUES(?,?,?,?)')
                    ->execute([$revision, $enable ? 'system.panic_enabled' : 'system.panic_disabled', $payload, $now]);
                $db->exec('COMMIT');
            } catch (\Throwable $e) {
                if ($db->inTransaction()) {
                    $db->exec('ROLLBACK');
                }
                throw $e;
            }
            if (!$enable && (!@unlink($this->markerPath()) || $this->hasMarker())) {
                throw new PanicModeException('PANIC_TRANSITION_INCOMPLETE', 'Database updated, but the emergency marker remains. The system is still restricted.');
            }
            return ['changed' => true, 'sessions_revoked' => $revoked];
        } catch (PanicModeException $e) {
            throw $e;
        } catch (\Throwable $e) {
            error_log('[PanicMode] transition_failed: ' . $e->getMessage());
            throw new PanicModeException('PANIC_TRANSITION_INCOMPLETE', 'Panic transition could not be completed. Check the current status.');
        } finally {
            self::unlock($mutation);
            self::unlock($control);
        }
    }
}
