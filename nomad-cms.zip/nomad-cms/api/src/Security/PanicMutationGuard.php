<?php
/**
 * NOMAD CMS — Shared mutation leases for panic transitions.
 * HTTP requests hold one lease until shutdown; workers hold bounded leases
 * around each batch. Nested work reuses its lease without an upgrade deadlock.
 * Every new lease rechecks control state after acquiring the stable inode.
 */

declare(strict_types=1);

namespace NomadCMS\Security;

final class PanicMutationGuard
{
    private static mixed $requestLease = null;
    private static int $depth = 0;

    public static function acquire(bool $recovery = false): mixed
    {
        $store = PanicModeService::store();
        if (!$recovery && $store->isActive()) {
            throw new PanicModeException('PANIC_MODE_ACTIVE', 'System is in emergency read-only mode.');
        }
        $lease = $store->lock('mutations', LOCK_SH, 1.0);
        try {
            $status = $store->status();
            if ($status['storage_health'] !== 'healthy' || (!$recovery && $store->isActive())) {
                throw new PanicModeException('PANIC_MODE_ACTIVE', 'System is in emergency read-only mode.');
            }
            return $lease;
        } catch (\Throwable $e) {
            PanicStateStore::unlock($lease);
            throw $e;
        }
    }

    public static function beginRequest(bool $recovery = false): void
    {
        self::$requestLease ??= self::acquire($recovery);
    }

    public static function releaseRequest(): void
    {
        PanicStateStore::unlock(self::$requestLease);
        self::$requestLease = null;
    }

    public static function run(callable $operation): mixed
    {
        if (self::$requestLease !== null || self::$depth > 0) {
            return $operation();
        }
        $lease = self::acquire();
        self::$depth++;
        try {
            return $operation();
        } finally {
            self::$depth--;
            PanicStateStore::unlock($lease);
        }
    }
}
