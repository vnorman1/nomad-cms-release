<?php
/**
 * NOMAD CMS - PHP Development Server Router
 * 
 * This file is used as the router for PHP's built-in development server.
 * It handles the path-based routing while the dev server runs from /api directory.
 * 
 * Usage: php -S 127.0.0.1:8000 router.php
 * 
 * In dev mode, requests come without /api prefix because:
 * - Vite proxy: /api/data/hero → (rewrite) → /data/hero
 * - PHP server root is /api, so it receives /data/hero
 * 
 * This router adds back the context and dispatches to index.php
 */

declare(strict_types=1);

require_once __DIR__ . '/update-guard.php';

// Get the request URI
$uri = $_SERVER['REQUEST_URI'] ?? '/';
$path = parse_url($uri, PHP_URL_PATH);

// ───────────────────────────────────────────────────────────────────────────
// FORM ATTACHMENT STORE - never serve directly
// ───────────────────────────────────────────────────────────────────────────
// files/forms/ holds attachments uploaded by ANONYMOUS visitors through the
// public form endpoint, and may contain personal data (CVs, contracts).
//
// The store ships a .htaccess with "Require all denied", but ONLY Apache reads
// it - the built-in dev server below (and nginx) would happily serve these files
// via the is_file() branch. Verified: without this block a GET on
// /files/forms/<uuid>.bin returned 200 with the file contents.
//
// They must only be served by endpoints/admin/form-files.php, which enforces
// authentication, RBAC, forms:decrypt for encrypted forms, and audit logging.
$normalisedPath = str_replace('\\', '/', rawurldecode((string) $path));
$segments = [];
foreach (explode('/', $normalisedPath) as $segment) {
    if ($segment === '' || $segment === '.') {
        continue;
    }
    if ($segment === '..') {
        array_pop($segments);
        continue;
    }
    $segments[] = $segment;
}
$normalisedPath = '/' . implode('/', $segments);
$path = $normalisedPath;
if (preg_match('~(^|/)files/(?:forms|editorials)(/|$)~i', $normalisedPath) === 1) {
    http_response_code(403);
    header('Content-Type: application/json; charset=utf-8');
    header('X-Content-Type-Options: nosniff');
    echo json_encode([
        'success' => false,
        'error' => 'A csatolmányok közvetlenül nem érhetők el.',
        'code' => 'FORBIDDEN',
    ], JSON_UNESCAPED_UNICODE);
    return true;
}

// ───────────────────────────────────────────────────────────────────────────
// SECRETS AND INTERNALS - never serve, on any server
// ───────────────────────────────────────────────────────────────────────────
// api/.htaccess blocks these for Apache (<Files ".env">, etc.), but the built-in
// dev server does not read .htaccess. Verified before this block existed:
// `curl http://127.0.0.1:8000/.env` returned 200 with ENCRYPTION_KEY,
// PASSWORD_PEPPER and the JWT secret in the body - and the README documents
// `php -S` as the standard dev workflow.
//
// Matched on the normalised path, so /./env-style tricks do not slip past.
$deniedPatterns = [
    '~(^|/)\.env~i',           // .env, .env.local, .env.backup
    '~(^|/)\.git(/|$)~i',
    '~(^|/)keys?/~i',          // keys/private.pem
    '~(^|/)databases?/~i',     // *.sqlite
    '~(^|/)logs?/~i',
    '~(^|/)storage/editorials(/|$)~i',
    '~(^|/)storage/updates(/|$)~i',
    '~(^|/)updater(/|$)~i',
    '~(^|/)storage/(?:seo|og)(/|$)~i',
    '~(^|/)vendor/~i',
    '~(^|/)composer\.(json|lock)$~i',
    '~(^|/)nomad-install\.lock$~i',
    '~\.(sqlite|sqlite3|db|pem|key|log)$~i',
];

foreach ($deniedPatterns as $pattern) {
    if (preg_match($pattern, $normalisedPath) === 1) {
        http_response_code(403);
        header('Content-Type: application/json; charset=utf-8');
        header('X-Content-Type-Options: nosniff');
        echo json_encode([
            'success' => false,
            'error' => 'Forbidden.',
            'code' => 'FORBIDDEN',
        ], JSON_UNESCAPED_UNICODE);
        return true;
    }
}

// Check if it's a real file (static assets, direct PHP access, with or without /api prefix)
$relativePath = str_starts_with($path, '/api/') ? substr($path, 4) : $path;
$realPath = __DIR__ . $relativePath;
if (is_file($realPath)) {
    // If it's a PHP endpoint, execute it
    if (str_ends_with($realPath, '.php')) {
        require $realPath;
        return true;
    }
    // Directly stream static file with proper MIME type
    $mime = mime_content_type($realPath) ?: 'application/octet-stream';
    header("Content-Type: {$mime}");
    header("Content-Length: " . (string)filesize($realPath));
    readfile($realPath);
    return true;
}

// Clean URL support: if requested without .php but matching .php file exists, execute it
if (!str_ends_with($realPath, '.php') && is_file($realPath . '.php')) {
    require $realPath . '.php';
    return true;
}

// For path-based routes, ensure $_SERVER['REQUEST_URI'] has the /api prefix for Router
$_SERVER['ORIGINAL_REQUEST_URI'] = $uri;
if (!str_starts_with($uri, '/api')) {
    $_SERVER['REQUEST_URI'] = '/api' . $uri;
} else {
    $_SERVER['REQUEST_URI'] = $uri;
}

// Load the front controller
require __DIR__ . '/index.php';

