<?php
/**
 * NOMAD CMS - Captcha Provider URL Registry
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * WHAT THIS FILE IS
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * A static, hand-maintained map of the HTTP endpoints each captcha provider
 * uses. It exists so that if Cloudflare or Google ever change their
 * siteverify/script URLs, an operator can fix it here WITHOUT a code deploy -
 * just edit this file over SFTP/SSH and the change takes effect immediately.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * WHAT YOU MAY EDIT
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *   - verify_url   the siteverify endpoint the SECRET key is POSTed to
 *   - script_url    the public <script> URL embedded in generated forms
 *                    (may contain the literal placeholder "{SITE_KEY}",
 *                    substituted at read time for reCAPTCHA v3's ?render=)
 *   - widget_class  the CSS class the embed snippet uses for the widget div
 *   - token_field   the POST field name the provider's widget writes its
 *                    response token into
 *   - min_score     (recaptcha_v3 only) minimum acceptable score, 0.0-1.0
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * WHAT YOU MUST NEVER DO
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *   - Never put a site key or secret key in this file. Those live in the
 *     form_captcha_providers / form_captcha_forms tables in system.sqlite
 *     (encrypted at rest), managed through the admin UI - NOT here.
 *   - This file is require()'d as executable PHP by CaptchaProviderRegistry.
 *     No endpoint, service, or admin action ever WRITES to it - a
 *     web-writable file that gets require()'d is a code-execution surface.
 *     Keep it that way: hand-edited only.
 *
 * A missing or malformed entry here does not break the site:
 * CaptchaProviderRegistry falls back to the built-in defaults below and logs
 * a warning, so a typo cannot take down every protected form at once.
 *
 * @package NomadCMS
 */

declare(strict_types=1);

return [
    'turnstile' => [
        'label' => 'Cloudflare Turnstile',
        'verify_url' => 'https://challenges.cloudflare.com/turnstile/v0/siteverify',
        'script_url' => 'https://challenges.cloudflare.com/turnstile/v0/api.js',
        'widget_class' => 'cf-turnstile',
        'token_field' => 'cf-turnstile-response',
    ],
    'recaptcha_v2' => [
        'label' => 'Google reCAPTCHA v2',
        'verify_url' => 'https://www.google.com/recaptcha/api/siteverify',
        'script_url' => 'https://www.google.com/recaptcha/api.js',
        'widget_class' => 'g-recaptcha',
        'token_field' => 'g-recaptcha-response',
    ],
    'recaptcha_v3' => [
        'label' => 'Google reCAPTCHA v3',
        'verify_url' => 'https://www.google.com/recaptcha/api/siteverify',
        'script_url' => 'https://www.google.com/recaptcha/api.js?render={SITE_KEY}',
        'widget_class' => null,
        'token_field' => 'g-recaptcha-response',
        'min_score' => 0.5,
    ],
];
