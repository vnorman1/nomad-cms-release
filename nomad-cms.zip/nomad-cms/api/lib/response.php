<?php
/**
 * NOMAD CMS - Response Utilities
 * JSON response helpers and CORS handling
 *
 * NOTE: bootstrap.php also defines handlePreflight() (allowlist-based CORS).
 * Every function here is guarded with function_exists() so this file is
 * safe to load either before or after bootstrap.php without a
 * "Cannot redeclare" fatal error.
 */

/**
 * Set CORS headers for the response
 *
 * SECURITY: Origin is validated against an explicit allowlist
 * (CORS_ALLOWED_ORIGINS env var) instead of being blindly reflected.
 * Reflecting an arbitrary Origin while also sending
 * Access-Control-Allow-Credentials: true allows any external site to
 * make authenticated cross-origin requests - this must never happen.
 */
if (!function_exists('setCorsHeaders')) {
    function setCorsHeaders(): void {
        $allowedOrigins = array_map('trim', explode(',', $_ENV['CORS_ALLOWED_ORIGINS'] ?? ''));
        $origin = $_SERVER['HTTP_ORIGIN'] ?? '';

        if ($origin !== '' && in_array($origin, $allowedOrigins, true)) {
            header("Access-Control-Allow-Origin: $origin");
            header('Access-Control-Allow-Credentials: true');
            header('Vary: Origin');
        } elseif (in_array('*', $allowedOrigins, true)) {
            // Wildcard mode: cannot be combined with credentials.
            header('Access-Control-Allow-Origin: *');
        }
        // If the origin is not allowed, no ACAO header is sent (browser blocks the response).

        header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
        header('Access-Control-Allow-Headers: Content-Type, Authorization, X-ADMIN-TOKEN, X-CSRF-TOKEN');
        header('Content-Type: application/json; charset=utf-8');
    }
}

/**
 * Handle preflight OPTIONS request
 */
if (!function_exists('handlePreflight')) {
    function handlePreflight(): void {
        if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
            setCorsHeaders();
            http_response_code(200);
            exit();
        }
    }
}

/**
 * Send JSON success response
 * @param mixed $data Response data
 * @param int $code HTTP status code
 */
if (!function_exists('sendResponse')) {
    function sendResponse(mixed $data, int $code = 200): void {
        http_response_code($code);
        echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
        exit();
    }
}

/**
 * Send JSON error response
 * @param string $message Error message
 * @param int $code HTTP status code
 */
if (!function_exists('sendError')) {
    function sendError(string $message, int $code = 400): void {
        http_response_code($code);
        echo json_encode([
            'success' => false,
            'error' => $message
        ], JSON_UNESCAPED_UNICODE);
        exit();
    }
}

/**
 * Get JSON body from request
 * @return array|null Decoded JSON or null
 */
if (!function_exists('getJsonBody')) {
    function getJsonBody(): ?array {
        $input = file_get_contents('php://input');
        if ((empty($input) || $input === false) && PHP_SAPI === 'cli') {
            $input = file_get_contents('php://stdin');
        }
        if (empty($input)) {
            return null;
        }
        return json_decode((string)$input, true);
    }
}
