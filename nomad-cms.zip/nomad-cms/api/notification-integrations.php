<?php

/**
 * NOMAD CMS - Trusted notification integration catalogue.
 * Registers source-module events consistently for HTTP inboxes, cron and CLI workers.
 * Registration is lazy and never migrates or processes source storage.
 */

declare(strict_types=1);

use NomadCMS\Services\EditorialsHub\Notifications\MentionNotificationIntegration;
use NomadCMS\Services\NotificationService\NotificationModule;
use NomadCMS\Services\Forms\FormNotificationIntegration;
use NomadCMS\Webhooks\Mapping\WebhookNotificationIntegration;

return static function (NotificationModule $module): void {
    (new MentionNotificationIntegration($module))->register();
    (new FormNotificationIntegration($module))->register();
    (new WebhookNotificationIntegration($module))->register();
};
