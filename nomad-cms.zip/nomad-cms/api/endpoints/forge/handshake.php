<?php
/**
 * Forge Handshake Endpoint
 * Returns server's X25519 public key for sealed box encryption
 * 
 * GET /api/endpoints/forge/handshake.php
 */

declare(strict_types=1);

require_once __DIR__ . '/../../bootstrap.php';

use NomadCMS\Middleware\AuthMiddleware;
use NomadCMS\Services\ForgeImportLimits;

// CORS
handlePreflight();

header('Content-Type: application/json');

// SECURITY: Use the same AuthMiddleware pipeline as every other protected
// endpoint (IP-hash binding, authoritative role re-resolution from the DB,
// panic-mode read-only enforcement, forced-password-change gate). Forge ETL
// is a system-level management action, same as backup.php / cache-rebuild.php.
AuthMiddleware::requireAuth();
AuthMiddleware::requirePermission('system:manage:*');

try {
    // Generate session ID
    $sessionId = bin2hex(random_bytes(16));
    
    // Generate X25519 keypair for sealed box
    $keypair = sodium_crypto_box_keypair();
    $publicKey = sodium_crypto_box_publickey($keypair);
    $secretKey = sodium_crypto_box_secretkey($keypair);
    
    // Store secret key in protected directory within api folder
    // Directory is inside api folder with restricted permissions
    $cacheDir = __DIR__ . '/../../storage/forge-sessions';
    if (!is_dir($cacheDir)) {
        mkdir($cacheDir, 0700, true);
    }
    
    // Cleanup expired sessions (older than 1 hour)
    cleanupExpiredSessions($cacheDir, 3600);
    
    // Store session key directly (directory is already protected)
    file_put_contents($cacheDir . '/' . $sessionId . '.key', $secretKey);
    chmod($cacheDir . '/' . $sessionId . '.key', 0600);
    $limits = ForgeImportLimits::current();
    file_put_contents($cacheDir . '/' . $sessionId . '.limits.json', json_encode($limits, JSON_THROW_ON_ERROR));
    
    echo json_encode([
        'success' => true,
        'publicKey' => base64_encode($publicKey),
        'sessionId' => $sessionId,
        'expiresIn' => 3600,
        'limits' => $limits,
    ]);
    
} catch (Exception $e) {
    error_log('[Forge Handshake] Error: ' . $e->getMessage());
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'Handshake failed'
    ]);
}

/**
 * Clean up expired forge sessions
 * Removes session keys and chunk directories older than maxAge seconds
 */
function cleanupExpiredSessions(string $cacheDir, int $maxAge = 3600): void {
    if (!is_dir($cacheDir)) {
        return;
    }
    
    $now = time();
    
    // Cleanup old .key files
    $keyFiles = glob($cacheDir . '/*.key');
    if ($keyFiles) {
        foreach ($keyFiles as $keyFile) {
            if ($now - filemtime($keyFile) > $maxAge) {
                @unlink($keyFile);
                @unlink(substr($keyFile, 0, -4) . '.limits.json');
            }
        }
    }
    
    // Cleanup old chunk directories
    $chunksDir = $cacheDir . '/chunks';
    if (is_dir($chunksDir)) {
        $sessionDirs = glob($chunksDir . '/*', GLOB_ONLYDIR);
        if ($sessionDirs) {
            foreach ($sessionDirs as $sessionDir) {
                // Check meta.json for last update time, or use dir mtime
                $metaFile = $sessionDir . '/meta.json';
                $lastUpdate = file_exists($metaFile) 
                    ? (json_decode(file_get_contents($metaFile), true)['lastUpdate'] ?? filemtime($sessionDir))
                    : filemtime($sessionDir);
                
                if ($now - $lastUpdate > $maxAge) {
                    // Remove all files in directory
                    $files = glob($sessionDir . '/*');
                    if ($files) {
                        foreach ($files as $file) {
                            @unlink($file);
                        }
                    }
                    @rmdir($sessionDir);
                }
            }
        }
        
        // Remove chunks directory if empty
        if (count(glob($chunksDir . '/*')) === 0) {
            @rmdir($chunksDir);
        }
    }
}
