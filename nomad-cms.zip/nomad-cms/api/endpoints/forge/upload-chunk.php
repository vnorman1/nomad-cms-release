<?php
/**
 * Forge Upload Chunk Endpoint
 * Receives encrypted data chunks and stores them temporarily
 * 
 * POST /api/endpoints/forge/upload-chunk.php
 */

declare(strict_types=1);

require_once __DIR__ . '/../../bootstrap.php';

use NomadCMS\Middleware\AuthMiddleware;
use NomadCMS\Security\InputSanitizer;
use NomadCMS\Services\ForgeImportLimits;

// CORS
handlePreflight();

// Only POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Method not allowed']);
    exit;
}

// SECURITY: Use the same AuthMiddleware pipeline as every other protected
// endpoint (IP-hash binding, authoritative role re-resolution from the DB,
// panic-mode read-only enforcement, forced-password-change gate). Forge ETL
// is a system-level management action, same as backup.php / cache-rebuild.php.
AuthMiddleware::requireAuth();
AuthMiddleware::requirePermission('system:manage:*');

try {
    // Get metadata
    $metadataJson = $_POST['metadata'] ?? null;
    if (!$metadataJson) {
        throw new Exception('Missing metadata');
    }
    
    $metadata = json_decode($metadataJson, true);
    if (!$metadata) {
        throw new Exception('Invalid metadata JSON');
    }
    
    $sessionId = $metadata['sessionId'] ?? null;
    $chunkIndex = $metadata['chunkIndex'] ?? null;
    $totalChunks = $metadata['totalChunks'] ?? null;
    $totalSize = $metadata['totalSize'] ?? null;
    $chunkHash = $metadata['chunkHash'] ?? null;
    
    if (!$sessionId || $chunkIndex === null || !$totalChunks) {
        throw new Exception('Missing required metadata fields');
    }
    
    // SECURITY: Strict sessionId validation via InputSanitizer
    $sessionId = InputSanitizer::forgeSessionId($sessionId);
    if ($sessionId === null) {
        error_log('[SECURITY] Invalid session ID format in upload-chunk.php');
        http_response_code(400);
        echo json_encode(['success' => false, 'error' => 'Invalid session ID format']);
        exit;
    }
    
    // SECURITY: Validate chunk index
    $chunkIndex = InputSanitizer::forgeChunkIndex($chunkIndex);
    if ($chunkIndex === null) {
        http_response_code(400);
        echo json_encode(['success' => false, 'error' => 'Invalid chunk index']);
        exit;
    }
    if (!is_int($totalChunks) || $totalChunks < 1 || $totalChunks > 1024 || $chunkIndex >= $totalChunks
        || !is_int($totalSize) || $totalSize < 1 || !is_string($chunkHash)) {
        throw new InvalidArgumentException('Invalid chunk metadata');
    }
    // Existing Forge clients send SHA-256 in base64; accept hex as well.
    if (!preg_match('/^[a-f0-9]{64}$/', $chunkHash)) {
        $decodedHash = base64_decode($chunkHash, true);
        if ($decodedHash === false || strlen($decodedHash) !== 32) {
            throw new InvalidArgumentException('Invalid chunk checksum');
        }
        $chunkHash = bin2hex($decodedHash);
    }
    
    // Validate session exists (storage within api folder)
    $cacheDirPath = __DIR__ . '/../../storage/forge-sessions';
    // Ensure directory exists (may not exist on fresh install)
    if (!is_dir($cacheDirPath)) {
        mkdir($cacheDirPath, 0700, true);
    }
    $cacheDir = realpath($cacheDirPath);
    if (!$cacheDir) {
        throw new Exception('Storage directory not found');
    }
    
    $sessionFile = $cacheDir . '/' . $sessionId . '.key';
    
    if (!file_exists($sessionFile) || time() - filemtime($sessionFile) > 3600) {
        throw new Exception('Invalid or expired session');
    }
    $limitsFile = $cacheDir . '/' . $sessionId . '.limits.json';
    $limits = is_file($limitsFile) ? json_decode(file_get_contents($limitsFile), true, 64, JSON_THROW_ON_ERROR) : ForgeImportLimits::current();
    if ($totalSize > ForgeImportLimits::encryptedCeiling($limits)) {
        throw new LengthException('FORGE_PAYLOAD_LIMIT', 413);
    }
    
    // Get chunk data
    if (!isset($_FILES['chunk']) || $_FILES['chunk']['error'] !== UPLOAD_ERR_OK) {
        throw new Exception('No chunk file received');
    }
    
    if ($_FILES['chunk']['size'] > 1024 * 1024 || $_FILES['chunk']['size'] > $totalSize) {
        throw new LengthException('Chunk exceeds size limit', 413);
    }
    $chunkData = file_get_contents($_FILES['chunk']['tmp_name']);
    if ($chunkData === false || !hash_equals($chunkHash, hash('sha256', $chunkData))) {
        throw new InvalidArgumentException('Chunk checksum mismatch');
    }
    
    // Store chunk temporarily
    $chunkDir = $cacheDir . '/chunks/' . $sessionId;
    if (!is_dir($chunkDir)) {
        mkdir($chunkDir, 0700, true);
    }
    
    // SECURITY: Final realpath check to ensure we're still in the allowed directory
    $realChunkDir = realpath($chunkDir) ?: $chunkDir;
    if (strpos($realChunkDir, $cacheDir) !== 0) {
        error_log('[SECURITY] Path escape attempt detected: ' . $realChunkDir);
        throw new Exception('Invalid storage path');
    }
    
    $chunkFile = $chunkDir . '/chunk_' . str_pad((string)$chunkIndex, 5, '0', STR_PAD_LEFT);
    
    // Store/update metadata
    $metaFile = $chunkDir . '/meta.json';
    $handle = fopen($metaFile, 'c+');
    if ($handle === false || !flock($handle, LOCK_EX)) {
        throw new RuntimeException('Unable to lock upload metadata');
    }
    try {
        $raw = stream_get_contents($handle);
        $existingMeta = $raw !== '' ? json_decode($raw, true, 64, JSON_THROW_ON_ERROR) : [];
        if ($existingMeta !== [] && ($existingMeta['totalChunks'] !== $totalChunks || $existingMeta['totalSize'] !== $totalSize)) {
            throw new InvalidArgumentException('Upload metadata changed');
        }
        // Retrying an identical chunk is idempotent; differing bytes never replace it.
        $duplicate = is_file($chunkFile);
        if ($duplicate && !hash_equals($chunkHash, hash_file('sha256', $chunkFile))) {
            throw new InvalidArgumentException('Chunk already exists with different bytes');
        }
        $receivedSize = (int) ($existingMeta['receivedSize'] ?? 0);
        if (!$duplicate && $receivedSize + strlen($chunkData) > $totalSize) {
            throw new LengthException('Uploaded bytes exceed declared size', 413);
        }
        if (!$duplicate && file_put_contents($chunkFile, $chunkData) !== strlen($chunkData)) {
            throw new RuntimeException('Unable to store chunk');
        }
        $existingMeta['totalChunks'] = $totalChunks;
        $existingMeta['totalSize'] = $totalSize;
        $existingMeta['receivedChunks'] = count(glob($chunkDir . '/chunk_*') ?: []);
        $existingMeta['receivedSize'] = $receivedSize + ($duplicate ? 0 : strlen($chunkData));
        $existingMeta['lastUpdate'] = time();
        rewind($handle);
        ftruncate($handle, 0);
        fwrite($handle, json_encode($existingMeta, JSON_THROW_ON_ERROR));
        fflush($handle);
    } finally {
        flock($handle, LOCK_UN);
        fclose($handle);
    }
    
    http_response_code(200);
    header('Content-Type: application/json');
    echo json_encode([
        'success' => true,
        'chunkIndex' => $chunkIndex,
        'received' => $existingMeta['receivedChunks'],
        'total' => $totalChunks,
    ]);
    
} catch (Exception $e) {
    http_response_code($e->getCode() === 413 ? 413 : 400);
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
}
