<?php
/**
 * NOMAD CMS - Media API Endpoint (Controller)
 * 
 * Thin HTTP dispatcher for media operations:
 * - GET: List media files or fetch single file info with usage details
 * - POST/PUT: Register external CDN media or update media metadata / binary overwrite
 * - DELETE: Delete single or batch media files with usage verification
 * 
 * Delegates all business logic, inverted SQL indexing, and file system operations
 * to NomadCMS\Services\MediaService.
 */

declare(strict_types=1);

require_once __DIR__ . '/../bootstrap.php';
require_once __DIR__ . '/../lib/image.php';

use NomadCMS\Database\ContentDatabase;
use NomadCMS\Middleware\AuthMiddleware;
use NomadCMS\Middleware\CSRFMiddleware;
use NomadCMS\Middleware\RateLimitMiddleware;
use NomadCMS\Security\ClientIpResolver;
use NomadCMS\Services\MediaService;
use NomadCMS\Services\MediaAliasService;
use NomadCMS\Services\MediaWebpConversionService;

// Handle CORS preflight
handlePreflight();

header('Content-Type: application/json');

$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
$mediaService = MediaService::getInstance();

try {
    switch ($method) {
        case 'GET':
            // Require auth + read permission for media library access
            // Supports ABAC 'own' scope: media:read:* sees everything, media:read:own sees own uploads
            AuthMiddleware::requireAuth();
            AuthMiddleware::requireAnyGrantedScope(['media:read:*', 'media:read:own']);
            $hasMediaReadAll = AuthMiddleware::hasGrantedScope('media:read:*');
            $hasMediaReadOwn = AuthMiddleware::hasGrantedScope('media:read:own');

            if (!$hasMediaReadAll && !$hasMediaReadOwn) {
                http_response_code(403);
                echo json_encode(['success' => false, 'error' => 'Nincs jogosultságod a művelet végrehajtásához.', 'code' => 'FORBIDDEN_ACTION']);
                exit;
            }

            $mediaOwnOnly = !$hasMediaReadAll && $hasMediaReadOwn;
            $currentUserUuid = AuthMiddleware::getCurrentUser()->uuid ?? null;
            $rawFile = $_GET['file'] ?? null;

            if ($rawFile) {
                // Single file info with usage
                $filename = MediaService::sanitizeMediaIdentifier((string)$rawFile);
                if (!$filename) {
                    http_response_code(400);
                    echo json_encode(['success' => false, 'error' => 'Invalid file identifier or URL']);
                    exit;
                }

                $info = $mediaService->getMediaFileInfo($filename);
                if ($mediaOwnOnly && !empty($info['success'])) {
                    $owner = $info['file']['uploadedBy'] ?? null;
                    if ($owner === null || $currentUserUuid === null || !hash_equals($owner, $currentUserUuid)) {
                        http_response_code(403);
                        echo json_encode(['success' => false, 'error' => 'Nincs jogosultságod ehhez a fájlhoz.']);
                        exit;
                    }
                }
                echo json_encode($info);
            } else {
                // List all media files (filtered to own uploads if only media:read:own is granted)
                echo json_encode($mediaService->getAllMediaFiles($mediaOwnOnly ? $currentUserUuid : null));
            }
            break;

        case 'POST':
        case 'PUT':
            // SECURITY: Validate CSRF token for session-based requests
            CSRFMiddleware::validateForSession();

            // Binary overwrite (Creative Studio "Felülírás/Overwrite"): multipart branch
            if (($_POST['action'] ?? null) === 'overwrite_binary') {
                echo json_encode(handleOverwriteBinary($mediaService));
                break;
            }

            // Require auth for metadata updates / CDN registration
            AuthMiddleware::requireAuth();
            AuthMiddleware::requireAnyGrantedScope([
                'media:update:*', 'media:update:own',
                'media:upload:*', 'media:upload:own',
                'media:create:*', 'media:create:own',
            ]);
            $hasMediaUpdateAll = AuthMiddleware::hasGrantedScope('media:update:*');
            $hasMediaUpdateOwn = AuthMiddleware::hasGrantedScope('media:update:own');
            $hasMediaCreateAny = AuthMiddleware::hasGrantedScope('media:upload:*')
                || AuthMiddleware::hasGrantedScope('media:upload:own')
                || AuthMiddleware::hasGrantedScope('media:create:*')
                || AuthMiddleware::hasGrantedScope('media:create:own');
            $currentUserUuid = AuthMiddleware::getCurrentUser()->uuid ?? null;

            $input = json_decode(file_get_contents('php://input') ?: '', true) ?? $_POST;
            $rawFilename = $input['url'] ?? $input['filename'] ?? $_GET['file'] ?? null;

            if (!$rawFilename) {
                http_response_code(400);
                echo json_encode(['success' => false, 'error' => 'Missing filename or URL parameter']);
                exit;
            }

            $filename = MediaService::sanitizeMediaIdentifier((string)$rawFilename);
            if ($filename) $filename = MediaAliasService::resolve($filename);
            if (!$filename) {
                http_response_code(400);
                echo json_encode(['success' => false, 'error' => 'Invalid file identifier or URL']);
                exit;
            }

            $isNewRegistration = !ContentDatabase::mediaMetaExists($filename);
            $existingMeta = $isNewRegistration ? null : ContentDatabase::getMediaMeta($filename);

            if (!$isNewRegistration && !$hasMediaUpdateAll) {
                $metaOwner = $existingMeta['uploaded_by'] ?? null;
                $ownsThisFile = $hasMediaUpdateOwn
                    && $currentUserUuid !== null
                    && $metaOwner !== null
                    && hash_equals($metaOwner, $currentUserUuid);
                if (!$ownsThisFile) {
                    http_response_code(403);
                    echo json_encode(['success' => false, 'error' => 'Nincs jogosultságod ennek a fájlnak a módosításához.', 'code' => 'FORBIDDEN_MEDIA_UPDATE']);
                    exit;
                }
            }

            if ($isNewRegistration && !$hasMediaUpdateAll && !$hasMediaCreateAny) {
                http_response_code(403);
                echo json_encode(['success' => false, 'error' => 'Nincs jogosultságod új média regisztrálásához.', 'code' => 'FORBIDDEN_MEDIA_CREATE']);
                exit;
            }

            $altTexts = is_array($input['alt'] ?? null) ? $input['alt'] : [];
            $title = isset($input['title']) ? (string)$input['title'] : null;
            $caption = isset($input['caption']) ? (string)$input['caption'] : null;
            $tags = is_array($input['tags'] ?? null) ? $input['tags'] : null;
            $mediaType = isset($input['media_type']) ? (string)$input['media_type'] : null;
            $dimensions = is_array($input['dimensions'] ?? null) ? $input['dimensions'] : null;
            $mimeType = isset($input['mime_type']) ? (string)$input['mime_type'] : null;

            // Sanitize ALT text inputs per language
            $sanitizedAlt = [];
            foreach ($altTexts as $lang => $text) {
                $cleanLang = preg_replace('/[^a-zA-Z0-9_-]/', '', (string)$lang);
                if (!empty($cleanLang)) {
                    $sanitizedAlt[$cleanLang] = trim(strip_tags((string)$text));
                }
            }

            $isExternal = MediaService::isExternalUrl($filename) ? 1 : 0;

            if ($isExternal && empty($mediaType)) {
                $ext = strtolower(pathinfo(parse_url($filename, PHP_URL_PATH) ?? '', PATHINFO_EXTENSION));
                $videoExts = ['mp4', 'webm', 'mov', 'avi', 'mkv'];
                $audioExts = ['mp3', 'wav', 'ogg', 'flac', 'aac', 'm4a'];
                if (in_array($ext, $videoExts, true)) {
                    $mediaType = 'video';
                } elseif (in_array($ext, $audioExts, true)) {
                    $mediaType = 'audio';
                } else {
                    $mediaType = 'image';
                }
            }

            $saved = ContentDatabase::saveMediaMeta(
                $filename,
                $sanitizedAlt,
                $title,
                $caption,
                $tags,
                $isExternal,
                $mediaType,
                $dimensions,
                $mimeType,
                $currentUserUuid
            );

            if ($saved) {
                $info = $mediaService->getMediaFileInfo($filename);
                echo json_encode([
                    'success' => true,
                    'message' => $isExternal ? 'External media registered successfully' : 'Metadata updated successfully',
                    'file' => $info['file'] ?? null
                ]);
            } else {
                http_response_code(500);
                echo json_encode(['success' => false, 'error' => 'Failed to save metadata']);
            }
            break;

        case 'DELETE':
            // SECURITY: Validate CSRF token for session-based requests
            CSRFMiddleware::validateForSession();

            AuthMiddleware::requireAuth();
            $hasMediaDeleteAll = AuthMiddleware::hasGrantedScope('media:delete:*');
            $hasMediaDeleteOwn = AuthMiddleware::hasGrantedScope('media:delete:own');
            if (!$hasMediaDeleteAll && !$hasMediaDeleteOwn) {
                http_response_code(403);
                echo json_encode(['success' => false, 'error' => 'Nincs jogosultságod a művelet végrehajtásához.', 'code' => 'FORBIDDEN_ACTION']);
                exit;
            }
            $deleteOwnOnly = !$hasMediaDeleteAll && $hasMediaDeleteOwn;
            $forceDelete = isset($_GET['force']) && $_GET['force'] === 'true';

            $rawFilename = $_GET['file'] ?? null;

            // Batch delete: JSON body with { files: [...], force: true }
            if (!$rawFilename) {
                $bodyRaw = file_get_contents('php://input');
                $body = !empty($bodyRaw) ? json_decode($bodyRaw, true) : null;

                if (is_array($body) && isset($body['files']) && is_array($body['files'])) {
                    $isForce = !empty($body['force']) || $forceDelete;
                    $currentUserUuid = $deleteOwnOnly ? (AuthMiddleware::getCurrentUser()->uuid ?? null) : null;

                    echo json_encode($mediaService->batchDeleteMediaFiles(
                        $body['files'],
                        $isForce,
                        $deleteOwnOnly,
                        $currentUserUuid
                    ));
                    break;
                }

                http_response_code(400);
                echo json_encode(['success' => false, 'error' => 'Missing file parameter']);
                exit;
            }

            $filename = MediaService::sanitizeMediaIdentifier((string)$rawFilename);
            if (!$filename) {
                http_response_code(400);
                echo json_encode(['success' => false, 'error' => 'Invalid file parameter']);
                exit;
            }

            if ($deleteOwnOnly) {
                $meta = ContentDatabase::getMediaMeta($filename);
                $owner = $meta['uploaded_by'] ?? null;
                $currentUserUuid = AuthMiddleware::getCurrentUser()->uuid ?? null;
                if ($owner === null || $currentUserUuid === null || !hash_equals($owner, $currentUserUuid)) {
                    http_response_code(403);
                    echo json_encode(['success' => false, 'error' => 'Nincs jogosultságod ehhez a fájlhoz.']);
                    exit;
                }
            }

            $result = $mediaService->deleteMediaFile($filename, $forceDelete);
            if (!$result['success'] && ($result['error'] ?? '') === 'File not found') {
                http_response_code(404);
            } elseif (!$result['success'] && ($result['error'] ?? '') === 'Failed to delete file') {
                http_response_code(500);
            }
            echo json_encode($result);
            break;

        default:
            http_response_code(405);
            echo json_encode(['success' => false, 'error' => 'Method not allowed']);
            break;
    }
} catch (\Throwable $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => ($_ENV['APP_DEBUG'] ?? 'false') === 'true' ? $e->getMessage() : 'Internal server error'
    ]);
}

/**
 * Handle multipart binary image replacement (Creative Studio "Felülírás/Overwrite")
 */
function handleOverwriteBinary(MediaService $mediaService): array
{
    @ini_set('memory_limit', '512M');
    @set_time_limit(180);

    AuthMiddleware::requireAuth();
    AuthMiddleware::requireAnyGrantedScope(['media:update:*', 'media:update:own']);
    $hasMediaUpdateAll = AuthMiddleware::hasGrantedScope('media:update:*');
    $hasMediaUpdateOwn = AuthMiddleware::hasGrantedScope('media:update:own');
    $currentUserUuid = AuthMiddleware::getCurrentUser()->uuid ?? null;

    $clientIp = ClientIpResolver::resolve();
    RateLimitMiddleware::check(
        key: 'media-overwrite:' . ($currentUserUuid ?: $clientIp),
        maxRequests: 120,
        windowSeconds: 60
    );

    $rawFilename = $_POST['filename'] ?? null;
    if (!$rawFilename) {
        http_response_code(400);
        return ['success' => false, 'error' => 'Missing filename parameter'];
    }

    $filename = MediaService::sanitizeMediaIdentifier((string)$rawFilename);
    if (!$filename || MediaService::isExternalUrl($filename)) {
        http_response_code(400);
        return ['success' => false, 'error' => 'Only local uploaded files can be overwritten'];
    }

    $filename = MediaAliasService::resolve($filename);
    $existingMeta = ContentDatabase::mediaMetaExists($filename) ? ContentDatabase::getMediaMeta($filename) : null;
    if (!$hasMediaUpdateAll) {
        $metaOwner = $existingMeta['uploaded_by'] ?? null;
        $ownsThisFile = $hasMediaUpdateOwn
            && $currentUserUuid !== null
            && $metaOwner !== null
            && hash_equals($metaOwner, $currentUserUuid);
        if (!$ownsThisFile) {
            http_response_code(403);
            return ['success' => false, 'error' => 'Nincs jogosultságod ennek a fájlnak a módosításához.', 'code' => 'FORBIDDEN_MEDIA_UPDATE'];
        }
    }

    $uploadDir = defined('UPLOAD_DIR') ? UPLOAD_DIR : (dirname(__DIR__) . '/uploads/');
    $targetPath = $uploadDir . $filename;

    $realUploadDir = realpath($uploadDir);
    $realTargetPath = realpath($targetPath);
    if ($realUploadDir === false || $realTargetPath === false || strpos($realTargetPath, $realUploadDir) !== 0) {
        http_response_code(404);
        return ['success' => false, 'error' => 'File not found'];
    }
    if (!is_file($realTargetPath)) {
        http_response_code(404);
        return ['success' => false, 'error' => 'File not found'];
    }

    if (!isset($_FILES['file']) || $_FILES['file']['error'] !== UPLOAD_ERR_OK) {
        $errorCode = $_FILES['file']['error'] ?? UPLOAD_ERR_NO_FILE;
        $errorMessages = [
            UPLOAD_ERR_INI_SIZE => 'File exceeds upload_max_filesize',
            UPLOAD_ERR_FORM_SIZE => 'File exceeds MAX_FILE_SIZE',
            UPLOAD_ERR_PARTIAL => 'File was only partially uploaded',
            UPLOAD_ERR_NO_FILE => 'No replacement file was uploaded',
            UPLOAD_ERR_NO_TMP_DIR => 'Missing temporary folder',
            UPLOAD_ERR_CANT_WRITE => 'Failed to write file to disk',
            UPLOAD_ERR_EXTENSION => 'File upload stopped by extension',
        ];
        http_response_code(400);
        return ['success' => false, 'error' => $errorMessages[$errorCode] ?? 'Unknown upload error'];
    }

    $tmpPath = $_FILES['file']['tmp_name'];

    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mimeType = finfo_file($finfo, $tmpPath);
    finfo_close($finfo);

    $allowedMimeToExt = [
        'image/jpeg' => ['jpg', 'jpeg'],
        'image/png' => ['png'],
        'image/webp' => ['webp'],
        'image/gif' => ['gif'],
        'image/avif' => ['avif'],
    ];
    if (!isset($allowedMimeToExt[$mimeType])) {
        http_response_code(400);
        return ['success' => false, 'error' => 'Invalid replacement file type. Allowed: JPG, PNG, WebP, GIF, AVIF'];
    }

    $imageInfo = @getimagesize($tmpPath);
    if ($imageInfo === false) {
        http_response_code(400);
        return ['success' => false, 'error' => 'Replacement file is not a valid image'];
    }

    if (($_POST['convert_to_webp'] ?? null) === '1') {
        try {
            $targetFilename = MediaWebpConversionService::replace($filename, $tmpPath, $uploadDir, $currentUserUuid ?? 'system');
            $info = $mediaService->getMediaFileInfo($targetFilename);
            return [
                'success' => true,
                'message' => 'Image overwritten as WebP; existing URLs follow its new filename.',
                'file' => $info['file'] ?? null,
            ];
        } catch (\NomadCMS\Database\OptimisticLockException $error) {
            http_response_code(409);
            return ['success' => false, 'error' => $error->getMessage()];
        } catch (\InvalidArgumentException $error) {
            http_response_code(409);
            return ['success' => false, 'error' => $error->getMessage()];
        } catch (\Throwable $error) {
            http_response_code(500);
            return ['success' => false, 'error' => $error->getMessage()];
        }
    }

    $currentExt = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
    $currentExt = $currentExt === 'jpeg' ? 'jpg' : $currentExt;
    $incomingExts = array_map(fn($e) => $e === 'jpeg' ? 'jpg' : $e, $allowedMimeToExt[$mimeType]);

    $stagingPath = $targetPath . '.tmp-' . bin2hex(random_bytes(6));
    $finalMime = $mimeType;

    if (in_array($currentExt, $incomingExts, true)) {
        if (!@move_uploaded_file($tmpPath, $stagingPath)) {
            if (!@copy($tmpPath, $stagingPath)) {
                http_response_code(500);
                return ['success' => false, 'error' => 'Failed to stage replacement file'];
            }
        }
    } else {
        $sourceImage = createImageFromFile($tmpPath, $mimeType);
        if ($sourceImage === false) {
            http_response_code(400);
            return ['success' => false, 'error' => 'Failed to decode replacement image for format conversion'];
        }

        $conversionSuccess = false;
        switch ($currentExt) {
            case 'webp':
                $quality = (int)($_ENV['WEBP_QUALITY'] ?? 90);
                $conversionSuccess = imagewebp($sourceImage, $stagingPath, $quality);
                $finalMime = 'image/webp';
                break;
            case 'jpg':
                $conversionSuccess = imagejpeg($sourceImage, $stagingPath, 90);
                $finalMime = 'image/jpeg';
                break;
            case 'png':
                imagealphablending($sourceImage, false);
                imagesavealpha($sourceImage, true);
                $conversionSuccess = imagepng($sourceImage, $stagingPath, 8);
                $finalMime = 'image/png';
                break;
            case 'gif':
                $conversionSuccess = imagegif($sourceImage, $stagingPath);
                $finalMime = 'image/gif';
                break;
            default:
                $conversionSuccess = false;
                break;
        }

        imagedestroy($sourceImage);

        if (!$conversionSuccess || !file_exists($stagingPath)) {
            http_response_code(500);
            return ['success' => false, 'error' => "Failed to convert replacement image to .{$currentExt} format"];
        }
    }

    @chmod($stagingPath, 0644);

    if (!@rename($stagingPath, $targetPath)) {
        if (!@copy($stagingPath, $targetPath)) {
            @unlink($stagingPath);
            http_response_code(500);
            return ['success' => false, 'error' => 'Failed to write replacement file (permission denied)'];
        }
        @unlink($stagingPath);
    }

    @chmod($targetPath, 0644);
    @touch($targetPath);
    clearstatcache(true, $targetPath);

    try {
        $newDimensions = @getimagesize($targetPath);
        if ($newDimensions !== false) {
            ContentDatabase::saveMediaMeta(
                filename: $filename,
                altTexts: $existingMeta['alt'] ?? [],
                title: $existingMeta['title'] ?? null,
                caption: $existingMeta['caption'] ?? null,
                tags: $existingMeta['tags'] ?? null,
                isExternal: 0,
                mediaType: 'image',
                dimensions: ['width' => $newDimensions[0], 'height' => $newDimensions[1]],
                mimeType: $finalMime,
                uploadedBy: $existingMeta['uploaded_by'] ?? $currentUserUuid
            );
        }
    } catch (\Throwable $e) {
        error_log('[Media Overwrite] Failed to refresh dimensions in media_meta: ' . $e->getMessage());
    }

    clearstatcache(true, $targetPath);
    $mtime = @filemtime($targetPath) ?: time();
    $info = $mediaService->getMediaFileInfo($filename);
    if (isset($info['file'])) {
        $info['file']['modifiedAt'] = date('c', $mtime);
        $info['file']['previewUrl'] = '/api/uploads/' . $filename . '?t=' . $mtime;
    }

    return [
        'success' => true,
        'message' => 'File overwritten successfully',
        'file' => $info['file'] ?? null,
    ];
}
