<?php
/**
 * NOMAD CMS - Versions API Endpoint
 * 
 * Handles all version history operations using query parameters:
 * - GET ?action=history&slot_key=X           - Get version history
 * - GET ?action=version&slot_key=X&version=N - Get specific version
 * - GET ?action=settings                     - Get versioning settings
 * - GET ?action=stats                        - Get storage statistics
 * - POST ?action=restore&slot_key=X          - Restore to version
 * - POST ?action=settings                    - Update versioning settings
 * - POST ?action=cleanup                     - Run cleanup task
 * - DELETE ?action=delete&slot_key=X         - Delete all versions
 * 
 * HYBRID VERSIONING (NEW):
 * - POST ?action=promote&version_id=X        - Promote shadow to commit/named
 * - POST ?action=rename&version_id=X         - Rename commit/named version
 * - DELETE ?action=delete_version&version_id=X - Delete specific version
 * - POST ?action=cleanup_shadows             - Cleanup expired shadow versions
 * 
 * SECURITY:
 * - All endpoints require authentication
 * - Rate limited: 60 requests/minute for history, 15 requests/minute for restore
 * - Admin-only: settings, cleanup, delete operations
 */

declare(strict_types=1);

require_once __DIR__ . '/../bootstrap.php';

use NomadCMS\Services\VersioningService;
use NomadCMS\Services\Versioning\VersionRepository;
use NomadCMS\Services\LoggerService;
use NomadCMS\Middleware\AuthMiddleware;
use NomadCMS\Middleware\RateLimitMiddleware;

// Apply CORS headers
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-API-Key');
header('Content-Type: application/json');

// Handle preflight
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

// Authenticate request
try {
    $currentUser = AuthMiddleware::requireAuth();
} catch (Exception $e) {
    http_response_code(401);
    echo json_encode(['success' => false, 'error' => 'Authentication required']);
    exit;
}

// Parse request
$method = $_SERVER['REQUEST_METHOD'];
$action = $_GET['action'] ?? '';
$slotKey = isset($_GET['slot_key']) ? urldecode($_GET['slot_key']) : '';
$versionNumber = isset($_GET['version']) ? (int) $_GET['version'] : 0;

// Get request body for POST/PUT
$input = [];
if (in_array($method, ['POST', 'PUT'])) {
    $rawInput = file_get_contents('php://input');
    if ($rawInput) {
        $input = json_decode($rawInput, true) ?? [];
    }
}

try {
    $versioning = VersioningService::getInstance();
    
    // =========================================================================
    // RATE LIMITING - Apply appropriate limits based on action type
    // =========================================================================
    
    // Stricter limits for write operations
    $isWriteOperation = in_array($action, ['restore', 'collection_restore', 'collection_rename', 'collection_delete_version', 'collection_delete_all', 'collection_promote', 'settings', 'cleanup', 'delete', 'promote', 'rename', 'delete_version', 'cleanup_shadows', 'prune_noise']);
    if ($isWriteOperation) {
        // 15 write operations per minute per IP
        RateLimitMiddleware::check(
            key: 'versions:write:' . ($_SERVER['REMOTE_ADDR'] ?? 'unknown'),
            maxRequests: 15,
            windowSeconds: 60
        );
    } else {
        // 60 read operations per minute per IP
        RateLimitMiddleware::check(
            key: 'versions:read:' . ($_SERVER['REMOTE_ADDR'] ?? 'unknown'),
            maxRequests: 60,
            windowSeconds: 60
        );
    }
    
    // =========================================================================
    // SETTINGS ROUTES
    // =========================================================================
    
    // GET ?action=settings - Get versioning settings
    if ($method === 'GET' && $action === 'settings') {
        $settings = $versioning->getAllSettings();
        echo json_encode([
            'success' => true,
            'settings' => $settings
        ]);
        exit;
    }
    
    // POST ?action=settings - Update versioning settings
    if ($method === 'POST' && $action === 'settings') {
        // RBAC: system:manage:* (consistent with cache-settings.php,
        // backup.php, cache-rebuild.php - all system-level admin settings
        // use the same permission tier so the "Cache and Version" tab in
        // Settings works uniformly for a system:manage:*-only role).
        if (!AuthMiddleware::hasPermission('system:manage:*') && !($currentUser->is_admin ?? false)) {
            http_response_code(403);
            echo json_encode(['success' => false, 'error' => 'Admin access required']);
            exit;
        }
        
        $updated = [];
        foreach ($input as $key => $value) {
            if (is_string($value)) {
                $versioning->setSetting($key, $value);
                $updated[$key] = $value;
            }
        }
        
        echo json_encode([
            'success' => true,
            'updated' => $updated
        ]);
        exit;
    }
    
    // =========================================================================
    // STATS ROUTES
    // =========================================================================
    
    // GET ?action=stats - Get storage statistics
    if ($method === 'GET' && $action === 'stats') {
        AuthMiddleware::requirePermission('versions:read:*');
        
        $stats = $versioning->getStorageStats();
        echo json_encode([
            'success' => true,
            'stats' => $stats
        ]);
        exit;
    }
    
    // POST ?action=cleanup - Run cleanup task
    if ($method === 'POST' && $action === 'cleanup') {
        // RBAC: system:manage:* (consistent with settings action above)
        if (!AuthMiddleware::hasPermission('system:manage:*') && !($currentUser->is_admin ?? false)) {
            http_response_code(403);
            echo json_encode(['success' => false, 'error' => 'Admin access required']);
            exit;
        }
        
        $result = $versioning->cleanupOldVersions();
        echo json_encode([
            'success' => true,
            'result' => $result
        ]);
        exit;
    }
    
    // =========================================================================
    // VERSION HISTORY ROUTES
    // =========================================================================
    
    // Helper: Validate slot access
    //
    // Two independent gates, in this order:
    //   1. The slot must exist -> 404 otherwise, so the endpoint does not
    //      confirm or deny the existence of arbitrary slot keys.
    //   2. The caller's role must have the slot in its slot_access patterns.
    //
    // SECURITY (gate 2): a version record carries a full content snapshot, so
    // reading version history/versions of a slot is equivalent to reading the
    // slot's content. data.php enforces requireSlotAccess() before serving
    // content; without the same check here, a role scoped to e.g. "cikk*" but
    // holding versions:read:* could read the complete snapshot history of ANY
    // slot - including slots data.php would refuse to show it. The restore
    // route already called requireSlotAccess() separately; centralising it here
    // closes the same hole on the history and version read routes.
    //
    // Gate 2 answers 403 (SLOT_ACCESS_DENIED, via AuthMiddleware) rather than
    // masking itself as a 404. Slot keys are not secrets - schema.php serves
    // the slot schema publicly and unauthenticated - so distinguishing
    // "exists but not yours" from "does not exist" discloses nothing, and the
    // frontend already renders SLOT_ACCESS_DENIED as an actionable message
    // (see client.ts).
    $validateSlotAccess = function(string $slotKey) use ($currentUser): void {
        // Admins can access any slot (even for debugging)
        if ($currentUser->is_admin ?? false) {
            return;
        }
        
        // Check if slot exists in database
        $slotData = \NomadCMS\Database\CollectionDatabase::isRegistered($slotKey) ? [] : \NomadCMS\Database\ContentDatabase::getSlot($slotKey);
        if ($slotData === null) {
            http_response_code(404);
            echo json_encode(['success' => false, 'error' => 'Slot not found']);
            exit;
        }
        
        // Role's slot_access must cover this slot (exits 403 if not)
        AuthMiddleware::requireSlotAccess($slotKey);
    };
    
    // GET ?action=history&slot_key=X - Get version history
    if (in_array($action,['collection_history','collection_version','collection_restore','collection_rename','collection_delete_version','collection_delete_all','collection_promote'],true)) {
        if (!\NomadCMS\Database\CollectionDatabase::isRegistered($slotKey)) throw new \OutOfBoundsException('Collection not found');
        echo json_encode(\NomadCMS\Services\CollectionHistoryService::handle($slotKey,$action,$method,$_GET,$input),JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
        exit;
    }
    if ($method === 'GET' && $action === 'history') {
        if (empty($slotKey)) {
            http_response_code(400);
            echo json_encode(['success' => false, 'error' => 'Missing slot_key parameter']);
            exit;
        }
        
        // Validate slot access
        $validateSlotAccess($slotKey);
        
        // RBAC: Check versions:read:* permission - if not present, silently return empty list
        if (!AuthMiddleware::hasPermission('versions:read:*') && !($currentUser->is_admin ?? false)) {
            // Silent permission denial: return empty history instead of 403
            echo json_encode([
                'success' => true,
                'slot_key' => $slotKey,
                'versions' => [],
                'total_count' => 0,
                'limit' => 0,
                'offset' => 0,
                'include_shadows' => false
            ]);
            exit;
        }
        
        $limit = (int) ($_GET['limit'] ?? 20);
        $offset = (int) ($_GET['offset'] ?? 0);
        $includeShadows = filter_var($_GET['include_shadows'] ?? 'false', FILTER_VALIDATE_BOOLEAN);
        
        $history = $versioning->getVersionHistory($slotKey, $limit, $offset, $includeShadows);
        $totalCount = $versioning->getVersionCount($slotKey, $includeShadows);
        
        echo json_encode([
            'success' => true,
            'slot_key' => $slotKey,
            'versions' => $history,
            'total_count' => $totalCount,
            'limit' => $limit,
            'offset' => $offset,
            'include_shadows' => $includeShadows
        ]);
        exit;
    }
    
    // GET ?action=version&slot_key=X&version=N - Get specific version
    if ($method === 'GET' && $action === 'version') {
        if (empty($slotKey) || $versionNumber < 1) {
            http_response_code(400);
            echo json_encode(['success' => false, 'error' => 'Missing slot_key or version parameter']);
            exit;
        }
        
        // Validate slot access
        $validateSlotAccess($slotKey);
        
        // RBAC: Check versions:read:* permission - if not present, silently return error
        if (!AuthMiddleware::hasPermission('versions:read:*') && !($currentUser->is_admin ?? false)) {
            // Silent permission denial: return not found instead of 403
            http_response_code(404);
            echo json_encode(['success' => false, 'error' => 'Version not found']);
            exit;
        }
        
        $version = $versioning->getVersion($slotKey, $versionNumber);
        
        if (!$version) {
            http_response_code(404);
            echo json_encode(['success' => false, 'error' => 'Version not found']);
            exit;
        }
        
        echo json_encode([
            'success' => true,
            'version' => $version
        ]);
        exit;
    }
    
    // =========================================================================
    // RESTORE ROUTE
    // =========================================================================
    
    // POST ?action=restore&slot_key=X - Restore to specific version
    if ($method === 'POST' && $action === 'restore') {
        if (empty($slotKey)) {
            http_response_code(400);
            echo json_encode(['success' => false, 'error' => 'Missing slot_key parameter']);
            exit;
        }
        
        // Validate slot access
        $validateSlotAccess($slotKey);
        
        // RBAC: Require versions:restore permission.
        // Slot access is already enforced by $validateSlotAccess() above (it
        // calls requireSlotAccess() for every version route), so it is not
        // repeated here.
        try {
            AuthMiddleware::requirePermission('versions:restore:*');
        } catch (\Exception $e) {
            http_response_code(403);
            echo json_encode(['success' => false, 'error' => 'Nincs jogosultság a visszaállításhoz']);
            exit;
        }
        
        $targetVersion = (int) ($input['version'] ?? 0);
        $useAtomicRestore = (bool) ($input['atomic'] ?? true); // Default to atomic restore
        
        if (!$targetVersion) {
            http_response_code(400);
            echo json_encode(['success' => false, 'error' => 'Missing version parameter']);
            exit;
        }
        
        // Use atomic restore (database-level transaction) by default
        if ($useAtomicRestore) {
            $result = $versioning->atomicRestore(
                $slotKey, 
                $targetVersion, 
                $currentUser->email ?? 'unknown'
            );
        } else {
            // Legacy restore (returns content only, client must save)
            $currentContent = $input['current_content'] ?? null;
            if ($currentContent === null) {
                http_response_code(400);
                echo json_encode(['success' => false, 'error' => 'Missing current_content for non-atomic restore']);
                exit;
            }
            $result = $versioning->restoreToVersion($slotKey, $targetVersion, $currentContent);
        }
        
        if (!$result['success']) {
            http_response_code(400);
            echo json_encode($result);
            exit;
        }
        
        LoggerService::info('VersionsAPI: Version restored', [
            'slot_key' => $slotKey,
            'target_version' => $targetVersion,
            'atomic' => $useAtomicRestore,
            'user' => $currentUser->email ?? 'unknown'
        ]);
        
        echo json_encode($result);
        exit;
    }
    
    // GET ?action=preview&slot_key=X&version=N - Preview version without restoring
    if ($method === 'GET' && $action === 'preview') {
        if (empty($slotKey) || $versionNumber < 1) {
            http_response_code(400);
            echo json_encode(['success' => false, 'error' => 'Missing slot_key or version parameter']);
            exit;
        }
        
        // Validate slot access
        $validateSlotAccess($slotKey);
        
        // RBAC: Check versions:read:* - silent permission denial
        if (!AuthMiddleware::hasPermission('versions:read:*') && !($currentUser->is_admin ?? false)) {
            // Silent permission denial: return 404 instead of 403
            http_response_code(404);
            echo json_encode(['success' => false, 'error' => 'Preview not available']);
            exit;
        }
        
        // Preview is read-only, no special permission needed beyond auth
        $result = $versioning->reconstructVersion($slotKey, $versionNumber);
        
        if (!$result['success']) {
            http_response_code(400);
            echo json_encode($result);
            exit;
        }
        
        echo json_encode([
            'success' => true,
            'preview' => true,
            'content' => $result['content'],
            'version' => $versionNumber,
            'strategy' => $result['strategy'] ?? 'unknown'
        ]);
        exit;
    }
    
    // =========================================================================
    // DELETE ROUTE
    // =========================================================================
    
    // DELETE ?action=delete&slot_key=X - Delete all versions
    if ($method === 'DELETE' && $action === 'delete') {
        if (empty($slotKey)) {
            http_response_code(400);
            echo json_encode(['success' => false, 'error' => 'Missing slot_key parameter']);
            exit;
        }
        
        // Validate slot access
        $validateSlotAccess($slotKey);
        
        // Require system admin permission (destructive, irreversible operation)
        if (!AuthMiddleware::hasPermission('system:admin:*') && !($currentUser->is_admin ?? false)) {
            http_response_code(403);
            echo json_encode(['success' => false, 'error' => 'Admin access required']);
            exit;
        }
        
        $result = $versioning->deleteAllVersions($slotKey);
        
        LoggerService::warning('VersionsAPI: All versions deleted', [
            'slot_key' => $slotKey,
            'user' => $currentUser->email ?? 'unknown'
        ]);
        
        echo json_encode([
            'success' => $result,
            'slot_key' => $slotKey
        ]);
        exit;
    }
    
    // =========================================================================
    // HYBRID VERSIONING ROUTES (Shadow/Commit/Named)
    // =========================================================================
    
    // POST ?action=promote&version_id=X - Promote shadow to commit/named
    if ($method === 'POST' && $action === 'promote') {
        $versionId = (int) ($_GET['version_id'] ?? $input['version_id'] ?? 0);
        
        if (!$versionId) {
            http_response_code(400);
            echo json_encode(['success' => false, 'error' => 'Missing version_id parameter']);
            exit;
        }
        
        // Require versions:restore permission (promotion mutates version history)
        try {
            AuthMiddleware::requirePermission('versions:restore:*');
        } catch (\Exception $e) {
            http_response_code(403);
            echo json_encode(['success' => false, 'error' => 'Nincs jogosultság a művelethez']);
            exit;
        }
        $name = $input['name'] ?? null;

        // Resolve target type from request body (frontend sends { type, name }).
        // Default to 'commit' if omitted for backward compatibility.
        $targetType = is_string($input['type'] ?? null) ? $input['type'] : VersionRepository::TYPE_COMMIT;

        // Validate target type
        if (!in_array($targetType, [VersionRepository::TYPE_COMMIT, VersionRepository::TYPE_NAMED])) {
            http_response_code(400);
            echo json_encode(['success' => false, 'error' => 'Invalid target type. Use "commit" or "named"']);
            exit;
        }
        
        $result = $versioning->promoteVersion($versionId, $targetType, $name);
        
        if (!$result['success']) {
            http_response_code(400);
            echo json_encode($result);
            exit;
        }
        
        LoggerService::info('VersionsAPI: Version promoted', [
            'version_id' => $versionId,
            'target_type' => $targetType,
            'name' => $name,
            'user' => $currentUser->email ?? 'unknown'
        ]);
        
        echo json_encode([
            'success' => true,
            'version_id' => $versionId,
            'new_type' => $targetType,
            'name' => $name
        ]);
        exit;
    }
    
    // POST ?action=rename&version_id=X - Rename commit/named version
    if ($method === 'POST' && $action === 'rename') {
        $versionId = (int) ($_GET['version_id'] ?? $input['version_id'] ?? 0);
        $name = $input['name'] ?? '';
        
        if (!$versionId) {
            http_response_code(400);
            echo json_encode(['success' => false, 'error' => 'Missing version_id parameter']);
            exit;
        }
        
        if (empty($name)) {
            http_response_code(400);
            echo json_encode(['success' => false, 'error' => 'Missing name parameter']);
            exit;
        }
        
        // Require versions:restore permission (rename mutates version metadata)
        try {
            AuthMiddleware::requirePermission('versions:restore:*');
        } catch (\Exception $e) {
            http_response_code(403);
            echo json_encode(['success' => false, 'error' => 'Nincs jogosultság a művelethez']);
            exit;
        }
        
        $result = $versioning->renameVersion($versionId, $name);
        
        if (!$result['success']) {
            http_response_code(400);
            echo json_encode($result);
            exit;
        }
        
        echo json_encode([
            'success' => true,
            'version_id' => $versionId,
            'new_name' => $name
        ]);
        exit;
    }
    
    // DELETE ?action=delete_version&version_id=X - Delete specific version
    if ($method === 'DELETE' && $action === 'delete_version') {
        $versionId = (int) ($_GET['version_id'] ?? 0);
        $forceNamedDelete = filter_var($_GET['force'] ?? 'false', FILTER_VALIDATE_BOOLEAN);
        
        if (!$versionId) {
            http_response_code(400);
            echo json_encode(['success' => false, 'error' => 'Missing version_id parameter']);
            exit;
        }
        
        // Require versions:restore permission (delete_version mutates version history)
        try {
            AuthMiddleware::requirePermission('versions:restore:*');
        } catch (\Exception $e) {
            http_response_code(403);
            echo json_encode(['success' => false, 'error' => 'Nincs jogosultság a művelethez']);
            exit;
        }
        
        // Get version info first for logging
        $versionInfo = $versioning->getVersionById($versionId);
        
        $result = $versioning->deleteVersion($versionId, $forceNamedDelete);
        
        if (!$result['success']) {
            // Check if requires confirmation
            if (isset($result['requires_confirmation']) && $result['requires_confirmation']) {
                http_response_code(409); // Conflict - needs confirmation
                echo json_encode($result);
                exit;
            }
            http_response_code(400);
            echo json_encode($result);
            exit;
        }
        
        LoggerService::info('VersionsAPI: Version deleted', [
            'version_id' => $versionId,
            'version_info' => $versionInfo,
            'user' => $currentUser->email ?? 'unknown'
        ]);
        
        echo json_encode([
            'success' => true,
            'version_id' => $versionId,
            'deleted' => true
        ]);
        exit;
    }
    
    // POST ?action=cleanup_shadows - Cleanup expired shadow versions
    if ($method === 'POST' && $action === 'cleanup_shadows') {
        // RBAC: destructive maintenance operation across all slots - require
        // system admin permission (same tier as ?action=cleanup and ?action=delete).
        if (!AuthMiddleware::hasPermission('system:admin:*') && !($currentUser->is_admin ?? false)) {
            http_response_code(403);
            echo json_encode(['success' => false, 'error' => 'Admin access required']);
            exit;
        }
        
        $slotKeyFilter = $input['slot_key'] ?? null;
        
        $deleted = $versioning->cleanupExpiredShadows($slotKeyFilter);
        
        echo json_encode([
            'success' => true,
            'deleted_count' => $deleted,
            'slot_key' => $slotKeyFilter
        ]);
        exit;
    }
    
    // POST ?action=prune_noise - Clean up ALREADY-ACCUMULATED noise versions
    // (retroactive cleanup for content saved before the semantic-skip
    // feature existed - see PruneNoiseService). DESTRUCTIVE on non-dry-run:
    // rewrites version chains, deleting versions whose canonical content
    // duplicates the version immediately before them.
    if ($method === 'POST' && $action === 'prune_noise') {
        // RBAC: same tier as cleanup/delete/cleanup_shadows (destructive,
        // cross-slot maintenance operation).
        if (!AuthMiddleware::hasPermission('system:admin:*') && !($currentUser->is_admin ?? false)) {
            http_response_code(403);
            echo json_encode(['success' => false, 'error' => 'Admin access required']);
            exit;
        }
        
        // PANIC MODE GATE: refuse to run destructive chain rewrites while
        // the system is in emergency read-only lockdown, even for admins -
        // panic mode exists precisely to freeze all mutation during an
        // incident, and this operation is irreversible without a backup.
        if (\NomadCMS\Security\PanicModeService::isActive()) {
            http_response_code(423); // Locked
            echo json_encode(['success' => false, 'error' => 'A rendszer pánik módban van, karbantartási műveletek nem futtathatók.']);
            exit;
        }
        
        // SAFETY: dry_run is the default. The caller must explicitly send
        // { "dry_run": false } to actually mutate anything - a bare POST
        // with no body, or a body that omits dry_run entirely, only
        // analyzes and reports what WOULD be pruned.
        $dryRun = !array_key_exists('dry_run', $input) || $input['dry_run'] !== false;
        
        // Optional: limit to specific slot keys (dashboard "prune just this
        // slot" action) instead of a full-database sweep.
        $slotKeysFilter = null;
        if (isset($input['slot_keys']) && is_array($input['slot_keys'])) {
            $slotKeysFilter = array_values(array_filter($input['slot_keys'], 'is_string'));
        }
        
        $result = $versioning->pruneNoise($dryRun, $slotKeysFilter);
        
        LoggerService::info('VersionsAPI: prune_noise executed', [
            'dry_run' => $dryRun,
            'slots_affected' => $result['slots_affected'],
            'versions_prunable' => $result['versions_prunable'],
            'bytes_prunable' => $result['bytes_prunable'],
            'user' => $currentUser->email ?? 'unknown'
        ]);
        
        echo json_encode($result);
        exit;
    }
    
    // GET ?action=version_by_id&version_id=X - Get version by ID (not version number)
    if ($method === 'GET' && $action === 'version_by_id') {
        $versionId = (int) ($_GET['version_id'] ?? 0);
        
        if (!$versionId) {
            http_response_code(400);
            echo json_encode(['success' => false, 'error' => 'Missing version_id parameter']);
            exit;
        }
        
        $version = $versioning->getVersionById($versionId);
        
        if (!$version) {
            http_response_code(404);
            echo json_encode(['success' => false, 'error' => 'Version not found']);
            exit;
        }
        
        // Validate slot access
        $validateSlotAccess($version['slot_key']);
        
        // RBAC: Check versions:read:* - silent permission denial
        if (!AuthMiddleware::hasPermission('versions:read:*') && !($currentUser->is_admin ?? false)) {
            // Silent permission denial: return 404 instead of 403
            http_response_code(404);
            echo json_encode(['success' => false, 'error' => 'Version not found']);
            exit;
        }
        
        echo json_encode([
            'success' => true,
            'version' => $version
        ]);
        exit;
    }
    
    // No matching route
    http_response_code(400);
    echo json_encode([
        'success' => false, 
        'error' => 'Invalid action. Valid actions: settings, stats, cleanup, history, version, version_by_id, restore, preview, delete, promote, rename, delete_version, cleanup_shadows, prune_noise'
    ]);
    
} catch (\NomadCMS\Database\OptimisticLockException $e) {
    http_response_code(409);
    echo json_encode(['success'=>false,'error'=>'CONFLICT','message'=>$e->getMessage()]);
} catch (\InvalidArgumentException|\DomainException $e) {
    http_response_code(400);
    echo json_encode(['success'=>false,'error'=>$e->getMessage()]);
} catch (\OutOfBoundsException $e) {
    http_response_code(404);
    echo json_encode(['success'=>false,'error'=>$e->getMessage()]);
} catch (Exception $e) {
    LoggerService::error('VersionsAPI: Error', [
        'error' => $e->getMessage(),
        'trace' => $e->getTraceAsString()
    ]);
    
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'Internal server error'
    ]);
}
