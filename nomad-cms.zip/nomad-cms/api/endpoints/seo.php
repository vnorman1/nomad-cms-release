<?php
/**
 * NOMAD CMS — anonymous SEO metadata, images and technical SEO delivery.
 * Does not start sessions or expose draft content; migrations are never run on a request.
 * @package NomadCMS\Endpoints
 */
declare(strict_types=1);

require_once dirname(__DIR__, 1) . '/update-guard.php';

require_once dirname(__DIR__) . '/vendor/autoload.php';
if (is_file(dirname(__DIR__) . '/.env')) {
    \Dotenv\Dotenv::createImmutable(dirname(__DIR__))->safeLoad();
}
// This public hot path intentionally bypasses the general bootstrap, but it
// shares the same operation lease and read-only policy as other endpoints.
\NomadCMS\Middleware\PanicModeMiddleware::check();
\NomadCMS\Services\Seo\HttpController::public();
