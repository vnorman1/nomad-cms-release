<?php
/**
 * NOMAD CMS - API Keys Management Endpoint
 * 
 * Admin-only endpoint for managing API keys.
 * 
 * GET    - List all API keys (masked)
 * POST   - Create new API key (returns key only once!)
 * DELETE - Revoke an API key
 *
 * OWNERSHIP NOTE (ABAC 'own' scope):
 * API keys are inherently personal credentials - every query in this endpoint
 * is already scoped to the authenticated user's own $userId (listKeys($userId),
 * createKey($userId, ...), revokeKey($userId, $keyId)). There is currently no
 * "view/manage everyone's keys" mode, so api_keys:read: and api_keys:delete:
 * (wildcard scope) and their :own counterparts behave identically here - both
 * are implicitly "own" scoped at the data-access level. This is intentional:
 * unlike content or media, API keys have no legitimate multi-user
 * shared-ownership concept.
 */

declare(strict_types=1);

require_once __DIR__ . '/../../bootstrap.php';

use NomadCMS\Security\ApiKeyService;
use NomadCMS\Security\InputSanitizer;
use NomadCMS\Database\AuthDatabase;
use NomadCMS\Database\UserRepository;
use NomadCMS\Middleware\AuthMiddleware;
use NomadCMS\Middleware\CSRFMiddleware;
use NomadCMS\Auth\TOTPService;

header('Content-Type: application/json');

// Get request method
$method = $_SERVER['REQUEST_METHOD'];

// Handle CORS preflight
if ($method === 'OPTIONS') {
    http_response_code(204);
    exit;
}

try {
    // Authenticate user
    $user = AuthMiddleware::requireInteractiveAuth();
    
    // Per-method RBAC (admins still fast-path inside requirePermission):
    //   GET    -> api_keys:read:*
    //   POST   -> api_keys:create:*
    //   PUT    -> api_keys:update:*
    //   DELETE -> api_keys:delete:*
    // An "api_keys:manage:*" permission covers all of the above.
    //
    // SCOPE EQUIVALENCE: for API keys the ':*' and ':own' scopes are
    // functionally identical, because every query in this endpoint is already
    // hard-filtered to the authenticated user (listKeys($userId),
    // createKey($userId, ...), revokeKey($userId, $keyId)) - there is no
    // multi-user admin view, by design, since API keys are personal
    // credentials. Both scopes are therefore accepted: requiring ':*' alone
    // would turn api_keys:read:own & co. into grants that permit nothing even
    // though the role matrix UI offers them, while accepting ':own' grants no
    // additional visibility whatsoever.
    switch ($method) {
        case 'GET':
            AuthMiddleware::requireAnyGrantedScope(['api_keys:read:*', 'api_keys:read:own']);
            break;
        case 'POST':
            AuthMiddleware::requireAnyGrantedScope(['api_keys:create:*', 'api_keys:create:own']);
            break;
        case 'PUT':
        case 'PATCH':
            AuthMiddleware::requireAnyGrantedScope(['api_keys:update:*', 'api_keys:update:own']);
            break;
        case 'DELETE':
            AuthMiddleware::requireAnyGrantedScope(['api_keys:delete:*', 'api_keys:delete:own']);
            break;
        default:
            http_response_code(405);
            echo json_encode(['success' => false, 'error' => 'Method not allowed']);
            exit;
    }
    
    // Get user ID from database
    $db = AuthDatabase::getInstance();
    $stmt = $db->prepare("SELECT id FROM users WHERE uuid = ?");
    $stmt->execute([$user->uuid]);
    $userRow = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$userRow) {
        http_response_code(401);
        echo json_encode(['success' => false, 'error' => 'User not found']);
        exit;
    }
    
    $userId = (int) $userRow['id'];
    $apiKeyService = new ApiKeyService();
    
    // Resolve SITE_URL for preview link generation
    $siteUrl = rtrim($_ENV['SITE_URL'] ?? $_ENV['APP_URL'] ?? '', '/');
    
    switch ($method) {
        case 'GET':
            // List all keys
            $keys = $apiKeyService->listKeys($userId);
            foreach ($keys as &$k) {
                if (!empty($k['is_draft_only']) && !empty($k['raw_key']) && $siteUrl !== '') {
                    $k['preview_url'] = $siteUrl . '?draftkey=' . $k['raw_key'];
                }
            }
            unset($k);
            echo json_encode([
                'success' => true,
                'keys' => $keys,
                'site_url' => $siteUrl,
            ]);
            break;
            
        case 'POST':
            // SECURITY: Validate CSRF token for session-based requests
            CSRFMiddleware::validateForSession();
            
            // Create new key
            $input = json_decode(file_get_contents('php://input'), true) ?? [];
            
            // Sanitize name
            $name = InputSanitizer::apiKeyName($input['name'] ?? null);
            if (!$name) {
                http_response_code(400);
                echo json_encode(['success' => false, 'error' => 'Valid key name is required (1-100 characters)']);
                exit;
            }
            
            // Validate permissions using whitelist
            $requestedPerms = $input['permissions'] ?? ['read'];
            $validPerms = ['read', 'write', 'admin'];
            $permissions = InputSanitizer::whitelist($requestedPerms, $validPerms);
            
            if (empty($permissions)) {
                $permissions = ['read'];
            }
            
            // Validate expiry (supports explicit expires_at datetime string, expires_in_hours, or expires_in days)
            $expiresAt = null;
            if (!empty($input['expires_at'])) {
                $parsedTime = strtotime((string) $input['expires_at']);
                if ($parsedTime !== false && $parsedTime > time()) {
                    // Maximum 10 years in the future
                    if ($parsedTime <= strtotime('+10 years')) {
                        $expiresAt = date('c', $parsedTime);
                    }
                }
            } elseif (isset($input['expires_in_hours']) && is_numeric($input['expires_in_hours'])) {
                $hours = (float) $input['expires_in_hours'];
                if ($hours > 0 && $hours <= 87600) { // Max 10 years
                    $seconds = (int) round($hours * 3600);
                    $expiresAt = date('c', time() + $seconds);
                }
            } else {
                $expiresIn = InputSanitizer::positiveInt($input['expires_in'] ?? null);
                if ($expiresIn !== null && $expiresIn > 0 && $expiresIn <= 3650) { // Max 10 years
                    $expiresAt = date('c', strtotime("+{$expiresIn} days"));
                }
            }
            
            // Check if enhanced (PRO) key is requested
            $isEnhanced = filter_var($input['enhanced'] ?? false, FILTER_VALIDATE_BOOLEAN);
            
            // Check if this is a draft-only key
            $isDraftOnly = filter_var($input['is_draft_only'] ?? false, FILTER_VALIDATE_BOOLEAN);
            
            // SECURITY: Draft-only keys can strictly have READ access only (no write, no admin, no PRO)
            if ($isDraftOnly) {
                if ($isEnhanced) {
                    http_response_code(400);
                    echo json_encode(['success' => false, 'error' => 'Draft-only keys cannot be PRO keys']);
                    exit;
                }
                if (in_array('write', $requestedPerms, true) || in_array('admin', $requestedPerms, true)) {
                    http_response_code(400);
                    echo json_encode(['success' => false, 'error' => 'Draft preview keys can only have read-only permissions']);
                    exit;
                }
                $permissions = ['read'];
            }
            
            if ($isEnhanced) {
                // SECURITY: PRO keys cannot be draft-only (they handle encrypted data, not public previews)
                if ($isDraftOnly) {
                    http_response_code(400);
                    echo json_encode(['success' => false, 'error' => 'Draft-only keys cannot be PRO keys']);
                    exit;
                }
                
                // Get user data with TOTP secret
                $userData = UserRepository::findByUuid($user->uuid);
                
                if (!$userData) {
                    http_response_code(403);
                    echo json_encode(['success' => false, 'error' => 'User not found']);
                    exit;
                }

                // Check if TOTP is enabled for this user
                if ($userData['totp_enabled']) {
                    // SECURITY: PRO keys require TOTP verification when 2FA is enabled
                    $totpCode = $input['totp_code'] ?? null;
                    if (!is_string($totpCode) || !preg_match('/^\d{6}$/D', $totpCode)) {
                        http_response_code(400);
                        echo json_encode(['success' => false, 'error' => 'TOTP kód szükséges PRO kulcs létrehozásához']);
                        exit;
                    }

                    // Get decrypted TOTP secret
                    $totpSecret = UserRepository::getTotpSecret($userData);
                    if (!$totpSecret) {
                        http_response_code(500);
                        echo json_encode(['success' => false, 'error' => 'TOTP konfigurációs hiba']);
                        exit;
                    }
                
                    // Verify TOTP
                    if (!TOTPService::verifyUserCode((int) $userData['id'], $totpCode)) {
                        http_response_code(401);
                        echo json_encode(['success' => false, 'error' => 'Érvénytelen TOTP kód']);
                        exit;
                    }
                }

                // Validate encrypted permissions for enhanced keys
                $requestedEncryptedPerms = $input['encrypted_permissions'] ?? [];
                $validEncryptedPerms = ['encrypted_read', 'encrypted_write'];
                $encryptedPermissions = InputSanitizer::whitelist($requestedEncryptedPerms, $validEncryptedPerms);
                
                $result = $apiKeyService->createEnhancedKey($userId, $name, $permissions, $encryptedPermissions, $expiresAt);
                
                echo json_encode([
                    'success' => true,
                    'message' => 'Enhanced (PRO) API key created. Save it now - you will not be able to see it again!',
                    'key' => $result,
                    'site_url' => $siteUrl,
                ]);
            } else {
                $result = $apiKeyService->createKey($userId, $name, $permissions, $expiresAt, $isDraftOnly);
                
                $response = [
                    'success' => true,
                    'message' => $isDraftOnly
                        ? 'Draft preview API key created.'
                        : 'API key created. Save it now - you will not be able to see it again!',
                    'key' => $result,
                    'site_url' => $siteUrl,
                ];
                
                // Generate preview URL for draft-only keys
                if ($isDraftOnly && $siteUrl !== '') {
                    $response['preview_url'] = $siteUrl . '?draftkey=' . $result['key'];
                }
                
                echo json_encode($response);
            }
            break;
            
        case 'DELETE':
            // SECURITY: Validate CSRF token for session-based requests
            CSRFMiddleware::validateForSession();
            
            // Revoke key
            $keyId = InputSanitizer::positiveInt($_GET['id'] ?? null);
            
            if (!$keyId) {
                http_response_code(400);
                echo json_encode(['success' => false, 'error' => 'Valid Key ID is required']);
                exit;
            }
            
            $revoked = $apiKeyService->revokeKey($userId, $keyId);
            
            if ($revoked) {
                echo json_encode([
                    'success' => true,
                    'message' => 'API key revoked',
                ]);
            } else {
                http_response_code(404);
                echo json_encode([
                    'success' => false,
                    'error' => 'Key not found or already revoked',
                ]);
            }
            break;
            
        default:
            http_response_code(405);
            echo json_encode(['success' => false, 'error' => 'Method not allowed']);
    }
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => ($_ENV['APP_DEBUG'] ?? 'false') === 'true' 
            ? 'Server error: ' . $e->getMessage() 
            : 'Internal server error',
    ]);
}
