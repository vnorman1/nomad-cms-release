<?php

/**
 * NOMAD CMS - Admin API - Mail Settings (SMTP profiles)
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * ENDPOINTS
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *   GET  /api/admin/mail-settings              all profiles (masked) + option catalogue
 *   GET  /api/admin/mail-settings?uuid=X       one profile (masked)
 *   POST /api/admin/mail-settings              mutate, dispatched on `action`
 *
 * POST actions:
 *   create        save a new profile, then send the confirmation e-mail
 *   update        modify a profile (requires uuid), then re-send confirmation
 *   delete        remove a profile (requires uuid)
 *   set_default   make a VERIFIED profile the active one (requires uuid)
 *   resend        issue a new token and send the confirmation again
 *   test          send a test message through a STORED profile, no state change
 *   disable       switch a profile off (driver + status = disabled)
 *   enable        switch it back on (restores the driver, requires re-verification)
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * WHY A FAILED CONFIRMATION STILL SAVES THE PROFILE
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * create/update persist the configuration FIRST and only then attempt delivery.
 * If the SMTP handshake fails the response is success:false with the classified
 * error code - but the profile stays, as `unverified`. Rolling it back would
 * force the admin to retype every field (including the password) after each
 * typo, which is exactly the situation where they are most likely to be making
 * typos. Nothing can send from an unverified profile, so keeping it costs
 * nothing.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * WHY NO RAW PASSWORD IS EVER IN A RESPONSE
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * Every response body is built from MailProfileStore::list()/masked(), which
 * emit `password_set: bool` and nothing else about the credential. The plaintext
 * exists only in memory for the duration of one send; the ciphertext only in
 * system.sqlite. Deliberately no "last 4 characters" hint - see the store.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * PERMISSIONS
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *   GET  -> mail:read:*    (viewing settings)
 *   POST -> mail:manage:*  (mutating settings, sending anything)
 *
 * A dedicated 'mail' resource, not the generic system:read/system:manage this
 * endpoint used to reuse: those also gate cache rebuilds, backups, Forge
 * migrations and panic mode, so a role that only needs to administer SMTP
 * profiles would otherwise have to be handed all of that as a side effect.
 * `mail:*` lets a custom role (e.g. "Mail admin") be scoped to exactly this
 * subsystem. Every write additionally passes
 * CSRFMiddleware::validateForSession() and is rate limited: `test` and
 * `resend` put the CMS's own SMTP credentials behind a "send mail to an
 * address I name" button, which is a spam relay if left unbounded.
 *
 * @package NomadCMS
 */

declare(strict_types=1);

require_once __DIR__ . '/../../bootstrap.php';

use NomadCMS\Middleware\AuthMiddleware;
use NomadCMS\Middleware\CSRFMiddleware;
use NomadCMS\Middleware\RateLimitMiddleware;
use NomadCMS\Security\EncryptionService;
use NomadCMS\Services\LoggerService;
use NomadCMS\Services\Mail\MailException;
use NomadCMS\Services\Mail\MailProfileStore;
use NomadCMS\Services\Mail\MailSchema;
use NomadCMS\Services\Mail\MailService;
use NomadCMS\Services\Mail\MailTemplates;
use NomadCMS\Services\Mail\MailUrlResolver;
use NomadCMS\Services\Mail\MailValidationException;

handlePreflight();
header('Content-Type: application/json; charset=utf-8');

/**
 * @param array<string, mixed> $payload
 */
function mailAdminJson(int $status, array $payload): never
{
    http_response_code($status);
    echo json_encode($payload, JSON_UNESCAPED_UNICODE);
    exit;
}

/**
 * @return array<string, mixed>
 */
function mailAdminBody(): array
{
    $raw = file_get_contents('php://input');
    $decoded = json_decode($raw === false ? '' : $raw, true);

    return is_array($decoded) ? $decoded : [];
}

/**
 * Everything the /mails page needs in one shot: the profiles, the coarse status
 * for the header badge, and the option catalogue.
 *
 * The catalogue is served from here rather than hardcoded in the frontend so the
 * allowed ports, auth mechanisms and timeout bounds cannot drift apart from what
 * the backend actually accepts.
 *
 * @return array<string, mixed>
 */
function mailAdminState(): array
{
    return [
        'status' => MailService::status(),
        'sending_enabled' => MailService::isEnabled(),
        'profiles' => MailProfileStore::list(),
        'options' => [
            'drivers' => [
                ['value' => MailSchema::DRIVER_SMTP, 'label' => 'SMTP kiszolgáló'],
                ['value' => MailSchema::DRIVER_MAIL, 'label' => 'PHP mail() (helyi MTA)'],
                ['value' => MailSchema::DRIVER_DISABLED, 'label' => 'Kikapcsolva'],
            ],
            'encryptions' => [
                ['value' => MailSchema::ENCRYPTION_TLS, 'label' => 'STARTTLS (ajánlott, 587)'],
                ['value' => MailSchema::ENCRYPTION_SSL, 'label' => 'SSL/TLS (SMTPS, 465)'],
                ['value' => MailSchema::ENCRYPTION_NONE, 'label' => 'Nincs titkosítás (nem ajánlott)'],
            ],
            'ports' => MailSchema::ALLOWED_PORTS,
            'default_ports' => MailSchema::DEFAULT_PORTS,
            'auth_types' => MailSchema::AUTH_TYPES,
            'timeout' => [
                'min' => MailSchema::TIMEOUT_MIN,
                'max' => MailSchema::TIMEOUT_MAX,
                'default' => MailSchema::TIMEOUT_DEFAULT,
            ],
            'name_max_length' => MailSchema::NAME_MAX_LENGTH,
            'verification_ttl_minutes' => (int) (MailSchema::VERIFICATION_TTL / 60),
            // Surfaced so the UI can explain WHY a save was refused instead of
            // showing a bare error: these two are server-side facts the admin
            // cannot discover from the form itself.
            'allow_local_hosts' => ($_ENV['MAIL_ALLOW_LOCAL'] ?? 'false') === 'true',
            'encryption_configured' => EncryptionService::isConfigured(),
            'kill_switch_active' => ($_ENV['FORMS_MAIL_ENABLED'] ?? 'true') === 'false',
        ],
    ];
}

/**
 * Issue a token and send the confirmation e-mail with the profile's OWN
 * configuration, to the profile's OWN address.
 *
 * ─────────────────────────────────────────────────────────────────────────────
 * WHY THE RECIPIENT IS THE PROFILE'S from_email
 * ─────────────────────────────────────────────────────────────────────────────
 * The confirmation has to prove two separate things:
 *   1. this configuration can SEND  (the handshake succeeded)
 *   2. this address can RECEIVE     (the mailbox is real and alive)
 *
 * Sending to the acting admin's login address only proves (1). Sending to the
 * address being registered proves both, which is what makes the `verified` state
 * mean something. A profile whose own mailbox silently discards mail is a
 * profile that will produce undeliverable bounces later.
 *
 * An explicit `to` override is still accepted, because a legitimate `noreply@`
 * sender may not accept inbound mail at all - without the override such a setup
 * could never be activated. The override is a deliberate act by an admin, not
 * the default.
 *
 * This is the one send path that bypasses the verified/default gate - it has to,
 * since the profile is unverified by definition at this point. It is only
 * reachable from create/update/resend below, all of which require
 * mail:manage:*.
 *
 * @param string|null $explicitTo Optional override; null = the profile's own address
 * @param string|null $frontendOrigin The calling browser's own base URL (origin
 *                     + SPA mount path), from the request body's
 *                     `frontend_origin` field - see MailUrlResolver::verifyUrl().
 * @return array<string, mixed> Delivery outcome, merged into the response
 */
function mailAdminSendVerification(string $uuid, ?string $explicitTo, ?string $frontendOrigin): array
{
    $config = MailProfileStore::resolve($uuid);
    if ($config === null) {
        throw MailException::profileNotFound();
    }

    if ($config['driver'] === MailSchema::DRIVER_DISABLED) {
        return [
            'sent' => false,
            'code' => 'MAIL_DRIVER_DISABLED',
            'error' => 'A profil ki van kapcsolva, ezért nem indult megerősítő levél.',
        ];
    }

    $to = mailAdminRecipient($explicitTo, $config['from_email']);

    $token = MailProfileStore::issueVerificationToken($uuid, $to);
    $url = MailUrlResolver::verifyUrl($token, $frontendOrigin);
    $ttlMinutes = (int) (MailSchema::VERIFICATION_TTL / 60);
    $template = MailTemplates::verification($config['name'], $url, $ttlMinutes);

    try {
        MailService::sendWithConfig($config, $to, $template['subject'], $template['text'], $template['html']);

        return ['sent' => true, 'sent_to' => $to];
    } catch (MailException $e) {
        return [
            'sent' => false,
            'code' => $e->getErrorCode(),
            'error' => $e->getMessage(),
            'sent_to' => $to,
        ];
    }
}

/**
 * Resolve the recipient of a verification or test message.
 *
 * Default: the profile's own sender address (see the reasoning above). An
 * explicit override wins, but must be a valid address - silently falling back
 * after a typo would send the confirmation somewhere the admin is not watching
 * and look like a delivery failure.
 */
function mailAdminRecipient(?string $explicitTo, string $fromEmail): string
{
    $explicit = $explicitTo === null ? '' : trim($explicitTo);

    if ($explicit !== '') {
        if (filter_var($explicit, FILTER_VALIDATE_EMAIL) === false) {
            throw new MailValidationException(['to' => 'A címzett e-mail cím érvénytelen.']);
        }

        return $explicit;
    }

    $own = trim($fromEmail);
    if ($own === '' || filter_var($own, FILTER_VALIDATE_EMAIL) === false) {
        throw new MailValidationException([
            'to' => 'A profil feladó címe érvénytelen, ezért nincs hova küldeni a levelet.',
        ]);
    }

    return $own;
}

/**
 * The `to` field of the request body, if present.
 *
 * @param array<string, mixed> $body
 */
function mailAdminExplicitTo(array $body): ?string
{
    return isset($body['to']) && is_string($body['to']) && trim($body['to']) !== '' ? $body['to'] : null;
}

/**
 * The `frontend_origin` field of the request body, if present - the calling
 * browser's own base URL (origin + SPA mount path), used to build a
 * confirmation link that points at the frontend instead of the raw backend
 * endpoint. See MailUrlResolver::verifyUrl().
 *
 * @param array<string, mixed> $body
 */
function mailAdminFrontendOrigin(array $body): ?string
{
    return isset($body['frontend_origin']) && is_string($body['frontend_origin']) && trim($body['frontend_origin']) !== ''
        ? $body['frontend_origin']
        : null;
}

/**
 * @param array<string, mixed> $context
 */
function mailAdminLog(string $message, array $context = []): void
{
    try {
        LoggerService::info('[Mail] ' . $message, array_merge(['component' => 'mail'], $context));
    } catch (Throwable) {
        // Audit logging must never break the operation it is describing.
    }
}

try {
    $user = AuthMiddleware::requireAuth();
    RateLimitMiddleware::check('admin-mail-settings', 120, 60);

    $method = strtoupper((string) ($_SERVER['REQUEST_METHOD'] ?? 'GET'));
    $uuidParam = isset($_GET['uuid']) && is_string($_GET['uuid']) ? trim($_GET['uuid']) : null;

    // =========================================================================
    // GET
    // =========================================================================
    if ($method === 'GET') {
        AuthMiddleware::requirePermission('mail:read:*');

        if ($uuidParam !== null && $uuidParam !== '') {
            mailAdminJson(200, [
                'success' => true,
                'profile' => MailProfileStore::requireMasked($uuidParam),
            ] + mailAdminState());
        }

        mailAdminJson(200, ['success' => true] + mailAdminState());
    }

    // =========================================================================
    // MUTATIONS
    // =========================================================================
    if ($method !== 'POST') {
        header('Allow: GET, POST');
        mailAdminJson(405, [
            'success' => false,
            'error' => 'Nem támogatott metódus.',
            'code' => 'METHOD_NOT_ALLOWED',
        ]);
    }

    CSRFMiddleware::validateForSession();
    AuthMiddleware::requirePermission('mail:manage:*');

    $body = mailAdminBody();
    $uuid = $uuidParam ?? (isset($body['uuid']) && is_string($body['uuid']) ? trim($body['uuid']) : null);
    $uuid = $uuid === '' ? null : $uuid;

    $action = isset($body['action']) && is_string($body['action']) ? $body['action'] : null;
    if ($action === null || $action === '') {
        // Convenience: a payload with no explicit action is a save, and the
        // presence of a uuid says which kind.
        $action = $uuid === null ? 'create' : 'update';
    }

    switch ($action) {
        // ---------------------------------------------------------------------
        case 'create':
            $newUuid = MailProfileStore::create($body);
            $delivery = mailAdminSendVerification($newUuid, mailAdminExplicitTo($body), mailAdminFrontendOrigin($body));

            mailAdminLog('Levelezési profil létrehozva', [
                'profile' => $newUuid,
                'by' => $user->uuid ?? null,
                'verification_sent' => $delivery['sent'],
                'error_code' => $delivery['code'] ?? null,
            ]);

            mailAdminJson($delivery['sent'] ? 201 : 200, [
                'success' => $delivery['sent'],
                'profile' => MailProfileStore::requireMasked($newUuid),
                'verification' => $delivery,
                'error' => $delivery['error'] ?? null,
                'code' => $delivery['code'] ?? null,
            ] + mailAdminState());

            // no break - mailAdminJson() exits
        // ---------------------------------------------------------------------
        case 'update':
            if ($uuid === null) {
                mailAdminJson(400, [
                    'success' => false,
                    'error' => 'Hiányzó uuid paraméter.',
                    'code' => 'MISSING_UUID',
                ]);
            }

            MailProfileStore::update($uuid, $body);
            $delivery = mailAdminSendVerification($uuid, mailAdminExplicitTo($body), mailAdminFrontendOrigin($body));

            mailAdminLog('Levelezési profil módosítva', [
                'profile' => $uuid,
                'by' => $user->uuid ?? null,
                'verification_sent' => $delivery['sent'],
                'error_code' => $delivery['code'] ?? null,
            ]);

            mailAdminJson(200, [
                'success' => $delivery['sent'],
                'profile' => MailProfileStore::requireMasked($uuid),
                'verification' => $delivery,
                'error' => $delivery['error'] ?? null,
                'code' => $delivery['code'] ?? null,
            ] + mailAdminState());

            // no break
        // ---------------------------------------------------------------------
        case 'resend':
            if ($uuid === null) {
                mailAdminJson(400, [
                    'success' => false,
                    'error' => 'Hiányzó uuid paraméter.',
                    'code' => 'MISSING_UUID',
                ]);
            }

            // 5/hour: a resend button is a "send mail to an address I choose"
            // primitive using the CMS's own credentials.
            RateLimitMiddleware::check('admin-mail-resend', 5, 3600);

            $delivery = mailAdminSendVerification($uuid, mailAdminExplicitTo($body), mailAdminFrontendOrigin($body));

            mailAdminLog('Megerősítő levél újraküldve', [
                'profile' => $uuid,
                'by' => $user->uuid ?? null,
                'sent' => $delivery['sent'],
                'error_code' => $delivery['code'] ?? null,
            ]);

            mailAdminJson($delivery['sent'] ? 200 : 502, [
                'success' => $delivery['sent'],
                'profile' => MailProfileStore::requireMasked($uuid),
                'verification' => $delivery,
                'error' => $delivery['error'] ?? null,
                'code' => $delivery['code'] ?? null,
            ] + mailAdminState());

            // no break
        // ---------------------------------------------------------------------
        case 'test':
            if ($uuid === null) {
                mailAdminJson(400, [
                    'success' => false,
                    'error' => 'Hiányzó uuid paraméter.',
                    'code' => 'MISSING_UUID',
                ]);
            }

            RateLimitMiddleware::check('admin-mail-test', 10, 3600);

            $config = MailProfileStore::resolve($uuid);
            if ($config === null) {
                throw MailException::profileNotFound();
            }
            if ($config['driver'] === MailSchema::DRIVER_DISABLED) {
                throw MailException::driverDisabled();
            }

            $to = mailAdminRecipient(mailAdminExplicitTo($body), $config['from_email']);
            $template = MailTemplates::test($config['name']);

            try {
                // Deliberately sendWithConfig() and not send(): a test must work
                // on an unverified profile, otherwise the admin cannot debug
                // their way TO verified. It changes no state beyond the
                // last_success_at / last_error_code diagnostics.
                MailService::sendWithConfig(
                    $config,
                    $to,
                    $template['subject'],
                    $template['text'],
                    $template['html']
                );

                mailAdminLog('Teszt e-mail elküldve', [
                    'profile' => $uuid,
                    'by' => $user->uuid ?? null,
                ]);

                mailAdminJson(200, [
                    'success' => true,
                    'sent_to' => $to,
                    'profile' => MailProfileStore::requireMasked($uuid),
                ] + mailAdminState());
            } catch (MailException $e) {
                mailAdminLog('Teszt e-mail sikertelen', [
                    'profile' => $uuid,
                    'by' => $user->uuid ?? null,
                    'error_code' => $e->getErrorCode(),
                ]);

                mailAdminJson($e->getStatusCode(), [
                    'success' => false,
                    'error' => $e->getMessage(),
                    'code' => $e->getErrorCode(),
                    'sent_to' => $to,
                    'profile' => MailProfileStore::requireMasked($uuid),
                ] + mailAdminState());
            }

            // no break
        // ---------------------------------------------------------------------
        case 'set_default':
            if ($uuid === null) {
                mailAdminJson(400, [
                    'success' => false,
                    'error' => 'Hiányzó uuid paraméter.',
                    'code' => 'MISSING_UUID',
                ]);
            }

            MailProfileStore::setDefault($uuid);

            mailAdminLog('Alapértelmezett levelezési profil beállítva', [
                'profile' => $uuid,
                'by' => $user->uuid ?? null,
            ]);

            mailAdminJson(200, [
                'success' => true,
                'profile' => MailProfileStore::requireMasked($uuid),
            ] + mailAdminState());

            // no break
        // ---------------------------------------------------------------------
        case 'disable':
            if ($uuid === null) {
                mailAdminJson(400, [
                    'success' => false,
                    'error' => 'Hiányzó uuid paraméter.',
                    'code' => 'MISSING_UUID',
                ]);
            }

            MailProfileStore::disable($uuid);

            mailAdminLog('Levelezési profil kikapcsolva', [
                'profile' => $uuid,
                'by' => $user->uuid ?? null,
            ]);

            mailAdminJson(200, [
                'success' => true,
                'profile' => MailProfileStore::requireMasked($uuid),
            ] + mailAdminState());

            // no break
        // ---------------------------------------------------------------------
        case 'enable':
            if ($uuid === null) {
                mailAdminJson(400, [
                    'success' => false,
                    'error' => 'Hiányzó uuid paraméter.',
                    'code' => 'MISSING_UUID',
                ]);
            }

            // Re-enabling lands in `unverified`, so a fresh confirmation goes out
            // in the same request: without it the admin would be left with a
            // profile that is on but cannot send, and no obvious next step. This
            // is exactly the dead end the disable/enable pair had before.
            RateLimitMiddleware::check('admin-mail-resend', 5, 3600);

            MailProfileStore::enable($uuid);
            $delivery = mailAdminSendVerification($uuid, mailAdminExplicitTo($body), mailAdminFrontendOrigin($body));

            mailAdminLog('Levelezési profil bekapcsolva', [
                'profile' => $uuid,
                'by' => $user->uuid ?? null,
                'verification_sent' => $delivery['sent'],
                'error_code' => $delivery['code'] ?? null,
            ]);

            mailAdminJson(200, [
                'success' => $delivery['sent'],
                'profile' => MailProfileStore::requireMasked($uuid),
                'verification' => $delivery,
                'error' => $delivery['error'] ?? null,
                'code' => $delivery['code'] ?? null,
            ] + mailAdminState());

            // no break
        // ---------------------------------------------------------------------
        case 'delete':
            if ($uuid === null) {
                mailAdminJson(400, [
                    'success' => false,
                    'error' => 'Hiányzó uuid paraméter.',
                    'code' => 'MISSING_UUID',
                ]);
            }

            $wasDefault = MailProfileStore::delete($uuid);

            mailAdminLog('Levelezési profil törölve', [
                'profile' => $uuid,
                'by' => $user->uuid ?? null,
                'was_default' => $wasDefault,
            ]);

            mailAdminJson(200, [
                'success' => true,
                // No replacement is promoted automatically: sending from an SMTP
                // identity the admin did not choose is worse than a visible
                // outage. The UI turns this into a prominent warning.
                'warning' => $wasDefault ? 'MAIL_SENDING_STOPPED' : null,
            ] + mailAdminState());

            // no break
        // ---------------------------------------------------------------------
        default:
            mailAdminJson(400, [
                'success' => false,
                'error' => 'Ismeretlen művelet: ' . $action,
                'code' => 'UNKNOWN_ACTION',
            ]);
    }
} catch (MailValidationException $e) {
    mailAdminJson(422, [
        'success' => false,
        'error' => $e->getMessage(),
        'code' => $e->getErrorCode(),
        'errors' => $e->getErrors(),
    ]);
} catch (MailException $e) {
    mailAdminJson($e->getStatusCode(), [
        'success' => false,
        'error' => $e->getMessage(),
        'code' => $e->getErrorCode(),
    ]);
} catch (Throwable $e) {
    error_log('[Mail] admin/mail-settings hiba: ' . $e->getMessage());
    mailAdminJson(500, [
        'success' => false,
        'error' => ($_ENV['APP_DEBUG'] ?? 'false') === 'true'
            ? $e->getMessage()
            : 'Váratlan hiba a levelezési beállítások kezelése során.',
        'code' => 'INTERNAL_ERROR',
    ]);
}
