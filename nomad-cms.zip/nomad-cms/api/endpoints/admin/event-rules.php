<?php

/**
 * NOMAD CMS - Notification routing rule endpoint.
 * Dispatches versioned configuration and read-only rule previews through RBAC.
 * Rules are bounded data structures, never executable scripts.
 */

declare(strict_types=1);

require_once __DIR__ . '/../../bootstrap.php';
handlePreflight();
\NomadCMS\Services\NotificationService\HttpController::dispatch('rules');
