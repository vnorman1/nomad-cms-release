<?php
/**
 * Admin API - Webhooks Management
 * 
 * RESTful webhook management for outgoing and incoming webhooks.
 * Requires authentication plus a per-method RBAC permission:
 *   GET    -> webhooks:read:*
 *   POST   -> webhooks:create:* (creation) or webhooks:update:* (test/rotate-secret/retry)
 *   PUT    -> webhooks:update:*
 *   DELETE -> webhooks:delete:*
 * A "webhooks:manage:*" permission covers all of the above.
 * 
 * Endpoints:
 *   GET    /admin/webhooks.php              - List all webhooks
 *   POST   /admin/webhooks.php              - Create webhook
 *   GET    /admin/webhooks.php?id=X         - Get webhook details
 *   PUT    /admin/webhooks.php              - Update webhook
 *   DELETE /admin/webhooks.php?id=X         - Delete webhook
 *   POST   /admin/webhooks.php?action=test  - Send test webhook
 *   POST   /admin/webhooks.php?action=rotate-secret - Rotate secret
 *   GET    /admin/webhooks.php?action=deliveries&id=X - Get delivery log
 *   GET    /admin/webhooks.php?action=events - Get available events
 *   
 *   Incoming Endpoints:
 *   GET    /admin/webhooks.php?type=endpoints           - List endpoints
 *   POST   /admin/webhooks.php?type=endpoints           - Create endpoint
 *   PUT    /admin/webhooks.php?type=endpoints           - Update endpoint
 *   DELETE /admin/webhooks.php?type=endpoints&id=X     - Delete endpoint
 */

require_once __DIR__ . '/../../bootstrap.php';

use NomadCMS\Middleware\AuthMiddleware;
use NomadCMS\Middleware\CSRFMiddleware;
use NomadCMS\Security\WebhookService;
use NomadCMS\Security\InputSanitizer;
use NomadCMS\Webhooks\Mapping\WebhookEventsSchema;

header('Content-Type: application/json');

try {
    // 1. Authenticate. Fine-grained permission checks happen per-method/action
    // below (read vs create vs update vs delete), so a "webhooks:read:*"-only
    // role can list/view without being able to mutate, matching the
    // permission matrix in the Roles admin UI.
    $user = AuthMiddleware::requireAuth();

    $method = $_SERVER['REQUEST_METHOD'];
    $webhookService = new WebhookService();
    
    // Determine request type (webhooks or endpoints)
    $type = $_GET['type'] ?? 'webhooks';
    $action = $_GET['action'] ?? null;
    $id = isset($_GET['id']) ? (int)$_GET['id'] : null;

    // 2. Per-method RBAC check (applies to both outgoing webhooks and incoming
    // endpoints, since they share identical CRUD semantics):
    //   GET    -> webhooks:read:*
    //   POST   -> webhooks:create:* for creation, webhooks:update:* for
    //             mutating actions (test/rotate-secret/retry) on an existing webhook
    //   PUT    -> webhooks:update:*
    //   DELETE -> webhooks:delete:*
    // A "webhooks:manage:*" (or "*") permission covers all of the above via
    // RBACService's manage/admin super-action hierarchy.
    $mutatingActions = ['test', 'rotate-secret', 'retry'];
    switch ($method) {
        case 'GET':
            AuthMiddleware::requirePermission('webhooks:read:*');
            break;
        case 'POST':
            if ($action !== null && in_array($action, $mutatingActions, true)) {
                AuthMiddleware::requirePermission('webhooks:update:*');
            } else {
                AuthMiddleware::requirePermission('webhooks:create:*');
            }
            break;
        case 'PUT':
            AuthMiddleware::requirePermission('webhooks:update:*');
            break;
        case 'DELETE':
            AuthMiddleware::requirePermission('webhooks:delete:*');
            break;
        default:
            http_response_code(405);
            echo json_encode(['success' => false, 'error' => 'Method not allowed']);
            exit;
    }

    // =========================================================================
    // OUTGOING WEBHOOKS
    // =========================================================================
    if ($type === 'webhooks') {
        
        // GET: List or Get Single
        if ($method === 'GET') {
            
            // Get available events
            if ($action === 'events') {
                echo json_encode([
                    'success' => true,
                    'events' => $webhookService->getAvailableEvents(),
                    'payload_fields' => $webhookService->getAvailablePayloadFields()
                ]);
                exit;
            }
            
            // Get delivery history
            if ($action === 'deliveries' && $id) {
                $webhook = $webhookService->getWebhook($id);
                if (!$webhook || $webhook['user_id'] !== $user->id) {
                    http_response_code(404);
                    echo json_encode(['success' => false, 'error' => 'Webhook not found']);
                    exit;
                }
                
                $limit = min((int)($_GET['limit'] ?? 50), 100);
                $deliveries = $webhookService->getDeliveries($id, $limit);
                
                echo json_encode([
                    'success' => true,
                    'deliveries' => $deliveries
                ]);
                exit;
            }
            
            // Get single webhook
            if ($id) {
                $webhook = $webhookService->getWebhook($id);
                if (!$webhook || $webhook['user_id'] !== $user->id) {
                    http_response_code(404);
                    echo json_encode(['success' => false, 'error' => 'Webhook not found']);
                    exit;
                }
                
                echo json_encode(['success' => true, 'webhook' => $webhook]);
                exit;
            }
            
            // List all webhooks
            $webhooks = $webhookService->getWebhooksForUser($user->id);
            echo json_encode(['success' => true, 'webhooks' => $webhooks]);
            exit;
        }
        
        // POST: Create or Action
        if ($method === 'POST') {
            CSRFMiddleware::validateForSession();
            
            // Test webhook
            if ($action === 'test' && $id) {
                $webhook = $webhookService->getWebhook($id);
                if (!$webhook || $webhook['user_id'] !== $user->id) {
                    http_response_code(404);
                    echo json_encode(['success' => false, 'error' => 'Webhook not found']);
                    exit;
                }
                
                $result = $webhookService->sendTestWebhook($id);
                echo json_encode([
                    'success' => $result->success,
                    'delivery' => $result->toArray()
                ]);
                exit;
            }
            
            // Rotate secret
            if ($action === 'rotate-secret' && $id) {
                $webhook = $webhookService->getWebhook($id);
                if (!$webhook || $webhook['user_id'] !== $user->id) {
                    http_response_code(404);
                    echo json_encode(['success' => false, 'error' => 'Webhook not found']);
                    exit;
                }
                
                $newSecret = $webhookService->rotateSecret($id);
                echo json_encode([
                    'success' => true,
                    'message' => 'Secret rotated successfully',
                    'secret' => $newSecret // Only shown once!
                ]);
                exit;
            }
            
            // Retry delivery
            if ($action === 'retry' && $id) {
                $result = $webhookService->retryDelivery($id);
                echo json_encode([
                    'success' => $result->success,
                    'delivery' => $result->toArray()
                ]);
                exit;
            }
            
            // Create webhook
            $data = json_decode(file_get_contents('php://input'), true);
            if (!$data) {
                throw new \Exception('Invalid JSON body');
            }
            
            $name = trim($data['name'] ?? '');
            $url = trim($data['url'] ?? '');
            $events = $data['events'] ?? [];
            $payloadFields = $data['payload_fields'] ?? null;
            $slotFilters = $data['slot_filters'] ?? null;
            $slotTypeFilters = $data['slot_type_filters'] ?? null;
            $retryCount = (int)($data['retry_count'] ?? 3);
            $timeoutSeconds = (int)($data['timeout_seconds'] ?? 30);
            // Body shape for the subscriber. Discord/Slack reject Nomad's own
            // envelope outright, so this is what makes those destinations work.
            $payloadShape = (string)($data['payload_shape'] ?? WebhookService::SHAPE_NOMAD);
            // Signature standard: 'nomad' (Nomad/Stripe) or 'standard' (Standard Webhooks / Svix)
            $signatureStandard = (string)($data['signature_standard'] ?? WebhookService::SIG_STANDARD_NOMAD);
            // How a burst of form.submitted events is handled for THIS webhook
            // (off/global/per_form) - see WebhookService::FORMS_BATCH_MODES.
            $formsBatchMode = (string)($data['forms_batch_mode'] ?? WebhookService::FORMS_BATCH_OFF);
            
            if (empty($name)) {
                throw new \Exception('Name is required');
            }
            if (empty($url)) {
                throw new \Exception('URL is required');
            }
            if (empty($events) || !is_array($events)) {
                throw new \Exception('At least one event is required');
            }
            
            if (isset($data['social_config']) && !is_array($data['social_config'])) {
                throw new \InvalidArgumentException('Social alert settings must be an object');
            }
            $webhook = $webhookService->createWebhook(
                $user->id,
                $name,
                $url,
                $events,
                $payloadFields,
                $slotFilters,
                $slotTypeFilters,
                $retryCount,
                $timeoutSeconds,
                $data['headers'] ?? null,
                $payloadShape,
                $formsBatchMode,
                $signatureStandard,
                (string) ($data['social_locale'] ?? 'hu'),
                $data['social_config'] ?? null
            );
            
            echo json_encode([
                'success' => true,
                'message' => 'Webhook created successfully',
                'webhook' => $webhook
            ]);
            exit;
        }
        
        // PUT: Update
        if ($method === 'PUT') {
            CSRFMiddleware::validateForSession();
            
            $data = json_decode(file_get_contents('php://input'), true);
            if (!$data || !isset($data['id'])) {
                throw new \Exception('Invalid JSON body or missing ID');
            }
            
            $webhookId = (int)$data['id'];
            $webhook = $webhookService->getWebhook($webhookId);
            
            if (!$webhook || $webhook['user_id'] !== $user->id) {
                http_response_code(404);
                echo json_encode(['success' => false, 'error' => 'Webhook not found']);
                exit;
            }
            
            $updateData = [];
            if (isset($data['name'])) $updateData['name'] = trim($data['name']);
            if (isset($data['url'])) $updateData['url'] = trim($data['url']);
            if (isset($data['events'])) $updateData['events'] = $data['events'];
            if (array_key_exists('payload_fields', $data)) $updateData['payload_fields'] = $data['payload_fields'];
            if (array_key_exists('slot_filters', $data)) $updateData['slot_filters'] = $data['slot_filters'];
            if (array_key_exists('slot_type_filters', $data)) $updateData['slot_type_filters'] = $data['slot_type_filters'];
            if (array_key_exists('payload_shape', $data)) $updateData['payload_shape'] = $data['payload_shape'];
            if (array_key_exists('social_locale', $data)) $updateData['social_locale'] = $data['social_locale'];
            if (array_key_exists('social_config', $data)) $updateData['social_config'] = $data['social_config'];
            if (array_key_exists('signature_standard', $data)) $updateData['signature_standard'] = $data['signature_standard'];
            if (array_key_exists('forms_batch_mode', $data)) $updateData['forms_batch_mode'] = $data['forms_batch_mode'];
            if (isset($data['is_active'])) $updateData['is_active'] = (bool)$data['is_active'];
            if (isset($data['retry_count'])) $updateData['retry_count'] = (int)$data['retry_count'];
            if (isset($data['timeout_seconds'])) $updateData['timeout_seconds'] = (int)$data['timeout_seconds'];
            
            $webhookService->updateWebhook($webhookId, $updateData);
            
            echo json_encode([
                'success' => true,
                'message' => 'Webhook updated successfully'
            ]);
            exit;
        }
        
        // DELETE: Remove
        if ($method === 'DELETE') {
            if (!$id) {
                throw new \Exception('Webhook ID is required');
            }
            
            $webhook = $webhookService->getWebhook($id);
            if (!$webhook || $webhook['user_id'] !== $user->id) {
                http_response_code(404);
                echo json_encode(['success' => false, 'error' => 'Webhook not found']);
                exit;
            }
            
            $webhookService->deleteWebhook($id);
            
            echo json_encode([
                'success' => true,
                'message' => 'Webhook deleted successfully'
            ]);
            exit;
        }
    }
    
    // =========================================================================
    // INCOMING WEBHOOK ENDPOINTS
    // =========================================================================
    if ($type === 'endpoints') {
        
        // GET: List or Get Single
        if ($method === 'GET') {
            if ($id) {
                $endpoints = $webhookService->getEndpointsForUser($user->id);
                $endpoint = array_filter($endpoints, fn($e) => $e['id'] === $id);
                $endpoint = reset($endpoint);
                
                if (!$endpoint) {
                    http_response_code(404);
                    echo json_encode(['success' => false, 'error' => 'Endpoint not found']);
                    exit;
                }
                
                echo json_encode(['success' => true, 'endpoint' => $endpoint]);
                exit;
            }
            
            $endpoints = $webhookService->getEndpointsForUser($user->id);
            echo json_encode(['success' => true, 'endpoints' => $endpoints]);
            exit;
        }
        
        // POST: Create
        if ($method === 'POST') {
            CSRFMiddleware::validateForSession();
            
            // Rotate secret
            if ($action === 'rotate-secret' && $id) {
                $endpoints = $webhookService->getEndpointsForUser($user->id);
                $endpoint = array_filter($endpoints, fn($e) => $e['id'] === $id);
                
                if (empty($endpoint)) {
                    http_response_code(404);
                    echo json_encode(['success' => false, 'error' => 'Endpoint not found']);
                    exit;
                }
                
                $newSecret = $webhookService->rotateEndpointSecret($id);
                echo json_encode([
                    'success' => true,
                    'message' => 'Secret rotated successfully',
                    'secret' => $newSecret
                ]);
                exit;
            }
            
            $data = json_decode(file_get_contents('php://input'), true);
            if (!$data) {
                throw new \Exception('Invalid JSON body');
            }
            
            $name = trim($data['name'] ?? '');
            $endpointKey = trim($data['endpoint_key'] ?? '');
            $handler = trim($data['handler'] ?? 'default');
            $signatureHeader = trim($data['signature_header'] ?? 'X-Webhook-Signature');
            $timestampHeader = trim($data['timestamp_header'] ?? '');
            $signatureFormat = trim($data['signature_format'] ?? 'auto');

            // How the incoming request proves itself. Defaults to 'signature' so an
            // API client that predates auth modes cannot accidentally create an
            // endpoint that accepts unsigned traffic.
            $authMode = trim($data['auth_mode'] ?? WebhookEventsSchema::AUTH_MODE_SIGNATURE);

            // The provider's own secret (Stripe's whsec_…, GitHub's configured
            // string). Storing theirs is what makes the setup a single paste.
            $providedSecret = isset($data['secret']) && is_string($data['secret']) && trim($data['secret']) !== ''
                ? trim($data['secret'])
                : null;

            if (empty($name)) {
                throw new \Exception('Adj nevet a webhooknak.');
            }

            // In url_token mode the key IS the credential, so the server generates
            // it. Accepting one from the client would let the UI (or a script)
            // choose a guessable value and silently defeat the whole mode.
            if ($authMode === WebhookEventsSchema::AUTH_MODE_URL_TOKEN) {
                $endpointKey = $webhookService->generateUrlToken();
            } elseif (empty($endpointKey)) {
                throw new \Exception('Adj meg egy azonosítót a webhook címéhez.');
            }
            
            $endpoint = $webhookService->createEndpoint(
                $user->id,
                $name,
                $endpointKey,
                $handler,
                $signatureHeader,
                $timestampHeader,
                $signatureFormat,
                $authMode,
                $providedSecret
            );
            
            echo json_encode([
                'success' => true,
                'message' => 'Endpoint created successfully',
                'endpoint' => $endpoint
            ]);
            exit;
        }
        
        // PUT: Update
        if ($method === 'PUT') {
            CSRFMiddleware::validateForSession();
            
            $data = json_decode(file_get_contents('php://input'), true);
            if (!$data || !isset($data['id'])) {
                throw new \Exception('Invalid JSON body or missing ID');
            }
            
            $endpointId = (int)$data['id'];
            $endpoints = $webhookService->getEndpointsForUser($user->id);
            $endpoint = array_filter($endpoints, fn($e) => $e['id'] === $endpointId);
            
            if (empty($endpoint)) {
                http_response_code(404);
                echo json_encode(['success' => false, 'error' => 'Endpoint not found']);
                exit;
            }
            
            $updateData = [];
            if (isset($data['name'])) $updateData['name'] = trim($data['name']);
            if (isset($data['handler'])) $updateData['handler'] = trim($data['handler']);
            if (isset($data['is_active'])) $updateData['is_active'] = (bool)$data['is_active'];
            if (isset($data['signature_header'])) $updateData['signature_header'] = trim($data['signature_header']);
            if (isset($data['timestamp_header'])) $updateData['timestamp_header'] = trim($data['timestamp_header']);
            if (isset($data['signature_format'])) $updateData['signature_format'] = trim($data['signature_format']);
            if (isset($data['auth_mode'])) $updateData['auth_mode'] = trim($data['auth_mode']);

            // A secret is never stored through the generic update path: it needs
            // encryption and a minimum-length check, so it goes through
            // setEndpointSecret() instead of being treated as an ordinary column.
            if (isset($data['secret']) && is_string($data['secret']) && trim($data['secret']) !== '') {
                $webhookService->setEndpointSecret($id, trim($data['secret']));
            }
            
            $webhookService->updateEndpoint($endpointId, $updateData);
            
            echo json_encode([
                'success' => true,
                'message' => 'Endpoint updated successfully'
            ]);
            exit;
        }
        
        // DELETE: Remove
        if ($method === 'DELETE') {
            if (!$id) {
                throw new \Exception('Endpoint ID is required');
            }
            
            $endpoints = $webhookService->getEndpointsForUser($user->id);
            $endpoint = array_filter($endpoints, fn($e) => $e['id'] === $id);
            
            if (empty($endpoint)) {
                http_response_code(404);
                echo json_encode(['success' => false, 'error' => 'Endpoint not found']);
                exit;
            }
            
            $webhookService->deleteEndpoint($id);
            
            echo json_encode([
                'success' => true,
                'message' => 'Endpoint deleted successfully'
            ]);
            exit;
        }
    }
    
    // Method not allowed
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Method not allowed']);

} catch (\Exception $e) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
