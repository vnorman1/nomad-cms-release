<?php
/**
 * NOMAD CMS - Admin API - Verified Mail Profiles (for the Form Builder)
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * WHY THIS EXISTS INSTEAD OF REUSING /admin/mail-settings.php
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * The Forms module lets an admin pick which SMTP profile should send a form's
 * submission notifications. That picker needs a list of profiles - but a
 * forms:update:* role is not necessarily a mail:read:* role, and the full
 * mail-settings.php response carries host/port/username/diagnostics/advanced
 * transport options that a forms editor has no business seeing.
 *
 * This endpoint is the narrow slice: uuid + name + is_default, filtered to
 * profiles that are ACTUALLY sendable right now (status=verified AND
 * driver != disabled). An unverified or disabled profile is deliberately
 * omitted rather than shown greyed-out - FormNotifier::sendEmail() will not
 * use one anyway (see its class docblock), so listing it here would just be a
 * choice that silently does nothing.
 *
 * PERMISSION CHOICE: this intentionally checks forms:update:*, NOT mail:read:*
 * (the permission mail-settings.php now uses - see that file's docblock for
 * why 'mail' became its own resource instead of reusing system:read/manage).
 * The two are orthogonal: a Forms editor without any mail:* grant must still
 * be able to pick a profile for a form's notifications, and a Mail admin
 * without forms:update:* must not be able to edit form definitions through
 * this endpoint. Requiring mail:read:* here as well (an AND) would lock out
 * the common case of a forms-only editor role; requiring it as an alternative
 * (an OR) would let a mail-only admin edit form settings via this endpoint,
 * which is not this endpoint's job. forms:update:* alone is the correct,
 * minimal gate for "may configure which profile a FORM uses".
 *
 * GET /admin/form-mail-profiles.php
 * Permission: forms:update:* (creating/editing a form's notification settings)
 *
 * @package NomadCMS
 */

declare(strict_types=1);

require_once __DIR__ . '/../../bootstrap.php';

use NomadCMS\Middleware\AuthMiddleware;
use NomadCMS\Middleware\RateLimitMiddleware;
use NomadCMS\Services\Mail\MailProfileStore;
use NomadCMS\Services\Mail\MailSchema;

handlePreflight();
header('Content-Type: application/json; charset=utf-8');

/**
 * @param array<string, mixed> $payload
 */
function formMailProfilesJson(int $status, array $payload): never
{
    http_response_code($status);
    echo json_encode($payload, JSON_UNESCAPED_UNICODE);
    exit;
}

try {
    AuthMiddleware::requireAuth();
    AuthMiddleware::requirePermission('forms:update:*');
    RateLimitMiddleware::check('admin-form-mail-profiles', 120, 60);

    $method = strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET');
    if ($method !== 'GET') {
        header('Allow: GET, OPTIONS');
        formMailProfilesJson(405, ['success' => false, 'error' => 'Nem támogatott HTTP metódus.']);
    }

    $profiles = [];
    foreach (MailProfileStore::list() as $profile) {
        if ($profile['status'] !== MailSchema::STATUS_VERIFIED) {
            continue;
        }
        if ($profile['driver'] === MailSchema::DRIVER_DISABLED) {
            continue;
        }

        $profiles[] = [
            'uuid' => $profile['uuid'],
            'name' => $profile['name'],
            'is_default' => $profile['is_default'],
        ];
    }

    formMailProfilesJson(200, ['success' => true, 'profiles' => $profiles]);
} catch (Throwable $e) {
    error_log('[Forms][admin/form-mail-profiles] ' . $e->getMessage());
    $debug = ($_ENV['APP_DEBUG'] ?? 'false') === 'true';
    formMailProfilesJson(500, [
        'success' => false,
        'error' => $debug ? $e->getMessage() : 'Váratlan szerverhiba.',
        'code' => 'INTERNAL_ERROR',
    ]);
}
