<?php
/**
 * NOMAD CMS - Admin API - Webhook Mapping (automapper)
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * ENDPOINTS
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *   GET  /api/admin/webhook-mapping?endpoint=X&action=overview
 *        everything the mapper page needs in ONE request: endpoint state,
 *        discovered incoming fields, target catalog, current rules, suggestions
 *
 *   GET  ...&action=fields[&event_type=Y]   discovered incoming fields only
 *   GET  ...&action=targets                 two-level destination catalog
 *   GET  ...&action=rules                   the endpoint's approved rules
 *   GET  ...&action=suggest                 heuristic suggestions
 *   GET  ...&action=forward                 the endpoint's single outgoing target, or null
 *
 *   POST ...&action=rules      { rules: [...] }        approve pairings
 *   POST ...&action=target     { target_kind, target_key }
 *   POST ...&action=mode       { ingest_mode }         go live / back to test
 *   POST ...&action=forward    { url, payload_shape?, mapping? }  upsert the
 *        one outgoing webhook this endpoint forwards its mapped payload to
 *
 *   DELETE ...&rule_id=N       remove one rule
 *   DELETE ...&action=forward  remove the endpoint's outgoing target
 *
 * WHY AN `overview` ACTION EXISTS:
 * The mapper page is useless until it has all five of those things, and issuing
 * five round trips would mean five progressively-appearing panels - the kind of
 * loading experience that makes a tool feel unreliable. One request, one render.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * PERMISSIONS
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *   GET     webhooks:read:*
 *   POST    webhooks:update:*
 *   DELETE  webhooks:delete:*
 *
 * A "webhooks:manage:*" permission covers all of the above via RBACService's
 * manage/admin super-action hierarchy, matching admin/webhooks.php.
 *
 * NOTE ON SAMPLE VALUES: the field list returned here carries MASKED samples.
 * The masking happens in PayloadIntrospector, i.e. server-side, so a full email
 * address or phone number is never present in this response at all - not merely
 * hidden by the UI.
 *
 * @package NomadCMS
 */

declare(strict_types=1);

require_once __DIR__ . '/../../bootstrap.php';

use NomadCMS\Middleware\AuthMiddleware;
use NomadCMS\Middleware\CSRFMiddleware;
use NomadCMS\Security\WebhookService;
use NomadCMS\Services\Forms\FormService;
use NomadCMS\Services\Forms\FormValidationException;
use NomadCMS\Services\Forms\FormValidator;
use NomadCMS\Webhooks\Mapping\EventIngestService;
use NomadCMS\Webhooks\Mapping\FieldSynonyms;
use NomadCMS\Webhooks\Mapping\HeuristicMapper;
use NomadCMS\Webhooks\Mapping\MappingRuleRepository;
use NomadCMS\Webhooks\Mapping\PayloadIntrospector;
use NomadCMS\Webhooks\Mapping\TargetCatalogService;
use NomadCMS\Webhooks\Mapping\WebhookEventsSchema;

header('Content-Type: application/json; charset=utf-8');

/**
 * @param array<string, mixed> $payload
 */
function mappingJson(int $status, array $payload): never
{
    http_response_code($status);
    echo json_encode($payload, JSON_UNESCAPED_UNICODE);
    exit;
}

try {
    $user = AuthMiddleware::requireAuth();
    $method = $_SERVER['REQUEST_METHOD'];

    switch ($method) {
        case 'GET':
            AuthMiddleware::requirePermission('webhooks:read:*');
            break;
        case 'POST':
            AuthMiddleware::requirePermission('webhooks:update:*');
            CSRFMiddleware::validateForSession();
            break;
        case 'DELETE':
            AuthMiddleware::requirePermission('webhooks:delete:*');
            CSRFMiddleware::validateForSession();
            break;
        default:
            mappingJson(405, ['success' => false, 'error' => 'A metódus nem engedélyezett.']);
    }

    $endpointKey = trim((string) ($_GET['endpoint'] ?? ''));
    $action = (string) ($_GET['action'] ?? 'overview');

    $webhookService = new WebhookService();
    $catalog = new TargetCatalogService();

    // The target catalog is the only action that does not need an endpoint: the
    // UI loads it while the user is still choosing which endpoint to configure.
    if ($method === 'GET' && $action === 'targets') {
        mappingJson(200, ['success' => true] + $catalog->catalog());
    }

    if ($endpointKey === '' || !preg_match('/^[a-z0-9-]{3,64}$/', $endpointKey)) {
        mappingJson(400, ['success' => false, 'error' => 'Hiányzó vagy érvénytelen végpont-azonosító.']);
    }

    $endpoint = $webhookService->getEndpointByKey($endpointKey);
    if ($endpoint === null) {
        mappingJson(404, ['success' => false, 'error' => 'A végpont nem található.']);
    }

    // Ownership check, mirroring admin/webhooks.php: an endpoint belongs to the
    // user who created it, and a *-scoped role is what grants access to others'.
    if ((int) $endpoint['user_id'] !== (int) $user->id) {
        AuthMiddleware::requirePermission('webhooks:manage:*');
    }

    $introspector = new PayloadIntrospector();
    $rulesRepo = new MappingRuleRepository();
    $ingest = new EventIngestService();

    $eventType = isset($_GET['event_type']) && $_GET['event_type'] !== ''
        ? substr((string) $_GET['event_type'], 0, 128)
        : null;

    // =========================================================================
    // GET
    // =========================================================================
    if ($method === 'GET') {
        $fields = null;
        $rules = null;

        if (in_array($action, ['overview', 'fields', 'suggest'], true)) {
            $fields = $introspector->describeEndpoint($endpointKey, $eventType);
        }
        if (in_array($action, ['overview', 'rules', 'suggest'], true)) {
            $rules = $rulesRepo->forEndpoint($endpointKey, null, false);
        }

        if ($action === 'fields') {
            mappingJson(200, ['success' => true, 'fields' => $fields]);
        }
        if ($action === 'rules') {
            mappingJson(200, ['success' => true, 'rules' => $rules]);
        }
        if ($action === 'forward') {
            $existing = mappingFindForwardWebhook($endpointKey, (int) $endpoint['user_id']);
            mappingJson(200, ['success' => true, 'forward' => $existing !== null ? mappingForwardState($existing) : null]);
        }

        $suggestions = null;
        if (in_array($action, ['overview', 'suggest'], true)) {
            $suggestions = buildSuggestions($endpoint, $fields, $catalog, $rulesRepo, $eventType);
        }

        if ($action === 'suggest') {
            mappingJson(200, ['success' => true] + $suggestions);
        }

        // overview
        mappingJson(200, [
            'success' => true,
            'endpoint' => mappingEndpointState($endpoint, $ingest),
            'fields' => $fields,
            'targets' => $catalog->catalog()['groups'],
            'rules' => $rules,
            'suggestions' => $suggestions['suggestions'] ?? [],
            'unmatched_sources' => $suggestions['unmatched_sources'] ?? [],
            'unmatched_targets' => $suggestions['unmatched_targets'] ?? [],
        ]);
    }

    // =========================================================================
    // DELETE
    // =========================================================================
    if ($method === 'DELETE') {
        if ($action === 'forward') {
            $existing = mappingFindForwardWebhook($endpointKey, (int) $endpoint['user_id']);
            $deleted = $existing !== null && $webhookService->deleteWebhook((int) $existing['id']);
            mappingJson($deleted ? 200 : 404, [
                'success' => $deleted,
                'error' => $deleted ? null : 'Nincs beállított kimenő cél ehhez a végponthoz.',
            ]);
        }

        $ruleId = (int) ($_GET['rule_id'] ?? 0);
        if ($ruleId <= 0) {
            mappingJson(400, ['success' => false, 'error' => 'Hiányzó szabály azonosító.']);
        }

        $deleted = $rulesRepo->delete($endpointKey, $ruleId);
        mappingJson($deleted ? 200 : 404, [
            'success' => $deleted,
            'error' => $deleted ? null : 'A szabály nem található ehhez a végponthoz.',
        ]);
    }

    // =========================================================================
    // POST
    // =========================================================================
    $body = json_decode((string) file_get_contents('php://input'), true);
    if (!is_array($body)) {
        $body = [];
    }

    /**
     * "Form generálása a webhookból" - the one-click path that replaces the
     * old flow: hand-build a Form in the schema builder, hunt for it in the
     * target selector, then drag every cable in one at a time.
     *
     * Instead this single action, given nothing but the endpoint's already-
     * discovered incoming fields (see PayloadIntrospector; the same data the
     * canvas is already rendering):
     *
     *   1. builds a Form field definition per incoming field, inferring the
     *      Form field TYPE from the type PayloadIntrospector already detected
     *      (email/phone/datetime/number/... - see mapFieldType below), so the
     *      admin never re-types what the payload already proved,
     *   2. creates that Form via the normal FormService::create() - it is a
     *      completely ordinary form afterwards, editable in the Forms page
     *      like any other,
     *   3. points this endpoint at it (same effect as action=target),
     *   4. saves a straight 1:1 rule per field (same effect as action=rules).
     *
     * Anything that already exists (a chosen target, approved rules) is left
     * untouched if this fails partway - each step re-uses the same service
     * calls the manual flow uses, so a partial failure leaves the endpoint in
     * a state the manual flow could have produced too, never a broken one.
     */
    if ($action === 'generate-form') {
        $fields = $introspector->describeEndpoint($endpointKey, $eventType);
        $incoming = (array) ($fields['fields'] ?? []);

        // No hard stop when nothing has arrived yet: the admin may reasonably
        // want the Form (and the endpoint pointed at it) to exist BEFORE the
        // first test event, so it is there and ready the moment a real
        // payload shows up - mapping is a separate, later step (via the
        // table/canvas or the `rules` action), not something this action
        // must complete in the same request. An empty $incoming below simply
        // produces a Form with no fields yet and skips the 1:1 rule-building
        // loop; nothing downstream assumes the list is non-empty.

        // Only the fields the user actually wants, if they narrowed the
        // selection on the canvas/table first; otherwise every discovered
        // field becomes a Form field.
        $selectedPaths = isset($body['source_paths']) && is_array($body['source_paths'])
            ? array_map('strval', $body['source_paths'])
            : null;
        if ($selectedPaths !== null) {
            $selected = array_flip($selectedPaths);
            $incoming = array_values(array_filter(
                $incoming,
                static fn (array $f): bool => isset($selected[(string) $f['path']])
            ));
        }

        $formName = trim((string) ($body['name'] ?? ''));
        if ($formName === '') {
            // The endpoint's own name first: the admin already chose it and it
            // is always specific ("Cal.com időpontok"). provider_label falls
            // back to the generic "Egyéb szolgáltatás" whenever no payload has
            // been sampled yet, which would win every time if checked first.
            $formName = (string) ($endpoint['name'] ?? $fields['provider_label'] ?? 'Webhook űrlap');
        }
        $formSlug = isset($body['slug']) && is_string($body['slug']) && trim($body['slug']) !== ''
            ? trim($body['slug'])
            : null;

        $formFields = [];
        $usedNames = [];

        if ($incoming === []) {
            // Nothing sampled yet: rather than a blank Form, seed it with the
            // fields almost every lead/booking/contact form needs (name,
            // e-mail, phone, message...) - see mappingGuessedFields() for the
            // exact list and why this order. The admin edits or deletes any
            // of these freely once real data starts mapping in; this is a
            // head start, not a commitment.
            $formFields = mappingGuessedFields();
        } else {
            foreach ($incoming as $index => $field) {
                $name = mappingNormalizeFieldName((string) ($field['key'] ?? ''), $index);
                // A collision means two different JSON paths reduced to the same
                // leaf key (e.g. "attendee.email" and "organizer.email" both have
                // key "email") - suffixing keeps every discovered field instead of
                // silently dropping one, which would otherwise show up later as
                // "why does my form have one fewer field than the payload".
                $base = $name;
                $suffix = 2;
                while (isset($usedNames[$name])) {
                    $name = $base . '_' . $suffix;
                    $suffix++;
                }
                $usedNames[$name] = true;

                $formFields[] = [
                    'name' => $name,
                    'label' => (string) ($field['label'] ?? $name),
                    'type' => mappingFieldTypeForForm((string) ($field['type'] ?? 'string')),
                    'required' => false,
                    // The webhook's own field labeler already flags likely PII
                    // (email/phone/name-shaped values) via `role` - carrying that
                    // into the Form definition means the new form is born with
                    // the same "handle this carefully" flag a hand-built one would
                    // need an admin to set manually.
                    'pii' => in_array($field['role'] ?? null, ['customer', 'owner'], true),
                ];

                // Kept for the rule-building loop below, without re-deriving it.
                $incoming[$index]['_form_field_name'] = $name;
            }
        }

        try {
            $form = FormService::create([
                'name' => $formName,
                'slug' => $formSlug,
                'description' => sprintf(
                    'Automatikusan létrehozva a "%s" webhook végpontból (%s).',
                    (string) ($endpoint['name'] ?? $endpointKey),
                    gmdate('Y-m-d')
                ),
                'fields' => $formFields,
                // A webhook delivers server-to-server: there is no browser to
                // solve the Proof-of-Work challenge and no human to leave a
                // honeypot field empty, so both defences would only ever
                // block the legitimate traffic this form exists to receive.
                // strict_schema stays at its normal default (false) - nothing
                // about coming from a webhook changes whether unknown keys
                // should be tolerated.
                'settings' => [
                    'honeypot_enabled' => false,
                    'pow' => ['enabled' => false],
                ],
            ], $user->uuid ?? null);
        } catch (FormValidationException $e) {
            mappingJson(422, ['success' => false, 'error' => 'Form létrehozása sikertelen.', 'details' => $e->getErrors()]);
        }

        $newSlug = (string) $form['data']['slug'];

        try {
            $webhookService->updateEndpoint((int) $endpoint['id'], [
                'target_kind' => WebhookEventsSchema::TARGET_FORM,
                'target_key' => $newSlug,
            ]);
        } catch (\InvalidArgumentException $e) {
            mappingJson(422, ['success' => false, 'error' => $e->getMessage()]);
        }
        $rulesRepo->pruneForeignTargets($endpointKey, WebhookEventsSchema::TARGET_FORM, $newSlug);

        // Straight 1:1: every discovered field feeds the Form field generated
        // from it. There is nothing to guess here (unlike the heuristic
        // suggester, which pairs against an EXISTING, independently-named
        // target) - the field was named FROM this exact source path.
        $rules = [];
        foreach ($incoming as $field) {
            $rules[] = [
                'source_space' => $field['space'] ?? WebhookEventsSchema::SPACE_RAW,
                'source_path' => $field['path'],
                'target_kind' => WebhookEventsSchema::TARGET_FORM,
                'target_key' => $newSlug,
                'target_field' => $field['_form_field_name'],
                'transform' => null,
                'event_type' => $eventType,
                'origin' => WebhookEventsSchema::ORIGIN_USER,
            ];
        }
        $saved = $rulesRepo->saveMany($endpointKey, $rules, (int) $user->id);

        mappingJson(201, [
            'success' => true,
            'form' => $form,
            'endpoint' => mappingEndpointState($webhookService->getEndpointByKey($endpointKey), $ingest),
            'targets' => $catalog->catalog()['groups'],
            'saved_rules' => $saved['saved'],
            'rules' => $rulesRepo->forEndpoint($endpointKey, null, false),
        ]);
    }

    /**
     * Add one new field to the current Form target on the fly.
     *
     * Exists for exactly the moment the automapper is proven not to be magic:
     * the payload has a field the admin wants kept, but the Form was built
     * before that field existed. Without this the only path is leaving the
     * mapper, opening the Forms builder, adding the field, saving, and coming
     * back - for a single text column.
     *
     * Deliberately FORM-ONLY. `massive`/`content` targets are declared in
     * nomad.schema.json (or, for schemaless massive slots, already accept any
     * field name the mapper types in - see TargetCatalogService's schemaless
     * handling), so there is no equivalent "the schema is too strict" problem
     * to solve for them here.
     *
     * Accepts EITHER a single field (name/label/type/pii at the top level,
     * the original shape) OR a batch (`fields`: [...] of the same shape) in
     * one request - added for "Újra-mappelés" against a Form with too few
     * columns for its discovered payload: generating N missing columns as N
     * separate round trips would be needlessly slow and would leave the Form
     * in N-1 different intermediate shapes if one failed partway.
     */
    if ($action === 'add-target-field') {
        $targetKind = (string) ($endpoint['target_kind'] ?? '');
        $targetKey = (string) ($endpoint['target_key'] ?? '');
        if ($targetKind !== WebhookEventsSchema::TARGET_FORM || $targetKey === '') {
            mappingJson(422, [
                'success' => false,
                'error' => 'Ez a végpont mentési célja nem egy űrlap, ide nem adható új mező.',
            ]);
        }

        $requested = isset($body['fields']) && is_array($body['fields'])
            ? $body['fields']
            : [$body];

        if (count($requested) > 15) {
            mappingJson(422, ['success' => false, 'error' => 'Egyszerre legfeljebb 15 mező adható hozzá.']);
        }

        $form = FormService::findBySlug($targetKey);
        if ($form === null) {
            mappingJson(404, ['success' => false, 'error' => 'Az űrlap már nem létezik.']);
        }

        $existingFields = (array) ($form['data']['fields'] ?? []);
        $existingNames = array_flip(array_column($existingFields, 'name'));

        $toAdd = [];
        foreach ($requested as $raw) {
            if (!is_array($raw)) {
                continue;
            }

            $name = FormValidator::normalizeFieldName($raw['name'] ?? null);
            if ($name === null) {
                mappingJson(422, [
                    'success' => false,
                    'error' => 'A mező neve kötelező: csak betű, szám, kötőjel vagy alulvonás, max. 64 karakter.',
                ]);
            }
            if (isset($existingNames[$name]) || isset($toAdd[$name])) {
                mappingJson(422, [
                    'success' => false,
                    'error' => sprintf('Már van "%s" nevű mező ezen az űrlapon.', $name),
                ]);
            }

            $type = is_string($raw['type'] ?? null) ? (string) $raw['type'] : 'text';
            $toAdd[$name] = [
                'name' => $name,
                'label' => is_string($raw['label'] ?? null) && trim((string) $raw['label']) !== ''
                    ? (string) $raw['label']
                    : $name,
                'type' => in_array($type, FormValidator::TYPES, true) ? $type : 'text',
                'required' => false,
                'pii' => (bool) ($raw['pii'] ?? false),
            ];
        }

        if ($toAdd === []) {
            mappingJson(422, ['success' => false, 'error' => 'Nincs érvényes mező a hozzáadáshoz.']);
        }

        $existingFields = [...$existingFields, ...array_values($toAdd)];

        try {
            $updated = FormService::update($targetKey, ['fields' => $existingFields]);
        } catch (FormValidationException $e) {
            mappingJson(422, ['success' => false, 'error' => 'A mező hozzáadása sikertelen.', 'details' => $e->getErrors()]);
        }

        mappingJson(200, [
            'success' => true,
            'form' => $updated,
            'targets' => $catalog->catalog()['groups'],
        ]);
    }

    /**
     * Remove one field from the current Form target.
     *
     * The counterpart to add-target-field: a field added on the fly (or one
     * generate-form created from a payload) can be just as easily wrong as
     * useful, and until now undoing that meant leaving the mapper for the
     * Forms builder. Any mapping rule already pointing at the removed field
     * is dropped in the same request - see MappingRuleRepository's
     * deleteForTargetField for why a dangling rule is worse than none.
     *
     * Deliberately FORM-ONLY, for the same reason add-target-field is: massive/
     * content targets come from nomad.schema.json, not from this endpoint.
     */
    if ($action === 'remove-target-field') {
        $targetKind = (string) ($endpoint['target_kind'] ?? '');
        $targetKey = (string) ($endpoint['target_key'] ?? '');
        if ($targetKind !== WebhookEventsSchema::TARGET_FORM || $targetKey === '') {
            mappingJson(422, [
                'success' => false,
                'error' => 'Ez a végpont mentési célja nem egy űrlap, itt nincs mit törölni.',
            ]);
        }

        $name = FormValidator::normalizeFieldName($body['name'] ?? null);
        if ($name === null) {
            mappingJson(422, ['success' => false, 'error' => 'Hiányzó vagy érvénytelen mezőnév.']);
        }

        $form = FormService::findBySlug($targetKey);
        if ($form === null) {
            mappingJson(404, ['success' => false, 'error' => 'Az űrlap már nem létezik.']);
        }

        $existingFields = (array) ($form['data']['fields'] ?? []);
        $remaining = array_values(array_filter(
            $existingFields,
            static fn (array $f): bool => ($f['name'] ?? null) !== $name
        ));

        if (count($remaining) === count($existingFields)) {
            mappingJson(404, ['success' => false, 'error' => sprintf('Nincs "%s" nevű mező ezen az űrlapon.', $name)]);
        }

        try {
            $updated = FormService::update($targetKey, ['fields' => $remaining]);
        } catch (FormValidationException $e) {
            mappingJson(422, ['success' => false, 'error' => 'A mező törlése sikertelen.', 'details' => $e->getErrors()]);
        }

        $rulesRepo->deleteForTargetField($endpointKey, $targetKind, $targetKey, $name);

        mappingJson(200, [
            'success' => true,
            'form' => $updated,
            'targets' => $catalog->catalog()['groups'],
            'rules' => $rulesRepo->forEndpoint($endpointKey, null, false),
        ]);
    }

    if ($action === 'target') {
        $targetKind = (string) ($body['target_kind'] ?? '');
        $targetKey = (string) ($body['target_key'] ?? '');

        if ($catalog->findTarget($targetKind, $targetKey) === null) {
            mappingJson(422, ['success' => false, 'error' => 'A választott mentési cél nem létezik.']);
        }

        try {
            $webhookService->updateEndpoint((int) $endpoint['id'], [
                'target_kind' => $targetKind,
                'target_key' => $targetKey,
            ]);
        } catch (\InvalidArgumentException $e) {
            mappingJson(422, ['success' => false, 'error' => $e->getMessage()]);
        }

        // Rules pointing at the PREVIOUS destination must go. Keeping them would
        // be worse than useless: they still match by source path, so the executor
        // would keep writing into a form this endpoint is no longer bound to.
        $pruned = $rulesRepo->pruneForeignTargets($endpointKey, $targetKind, $targetKey);

        mappingJson(200, [
            'success' => true,
            'pruned_rules' => $pruned,
            'endpoint' => mappingEndpointState($webhookService->getEndpointByKey($endpointKey), $ingest),
        ]);
    }

    if ($action === 'mode') {
        $mode = (string) ($body['ingest_mode'] ?? '');
        if (!in_array($mode, WebhookEventsSchema::MODES, true)) {
            mappingJson(422, ['success' => false, 'error' => 'Érvénytelen üzemmód.']);
        }

        if ($mode === WebhookEventsSchema::MODE_LIVE) {
            // Going live means "from now on, signed events write to my content".
            // Both preconditions are checked here rather than trusted from the
            // UI, because this is the switch that lets external input reach live
            // data.
            if (($endpoint['target_kind'] ?? null) === null || ($endpoint['target_key'] ?? null) === null) {
                mappingJson(422, [
                    'success' => false,
                    'error' => 'Élesítés előtt válaszd ki, hova mentsük az adatot.',
                ]);
            }
            // A secret is only a precondition when this endpoint AUTHENTICATES by
            // signature. In url_token mode the unguessable URL is the credential,
            // and demanding a secret would send the user looking for a setting
            // that has no purpose here.
            $authMode = (string) ($endpoint['auth_mode'] ?? WebhookEventsSchema::AUTH_MODE_SIGNATURE);
            if ($authMode === WebhookEventsSchema::AUTH_MODE_SIGNATURE && empty($endpoint['secret'])) {
                mappingJson(422, [
                    'success' => false,
                    'error' => 'Élesítés előtt add meg a szolgáltató titkos kulcsát (aláírás-ellenőrzés).',
                ]);
            }
        }

        $update = ['ingest_mode' => $mode];
        if ($mode === WebhookEventsSchema::MODE_LEARNING) {
            // Re-opening the learning window restarts the clock, so a user who
            // returns to test mode gets a full window rather than an already
            // expired one.
            $update['learning_expires_at'] = gmdate('c', time() + WebhookEventsSchema::LEARNING_WINDOW_SECONDS);
        }

        try {
            $webhookService->updateEndpoint((int) $endpoint['id'], $update);
        } catch (\InvalidArgumentException $e) {
            mappingJson(422, ['success' => false, 'error' => $e->getMessage()]);
        }

        mappingJson(200, [
            'success' => true,
            'endpoint' => mappingEndpointState($webhookService->getEndpointByKey($endpointKey), $ingest),
        ]);
    }

    if ($action === 'rules') {
        $incoming = $body['rules'] ?? null;
        if (!is_array($incoming)) {
            mappingJson(400, ['success' => false, 'error' => 'A "rules" mezőnek listának kell lennie.']);
        }
        if (count($incoming) > 200) {
            mappingJson(422, ['success' => false, 'error' => 'Egyszerre legfeljebb 200 összekötés mentheto.']);
        }

        $targetKind = (string) ($endpoint['target_kind'] ?? '');
        $targetKey = (string) ($endpoint['target_key'] ?? '');
        if ($targetKind === '' || $targetKey === '') {
            mappingJson(422, [
                'success' => false,
                'error' => 'Először válaszd ki a mentési célt, utána köthetsz össze mezőket.',
            ]);
        }

        $target = $catalog->findTarget($targetKind, $targetKey);
        if ($target === null) {
            mappingJson(422, ['success' => false, 'error' => 'A beállított mentési cél már nem létezik.']);
        }

        // Field names are validated against the destination unless it is
        // schemaless. A typo'd field name on a schema'd target is always a
        // mistake, and catching it here is far cheaper than discovering it when
        // a week of events have written into a column that does not exist.
        $allowedFields = array_column((array) $target['fields'], 'name');
        $schemaless = ($target['schemaless'] ?? false) === true;

        $prepared = [];
        foreach ($incoming as $rule) {
            if (!is_array($rule)) {
                continue;
            }
            $field = (string) ($rule['target_field'] ?? '');
            if (!$schemaless && $allowedFields !== [] && !in_array($field, $allowedFields, true)) {
                mappingJson(422, [
                    'success' => false,
                    'error' => sprintf('A "%s" nem létező célmező.', $field),
                ]);
            }

            $prepared[] = [
                'source_space' => $rule['source_space'] ?? WebhookEventsSchema::SPACE_RAW,
                'source_path' => $rule['source_path'] ?? '',
                'target_kind' => $targetKind,
                'target_key' => $targetKey,
                'target_field' => $field,
                'transform' => $rule['transform'] ?? null,
                'event_type' => $rule['event_type'] ?? null,
                'origin' => WebhookEventsSchema::ORIGIN_USER,
            ];
        }

        try {
            $saved = $rulesRepo->saveMany($endpointKey, $prepared, (int) $user->id);
        } catch (\InvalidArgumentException $e) {
            mappingJson(422, ['success' => false, 'error' => $e->getMessage()]);
        }

        mappingJson(200, [
            'success' => true,
            'saved' => $saved['saved'],
            'replaced' => $saved['replaced'],
            'rules' => $rulesRepo->forEndpoint($endpointKey, null, false),
        ]);
    }

    if ($action === 'forward') {
        $url = trim((string) ($body['url'] ?? ''));
        if ($url === '') {
            mappingJson(422, ['success' => false, 'error' => 'Hiányzó cél URL.']);
        }

        $shape = (string) ($body['payload_shape'] ?? WebhookService::SHAPE_NOMAD);
        $mapping = is_array($body['mapping'] ?? null) ? $body['mapping'] : [];
        $payloadFields = array_values(array_unique(array_filter(array_map('strval', $mapping))));

        $existing = mappingFindForwardWebhook($endpointKey, (int) $endpoint['user_id']);

        try {
            if ($existing !== null) {
                $webhookService->updateWebhook((int) $existing['id'], [
                    'url' => $url,
                    'payload_shape' => $shape,
                    'payload_fields' => $payloadFields !== [] ? $payloadFields : null,
                    'events' => ['webhook.forwarded'],
                    'slot_filters' => [$endpointKey],
                    'is_active' => true,
                ]);
                $saved = $webhookService->getWebhook((int) $existing['id']);
            } else {
                $saved = $webhookService->createWebhook(
                    (int) $endpoint['user_id'],
                    'Kimenő: ' . (string) ($endpoint['name'] ?? $endpointKey),
                    $url,
                    ['webhook.forwarded'],
                    $payloadFields !== [] ? $payloadFields : null,
                    [$endpointKey],
                    null,
                    3,
                    15,
                    null,
                    $shape
                );
            }
        } catch (\RuntimeException $e) {
            mappingJson(422, ['success' => false, 'error' => $e->getMessage()]);
        }

        mappingJson($existing !== null ? 200 : 201, ['success' => true, 'forward' => mappingForwardState($saved)]);
    }

    mappingJson(400, ['success' => false, 'error' => 'Ismeretlen művelet: ' . $action]);
} catch (\Throwable $e) {
    error_log('[WebhookMapping] Admin endpoint error: ' . $e->getMessage());

    if (!headers_sent()) {
        http_response_code(500);
        echo json_encode([
            'success' => false,
            'error' => 'Váratlan hiba történt.',
        ], JSON_UNESCAPED_UNICODE);
    }
}

// =============================================================================
// HELPERS
// =============================================================================

/**
 * The endpoint's single outgoing target, if one is configured.
 *
 * A `webhooks` row belongs to this endpoint's forward when it is owned by the
 * same user, subscribes to `webhook.forwarded`, and names this endpoint's
 * slug in its slot_filters - the same identity the dispatch bridge in
 * webhook-receiver.php matches on. Scans the user's webhooks (there are only
 * ever a handful per user) rather than adding a dedicated lookup table.
 */
function mappingFindForwardWebhook(string $endpointKey, int $userId): ?array
{
    $db = \NomadCMS\Database\AuthDatabase::getInstance();
    $stmt = $db->prepare("SELECT id FROM webhooks WHERE user_id = ? AND events LIKE ? ORDER BY id ASC");
    $stmt->execute([$userId, '%"webhook.forwarded"%']);

    $service = new WebhookService();
    while ($row = $stmt->fetch()) {
        $webhook = $service->getWebhook((int) $row['id']);
        if ($webhook === null) {
            continue;
        }
        $filters = $webhook['slot_filters'] ?? null;
        if (is_array($filters) && in_array($endpointKey, $filters, true)) {
            return $webhook;
        }
    }

    return null;
}

/**
 * The forward config shape the CanvasMap outgoing node reads/writes. Never
 * carries the signing secret.
 *
 * @param array<string, mixed> $webhook
 * @return array<string, mixed>
 */
function mappingForwardState(array $webhook): array
{
    return [
        'id' => (int) $webhook['id'],
        'url' => (string) $webhook['url'],
        'payload_shape' => (string) ($webhook['payload_shape'] ?? WebhookService::SHAPE_NOMAD),
        'mapping' => array_values((array) ($webhook['payload_fields'] ?? [])),
        'is_active' => (bool) ($webhook['is_active'] ?? true),
    ];
}

/**
 * Endpoint state as the mapper UI needs it.
 *
 * `effective_mode` is reported ALONGSIDE the stored mode on purpose: an endpoint
 * whose learning window has elapsed is already enforcing signatures, and showing
 * only the stored "Teszt mód" would be a lie the user cannot debug.
 *
 * @param array<string, mixed> $endpoint
 * @return array<string, mixed>
 */
function mappingEndpointState(array $endpoint, EventIngestService $ingest): array
{
    return [
        'key' => (string) $endpoint['endpoint_key'],
        'name' => (string) $endpoint['name'],
        'is_active' => (bool) $endpoint['is_active'],
        'ingest_mode' => (string) ($endpoint['ingest_mode'] ?? WebhookEventsSchema::MODE_LIVE),
        'effective_mode' => $ingest->effectiveMode($endpoint),
        'learning_expires_at' => $endpoint['learning_expires_at'] ?? null,
        'target_kind' => $endpoint['target_kind'] ?? null,
        'target_key' => $endpoint['target_key'] ?? null,
        'signature_format' => (string) ($endpoint['signature_format'] ?? 'auto'),
        'auth_mode' => (string) ($endpoint['auth_mode'] ?? WebhookEventsSchema::AUTH_MODE_SIGNATURE),
        // The full URL to paste into the provider. In url_token mode this IS the
        // credential, which is why the UI needs it front and centre rather than
        // buried in a details panel.
        'url' => $endpoint['url'] ?? null,
        'last_called_at' => $endpoint['last_called_at'] ?? null,
        // Never the secret itself, only whether one exists - which is all the
        // "can I go live?" check needs.
        'has_secret' => !empty($endpoint['secret']),
    ];
}

/**
 * Turn a discovered leaf key into a legal Form field name.
 *
 * FormValidator::normalizeFieldName only accepts [A-Za-z0-9_-]{1,64}, but a
 * webhook's leaf key can be anything a third party chose (camelCase, spaces,
 * unicode, a bare index from an array). Rather than reject the whole
 * generate-form request over one oddly-named field, every disallowed
 * character is folded to "_" and an empty or over-long result falls back to
 * a positional name - so a payload with a field the admin never anticipated
 * still produces a usable form instead of a 422.
 */
function mappingNormalizeFieldName(string $key, int $index): string
{
    $slug = preg_replace('/[^A-Za-z0-9_\-]+/', '_', trim($key)) ?? '';
    $slug = trim($slug, '_');

    if ($slug === '' || strlen($slug) > 64) {
        return 'field_' . ($index + 1);
    }

    return $slug;
}

/**
 * Map a PayloadIntrospector-detected value type to a Form field type.
 *
 * The webhook side and the Form side each have their own type vocabulary for
 * historical reasons (PayloadIntrospector::inferType vs FormValidator::TYPES),
 * so generate-form is the one place that has to reconcile them. Anything with
 * no obviously better Form type becomes 'text' rather than failing the whole
 * request over an exotic value.
 */
function mappingFieldTypeForForm(string $incomingType): string
{
    return match ($incomingType) {
        'email' => 'email',
        'phone' => 'tel',
        'url' => 'url',
        'datetime' => 'date',
        'number', 'numeric_string' => 'number',
        'boolean' => 'checkbox',
        default => 'text',
    };
}

/**
 * A best-guess starter field set for a Form generated with no payload to
 * learn from yet.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * WHY THESE, IN THIS ORDER, AND WHY 15
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * FieldSynonyms already encodes, for the heuristic mapper, which canonical
 * concepts (name, email, phone, message...) show up across real lead/
 * booking/contact forms and under what Hungarian/English key names. That
 * same list of concepts is what a human would sketch on a whiteboard before
 * building this Form by hand - so it is reused here as the FALLBACK vocabulary
 * instead of inventing a second one that could drift from it.
 *
 * The order is deliberately "who, how to reach them, why they are here,
 * when" - the shape of almost any lead/booking/contact form - followed by the
 * commerce- and logistics-flavoured groups (amount, address, reference...)
 * that only some integrations need. Capping at 15 keeps the generated Form
 * from becoming a wall of fields nobody asked for; a webhook whose payload
 * genuinely needs more can always add them (see add-target-field) once real
 * data starts arriving and shows what is actually there.
 *
 * @return array<int, array<string, mixed>>
 */
function mappingGuessedFields(): array
{
    $priority = [
        FieldSynonyms::NAME,
        FieldSynonyms::EMAIL,
        FieldSynonyms::PHONE,
        FieldSynonyms::MESSAGE,
        FieldSynonyms::SUBJECT,
        FieldSynonyms::DATE,
        FieldSynonyms::COMPANY,
        FieldSynonyms::ADDRESS,
        FieldSynonyms::CITY,
        FieldSynonyms::POSTAL_CODE,
        FieldSynonyms::COUNTRY,
        FieldSynonyms::AMOUNT,
        FieldSynonyms::QUANTITY,
        FieldSynonyms::REFERENCE,
        FieldSynonyms::LOCATION,
    ];

    // A Form field TYPE per canonical group - not every group maps cleanly
    // onto mappingFieldTypeForForm's webhook-value-type vocabulary, since
    // there is no sampled value here to infer a type FROM.
    $typeByGroup = [
        FieldSynonyms::EMAIL => 'email',
        FieldSynonyms::PHONE => 'tel',
        FieldSynonyms::MESSAGE => 'textarea',
        FieldSynonyms::DATE => 'date',
        FieldSynonyms::AMOUNT => 'number',
        FieldSynonyms::QUANTITY => 'number',
        FieldSynonyms::URL => 'url',
    ];

    // A Form field marked PII by default where the concept unambiguously IS
    // personal data - mirrors the `role`-based flag generate-form applies
    // when it DOES have a payload to read `role` from.
    $piiGroups = [
        FieldSynonyms::NAME, FieldSynonyms::EMAIL, FieldSynonyms::PHONE,
        FieldSynonyms::ADDRESS, FieldSynonyms::CITY, FieldSynonyms::POSTAL_CODE,
    ];

    $fields = [];
    foreach (array_slice($priority, 0, 15) as $group) {
        $fields[] = [
            'name' => $group,
            'label' => FieldSynonyms::LABELS[$group] ?? $group,
            'type' => $typeByGroup[$group] ?? 'text',
            // Only the two concepts a submission is nearly meaningless without.
            'required' => in_array($group, [FieldSynonyms::NAME, FieldSynonyms::EMAIL], true),
            'pii' => in_array($group, $piiGroups, true),
        ];
    }

    return $fields;
}

/**
 * Run the heuristic against the endpoint's current target.
 *
 * @param array<string, mixed> $endpoint
 * @param array<string, mixed>|null $fields
 * @return array<string, mixed>
 */
function buildSuggestions(
    array $endpoint,
    ?array $fields,
    TargetCatalogService $catalog,
    MappingRuleRepository $rulesRepo,
    ?string $eventType
): array {
    $empty = ['suggestions' => [], 'unmatched_sources' => [], 'unmatched_targets' => []];

    $targetKind = (string) ($endpoint['target_kind'] ?? '');
    $targetKey = (string) ($endpoint['target_key'] ?? '');
    if ($targetKind === '' || $targetKey === '' || $fields === null) {
        return $empty;
    }

    $target = $catalog->findTarget($targetKind, $targetKey);
    if ($target === null) {
        return $empty;
    }

    $endpointKey = (string) $endpoint['endpoint_key'];

    return (new HeuristicMapper())->suggest(
        (array) ($fields['fields'] ?? []),
        (array) ($target['fields'] ?? []),
        // Both the endpoint's own approved rules and transferable ones from other
        // endpoints, so a decision made once is reusable everywhere.
        $rulesRepo->learnedFor($endpointKey, $eventType),
        $endpointKey
    );
}
