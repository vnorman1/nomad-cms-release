<?php
/**
 * NOMAD CMS - Admin API - Form Definitions
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * ENDPOINTS
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *   GET    /api/admin/forms                          list (with submission stats)
 *   GET    /api/admin/forms?slug=X                   single definition
 *   GET    /api/admin/forms?slug=X&action=encryption-status
 *                                                    pending migration work
 *   GET    /api/admin/forms?slug=X&action=retention-preview
 *                                                    how many rows a sweep would delete
 *   POST   /api/admin/forms                          create
 *   POST   /api/admin/forms?action=encrypt&slug=X    enable encryption + migrate
 *   POST   /api/admin/forms?action=decrypt&slug=X    disable encryption + migrate
 *   POST   /api/admin/forms?action=reindex&slug=X    rebuild blind index
 *   POST   /api/admin/forms?action=retention-sweep   run retention now
 *   PUT    /api/admin/forms                          update (body carries slug)
 *   DELETE /api/admin/forms?slug=X                   delete form AND its submissions
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * PERMISSIONS
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *   read/list       forms:read:*        (forms:list:* also accepted)
 *   create          forms:create:*
 *   update          forms:update:*
 *   delete          forms:delete:*
 *   enable crypto   forms:update:*
 *   disable crypto  forms:update:* AND forms:decrypt:*
 *
 * Disabling encryption turns personal data back into readable plaintext on
 * disk, which is exactly what forms:decrypt:* governs - so it needs both.
 *
 * NOTE: `decrypt` is deliberately NOT part of RBACService::MANAGE_COVERS /
 * ADMIN_COVERS, so a role with forms:manage:* can administer forms but cannot
 * expose personal data. Only an explicit forms:decrypt:*, forms:*:* or *:*:*
 * grants it.
 *
 * @package NomadCMS
 */

declare(strict_types=1);

require_once __DIR__ . '/../../bootstrap.php';

use NomadCMS\Middleware\AuthMiddleware;
use NomadCMS\Middleware\CSRFMiddleware;
use NomadCMS\Middleware\RateLimitMiddleware;
use NomadCMS\Security\InputSanitizer;
use NomadCMS\Services\Forms\CaptchaConfigStore;
use NomadCMS\Services\Forms\CaptchaProviderRegistry;
use NomadCMS\Services\Forms\FormAuditLog;
use NomadCMS\Services\Forms\FormCrypto;
use NomadCMS\Services\Forms\FormCryptoException;
use NomadCMS\Services\Forms\FormEncryptionMigrator;
use NomadCMS\Services\Forms\FormNotFoundException;
use NomadCMS\Services\Forms\FormRetentionService;
use NomadCMS\Services\Forms\FormService;
use NomadCMS\Services\Forms\FormSubmissionService;
use NomadCMS\Services\Forms\FormValidationException;

handlePreflight();
header('Content-Type: application/json; charset=utf-8');

/**
 * @param array<string, mixed> $payload
 */
function formsAdminJson(int $status, array $payload): never
{
    http_response_code($status);
    echo json_encode($payload, JSON_UNESCAPED_UNICODE);
    exit;
}

/**
 * Read a JSON request body.
 *
 * @return array<string, mixed>
 */
function formsAdminBody(): array
{
    $raw = file_get_contents('php://input');
    $decoded = json_decode($raw === false ? '' : $raw, true);

    return is_array($decoded) ? $decoded : [];
}

/**
 * Masked admin captcha state for one form, AUGMENTED with the registry fields
 * (script_url/widget_class/token_field) the frontend's embed code generator
 * needs to build working markup without hardcoding any provider URL.
 *
 * Still never carries a secret - it is built on top of
 * CaptchaConfigStore::maskedFormConfig(), which has none to give.
 *
 * @return array<string, mixed>
 */
function formsAdminCaptchaProjection(string $slug): array
{
    $masked = CaptchaConfigStore::maskedFormConfig($slug);
    $provider = $masked['provider'] ?? 'none';

    if ($provider === 'none' || !in_array($provider, CaptchaProviderRegistry::PROVIDERS, true)) {
        return $masked;
    }

    return array_merge($masked, [
        'script_url' => CaptchaProviderRegistry::scriptUrl($provider, $masked['site_key'] ?? null),
        'widget_class' => CaptchaProviderRegistry::widgetClass($provider),
        'token_field' => CaptchaProviderRegistry::tokenField($provider),
    ]);
}

try {
    $user = AuthMiddleware::requireAuth();
    RateLimitMiddleware::check('admin-forms', 120, 60);

    $method = strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET');
    $action = isset($_GET['action']) ? (string) $_GET['action'] : null;
    $slugParam = isset($_GET['slug']) ? InputSanitizer::slug((string) $_GET['slug'], 64) : null;

    // Whether this caller may see decrypted personal data anywhere in this
    // request. Resolved once, passed down explicitly - never inferred deeper in
    // the stack, so the decision is auditable in one place.
    $canDecrypt = AuthMiddleware::hasPermission('forms:decrypt:*');

    // =========================================================================
    // GET
    // =========================================================================
    if ($method === 'GET') {
        AuthMiddleware::requireAnyPermission(['forms:read:*', 'forms:list:*']);

        if ($action === 'encryption-status') {
            if ($slugParam === null) {
                formsAdminJson(400, ['success' => false, 'error' => 'Hiányzó slug paraméter.']);
            }
            formsAdminJson(200, [
                'success' => true,
                'status' => FormEncryptionMigrator::status($slugParam),
            ]);
        }

        if ($action === 'retention-preview') {
            if ($slugParam === null) {
                formsAdminJson(400, ['success' => false, 'error' => 'Hiányzó slug paraméter.']);
            }
            formsAdminJson(200, [
                'success' => true,
                'retention' => FormRetentionService::preview($slugParam),
            ]);
        }

        if ($slugParam !== null) {
            $form = FormService::requireBySlug($slugParam);
            $form['captcha'] = formsAdminCaptchaProjection($slugParam);

            formsAdminJson(200, [
                'success' => true,
                'form' => $form,
                'stats' => FormSubmissionService::statusCounts($slugParam),
                'can_decrypt' => $canDecrypt,
            ]);
        }

        // Every form gets its own masked captcha projection attached - never
        // the plaintext secret, same rule as GET /admin/form-captcha - so the
        // list view can show a "Biztonság: Turnstile" badge without a second
        // round trip per row.
        $forms = FormService::listAll();
        foreach ($forms as &$listedForm) {
            $listedForm['captcha'] = formsAdminCaptchaProjection((string) ($listedForm['data']['slug'] ?? ''));
        }
        unset($listedForm);

        formsAdminJson(200, [
            'success' => true,
            'forms' => $forms,
            'can_decrypt' => $canDecrypt,
            // Surfaced so the builder can explain WHY the encryption toggle is
            // disabled instead of just failing on save.
            'encryption_available' => FormCrypto::isAvailable(),
            'blind_index_available' => FormCrypto::isBlindIndexAvailable(),
        ]);
    }

    // =========================================================================
    // MUTATIONS - CSRF for every write, like every other admin endpoint
    // =========================================================================
    CSRFMiddleware::validateForSession();

    if ($method === 'POST') {
        // ── Encryption switch ────────────────────────────────────────────────
        if ($action === 'encrypt' || $action === 'decrypt') {
            AuthMiddleware::requirePermission('forms:update:*');

            $body = formsAdminBody();
            $slug = $slugParam ?? InputSanitizer::slug((string) ($body['slug'] ?? ''), 64);
            if ($slug === null) {
                formsAdminJson(400, ['success' => false, 'error' => 'Hiányzó slug paraméter.']);
            }

            $batch = isset($body['batch_size']) && is_numeric($body['batch_size'])
                ? (int) $body['batch_size']
                : FormEncryptionMigrator::DEFAULT_BATCH;

            if ($action === 'decrypt') {
                // Turning encryption OFF writes personal data back to disk in
                // the clear - that is precisely the decrypt capability.
                AuthMiddleware::requirePermission('forms:decrypt:*');
                $summary = FormEncryptionMigrator::disable($slug, $batch);
                FormAuditLog::encryptionChanged($user, $slug, false, $summary);
            } else {
                $summary = FormEncryptionMigrator::enable($slug, $batch);
                FormAuditLog::encryptionChanged($user, $slug, true, $summary);
            }

            formsAdminJson(200, ['success' => true, 'migration' => $summary]);
        }

        // ── Blind index rebuild ──────────────────────────────────────────────
        if ($action === 'reindex') {
            AuthMiddleware::requirePermission('forms:update:*');

            $body = formsAdminBody();
            $slug = $slugParam ?? InputSanitizer::slug((string) ($body['slug'] ?? ''), 64);
            if ($slug === null) {
                formsAdminJson(400, ['success' => false, 'error' => 'Hiányzó slug paraméter.']);
            }

            $summary = FormEncryptionMigrator::reindex($slug);
            FormAuditLog::reindex($user, $slug, $summary);

            formsAdminJson(200, ['success' => true, 'reindex' => $summary]);
        }

        // ── Manual retention sweep ───────────────────────────────────────────
        if ($action === 'retention-sweep') {
            AuthMiddleware::requirePermission('forms:delete:*');

            $body = formsAdminBody();
            $max = isset($body['max_per_form']) && is_numeric($body['max_per_form'])
                ? (int) $body['max_per_form']
                : FormRetentionService::DEFAULT_MAX_PER_RUN;

            formsAdminJson(200, [
                'success' => true,
                'retention' => FormRetentionService::sweep($max),
            ]);
        }

        // ── Create ───────────────────────────────────────────────────────────
        AuthMiddleware::requirePermission('forms:create:*');

        $body = formsAdminBody();
        // requireAuth() returns the JWT payload as an object; the uuid drives the
        // owner_uuid column (recorded for provenance - the module does not use
        // 'own' scope filtering, see docs/forms.md).
        $ownerUuid = $user->uuid ?? null;
        $form = FormService::create($body, is_string($ownerUuid) ? $ownerUuid : null);

        formsAdminJson(201, ['success' => true, 'form' => $form]);
    }

    if ($method === 'PUT') {
        AuthMiddleware::requirePermission('forms:update:*');

        $body = formsAdminBody();
        $slug = $slugParam ?? InputSanitizer::slug((string) ($body['slug'] ?? ''), 64);
        if ($slug === null) {
            formsAdminJson(400, ['success' => false, 'error' => 'Hiányzó slug paraméter.']);
        }

        // `slug` in the body identifies the form; `new_slug` renames it. Without
        // this split, a PUT could never rename a form without ambiguity.
        $payload = $body;
        if (array_key_exists('new_slug', $body)) {
            $payload['slug'] = $body['new_slug'];
        } else {
            unset($payload['slug']);
        }

        $form = FormService::update($slug, $payload);

        formsAdminJson(200, ['success' => true, 'form' => $form]);
    }

    if ($method === 'DELETE') {
        AuthMiddleware::requirePermission('forms:delete:*');

        $slug = $slugParam;
        if ($slug === null) {
            $body = formsAdminBody();
            $slug = InputSanitizer::slug((string) ($body['slug'] ?? ''), 64);
        }
        if ($slug === null) {
            formsAdminJson(400, ['success' => false, 'error' => 'Hiányzó slug paraméter.']);
        }

        $result = FormService::delete($slug);
        FormAuditLog::formDeleted($user, $slug, $result['submissions_deleted']);

        formsAdminJson(200, [
            'success' => true,
            'deleted' => $result['deleted'],
            'submissions_deleted' => $result['submissions_deleted'],
        ]);
    }

    header('Allow: GET, POST, PUT, DELETE, OPTIONS');
    formsAdminJson(405, ['success' => false, 'error' => 'Nem támogatott HTTP metódus.']);
} catch (FormValidationException $e) {
    formsAdminJson(400, [
        'success' => false,
        'error' => $e->getMessage(),
        'code' => 'VALIDATION_FAILED',
        'errors' => $e->getErrors(),
    ]);
} catch (FormNotFoundException $e) {
    formsAdminJson(404, ['success' => false, 'error' => $e->getMessage(), 'code' => 'FORM_NOT_FOUND']);
} catch (FormCryptoException $e) {
    formsAdminJson(503, ['success' => false, 'error' => $e->getMessage(), 'code' => 'ENCRYPTION_UNAVAILABLE']);
} catch (Throwable $e) {
    error_log('[Forms][admin/forms] ' . $e->getMessage());
    $debug = ($_ENV['APP_DEBUG'] ?? 'false') === 'true';
    formsAdminJson(500, [
        'success' => false,
        'error' => $debug ? $e->getMessage() : 'Váratlan szerverhiba.',
        'code' => 'INTERNAL_ERROR',
    ]);
}
