<?php
/**
 * Admin API - User Invitations (Magic Links)
 *
 * Lets an admin hand out a one-time onboarding link for an EXISTING user -
 * effectively an admin-driven password reset, without the admin ever learning
 * (or setting) the user's password.
 *
 * GET    ?user_id=N   -> current invitation status (none | pending | expired)
 * POST   {user_id, invite_ttl?, send_email?, frontend_origin?} -> generate/
 *                        regenerate a link, returns the raw token EXACTLY ONCE
 *                        (it is never stored in plaintext). When send_email is
 *                        truthy, also e-mails the link to the user via the
 *                        verified default SMTP profile (see
 *                        userInvitationSendEmail()). frontend_origin (the
 *                        caller's own window.location.origin) is used to build
 *                        that e-mail's link when no ADMIN_URL/SITE_URL is
 *                        configured - no extra setup required.
 * DELETE ?user_id=N   -> revoke the active invitation
 *
 * IMPORTANT SECURITY PROPERTY:
 * Generating a link does NOT touch the target user's record. Their existing
 * password keeps working, and they are not pushed into onboarding, until the
 * link is actually redeemed (see auth/magic-login.php). That way a generated
 * link that never gets used cannot lock anybody out.
 */

require_once __DIR__ . '/../../bootstrap.php';

use NomadCMS\Auth\MagicLinkService;
use NomadCMS\Database\UserRepository;
use NomadCMS\Middleware\AuthMiddleware;
use NomadCMS\Middleware\CSRFMiddleware;
use NomadCMS\Middleware\RateLimitMiddleware;
use NomadCMS\Security\InputSanitizer;
use NomadCMS\Security\WebhookService;
use NomadCMS\Services\Mail\MailProfileStore;
use NomadCMS\Services\Mail\MailService;
use NomadCMS\Services\Mail\MailTemplates;
use NomadCMS\Services\Mail\MailUrlResolver;

/**
 * E-mail the just-(re)generated magic link to its owner.
 *
 * Picks the template by the link's purpose: a brand-new account with no
 * password gets MailTemplates::invitation() (there is no "current password"
 * to fall back to, so the copy must not imply one), while an existing user
 * gets the same passwordReset() template and layout as the self-service flow
 * (auth/ar-request.php) - that user should not be able to tell which path
 * produced the message they received.
 *
 * Hard-gated on MailProfileStore::isSendable(): the admin UI is expected to
 * hide/disable the "send e-mail" control when there is no verified default
 * profile, but this function re-checks rather than trusting the caller, since
 * it is reachable by anyone holding users:update:* - not necessarily the same
 * admin who configured mail.
 *
 * @param array<string, mixed> $target The invited user's row (needs 'email',
 *                                      'first_name', 'last_name')
 * @param array{token: string, expires_at: string, purpose: string} $link
 * @param string|null $frontendOrigin The calling browser's own origin (e.g.
 *                     window.location.origin), used to build the link when no
 *                     ADMIN_URL/SITE_URL is configured - see
 *                     MailUrlResolver::resolveFrontendOrigin().
 * @return array{0: bool, 1: string|null, 2: string|null} [sent, error_code, error_message]
 */
function userInvitationSendEmail(array $target, array $link, ?string $frontendOrigin): array
{
    if (!MailProfileStore::isSendable()) {
        return [false, 'MAIL_NOT_SENDABLE', 'A levelezés jelenleg nincs beállítva vagy nincs hitelesítve.'];
    }

    $origin = MailUrlResolver::resolveFrontendOrigin($frontendOrigin);
    if ($origin === null) {
        return [
            false,
            'NO_FRONTEND_URL',
            'Nem sikerült megállapítani az admin felület címét a hivatkozáshoz. Próbáld újra.',
        ];
    }

    $isInvite = $link['purpose'] === MagicLinkService::PURPOSE_INVITE;
    // /welcome and /reset-password render the same component - the frontend
    // just picks different copy by route - but keeping the link on the route
    // that matches its purpose is what makes that copy correct.
    $linkUrl = $origin . ($isInvite ? '/welcome' : '/reset-password') . '#t=' . rawurlencode($link['token']);

    $expiresTs = strtotime((string) $link['expires_at']);
    $ttlMinutes = $expiresTs !== false ? max(1, (int) ceil(($expiresTs - time()) / 60)) : 60;

    $userName = trim(((string) ($target['first_name'] ?? '')) . ' ' . ((string) ($target['last_name'] ?? '')));
    $template = $isInvite
        ? MailTemplates::invitation($linkUrl, $userName !== '' ? $userName : null, $ttlMinutes)
        : MailTemplates::passwordReset($linkUrl, $userName !== '' ? $userName : null, $ttlMinutes);

    try {
        MailService::send((string) $target['email'], $template['subject'], $template['text'], $template['html']);

        return [true, null, null];
    } catch (\NomadCMS\Services\Mail\MailException $e) {
        // Preserve the classified failure (SMTP_CONNECT_FAILED, AUTH_FAILED,
        // TIMEOUT, ...) instead of collapsing everything into one generic code -
        // MailService::classify() already did the work of figuring out what
        // actually went wrong, so the caller and the admin UI should see it.
        error_log(sprintf(
            '[MagicLink] E-mail küldés sikertelen user #%s: [%s] %s',
            $target['id'] ?? '?',
            $e->getErrorCode(),
            $e->getMessage()
        ));

        return [false, $e->getErrorCode(), $e->getMessage()];
    } catch (\Throwable $e) {
        error_log('[MagicLink] E-mail küldés sikertelen user #' . ($target['id'] ?? '?') . ': ' . $e->getMessage());

        return [false, 'SEND_FAILED', 'Nem sikerült elküldeni az e-mailt.'];
    }
}

header('Content-Type: application/json');

try {
    RateLimitMiddleware::check();

    // Authenticate FIRST so an anonymous caller gets a truthful 401 instead of
    // a misleading CSRF 403 (matches the ordering in admin/users.php).
    // Issuing a credential-recovery link is a user-record mutation in spirit,
    // so it requires the same permission as editing a user.
    $actor = AuthMiddleware::requireAuth();

    // SECURITY: Validate CSRF token for session-based (cookie) requests.
    // Bearer-token requests are inherently CSRF-safe and skip this.
    CSRFMiddleware::validateForSession();

    $method = $_SERVER['REQUEST_METHOD'];

    if (!in_array($method, ['GET', 'POST', 'DELETE'], true)) {
        http_response_code(405);
        echo json_encode(['success' => false, 'error' => 'Method not allowed']);
        exit;
    }

    AuthMiddleware::requirePermission($method === 'GET' ? 'users:read:*' : 'users:update:*');

    $data = [];
    if ($method === 'POST') {
        $data = json_decode(file_get_contents('php://input'), true) ?? [];
    }

    // Resolve the target user id from body (POST) or query string (GET/DELETE)
    $userId = InputSanitizer::positiveInt($data['user_id'] ?? $_GET['user_id'] ?? null);

    if (!$userId) {
        throw new Exception('Valid User ID is required');
    }

    $target = UserRepository::findById($userId);

    if (!$target) {
        http_response_code(404);
        echo json_encode(['success' => false, 'error' => 'User not found']);
        exit;
    }

    if ($method === 'GET') {
        echo json_encode([
            'success' => true,
            'user_id' => $userId,
            'invitation' => MagicLinkService::getStatusForUser($userId),
        ]);
        exit;
    }

    if ($method === 'POST') {
        // Throws on anything outside the 1h / 24h / 7d whitelist
        $ttl = MagicLinkService::normalizeTtl($data['invite_ttl'] ?? null);

        // Own bucket for the e-mail-sending variant: it hands the CMS's own
        // SMTP credentials a "send mail to this user" trigger, same class of
        // risk as admin/mail-settings.php's resend/enable actions.
        if (!empty($data['send_email'])) {
            RateLimitMiddleware::check('admin-magiclink-email', 10, 3600);
        }

        // A brand-new user who never had a password is still an 'invite';
        // anyone with a password gets a 'reset' link.
        $purpose = empty($target['password_hash'])
            ? MagicLinkService::PURPOSE_INVITE
            : MagicLinkService::PURPOSE_RESET;

        $link = MagicLinkService::create(
            $userId,
            $ttl,
            $purpose,
            isset($actor->id) ? (int) $actor->id : null
        );

        // AUDIT: record who generated a credential-recovery link for whom.
        // This is a sensitive action - it must be traceable.
        error_log(sprintf(
            '[MagicLink] %s link generated for user #%d (%s) by %s',
            $purpose,
            $userId,
            $target['email'],
            $actor->email ?? 'unknown'
        ));

        try {
            $webhookService = new WebhookService();
            $webhookService->dispatchEventAsync('user.invited', [
                'user_id' => $target['uuid'],
                'email' => $target['email'],
                'purpose' => $link['purpose'],
                'expires_at' => $link['expires_at'],
                'password_preserved' => !empty($target['password_hash']),
                'invited_by' => $actor->uuid ?? null,
                'timestamp' => date('c'),
            ]);
        } catch (\Exception $e) {
            error_log('Webhook dispatch failed for user.invited: ' . $e->getMessage());
        }

        // Optional: hand the link to the user directly by e-mail instead of
        // (or in addition to) the admin copying it manually. Opt-in via
        // `send_email`, and hard-gated on a verified, sendable SMTP profile -
        // the admin UI is expected to hide/disable the control otherwise, but
        // this endpoint re-checks server-side rather than trusting that.
        $emailSent = false;
        $emailError = null;
        $emailErrorMessage = null;
        if (!empty($data['send_email'])) {
            [$emailSent, $emailError, $emailErrorMessage] = userInvitationSendEmail(
                $target,
                $link,
                isset($data['frontend_origin']) && is_string($data['frontend_origin']) ? $data['frontend_origin'] : null
            );
        }

        echo json_encode([
            'success' => true,
            'message' => 'Magic link generated',
            'user_id' => $userId,
            'invitation' => [
                // Returned ONCE - cannot be retrieved again, only regenerated
                'token' => $link['token'],
                'expires_at' => $link['expires_at'],
                'purpose' => $link['purpose'],
            ],
            // Tells the UI whether the old password is still usable
            'password_preserved' => !empty($target['password_hash']),
            'email_sent' => $emailSent,
            'email_error' => $emailError,
            // Human-readable, actionable Hungarian message for the admin UI -
            // null when email_sent is true or send_email was not requested.
            'email_error_message' => $emailErrorMessage,
        ]);
        exit;
    }

    // DELETE - revoke
    $revoked = MagicLinkService::revokeAllForUser($userId);

    error_log(sprintf(
        '[MagicLink] invitation(s) revoked for user #%d (%s) by %s',
        $userId,
        $target['email'],
        $actor->email ?? 'unknown'
    ));

    echo json_encode([
        'success' => true,
        'message' => $revoked > 0 ? 'Invitation revoked' : 'No active invitation to revoke',
        'revoked' => $revoked,
    ]);

} catch (Exception $e) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
