<?php

/**
 * NOMAD CMS - Notification delivery diagnostics endpoint.
 * Provides bounded masked delivery history and explicitly authorized targeted retries.
 * Successful deliveries cannot be copied through the retry operation.
 */

declare(strict_types=1);

require_once __DIR__ . '/../../bootstrap.php';
handlePreflight();
\NomadCMS\Services\NotificationService\HttpController::dispatch('deliveries');
