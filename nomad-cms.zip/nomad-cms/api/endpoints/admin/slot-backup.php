<?php
/**
 * NOMAD CMS - Slot Backup & Restore Endpoint
 * 
 * Granular slot-level single-JSON export, inspection, and restore.
 * 
 * GET  /api/admin/slot-backup?action=slots            → List all exportable slots
 * GET  /api/admin/slot-backup?action=export&slot=key  → Download slot export JSON
 * POST /api/admin/slot-backup?action=inspect          → Inspect uploaded slot package
 * POST /api/admin/slot-backup?action=import           → Import slot package with options
 */

declare(strict_types=1);

require_once __DIR__ . '/../../bootstrap.php';

use NomadCMS\Services\SlotBackupService;
use NomadCMS\Database\AuthDatabase;
use NomadCMS\Database\UserRepository;
use NomadCMS\Middleware\AuthMiddleware;
use NomadCMS\Middleware\CSRFMiddleware;
use NomadCMS\Security\InputSanitizer;

// CORS Preflight
handlePreflight();

try {
    // 1. Require Authentication
    $currentUser = AuthMiddleware::requireAuth();

    AuthDatabase::getInstance();
    $user = UserRepository::findByUuid($currentUser->uuid);

    if (!$user || (!$user['is_admin'] && !AuthMiddleware::hasPermission('system:manage:*') && !AuthMiddleware::hasPermission('content:read'))) {
        http_response_code(403);
        header('Content-Type: application/json');
        echo json_encode(['success' => false, 'error' => 'Admin or content management permission required']);
        exit;
    }

    $service = new SlotBackupService();
    $method = $_SERVER['REQUEST_METHOD'];
    $action = $_GET['action'] ?? '';

    // =========================================================================
    // GET: List Slots or Export Single Slot
    // =========================================================================
    if ($method === 'GET') {
        if ($action === 'slots') {
            header('Content-Type: application/json');
            $slots = $service->getExportableSlots();
            echo json_encode([
                'success' => true,
                'slots' => $slots,
            ], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
            exit;
        }

        if ($action === 'export') {
            $slotKey = $_GET['slot'] ?? '';
            if (empty($slotKey)) {
                http_response_code(400);
                header('Content-Type: application/json');
                echo json_encode(['success' => false, 'error' => 'Hiányzó slot paraméter']);
                exit;
            }

            $collection = \NomadCMS\Database\CollectionDatabase::isRegistered($slotKey);
            $package = $collection ? null : $service->exportSlot($slotKey);
            $filename = sprintf('slot_%s_%s.json', preg_replace('/[^a-zA-Z0-9_\-]/', '_', $slotKey), date('Y-m-d_His'));

            header('Content-Type: application/json; charset=utf-8');
            header('Content-Disposition: attachment; filename="' . $filename . '"');
            header('Cache-Control: no-cache, no-store, must-revalidate');
            header('Pragma: no-cache');
            header('Expires: 0');

            if ($collection) $service->streamCollectionExport($slotKey, fopen('php://output','wb'));
            else echo json_encode($package, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
            exit;
        }

        http_response_code(400);
        header('Content-Type: application/json');
        echo json_encode(['success' => false, 'error' => 'Érvénytelen GET akció. Támogatott akciók: slots, export']);
        exit;
    }

    // =========================================================================
    // POST: Inspect or Import Package
    // =========================================================================
    if ($method === 'POST') {
        CSRFMiddleware::validateForSession();

        // Check write permission for import
        if ($action === 'import' && !$user['is_admin'] && !AuthMiddleware::hasPermission('system:manage:*') && !AuthMiddleware::hasPermission('content:write')) {
            http_response_code(403);
            header('Content-Type: application/json');
            echo json_encode(['success' => false, 'error' => 'Nincs jogosultságod tartalom importálására']);
            exit;
        }

        // Parse package from either multipart file upload or JSON payload
        $package = null;
        $options = [];
        $stream = null;

        if (isset($_FILES['package_file']) && $_FILES['package_file']['error'] === UPLOAD_ERR_OK) {
            try {
                $stream = new \NomadCMS\Services\SlotPackageStream($_FILES['package_file']['tmp_name']);
            } catch (InvalidArgumentException $e) {
                if ($e->getMessage() !== 'Not a collection backup' && !str_contains($e->getMessage(),'expected [')) throw $e;
                $content = file_get_contents($_FILES['package_file']['tmp_name']);
                $package = $content !== false ? json_decode($content,true) : null;
            }
            $options = [
                'target_slot' => $_POST['target_slot'] ?? null,
                'mode' => $_POST['mode'] ?? 'overwrite',
                'sync_schema' => filter_var($_POST['sync_schema'] ?? false, FILTER_VALIDATE_BOOLEAN),
                'overwrite_schema' => filter_var($_POST['overwrite_schema'] ?? false, FILTER_VALIDATE_BOOLEAN),
            ];
        } else {
            $input = json_decode(file_get_contents('php://input'), true);
            if (is_array($input)) {
                $package = $input['package'] ?? $input;
                $options = [
                    'target_slot' => $input['target_slot'] ?? null,
                    'mode' => $input['mode'] ?? 'overwrite',
                    'sync_schema' => !empty($input['sync_schema']),
                    'overwrite_schema' => !empty($input['overwrite_schema']),
                ];
            }
        }

        if ($stream === null && !is_array($package)) {
            http_response_code(400);
            header('Content-Type: application/json');
            echo json_encode(['success' => false, 'error' => 'Érvénytelen vagy hiányzó JSON csomag']);
            exit;
        }

        header('Content-Type: application/json');

        if ($action === 'inspect') {
            $report = $stream ? $service->inspectCollectionFile($stream,$options['target_slot']??null) : $service->inspectSlotPackage($package, $options['target_slot'] ?? null);
            http_response_code($report['valid'] ? 200 : 400);
            echo json_encode([
                'success' => $report['valid'],
                'report' => $report,
            ], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
            exit;
        }

        if ($action === 'import') {
            $result = $stream ? $service->importCollectionFile($stream,$options,$currentUser->uuid) : $service->importSlot($package, $options, $currentUser->uuid);
            http_response_code(200);
            echo json_encode($result, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
            exit;
        }

        http_response_code(400);
        echo json_encode(['success' => false, 'error' => 'Érvénytelen POST akció. Támogatott akciók: inspect, import']);
        exit;
    }

    // Method not allowed
    http_response_code(405);
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'error' => 'Method not allowed']);

} catch (InvalidArgumentException $e) {
    http_response_code(400);
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
} catch (RuntimeException $e) {
    http_response_code(500);
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
} catch (\Throwable $e) {
    http_response_code(500);
    header('Content-Type: application/json');
    echo json_encode([
        'success' => false,
        'error' => ($_ENV['APP_DEBUG'] ?? 'false') === 'true' ? $e->getMessage() : 'Belső szerverhiba történt',
    ]);
}
