<?php
/**
 * NOMAD CMS - Admin API - Webhook Event Inbox
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * ENDPOINTS
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *   GET  /api/admin/webhook-events?endpoint=X[&status=&event_type=&page=&pageSize=]
 *   GET  ...&action=stats             per-status counts + replayable count
 *   GET  ...&id=N                     ONE event including its raw payload
 *
 *   POST ...&action=replay            { event_ids?: [], statuses?: [], limit?: n }
 *   POST ...&action=retention         run the retention sweep now
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * WHY THE LIST DOES NOT INCLUDE PAYLOADS
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * A raw webhook payload is full of personal data. Returning 50 of them so a list
 * view can show a status badge would put a page of PII into the browser, the
 * browser's history and any HAR file a user attaches to a support ticket - to
 * render information that does not need it.
 *
 * So the list returns metadata only, and the payload is fetched deliberately for
 * ONE event (`&id=N`) when a human explicitly asks to inspect it. That request
 * additionally requires webhooks:manage:*, because reading raw personal data is a
 * bigger privilege than seeing that an event arrived - the same separation the
 * Forms module makes between reading an inbox and decrypting a submission.
 *
 * @package NomadCMS
 */

declare(strict_types=1);

require_once __DIR__ . '/../../bootstrap.php';

use NomadCMS\Middleware\AuthMiddleware;
use NomadCMS\Middleware\CSRFMiddleware;
use NomadCMS\Security\WebhookService;
use NomadCMS\Webhooks\Mapping\ReplayService;
use NomadCMS\Webhooks\Mapping\WebhookEventRetentionService;
use NomadCMS\Webhooks\Mapping\WebhookEventsSchema;

header('Content-Type: application/json; charset=utf-8');

/**
 * @param array<string, mixed> $payload
 */
function eventsJson(int $status, array $payload): never
{
    http_response_code($status);
    echo json_encode($payload, JSON_UNESCAPED_UNICODE);
    exit;
}

try {
    $user = AuthMiddleware::requireAuth();
    $method = $_SERVER['REQUEST_METHOD'];

    switch ($method) {
        case 'GET':
            AuthMiddleware::requirePermission('webhooks:read:*');
            break;
        case 'POST':
            AuthMiddleware::requirePermission('webhooks:update:*');
            CSRFMiddleware::validateForSession();
            break;
        default:
            eventsJson(405, ['success' => false, 'error' => 'A metódus nem engedélyezett.']);
    }

    $endpointKey = trim((string) ($_GET['endpoint'] ?? ''));
    if ($endpointKey === '' || !preg_match('/^[a-z0-9-]{3,64}$/', $endpointKey)) {
        eventsJson(400, ['success' => false, 'error' => 'Hiányzó vagy érvénytelen végpont-azonosító.']);
    }

    $webhookService = new WebhookService();
    $endpoint = $webhookService->getEndpointByKey($endpointKey);
    if ($endpoint === null) {
        eventsJson(404, ['success' => false, 'error' => 'A végpont nem található.']);
    }
    if ((int) $endpoint['user_id'] !== (int) $user->id) {
        AuthMiddleware::requirePermission('webhooks:manage:*');
    }

    WebhookEventsSchema::ensureTables();
    $db = WebhookEventsSchema::db();
    $table = WebhookEventsSchema::TABLE_EVENTS;
    $action = (string) ($_GET['action'] ?? 'list');

    // =========================================================================
    // GET
    // =========================================================================
    if ($method === 'GET') {
        if ($action === 'stats') {
            $stmt = $db->prepare("
                SELECT status, COUNT(*) AS c FROM {$table}
                WHERE endpoint_slug = ? GROUP BY status
            ");
            $stmt->execute([$endpointKey]);

            $counts = [];
            foreach (WebhookEventsSchema::STATUSES as $status) {
                $counts[$status] = 0;
            }
            foreach ($stmt->fetchAll() as $row) {
                $counts[(string) $row['status']] = (int) $row['c'];
            }

            eventsJson(200, [
                'success' => true,
                'counts' => $counts,
                'total' => array_sum($counts),
                'replayable' => (new ReplayService())->replayableCount($endpointKey),
                'retention' => WebhookEventRetentionService::preview(),
            ]);
        }

        // Single event WITH payload - the deliberate inspection path.
        $eventId = isset($_GET['id']) ? (int) $_GET['id'] : 0;
        if ($eventId > 0) {
            // Reading raw personal data is a bigger privilege than seeing that an
            // event arrived, so it is gated separately.
            AuthMiddleware::requirePermission('webhooks:manage:*');

            $stmt = $db->prepare("SELECT * FROM {$table} WHERE id = ? AND endpoint_slug = ?");
            $stmt->execute([$eventId, $endpointKey]);
            $row = $stmt->fetch();

            if ($row === false) {
                eventsJson(404, ['success' => false, 'error' => 'Az esemény nem található.']);
            }

            $event = eventMeta($row);
            $event['payload'] = json_decode((string) $row['payload'], true);
            $event['headers'] = json_decode((string) ($row['headers'] ?? '{}'), true);

            eventsJson(200, ['success' => true, 'event' => $event]);
        }

        // List - metadata only.
        $page = max(1, (int) ($_GET['page'] ?? 1));
        $pageSize = max(1, min(100, (int) ($_GET['pageSize'] ?? 25)));
        $offset = ($page - 1) * $pageSize;

        $where = 'endpoint_slug = ?';
        $params = [$endpointKey];

        $status = (string) ($_GET['status'] ?? '');
        if ($status !== '' && in_array($status, WebhookEventsSchema::STATUSES, true)) {
            $where .= ' AND status = ?';
            $params[] = $status;
        }

        $eventType = (string) ($_GET['event_type'] ?? '');
        if ($eventType !== '') {
            $where .= ' AND event_type = ?';
            $params[] = substr($eventType, 0, 128);
        }

        $countStmt = $db->prepare("SELECT COUNT(*) FROM {$table} WHERE {$where}");
        $countStmt->execute($params);
        $total = (int) $countStmt->fetchColumn();

        // Deliberately NOT selecting `payload`.
        $listStmt = $db->prepare("
            SELECT id, endpoint_slug, event_type, status, signature_state, idempotency_key,
                   payload_bytes, mapped_at, mapped_target, mapped_record_id, error, created_at
            FROM {$table}
            WHERE {$where}
            ORDER BY created_at DESC, id DESC
            LIMIT ? OFFSET ?
        ");
        $listStmt->execute(array_merge($params, [$pageSize, $offset]));

        eventsJson(200, [
            'success' => true,
            'events' => array_map('eventMeta', $listStmt->fetchAll()),
            'total' => $total,
            'page' => $page,
            'pageSize' => $pageSize,
            'totalPages' => (int) ceil($total / $pageSize),
        ]);
    }

    // =========================================================================
    // POST
    // =========================================================================
    $body = json_decode((string) file_get_contents('php://input'), true);
    if (!is_array($body)) {
        $body = [];
    }

    if ($action === 'replay') {
        $options = [];

        if (isset($body['event_ids']) && is_array($body['event_ids'])) {
            $options['event_ids'] = array_map('intval', $body['event_ids']);
        }
        if (isset($body['statuses']) && is_array($body['statuses'])) {
            $options['statuses'] = array_map('strval', $body['statuses']);
        }
        if (isset($body['event_type']) && is_string($body['event_type'])) {
            $options['event_type'] = $body['event_type'];
        }
        if (isset($body['limit'])) {
            $options['limit'] = (int) $body['limit'];
        }

        $result = (new ReplayService())->replay($endpointKey, $options);

        eventsJson(200, ['success' => true, 'replay' => $result]);
    }

    if ($action === 'retention') {
        $max = isset($body['max'])
            ? (int) $body['max']
            : WebhookEventRetentionService::DEFAULT_MAX_PER_RUN;

        eventsJson(200, [
            'success' => true,
            'retention' => WebhookEventRetentionService::sweep($max),
        ]);
    }

    eventsJson(400, ['success' => false, 'error' => 'Ismeretlen művelet: ' . $action]);
} catch (\Throwable $e) {
    error_log('[WebhookMapping] Event inbox error: ' . $e->getMessage());

    if (!headers_sent()) {
        http_response_code(500);
        echo json_encode(['success' => false, 'error' => 'Váratlan hiba történt.'], JSON_UNESCAPED_UNICODE);
    }
}

/**
 * Non-sensitive event metadata.
 *
 * @param array<string, mixed> $row
 * @return array<string, mixed>
 */
function eventMeta(array $row): array
{
    return [
        'id' => (int) $row['id'],
        'event_type' => $row['event_type'] !== null ? (string) $row['event_type'] : null,
        'status' => (string) $row['status'],
        'signature_state' => $row['signature_state'] !== null ? (string) $row['signature_state'] : null,
        'has_idempotency_key' => !empty($row['idempotency_key']),
        'payload_bytes' => $row['payload_bytes'] !== null ? (int) $row['payload_bytes'] : null,
        'mapped_at' => $row['mapped_at'] ?? null,
        'mapped_target' => $row['mapped_target'] ?? null,
        'mapped_record_id' => $row['mapped_record_id'] ?? null,
        'error' => $row['error'] ?? null,
        'created_at' => (string) $row['created_at'],
    ];
}
