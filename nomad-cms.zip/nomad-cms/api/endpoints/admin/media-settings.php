<?php
/**
 * NOMAD CMS - Media Settings Endpoint
 * 
 * Admin-only endpoint to manage media processing settings.
 * 
 * GET  /api/endpoints/admin/media-settings.php - Get current settings
 * POST /api/endpoints/admin/media-settings.php - Update settings
 *      Body: { "media.webpConversionEnabled": "true", ... }
 * 
 * Response:
 * {
 *   "success": true,
 *   "settings": { "media.webpConversionEnabled": "true", ... }
 * }
 */

declare(strict_types=1);

require_once __DIR__ . '/../../bootstrap.php';

use NomadCMS\Middleware\AuthMiddleware;
use NomadCMS\Middleware\CSRFMiddleware;
use NomadCMS\Services\MediaSettingsService;

// Handle CORS preflight
handlePreflight();

header('Content-Type: application/json');

// Authenticate. Per-method RBAC:
//   GET  -> system:read:*   (viewing settings)
//   POST -> system:manage:* (mutating settings)
// A "system:manage:*" (or "system:admin:*") permission covers reads too via
// the manage/admin super-action hierarchy.
try {
    CSRFMiddleware::validateForSession();
    AuthMiddleware::requireAuth();
    if ($_SERVER['REQUEST_METHOD'] === 'GET') {
        AuthMiddleware::requirePermission('system:read:*');
    } else {
        AuthMiddleware::requirePermission('system:manage:*');
    }
} catch (\Exception $e) {
    http_response_code(401);
    echo json_encode(['success' => false, 'error' => 'Unauthorized']);
    exit;
}

$method = $_SERVER['REQUEST_METHOD'];

try {
    $mediaSettings = MediaSettingsService::getInstance();
    
    switch ($method) {
        case 'GET':
            // Return current settings
            $settings = $mediaSettings->getAllSettings();
            
            echo json_encode([
                'success' => true,
                'settings' => $settings,
            ], JSON_UNESCAPED_UNICODE);
            break;
            
        case 'POST':
            // Update settings
            $body = json_decode(file_get_contents('php://input'), true);
            
            if (!is_array($body)) {
                http_response_code(400);
                echo json_encode(['success' => false, 'error' => 'Invalid request body']);
                exit;
            }
            
            // Allowed setting keys
            $allowedKeys = [
                'media.webpConversionEnabled',
                'media.webpQuality',
            ];
            
            $updated = [];
            
            foreach ($body as $key => $value) {
                if (!in_array($key, $allowedKeys, true)) {
                    continue; // Skip unknown keys
                }
                
                // Validate values
                if ($key === 'media.webpConversionEnabled') {
                    $value = ($value === 'true' || $value === true) ? 'true' : 'false';
                } elseif ($key === 'media.webpQuality') {
                    $valInt = (int) $value;
                    $valInt = max(0, min(100, $valInt)); // clamped between 0 and 100
                    $value = (string) $valInt;
                }
                
                $mediaSettings->setSetting($key, (string) $value);
                $updated[$key] = $value;
            }
            
            echo json_encode([
                'success' => true,
                'updated' => $updated,
                'settings' => $mediaSettings->getAllSettings(),
            ], JSON_UNESCAPED_UNICODE);
            break;
            
        default:
            http_response_code(405);
            echo json_encode(['success' => false, 'error' => 'Method not allowed']);
    }
    
} catch (\Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => ($_ENV['APP_DEBUG'] ?? 'false') === 'true' 
            ? $e->getMessage() 
            : 'Internal server error',
    ]);
}
