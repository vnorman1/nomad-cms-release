<?php
/**
 * Admin API - Panic Mode Management 🚨
 * 
 * "DON'T PANIC" - Friendly reminder from your admin panel
 * 
 * GET: Check panic mode status
 * POST: Enable/Disable panic mode (toggle)
 * 
 * Only accessible by admin users.
 * When enabled, the entire system goes read-only.
 */

declare(strict_types=1);

require_once __DIR__ . '/../../bootstrap.php';

use NomadCMS\Middleware\AuthMiddleware;
use NomadCMS\Middleware\CSRFMiddleware;
use NomadCMS\Middleware\PanicModeMiddleware;
use NomadCMS\Security\PanicModeException;
use NomadCMS\Security\PanicModeService;

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

try {
    // Authenticate and require the current, authoritative recovery permission.
    $user = AuthMiddleware::requireAuth();
    AuthMiddleware::requirePermission('system:admin:*');
    PanicModeService::requireRecoveryAdmin((array) $user);
    $method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

    if ($method === 'GET') {
        echo json_encode(['success' => true, 'panic_mode' => PanicModeService::getStatus()], JSON_THROW_ON_ERROR);
        exit;
    }
    if ($method !== 'POST') {
        header('Allow: GET, POST');
        throw new PanicModeException('METHOD_NOT_ALLOWED', 'Use GET for status or POST for an explicit action.', 405);
    }
    if (($user->source ?? '') === 'api_key') {
        throw new PanicModeException('PANIC_RECOVERY_FORBIDDEN', 'Panic control requires a personal administrator session.', 403);
    }
    // JWT requests are header-authenticated; cookie sessions retain CSRF checks.
    CSRFMiddleware::validateForSession();
    $raw = file_get_contents('php://input', false, null, 0, 4097);
    if ($raw === false || strlen($raw) > 4096) {
        throw new PanicModeException('INVALID_PANIC_INPUT', 'Invalid panic request body.', 400);
    }
    try {
        $data = json_decode($raw, true, 16, JSON_THROW_ON_ERROR);
    } catch (JsonException) {
        throw new PanicModeException('INVALID_PANIC_INPUT', 'A valid JSON object is required.', 400);
    }
    if (!is_array($data) || array_is_list($data) || !isset($data['action'])
        || !is_string($data['action']) || !in_array($data['action'], ['enable', 'disable', 'toggle'], true)) {
        throw new PanicModeException('INVALID_PANIC_INPUT', 'Specify action: enable or disable. Legacy toggle requires a revision.', 400);
    }
    $reason = $data['reason'] ?? null;
    if ($reason !== null && (!is_string($reason) || !preg_match('//u', $reason)
        || preg_match_all('/./us', $reason) > 500)) {
        throw new PanicModeException('INVALID_PANIC_INPUT', 'Reason must contain at most 500 Unicode characters.', 400);
    }
    $reason = $reason !== null ? trim($reason) : null;
    $revision = $data['expected_revision'] ?? null;
    if ($revision !== null && (!is_int($revision) || $revision < 0)) {
        throw new PanicModeException('INVALID_PANIC_INPUT', 'expected_revision must be a non-negative integer.', 400);
    }
    $action = $data['action'];
    $status = PanicModeService::getStatus();
    if ($action !== 'enable' && $revision === null) {
        throw new PanicModeException('INVALID_PANIC_INPUT', 'Unlock and toggle require expected_revision.', 400);
    }
    if ($action === 'toggle') {
        if ($revision !== $status['revision']) {
            throw new PanicModeException('PANIC_REVISION_CONFLICT', 'Panic status changed. Refresh it first.', 409);
        }
        $action = $status['enabled'] ? 'disable' : 'enable';
    }
    if ($action === 'disable' && $status['enabled'] && empty($user->panic_recovery)) {
        throw new PanicModeException('PANIC_REAUTH_REQUIRED', 'Sign in again to unlock the system.', 403);
    }
    $result = $action === 'enable'
        ? PanicModeService::enable((int) $user->id, $reason === '' ? null : $reason, $data['action'] === 'toggle' ? $revision : null)
        : PanicModeService::disable((int) $user->id, $revision);
    echo json_encode($result + ['action' => $action === 'enable' ? 'enabled' : 'disabled',
        'status' => PanicModeService::getStatus(), 'reauthentication_required' => $result['changed']], JSON_THROW_ON_ERROR);
} catch (PanicModeException $e) {
    // Incomplete transitions report their effective, still-restricted status.
    http_response_code($e->httpStatus);
    if ($e->httpStatus === 503) {
        header('Retry-After: 300');
    }
    echo json_encode(['success' => false, 'error' => $e->getMessage(), 'code' => $e->errorCode,
        'status' => PanicModeService::getStatus()], JSON_THROW_ON_ERROR);
} catch (Throwable $e) {
    error_log('[PanicMode] endpoint_failed: ' . $e->getMessage());
    PanicModeMiddleware::respond(new PanicModeException('PANIC_STATE_UNAVAILABLE', 'Panic control is unavailable.'));
}
