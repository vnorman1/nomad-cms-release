<?php
/**
 * Admin API - Users Management
 * GET: List all users (incl. magic-link invitation status)
 * POST: Create new user - either WITH a password, or WITHOUT one plus a
 *       one-time magic link the admin copies and hands over out-of-band.
 */

require_once __DIR__ . '/../../bootstrap.php';

use NomadCMS\Auth\MagicLinkService;
use NomadCMS\Auth\PasswordPolicy;
use NomadCMS\Database\UserRepository;
use NomadCMS\Database\RoleRepository;
use NomadCMS\Middleware\AuthMiddleware;
use NomadCMS\Middleware\CSRFMiddleware;
use NomadCMS\Security\InputSanitizer;
use NomadCMS\Security\WebhookService;

header('Content-Type: application/json');

try {
    // 1. Authenticate. Fine-grained permission checks happen per-method below:
    //   GET  -> users:read:*
    //   POST -> users:create:*
    // A "users:manage:*" permission covers both via the manage super-action.
    $user = AuthMiddleware::requireAuth();

    $method = $_SERVER['REQUEST_METHOD'];

    // 2. Handle Requests
    if ($method === 'GET') {
        AuthMiddleware::requirePermission('users:read:*');

        // LIST USERS
        $users = UserRepository::findAll();

        // Magic-link invitation status for the whole list in ONE query
        // (instead of N per-user lookups), so the admin table can show
        // "invitation pending" / "invitation expired" badges.
        $inviteStatuses = MagicLinkService::getStatusMap(array_map(
            static fn($u) => (int) $u['id'],
            $users
        ));

        // Remove sensitive data just in case, though UserRepository selection is already specific
        $safeUsers = array_map(function ($u) use ($inviteStatuses) {
            unset($u['password_hash']);
            unset($u['totp_secret']);
            unset($u['backup_codes']);

            $u['has_password'] = (bool) ($u['has_password'] ?? false);

            $invite = $inviteStatuses[(int) $u['id']] ?? null;
            $u['invite_status'] = $invite['status'] ?? 'none';
            // ISO-8601 UTC (see MagicLinkService::toIso) so the browser cannot
            // misread it as local time
            $u['invite_expires_at'] = $invite['expires_at'] ?? null;
            $u['invite_purpose'] = $invite['purpose'] ?? null;
            $u['invite_first_used_at'] = $invite['first_used_at'] ?? null;

            return $u;
        }, $users);

        echo json_encode(['success' => true, 'users' => $safeUsers]);

    } elseif ($method === 'POST') {
        AuthMiddleware::requirePermission('users:create:*');

        // SECURITY: Validate CSRF token for session-based requests
        CSRFMiddleware::validateForSession();
        
        // CREATE USER
        $data = json_decode(file_get_contents('php://input'), true);
        
        if (!$data) {
            throw new Exception('Invalid JSON body');
        }
        
        // Sanitize inputs
        $email = InputSanitizer::email($data['email'] ?? null);
        
        if (!$email) {
            throw new Exception('Valid email is required');
        }

        // Names are MANDATORY when an admin creates a user, so the /welcome
        // onboarding page can greet the person by name and the admin tables
        // can identify people by something friendlier than an e-mail address.
        $firstName = InputSanitizer::personName($data['first_name'] ?? null);
        $lastName = InputSanitizer::personName($data['last_name'] ?? null);

        if ($firstName === null) {
            throw new Exception('A keresztnév megadása kötelező.');
        }
        if ($lastName === null) {
            throw new Exception('A vezetéknév megadása kötelező.');
        }

        // Auth mode: EITHER the admin sets a password, OR a magic link is
        // generated and the user picks their own password during onboarding.
        $authMode = $data['auth_mode'] ?? 'password';
        if (!is_string($authMode) || !in_array($authMode, ['password', 'magic_link'], true)) {
            throw new Exception('Érvénytelen hitelesítési mód. Engedélyezett: password, magic_link.');
        }

        $password = null;
        $inviteTtl = null;

        if ($authMode === 'password') {
            $password = $data['password'] ?? null;

            if (!$password || !is_string($password) || strlen($password) < 8) {
                throw new Exception('Password must be at least 8 characters');
            }

            if (strlen($password) > PasswordPolicy::MAX_LENGTH) {
                throw new Exception('Password too long');
            }
        } else {
            // Throws on anything outside the 1h / 24h / 7d whitelist
            $inviteTtl = MagicLinkService::normalizeTtl($data['invite_ttl'] ?? null);
        }

        $isAdmin = InputSanitizer::boolean($data['is_admin'] ?? false);

        // Extended RBAC: optional explicit role_slug assignment at creation time.
        // Falls back to legacy is_admin-derived role if not provided.
        // NOTE: role slugs use underscores (e.g. "super_admin"), NOT hyphens -
        // must use RoleRepository::normalizeSlug(), not InputSanitizer::slug()
        // (which is designed for URL slugs and would mangle "super_admin" into
        // "super-admin", silently breaking role lookups).
        $roleSlug = isset($data['role_slug']) ? RoleRepository::normalizeSlug((string) $data['role_slug']) : null;
        if ($roleSlug !== null && RoleRepository::findBySlug($roleSlug) === null) {
            throw new Exception("Ismeretlen szerepkör: {$roleSlug}");
        }

        // $password === null creates a PASSWORDLESS account (magic link mode):
        // password_hash stays NULL, so no password can ever authenticate it
        // until the user sets one through the onboarding flow.
        $newUser = UserRepository::create($email, $password, $isAdmin, true, null, $firstName, $lastName);

        if ($newUser && $roleSlug !== null) {
            RoleRepository::assignToUser((int) $newUser['id'], $roleSlug);
            $newUser = UserRepository::findById((int) $newUser['id']);
        }

        if (!$newUser) {
            throw new Exception('Failed to create user');
        }

        // Generate the one-time invitation AFTER the user row exists
        $invitation = null;
        if ($authMode === 'magic_link') {
            $link = MagicLinkService::create(
                (int) $newUser['id'],
                (int) $inviteTtl,
                MagicLinkService::PURPOSE_INVITE,
                isset($user->id) ? (int) $user->id : null
            );

            // SECURITY: the raw token is returned exactly ONCE, here. It is
            // never stored in plaintext and cannot be retrieved again - the
            // admin must regenerate the link if it gets lost.
            $invitation = [
                'token' => $link['token'],
                'expires_at' => $link['expires_at'],
                'purpose' => $link['purpose'],
            ];
        }

        // Remove sensitive data from response
        unset($newUser['password_hash']);
        unset($newUser['totp_secret']);
        unset($newUser['backup_codes']);

        // Dispatch webhook event for user created (async)
        try {
            $webhookService = new WebhookService();
            $webhookService->dispatchEventAsync('user.created', [
                'user_id' => $newUser['uuid'],
                'email' => $newUser['email'],
                'first_name' => $newUser['first_name'] ?? null,
                'last_name' => $newUser['last_name'] ?? null,
                'is_admin' => (bool) $isAdmin,
                'auth_mode' => $authMode,
                'created_by' => $user->uuid ?? null,
                'timestamp' => date('c'),
            ]);
        } catch (\Exception $e) {
            error_log("Webhook dispatch failed for user.created: " . $e->getMessage());
        }

        $response = [
            'success' => true,
            'message' => 'User created successfully',
            'user' => $newUser,
        ];

        if ($invitation !== null) {
            $response['invitation'] = $invitation;
        }

        echo json_encode($response);

    } else {
        http_response_code(405);
        echo json_encode(['success' => false, 'error' => 'Method not allowed']);
    }

} catch (Exception $e) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
