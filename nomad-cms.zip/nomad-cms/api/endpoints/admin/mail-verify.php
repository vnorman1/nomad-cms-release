<?php

/**
 * NOMAD CMS - Admin API - Mail Configuration Verification
 *
 *   GET /api/admin/mail/verify?token=...
 *   GET /api/endpoints/admin/mail-verify.php?token=...   (rewrite-independent)
 *
 * Redeems the token from the confirmation e-mail: the profile flips to
 * `verified` and - when nothing else is the default yet - becomes the active
 * one, which is what actually switches e-mail sending on.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * WHY THIS ENDPOINT IS UNAUTHENTICATED
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * The link is opened from a mail client, frequently on a phone, where there is
 * no admin session and no CSRF token. Requiring auth would mean the confirmation
 * only works if the admin happens to read mail in the same browser they
 * administer the CMS in - which would make the whole flow unreliable exactly
 * where it needs to be dependable.
 *
 * What the token grants, in full: flipping ONE already-admin-authored profile
 * from `unverified` to `verified`. It cannot create, read or modify any
 * configuration, cannot read the SMTP password, does not establish a session,
 * and reveals nothing about the system on failure.
 *
 * Compensating controls:
 *   - 15 minute lifetime (MailSchema::VERIFICATION_TTL)
 *   - single use: the token columns are cleared on success
 *   - only SHA-256(token) is stored, compared with hash_equals
 *   - any configuration save invalidates the outstanding token
 *   - 20 attempts/hour/IP, so the 256-bit token cannot be ground down
 *   - identical, generic messaging for "unknown" and "expired" beyond the reason
 *     code the admin UI needs
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * REDIRECT SAFETY
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * Two ways this endpoint answers, depending on the caller:
 *
 *   - JSON (Accept: application/json) - used by the frontend's own /mails
 *     page, which is what the e-mail link now normally points at
 *     (see MailUrlResolver::verifyUrl()). No redirect, no HTML: the SPA reads
 *     the token from its own URL fragment, calls this endpoint, and renders
 *     the result itself.
 *   - Redirect/HTML (anything else) - the legacy path, still used when the
 *     e-mail link had to fall back to this physical endpoint directly (no
 *     frontend base URL was known when the e-mail was sent). The Location
 *     target comes exclusively from MailUrlResolver::adminResultUrl(), which
 *     only accepts an absolute http(s) URL from ADMIN_URL (or a SITE_URL that
 *     is not the API's own origin). Anything else - relative, javascript:,
 *     absent - yields null and this endpoint renders its own confirmation
 *     page instead. That is the difference between a confirmation link and
 *     an open redirect.
 *
 * Note the ORDER in both paths: the token is consumed BEFORE the
 * redirect/response decision is made, so a missing/invalid ADMIN_URL can
 * never cost the admin their verification.
 *
 * @package NomadCMS
 */

declare(strict_types=1);

require_once __DIR__ . '/../../bootstrap.php';

use NomadCMS\Middleware\RateLimitMiddleware;
use NomadCMS\Services\LoggerService;
use NomadCMS\Services\Mail\MailException;
use NomadCMS\Services\Mail\MailProfileStore;
use NomadCMS\Services\Mail\MailUrlResolver;

/**
 * Self-contained result page.
 *
 * Inline styles and no external assets on purpose: this may be opened from a
 * mail client's in-app browser on a network that cannot reach the admin bundle,
 * and it must still be readable.
 */
function mailVerifyHtml(int $status, string $title, string $message, bool $success): never
{
    http_response_code($status);
    header('Content-Type: text/html; charset=utf-8');
    header('Cache-Control: no-store, no-cache, must-revalidate');
    header('X-Robots-Tag: noindex, nofollow');
    header('X-Content-Type-Options: nosniff');
    header('Referrer-Policy: no-referrer');

    $safeTitle = htmlspecialchars($title, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
    $safeMessage = htmlspecialchars($message, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
    $badgeText = $success ? 'HITELESÍTVE // AKTÍV' : 'ELUTASÍTVA // HIBA';
    $badgeBorder = $success ? '#22c55e' : '#ef4444';
    $badgeBg = $success ? '#f0fdf4' : '#fef2f2';
    $badgeColor = $success ? '#166534' : '#991b1b';
    $year = gmdate('Y');
    $timeUtc = gmdate('Y-m-d H:i:s') . ' UTC';

    echo '<!DOCTYPE html>'
        . '<html lang="hu">'
        . '<head>'
        . '<meta charset="utf-8">'
        . '<meta name="viewport" content="width=device-width,initial-scale=1.0">'
        . '<meta name="color-scheme" content="light">'
        . '<meta name="supported-color-schemes" content="light">'
        . '<title>' . $safeTitle . ' – NOMAD CMS</title>'
        . '<style>'
        . '* { box-sizing: border-box; margin: 0; padding: 0; }'
        . 'body { min-height: 100vh; display: flex; align-items: center; justify-content: center; background: #f5f5f5; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; color: #1f2937; padding: 24px 16px; -webkit-font-smoothing: antialiased; }'
        . '.card { max-width: 520px; width: 100%; background: #ffffff; border: 1px solid #e5e7eb; box-shadow: 0 10px 25px -5px rgba(0,0,0,0.1); }'
        . '.card-header { padding: 24px 28px; border-bottom: 1px solid #e5e7eb; display: flex; align-items: center; justify-content: space-between; }'
        . '.brand { font-size: 22px; font-weight: 900; letter-spacing: -0.05em; color: #000000; line-height: 1; }'
        . '.brand-sub { font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace; font-size: 9px; letter-spacing: 0.2em; text-transform: uppercase; color: #9ca3af; text-align: right; line-height: 1.4; }'
        . '.card-body { padding: 32px 28px; }'
        . '.badge { display: inline-block; font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace; font-size: 10px; font-weight: 700; letter-spacing: 0.15em; text-transform: uppercase; padding: 4px 10px; border: 1px solid ' . $badgeBorder . '; background: ' . $badgeBg . '; color: ' . $badgeColor . '; margin-bottom: 18px; border-radius: 0; }'
        . '.title { font-size: 22px; font-weight: 800; letter-spacing: -0.03em; color: #000000; margin-bottom: 14px; line-height: 1.25; }'
        . '.message { font-size: 14px; line-height: 1.6; color: #4b5563; margin-bottom: 24px; }'
        . '.spec-box { background: #fafafa; border: 1px solid #e5e7eb; border-left: 2px solid ' . ($success ? '#22c55e' : '#ef4444') . '; padding: 12px 16px; margin-bottom: 24px; border-radius: 0; }'
        . '.spec-row { display: flex; justify-content: space-between; font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace; font-size: 11px; padding: 8px 0; border-bottom: 1px solid #f0f0f0; }'
        . '.spec-row:last-child { border-bottom: none; }'
        . '.spec-key { color: #6b7280; text-transform: uppercase; letter-spacing: 0.1em; }'
        . '.spec-val { color: #111827; font-weight: 500; }'
        . '.card-footer { padding: 20px 28px; border-top: 1px solid #e5e7eb; background: #f9fafb; display: flex; align-items: center; justify-content: space-between; font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace; font-size: 9px; letter-spacing: 0.1em; color: #9ca3af; text-transform: uppercase; }'
        . '</style>'
        . '</head>'
        . '<body>'
        . '<main class="card">'
        . '<div class="card-header">'
        . '<div class="brand">NOMAD</div>'
        . '<div class="brand-sub">E-MAIL HITELESÍTÉS<br>CSOMÓPONT</div>'
        . '</div>'
        . '<div class="card-body">'
        . '<span class="badge">// ' . $badgeText . '</span>'
        . '<h1 class="title">' . $safeTitle . '</h1>'
        . '<p class="message">' . $safeMessage . '</p>'
        . '<div class="spec-box">'
        . '<div class="spec-row"><span class="spec-key">Állapotkód</span><span class="spec-val">HTTP ' . $status . '</span></div>'
        . '<div class="spec-row"><span class="spec-key">Időbélyeg</span><span class="spec-val">' . $timeUtc . '</span></div>'
        . '<div class="spec-row"><span class="spec-key">Eredmény</span><span class="spec-val">' . ($success ? 'VERIFIED_SUCCESS' : 'VERIFICATION_REJECTED') . '</span></div>'
        . '</div>'
        . '</div>'
        . '<div class="card-footer">'
        . '<span>NOMAD CMS · E-MAIL</span>'
        . '<span>© ' . $year . ' NOMAD</span>'
        . '</div>'
        . '</main>'
        . '</body>'
        . '</html>';

    exit;
}

function mailVerifyRedirect(string $url): never
{
    header('Location: ' . $url, true, 302);
    header('Cache-Control: no-store, no-cache, must-revalidate');
    header('X-Robots-Tag: noindex, nofollow');
    header('Referrer-Policy: no-referrer');
    exit;
}

/**
 * JSON response for the frontend's own AJAX call (see verifyUrl(): the link
 * in the e-mail now points at the SPA's /mails page, which reads the token
 * from the URL fragment and redeems it itself instead of following a backend
 * redirect chain).
 *
 * @param array<string, mixed> $extra Merged into the response body
 */
function mailVerifyJson(int $status, bool $success, string $code, string $message, array $extra = []): never
{
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store, no-cache, must-revalidate');
    header('X-Robots-Tag: noindex, nofollow');
    header('Referrer-Policy: no-referrer');

    echo json_encode(array_merge([
        'success' => $success,
        'code' => $code,
        'message' => $message,
    ], $extra), JSON_UNESCAPED_UNICODE);

    exit;
}

/**
 * Whether the caller wants JSON rather than a redirect/HTML page - i.e. the
 * frontend's own fetch() from the /mails page, as opposed to a mail client
 * following the raw link (which never sends this).
 */
function mailVerifyWantsJson(): bool
{
    $accept = $_SERVER['HTTP_ACCEPT'] ?? '';

    return is_string($accept) && str_contains($accept, 'application/json');
}

/**
 * @param array<string, mixed> $context
 */
function mailVerifyLog(string $message, array $context = []): void
{
    try {
        LoggerService::info('[Mail] ' . $message, array_merge(['component' => 'mail'], $context));
    } catch (Throwable) {
        // Never let logging break the confirmation.
    }
}

// Only GET: the link is opened by a browser following a URL from an e-mail,
// or fetched by the frontend's own JSON call.
if (strtoupper((string) ($_SERVER['REQUEST_METHOD'] ?? 'GET')) !== 'GET') {
    header('Allow: GET');
    if (mailVerifyWantsJson()) {
        mailVerifyJson(405, false, 'METHOD_NOT_ALLOWED', 'Ezt a kérést csak GET metódussal lehet elküldeni.');
    }
    mailVerifyHtml(405, 'Nem támogatott kérés', 'Ezt a hivatkozást csak megnyitni lehet.', false);
}

// Brute-force ceiling. The token is 256 bits, so this is belt and braces - but
// it also keeps a leaked link from being replayed in a loop.
RateLimitMiddleware::check('mail-verify', 20, 3600);

$token = isset($_GET['token']) && is_string($_GET['token']) ? trim($_GET['token']) : '';
$wantsJson = mailVerifyWantsJson();

try {
    if ($token === '') {
        throw MailException::invalidToken();
    }

    $profile = MailProfileStore::consumeVerificationToken($token);
    $uuid = is_string($profile['uuid'] ?? null) ? $profile['uuid'] : null;
    $becameDefault = ($profile['is_default'] ?? false) === true;

    mailVerifyLog('Levelezési profil hitelesítve', [
        'profile' => $uuid,
        'became_default' => $becameDefault,
    ]);

    if ($wantsJson) {
        mailVerifyJson(200, true, 'VERIFIED', $becameDefault
            ? 'A levelezési beállítás hitelesítve és aktiválva. Az e-mail funkciók mostantól működnek.'
            : 'A levelezési beállítás hitelesítve. Az aktiváláshoz állítsd be alapértelmezettként '
                . 'az admin felület Levelezés oldalán.', [
            'profile' => $uuid,
            'became_default' => $becameDefault,
        ]);
    }

    $redirect = MailUrlResolver::adminResultUrl(true, null, $uuid);
    if ($redirect !== null) {
        mailVerifyRedirect($redirect);
    }

    mailVerifyHtml(
        200,
        'Sikeres megerősítés',
        $becameDefault
            ? 'A levelezési beállítás hitelesítve és aktiválva. Az e-mail funkciók mostantól működnek.'
            : 'A levelezési beállítás hitelesítve. Az aktiváláshoz állítsd be alapértelmezettként '
                . 'az admin felület Levelezés oldalán.',
        true
    );
} catch (MailException $e) {
    $expired = $e->getErrorCode() === 'MAIL_TOKEN_EXPIRED';

    mailVerifyLog('Levelezési hitelesítés elutasítva', ['code' => $e->getErrorCode()]);

    if ($wantsJson) {
        mailVerifyJson(
            $e->getStatusCode(),
            false,
            $expired ? 'EXPIRED' : 'INVALID',
            $expired
                ? 'A megerősítő hivatkozás 15 percig érvényes. Kérj újat az admin felület Levelezés oldalán.'
                : 'Ez a hivatkozás érvénytelen, vagy már felhasználták. Kérj újat az admin felület '
                    . 'Levelezés oldalán.'
        );
    }

    $redirect = MailUrlResolver::adminResultUrl(false, $expired ? 'expired' : 'invalid');
    if ($redirect !== null) {
        mailVerifyRedirect($redirect);
    }

    mailVerifyHtml(
        $e->getStatusCode(),
        $expired ? 'A hivatkozás lejárt' : 'Érvénytelen hivatkozás',
        $expired
            ? 'A megerősítő hivatkozás 15 percig érvényes. Kérj újat az admin felület Levelezés oldalán.'
            : 'Ez a hivatkozás érvénytelen, vagy már felhasználták. Kérj újat az admin felület '
                . 'Levelezés oldalán.',
        false
    );
} catch (Throwable $e) {
    error_log('[Mail] admin/mail-verify hiba: ' . $e->getMessage());

    if ($wantsJson) {
        mailVerifyJson(500, false, 'UNKNOWN', 'A megerősítés feldolgozása során hiba történt. Próbáld újra az admin felületről.');
    }

    mailVerifyHtml(
        500,
        'Váratlan hiba',
        'A megerősítés feldolgozása során hiba történt. Próbáld újra az admin felületről.',
        false
    );
}
