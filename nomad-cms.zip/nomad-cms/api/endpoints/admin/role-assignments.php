<?php
/**
 * NOMAD CMS - Admin API - Role Assignments (Extended RBAC/ABAC-hybrid)
 *
 * PUT /admin/role-assignments.php
 * Body: { "user_id": int, "role_slug": string }
 *
 * Requires 'users:manage:*' permission.
 */

declare(strict_types=1);

require_once __DIR__ . '/../../bootstrap.php';

use NomadCMS\Database\RoleRepository;
use NomadCMS\Database\UserRepository;
use NomadCMS\Middleware\AuthMiddleware;
use NomadCMS\Middleware\CSRFMiddleware;
use NomadCMS\Security\InputSanitizer;
use NomadCMS\Security\WebhookService;

header('Content-Type: application/json');

try {
    $user = AuthMiddleware::requireAuth();
    AuthMiddleware::requirePermission('users:manage:*');

    if ($_SERVER['REQUEST_METHOD'] !== 'PUT') {
        http_response_code(405);
        echo json_encode(['success' => false, 'error' => 'Method not allowed']);
        exit;
    }

    CSRFMiddleware::validateForSession();

    $data = json_decode(file_get_contents('php://input'), true) ?? [];

    $userId = InputSanitizer::positiveInt($data['user_id'] ?? null);
    // NOTE: role slugs use underscores (e.g. "super_admin"), NOT hyphens -
    // use RoleRepository::normalizeSlug(), not InputSanitizer::slug().
    $roleSlug = isset($data['role_slug']) ? RoleRepository::normalizeSlug((string) $data['role_slug']) : '';

    if (!$userId || !$roleSlug) {
        throw new \Exception('user_id és role_slug megadása kötelező');
    }

    // Prevent an admin from demoting themselves out of super_admin (lockout protection)
    if ($userId === (int) $user->id && $roleSlug !== 'super_admin' && !empty($user->is_admin)) {
        throw new \Exception('You can not remove yourself from super_admin');
    }

    $targetUser = UserRepository::findById($userId);
    if (!$targetUser) {
        throw new \Exception('User not found');
    }

    RoleRepository::assignToUser($userId, $roleSlug);

    try {
        $webhookService = new WebhookService();
        $webhookService->dispatchEventAsync('role.assigned', [
            'user_id' => $targetUser['uuid'],
            'role_slug' => $roleSlug,
            'assigned_by' => $user->uuid ?? null,
            'timestamp' => date('c'),
        ]);
    } catch (\Exception $e) {
        error_log('Webhook dispatch failed for role.assigned: ' . $e->getMessage());
    }

    echo json_encode(['success' => true, 'message' => 'Szerepkör hozzárendelve']);

} catch (\Exception $e) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
