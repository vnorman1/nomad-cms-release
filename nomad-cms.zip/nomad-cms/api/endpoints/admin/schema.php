<?php
/**
 * NOMAD CMS — Schema management API.
 * Exposes protected drafts, reports, approvals, history and bounded work.
 * Browser sessions/JWT only; authority is checked live and mutations require CSRF.
 */

declare(strict_types=1);

require_once __DIR__ . '/../../bootstrap.php';

use NomadCMS\Middleware\AuthMiddleware;
use NomadCMS\Middleware\CSRFMiddleware;
use NomadCMS\Services\Schema\SchemaAccess;
use NomadCMS\Services\Schema\SchemaEngine;
use NomadCMS\Services\Schema\SchemaProvider;

handlePreflight();
header('Content-Type: application/json');
header('Cache-Control: no-store');

try {
    $user = SchemaAccess::requireManager();
    $engine = new SchemaEngine(SchemaProvider::store());
    $method = $_SERVER['REQUEST_METHOD'];
    if ($method === 'GET') {
        $action = $_GET['action'] ?? 'status';
        $result = match ($action) {
            'status' => $engine->status((int) ($_GET['limit'] ?? 100), max(0, (int) ($_GET['offset'] ?? 0))),
            'draft' => $engine->getDraft((string) ($_GET['id'] ?? '')),
            'revision' => $engine->store->revision((int) ($_GET['revision'] ?? 0)),
            'history' => $engine->store->history(
                ($_GET['summary'] ?? '') !== '1',
                max(0, (int) ($_GET['before'] ?? 0)),
                (int) ($_GET['limit'] ?? 50)
            ),
            'archive' => (function () use ($user): array {
                $key = (string) ($_GET['slot'] ?? '');
                AuthMiddleware::requireSlotAccess($key);
                AuthMiddleware::requirePermission('content:read:*', $key);
                // Native reads retain archived values; no public projection runs here.
                return ['slot' => $key, 'data' => \NomadCMS\Database\ContentDatabase::getSlot($key)];
            })(),
            default => throw new InvalidArgumentException('Unknown schema action.', 400),
        };
    } elseif ($method === 'POST') {
        CSRFMiddleware::validateForSession();
        $body = getJsonBody() ?? [];
        $id = (string) ($body['id'] ?? '');
        $result = match ($body['action'] ?? '') {
            'draft' => $engine->draft($body['schema'] ?? [], (int) ($body['base_revision'] ?? 0), $user->uuid, (string) ($body['reason'] ?? '')),
            'rollback' => $engine->draft($engine->store->revision((int) ($body['revision'] ?? 0))['schema'], (int) ($engine->store->active()['revision'] ?? 0), $user->uuid, (string) ($body['reason'] ?? ''), (int) $body['revision']),
            'analyse' => $engine->analyse($id),
            'delete_draft' => $engine->deleteDraft($id, $user->uuid),
            'test' => $engine->test($id),
            'approve' => $engine->approve($id, $user->uuid, (string) ($body['report_hash'] ?? ''), !empty($body['accept_legacy'])),
            'advance' => $engine->advance($id),
            'work' => $engine->work(),
            'approve_index' => ['id' => $engine->approveIndex((string) ($body['slot'] ?? ''), (string) ($body['field'] ?? ''), $user->uuid)],
            default => throw new InvalidArgumentException('Unknown schema action.', 400),
        };
    } else {
        throw new RuntimeException('Method not allowed.', 405);
    }
    echo json_encode(['success' => true, 'data' => $result], JSON_THROW_ON_ERROR | JSON_UNESCAPED_UNICODE);
} catch (Throwable $error) {
    $status = in_array($error->getCode(), [400, 403, 404, 405, 409, 410, 422, 503], true) ? $error->getCode() : 500;
    http_response_code($status);
    echo json_encode(['success' => false, 'error' => $error->getMessage()], JSON_UNESCAPED_UNICODE);
} finally {
    SchemaProvider::release();
}
