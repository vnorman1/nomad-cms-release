<?php
/**
 * NOMAD CMS - Admin API - Analytics
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * ENDPOINTS
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *   GET  /api/admin/analytics?action=overview&host=X&start=YYYY-MM-DD&end=YYYY-MM-DD
 *                                                    time-series + top lists + period comparison
 *   GET  /api/admin/analytics?action=heatmap&host=X&start=YYYY-MM-DD&end=YYYY-MM-DD[&type=punchcard|calendar]
 *                                                    0-PII time-series activity heatmap
 *   GET  /api/admin/analytics?action=explore&host=X&start=...&end=...
 *        [&filter[path]=/blog&breakdown=device&page=1&pageSize=50]
 *                                                    ad-hoc filtered/broken-down query
 *   GET  /api/admin/analytics?action=export&host=X&start=...&end=...[&filter[...]&breakdown=...]
 *                                                    same as explore, as CSV
 *   GET  /api/admin/analytics?action=settings                    current settings
 *   GET  /api/admin/analytics?action=diagnostics                  pipeline health snapshot
 *                                                    raw event buffer size, spool ingest backlog,
 *                                                    finalization progress, aggregated table sizes
 *   GET  /api/admin/analytics?action=campaigns-list&host=X&days=30
 *                                                    saved UTM campaigns + last-N-days views/visitors
 *   GET  /api/admin/analytics?action=wrapped&year=YYYY
 *                                                    yearly recap ("NOMAD Wrapped") - only available
 *                                                    while AnalyticsWrappedWindow::isActive() AND the
 *                                                    wrapped_enabled setting is true; otherwise
 *                                                    {available:false} with no data
 *   POST /api/admin/analytics?action=settings                    update settings
 *   POST /api/admin/analytics?action=aggregate                   manual aggregation sweep now
 *   POST /api/admin/analytics?action=purge                       manual retention sweep now
 *   POST /api/admin/analytics?action=campaigns-create             create a UTM campaign
 *        body: {name, base_url, utm_source, utm_medium, utm_campaign, utm_term?, utm_content?, notes?, force?}
 *        -> 409 with {existing_campaign} if a base_url+UTM conflict exists and force is not true
 *   POST /api/admin/analytics?action=campaigns-update&id=X        update a UTM campaign (same body/409 semantics)
 *   POST /api/admin/analytics?action=campaigns-delete&id=X        delete a UTM campaign
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * PERMISSIONS
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *   overview/heatmap/explore/settings(GET)/diagnostics/campaigns-list   analytics:read:*  (analytics:list:* also accepted)
 *   export                           analytics:export:*
 *   settings(POST)/aggregate/purge/campaigns-create/campaigns-update/campaigns-delete/wrapped   analytics:manage:*
 *
 * This is the first AUTHENTICATED endpoint in the Analytics module - every
 * other piece (collect.php, the spool/ingest/aggregation pipeline) is either
 * public-unauthenticated or pure background processing. Nothing here ever
 * touches raw massive_analytics_events; see AnalyticsQueryService's docblock.
 *
 * @package NomadCMS
 */

declare(strict_types=1);

require_once __DIR__ . '/../../bootstrap.php';

use NomadCMS\Middleware\AuthMiddleware;
use NomadCMS\Middleware\RateLimitMiddleware;
use NomadCMS\Services\Analytics\AggregationService;
use NomadCMS\Services\Analytics\AnalyticsQueryService;
use NomadCMS\Services\Analytics\AnalyticsRetentionService;
use NomadCMS\Services\Analytics\AnalyticsSettingsService;
use NomadCMS\Services\Analytics\AnalyticsWrappedWindow;
use NomadCMS\Services\Analytics\CampaignService;
use NomadCMS\Services\Analytics\DuplicateCampaignException;

handlePreflight();
header('Content-Type: application/json; charset=utf-8');

/**
 * @param array<string, mixed> $payload
 */
function analyticsAdminJson(int $status, array $payload): never
{
    http_response_code($status);
    echo json_encode($payload, JSON_UNESCAPED_UNICODE);
    exit;
}

/**
 * @return array<string, mixed>
 */
function analyticsAdminBody(): array
{
    $raw = file_get_contents('php://input');
    $decoded = json_decode($raw === false ? '' : $raw, true);
    return is_array($decoded) ? $decoded : [];
}

/**
 * Default host: the current request's own host, so a single-site install
 * (the common case) never needs the frontend to know/pass a host at all.
 */
function analyticsAdminDefaultHost(): string
{
    return (string) ($_SERVER['HTTP_HOST'] ?? ($_ENV['APP_URL'] ?? 'default'));
}

function analyticsAdminDay(?string $value, string $fallback): string
{
    if ($value === null || $value === '') {
        return $fallback;
    }
    return $value;
}

try {
    AuthMiddleware::requireAuth();
    RateLimitMiddleware::check('admin-analytics', 120, 60);

    $method = strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET');
    $action = isset($_GET['action']) ? (string) $_GET['action'] : 'overview';

    $host = isset($_GET['host']) && $_GET['host'] !== '' ? (string) $_GET['host'] : analyticsAdminDefaultHost();
    $today = date('Y-m-d');
    $startDay = analyticsAdminDay($_GET['start'] ?? null, date('Y-m-d', strtotime('-29 days')));
    $endDay = analyticsAdminDay($_GET['end'] ?? null, $today);

    // =========================================================================
    // GET actions
    // =========================================================================

    if ($method === 'GET' && $action === 'overview') {
        AuthMiddleware::requireAnyPermission(['analytics:read:*', 'analytics:list:*']);

        $topLimit = isset($_GET['topLimit']) ? max(1, min(50, (int) $_GET['topLimit'])) : 10;
        $dow = (isset($_GET['dow']) && $_GET['dow'] !== '') ? (int) $_GET['dow'] : null;
        if ($dow !== null && ($dow < 0 || $dow > 6)) {
            $dow = null;
        }
        $result = AnalyticsQueryService::overview($host, $startDay, $endDay, $topLimit, $dow);

        analyticsAdminJson(200, ['success' => true] + $result);
    }

    if ($method === 'GET' && $action === 'heatmap') {
        AuthMiddleware::requireAnyPermission(['analytics:read:*', 'analytics:list:*']);

        $type = isset($_GET['type']) && $_GET['type'] === 'calendar' ? 'calendar' : 'punchcard';
        $result = AnalyticsQueryService::heatmap($host, $startDay, $endDay, $type);

        analyticsAdminJson(200, ['success' => true] + $result);
    }

    if ($method === 'GET' && $action === 'explore') {
        AuthMiddleware::requireAnyPermission(['analytics:read:*', 'analytics:list:*']);

        $filters = [];
        if (isset($_GET['filter']) && is_array($_GET['filter'])) {
            foreach ($_GET['filter'] as $dimension => $value) {
                if (is_string($dimension) && is_string($value) && $value !== '') {
                    $filters[$dimension] = $value;
                }
            }
        }

        $breakdown = isset($_GET['breakdown']) && $_GET['breakdown'] !== '' ? (string) $_GET['breakdown'] : null;
        $page = isset($_GET['page']) ? max(1, (int) $_GET['page']) : 1;
        $pageSize = isset($_GET['pageSize']) ? max(1, min(500, (int) $_GET['pageSize'])) : 50;
        $sortDir = isset($_GET['sortDir']) ? (string) $_GET['sortDir'] : 'desc';

        $result = AnalyticsQueryService::explore($host, $startDay, $endDay, $filters, $breakdown, $page, $pageSize, 'views', $sortDir);

        analyticsAdminJson(200, ['success' => true] + $result);
    }

    if ($method === 'GET' && $action === 'export') {
        AuthMiddleware::requirePermission('analytics:export:*');

        $filters = [];
        if (isset($_GET['filter']) && is_array($_GET['filter'])) {
            foreach ($_GET['filter'] as $dimension => $value) {
                if (is_string($dimension) && is_string($value) && $value !== '') {
                    $filters[$dimension] = $value;
                }
            }
        }
        $breakdown = isset($_GET['breakdown']) && $_GET['breakdown'] !== '' ? (string) $_GET['breakdown'] : null;

        $csv = AnalyticsQueryService::exploreCsv($host, $startDay, $endDay, $filters, $breakdown);

        http_response_code(200);
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="analytics-' . $startDay . '-to-' . $endDay . '.csv"');
        header('Cache-Control: no-store');
        echo $csv;
        exit;
    }

    if ($method === 'GET' && $action === 'settings') {
        AuthMiddleware::requireAnyPermission(['analytics:read:*', 'analytics:list:*']);
        analyticsAdminJson(200, ['success' => true, 'settings' => AnalyticsSettingsService::getInstance()->toArray()]);
    }

    if ($method === 'GET' && $action === 'diagnostics') {
        AuthMiddleware::requireAnyPermission(['analytics:read:*', 'analytics:list:*']);
        analyticsAdminJson(200, ['success' => true, 'diagnostics' => AnalyticsQueryService::diagnostics()]);
    }

    if ($method === 'GET' && $action === 'campaigns-list') {
        AuthMiddleware::requireAnyPermission(['analytics:read:*', 'analytics:list:*']);

        $days = isset($_GET['days']) ? max(1, min(366, (int) $_GET['days'])) : 30;
        $campaigns = CampaignService::list();

        // Single batch call for ALL campaigns' metrics - never one explore()
        // call per campaign (see AnalyticsQueryService::metricsForUtmCombinations
        // docblock for why that would not scale).
        // CampaignService stores omitted utm_term/utm_content as '' (empty
        // string - see AnalyticsCampaignsSchema docblock for why NULL is
        // avoided), but the beacon/aggregation pipeline stores an absent UTM
        // value as the '(none)' sentinel (AnalyticsSchema::DIM_NONE). These
        // are two different domains (campaign builder INPUT vs. normalized
        // beacon DIMENSION) - bridge them here, at the one place they meet,
        // rather than leaking beacon-specific sentinels into CampaignService.
        $toDimensionValue = static function (mixed $v): string {
            $s = is_scalar($v) ? (string) $v : '';
            return $s === '' ? '(none)' : $s;
        };

        $combinations = array_map(static fn (array $c) => [
            'utm_source' => $toDimensionValue($c['utm_source']),
            'utm_medium' => $toDimensionValue($c['utm_medium']),
            'utm_campaign' => $toDimensionValue($c['utm_campaign']),
            'utm_term' => $toDimensionValue($c['utm_term']),
            'utm_content' => $toDimensionValue($c['utm_content']),
        ], $campaigns);

        $metricsByKey = AnalyticsQueryService::metricsForUtmCombinations($host, $combinations, $days);

        $enriched = array_map(static function (array $c) use ($metricsByKey, $toDimensionValue) {
            $key = AnalyticsQueryService::combinationKey([
                'utm_source' => $toDimensionValue($c['utm_source']),
                'utm_medium' => $toDimensionValue($c['utm_medium']),
                'utm_campaign' => $toDimensionValue($c['utm_campaign']),
                'utm_term' => $toDimensionValue($c['utm_term']),
                'utm_content' => $toDimensionValue($c['utm_content']),
            ]);
            $c['metrics'] = $metricsByKey[$key] ?? ['views' => 0, 'visitors' => 0, 'approximate' => true];
            return $c;
        }, $campaigns);

        analyticsAdminJson(200, ['success' => true, 'campaigns' => $enriched, 'metrics_range_days' => $days]);
    }

    if ($method === 'GET' && $action === 'wrapped') {
        AuthMiddleware::requirePermission('analytics:manage:*');

        $windowActive = AnalyticsWrappedWindow::isActive();
        $wrappedEnabled = AnalyticsSettingsService::getInstance()->isWrappedEnabled();

        if (!$wrappedEnabled || !$windowActive) {
            analyticsAdminJson(200, ['success' => true, 'available' => false]);
        }

        $year = isset($_GET['year']) && $_GET['year'] !== '' ? (int) $_GET['year'] : AnalyticsWrappedWindow::recapYear();
        $result = AnalyticsQueryService::wrapped($host, $year);

        analyticsAdminJson(200, ['success' => true, 'available' => true] + $result);
    }

    // =========================================================================
    // POST actions
    // =========================================================================

    if ($method === 'POST' && $action === 'settings') {
        AuthMiddleware::requirePermission('analytics:manage:*');
        $body = analyticsAdminBody();
        $updated = AnalyticsSettingsService::getInstance()->update($body);
        analyticsAdminJson(200, ['success' => true, 'settings' => $updated]);
    }

    if ($method === 'POST' && $action === 'aggregate') {
        AuthMiddleware::requirePermission('analytics:manage:*');
        \NomadCMS\Services\Analytics\SpoolIngestService::ingest();
        $results = AggregationService::aggregateAllPending();
        $finalized = AggregationService::finalizeElapsedDays();
        analyticsAdminJson(200, ['success' => true, 'aggregated' => $results, 'finalized_days' => $finalized]);
    }

    if ($method === 'POST' && $action === 'purge') {
        AuthMiddleware::requirePermission('analytics:manage:*');
        $result = AnalyticsRetentionService::sweep(5000);
        analyticsAdminJson(200, ['success' => true] + $result);
    }

    if ($method === 'POST' && $action === 'regenerate-snippet') {
        AuthMiddleware::requirePermission('analytics:manage:*');
        $ok = \NomadCMS\Services\Analytics\AnalyticsScriptGenerator::generate();
        analyticsAdminJson($ok ? 200 : 500, ['success' => $ok]);
    }

    if ($method === 'POST' && $action === 'campaigns-create') {
        AuthMiddleware::requirePermission('analytics:manage:*');
        $user = AuthMiddleware::requireAuth();
        $body = analyticsAdminBody();
        $force = (bool) ($body['force'] ?? false);

        try {
            $campaign = CampaignService::create($body, $force, isset($user->uuid) ? (string) $user->uuid : null);
            analyticsAdminJson(201, ['success' => true, 'campaign' => $campaign]);
        } catch (DuplicateCampaignException $e) {
            analyticsAdminJson(409, [
                'success' => false,
                'error' => $e->getMessage(),
                'existing_campaign' => $e->getExistingCampaign(),
            ]);
        }
    }

    if ($method === 'POST' && $action === 'campaigns-update') {
        AuthMiddleware::requirePermission('analytics:manage:*');
        $id = isset($_GET['id']) ? (int) $_GET['id'] : 0;
        if ($id <= 0) {
            analyticsAdminJson(400, ['success' => false, 'error' => 'Hiányzó vagy érvénytelen kampány azonosító.']);
        }

        $body = analyticsAdminBody();
        $force = (bool) ($body['force'] ?? false);

        try {
            $campaign = CampaignService::update($id, $body, $force);
            analyticsAdminJson(200, ['success' => true, 'campaign' => $campaign]);
        } catch (DuplicateCampaignException $e) {
            analyticsAdminJson(409, [
                'success' => false,
                'error' => $e->getMessage(),
                'existing_campaign' => $e->getExistingCampaign(),
            ]);
        }
    }

    if ($method === 'POST' && $action === 'campaigns-delete') {
        AuthMiddleware::requirePermission('analytics:manage:*');
        $id = isset($_GET['id']) ? (int) $_GET['id'] : 0;
        if ($id <= 0) {
            analyticsAdminJson(400, ['success' => false, 'error' => 'Hiányzó vagy érvénytelen kampány azonosító.']);
        }

        $deleted = CampaignService::delete($id);
        analyticsAdminJson($deleted ? 200 : 404, ['success' => $deleted]);
    }

    header('Allow: GET, POST');
    analyticsAdminJson(405, ['success' => false, 'error' => 'Nem támogatott művelet vagy HTTP metódus.']);
} catch (\Throwable $e) {
    $debug = ($_ENV['APP_DEBUG'] ?? 'false') === 'true';
    analyticsAdminJson(
        $e instanceof \InvalidArgumentException ? 400 : 500,
        [
            'success' => false,
            'error' => $debug ? $e->getMessage() : 'Belső szerverhiba történt.',
        ]
    );
}
