<?php
/**
 * NOMAD CMS - Admin API - Roles Management (Extended RBAC/ABAC-hybrid)
 *
 * Endpoints:
 *   GET    /admin/roles.php                    - List all roles (with permissions & slot_access)
 *   GET    /admin/roles.php?slug=X              - Get single role
 *   GET    /admin/roles.php?action=users&slug=X - List users assigned to a role
 *   POST   /admin/roles.php                    - Create custom role
 *   PUT    /admin/roles.php                    - Update role (system roles: editor/viewer only, super_admin locked)
 *   DELETE /admin/roles.php?slug=X             - Delete custom role (system roles protected)
 *
 * Requires 'users:manage:*' permission (super_admin always passes).
 */

declare(strict_types=1);

require_once __DIR__ . '/../../bootstrap.php';

use NomadCMS\Database\RoleRepository;
use NomadCMS\Database\UserRepository;
use NomadCMS\Middleware\AuthMiddleware;
use NomadCMS\Middleware\CSRFMiddleware;
use NomadCMS\Security\InputSanitizer;
use NomadCMS\Security\WebhookService;

header('Content-Type: application/json');

/**
 * Safely normalize a role slug, tolerating null/empty input (returns null
 * instead of throwing) for optional query-param contexts.
 *
 * NOTE: role slugs use underscores (e.g. "super_admin"), NOT hyphens - must
 * use RoleRepository::normalizeSlug(), not InputSanitizer::slug() (which is
 * designed for URL slugs and mangles underscores into hyphens, silently
 * breaking lookups for every role whose slug contains an underscore).
 */
function safeRoleSlug(?string $input): ?string
{
    if ($input === null || trim($input) === '') {
        return null;
    }
    try {
        return RoleRepository::normalizeSlug($input);
    } catch (\Exception $e) {
        return null;
    }
}

try {
    // 1. Authenticate. GET (listing/viewing roles) only requires read access;
    // mutating role definitions (create/update/delete) is a privileged action
    // that still requires full user-management permission.
    $user = AuthMiddleware::requireAuth();

    $method = $_SERVER['REQUEST_METHOD'];

    if ($method === 'GET') {
        AuthMiddleware::requirePermission('users:read:*');
        $slug = isset($_GET['slug']) ? safeRoleSlug($_GET['slug']) : null;
        $action = $_GET['action'] ?? null;

        // GET /admin/roles.php?action=users&slug=X - list users assigned to a role
        if ($action === 'users') {
            if (!$slug) {
                throw new \Exception('slug megadása kötelező');
            }
            if (RoleRepository::findBySlug($slug) === null) {
                http_response_code(404);
                echo json_encode(['success' => false, 'error' => 'Szerepkör nem található']);
                exit;
            }

            $users = UserRepository::findByRoleSlug($slug);
            echo json_encode(['success' => true, 'users' => $users]);
            exit;
        }

        if ($slug) {
            $role = RoleRepository::findBySlug($slug);
            if (!$role) {
                http_response_code(404);
                echo json_encode(['success' => false, 'error' => 'Szerepkör nem található']);
                exit;
            }
            echo json_encode(['success' => true, 'role' => $role]);
        } else {
            echo json_encode(['success' => true, 'roles' => RoleRepository::findAll()]);
        }
        exit;
    }

    // Mutating role definitions (create/update/delete) requires full
    // user-management permission - role management is a privileged action.
    AuthMiddleware::requirePermission('users:manage:*');

    // Mutating operations require CSRF validation for session-based requests
    CSRFMiddleware::validateForSession();

    if ($method === 'POST') {
        $data = json_decode(file_get_contents('php://input'), true);
        if (!$data) {
            throw new \Exception('Invalid JSON body');
        }

        $slug = safeRoleSlug($data['slug'] ?? '');
        $name = InputSanitizer::plainText($data['name'] ?? '', 100);
        $description = isset($data['description']) ? InputSanitizer::plainText($data['description'], 500) : null;
        $priority = InputSanitizer::positiveInt($data['priority'] ?? 100) ?? 100;

        $permissions = sanitizePermissions($data['permissions'] ?? []);
        $slotAccess = sanitizeSlotAccess($data['slot_access'] ?? []);

        if (!$slug || !$name) {
            throw new \Exception('A szerepkör azonosító (slug) és név megadása kötelező');
        }

        $role = RoleRepository::create($slug, $name, $description, $permissions, $slotAccess, $priority);

        try {
            $webhookService = new WebhookService();
            $webhookService->dispatchEventAsync('role.created', [
                'role_slug' => $role['slug'],
                'created_by' => $user->uuid ?? null,
                'timestamp' => date('c'),
            ]);
        } catch (\Exception $e) {
            error_log('Webhook dispatch failed for role.created: ' . $e->getMessage());
        }

        echo json_encode(['success' => true, 'message' => 'Szerepkör létrehozva', 'role' => $role]);
        exit;
    }

    if ($method === 'PUT') {
        $data = json_decode(file_get_contents('php://input'), true);
        if (!$data || empty($data['slug'])) {
            throw new \Exception('A szerepkör azonosító (slug) megadása kötelező');
        }

        $slug = safeRoleSlug($data['slug']);
        $updateData = [];

        if (isset($data['name'])) {
            $updateData['name'] = InputSanitizer::plainText($data['name'], 100);
        }
        if (array_key_exists('description', $data)) {
            $updateData['description'] = $data['description'] !== null
                ? InputSanitizer::plainText($data['description'], 500)
                : null;
        }
        if (isset($data['priority'])) {
            $updateData['priority'] = InputSanitizer::positiveInt($data['priority']) ?? 100;
        }
        if (isset($data['permissions'])) {
            $updateData['permissions'] = sanitizePermissions($data['permissions']);
        }
        if (isset($data['slot_access'])) {
            $updateData['slot_access'] = sanitizeSlotAccess($data['slot_access']);
        }

        $role = RoleRepository::update($slug, $updateData);

        try {
            $webhookService = new WebhookService();
            $webhookService->dispatchEventAsync('role.updated', [
                'role_slug' => $role['slug'],
                'updated_by' => $user->uuid ?? null,
                'updated_fields' => array_keys($updateData),
                'timestamp' => date('c'),
            ]);
        } catch (\Exception $e) {
            error_log('Webhook dispatch failed for role.updated: ' . $e->getMessage());
        }

        echo json_encode(['success' => true, 'message' => 'Szerepkör frissítve', 'role' => $role]);
        exit;
    }

    if ($method === 'DELETE') {
        $slug = safeRoleSlug($_GET['slug'] ?? '');
        if (!$slug) {
            throw new \Exception('A szerepkör azonosító (slug) megadása kötelező');
        }

        $reassignedCount = RoleRepository::delete($slug);

        try {
            $webhookService = new WebhookService();
            $webhookService->dispatchEventAsync('role.deleted', [
                'role_slug' => $slug,
                'deleted_by' => $user->uuid ?? null,
                'reassigned_users' => $reassignedCount,
                'timestamp' => date('c'),
            ]);
        } catch (\Exception $e) {
            error_log('Webhook dispatch failed for role.deleted: ' . $e->getMessage());
        }

        echo json_encode([
            'success' => true,
            'message' => 'Szerepkör törölve',
            'reassigned_users' => $reassignedCount,
        ]);
        exit;
    }

    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Method not allowed']);

} catch (\Exception $e) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}

/**
 * Validate & sanitize a permission list: must be an array of "resource:action:scope" strings.
 *
 * @return array<int, string>
 */
function sanitizePermissions(mixed $input): array
{
    if (!is_array($input)) {
        return [];
    }

    $clean = [];
    foreach ($input as $permission) {
        if (!is_string($permission)) {
            continue;
        }
        $permission = trim($permission);
        // Must match resource:action:scope with word chars or wildcard per segment
        if (preg_match('/^[a-z_*]+:[a-z_*]+:(?:\*|own)$/', $permission)) {
            $clean[] = $permission;
        }
    }

    return array_values(array_unique($clean));
}

/**
 * Validate & sanitize slot access wildcard patterns.
 *
 * @return array<int, string>
 */
function sanitizeSlotAccess(mixed $input): array
{
    if (!is_array($input)) {
        return [];
    }

    $clean = [];
    foreach ($input as $pattern) {
        if (!is_string($pattern)) {
            continue;
        }
        $pattern = trim($pattern);
        if ($pattern === '') {
            continue;
        }
        // Allow: "*", exact slot keys, or prefix wildcards like "cikk*"
        if (preg_match('/^[a-zA-Z0-9_\-]*\*?$/', $pattern)) {
            $clean[] = $pattern;
        }
    }

    return array_values(array_unique($clean));
}
