<?php
/**
 * NOMAD CMS — administrative SEO Studio endpoint.
 * Delegates authorization, CSRF, bounded parsing and dispatch to the module controller.
 * @package NomadCMS\Endpoints
 */
declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/bootstrap.php';
\NomadCMS\Services\Seo\HttpController::admin();
