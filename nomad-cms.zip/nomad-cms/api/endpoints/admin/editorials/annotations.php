<?php

/**
 * NOMAD CMS - Editorials Hub annotation endpoint.
 *
 * Dispatches target-anchored comments and their CMS-side reverse lookup.
 * Business rules and authorization belong to the Hub services.
 *
 * @package NomadCMS\Endpoints\EditorialsHub
 */

declare(strict_types=1);

require_once __DIR__ . '/../../../bootstrap.php';

NomadCMS\Services\EditorialsHub\HttpController::dispatch('annotations');
