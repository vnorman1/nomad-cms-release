<?php

/**
 * NOMAD CMS - Editorials Hub transfers.
 *
 * HTTP entrypoint for the Editorials Hub transfers route family.
 * HTTP validation delegates to the controller; business logic and SQL stay in services.
 *
 * @package NomadCMS\Services\EditorialsHub
 */

declare(strict_types=1);

/** HTTP explicit preview/apply dispatch; destinations commit their own durable receipts. */
require_once dirname(__DIR__, 3) . '/bootstrap.php';
\NomadCMS\Services\EditorialsHub\HttpController::dispatch('transfers');
