<?php

/**
 * NOMAD CMS - Editorials Hub targets.
 *
 * HTTP entrypoint for the Editorials Hub targets route family.
 * HTTP validation delegates to the controller; business logic and SQL stay in services.
 *
 * @package NomadCMS\Services\EditorialsHub
 */

declare(strict_types=1);

/** HTTP permission-filtered suggestions, references and proposals. */
require_once dirname(__DIR__, 3) . '/bootstrap.php';
\NomadCMS\Services\EditorialsHub\HttpController::dispatch('targets');
