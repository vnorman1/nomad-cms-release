<?php

/**
 * NOMAD CMS - Editorials Hub boards.
 *
 * HTTP entrypoint for the Editorials Hub boards route family.
 * HTTP validation delegates to the controller; business logic and SQL stay in services.
 *
 * @package NomadCMS\Services\EditorialsHub
 */

declare(strict_types=1);

/** HTTP board lifecycle/membership/status dispatch; no SQL in this endpoint. */
require_once dirname(__DIR__, 3) . '/bootstrap.php';
\NomadCMS\Services\EditorialsHub\HttpController::dispatch('boards');
