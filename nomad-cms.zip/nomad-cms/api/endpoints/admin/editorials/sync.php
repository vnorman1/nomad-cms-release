<?php

/**
 * NOMAD CMS - Editorials Hub sync.
 *
 * HTTP entrypoint for the Editorials Hub sync route family.
 * HTTP validation delegates to the controller; business logic and SQL stay in services.
 *
 * @package NomadCMS\Services\EditorialsHub
 */

declare(strict_types=1);

/** HTTP changes, presence and binary note relay dispatch. */
require_once dirname(__DIR__, 3) . '/bootstrap.php';
\NomadCMS\Services\EditorialsHub\HttpController::dispatch('sync');
