<?php

/**
 * NOMAD CMS - Editorials Hub attachments.
 *
 * HTTP entrypoint for the Editorials Hub attachments route family.
 * HTTP validation delegates to the controller; business logic and SQL stay in services.
 *
 * @package NomadCMS\Services\EditorialsHub
 */

declare(strict_types=1);

/** HTTP streamed, board-authorized private image upload/download. */
require_once dirname(__DIR__, 3) . '/bootstrap.php';
\NomadCMS\Services\EditorialsHub\HttpController::dispatch('attachments');
