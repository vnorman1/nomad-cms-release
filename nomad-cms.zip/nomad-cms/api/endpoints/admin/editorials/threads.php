<?php

/**
 * NOMAD CMS - Editorials Hub threads.
 *
 * HTTP entrypoint for the Editorials Hub threads route family.
 * HTTP validation delegates to the controller; business logic and SQL stay in services.
 *
 * @package NomadCMS\Services\EditorialsHub
 */

declare(strict_types=1);

/** HTTP thread/message dispatch with author-only edits. */
require_once dirname(__DIR__, 3) . '/bootstrap.php';
\NomadCMS\Services\EditorialsHub\HttpController::dispatch('threads');
