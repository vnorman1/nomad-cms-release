<?php

/**
 * NOMAD CMS - Editorials Hub items.
 *
 * HTTP entrypoint for the Editorials Hub items route family.
 * HTTP validation delegates to the controller; business logic and SQL stay in services.
 *
 * @package NomadCMS\Services\EditorialsHub
 */

declare(strict_types=1);

/** HTTP card/viewport/ticket/geometry dispatch; all policy lives in the services. */
require_once dirname(__DIR__, 3) . '/bootstrap.php';
\NomadCMS\Services\EditorialsHub\HttpController::dispatch('items');
