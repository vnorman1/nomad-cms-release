<?php
/**
 * Admin API - User Actions
 * PUT: Update user
 * DELETE: Delete user
 * PATCH: Toggle lock status
 */

require_once __DIR__ . '/../../bootstrap.php';

use NomadCMS\Database\UserRepository;
use NomadCMS\Database\RoleRepository;
use NomadCMS\Database\AuthDatabase;
use NomadCMS\Middleware\AuthMiddleware;
use NomadCMS\Middleware\CSRFMiddleware;
use NomadCMS\Security\InputSanitizer;
use NomadCMS\Security\WebhookService;

header('Content-Type: application/json');

try {
    // SECURITY: Validate CSRF token for session-based requests
    CSRFMiddleware::validateForSession();
    
    // 1. Authenticate. Fine-grained permission checks happen per-method below:
    //   PUT   -> users:update:*
    //   DELETE -> users:delete:*
    //   PATCH -> users:update:* (lock/unlock is a user-record mutation)
    // A "users:manage:*" permission covers all of the above via the manage
    // super-action hierarchy.
    $user = AuthMiddleware::requireAuth();

    $method = $_SERVER['REQUEST_METHOD'];

    switch ($method) {
        case 'PUT':
        case 'PATCH':
            AuthMiddleware::requirePermission('users:update:*');
            break;
        case 'DELETE':
            AuthMiddleware::requirePermission('users:delete:*');
            break;
        default:
            http_response_code(405);
            echo json_encode(['success' => false, 'error' => 'Method not allowed']);
            exit;
    }

    $data = json_decode(file_get_contents('php://input'), true) ?? [];
    
    // Sanitize and validate user ID
    $userId = InputSanitizer::positiveInt($data['id'] ?? null);

    if (!$userId) {
        // Try to get ID from query string for DELETE
        if ($method === 'DELETE' && isset($_GET['id'])) {
            $userId = InputSanitizer::positiveInt($_GET['id']);
        }
        
        if (!$userId) {
            throw new Exception('Valid User ID is required');
        }
    }

    // Prevent self-deletion or self-demotion to avoid lockout
    if ($userId == $user->id) {
        if ($method === 'DELETE') {
            throw new Exception('Cannot delete your own account');
        }
        if ($method === 'PATCH' && InputSanitizer::boolean($data['lock'] ?? false)) {
             throw new Exception('Cannot lock your own account');
        }
        if ($method === 'PUT' && isset($data['is_admin']) && !InputSanitizer::boolean($data['is_admin'])) {
             throw new Exception('Cannot remove your own admin privileges');
        }
    }

    /**
     * SAFETY: Prevent the LAST active (non-locked) super_admin from being
     * deleted or locked by ANYONE (including another super_admin), so the
     * system can never end up with zero manageable accounts.
     */
    $isTargetActiveSuperAdmin = function (int $targetId): bool {
        $target = UserRepository::findById($targetId);
        if (!$target) {
            return false;
        }
        $isSuperAdmin = ($target['role_slug'] ?? null) === 'super_admin'
            || (empty($target['role_slug']) && !empty($target['is_admin']));
        $isActive = empty($target['locked_until']) || strtotime($target['locked_until']) <= time();
        return $isSuperAdmin && $isActive;
    };

    if ($isTargetActiveSuperAdmin($userId)) {
        $db = AuthDatabase::getInstance();
        $remainingOtherSuperAdmins = RoleRepository::countActiveSuperAdmins($db, excludeUserId: $userId);

        if ($remainingOtherSuperAdmins === 0) {
            if ($method === 'DELETE') {
                throw new Exception('Nem törölhető az utolsó aktív Super Admin felhasználó.');
            }
            if ($method === 'PATCH' && InputSanitizer::boolean($data['lock'] ?? false)) {
                throw new Exception('Nem zárolható az utolsó aktív Super Admin felhasználó.');
            }
        }
    }

    if ($method === 'PUT') {
        // UPDATE USER - Sanitize all input data
        $sanitizedData = InputSanitizer::userUpdateData($data);
        
        if (empty($sanitizedData)) {
            throw new Exception('No valid update data provided');
        }
        
        if (UserRepository::update($userId, $sanitizedData)) {
            // Dispatch webhook event for user updated (async)
            try {
                $targetUser = UserRepository::findById($userId);
                $webhookService = new WebhookService();
                $webhookService->dispatchEventAsync('user.updated', [
                    'user_id' => $targetUser['uuid'] ?? null,
                    'email' => $targetUser['email'] ?? null,
                    'updated_fields' => array_keys($sanitizedData),
                    'updated_by' => $user->uuid ?? null,
                    'timestamp' => date('c'),
                ]);
            } catch (\Exception $e) {
                error_log("Webhook dispatch failed for user.updated: " . $e->getMessage());
            }
            echo json_encode(['success' => true, 'message' => 'User updated successfully']);
        } else {
            throw new Exception('Failed to update user');
        }

    } elseif ($method === 'DELETE') {
        // DELETE USER
        // Get user data before deletion for webhook
        $targetUser = UserRepository::findById($userId);
        
        if (UserRepository::delete($userId)) {
            // Dispatch webhook event for user deleted (async)
            try {
                $webhookService = new WebhookService();
                $webhookService->dispatchEventAsync('user.deleted', [
                    'user_id' => $targetUser['uuid'] ?? null,
                    'email' => $targetUser['email'] ?? null,
                    'deleted_by' => $user->uuid ?? null,
                    'timestamp' => date('c'),
                ]);
            } catch (\Exception $e) {
                error_log("Webhook dispatch failed for user.deleted: " . $e->getMessage());
            }
            echo json_encode(['success' => true, 'message' => 'User deleted successfully']);
        } else {
            throw new Exception('Failed to delete user');
        }

    } elseif ($method === 'PATCH') {
        // TOGGLE LOCK
        if (isset($data['lock'])) {
            $lockStatus = InputSanitizer::boolean($data['lock']);
            
            if (UserRepository::toggleLock($userId, $lockStatus)) {
                echo json_encode(['success' => true, 'message' => 'User lock status updated']);
            } else {
                throw new Exception('Failed to update lock status');
            }
        } else {
            throw new Exception('Lock status (lock: true/false) required');
        }

    } else {
        http_response_code(405);
        echo json_encode(['success' => false, 'error' => 'Method not allowed']);
    }

} catch (Exception $e) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
