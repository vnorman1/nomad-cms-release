<?php
/**
 * NOMAD CMS - Admin API - Form Files (FileStorage library)
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * ENDPOINTS
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *   GET    /api/admin/form-files                     paginated library listing
 *          ?form_slug=X&group=image&search=…&page=1&pageSize=40
 *   GET    /api/admin/form-files?action=stats        totals + per-form breakdown
 *   GET    /api/admin/form-files?action=quota&form_slug=X    one form's usage
 *   GET    /api/admin/form-files?uuid=…              DOWNLOAD the file itself
 *          &disposition=inline                      (for image previews)
 *   GET    /api/admin/form-files?submission_id=123   attachments of a submission
 *
 *   DELETE /api/admin/form-files?uuid=…              delete one attachment
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * PERMISSIONS
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *   list / metadata     forms:read:*  (or forms:list:*)
 *   DOWNLOAD content    forms:read:*  AND, for an attachment of an ENCRYPTED
 *                       form, forms:decrypt:*
 *   delete              forms:delete:*
 *
 * WHY DOWNLOAD NEEDS forms:decrypt FOR ENCRYPTED FORMS:
 * The whole point of encrypting a form is that administering it and reading the
 * personal data in it are separate privileges. A CV attached to an encrypted
 * application form is personal data of exactly the kind the values are, so it
 * follows the same rule - otherwise the padlock would be trivially bypassable by
 * downloading the attachment instead of reading the fields.
 *
 * Every download and every delete writes an audit entry with ids and filenames
 * only. The FILE CONTENT never goes near the log.
 *
 * @package NomadCMS
 */

declare(strict_types=1);

require_once __DIR__ . '/../../bootstrap.php';

use NomadCMS\Middleware\AuthMiddleware;
use NomadCMS\Middleware\CSRFMiddleware;
use NomadCMS\Middleware\RateLimitMiddleware;
use NomadCMS\Security\InputSanitizer;
use NomadCMS\Services\Forms\FormAuditLog;
use NomadCMS\Services\Forms\FormAttachmentService;
use NomadCMS\Services\Forms\FormCrypto;
use NomadCMS\Services\Forms\FormFileCrypto;
use NomadCMS\Services\Forms\FormFileException;
use NomadCMS\Services\Forms\FormFileRepository;
use NomadCMS\Services\Forms\FormFileStorage;
use NomadCMS\Services\Forms\FormService;
use NomadCMS\Services\Forms\FormSubmissionRepository;
use NomadCMS\Services\Forms\FormsSchema;

handlePreflight();

/**
 * @param array<string, mixed> $payload
 */
function filesJson(int $status, array $payload): never
{
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($payload, JSON_UNESCAPED_UNICODE);
    exit;
}

try {
    $user = AuthMiddleware::requireAuth();
    RateLimitMiddleware::check('admin-form-files', 240, 60);

    $method = strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET');
    $action = isset($_GET['action']) ? (string) $_GET['action'] : null;

    $formSlug = isset($_GET['form_slug']) ? InputSanitizer::slug((string) $_GET['form_slug'], 64) : null;
    $group = isset($_GET['group']) && isset(FormsSchema::UPLOAD_TYPE_GROUPS[(string) $_GET['group']])
        ? (string) $_GET['group']
        : null;
    $search = isset($_GET['search']) ? (string) $_GET['search'] : '';

    $canDecrypt = AuthMiddleware::hasPermission('forms:decrypt:*');

    // =========================================================================
    // GET
    // =========================================================================
    if ($method === 'GET') {
        AuthMiddleware::requireAnyPermission(['forms:read:*', 'forms:list:*']);

        // ── Download / preview one attachment ────────────────────────────────
        if (isset($_GET['uuid'])) {
            $uuid = (string) $_GET['uuid'];
            $file = FormFileRepository::findByUuid($uuid);

            if ($file === null) {
                filesJson(404, ['success' => false, 'error' => 'Nincs ilyen csatolmány.', 'code' => 'NOT_FOUND']);
            }

            // An attachment of an encrypted form is personal data behind the same
            // gate as the submitted values.
            if ($file['encrypted'] && !$canDecrypt) {
                filesJson(403, [
                    'success' => false,
                    'error' => 'Ehhez a csatolmányhoz forms:decrypt jogosultság kell (titkosított űrlap).',
                    'code' => 'DECRYPT_FORBIDDEN',
                ]);
            }

            if ($file['missing']) {
                filesJson(404, [
                    'success' => false,
                    'error' => 'A csatolmány fájlja nem található a tárolóban.',
                    'code' => 'FILE_MISSING',
                ]);
            }

            // Inline only for images, and only when explicitly asked: an inline
            // PDF or HTML-ish payload would be rendered by the browser in our own
            // origin, which is exactly what the type whitelist is trying to avoid.
            $wantsInline = ($_GET['disposition'] ?? '') === 'inline'
                && str_starts_with((string) $file['mime_type'], 'image/');

            $disposition = $wantsInline ? 'inline' : 'attachment';
            $downloadName = (string) $file['original_name'];

            // Audit BEFORE streaming: once the body starts we cannot change the
            // response, and a download that fails halfway still exposed the file.
            FormAuditLog::fileDownload(
                $user,
                (string) $file['uuid'],
                (string) $file['form_slug'],
                $downloadName,
                (bool) $file['encrypted']
            );

            // Streaming means every buffer above us has to go first, otherwise the
            // whole file is accumulated in memory (and RequestLoggerMiddleware
            // would try to log a binary body).
            while (ob_get_level() > 0) {
                ob_end_flush();
            }

            http_response_code(200);
            header('Content-Type: ' . $file['mime_type']);
            // Content-Length comes from the DB, NOT filesize(): for an encrypted
            // attachment the ciphertext on disk is larger than the real content.
            header('Content-Length: ' . (int) $file['size_bytes']);
            header(sprintf(
                '%s; filename="%s"; filename*=UTF-8\'\'%s',
                'Content-Disposition: ' . $disposition,
                // ASCII fallback for old clients; the RFC 5987 form carries the
                // real name. The filename was sanitised on upload, so it cannot
                // contain quotes or newlines to break out of this header.
                preg_replace('/[^\x20-\x7e]/', '_', $downloadName),
                rawurlencode($downloadName)
            ));
            header('X-Content-Type-Options: nosniff');
            // Belt and braces for the inline image case: even if something slipped
            // through the whitelist, nothing may execute.
            header("Content-Security-Policy: default-src 'none'; img-src 'self'; sandbox");
            header('Cache-Control: private, no-store');
            header('X-Robots-Tag: noindex, nofollow');

            try {
                FormFileCrypto::streamToOutput(
                    (string) $file['disk_path'],
                    (bool) $file['encrypted'],
                    fopen('php://output', 'wb')
                );
            } catch (FormFileException $e) {
                // Headers are already sent; all we can do is log and stop.
                error_log('[Forms] Csatolmany letoltes hiba: ' . $e->getMessage());
            }

            exit;
        }

        // ── Attachments of one submission ────────────────────────────────────
        if (isset($_GET['submission_id'])) {
            $submissionId = (int) $_GET['submission_id'];
            $files = FormFileRepository::listBySubmission($submissionId);
            $submissionsById = FormSubmissionRepository::findByIds(array_map(
                static fn(array $f) => (int) $f['submission_id'],
                $files
            ));

            filesJson(200, [
                'success' => true,
                'files' => array_map(
                    static fn(array $f) => formFilesPresent($f, $submissionsById[(int) $f['submission_id']] ?? null, $canDecrypt),
                    $files
                ),
                'can_decrypt' => $canDecrypt,
            ]);
        }

        // ── Stats / quota ────────────────────────────────────────────────────
        if ($action === 'stats') {
            $perForm = FormFileRepository::statsByForm();

            // Enrich with the form's own name and quota so the library can show a
            // usable overview without a second round trip.
            $forms = [];
            foreach (FormService::listAll() as $form) {
                $slug = (string) $form['data']['slug'];
                $uploads = FormService::uploadSettings($form);

                $forms[] = [
                    'slug' => $slug,
                    'name' => (string) $form['data']['name'],
                    'uploads_enabled' => ($uploads['enabled'] ?? false) === true,
                    'files' => $perForm[$slug]['files'] ?? 0,
                    'bytes' => $perForm[$slug]['bytes'] ?? 0,
                    'quota_bytes' => (int) ($uploads['quota_bytes'] ?? FormsSchema::DEFAULT_FORM_QUOTA_BYTES),
                ];
            }

            filesJson(200, [
                'success' => true,
                'total_files' => FormFileRepository::countAll(),
                'total_bytes' => FormFileRepository::sumSizeTotal(),
                'forms' => $forms,
                'groups' => array_keys(FormsSchema::UPLOAD_TYPE_GROUPS),
                'can_decrypt' => $canDecrypt,
            ]);
        }

        if ($action === 'quota') {
            if ($formSlug === null) {
                filesJson(400, ['success' => false, 'error' => 'Hiányzó form_slug.', 'code' => 'MISSING_SLUG']);
            }

            $form = FormService::findBySlug($formSlug);
            if ($form === null) {
                filesJson(404, ['success' => false, 'error' => 'Nincs ilyen űrlap.', 'code' => 'FORM_NOT_FOUND']);
            }

            filesJson(200, ['success' => true, 'quota' => FormAttachmentService::quota($form)]);
        }

        // ── Paginated library listing ────────────────────────────────────────
        $page = isset($_GET['page']) ? max(1, (int) $_GET['page']) : 1;
        $pageSize = isset($_GET['pageSize'])
            ? (int) $_GET['pageSize']
            : FormFileRepository::DEFAULT_PAGE_SIZE;

        $result = FormFileRepository::listPaginated([
            'form_slug' => $formSlug,
            'group' => $group,
            'search' => $search,
            'page' => $page,
            'pageSize' => $pageSize,
        ]);

        // One batch lookup for the whole page's parent submissions, instead of
        // one query per row - the page can hold up to MAX_PAGE_SIZE attachments.
        $submissionsById = FormSubmissionRepository::findByIds(array_map(
            static fn(array $f) => (int) $f['submission_id'],
            $result['items']
        ));

        filesJson(200, [
            'success' => true,
            'files' => array_map(
                static fn(array $f) => formFilesPresent($f, $submissionsById[(int) $f['submission_id']] ?? null, $canDecrypt),
                $result['items']
            ),
            'pagination' => [
                'total' => $result['total'],
                'page' => $result['page'],
                'pageSize' => $result['pageSize'],
                'totalPages' => $result['totalPages'],
            ],
            'can_decrypt' => $canDecrypt,
        ]);
    }

    // =========================================================================
    // DELETE
    // =========================================================================
    if ($method === 'DELETE') {
        AuthMiddleware::requirePermission('forms:delete:*');
        // validateForSession(), not validate(): a Bearer JWT is inherently
        // CSRF-safe (a browser will not attach it cross-site), and this is the
        // convention every other admin endpoint here follows. Using validate()
        // would reject every legitimate token-authenticated call.
        CSRFMiddleware::validateForSession();

        $uuid = isset($_GET['uuid']) ? (string) $_GET['uuid'] : '';
        $file = FormFileRepository::findByUuid($uuid);

        if ($file === null) {
            filesJson(404, ['success' => false, 'error' => 'Nincs ilyen csatolmány.', 'code' => 'NOT_FOUND']);
        }

        FormAuditLog::fileDeleted(
            $user,
            (string) $file['uuid'],
            (string) $file['form_slug'],
            (string) $file['original_name'],
            (int) $file['size_bytes']
        );

        $deleted = FormFileRepository::deleteByUuid($uuid);
        FormFileStorage::pruneEmptyBuckets();

        filesJson(200, [
            'success' => $deleted,
            'deleted' => $deleted,
            'bytes_freed' => (int) $file['size_bytes'],
        ]);
    }

    filesJson(405, ['success' => false, 'error' => 'Nem támogatott metódus.', 'code' => 'METHOD_NOT_ALLOWED']);
} catch (FormFileException $e) {
    filesJson($e->getStatusCode(), [
        'success' => false,
        'error' => $e->getMessage(),
        'code' => $e->getErrorCode(),
    ]);
} catch (Throwable $e) {
    error_log('[Forms] admin/form-files hiba: ' . $e->getMessage());
    filesJson(500, [
        'success' => false,
        'error' => 'Váratlan hiba a csatolmányok kezelése során.',
        'code' => 'INTERNAL_ERROR',
    ]);
}

/**
 * Public projection of an attachment row.
 *
 * disk_path is deliberately NOT exposed: it is an internal detail, and handing
 * out storage paths invites someone to try requesting them directly.
 *
 * @param array<string, mixed> $file
 * @param array<string, mixed>|null $submission Parent submission row (hydrated,
 *        i.e. {id, data, created_at, updated_at}), or null if it vanished
 * @return array<string, mixed>
 */
function formFilesPresent(array $file, ?array $submission, bool $canDecrypt): array
{
    $submissionUuid = null;
    $submitter = null;

    if ($submission !== null) {
        $data = $submission['data'] ?? [];
        $submissionUuid = isset($data['uuid']) && is_string($data['uuid']) ? $data['uuid'] : null;
        $submitter = resolveSubmitterLabel($data, $canDecrypt);
    }

    return [
        'uuid' => $file['uuid'],
        'submission_id' => $file['submission_id'],
        // The submission's own UUID, so the card can link straight to THAT
        // submission (see FormsPage's openSubmissionUuid deep-link handling)
        // instead of just the form's inbox in general. Null when the parent
        // submission was deleted but the attachment row survived, or predates
        // the uuid field.
        'submission_uuid' => $submissionUuid,
        // A short "who sent this" label (typically the email/name field), so
        // the library does not need a second round trip just to show who a
        // card belongs to. Withheld for an encrypted form's attachments unless
        // the caller holds forms:decrypt - it is exactly the same personal
        // data the submission's own values are guarded by, and showing it here
        // would bypass that gate.
        'submitter' => $submitter,
        'form_slug' => $file['form_slug'],
        'original_name' => $file['original_name'],
        'extension' => $file['extension'],
        'mime_type' => $file['mime_type'],
        'size_bytes' => $file['size_bytes'],
        'encrypted' => $file['encrypted'],
        'group' => $file['group'],
        'field_name' => $file['field_name'],
        'created_at' => $file['created_at'],
        'missing' => $file['missing'],
    ];
}

/**
 * Pick one human-identifying value out of a submission's envelope to show as
 * "who sent this" on an attachment card - preferring an email/name-shaped key,
 * falling back to the first non-empty scalar so a form with no email field
 * still shows something better than "Beküldés #123".
 *
 * @param array<string, mixed> $envelope
 */
function resolveSubmitterLabel(array $envelope, bool $canDecrypt): ?string
{
    $encrypted = (bool) ($envelope['encrypted'] ?? false);

    if ($encrypted && !$canDecrypt) {
        return null; // Masked, same as the submission's own values.
    }

    if ($encrypted) {
        try {
            $values = FormCrypto::openValues((string) ($envelope['values_encrypted'] ?? ''));
        } catch (\Throwable) {
            return null; // Same "decrypt failed" fate as the submission itself.
        }
    } else {
        $values = is_array($envelope['values'] ?? null) ? $envelope['values'] : [];
    }

    if (!is_array($values) || empty($values)) {
        return null;
    }

    // Prefer a field that LOOKS like an email/name over the first key in
    // insertion order, since "utm_source" is a worse identifier than "email"
    // even if it happens to be submitted first.
    foreach (['email', 'e-mail', 'name', 'nev', 'full_name', 'fullname'] as $preferred) {
        foreach ($values as $key => $value) {
            if (strtolower((string) $key) === $preferred && is_scalar($value) && trim((string) $value) !== '') {
                return trim((string) $value);
            }
        }
    }

    foreach ($values as $value) {
        if (is_scalar($value) && trim((string) $value) !== '') {
            return trim((string) $value);
        }
    }

    return null;
}
