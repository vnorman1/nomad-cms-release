<?php
/**
 * NOMAD CMS - Admin API - Form Captcha Configuration
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * ENDPOINTS
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *   GET  /api/admin/form-captcha?slug=X    per-form config (masked) + global
 *                                          providers (masked) + provider registry
 *   POST /api/admin/form-captcha           save per-form and/or global config
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * POST BODY
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *   {
 *     "slug": "kapcsolat",                 required
 *     "provider": "turnstile",             none|turnstile|recaptcha_v2|recaptcha_v3
 *     "use_custom_keys": false,
 *     "site_key": "...",                   only meaningful when use_custom_keys
 *     "secret_key": "...",                 PLAINTEXT, only when use_custom_keys.
 *                                          Omitted/empty = leave the existing
 *                                          secret unchanged. clear_secret=true
 *                                          is required to blank it.
 *     "clear_secret": false,
 *
 *     "global": {                          optional: also update a GLOBAL
 *       "provider": "turnstile",           provider's shared key pair
 *       "site_key": "...",
 *       "secret_key": "...",
 *       "clear_secret": false
 *     }
 *   }
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * WHY NEVER A RAW SECRET IN ANY RESPONSE
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * The GET response and the POST response both only ever expose
 * {site_key, secret_key_set, secret_key_last4} - see
 * CaptchaConfigStore::maskedFormConfig()/maskedProvider(). The plaintext
 * secret exists only inside api/external/captcha.json (Defuse-encrypted) and
 * in memory for the duration of a siteverify call. It never round-trips
 * through this endpoint.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * PERMISSIONS
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *   GET (read masked state)   forms:read:*  (forms:list:* also accepted)
 *   POST (save config)        forms:update:*
 *
 * Every save writes a FormAuditLog entry (provider + which flags changed -
 * never the key value itself, same rule as every other audit entry in this
 * module).
 *
 * @package NomadCMS
 */

declare(strict_types=1);

require_once __DIR__ . '/../../bootstrap.php';

use NomadCMS\Middleware\AuthMiddleware;
use NomadCMS\Middleware\CSRFMiddleware;
use NomadCMS\Middleware\RateLimitMiddleware;
use NomadCMS\Security\InputSanitizer;
use NomadCMS\Services\Forms\CaptchaConfigStore;
use NomadCMS\Services\Forms\CaptchaException;
use NomadCMS\Services\Forms\CaptchaProviderRegistry;
use NomadCMS\Services\Forms\FormAuditLog;
use NomadCMS\Services\Forms\FormNotFoundException;
use NomadCMS\Services\Forms\FormService;
use NomadCMS\Services\Forms\FormValidationException;

handlePreflight();
header('Content-Type: application/json; charset=utf-8');

/**
 * @param array<string, mixed> $payload
 */
function captchaAdminJson(int $status, array $payload): never
{
    http_response_code($status);
    echo json_encode($payload, JSON_UNESCAPED_UNICODE);
    exit;
}

/**
 * @return array<string, mixed>
 */
function captchaAdminBody(): array
{
    $raw = file_get_contents('php://input');
    $decoded = json_decode($raw === false ? '' : $raw, true);

    return is_array($decoded) ? $decoded : [];
}

/**
 * Registry projection for the frontend: everything needed to render a
 * provider picker and build embed markup, nothing an operator would need to
 * hand-edit through the UI (this is providers.php's job, on purpose).
 *
 * @return array<string, array<string, mixed>>
 */
function captchaRegistryProjection(): array
{
    $projection = [];
    foreach (CaptchaProviderRegistry::PROVIDERS as $provider) {
        $projection[$provider] = [
            'label' => CaptchaProviderRegistry::label($provider),
            'script_url' => CaptchaProviderRegistry::scriptUrl($provider),
            'widget_class' => CaptchaProviderRegistry::widgetClass($provider),
            'token_field' => CaptchaProviderRegistry::tokenField($provider),
            'min_score' => CaptchaProviderRegistry::minScore($provider),
        ];
    }

    return $projection;
}

/**
 * @return array<string, array<string, mixed>>
 */
function captchaGlobalProjection(): array
{
    $projection = [];
    foreach (CaptchaProviderRegistry::PROVIDERS as $provider) {
        $projection[$provider] = CaptchaConfigStore::maskedProvider($provider);
    }

    return $projection;
}

try {
    $user = AuthMiddleware::requireAuth();
    RateLimitMiddleware::check('admin-form-captcha', 120, 60);

    $method = strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET');
    $slugParam = isset($_GET['slug']) ? InputSanitizer::slug((string) $_GET['slug'], 64) : null;

    // =========================================================================
    // GET
    // =========================================================================
    if ($method === 'GET') {
        AuthMiddleware::requireAnyPermission(['forms:read:*', 'forms:list:*']);

        // A slug is OPTIONAL on GET: the standalone global "Biztonság" page
        // (/forms/security) only ever needs the `providers`/`registry`
        // blocks, which are identical regardless of which form (if any) is
        // asked about. Omitting the slug entirely - rather than requiring a
        // throwaway one - keeps that page from depending on any form existing
        // at all.
        if ($slugParam === null) {
            captchaAdminJson(200, [
                'success' => true,
                'form' => null,
                'providers' => captchaGlobalProjection(),
                'registry' => captchaRegistryProjection(),
            ]);
        }

        // Confirms the form exists (404 otherwise) without ever touching the
        // captcha store for a slug that has no corresponding form.
        FormService::requireBySlug($slugParam);

        captchaAdminJson(200, [
            'success' => true,
            'form' => CaptchaConfigStore::maskedFormConfig($slugParam),
            'providers' => captchaGlobalProjection(),
            'registry' => captchaRegistryProjection(),
        ]);
    }

    // =========================================================================
    // MUTATIONS - CSRF for every write, like every other admin endpoint
    // =========================================================================
    CSRFMiddleware::validateForSession();

    if ($method === 'POST') {
        AuthMiddleware::requirePermission('forms:update:*');

        $body = captchaAdminBody();
        $slugInput = $slugParam ?? (isset($body['slug']) ? (string) $body['slug'] : '');
        $slug = $slugInput !== '' ? InputSanitizer::slug($slugInput, 64) : null;

        // A slug is only REQUIRED when the request also touches a per-form
        // override. A request that carries ONLY a `global` block (the global
        // "Biztonság" page, which has no form to scope to) must be able to
        // update a provider's shared key pair without pretending to also be
        // about some specific, unrelated form - sending a per-form payload
        // just to reach this code would risk silently overwriting that
        // form's own override.
        $touchesPerForm = array_key_exists('provider', $body) || array_key_exists('use_custom_keys', $body);

        if ($touchesPerForm) {
            if ($slug === null) {
                captchaAdminJson(400, ['success' => false, 'error' => 'Hiányzó slug paraméter.']);
            }

            // Confirms the form exists before writing anything into
            // captcha.json under its slug - otherwise a typo'd slug would
            // silently create an orphaned entry nothing ever reads.
            FormService::requireBySlug($slug);

            $provider = is_string($body['provider'] ?? null) ? $body['provider'] : 'none';
            $useCustomKeys = (bool) ($body['use_custom_keys'] ?? false);
            $siteKey = isset($body['site_key']) && is_string($body['site_key']) && $body['site_key'] !== ''
                ? $body['site_key']
                : null;
            $secretKey = isset($body['secret_key']) && is_string($body['secret_key']) && $body['secret_key'] !== ''
                ? $body['secret_key']
                : null;
            $clearSecret = (bool) ($body['clear_secret'] ?? false);

            CaptchaConfigStore::setFormConfig($slug, $provider, $useCustomKeys, $siteKey, $secretKey, $clearSecret);
        } else {
            $provider = null;
            $useCustomKeys = false;
        }

        // Optional: also update a GLOBAL provider's shared key pair in the
        // same request. Used both by the per-form "Biztonság" tab (saving
        // alongside a per-form choice) and by the standalone global
        // "Biztonság" page (slug-less, provider/use_custom_keys absent above).
        $globalChanged = null;
        if (is_array($body['global'] ?? null)) {
            $global = $body['global'];
            $globalProvider = is_string($global['provider'] ?? null) ? $global['provider'] : null;

            if ($globalProvider !== null && in_array($globalProvider, CaptchaProviderRegistry::PROVIDERS, true)) {
                $globalSiteKey = isset($global['site_key']) && is_string($global['site_key']) && $global['site_key'] !== ''
                    ? $global['site_key']
                    : null;
                $globalSecretKey = isset($global['secret_key']) && is_string($global['secret_key']) && $global['secret_key'] !== ''
                    ? $global['secret_key']
                    : null;
                $globalClearSecret = (bool) ($global['clear_secret'] ?? false);

                CaptchaConfigStore::setGlobalProvider($globalProvider, $globalSiteKey, $globalSecretKey, $globalClearSecret);
                $globalChanged = $globalProvider;
            }
        }

        if (!$touchesPerForm && $globalChanged === null) {
            captchaAdminJson(400, [
                'success' => false,
                'error' => 'A kérés nem tartalmaz sem per-form, sem globális captcha adatot.',
            ]);
        }

        FormAuditLog::captchaChanged($user, $slug, $provider ?? 'none', $useCustomKeys, $globalChanged);

        captchaAdminJson(200, [
            'success' => true,
            'form' => $slug !== null ? CaptchaConfigStore::maskedFormConfig($slug) : null,
            'providers' => captchaGlobalProjection(),
            'registry' => captchaRegistryProjection(),
        ]);
    }

    header('Allow: GET, POST');
    captchaAdminJson(405, ['success' => false, 'error' => 'Nem támogatott metódus.', 'code' => 'METHOD_NOT_ALLOWED']);
} catch (FormNotFoundException $e) {
    captchaAdminJson(404, ['success' => false, 'error' => $e->getMessage()]);
} catch (FormValidationException $e) {
    captchaAdminJson(422, ['success' => false, 'error' => $e->getMessage(), 'errors' => $e->getErrors()]);
} catch (CaptchaException $e) {
    captchaAdminJson($e->getStatusCode(), [
        'success' => false,
        'error' => $e->getMessage(),
        'code' => $e->getErrorCode(),
    ]);
} catch (Throwable $e) {
    error_log('[Forms] admin/form-captcha hiba: ' . $e->getMessage());
    captchaAdminJson(500, [
        'success' => false,
        'error' => 'Váratlan hiba a captcha beállítások kezelése során.',
        'code' => 'INTERNAL_ERROR',
    ]);
}
