<?php
/**
 * NOMAD CMS - Cache Rebuild Endpoint
 * 
 * Admin-only endpoint to rebuild all static cache files.
 * Useful after database restore, migration, or manual data changes.
 * 
 * POST /api/endpoints/admin/cache-rebuild.php              Rebuild everything
 * POST /api/endpoints/admin/cache-rebuild.php?clear=1      Clear then rebuild
 * POST /api/endpoints/admin/cache-rebuild.php?action=purge Sweep orphaned files
 *                                                           (manifest-driven,
 *                                                           no DB query, safe
 *                                                           to run any time —
 *                                                           see purgeOrphanedFiles())
 * POST ...&action=purge&slot=projects                      Purge one slot only
 * 
 * Response (rebuild):
 * {
 *   "success": true,
 *   "message": "Rebuilt 42 cache files",
 *   "count": 42,
 *   "errors": 0,
 *   "purged": 3,
 *   "stats": { ... }
 * }
 *
 * A concurrent rebuild returns success:false with `locked: true` — this must be
 * surfaced as an error, never treated as "nothing to do".
 */

declare(strict_types=1);

require_once __DIR__ . '/../../bootstrap.php';

use NomadCMS\Middleware\AuthMiddleware;
use NomadCMS\Middleware\CSRFMiddleware;
use NomadCMS\Services\StaticCacheService;

// Handle CORS preflight
handlePreflight();

header('Content-Type: application/json');

// Only POST allowed
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Method not allowed']);
    exit;
}

// Require admin authentication
try {
    CSRFMiddleware::validateForSession();
    AuthMiddleware::requireAuth();
    AuthMiddleware::requirePermission('system:manage:*');
} catch (\Exception $e) {
    http_response_code(401);
    echo json_encode(['success' => false, 'error' => 'Unauthorized']);
    exit;
}

$action = $_GET['action'] ?? null;

// --- Orphan purge: file-only sweep, independent of the rebuild lock --------
if ($action === 'purge') {
    $slot = $_GET['slot'] ?? null;
    $slot = is_string($slot) && $slot !== '' ? $slot : null;

    try {
        $result = StaticCacheService::purgeOrphanedFiles($slot);
        echo json_encode([
            'success' => true,
            'message' => "Purged {$result['deleted']} orphaned file(s)",
            'deleted' => $result['deleted'],
            'scanned_slots' => $result['scanned_slots'],
            'deleted_files' => $result['deleted_files'],
        ], JSON_UNESCAPED_UNICODE);
    } catch (\Exception $e) {
        http_response_code(500);
        echo json_encode([
            'success' => false,
            'error' => ($_ENV['APP_DEBUG'] ?? 'false') === 'true'
                ? $e->getMessage()
                : 'Orphan purge failed',
        ]);
    }
    exit;
}

// Check for optional clear parameter
$clearFirst = ($_GET['clear'] ?? '') === '1';

try {
    // Optionally clear all cache first
    if ($clearFirst) {
        $cleared = StaticCacheService::clearAll();
        error_log("[CacheRebuild] Cleared {$cleared} cache files");
    }
    
    // Rebuild all caches (supports ?concurrency=1..4)
    $concurrency = isset($_GET['concurrency']) ? max(1, min(4, (int)$_GET['concurrency'])) : 1;
    $result = StaticCacheService::rebuildAll($concurrency);

    // A lock timeout touched NOTHING - this must read as a failure, not as a
    // rebuild that legitimately found zero changes.
    if (!empty($result['locked'])) {
        http_response_code(409);
        echo json_encode([
            'success' => false,
            'error' => $result['message'] ?? 'Another cache rebuild is already running.',
            'locked' => true,
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }
    
    // Get updated stats
    $stats = StaticCacheService::getStats();
    
    echo json_encode([
        'success' => true,
        'message' => "Rebuilt {$result['count']} cache files",
        'count' => $result['count'],
        'errors' => $result['errors'],
        'purged' => $result['purged'] ?? 0,
        'cleared' => $clearFirst ? ($cleared ?? 0) : null,
        'stats' => $stats,
        'pending' => StaticCacheService::getPendingStatus(),
    ], JSON_UNESCAPED_UNICODE);
    
} catch (\Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => ($_ENV['APP_DEBUG'] ?? 'false') === 'true' 
            ? $e->getMessage() 
            : 'Cache rebuild failed',
    ]);
}
