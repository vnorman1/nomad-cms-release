<?php

/**
 * NOMAD CMS - Notification catalogue and operational status endpoint.
 * Exposes installed event contracts, channel names and queue health to permitted admins.
 * Does not expose event payloads, personal inboxes or transport secrets.
 */

declare(strict_types=1);

require_once __DIR__ . '/../../bootstrap.php';
handlePreflight();
\NomadCMS\Services\NotificationService\HttpController::dispatch('events');
