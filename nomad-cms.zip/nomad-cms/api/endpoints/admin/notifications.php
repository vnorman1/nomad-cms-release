<?php

/**
 * NOMAD CMS - Administrator notification submission endpoint.
 * Exposes capabilities, preview, durable send and authorized submission history.
 * Administrator identities are taken exclusively from backend authentication.
 */

declare(strict_types=1);

require_once __DIR__ . '/../../bootstrap.php';
handlePreflight();
\NomadCMS\Services\NotificationService\HttpController::dispatch('admin');
