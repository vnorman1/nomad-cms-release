<?php

/**
 * NOMAD CMS - Notification destination endpoint.
 * Manages references to installed delivery channels and preconfigured transports.
 * Direct destination URLs and transport credentials are not accepted here.
 */

declare(strict_types=1);

require_once __DIR__ . '/../../bootstrap.php';
handlePreflight();
\NomadCMS\Services\NotificationService\HttpController::dispatch('destinations');
