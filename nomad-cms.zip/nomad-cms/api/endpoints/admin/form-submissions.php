<?php
/**
 * NOMAD CMS - Admin API - Form Submissions (Inbox)
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * ENDPOINTS
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *   GET    /api/admin/form-submissions                       paginated list
 *          ?form_slug=X&status=unread&search=…&page=1&pageSize=25&dir=desc
 *   GET    /api/admin/form-submissions?id=123                single submission
 *          &mark_read=1                                      also flip unread -> read
 *   GET    /api/admin/form-submissions?action=stats           status counters
 *   GET    /api/admin/form-submissions?export=csv             CSV export
 *
 *   POST   /api/admin/form-submissions?action=status          { id, status }
 *   POST   /api/admin/form-submissions?action=bulk-status     { ids[], status }
 *   POST   /api/admin/form-submissions?action=bulk-delete     { ids[] }
 *   POST   /api/admin/form-submissions?action=erase           { id }
 *   DELETE /api/admin/form-submissions?id=123
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * PERMISSIONS
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *   read/list          forms:read:*  (or forms:list:*)
 *   values (encrypted) forms:decrypt:*   -> otherwise values come back MASKED
 *   status change      forms:update:*
 *   delete / erase     forms:delete:*
 *   CSV export         forms:export:*  (+ forms:decrypt:* to include real values
 *                                        of an encrypted form)
 *
 * Every operation that actually exposes or destroys personal data writes an
 * audit entry (FormAuditLog) containing ids and counts only - never the values,
 * which would move the personal data straight into a plaintext log file.
 *
 * @package NomadCMS
 */

declare(strict_types=1);

require_once __DIR__ . '/../../bootstrap.php';

use NomadCMS\Middleware\AuthMiddleware;
use NomadCMS\Middleware\CSRFMiddleware;
use NomadCMS\Middleware\RateLimitMiddleware;
use NomadCMS\Security\InputSanitizer;
use NomadCMS\Services\Forms\FormAuditLog;
use NomadCMS\Services\Forms\FormNotFoundException;
use NomadCMS\Services\Forms\FormSubmissionRepository;
use NomadCMS\Services\Forms\FormSubmissionService;
use NomadCMS\Services\Forms\FormService;
use NomadCMS\Services\Forms\FormValidationException;
use NomadCMS\Services\Forms\FormsSchema;

handlePreflight();

/**
 * @param array<string, mixed> $payload
 */
function submissionsJson(int $status, array $payload): never
{
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($payload, JSON_UNESCAPED_UNICODE);
    exit;
}

/**
 * @return array<string, mixed>
 */
function submissionsBody(): array
{
    $raw = file_get_contents('php://input');
    $decoded = json_decode($raw === false ? '' : $raw, true);

    return is_array($decoded) ? $decoded : [];
}

/**
 * @param mixed $input
 * @return array<int, int>
 */
function submissionsIds(mixed $input): array
{
    if (is_string($input)) {
        $input = explode(',', $input);
    }
    if (!is_array($input)) {
        return [];
    }

    $ids = [];
    foreach ($input as $value) {
        if (is_numeric($value)) {
            $id = (int) $value;
            if ($id > 0) {
                $ids[] = $id;
            }
        }
    }

    // Bound the batch so one request cannot ask for unbounded work
    return array_slice(array_values(array_unique($ids)), 0, 500);
}

try {
    $user = AuthMiddleware::requireAuth();
    RateLimitMiddleware::check('admin-form-submissions', 240, 60);

    $method = strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET');
    $action = isset($_GET['action']) ? (string) $_GET['action'] : null;

    $formSlug = isset($_GET['form_slug']) ? InputSanitizer::slug((string) $_GET['form_slug'], 64) : null;
    $status = isset($_GET['status']) && in_array($_GET['status'], FormsSchema::STATUSES, true)
        ? (string) $_GET['status']
        : null;
    $search = isset($_GET['search']) ? (string) $_GET['search'] : '';

    // Single source of truth for the decrypt decision in this request.
    $canDecrypt = AuthMiddleware::hasPermission('forms:decrypt:*');

    // =========================================================================
    // GET
    // =========================================================================
    if ($method === 'GET') {
        AuthMiddleware::requireAnyPermission(['forms:read:*', 'forms:list:*']);

        // ── Stats ────────────────────────────────────────────────────────────
        if ($action === 'stats') {
            submissionsJson(200, [
                'success' => true,
                'stats' => FormSubmissionService::statusCounts($formSlug),
                'can_decrypt' => $canDecrypt,
            ]);
        }

        // ── CSV export ───────────────────────────────────────────────────────
        if (($_GET['export'] ?? null) === 'csv') {
            AuthMiddleware::requirePermission('forms:export:*');

            $filename = 'nomad-form-submissions-' . ($formSlug ?? 'all') . '-' . gmdate('Ymd-His') . '.csv';

            // Counted BEFORE streaming starts, because headers cannot be sent
            // once the first CSV byte is out. Cheap now that the filter columns
            // are indexed (measured 0.3 ms on 365k rows), and it keeps the
            // X-Nomad-Export-Rows contract the admin UI relies on.
            $expectedRows = FormSubmissionService::countForExport([
                'form_slug' => $formSlug,
                'status' => $status,
                'search' => $search,
            ]);

            http_response_code(200);
            header('Content-Type: text/csv; charset=utf-8');
            header('Content-Disposition: attachment; filename="' . $filename . '"');
            header('Cache-Control: no-store');
            header('X-Nomad-Export-Rows: ' . $expectedRows);
            // Tells the UI whether the downloaded file contains personal data in
            // the clear, so it can warn the user at the right moment.
            header('X-Nomad-Export-Decrypted: ' . ($canDecrypt ? '1' : '0'));

            // The export is STREAMED, so every output buffer above us has to go
            // first. RequestLoggerMiddleware wraps each request in ob_start() to
            // capture the response body for the log; leaving it in place would
            // accumulate the entire CSV in memory again - defeating the whole
            // point of streaming - and would also try to JSON-decode a multi-MB
            // CSV when logging.
            while (ob_get_level() > 0) {
                ob_end_flush();
            }

            $export = FormSubmissionService::streamCsv([
                'form_slug' => $formSlug,
                'status' => $status,
                'search' => $search,
            ], $canDecrypt);

            // Audited after the fact: the row count is only known once streamed.
            // A header cannot be used for it either, since headers are long gone.
            FormAuditLog::export($user, $formSlug, $export['rows'], $canDecrypt);

            exit;
        }

        // ── Single submission by UUID (deep link) ────────────────────────────
        // Separate from the id lookup: a shared link must resolve regardless of
        // which page the row currently sits on.
        if (isset($_GET['uuid'])) {
            $item = FormSubmissionService::getByUuid((string) $_GET['uuid'], $canDecrypt);

            if ($item === null) {
                submissionsJson(404, [
                    'success' => false,
                    'error' => 'Nincs ilyen beküldés.',
                    'code' => 'NOT_FOUND',
                ]);
            }

            if ($item['encrypted'] && !$item['masked']) {
                FormAuditLog::decrypt($user, $item['form_slug'], [(int) $item['id']]);
            }

            submissionsJson(200, [
                'success' => true,
                'submission' => $item,
                'can_decrypt' => $canDecrypt,
            ]);
        }

        // ── Single submission ────────────────────────────────────────────────
        if (isset($_GET['id'])) {
            $id = (int) $_GET['id'];
            $item = FormSubmissionService::getById($id, $canDecrypt);

            if ($item === null) {
                submissionsJson(404, ['success' => false, 'error' => 'Nincs ilyen beküldés.', 'code' => 'NOT_FOUND']);
            }

            // Optional convenience for the detail modal: opening an unread
            // submission marks it read. Requires update permission, and never
            // fails the read if the caller lacks it.
            if (($_GET['mark_read'] ?? null) === '1'
                && $item['status'] === FormsSchema::STATUS_UNREAD
                && AuthMiddleware::hasPermission('forms:update:*')
            ) {
                FormSubmissionService::setStatus($id, FormsSchema::STATUS_READ);
                $item['status'] = FormsSchema::STATUS_READ;
            }

            if ($item['encrypted'] && !$item['masked']) {
                FormAuditLog::decrypt($user, $item['form_slug'], [$id]);
            }

            submissionsJson(200, ['success' => true, 'submission' => $item, 'can_decrypt' => $canDecrypt]);
        }

        // ── List ─────────────────────────────────────────────────────────────
        $result = FormSubmissionService::list([
            'form_slug' => $formSlug,
            'status' => $status,
            'search' => $search,
            'page' => isset($_GET['page']) ? (int) $_GET['page'] : 1,
            'pageSize' => isset($_GET['pageSize']) ? (int) $_GET['pageSize'] : null,
            'dir' => $_GET['dir'] ?? 'desc',
        ], $canDecrypt);

        // Audit only when encrypted rows were actually revealed - logging every
        // plaintext page view would bury the events that matter.
        $decryptedIds = [];
        foreach ($result['items'] as $item) {
            if ($item['encrypted'] && !$item['masked']) {
                $decryptedIds[] = $item['id'];
            }
        }
        if (!empty($decryptedIds)) {
            FormAuditLog::decrypt($user, $formSlug, $decryptedIds);
        }

        submissionsJson(200, [
            'success' => true,
            'submissions' => $result['items'],
            'pagination' => [
                'total' => $result['total'],
                'page' => $result['page'],
                'pageSize' => $result['pageSize'],
                'totalPages' => $result['totalPages'],
            ],
            'search_mode' => $result['search_mode'],
            'stats' => FormSubmissionService::statusCounts($formSlug),
            'can_decrypt' => $canDecrypt,
        ]);
    }

    // =========================================================================
    // MUTATIONS
    // =========================================================================
    CSRFMiddleware::validateForSession();

    if ($method === 'POST') {
        $body = submissionsBody();

        if ($action === 'status') {
            AuthMiddleware::requirePermission('forms:update:*');

            $id = isset($body['id']) && is_numeric($body['id']) ? (int) $body['id'] : 0;
            $newStatus = is_string($body['status'] ?? null) ? $body['status'] : '';

            if ($id <= 0) {
                submissionsJson(400, ['success' => false, 'error' => 'Hiányzó beküldés azonosító.']);
            }

            FormSubmissionService::setStatus($id, $newStatus);
            submissionsJson(200, ['success' => true, 'id' => $id, 'status' => $newStatus]);
        }

        if ($action === 'bulk-status') {
            AuthMiddleware::requirePermission('forms:update:*');

            $ids = submissionsIds($body['ids'] ?? []);
            $newStatus = is_string($body['status'] ?? null) ? $body['status'] : '';

            if (empty($ids)) {
                submissionsJson(400, ['success' => false, 'error' => 'Nincs kijelölt beküldés.']);
            }

            $changed = FormSubmissionService::bulkSetStatus($ids, $newStatus);
            submissionsJson(200, ['success' => true, 'changed' => $changed, 'status' => $newStatus]);
        }

        if ($action === 'bulk-status-filters') {
            AuthMiddleware::requirePermission('forms:update:*');

            $filterFormSlug = isset($body['form_slug']) && is_string($body['form_slug']) && $body['form_slug'] !== ''
                ? InputSanitizer::slug((string) $body['form_slug'], 64)
                : null;
            $filterStatus = isset($body['status_filter']) && in_array($body['status_filter'], FormsSchema::STATUSES, true)
                ? (string) $body['status_filter']
                : null;
            $newStatus = isset($body['new_status']) && is_string($body['new_status']) ? $body['new_status'] : '';
            $filterSearch = isset($body['search']) ? (string) $body['search'] : '';

            // Build match expression for search
            $form = $filterFormSlug !== null ? FormService::findBySlug($filterFormSlug) : null;
            $matchInfo = FormSubmissionService::buildMatch($filterSearch, $form);

            // Get all matching IDs (without pagination)
            $criteria = [
                'form_slug' => $filterFormSlug,
                'status' => $filterStatus,
                'match' => $matchInfo['expression'],
            ];

            $ids = FormSubmissionRepository::getMatchingIds($criteria);

            if (empty($ids)) {
                submissionsJson(200, ['success' => true, 'changed' => 0, 'status' => $newStatus]);
            }

            $changed = FormSubmissionService::bulkSetStatus($ids, $newStatus);
            submissionsJson(200, ['success' => true, 'changed' => $changed, 'status' => $newStatus]);
        }

        if ($action === 'bulk-delete') {
            AuthMiddleware::requirePermission('forms:delete:*');

            $ids = submissionsIds($body['ids'] ?? []);
            if (empty($ids)) {
                submissionsJson(400, ['success' => false, 'error' => 'Nincs kijelölt beküldés.']);
            }

            $deleted = FormSubmissionService::bulkErase($ids);
            FormAuditLog::erase($user, $formSlug, $ids);

            submissionsJson(200, ['success' => true, 'deleted' => $deleted]);
        }

        if ($action === 'bulk-delete-filters') {
            AuthMiddleware::requirePermission('forms:delete:*');

            $filterFormSlug = isset($body['form_slug']) && is_string($body['form_slug']) && $body['form_slug'] !== ''
                ? InputSanitizer::slug((string) $body['form_slug'], 64)
                : null;
            $filterStatus = isset($body['status']) && in_array($body['status'], FormsSchema::STATUSES, true)
                ? (string) $body['status']
                : null;
            $filterSearch = isset($body['search']) ? (string) $body['search'] : '';

            // Build match expression for search
            $form = $filterFormSlug !== null ? FormService::findBySlug($filterFormSlug) : null;
            $matchInfo = FormSubmissionService::buildMatch($filterSearch, $form);

            // Get all matching IDs (without pagination)
            $criteria = [
                'form_slug' => $filterFormSlug,
                'status' => $filterStatus,
                'match' => $matchInfo['expression'],
            ];

            $ids = FormSubmissionRepository::getMatchingIds($criteria);

            if (empty($ids)) {
                submissionsJson(200, ['success' => true, 'deleted' => 0]);
            }

            $deleted = FormSubmissionService::bulkErase($ids);
            FormAuditLog::erase($user, $filterFormSlug, $ids);

            submissionsJson(200, ['success' => true, 'deleted' => $deleted]);
        }

        if ($action === 'erase') {
            AuthMiddleware::requirePermission('forms:delete:*');

            $id = isset($body['id']) && is_numeric($body['id']) ? (int) $body['id'] : 0;
            if ($id <= 0) {
                submissionsJson(400, ['success' => false, 'error' => 'Hiányzó beküldés azonosító.']);
            }

            $existing = FormSubmissionService::getById($id, false);
            $erased = FormSubmissionService::erase($id);
            FormAuditLog::erase($user, $existing['form_slug'] ?? $formSlug, [$id]);

            submissionsJson(200, ['success' => true, 'erased' => $erased, 'id' => $id]);
        }

        submissionsJson(400, ['success' => false, 'error' => 'Ismeretlen művelet.', 'code' => 'UNKNOWN_ACTION']);
    }

    if ($method === 'DELETE') {
        AuthMiddleware::requirePermission('forms:delete:*');

        $id = isset($_GET['id']) ? (int) $_GET['id'] : 0;
        if ($id <= 0) {
            submissionsJson(400, ['success' => false, 'error' => 'Hiányzó beküldés azonosító.']);
        }

        $existing = FormSubmissionService::getById($id, false);
        $erased = FormSubmissionService::erase($id);
        FormAuditLog::erase($user, $existing['form_slug'] ?? null, [$id]);

        submissionsJson(200, ['success' => true, 'erased' => $erased, 'id' => $id]);
    }

    header('Allow: GET, POST, DELETE, OPTIONS');
    submissionsJson(405, ['success' => false, 'error' => 'Nem támogatott HTTP metódus.']);
} catch (FormValidationException $e) {
    submissionsJson(400, [
        'success' => false,
        'error' => $e->getMessage(),
        'code' => 'VALIDATION_FAILED',
        'errors' => $e->getErrors(),
    ]);
} catch (FormNotFoundException $e) {
    submissionsJson(404, ['success' => false, 'error' => $e->getMessage(), 'code' => 'NOT_FOUND']);
} catch (Throwable $e) {
    error_log('[Forms][admin/form-submissions] ' . $e->getMessage());
    $debug = ($_ENV['APP_DEBUG'] ?? 'false') === 'true';
    submissionsJson(500, [
        'success' => false,
        'error' => $debug ? $e->getMessage() : 'Váratlan szerverhiba.',
        'code' => 'INTERNAL_ERROR',
    ]);
}
