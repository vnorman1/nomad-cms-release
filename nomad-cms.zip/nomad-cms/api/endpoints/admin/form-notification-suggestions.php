<?php
/**
 * NOMAD CMS - Admin API - Form Notification Recipient Suggestions
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * WHAT THIS IS FOR
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * EmailTagInput (the notification recipient field in the Form Builder) stays
 * free-text on purpose - an external address (a client's inbox, a shared
 * support mailbox) is a perfectly legitimate notification target, so the field
 * must never be restricted to a fixed list. But free-text-only invites typos,
 * and every existing e-mail address on the install is a reasonable one-click
 * suggestion. This endpoint is that suggestion list, autocomplete-style: the
 * frontend still accepts anything the admin types, this just reduces how often
 * they have to.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * TWO SOURCES, MERGED
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *   1. Every system user's e-mail address (UserRepository::findAll() already
 *      selects it in plaintext - the users table is not blind-indexed on this
 *      column, see UserRepository::findByEmail()).
 *   2. The from_email of every VERIFIED mail profile (mirrors
 *      form-mail-profiles.php's own filter: status=verified AND
 *      driver != disabled) - these are the addresses the CMS can itself send
 *      FROM, which makes them equally plausible as a notification recipient
 *      (e.g. "notify the shared inbox we send from").
 *
 * Deduplicated case-insensitively; no other user field (name, role, lock
 * state, admin flag) is exposed - this is a flat list of addresses, not a user
 * picker.
 *
 * PERMISSION CHOICE: forms:update:*, matching form-mail-profiles.php - not
 * users:read:* or mail:read:*. Both of those would be more data than this
 * endpoint returns (full user objects / full profile configs respectively),
 * and requiring either as well would lock a forms-only editor role out of a
 * feature that only needs a flat address list, not the underlying records.
 *
 * GET /admin/form-notification-suggestions.php
 * Permission: forms:update:*
 *
 * @package NomadCMS
 */

declare(strict_types=1);

require_once __DIR__ . '/../../bootstrap.php';

use NomadCMS\Middleware\AuthMiddleware;
use NomadCMS\Middleware\RateLimitMiddleware;
use NomadCMS\Database\UserRepository;
use NomadCMS\Services\Mail\MailProfileStore;
use NomadCMS\Services\Mail\MailSchema;

handlePreflight();
header('Content-Type: application/json; charset=utf-8');

/**
 * @param array<string, mixed> $payload
 */
function formNotificationSuggestionsJson(int $status, array $payload): never
{
    http_response_code($status);
    echo json_encode($payload, JSON_UNESCAPED_UNICODE);
    exit;
}

try {
    AuthMiddleware::requireAuth();
    AuthMiddleware::requirePermission('forms:update:*');
    RateLimitMiddleware::check('admin-form-notification-suggestions', 120, 60);

    $method = strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET');
    if ($method !== 'GET') {
        header('Allow: GET, OPTIONS');
        formNotificationSuggestionsJson(405, ['success' => false, 'error' => 'Nem támogatott HTTP metódus.']);
    }

    /** @var array<string, string> lowercase => original-case address, first occurrence wins */
    $seen = [];
    $emails = [];

    $addEmail = function (mixed $candidate) use (&$seen, &$emails): void {
        if (!is_string($candidate) || $candidate === '') {
            return;
        }
        if (filter_var($candidate, FILTER_VALIDATE_EMAIL) === false) {
            return;
        }

        $key = mb_strtolower($candidate);
        if (isset($seen[$key])) {
            return;
        }

        $seen[$key] = true;
        $emails[] = $candidate;
    };

    foreach (UserRepository::findAll() as $user) {
        $addEmail($user['email'] ?? null);
    }

    foreach (MailProfileStore::list() as $profile) {
        if ($profile['status'] !== MailSchema::STATUS_VERIFIED) {
            continue;
        }
        if ($profile['driver'] === MailSchema::DRIVER_DISABLED) {
            continue;
        }

        $addEmail($profile['from_email'] ?? null);
    }

    sort($emails, SORT_STRING | SORT_FLAG_CASE);

    formNotificationSuggestionsJson(200, ['success' => true, 'emails' => $emails]);
} catch (Throwable $e) {
    error_log('[Forms][admin/form-notification-suggestions] ' . $e->getMessage());
    $debug = ($_ENV['APP_DEBUG'] ?? 'false') === 'true';
    formNotificationSuggestionsJson(500, [
        'success' => false,
        'error' => $debug ? $e->getMessage() : 'Váratlan szerverhiba.',
        'code' => 'INTERNAL_ERROR',
    ]);
}
