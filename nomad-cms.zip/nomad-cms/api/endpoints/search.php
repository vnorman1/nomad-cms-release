<?php
/**
 * NOMAD CMS - Search Endpoint
 * 
 * Deep, optimized content search across slots, collections, localized sections and blocks.
 * 
 * Performance & Optimization Features:
 * - SQLite Unicode-aware case-insensitive substring search (mb_lower).
 * - Capped COUNT(*) subquery to avoid scanning massive tables.
 * - Cursor-based row streaming (zero memory exhaustion).
 * - Full recursion into localized sections (hu, en, etc.) and component blocks.
 * - Deep link generation to jump directly to slot/item/block in the editor.
 * - Extended RBAC / ABAC 'content:read:own' scope support.
 * 
 * GET /search.php?q=query&slot=optional&limit=20&offset=0
 */

declare(strict_types=1);

require_once __DIR__ . '/../bootstrap.php';

use NomadCMS\Services\ContentSearchService;
use NomadCMS\Middleware\AuthMiddleware;
use NomadCMS\Security\InputSanitizer;

// Handle CORS preflight
handlePreflight();

// Set JSON content type
header('Content-Type: application/json');

$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

if ($method !== 'GET') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Method not allowed']);
    exit;
}

try {
    // Require authentication and content read permissions (supports ABAC 'own' scope)
    AuthMiddleware::requireAuth();
    AuthMiddleware::requireAnyGrantedScope(['content:read:*', 'content:read:own']);

    $query = trim($_GET['q'] ?? '');
    $limit = min(max((int)($_GET['limit'] ?? 20), 1), 100); // 1-100 results
    $offset = max((int)($_GET['offset'] ?? 0), 0);
    $slotKey = $_GET['slot'] ?? null;

    if (mb_strlen($query) < 2) {
        echo json_encode([
            'success' => true,
            'query' => $query,
            'results' => [],
            'total' => 0,
            'limit' => $limit,
            'offset' => $offset,
            'hasMore' => false,
            'message' => 'A keresőkifejezésnek legalább 2 karakterből kell állnia'
        ]);
        exit;
    }

    if (mb_strlen($query) > 200) {
        http_response_code(400);
        echo json_encode(['success' => false, 'error' => 'A keresőkifejezés túl hosszú (max 200 karakter)']);
        exit;
    }

    $cleanSlotKey = null;
    // Optional slot key filter
    if (!empty($slotKey)) {
        $cleanSlotKey = InputSanitizer::slotKey((string) $slotKey);
        if ($cleanSlotKey === null) {
            http_response_code(400);
            echo json_encode(['success' => false, 'error' => 'Invalid slot key']);
            exit;
        }
    }
    echo json_encode(ContentSearchService::search($query, $limit, $offset, $cleanSlotKey));

} catch (\Throwable $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => ($_ENV['APP_DEBUG'] ?? 'false') === 'true' ? $e->getMessage() : 'Search failed'
    ]);
}
