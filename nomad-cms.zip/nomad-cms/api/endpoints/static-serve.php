<?php
/**
 * NOMAD CMS - Static Content Server with ETag Support
 * 
 * Lightweight endpoint for serving cached static content
 * with ETag validation for efficient cache revalidation.
 * 
 * Routes (via Router):
 *   GET /api/static/{slot}           → Full slot data (all items combined)
 *   GET /api/static/{slot}/{item}    → Single item from slot
 *
 * Query parameters:
 *   ?lang={code}  Keep only that language inside every `locales` map. Payloads
 *                 of single-language sites have no `locales` key, so it is a
 *                 no-op for them. Pure key selection, no re-projection.
 * 
 * Legacy:
 *   GET /api/endpoints/static-serve.php?slot={slot}&item={item}
 * 
 * Cache Structure (per-slot folders):
 *   /static/content/{slot}/manifest.json    - Slot metadata
 *   /static/content/{slot}/{identifier}.json - Individual items
 *
 * Payload shape (written by StaticCacheService, see PublicPayloadService):
 *   {
 *     "slot": "...", "slug": "...", "generated_at": "...",
 *     "languages": [...], "defaultLanguage": "...",   // multilingual only
 *     <language-independent fields>,
 *     "locales": { "<lang>": { <localized fields, fully flattened> } }
 *   }
 * 
 * Response headers:
 * - ETag: Content hash for cache validation
 * - Cache-Control: public, max-age=3600, must-revalidate
 * 
 * Returns 304 Not Modified if client ETag matches
 */

declare(strict_types=1);

// Handle CORS preflight
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Methods: GET, OPTIONS');
    header('Access-Control-Allow-Headers: If-None-Match');
    header('Access-Control-Max-Age: 86400');
    http_response_code(204);
    exit;
}

// Set CORS headers for all responses
header('Access-Control-Allow-Origin: *');
header('Access-Control-Expose-Headers: ETag, Last-Modified, X-Cache-Status');

// Load bootstrap for rate limiting (minimal overhead)
require_once __DIR__ . '/../bootstrap.php';

use NomadCMS\Middleware\RateLimitMiddleware;
use NomadCMS\Config\Security;

// Apply rate limiting: 300 requests per minute per IP (generous for static content)
$settings = Security::getRateLimitSettings()['static_serve'];
RateLimitMiddleware::check(
    key: 'static:' . ($_SERVER['REMOTE_ADDR'] ?? 'unknown'),
    maxRequests: $settings['max'],
    windowSeconds: $settings['window']
);

// Get parameters
$slot = $_GET['slot'] ?? '';
if (\NomadCMS\Services\Schema\SchemaProvider::initialized() && !\NomadCMS\Services\Schema\SchemaProvider::slot((string) $slot)) {
    http_response_code(410);
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'error' => 'SCHEMA_SLOT_ARCHIVED']);
    exit;
}
$item = $_GET['item'] ?? null;  // Optional: specific item identifier

// DRAFT PREVIEW MODE DELEGATION
if (array_key_exists('relation_field', $_GET) || array_key_exists('relation_uid', $_GET)) {
    http_response_code(400);
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'error' => 'Relation filtering requires the dynamic data API.', 'code' => 'RELATION_REQUIRES_DYNAMIC']);
    exit;
}

// When draft preview mode is active (nomad_draft cookie, ?draftkey=, ?draft=1, ?preview=1, or X-Nomad-Draft),
// static-serve delegates seamlessly to data.php so unpublished draft items and manifests
// are generated and returned on the fly, without polluting static JSON files on disk.
$draftCookie = $_COOKIE['nomad_draft'] ?? '';
$hasDraftKey = (str_starts_with($draftCookie, 'nmk_') || (isset($_GET['draftkey']) && str_starts_with((string)$_GET['draftkey'], 'nmk_')));
$isDraftRequest = $hasDraftKey 
    || (isset($_GET['draft']) && ($_GET['draft'] === '1' || $_GET['draft'] === 'true'))
    || (isset($_GET['preview']) && ($_GET['preview'] === '1' || $_GET['preview'] === 'true'))
    || (isset($_SERVER['HTTP_X_NOMAD_DRAFT']) && $_SERVER['HTTP_X_NOMAD_DRAFT'] === '1');

if ($isDraftRequest) {
    $_GET['key'] = $slot;
    if ($item !== null) {
        $_GET['item'] = $item;
    }
    $_GET['draft'] = '1';
    require __DIR__ . '/data.php';
    exit;
}

// Validate slot name (alphanumeric, underscore, dash only)
if (empty($slot) || 
    !preg_match('/^[a-zA-Z0-9_\-]+$/', $slot) ||
    str_contains($slot, '..') ||
    str_contains($slot, '/') ||
    str_contains($slot, '\\')) {
    http_response_code(400);
    header('Content-Type: application/json');
    echo json_encode([
        'success' => false, 
        'error' => 'Invalid or missing slot parameter'
    ]);
    exit;
}

// Validate item name if provided
if ($item !== null && (
    !preg_match('/^[a-zA-Z0-9_\-\.]+$/', $item) ||
    str_contains($item, '..'))
) {
    http_response_code(400);
    header('Content-Type: application/json');
    echo json_encode([
        'success' => false, 
        'error' => 'Invalid item parameter'
    ]);
    exit;
}

// Optional language narrowing: ?lang=hu keeps only that branch of `locales`.
//
// This is pure key selection on data that was already materialised at write
// time — no re-projection, which is what keeps this endpoint cheap enough for
// shared hosting.
$lang = $_GET['lang'] ?? null;
if ($lang !== null && !preg_match('/^[a-z]{2,3}([-_][A-Za-z0-9]{2,8})*$/', (string) $lang)) {
    http_response_code(400);
    header('Content-Type: application/json');
    echo json_encode([
        'success' => false,
        'error' => 'Invalid lang parameter',
    ]);
    exit;
}
$lang = $lang !== null ? (string) $lang : null;

/**
 * Keep only the requested language inside every `locales` map.
 *
 * Payloads generated for a single-language site have no `locales` key at all, so
 * this is a no-op for them.
 */
$narrowLanguage = static function (mixed $node, ?string $lang) use (&$narrowLanguage): mixed {
    if ($lang === null || !is_array($node)) {
        return $node;
    }

    if (isset($node['locales']) && is_array($node['locales'])) {
        $node['locales'] = array_key_exists($lang, $node['locales'])
            ? [$lang => $node['locales'][$lang]]
            : [];
    }

    foreach ($node as $key => $value) {
        if ($key !== 'locales' && is_array($value)) {
            $node[$key] = $narrowLanguage($value, $lang);
        }
    }

    return $node;
};

// Cache paths - NEW folder structure
try {
    \NomadCMS\Services\Schema\SchemaProvider::lease($slot);
    $slotDefinition = \NomadCMS\Services\StaticCacheService::getSlotDefinition($slot);
    if (\NomadCMS\Services\Schema\SchemaProvider::initialized() && $slotDefinition === null) {
        throw new \OutOfBoundsException('Content not publicly available');
    }
} catch (\Throwable $error) {
    http_response_code($error instanceof \OutOfBoundsException ? 404 : ($error->getCode() === 503 ? 503 : 500));
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'error' => 'Content not currently available']);
    exit;
}
if (($slotDefinition['type'] ?? '') === 'list') {
    if (!\NomadCMS\Services\RelationService::isPublicList($slot)) {
        http_response_code(404);
        header('Content-Type: application/json');
        echo json_encode(['success' => false, 'error' => 'Content not publicly available']);
        exit;
    }
    // Missing list files use the same publication-aware UID lookup as dynamic reads.
    if (!is_file(__DIR__ . '/../static/content/' . $slot . '/' . ($item ?? 'manifest') . '.json')) {
        $_GET['key'] = $slot;
        if ($item !== null && $item !== 'manifest') {
            $_GET['item'] = $item;
        } else {
            unset($_GET['item']);
        }
        require __DIR__ . '/data.php';
        exit;
    }
}
$cacheDir = __DIR__ . '/../static/content/';
$slotDir = $cacheDir . $slot . '/';
$manifestPath = $slotDir . 'manifest.json';

// Check if slot directory exists
if (\NomadCMS\Database\CollectionDatabase::isRegistered($slot)) {
    \NomadCMS\Services\RelationService::loadSchema();
    $state=\NomadCMS\Database\CollectionDatabase::state($slot);
    $marker=is_file($slotDir.'.collection_revision') ? json_decode(file_get_contents($slotDir.'.collection_revision'),true) : null;
    if (!$marker || (int)($marker['revision']??-1)!==(int)$state['revision'] || ($marker['schema_revision']??'')!==$state['schema_hash']) {
        $_GET['key']=$slot;
        if ($item!==null && $item!=='manifest') $_GET['item']=$item; else unset($_GET['item']);
        require __DIR__.'/data.php';
        exit;
    }
}
if (!is_dir($slotDir)) {
    http_response_code(404);
    header('Content-Type: application/json');
    echo json_encode([
        'success' => false, 
        'error' => 'Content not found in cache',
        'slot' => $slot
    ]);
    exit;
}

// Determine what to serve
if ($item !== null) {
    // Serve specific item
    $filepath = $slotDir . $item . '.json';
    
    if (!file_exists($filepath)) {
        if (\NomadCMS\Database\CollectionDatabase::isRegistered($slot)) {
            $_GET['key']=$slot; $_GET['item']=$item; require __DIR__.'/data.php'; exit;
        }
        // ON-DEMAND FALLBACK:
        // If the static file doesn't exist on disk (e.g. collection had > 300 items so sync build was deferred),
        // fetch and generate this single item from the database on-demand.
        $dbData = \NomadCMS\Database\ContentDatabase::getSlot($slot);
        if (is_array($dbData) && array_is_list($dbData)) {
            $slotDef = \NomadCMS\Services\StaticCacheService::getSlotDefinition($slot);
            $items = \NomadCMS\Services\PublicPayloadService::filterPublished($slot, $dbData);
            $idField = !empty($items) ? \NomadCMS\Services\StaticCacheService::detectItemIdentifier($slotDef, $items[0]) : 'slug';

            $foundItem = null;
            $foundIdentifier = null;
            foreach ($items as $i => $it) {
                $id = \NomadCMS\Services\StaticCacheService::getItemIdentifier($it, $idField, $i);
                if ($id === $item || ($it['slug'] ?? null) === $item || (string)($it['id'] ?? '') === $item) {
                    $foundItem = $it;
                    $foundIdentifier = $id;
                    break;
                }
            }

            if ($foundItem !== null) {
                $projected = \NomadCMS\Services\RelationService::projectForPublic($slot, [$foundItem], \NomadCMS\Services\RelationService::loadSchema());
                $projectedItem = $projected[0] ?? $foundItem;
                $itemFile = \NomadCMS\Services\StaticCacheService::buildSingleItemPayload($slot, $projectedItem, $foundIdentifier);

                if (!\NomadCMS\Security\PanicModeService::isReadOnlyRequest()
                    && is_dir($slotDir) && is_writable($slotDir)) {
                    @file_put_contents($filepath, json_encode($itemFile, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT));
                }

                $data = $itemFile;
                if ($lang !== null && is_array($data)) {
                    $data = $narrowLanguage($data, $lang);
                    $etag = '"' . md5(json_encode($data) . '|' . $lang) . '"';
                } else {
                    $etag = '"' . md5(json_encode($itemFile)) . '"';
                }

                $clientEtag = $_SERVER['HTTP_IF_NONE_MATCH'] ?? '';
                if ($clientEtag === $etag) {
                    http_response_code(304);
                    header('Cache-Control: public, max-age=3600, must-revalidate');
                    header('ETag: ' . $etag);
                    exit;
                }

                header('Content-Type: application/json; charset=utf-8');
                header('Cache-Control: public, max-age=3600, must-revalidate');
                header('X-Content-Type-Options: nosniff');
                header('X-Cache-Status: MISS');
                header('ETag: ' . $etag);

                $response = [
                    'success' => true,
                    'data' => $data,
                    'cached_at' => $itemFile['generated_at'] ?? date('c'),
                    'slot' => $slot,
                    'item' => $item,
                ];
                if ($lang !== null) {
                    $response['lang'] = $lang;
                }
                echo json_encode($response, JSON_UNESCAPED_UNICODE);
                exit;
            }
        }

        http_response_code(404);
        header('Content-Type: application/json');
        echo json_encode([
            'success' => false, 
            'error' => 'Item not found in cache',
            'slot' => $slot,
            'item' => $item
        ]);
        exit;
    }
} else {
    // Serve slot manifest data (avoids reading all individual item files)
    $manifest = null;
    if (file_exists($manifestPath)) {
        $manifestContent = file_get_contents($manifestPath);
        $manifest = json_decode($manifestContent, true);
    }
    
    if ($manifest === null) {
        http_response_code(404);
        header('Content-Type: application/json');
        echo json_encode([
            'success' => false, 
            'error' => 'No cached content available',
            'slot' => $slot
        ]);
        exit;
    }
    
    $slotType = $manifest['type'] ?? 'collection';
    $latestMtime = file_exists($manifestPath) ? filemtime($manifestPath) : time();
    
    if ($slotType === 'collection') {
        // Collection slots serve the manifest directly (lightweight index, no blocks)
        $responseData = $manifest;
    } elseif ($slotType === 'object') {
        // Object slots keep their payload inside manifest minus meta keys
        $responseData = $manifest;
        foreach (['type', 'itemCount', 'identifierField', 'index', 'hasChunks', 'chunkSize', 'chunks'] as $metaKey) {
            unset($responseData[$metaKey]);
        }
    } elseif ($slotType === 'list' && array_key_exists('items', $manifest)) {
        $responseData = $manifest;
    } else {
        $responseData = $manifest;
    }
    
    // Check If-None-Match header
    $clientEtag = $_SERVER['HTTP_IF_NONE_MATCH'] ?? '';
    if ($clientEtag === $etag) {
        http_response_code(304);
        header('Cache-Control: public, max-age=3600, must-revalidate');
        header('ETag: ' . $etag);
        exit;
    }
    
    // Serve combined content
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: public, max-age=3600, must-revalidate');
    header('X-Content-Type-Options: nosniff');
    header('X-Cache-Status: HIT');
    header('ETag: ' . $etag);
    
    if ($latestMtime > 0) {
        header('Last-Modified: ' . gmdate('D, d M Y H:i:s', $latestMtime) . ' GMT');
    }
    
    $response = [
        'success' => true,
        'data' => $responseData,
        // The generator writes `generated_at`; the old `updated_at` lookup never
        // matched, so this always fell back to "now".
        'cached_at' => $manifest['generated_at'] ?? date('c'),
        'slot' => $slot,
        'item_count' => $manifest['itemCount'] ?? (isset($manifest['index']) && is_array($manifest['index']) ? count($manifest['index']) : 1),
    ];

    if (isset($manifest['languages'])) {
        $response['languages'] = $manifest['languages'];
        $response['defaultLanguage'] = $manifest['defaultLanguage'] ?? null;
    }
    if ($lang !== null) {
        $response['lang'] = $lang;
    }

    echo json_encode($response, JSON_UNESCAPED_UNICODE);
    exit;
}

// Serving single item file
$mtime = filemtime($filepath);
$content = file_get_contents($filepath);
$data = json_decode($content, true);

// Narrowing changes the payload, so the ETag must follow it — otherwise ?lang=hu
// and ?lang=en would share one validator.
if ($lang !== null && is_array($data)) {
    $data = $narrowLanguage($data, $lang);
    $etag = '"' . md5(json_encode($data) . '|' . $lang) . '"';
} else {
    $etag = '"' . md5($content) . '"';
}

// Check If-None-Match header
$clientEtag = $_SERVER['HTTP_IF_NONE_MATCH'] ?? '';
if ($clientEtag === $etag) {
    http_response_code(304);
    header('Cache-Control: public, max-age=3600, must-revalidate');
    header('ETag: ' . $etag);
    exit;
}

// Serve the cached content
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: public, max-age=3600, must-revalidate');
header('X-Content-Type-Options: nosniff');
header('X-Cache-Status: HIT');
header('ETag: ' . $etag);

if ($mtime) {
    header('Last-Modified: ' . gmdate('D, d M Y H:i:s', $mtime) . ' GMT');
}

// Wrap in standard response format
$response = [
    'success' => true,
    'data' => $data,
    'cached_at' => is_array($data) ? ($data['generated_at'] ?? date('c', $mtime)) : date('c', $mtime),
    'slot' => $slot,
    'item' => $item,
];

if ($lang !== null) {
    $response['lang'] = $lang;
}

echo json_encode($response, JSON_UNESCAPED_UNICODE);
