<?php
/**
 * Delete Image Endpoint Logic
 * Deletes uploaded images
 */

declare(strict_types=1);

require_once __DIR__ . '/../bootstrap.php';

use NomadCMS\Middleware\AuthMiddleware;
use NomadCMS\Middleware\CSRFMiddleware;

// Handle CORS preflight
handlePreflight();

// Set JSON content type
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST' && $_SERVER['REQUEST_METHOD'] !== 'DELETE') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Method not allowed']);
    exit;
}

try {
    // SECURITY: Validate CSRF token for session-based requests
    CSRFMiddleware::validateForSession();
    
    // Validate admin token
    // ABAC: media:delete:* deletes any file, media:delete:own only files this
    // user uploaded. Grant detection uses hasGrantedScope() because media
    // ownership lives in media_meta.uploaded_by, not in the content-slot
    // ownership table that hasPermission() consults - the actual per-file
    // check happens once the filename is known, below. This mirrors
    // media.php's DELETE branch so that "delete my own file" behaves
    // identically no matter which of the two delete endpoints is used.
    AuthMiddleware::requireAuth();
    AuthMiddleware::requireAnyGrantedScope(['media:delete:*', 'media:delete:own']);
    $hasMediaDeleteAll = AuthMiddleware::hasGrantedScope('media:delete:*');
    $deleteOwnOnly = !$hasMediaDeleteAll;

    // Get the URL to delete from request body
    $input = file_get_contents('php://input');
    $body = !empty($input) ? json_decode($input, true) : [];
    $url = $body['url'] ?? '';

    if (empty($url)) {
        http_response_code(400);
        echo json_encode(['success' => false, 'error' => 'No URL provided']);
        exit;
    }

    // Extract filename from URL (e.g., /api/uploads/image.webp -> image.webp)
    $pathPart = parse_url($url, PHP_URL_PATH);
    if ($pathPart === false || $pathPart === null) {
        http_response_code(400);
        echo json_encode(['success' => false, 'error' => 'Invalid URL format']);
        exit;
    }
    $filename = basename($pathPart);

    if (empty($filename)) {
        http_response_code(400);
        echo json_encode(['success' => false, 'error' => 'Invalid URL format']);
        exit;
    }

    // Security check: ensure filename doesn't contain path traversal
    if (strpos($filename, '..') !== false || strpos($filename, '/') !== false) {
        http_response_code(400);
        echo json_encode(['success' => false, 'error' => 'Invalid filename']);
        exit;
    }

    // ABAC 'own' scope: a caller without media:delete:* may only delete files
    // they uploaded. Fail-closed - a file with no recorded owner (legacy data)
    // is not deletable by an own-scoped role.
    if ($deleteOwnOnly) {
        $meta = \NomadCMS\Database\ContentDatabase::getMediaMeta($filename);
        $owner = $meta['uploaded_by'] ?? null;
        $currentUserUuid = AuthMiddleware::getCurrentUser()->uuid ?? null;
        if ($owner === null || $currentUserUuid === null || !hash_equals($owner, $currentUserUuid)) {
            http_response_code(403);
            echo json_encode(['success' => false, 'error' => 'Nincs jogosultságod ehhez a fájlhoz.', 'code' => 'FORBIDDEN_MEDIA_DELETE']);
            exit;
        }
    }

    $res = \NomadCMS\Services\MediaService::getInstance()->deleteMediaFile($filename, true);
    if (!empty($res['success'])) {
        echo json_encode([
            'success' => true,
            'message' => 'File deleted successfully',
            'filename' => $filename
        ]);
    } elseif (($res['error'] ?? '') === 'File not found') {
        echo json_encode([
            'success' => true,
            'message' => 'File already deleted or does not exist',
            'filename' => $filename
        ]);
    } else {
        http_response_code(500);
        echo json_encode(['success' => false, 'error' => $res['error'] ?? 'Failed to delete file']);
    }

} catch (\Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => $_ENV['APP_DEBUG'] === 'true' ? $e->getMessage() : 'Internal server error',
    ]);
}
