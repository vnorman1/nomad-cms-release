<?php
/**
 * Data Endpoint Logic
 * Handles GET, POST, DELETE operations for slot data
 * 
 * Auth requirements by operation:
 * - GET (public data): No auth required
 * - GET (?admin=1): Auth + slot access (internal shape, see below)
 * - GET (?with_version=true): Auth + content:read (admin editor)
 * - GET (__all_keys__): Admin only
 * - POST (write data): Auth + write permission (with OPTIMISTIC LOCKING)
 * - DELETE: Auth + admin permission
 *
 * PUBLIC vs INTERNAL READ SHAPE:
 * - Public GET returns content projected for publication: relation fields carry
 *   their RESOLVED target content under their own name, and no internal key or
 *   item uid (`_dndId`, `_<fieldId>`) is present.
 * - `?admin=1` and `?with_version=true` return the internal shape (raw relation
 *   uids + `_<fieldId>` embeds + `_dndId`), which the editor needs in order to
 *   store references. Both require authentication.
 * 
 * OPTIMISTIC LOCKING (2026-01-05):
 * - POST requests can include 'expected_version' to prevent lost updates
 * - If version mismatch, returns HTTP 409 Conflict with current version
 * - Frontend should prompt user to reload/merge on conflict
 * 
 * SMART MEDIA INGESTION (2026-01-06):
 * - Auto-detects image URLs/Base64 in JSON payloads
 * - Queues for background download and WebP conversion
 * - Replaces with local paths immediately
 * 
 * SNAPSHOT VERSIONING (2026-01-06):
 * - API requests with 'bulk_import' flag skip versioning for performance
 * - Used for mass data imports and webhook sync
 */

declare(strict_types=1);

require_once __DIR__ . '/../bootstrap.php';

use NomadCMS\Database\ContentDatabase;
use NomadCMS\Database\OptimisticLockException;
use NomadCMS\Middleware\AuthMiddleware;
use NomadCMS\Middleware\CSRFMiddleware;
use NomadCMS\Middleware\RateLimitMiddleware;
use NomadCMS\Config\Security;
use NomadCMS\Security\InputSanitizer;
use NomadCMS\Security\WebhookService;
use NomadCMS\Services\StaticCacheService;
use NomadCMS\Services\VersioningService;
use NomadCMS\Services\SmartIngestService;
use NomadCMS\Services\DependencyGraphService;
use NomadCMS\Services\RelationService;
use NomadCMS\Services\PublicPayloadService;

// Handle CORS preflight
handlePreflight();

// Set JSON content type
header('Content-Type: application/json');

$method = $_SERVER['REQUEST_METHOD'];

// Apply rate limiting based on request type
if ($method === 'GET') {
    // Public GET: 200/min per IP - generous for SPA/public sites
    $settings = Security::getRateLimitSettings()['public_api'];
    RateLimitMiddleware::check(
        key: 'public_api:' . ($_SERVER['REMOTE_ADDR'] ?? 'unknown'),
        maxRequests: $settings['max'],
        windowSeconds: $settings['window']
    );
} elseif ($method === 'POST' || $method === 'DELETE') {
    // Write operations: 60/min per IP - stricter limit
    // Prevents abuse while allowing reasonable editing workflows
    RateLimitMiddleware::check(
        key: 'write_api:' . ($_SERVER['REMOTE_ADDR'] ?? 'unknown'),
        maxRequests: 360,
        windowSeconds: 60
    );
}

/**
 * Shared schema accessor.
 *
 * RelationService caches the parsed schema per request, so this is cheap to call
 * from any branch. Previously each branch re-read and re-decoded the file (and the
 * POST branch relied on a $schema that was only ever assigned inside the GET
 * branch, silently falling back to defaults).
 */
function nomadSchema(): array
{
    return RelationService::loadSchema();
}

try {
    if (!in_array($method, ['GET', 'OPTIONS'], true)) {
        \NomadCMS\Services\Schema\SchemaProvider::assertClientRevision();
    }
    switch ($method) {
        case 'GET':
            $key = InputSanitizer::slotKey($_GET['key'] ?? '');
            
            // Special route: get all keys (admin only)
            if ($key === '__all_keys__') {
                AuthMiddleware::requireAuth();
                AuthMiddleware::requirePermission('system:admin:*');
                echo json_encode(['success' => true, 'keys' => ContentDatabase::getAllSlots()]);
                exit;
            }
            
            if (empty($key)) {
                http_response_code(400);
                echo json_encode(['success' => false, 'error' => 'Missing key parameter']);
                exit;
            }
            
            if (\NomadCMS\Services\Schema\SchemaProvider::initialized() && !\NomadCMS\Services\Schema\SchemaProvider::slot($key)) {
                throw new \RuntimeException('SCHEMA_SLOT_ARCHIVED', 410);
            }

            // Check if version info requested (for optimistic locking)
            if (array_key_exists('relation_field', $_GET) || array_key_exists('relation_uid', $_GET)) {
                echo json_encode(\NomadCMS\Services\PublicCollectionService::readRelated($key, $_GET), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
                exit;
            }
            $withVersion = isset($_GET['with_version']) && $_GET['with_version'] === 'true';
            if (isset($_GET['collection_page']) && (\NomadCMS\Database\CollectionDatabase::isRegistered($key)
                || \NomadCMS\Database\CollectionDatabase::canInitializeEmpty($key))) {
                echo json_encode(\NomadCMS\Services\CollectionApiService::read($key, $_GET), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
                exit;
            }

            // INTERNAL (admin) READ MODE.
            //
            // The default GET is PUBLIC output: relations are merged onto their
            // own field names and every internal key/uid is stripped, so a
            // headless consumer never receives `_dndId` or a raw relation uid.
            //
            // The editor, however, needs exactly that internal shape — the
            // relation picker stores the target item's uid, so it must be able to
            // read it. `?admin=1` opts into the internal shape and, unlike the
            // public read, REQUIRES authentication + slot access.
            $internalMode = isset($_GET['admin']) && ($_GET['admin'] === '1' || $_GET['admin'] === 'true');

            // DRAFT / PREVIEW READ MODE
            //
            // Allows authorized clients (valid API key with can_read, or logged-in editor/admin)
            // to fetch unpublished / draft items dynamically.
            // Draft content is STRICTLY dynamic and NEVER generates static JSON files.
            $requestedDraft = isset($_GET['draft']) && ($_GET['draft'] === '1' || $_GET['draft'] === 'true')
                           || isset($_GET['preview']) && ($_GET['preview'] === '1' || $_GET['preview'] === 'true')
                           || (isset($_SERVER['HTTP_X_NOMAD_DRAFT']) && $_SERVER['HTTP_X_NOMAD_DRAFT'] === '1');

            // Auto-detect draft mode from draftkey query param or nomad_draft cookie
            // (set by the .htaccess Session Cookie Preview Engine or PHP bootstrap fallback).
            // When a valid draft-only API key is present as a cookie, the user's browser
            // transparently enters preview mode without explicit ?draft=1 on every request.
            $hasDraftKeyCookie = !empty($_COOKIE['nomad_draft']) || !empty($_GET['draftkey']);
            if (!$requestedDraft && $hasDraftKeyCookie) {
                $requestedDraft = true;
            }

            $includeDrafts = false;
            if ($requestedDraft) {
                // Must be authenticated to read drafts
                $authCaller = AuthMiddleware::optionalAuth();
                if (!$authCaller) {
                    http_response_code(401);
                    echo json_encode([
                        'success' => false,
                        'error'   => 'Draft content access requires authentication. Provide a valid API key or Bearer token.',
                        'code'    => 'UNAUTHORIZED_DRAFT_ACCESS',
                    ]);
                    exit;
                }

                if (!AuthMiddleware::canReadDrafts()) {
                    http_response_code(403);
                    echo json_encode([
                        'success' => false,
                        'error'   => 'Your API key or session does not have permission to read draft content.',
                        'code'    => 'FORBIDDEN_DRAFT_ACCESS',
                    ]);
                    exit;
                }

                $includeDrafts = true;
            }

            $lang = $_GET['lang'] ?? null;
            if (!$withVersion && !$internalMode && \NomadCMS\Database\CollectionDatabase::isRegistered($key)) {
                echo json_encode(\NomadCMS\Services\PublicCollectionService::read($key, isset($_GET['item']) ? (string)$_GET['item'] : null, $lang, $includeDrafts), JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
                exit;
            }
            
            
            if ($withVersion) {
                // Return data with version for optimistic locking (admin editor)
                // REQUIRES: Proper permission check for admin read access
                AuthMiddleware::requireAuth();

                $result = ContentDatabase::getSlotWithVersion($key);

                // Check content:read permission.
                //
                // OWNERSHIP MODEL NUANCE: for list/collection slots, ownership is
                // tracked PER ITEM (slot_ownership.item_uid = the item's _dndId),
                // there is no single "owner of the whole slot". So a plain
                // hasPermission('content:read:own', $key) call - which checks
                // isOwnedBy($key, ..., itemUid: null), i.e. OBJECT-slot ownership -
                // always returns false for a list/collection slot, even for a user
                // who owns some (or all) of the items in it. That would incorrectly
                // 403 an own-scoped user out of their own content.
                //
                // Detecting list-vs-object from the SCHEMA's declared slot type is
                // unreliable (a slot key may not even be registered in the schema
                // yet, e.g. ad-hoc/test data, or the schema could be stale) - the
                // one source of truth is the ACTUAL saved shape. A PHP list decodes
                // from JSON as a sequential array, so array_is_list() on the loaded
                // data reliably tells list/collection apart from a single object,
                // matching exactly what ContentDatabase/RelationService already
                // treat as "is this a list slot" elsewhere in this file.
                $isListOrCollection = $result !== null && is_array($result['data']) && array_is_list($result['data']);

                $hasContentReadAll = AuthMiddleware::hasPermission('content:read:*', $key);
                if ($isListOrCollection) {
                    // For list/collection slots, grant detection uses
                    // hasGrantedScope() (no ownership lookup) - the actual
                    // per-item filtering happens below after the data is loaded.
                    $hasContentReadOwn = AuthMiddleware::hasGrantedScope('content:read:own');
                } else {
                    $hasContentReadOwn = AuthMiddleware::hasPermission('content:read:own', $key);
                }
                
                if (!$hasContentReadAll && !$hasContentReadOwn) {
                    http_response_code(403);
                    echo json_encode(['success' => false, 'error' => 'Nincs jogosultságod a tartalom megtekintéséhez.', 'code' => 'FORBIDDEN_READ']);
                    exit;
                }
                
                if ($result === null) {
                    echo json_encode([
                        'success' => true, 
                        'data' => null, 
                        'version' => 0,
                        'exists' => false
                    ]);
                } else {
                    // Embed related items so the editor can render labels without
                    // a second round-trip. Item identity (_dndId) is already in the
                    // stored payload, so nothing is invented here.
                    $adminData = RelationService::resolveForSlot($key, $result['data'], nomadSchema());

                    // OWN-SCOPE FILTERING (list/collection only): if the caller
                    // only has content:read:own (not :*), keep only the items
                    // they actually own, per slot_ownership.item_uid. Items with
                    // no ownership record (legacy data predating this feature)
                    // are excluded too - fail-closed, matching the media/logs
                    // own-scope behaviour.
                    if ($isListOrCollection && !$hasContentReadAll && is_array($adminData)) {
                        $currentUserUuid = AuthMiddleware::getCurrentUser()->uuid ?? null;
                        $ownershipRows = ContentDatabase::getSlotOwnership($key);
                        $ownerByItemUid = [];
                        foreach ($ownershipRows as $row) {
                            if ($row['item_uid'] !== null) {
                                $ownerByItemUid[$row['item_uid']] = $row['owner_uuid'];
                            }
                        }
                        $adminData = array_values(array_filter($adminData, function ($item) use ($ownerByItemUid, $currentUserUuid) {
                            $itemUid = is_array($item) ? ($item['_dndId'] ?? null) : null;
                            if ($itemUid === null || $currentUserUuid === null) return false;
                            $owner = $ownerByItemUid[$itemUid] ?? null;
                            return $owner !== null && hash_equals($owner, $currentUserUuid);
                        }));
                    }

                    echo json_encode([
                        'success' => true,
                        'data' => $adminData,
                        'version' => $result['version'],
                        'exists' => true
                    ]);
                }
            } else {
                // Standard GET - dynamic content request (enriched with media ALTs and localized)
                //
                // Two shapes are served here, and the difference is a security
                // boundary, not a convenience:
                //
                //   ?admin=1  INTERNAL — raw relation uids + `_<fieldId>` embeds
                //             + `_dndId`. The editor's relation picker needs the
                //             uids. Gated by the SAME RBAC checks as the
                //             ?with_version=true admin read: auth, slot access,
                //             content:read, and own-scope per-item filtering.
                //   default   PUBLIC   — relations merged onto their own field
                //             names, every internal key and uid stripped. No auth.
                //
                // `list` type slots are internal-only regardless of mode: they
                // exist purely as relation targets (tags/categories/authors...)
                // embedded into other slots' payloads, and have no per-item
                // identity meant for direct public consumption. Only the PUBLIC
                // branch is gated here — ?admin=1 / ?with_version=true keep
                // working, because the editor legitimately reads a list slot
                // directly (e.g. to populate a relation picker).
                $slotType = nomadSchema()['slots'][$key]['type'] ?? null;
                if (!$internalMode && $slotType === 'list' && !RelationService::isPublicList($key)) {
                    http_response_code(404);
                    echo json_encode([
                        'success' => false,
                        'error' => 'Content not publicly available',
                        'key' => $key,
                    ]);
                    exit;
                }

                if (!$internalMode && $slotType === 'list') {
                    // Even an authorized article preview receives only publicly
                    // readable taxonomy items here. Admin reads remain separate.
                    $uid = $_GET['item'] ?? null;
                    if (($uid !== null && !is_string($uid)) || ($lang !== null && !is_string($lang))) {
                        throw new \InvalidArgumentException('Invalid item or language.');
                    }
                    echo json_encode(\NomadCMS\Services\PublicListService::read($key, $uid, $lang), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
                    exit;
                }

                $data = ContentDatabase::getSlot($key);

                if ($internalMode) {
                    AuthMiddleware::requireAuth();
                    AuthMiddleware::requireSlotAccess($key);

                    // Ownership for list/collection slots is per item, so a plain
                    // hasPermission('content:read:own') would always be false for
                    // them (it tests OBJECT-slot ownership). Mirror the
                    // with_version branch: detect the shape from the saved data,
                    // use hasGrantedScope() for itemised slots, and filter items
                    // below. See the long comment in that branch for the details.
                    $isListOrCollection = is_array($data) && array_is_list($data);

                    $hasContentReadAll = AuthMiddleware::hasPermission('content:read:*', $key);
                    $hasContentReadOwn = $isListOrCollection
                        ? AuthMiddleware::hasGrantedScope('content:read:own')
                        : AuthMiddleware::hasPermission('content:read:own', $key);

                    if (!$hasContentReadAll && !$hasContentReadOwn) {
                        http_response_code(403);
                        echo json_encode([
                            'success' => false,
                            'error'   => 'Nincs jogosultságod a tartalom megtekintéséhez.',
                            'code'    => 'FORBIDDEN_READ',
                        ]);
                        exit;
                    }

                    // OWN-SCOPE FILTERING: keep only items the caller owns, per
                    // slot_ownership.item_uid. Items with no ownership record are
                    // excluded too - fail-closed, as elsewhere.
                    if ($isListOrCollection && !$hasContentReadAll) {
                        $currentUserUuid = AuthMiddleware::getCurrentUser()->uuid ?? null;
                        $ownerByItemUid  = [];
                        foreach (ContentDatabase::getSlotOwnership($key) as $row) {
                            if ($row['item_uid'] !== null) {
                                $ownerByItemUid[$row['item_uid']] = $row['owner_uuid'];
                            }
                        }
                        $data = array_values(array_filter($data, function ($item) use ($ownerByItemUid, $currentUserUuid) {
                            $itemUid = is_array($item) ? ($item['_dndId'] ?? null) : null;
                            if ($itemUid === null || $currentUserUuid === null) {
                                return false;
                            }
                            $owner = $ownerByItemUid[$itemUid] ?? null;
                            return $owner !== null && hash_equals($owner, $currentUserUuid);
                        }));
                    }
                }
                
                if ($data === null) {
                    echo json_encode(['success' => true, 'data' => null, 'exists' => false]);
                } else {
                    if ($internalMode) {
                        // INTERNAL: hand back the content as stored — language maps,
                        // block ids and relation uids intact. It must NOT be run
                        // through the public projection or the editor loses the
                        // very things it needs to write content back.
                        $editable = \NomadCMS\Services\Schema\SchemaValues::editorPayload(ContentDatabase::getInstance(), $key, $data);
                        $payload = RelationService::resolveForSlot($key, $editable, nomadSchema());
                        $response = ['success' => true, 'data' => $payload, 'exists' => true];
                        echo json_encode($response);
                    } else {
                        $itemParam = $_GET['item'] ?? $_GET['slug'] ?? null;
                        $item = $itemParam !== null ? trim((string)$itemParam) : null;
                        $chunk = isset($_GET['chunk']) && is_numeric($_GET['chunk']) ? (int)$_GET['chunk'] : null;

                        // Support chunk requests passed via item path (e.g. /data/projects/chunk_0 or chunk_0.json)
                        if ($item !== null && preg_match('/^chunk_(\d+)(?:\.json)?$/', $item, $chunkMatch)) {
                            $chunk = (int)$chunkMatch[1];
                            $item = null;
                        }

                        if ($item !== null && $item !== '') {
                            // SINGLE ITEM REQUEST (e.g. /data/projects?item=my-project)
                            if ($slotType !== 'collection') {
                                http_response_code(400);
                                echo json_encode([
                                    'success' => false,
                                    'error'   => "Slot '{$key}' is not a collection, single item read is not applicable",
                                    'slot'    => $key,
                                ]);
                                exit;
                            }

                            $slotDef = nomadSchema()['slots'][$key] ?? null;
                            $items = $includeDrafts
                                ? (is_array($data) ? $data : [])
                                : PublicPayloadService::filterPublished($key, is_array($data) ? $data : []);
                            $idField = !empty($items) ? StaticCacheService::detectItemIdentifier($slotDef, $items[0]) : 'slug';

                            $foundItem = null;
                            $foundIdentifier = null;
                            foreach ($items as $i => $it) {
                                $id = StaticCacheService::getItemIdentifier($it, $idField, $i);
                                if ($id === $item || ($it['slug'] ?? null) === $item || (string)($it['id'] ?? '') === $item) {
                                    $foundItem = $it;
                                    $foundIdentifier = $id;
                                    break;
                                }
                            }

                            if ($foundItem === null) {
                                http_response_code(404);
                                echo json_encode([
                                    'success' => false,
                                    'error'   => "Item '{$item}' not found in slot '{$key}'",
                                    'slot'    => $key,
                                    'item'    => $item,
                                ]);
                                exit;
                            }

                            $isDraftItem = !PublicPayloadService::isItemPublished($slotDef ?? [], $foundItem);

                            // Project relations for single item
                            $projected = RelationService::projectForPublic($key, [$foundItem], nomadSchema());
                            $projectedItem = $projected[0] ?? $foundItem;
                            $itemPayload = StaticCacheService::buildSingleItemPayload($key, $projectedItem, $foundIdentifier, $lang);

                            $response = [
                                'success' => true,
                                'data'    => $itemPayload,
                                'exists'  => true,
                                'slot'    => $key,
                                'item'    => $foundIdentifier,
                            ];
                            if ($isDraftItem) {
                                $response['is_draft'] = true;
                            }
                            $langMeta = PublicPayloadService::envelopeLanguageMeta();
                            if ($langMeta !== []) {
                                $response += $langMeta;
                            }
                            echo json_encode($response);
                            exit;
                        }

                        if ($slotType === 'collection') {
                            // COLLECTION MANIFEST REQUEST (Lightweight index, no blocks)
                            $slotDef = nomadSchema()['slots'][$key] ?? null;
                            $items = $includeDrafts
                                ? (is_array($data) ? $data : [])
                                : PublicPayloadService::filterPublished($key, is_array($data) ? $data : []);

                            // Identify draft items from raw data before public projection strips publishedField
                            $draftIdentifiers = [];
                            if ($includeDrafts) {
                                foreach ($items as $idx => $it) {
                                    if (is_array($it) && !PublicPayloadService::isItemPublished($slotDef ?? [], $it)) {
                                        $idField = StaticCacheService::detectItemIdentifier($slotDef, $it);
                                        $ident = StaticCacheService::getItemIdentifier($it, $idField, $idx);
                                        $draftIdentifiers[$ident] = true;
                                        if (isset($it['slug']) && is_string($it['slug'])) {
                                            $draftIdentifiers[$it['slug']] = true;
                                        }
                                    }
                                }
                            }

                            $projected = RelationService::projectForPublic($key, $items, nomadSchema());
                            $manifestPayload = StaticCacheService::buildCollectionManifestPayload($key, $projected, $slotDef);

                            if ($includeDrafts && !empty($draftIdentifiers)) {
                                // Mark draft items in manifest (manifest index)
                                if (isset($manifestPayload['manifest']['index']) && is_array($manifestPayload['manifest']['index'])) {
                                    foreach ($manifestPayload['manifest']['index'] as &$mItem) {
                                        $slug = is_array($mItem) ? ($mItem['slug'] ?? null) : null;
                                        if ($slug !== null && isset($draftIdentifiers[$slug])) {
                                            $mItem['is_draft'] = true;
                                        }
                                    }
                                    unset($mItem);
                                }
                                if (isset($manifestPayload['manifest']['items']) && is_array($manifestPayload['manifest']['items'])) {
                                    foreach ($manifestPayload['manifest']['items'] as &$mItem) {
                                        $slug = is_array($mItem) ? ($mItem['slug'] ?? null) : null;
                                        if ($slug !== null && isset($draftIdentifiers[$slug])) {
                                            $mItem['is_draft'] = true;
                                        }
                                    }
                                    unset($mItem);
                                }
                            }

                            if ($chunk !== null) {
                                if (isset($manifestPayload['chunks'][$chunk])) {
                                    $chunkData = $manifestPayload['chunks'][$chunk];
                                    if ($includeDrafts && !empty($draftIdentifiers) && is_array($chunkData) && isset($chunkData['items']) && is_array($chunkData['items'])) {
                                        foreach ($chunkData['items'] as &$cItem) {
                                            $slug = is_array($cItem) ? ($cItem['slug'] ?? null) : null;
                                            if ($slug !== null && isset($draftIdentifiers[$slug])) {
                                                $cItem['is_draft'] = true;
                                            }
                                        }
                                        unset($cItem);
                                    }
                                    echo json_encode([
                                        'success' => true,
                                        'data'    => $chunkData,
                                        'exists'  => true,
                                        'slot'    => $key,
                                        'chunk'   => $chunk,
                                    ]);
                                } else {
                                    http_response_code(404);
                                    echo json_encode([
                                        'success' => false,
                                        'error'   => "Chunk {$chunk} not found in slot '{$key}'",
                                        'slot'    => $key,
                                    ]);
                                }
                                exit;
                            }

                            $response = [
                                'success' => true,
                                'data'    => $manifestPayload['manifest'],
                                'exists'  => true,
                                'slot'    => $key,
                            ];
                            if ($includeDrafts) {
                                $response['is_draft_mode'] = true;
                                if (isset($manifestPayload['manifest']) && is_array($manifestPayload['manifest'])) {
                                    $manifestPayload['manifest']['is_draft_mode'] = true;
                                    $response['data'] = $manifestPayload['manifest'];
                                }
                            }
                            $langMeta = PublicPayloadService::envelopeLanguageMeta();
                            if ($langMeta !== []) {
                                $response += $langMeta;
                            }
                            echo json_encode($response);
                            exit;
                        }

                        // OBJECT SLOTS (e.g. meta, home, about, contact)
                        $payload = RelationService::projectForPublic($key, $data, nomadSchema());
                        $payload = PublicPayloadService::projectSlot($key, $payload, $lang, $includeDrafts);
                        $response = ['success' => true, 'data' => $payload, 'exists' => true, 'slot' => $key];

                        if ($includeDrafts) {
                            $slotDef = nomadSchema()['slots'][$key] ?? [];
                            if (!PublicPayloadService::isItemPublished($slotDef, is_array($data) ? $data : [])) {
                                $response['is_draft'] = true;
                            }
                        }

                        $langMeta = PublicPayloadService::envelopeLanguageMeta();
                        if ($langMeta !== []) {
                            $response += $langMeta;
                        }
                        echo json_encode($response);
                    }
                }
            }
            break;
            
        case 'POST':
            // SECURITY: Validate CSRF token for session-based requests
            CSRFMiddleware::validateForSession();
            
            // Require auth first (needed to read key from body for slot access check)
            AuthMiddleware::requireAuth();
            
            $input = file_get_contents('php://input');
            $body = !empty($input) ? json_decode($input, true) : null;

            if (!$body || !is_array($body)) {
                http_response_code(400);
                echo json_encode(['success' => false, 'error' => 'Invalid JSON body']);
                exit;
            }
            
            $key = InputSanitizer::slotKey($body['key'] ?? '');
            
            if (empty($key)) {
                http_response_code(400);
                echo json_encode(['success' => false, 'error' => 'Missing or invalid key in request body']);
                exit;
            }
            
            // RBAC: role must have access to this slot at all
            AuthMiddleware::requireSlotAccess($key);
            if (($body['action'] ?? null) === 'quick_create') {
                echo json_encode(\NomadCMS\Services\ListQuickCreateService::createAuthorized($key, $body['name'] ?? null), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
                exit;
            }
            if (array_key_exists('collection_bulk_publish',$body) && \NomadCMS\Database\CollectionDatabase::isRegistered($key)) {
                // Large atomic bulk updates can exceed the normal PHP request limit.
                set_time_limit(0);
                echo json_encode(\NomadCMS\Services\CollectionApiService::publishAll($key,$body),JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
                exit;
            }
            if ((isset($body['collection_operations']) || isset($body['collection_order'])) && \NomadCMS\Database\CollectionDatabase::isRegistered($key)) {
                echo json_encode(\NomadCMS\Services\CollectionApiService::batch($key, $body), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
                exit;
            }
            if (isset($body['item_dnd_id']) && \NomadCMS\Database\CollectionDatabase::isRegistered($key)) {
                echo json_encode(\NomadCMS\Services\CollectionApiService::write($key, $body), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
                exit;
            }
            
            // ABAC: content:update:* (any content) OR content:update:own (only if
            // this slot/item is already owned by the current user; new content
            // is always allowed to be created by anyone with slot access)
            $existingBeforeCheck = ContentDatabase::getSlot($key);
            $incomingData = $body['data'] ?? null;

            // ═══════════════════════════════════════════════════════════════
            // SINGLE-ITEM PATCH (list/collection only) - bandwidth optimisation
            // ═══════════════════════════════════════════════════════════════
            // A list/collection slot with hundreds of items previously required
            // the client to send (and this endpoint to receive) the ENTIRE array
            // just to edit or delete ONE item - the storage model is a single
            // JSON blob per slot (see ContentDatabase::saveSlot), so the actual
            // database write was always whole-slot regardless. What this DOES
            // fix is the network cost on both legs: a 300-item list's editor no
            // longer has to upload/download the other 299 untouched items for a
            // one-item edit.
            //
            // `item_dnd_id` selects the target by its stable identity (_dndId,
            // NOT array index - the client's filtered/sorted view may not match
            // storage order). Two shapes:
            //   { item_dnd_id, item_data }   -> upsert one item (edit or append
            //                                   if item_dnd_id is not found)
            //   { item_dnd_id, item_delete: true } -> remove one item
            //
            // Deliberately built as a THIN PRE-STEP rather than a parallel code
            // path: it only computes $incomingData (the full array with one item
            // changed) from the just-fetched $existingBeforeCheck, then falls
            // through into the SAME ownership-merge / RBAC / webhook /
            // versioning / static-cache logic below, unchanged. This guarantees
            // an item-level edit can never bypass a security or business rule
            // that a whole-array save would have enforced.
            $isItemOperation = false;
            $itemOperationType = null; // 'create' | 'update' | 'delete'
            $affectedItem = null;
            $previousItemBeforeSave = null;
            $targetItemUid = null;

            if (isset($body['item_dnd_id']) && is_string($body['item_dnd_id']) && $body['item_dnd_id'] !== '') {
                $isItemOperation = true;
                $targetItemUid = $body['item_dnd_id'];
                $existingList = $existingBeforeCheck ?? [];
                if (!is_array($existingList) || !array_is_list($existingList)) {
                    http_response_code(400);
                    echo json_encode(['success' => false, 'error' => 'item_dnd_id is only valid for list/collection slots']);
                    exit;
                }

                $targetUid = $body['item_dnd_id'];
                $wantsDelete = ($body['item_delete'] ?? false) === true;
                $itemData = $body['item_data'] ?? null;

                if (!$wantsDelete && (!is_array($itemData))) {
                    http_response_code(400);
                    echo json_encode(['success' => false, 'error' => 'Missing item_data for item upsert']);
                    exit;
                }

                $found = false;
                $rebuilt = [];
                foreach ($existingList as $existingItem) {
                    $existingUid = is_array($existingItem) ? ($existingItem['_dndId'] ?? null) : null;
                    if ($existingUid === $targetUid) {
                        $found = true;
                        if ($wantsDelete) {
                            $itemOperationType = 'delete';
                            $affectedItem = $existingItem;
                            continue; // drop this item
                        }
                        $itemOperationType = 'update';
                        $previousItemBeforeSave = $existingItem;
                        $itemData['_dndId'] = $targetUid;
                        $affectedItem = $itemData;
                        $rebuilt[] = $itemData;
                        continue;
                    }
                    $rebuilt[] = $existingItem;
                }

                if (!$found) {
                    if ($wantsDelete) {
                        http_response_code(404);
                        echo json_encode(['success' => false, 'error' => 'Item not found']);
                        exit;
                    }
                    // Not found + not deleting: treat as append (new item created
                    // through the single-item endpoint, e.g. optimistic client
                    // create). RelationService::normalizeForSave (below, on the
                    // full array) issues a real _dndId if this one collides or is
                    // absent, mirroring how a brand-new item behaves today.
                    $itemOperationType = 'create';
                    $itemData['_dndId'] = $targetUid;
                    $affectedItem = $itemData;
                    $rebuilt[] = $itemData;
                }

                $incomingData = $rebuilt;
            }

            // OWNERSHIP MODEL NUANCE (same root cause as the GET ?with_version
            // fix above): for list/collection slots, ownership is tracked PER
            // ITEM (slot_ownership.item_uid), not at the slot level. A plain
            // hasPermission('content:update:own', $key) call checks
            // isOwnedBy($key, ..., itemUid: null) - OBJECT-slot ownership -
            // which is always false for a list/collection slot, so an
            // own-scoped user could never save one at all under the naive
            // check. Detect list/collection from the actual saved (or
            // incoming, for brand-new slots) shape, exactly like the GET
            // branch does.
            $existingIsList = is_array($existingBeforeCheck) && array_is_list($existingBeforeCheck);
            $incomingIsList = is_array($incomingData) && array_is_list($incomingData);
            $isListOrCollectionSave = $existingIsList || $incomingIsList;

            if ($existingBeforeCheck !== null) {
                // Existing content -> must have update:* OR be the owner for update:own
                $hasFullUpdate = AuthMiddleware::hasPermission('content:update:*');

                if ($isListOrCollectionSave) {
                    // List/collection: grant detection only (no ownership
                    // lookup here - isOwnedBy() has no concept of "owns the
                    // whole list"). Per-item ownership is enforced below,
                    // BEFORE any data is written, by comparing the incoming
                    // payload against the stored list.
                    $hasOwnUpdate = !$hasFullUpdate && AuthMiddleware::hasGrantedScope('content:update:own');
                } else {
                    $hasOwnUpdate = !$hasFullUpdate && AuthMiddleware::hasPermission('content:update:own', $key);
                }

                if (!$hasFullUpdate && !$hasOwnUpdate) {
                    AuthMiddleware::requirePermission('content:update:*'); // triggers 403 with clear message
                }

                // Did the caller's READ view of this slot get filtered down to
                // just their own items? This is the decisive question for
                // list/collection saves, and it is INDEPENDENT of their update
                // scope. The GET ?with_version=true branch filters the list to
                // owned items whenever the caller lacks content:read:* - so if
                // read is own-scoped, the payload they send back can only ever
                // contain the subset they were shown, no matter how broad
                // their write permission is.
                //
                // This is the exact edge case behind the reported bug: a role
                // with content:read:own + content:update:* (mixed scopes) got
                // a filtered list on read, but because update was a wildcard
                // the merge below was skipped entirely and the filtered
                // payload replaced the whole stored list, wiping every item
                // the caller could not see - including for the superadmin.
                $readWasFiltered = $isListOrCollectionSave
                    && !AuthMiddleware::hasPermission('content:read:*', $key)
                    && AuthMiddleware::hasGrantedScope('content:read:own');

                // PER-ITEM OWNERSHIP + AUTO-MERGE (list/collection)
                // only): the list/collection editor implements "delete one
                // item" by re-POSTing the WHOLE list minus that item, and
                // "read" only ever showed the caller items THEY own (see the
                // GET ?with_version=true branch above) - so the incoming
                // payload from an own-scoped client NEVER includes items
                // belonging to other users or legacy unowned items in the
                // first place. Treating anything missing from the payload as
                // "the caller wants to delete it" is thus wrong for those
                // items: the caller never even saw them, so they can't have
                // intentionally removed them.
                //
                // Fix: MERGE instead of trusting the incoming list wholesale.
                // - Items the caller does not own, currently in storage, are
                //   always preserved verbatim, in their original position,
                //   regardless of whether they appear in the incoming payload.
                // - Items the caller owns are taken from the incoming payload
                //   (edited or removed, both allowed - it's their own item).
                // - Brand-new items (no _dndId yet) are appended - they become
                //   the caller's via first-writer-wins ownership on save.
                // - If the caller's payload tries to CHANGE an item they don't
                //   own (i.e. it exists in storage under a foreign owner AND
                //   the caller submitted a different version of it), that's
                //   still rejected outright (403) - own-scope must never let
                //   a client-supplied edit to someone else's item through,
                //   merge or not.
                //
                // GATING: the merge must run whenever the caller's payload
                // CANNOT be trusted as the complete list. That is true in two
                // independent situations:
                //   a) $readWasFiltered - read is own-scoped, so the payload is
                //      necessarily a subset of storage. This holds even when
                //      the caller's UPDATE scope is a wildcard (the mixed
                //      content:read:own + content:update:* case).
                //   b) $hasOwnUpdate - update is own-scoped, so per-item
                //      ownership must be enforced regardless of read scope.
                if ($isListOrCollectionSave && ($readWasFiltered || $hasOwnUpdate) && is_array($incomingData)) {
                    $currentUserUuid = AuthMiddleware::getCurrentUser()->uuid ?? null;
                    $ownershipRows = ContentDatabase::getSlotOwnership($key);
                    $ownerByItemUid = [];
                    foreach ($ownershipRows as $row) {
                        if ($row['item_uid'] !== null) {
                            $ownerByItemUid[$row['item_uid']] = $row['owner_uuid'];
                        }
                    }

                    $isOwnUid = function (?string $uid) use ($ownerByItemUid, $currentUserUuid): bool {
                        if ($uid === null || $currentUserUuid === null) return false;
                        $owner = $ownerByItemUid[$uid] ?? null;
                        return $owner !== null && hash_equals($owner, $currentUserUuid);
                    };

                    // Index the CURRENT full stored list (not the filtered
                    // view the caller saw) by _dndId, preserving order.
                    $existingByUid = [];
                    $existingOrder = [];
                    if (is_array($existingBeforeCheck)) {
                        foreach ($existingBeforeCheck as $item) {
                            $uid = is_array($item) ? ($item['_dndId'] ?? null) : null;
                            if ($uid !== null) {
                                $existingByUid[$uid] = $item;
                                $existingOrder[] = $uid;
                            }
                        }
                    }

                    $incomingByUid = [];
                    $newItemsNoUid = [];
                    foreach ($incomingData as $item) {
                        $uid = is_array($item) ? ($item['_dndId'] ?? null) : null;
                        if ($uid === null) {
                            $newItemsNoUid[] = $item;
                        } else {
                            $incomingByUid[$uid] = $item;
                        }
                    }

                    // TAMPER REJECTION - only when the caller's update scope is
                    // 'own'. Submitting a CHANGED copy of an item they don't
                    // own is then an explicit privilege-escalation attempt and
                    // is rejected before anything is written. (With
                    // content:update:* the same submission is a legitimate
                    // wildcard edit and is honoured by the merge below.)
                    if ($hasOwnUpdate) {
                        foreach ($incomingByUid as $uid => $item) {
                            $existed = array_key_exists($uid, $existingByUid);
                            $changed = $existed && $existingByUid[$uid] !== $item;
                            if ($existed && $changed && !$isOwnUid($uid)) {
                                http_response_code(403);
                                echo json_encode(['success' => false, 'error' => 'Nincs jogosultságod ezt az elemet módosítani.', 'code' => 'FORBIDDEN_ITEM_UPDATE']);
                                exit;
                            }
                        }
                    }

                    // Build the merged list by walking the ORIGINAL stored
                    // order, deciding per item whether the caller's payload is
                    // authoritative for it.
                    $merged = [];
                    foreach ($existingOrder as $uid) {
                        $inPayload = array_key_exists($uid, $incomingByUid);

                        if ($isOwnUid($uid)) {
                            // Caller's own item: their payload is fully
                            // authoritative - keep their version, or drop the
                            // item entirely if they removed it (their call).
                            if ($inPayload) {
                                $merged[] = $incomingByUid[$uid];
                            }
                            continue;
                        }

                        // Not the caller's item (another user's, or legacy
                        // unowned).
                        if ($inPayload && $hasFullUpdate) {
                            // Wildcard update scope: an explicitly submitted
                            // version of this item is a legitimate edit.
                            $merged[] = $incomingByUid[$uid];
                        } else {
                            // Either the caller never saw this item (absent
                            // from the payload because read was filtered), or
                            // they lack the scope to touch it. Preserve the
                            // stored version verbatim - absence must NEVER be
                            // read as "delete this".
                            $merged[] = $existingByUid[$uid];
                        }
                    }

                    // Any payload item whose _dndId doesn't exist in storage at
                    // all (e.g. stale client state) is appended - first-writer-
                    // wins ownership claims it for the caller on save, same as
                    // a brand-new item.
                    foreach ($incomingByUid as $uid => $item) {
                        if (!array_key_exists($uid, $existingByUid)) {
                            $merged[] = $item;
                        }
                    }

                    // Finally, brand-new items with no _dndId yet.
                    foreach ($newItemsNoUid as $item) {
                        $merged[] = $item;
                    }

                    $incomingData = array_values($merged);
                }
            } else {
                // New content -> creating requires content:create or
                // content:update (the editor's default), at EITHER scope.
                //
                // The 'own' scope must be accepted here: creating brand-new
                // content is inherently an "own" operation - there is no
                // pre-existing owner to check against, and the first-writer-
                // wins recordOwnership() call below makes the creator the
                // owner. Requiring a wildcard would have made
                // content:create:own a grant that silently permits nothing,
                // even though the role matrix UI offers it as a real choice.
                if (!AuthMiddleware::hasPermission('content:create:*')
                    && !AuthMiddleware::hasPermission('content:update:*')
                    && !AuthMiddleware::hasGrantedScope('content:create:own')
                    && !AuthMiddleware::hasGrantedScope('content:update:own')) {
                    AuthMiddleware::requirePermission('content:create:*');
                }
            }
            
            $data = $incomingData;
            $slotType = $body['slot_type'] ?? (nomadSchema()['slots'][$key]['type'] ?? null);
            if ($slotType === null && is_array($data)) {
                $slotType = array_is_list($data) ? 'collection' : 'object';
            }
            
            // ENTERPRISE OPTIMISTIC LOCKING:
            // 1. expected_hash (recommended) - SHA-256 content hash, TRUE identity check
            // 2. expected_version (fallback) - Version number, simpler but less robust
            $expectedHash = isset($body['expected_hash']) ? (string) $body['expected_hash'] : null;
            $expectedVersion = isset($body['expected_version']) ? (int) $body['expected_version'] : null;
            
            // WASM PRECOMPUTED VERSION DATA:
            // Frontend can compute diff + compress using WASM, sending precomputed data
            // This offloads CPU-intensive work from server
            $precomputedVersion = $body['precomputed_version'] ?? null;
            
            // SHADOW/COMMIT SAVE MODE (noise reduction):
            // 'auto'   -> editor autosave, creates a debounced SHADOW version
            //             (TTL-expiring draft, merges rapid saves into one row)
            // 'manual' -> explicit user save (Save button, bulk actions, drag
            //             reorder), creates a permanent COMMIT version - this
            //             is the DEFAULT so any caller that doesn't send
            //             save_mode keeps today's behavior exactly.
            // Anything else falls back to 'manual' rather than erroring, so a
            // malformed/unexpected value can never silently create shadow
            // noise or be rejected outright.
            $saveMode = $body['save_mode'] ?? 'manual';
            if (!in_array($saveMode, ['auto', 'manual'], true)) {
                $saveMode = 'manual';
            }
            
            if ($data === null) {
                http_response_code(400);
                echo json_encode(['success' => false, 'error' => 'Missing data in request body']);
                exit;
            }
            
            // ═══════════════════════════════════════════════════════════════
            // RELATION NORMALISATION (must run before anything reads $data)
            // ═══════════════════════════════════════════════════════════════
            // - Guarantees a unique item UID (_dndId) for every list/collection
            //   item. This is what makes duplication safe: a copied item arrives
            //   with its source's UID, the collision is detected and the copy is
            //   re-issued a fresh one, so a UID can never address two items.
            // - Strips resolved relation embeds (_<fieldId>), which are derived
            //   read-time data and must never be persisted back into content.
            // - Coerces relation values to their canonical shape (uid | uid[]),
            //   migrating legacy numeric references on the way.
            $data = RelationService::normalizeForSave($key, $data, nomadSchema());
            
            // Check if content exists BEFORE saving (for webhook event type)
            // Reuse the lookup already performed during the RBAC ownership check above
            $existingData = $existingBeforeCheck;
            $isNewContent = ($existingData === null);
            
            // Track previous status for content.published detection
            $previousStatus = null;
            if (!$isNewContent && is_array($existingData)) {
                $previousStatus = $existingData['status'] ?? null;
            }
            
            // Get current user for version metadata
            $currentUser = AuthMiddleware::getCurrentUser();
            $changedBy = $currentUser ? ($currentUser->email ?? 'unknown') : 'anonymous';
            
            // SMART MEDIA INGESTION (2026-01-06):
            // Auto-detect and queue images in payload for background processing
            // Replaces URLs/Base64 with predicted local paths immediately.
            //
            // BUG FIX (CDN image loss): this was defaulting to ENABLED for
            // every regular content save, silently rewriting any external
            // image URL (e.g. a CDN reference just picked via the Media
            // Picker's CDN tab) ending in a known image extension into a
            // PREDICTED local /uploads/... path, then queueing the actual
            // download into media_queue. That queue is only ever drained by
            // the Forge import flow (queue-process.php is called exclusively
            // from the Forge finalize step) - a normal editor save never
            // triggers processing, so the predicted local file never gets
            // created and the reference becomes permanently dead ("hiányzó
            // kép"), even though the CDN item is correctly registered in
            // media_meta and visible in the media library.
            //
            // Smart Ingest exists for the Forge MIGRATION use case (pulling
            // images from an old server during import), but Forge does not
            // even go through this endpoint - it saves via
            // ContentDatabase::saveSlot() directly and downloads images with
            // its own ForgeImageQueueService/downloadExternalImage() pipeline
            // (see forge/finalize.php). So this endpoint's Smart Ingest call
            // was only ever actually hit by regular content saves, where it
            // does nothing but break intentional CDN references.
            //
            // Default is now OFF; callers that genuinely want this behavior
            // (if any) must opt in explicitly with `smart_ingest: true`.
            $enableSmartIngest = ($body['smart_ingest'] ?? false) === true;
            $jobId = null;
            
            if ($enableSmartIngest && is_array($data)) {
                try {
                    $jobId = bin2hex(random_bytes(8));
                    SmartIngestService::processPayload($data, $jobId);
                } catch (\Throwable $e) {
                    error_log("[SmartIngest] Processing failed: " . $e->getMessage());
                    // Non-blocking: continue with original data if ingestion fails
                }
            }
            
            // SNAPSHOT VERSIONING (2026-01-06):
            // Skip versioning for bulk imports to prevent database bloat
            // Used for API imports, webhooks, and mass data sync
            $isBulkImport = ($body['bulk_import'] ?? false) === true;
            
            // Build save options with ENTERPRISE OPTIMISTIC LOCKING support
            // 
            // SIMPLIFIED VERSIONING (2026-01-05):
            // - ALL saves attempt version creation
            // - Backend auto-skips if content hash is identical to last version
            // - No more frontend complexity with create_version flag
            // - Object types with high-frequency saves naturally dedupe via hash
            //
            // WASM PRECOMPUTATION (2026-01-05):
            // - Frontend can compute diff + compress using WASM
            // - Pass precomputed_version to offload server CPU
            //
            $saveOptions = [
                'changed_by' => $changedBy,
                'slot_type' => $slotType,
                'skip_versioning' => $isBulkImport,  // Skip for bulk imports
                'force_version' => false,             // Hash-based dedup handles this
                'owner_uuid' => $currentUser->uuid ?? null, // RBAC/ABAC: first-writer-wins ownership
                'version_intent' => $saveMode,         // 'auto' -> shadow, 'manual' -> commit
            ];
            
            // Add precomputed version data if provided (WASM optimization)
            if ($precomputedVersion !== null && is_array($precomputedVersion)) {
                $saveOptions['precomputed_version'] = $precomputedVersion;
            }
            
            // Add optimistic locking (hash preferred over version)
            if ($expectedHash !== null) {
                $saveOptions['expected_hash'] = $expectedHash;  // Recommended: TRUE content identity
            } elseif ($expectedVersion !== null) {
                $saveOptions['expected_version'] = $expectedVersion;  // Fallback: simpler but less robust
            }
            
            try {
                $saveResult = ContentDatabase::saveSlotWithResult($key, $data, $saveOptions);
                
                if (!$saveResult['success']) {
                    // Check if it's a conflict error
                    if (($saveResult['error'] ?? '') === 'CONFLICT') {
                        http_response_code(409); // HTTP 409 Conflict
                        $lockType = $saveResult['lock_type'] ?? 'version';
                        echo json_encode([
                            'success' => false,
                            'error' => $lockType === 'hash' ? 'HASH_CONFLICT' : 'VERSION_CONFLICT',
                            'lock_type' => $lockType,
                            'message' => 'Content was modified by another user. Please reload and try again.',
                            'expected_version' => $saveResult['expected_version'] ?? null,
                            'current_version' => $saveResult['actual_version'] ?? null,
                            'expected_hash' => $saveResult['expected_hash'] ?? null,
                            'current_hash' => $saveResult['actual_hash'] ?? null
                        ]);
                        exit;
                    }
                    throw new \RuntimeException($saveResult['error'] ?? 'Save failed');
                }
                
                $newVersion = $saveResult['version'] ?? 0;
                $newHash = $saveResult['hash'] ?? null;
                
                // BI-DIRECTIONAL ALT SYNC: Extract any ALT texts and update central media_meta (Local & External CDN)
                $schema = nomadSchema();
                $schemaDefaultLang = $schema['i18n']['defaultLanguage'] ?? 'hu';
                $availableLangs = $schema['i18n']['languages'] ?? ['hu', 'en'];
                $syncMediaAlt = function($node, ?string $currentLang = null) use (&$syncMediaAlt, $schemaDefaultLang, $availableLangs) {
                    if (is_string($node) && (str_contains($node, '<img') || str_contains($node, '<video') || str_contains($node, '<audio'))) {
                        if (preg_match_all('/<(?:img|video|audio)\b([^>]*)>/i', $node, $matches)) {
                            foreach ($matches[1] as $attrs) {
                                if (preg_match('/\bsrc\s*=\s*["\']([^"\']+)["\']/i', $attrs, $sm) &&
                                    preg_match('/\balt\s*=\s*["\']([^"\']+)["\']/i', $attrs, $am)) {
                                    $src = $sm[1];
                                    $altTxt = trim(strip_tags($am[1]));
                                    $langToUse = $currentLang ?? $schemaDefaultLang;
                                    if (!empty($altTxt)) {
                                        if (str_contains($src, '/uploads/') || str_contains($src, '/api/uploads/')) {
                                            $filename = basename(rawurldecode(parse_url($src, PHP_URL_PATH) ?? ''));
                                            if (!empty($filename)) {
                                                try {
                                                    ContentDatabase::saveMediaMeta($filename, [$langToUse => $altTxt]);
                                                } catch (\Throwable $e) {}
                                            }
                                        } elseif (str_starts_with($src, 'http://') || str_starts_with($src, 'https://')) {
                                            try {
                                                ContentDatabase::saveMediaMeta($src, [$langToUse => $altTxt]);
                                            } catch (\Throwable $e) {}
                                        }
                                    }
                                }
                            }
                        }
                        return;
                    }
                    if (!is_array($node)) return;
                    
                    if (isset($node['src']) && is_string($node['src']) && isset($node['alt'])) {
                        $src = $node['src'];
                        $cleanAlt = [];
                        if (is_array($node['alt'])) {
                            if (!empty($currentLang)) {
                                if (isset($node['alt'][$currentLang]) && is_string($node['alt'][$currentLang]) && trim($node['alt'][$currentLang]) !== '') {
                                    $cleanAlt[$currentLang] = trim(strip_tags($node['alt'][$currentLang]));
                                }
                            } else {
                                foreach ($node['alt'] as $l => $txt) {
                                    if (is_string($txt) && trim($txt) !== '') {
                                        $cleanAlt[$l] = trim(strip_tags($txt));
                                    }
                                }
                            }
                        } elseif (is_string($node['alt']) && trim($node['alt']) !== '') {
                            $langToUse = $currentLang ?? $schemaDefaultLang;
                            $cleanAlt[$langToUse] = trim(strip_tags($node['alt']));
                        }
                        
                        if (!empty($cleanAlt)) {
                            if (str_starts_with($src, '/api/uploads/') || str_starts_with($src, '/uploads/')) {
                                $filename = basename(rawurldecode($src));
                                if (!empty($filename)) {
                                    try {
                                        ContentDatabase::saveMediaMeta($filename, $cleanAlt);
                                    } catch (\Throwable $e) {
                                        error_log("[MediaSync] Failed to sync ALT for {$filename}: " . $e->getMessage());
                                    }
                                }
                            } elseif (str_starts_with($src, 'http://') || str_starts_with($src, 'https://')) {
                                try {
                                    ContentDatabase::saveMediaMeta($src, $cleanAlt);
                                } catch (\Throwable $e) {
                                    error_log("[MediaSync] Failed to sync ALT for {$src}: " . $e->getMessage());
                                }
                            }
                        }
                    }
                    
                    foreach ($node as $key => $child) {
                        $nextLang = in_array($key, $availableLangs, true) ? (string)$key : $currentLang;
                        $syncMediaAlt($child, $nextLang);
                    }
                };
                $syncMediaAlt($data);
                
                // Dispatch webhook event for content created/updated
                try {
                    $isObjectType = ($slotType === 'object');
                    $isItemised = in_array($slotType, ['list', 'collection'], true);

                    if ($isItemOperation && is_array($affectedItem)) {
                        // Single item operation (add, update, delete via saveSlotItem / item_dnd_id)
                        $itemIsDraft = (($affectedItem['status'] ?? '') === 'draft' || ($affectedItem['isDraft'] ?? false) === true);

                        if (!$itemIsDraft || $itemOperationType === 'delete') {
                            $webhookService = new WebhookService();
                            $eventType = match ($itemOperationType) {
                                'create' => 'content.created',
                                'delete' => 'content.deleted',
                                default => 'content.updated',
                            };

                            $itemId = $affectedItem['id'] ?? $affectedItem['slug'] ?? $affectedItem['_dndId'] ?? $targetItemUid ?? $key;

                            // Include item fields at top level so dynamic payload fields are resolved
                            $webhookPayload = $affectedItem;
                            $webhookPayload['id'] = $itemId;
                            $webhookPayload['slot'] = $key;
                            $webhookPayload['slot_type'] = $slotType;
                            $webhookPayload['version'] = $newVersion;
                            $webhookPayload['timestamp'] = date('c');
                            // Full content is STRICTLY this one affected item, NOT the entire slot!
                            $webhookPayload['content'] = $affectedItem;

                            if ($currentUser && $currentUser->uuid) {
                                $webhookPayload['author_id'] = $currentUser->uuid;
                            }

                            $queued = $webhookService->dispatchEventAsync($eventType, $webhookPayload, $key, $slotType);
                            error_log("[WEBHOOK DEBUG] Queued {$queued} webhooks for item {$eventType}: {$key}#{$itemId}");

                            // Detect status transitions for the single item
                            if ($itemOperationType !== 'delete') {
                                $wasPub = is_array($previousItemBeforeSave) && (
                                    ($previousItemBeforeSave['status'] ?? '') === 'published' ||
                                    ($previousItemBeforeSave['public'] ?? false) === true
                                );
                                $isPub = (
                                    ($affectedItem['status'] ?? '') === 'published' ||
                                    ($affectedItem['public'] ?? false) === true
                                );

                                if (!$wasPub && $isPub) {
                                    $webhookService->dispatchEventAsync('content.published', $webhookPayload, $key, $slotType);
                                } elseif ($wasPub && !$isPub) {
                                    $webhookService->dispatchEventAsync('content.unpublished', $webhookPayload, $key, $slotType);
                                }
                            }
                        }
                    } elseif ($isItemised && is_array($data) && array_is_list($data)) {
                        // Full array save on an itemised slot - diff to find modified items
                        $oldList = (is_array($existingBeforeCheck) && array_is_list($existingBeforeCheck)) ? $existingBeforeCheck : [];
                        $newList = $data;

                        $oldMap = [];
                        foreach ($oldList as $idx => $it) {
                            if (is_array($it)) {
                                $uid = $it['_dndId'] ?? $it['id'] ?? $it['slug'] ?? "idx_{$idx}";
                                $oldMap[$uid] = $it;
                            }
                        }
                        $newMap = [];
                        foreach ($newList as $idx => $it) {
                            if (is_array($it)) {
                                $uid = $it['_dndId'] ?? $it['id'] ?? $it['slug'] ?? "idx_{$idx}";
                                $newMap[$uid] = $it;
                            }
                        }

                        $addedUids = array_diff(array_keys($newMap), array_keys($oldMap));
                        $deletedUids = array_diff(array_keys($oldMap), array_keys($newMap));
                        $commonUids = array_intersect(array_keys($oldMap), array_keys($newMap));
                        $updatedUids = [];
                        foreach ($commonUids as $u) {
                            if (json_encode($oldMap[$u]) !== json_encode($newMap[$u])) {
                                $updatedUids[] = $u;
                            }
                        }

                        $totalChanges = count($addedUids) + count($deletedUids) + count($updatedUids);
                        $webhookService = new WebhookService();

                        if ($totalChanges > 0 && $totalChanges <= 25) {
                            foreach ($addedUids as $u) {
                                $it = $newMap[$u];
                                $p = array_merge($it, [
                                    'id' => $it['id'] ?? $it['slug'] ?? $u,
                                    'slot' => $key,
                                    'slot_type' => $slotType,
                                    'version' => $newVersion,
                                    'timestamp' => date('c'),
                                    'content' => $it,
                                ]);
                                if ($currentUser && $currentUser->uuid) $p['author_id'] = $currentUser->uuid;
                                $webhookService->dispatchEventAsync('content.created', $p, $key, $slotType);
                            }
                            foreach ($updatedUids as $u) {
                                $it = $newMap[$u];
                                $p = array_merge($it, [
                                    'id' => $it['id'] ?? $it['slug'] ?? $u,
                                    'slot' => $key,
                                    'slot_type' => $slotType,
                                    'version' => $newVersion,
                                    'timestamp' => date('c'),
                                    'content' => $it,
                                ]);
                                if ($currentUser && $currentUser->uuid) $p['author_id'] = $currentUser->uuid;
                                $webhookService->dispatchEventAsync('content.updated', $p, $key, $slotType);
                            }
                            foreach ($deletedUids as $u) {
                                $it = $oldMap[$u];
                                $p = array_merge($it, [
                                    'id' => $it['id'] ?? $it['slug'] ?? $u,
                                    'slot' => $key,
                                    'slot_type' => $slotType,
                                    'version' => $newVersion,
                                    'timestamp' => date('c'),
                                    'content' => $it,
                                ]);
                                if ($currentUser && $currentUser->uuid) $p['author_id'] = $currentUser->uuid;
                                $webhookService->dispatchEventAsync('content.deleted', $p, $key, $slotType);
                            }
                        } elseif ($totalChanges === 0) {
                            // Reorder or identical save
                            $webhookPayload = [
                                'id' => $key,
                                'slot' => $key,
                                'slot_type' => $slotType,
                                'version' => $newVersion,
                                'timestamp' => date('c'),
                                'operation' => 'reorder',
                                'content' => $data,
                            ];
                            if ($currentUser && $currentUser->uuid) $webhookPayload['author_id'] = $currentUser->uuid;
                            $webhookService->dispatchEventAsync('content.updated', $webhookPayload, $key, $slotType);
                        } else {
                            // Bulk import (> 25 changes)
                            $webhookPayload = [
                                'id' => $key,
                                'slot' => $key,
                                'slot_type' => $slotType,
                                'version' => $newVersion,
                                'timestamp' => date('c'),
                                'operation' => 'bulk_update',
                                'count' => count($data),
                                'content' => $data,
                            ];
                            if ($currentUser && $currentUser->uuid) $webhookPayload['author_id'] = $currentUser->uuid;
                            $webhookService->dispatchEventAsync('content.updated', $webhookPayload, $key, $slotType);
                        }
                    } else {
                        // Object slots and other non-itemised slots
                        $isDraft = is_array($data) && (($data['status'] ?? '') === 'draft' || ($data['isDraft'] ?? false) === true);

                        if (!$isDraft) {
                            $webhookService = new WebhookService();
                            $eventType = $isNewContent ? 'content.created' : 'content.updated';

                            $webhookPayload = array_merge(is_array($data) ? $data : [], [
                                'id' => $key,
                                'slot' => $key,
                                'slot_type' => $slotType,
                                'version' => $newVersion,
                                'timestamp' => date('c'),
                                'content' => $data,
                            ]);

                            if ($currentUser && $currentUser->uuid) {
                                $webhookPayload['author_id'] = $currentUser->uuid;
                            }

                            if ($isObjectType) {
                                $webhookService->scheduleDebounced($eventType, $webhookPayload, $key, $slotType, 10);
                            } else {
                                $webhookService->dispatchEventAsync($eventType, $webhookPayload, $key, $slotType);
                            }

                            $newStatus = is_array($data) ? ($data['status'] ?? null) : null;
                            $isPublishedTransition = $newStatus === 'published' && $previousStatus !== 'published';
                            if ($isPublishedTransition) {
                                if ($isObjectType) {
                                    $webhookService->scheduleDebounced('content.published', $webhookPayload, $key, $slotType, 10);
                                } else {
                                    $webhookService->dispatchEventAsync('content.published', $webhookPayload, $key, $slotType);
                                }
                            }
                        }
                    }
                } catch (\Exception $e) {
                    error_log("[WEBHOOK ERROR] Dispatch failed for content: " . $e->getMessage() . "\n" . $e->getTraceAsString());
                }
                
                // Generate static cache for faster public access
                try {
                    // The persisted content changed, so any memoised target-slot
                    // lookup for this key is stale.
                    RelationService::clearCache($key);
                    
                    // Rebuild the derived reverse index for this slot. Wholesale
                    // rebuild from the saved payload means deleted items, removed
                    // fields and reordered values need no special handling.
                    RelationService::syncRelations($key, $data, nomadSchema());
                    
                    StaticCacheService::generateForSlot($key, $data, $slotType);
                    
                    // PERMAFROST FIX: Cascade updates to dependent slots
                    // If this slot is a "parent" (e.g., authors), regenerate all
                    // "child" slots that embed its data (e.g., posts with author info)
                    DependencyGraphService::touchDependents($key);
                } catch (\Exception $e) {
                    error_log("[StaticCache] Generation failed for {$key}: " . $e->getMessage());
                }
                
                // Return success with version + hash for ENTERPRISE optimistic locking
                // version_created/skip_reason let the frontend distinguish a genuine
                // new history entry from a semantically-empty save that still
                // persisted the content but produced no version (noise reduction).
                echo json_encode([
                    'success' => true, 
                    'message' => 'Data saved successfully',
                    'version' => $newVersion,
                    'hash' => $newHash,  // For next save's optimistic lock (recommended)
                    'version_created' => $saveResult['version_created'] ?? null,
                    'skip_reason' => $saveResult['skip_reason'] ?? null,
                    'version_type' => $saveResult['version_type'] ?? null,
                ]);
                
            } catch (OptimisticLockException $e) {
                http_response_code(409);
                echo json_encode([
                    'success' => false,
                    'error' => 'VERSION_CONFLICT',
                    'message' => $e->getMessage(),
                    'expected_version' => $e->expectedVersion,
                    'current_version' => $e->actualVersion
                ]);
            }
            break;
            
        case 'DELETE':
            // SECURITY: Validate CSRF token for session-based requests
            CSRFMiddleware::validateForSession();
            
            // Require auth
            AuthMiddleware::requireAuth();
            
            $key = InputSanitizer::slotKey($_GET['key'] ?? '');
            
            if (empty($key)) {
                http_response_code(400);
                echo json_encode(['success' => false, 'error' => 'Missing key parameter']);
                exit;
            }
            
            // RBAC: role must have access to this slot at all
            AuthMiddleware::requireSlotAccess($key);
            
            // ABAC: content:delete:* (any content) OR content:delete:own (only own)
            $hasFullDelete = AuthMiddleware::hasPermission('content:delete:*');
            $hasOwnDelete = !$hasFullDelete && AuthMiddleware::hasPermission('content:delete:own', $key);
            if (!$hasFullDelete && !$hasOwnDelete) {
                AuthMiddleware::requirePermission('content:delete:*'); // triggers 403 with clear message
            }
            
            if (ContentDatabase::deleteSlot($key)) {
                // Dispatch webhook event for content deleted
                try {
                    $webhookService = new WebhookService();
                    $currentUser = AuthMiddleware::getCurrentUser();
                    
                    $webhookPayload = [
                        'id' => $key,
                        'slot' => $key,
                        'timestamp' => date('c'),
                    ];
                    if ($currentUser && $currentUser->uuid) {
                        $webhookPayload['author_id'] = $currentUser->uuid;
                    }
                    
                    $webhookService->dispatchEventAsync('content.deleted', $webhookPayload, $key);
                } catch (\Exception $e) {
                    error_log("Webhook dispatch failed for content.deleted: " . $e->getMessage());
                }
                
                // Invalidate static cache
                try {
                    StaticCacheService::invalidateSlot($key);
                } catch (\Exception $e) {
                    error_log("[StaticCache] Invalidation failed for {$key}: " . $e->getMessage());
                }
                
                // Drop the slot's rows from the derived relation index — both the
                // rows it owns and the rows other slots hold against it — then
                // regenerate every slot that pointed at it so their embeds stop
                // referencing content that no longer exists.
                try {
                    $dependents = RelationService::getDependentSlots($key);
                    RelationService::forgetSlot($key);
                    RelationService::clearCache();
                    
                    foreach ($dependents as $depKey) {
                        $depData = ContentDatabase::getSlot($depKey);
                        if ($depData !== null) {
                            StaticCacheService::generateForSlot($depKey, $depData, null, true);
                        }
                    }
                } catch (\Exception $e) {
                    error_log("[RelationService] Cleanup after delete failed for {$key}: " . $e->getMessage());
                }
                
                echo json_encode(['success' => true, 'message' => 'Data deleted successfully']);
            } else {
                http_response_code(in_array($e->getCode(), [403, 409, 410, 422, 503], true) ? $e->getCode() : 500);
                echo json_encode(['success' => false, 'error' => 'Failed to delete data']);
            }
            break;
            
        default:
            http_response_code(405);
            echo json_encode(['success' => false, 'error' => 'Method not allowed']);
    }
} catch (OptimisticLockException $e) {
    http_response_code(409);
    echo json_encode(['success'=>false,'error'=>'CONFLICT','message'=>$e->getMessage(),'lock_type'=>$e->lockType,'current_version'=>$e->actualVersion,'current_hash'=>$e->actualHash]);
} catch (\NomadCMS\Services\Seo\SeoException $e) {
    // SEO lifecycle validation participates in the content transaction. Surface
    // its domain status instead of treating a rejected publication as a crash.
    http_response_code($e->status);
    echo json_encode([
        'success' => false,
        'error' => $e->errorCode,
        // A conflicting target may belong to another editor's private slot.
        'details' => array_intersect_key($e->details, ['path' => true]),
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
} catch (\OutOfBoundsException $e) {
    http_response_code(404);
    echo json_encode(['success'=>false,'error'=>$e->getMessage()]);
} catch (\InvalidArgumentException|\DomainException $e) {
    http_response_code($e->getCode() === 422 ? 422 : 400);
    echo json_encode(['success'=>false,'error'=>$e->getMessage()]);
} catch (\Exception $e) {
    http_response_code(in_array($e->getCode(), [403, 409, 410, 422, 503], true) ? $e->getCode() : 500);
    
    // Only show detailed errors in development mode
    // SECURITY: Never expose stack traces in production
    $isDevMode = (($_ENV['APP_DEBUG'] ?? 'false') === 'true') 
                 && (($_ENV['APP_ENV'] ?? 'production') !== 'production');
    
    echo json_encode([
        'success' => false,
        'error' => ($isDevMode || $e->getCode() > 0) ? $e->getMessage() : 'Internal server error',
    ]);
}
