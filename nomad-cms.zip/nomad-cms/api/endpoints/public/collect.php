<?php
/**
 * NOMAD CMS - Analytics Beacon Endpoint (0-PII)
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * ROUTES
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *   POST    /api/collect                        beacon (public, no auth)
 *   OPTIONS /api/collect                         CORS preflight
 *
 *   Rewrite-independent equivalent:
 *   POST /api/endpoints/public/collect.php
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * WHY THIS ENDPOINT NEVER TOUCHES massive.sqlite ON THE HOT PATH
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * Every other write path in this codebase (Forms, Webhooks, ...) can afford a
 * SQLite INSERT per request because those are comparatively rare events. A
 * page-view beacon fires on every single page load of the measured site, so
 * this endpoint is deliberately built to do the ABSOLUTE MINIMUM before
 * answering:
 *
 *   1. Validate + normalize the request (RequestNormalizer - in memory only)
 *   2. Send 204 No Content immediately
 *   3. AFTER the response is flushed (fastcgi_finish_request), append one
 *      line to today's NDJSON spool file (SpoolWriter - no DB connection)
 *
 * The (comparatively expensive) SQLite ingest happens later, in bulk, on the
 * piggyback path (task 5/8) - never inline with a visitor's request.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * SECURITY MODEL - INTENTIONALLY UNAUTHENTICATED, MINIMAL SURFACE
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *   1. Hard body size ceiling (a beacon payload is tiny; anything else is rejected)
 *   2. AnalyticsSettingsService::isEnabled() kill switch
 *   3. Domain allowlist (optional; empty = accept any host, single-site default)
 *   4. RequestNormalizer's own rejection paths (bot UA, DNT/GPC, prefetch, malformed URL)
 *   5. Per-IP+day event budget is enforced later at ingest time via
 *      AnalyticsSettingsService::getDailyEventCap() (task 5/7) - not here, to
 *      keep this endpoint free of any database round trip.
 *   6. No cookies are read or set. No JavaScript execution capability of any
 *      kind is exposed - this endpoint is pure data intake.
 *   7. Global panic mode (bootstrap blocks every non-GET while active) - see
 *      PanicModeMiddleware, applied automatically by bootstrap.php.
 *
 * Always answers 204 (or CORS 204 for OPTIONS) even when the event is
 * silently dropped: a script embedded on a third-party page must never learn
 * WHY an event was or wasn't recorded (bot detection, DNT, disabled module,
 * etc. are not information to hand back to the calling page).
 *
 * @package NomadCMS
 */

declare(strict_types=1);

require_once __DIR__ . '/../../bootstrap.php';

use NomadCMS\Services\Analytics\AnalyticsSettingsService;
use NomadCMS\Services\Analytics\RequestNormalizer;
use NomadCMS\Services\Analytics\SpoolWriter;
use NomadCMS\Services\Analytics\VisitorHashService;

/** Hard ceiling on the raw request body - a beacon payload is a few hundred bytes */
const ANALYTICS_COLLECT_MAX_BODY_BYTES = 8192;

/**
 * Client IP, honouring proxy headers only from configured TRUSTED_PROXIES.
 * Mirrors RateLimitMiddleware::getClientIp() / forms.php's formsClientIp().
 */
function analyticsClientIp(): string
{
    $directIp = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';

    $trustedProxies = array_filter(array_map('trim', explode(',', $_ENV['TRUSTED_PROXIES'] ?? '')));
    if (empty($trustedProxies) || !in_array($directIp, $trustedProxies, true)) {
        return $directIp;
    }

    foreach (['HTTP_CF_CONNECTING_IP', 'HTTP_X_FORWARDED_FOR', 'HTTP_X_REAL_IP'] as $header) {
        if (!empty($_SERVER[$header])) {
            $candidate = trim(explode(',', (string) $_SERVER[$header])[0]);
            if (filter_var($candidate, FILTER_VALIDATE_IP)) {
                return $candidate;
            }
        }
    }

    return $directIp;
}

/**
 * Collect the small set of request headers RequestNormalizer needs.
 *
 * @return array<string, string>
 */
function analyticsCollectHeaders(): array
{
    $headers = [];
    foreach (['DNT', 'SEC_GPC', 'SEC_PURPOSE', 'PURPOSE', 'SEC_CH_UA_MOBILE', 'CF_IPCOUNTRY', 'X_COUNTRY_CODE'] as $name) {
        $serverKey = 'HTTP_' . $name;
        if (isset($_SERVER[$serverKey])) {
            $headers[str_replace('_', '-', strtolower($name))] = (string) $_SERVER[$serverKey];
        }
    }
    return $headers;
}

/**
 * Apply CORS for the beacon: any origin may embed the snippet (this is a
 * public write-only intake, not a place that returns anything sensitive), and
 * credentials are never allowed - the endpoint takes no cookies.
 */
function analyticsApplyCors(?string $origin): void
{
    if ($origin === null || $origin === '') {
        return;
    }
    header('Access-Control-Allow-Origin: ' . $origin);
    header('Vary: Origin');
}

$method = strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET');
$origin = $_SERVER['HTTP_ORIGIN'] ?? null;

analyticsApplyCors($origin);

if ($method === 'OPTIONS') {
    header('Access-Control-Allow-Methods: POST, OPTIONS');
    header('Access-Control-Allow-Headers: Content-Type');
    header('Access-Control-Max-Age: 86400');
    http_response_code(204);
    exit;
}

if ($method !== 'POST') {
    header('Allow: POST, OPTIONS');
    http_response_code(405);
    exit;
}

// Hard body size ceiling BEFORE reading the whole body into memory.
$contentLength = (int) ($_SERVER['CONTENT_LENGTH'] ?? 0);
if ($contentLength > ANALYTICS_COLLECT_MAX_BODY_BYTES) {
    http_response_code(204); // Never reveal why - just drop silently.
    exit;
}

$rawBody = file_get_contents('php://input', false, null, 0, ANALYTICS_COLLECT_MAX_BODY_BYTES + 1);
if ($rawBody === false || strlen($rawBody) > ANALYTICS_COLLECT_MAX_BODY_BYTES) {
    http_response_code(204);
    exit;
}

$payload = json_decode($rawBody, true);
if (!is_array($payload)) {
    $payload = [];
}

// Everything from here on is prepared in memory only - nothing touches disk
// or a database connection until AFTER the response has been sent.
$settings = AnalyticsSettingsService::getInstance();

$shouldRecord = $settings->isEnabled();

$normalized = null;
$visitorHash = null;
$day = null;

if ($shouldRecord) {
    $url = (string) ($payload['url'] ?? '');
    $referrer = isset($payload['referrer']) ? (string) $payload['referrer'] : null;
    $userAgent = (string) ($_SERVER['HTTP_USER_AGENT'] ?? '');

    $normalized = RequestNormalizer::normalize([
        'url' => $url,
        'referrer' => $referrer,
        'user_agent' => $userAgent,
        'headers' => analyticsCollectHeaders(),
        'host_allowlist' => $settings->getDomainAllowlist(),
        'respect_dnt' => $settings->isRespectDntEnabled(),
        'bot_filter_enabled' => $settings->isBotFilterEnabled(),
    ]);

    if ($normalized !== null) {
        $ip = analyticsClientIp();
        $day = date('Y-m-d');
        $visitorHash = VisitorHashService::hash($ip, $userAgent, $day);
    }
}

// =============================================================================
// RESPOND IMMEDIATELY - the calling page must never wait on disk I/O
// =============================================================================

http_response_code(204);
header('Cache-Control: no-store');
header('Content-Length: 0');

if (function_exists('fastcgi_finish_request')) {
    fastcgi_finish_request();
} else {
    if (ob_get_level() > 0) {
        ob_end_flush();
    }
    flush();
}

// =============================================================================
// POST-RESPONSE WORK - append-only, no flock, no database connection
// =============================================================================

if ($normalized !== null && $visitorHash !== null && $day !== null) {
    try {
        SpoolWriter::append([
            'ts' => time(),
            'day' => $day,
            'host' => $normalized['host'],
            'path' => $normalized['path'],
            'referrer_domain' => $normalized['referrer_domain'],
            'device' => $normalized['device'],
            'country' => $normalized['country'],
            'utm_source' => $normalized['utm_source'],
            'utm_medium' => $normalized['utm_medium'],
            'utm_campaign' => $normalized['utm_campaign'],
            'utm_term' => $normalized['utm_term'],
            'utm_content' => $normalized['utm_content'],
            'visitor_hash' => $visitorHash,
        ]);
    } catch (\Throwable $e) {
        // Never let a spool write failure surface anywhere - the response is
        // already gone, so there's nobody left to tell.
        error_log('[Analytics] Spool write error: ' . $e->getMessage());
    }
}
