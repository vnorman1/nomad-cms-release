<?php
/**
 * NOMAD CMS - Analytics Script Fallback Server
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * WHY THIS FILE EXISTS DESPITE THE SCRIPT BEING "GENUINELY STATIC"
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * In production, api/static/nomad.js (written once by
 * AnalyticsScriptGenerator - see that class's docblock) is served directly by
 * the web server via the SAME nginx `location /api/static/ { alias ...; }`
 * block the README already documents for content JSON - true zero-PHP-overhead,
 * this file is never even reached.
 *
 * On setups WITHOUT that alias (the PHP built-in dev server used throughout
 * this project's own test suite, or a host where the alias was never
 * configured), a request for /api/static/nomad.js would otherwise 404.
 * This file is the fallback for exactly that case, reached only through the
 * Router (GET /api/nomad.js) rather than the static path.
 *
 * DELIBERATELY DOES NOT require bootstrap.php: no env loading, no DB
 * connection warmup, no middleware chain - just a raw file read and a few
 * headers. This keeps the fallback close to the "zero overhead" cost of a
 * real static file, for the one deployment shape where a real static file
 * isn't being used.
 *
 * @package NomadCMS
 */

declare(strict_types=1);

$scriptPath = __DIR__ . '/../../static/nomad.js';

if (!is_file($scriptPath)) {
    http_response_code(404);
    header('Content-Type: text/plain; charset=utf-8');
    echo '// nomad.js not yet generated';
    exit;
}

header('Content-Type: application/javascript; charset=utf-8');
header('Cache-Control: public, max-age=300, must-revalidate');
header('X-Content-Type-Options: nosniff');
header('Access-Control-Allow-Origin: *'); // The script itself is public, non-sensitive JS - safe to load cross-origin.

readfile($scriptPath);
