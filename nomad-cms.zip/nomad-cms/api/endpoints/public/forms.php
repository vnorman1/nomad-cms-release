<?php
/**
 * NOMAD CMS - Public Form Endpoint (Formspree-style)
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * ROUTES
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *   GET     /api/forms/{slug}                                  public schema
 *   POST    /api/forms/{slug}                                  submit
 *   OPTIONS /api/forms/{slug}                                  CORS preflight
 *
 *   Rewrite-independent equivalents (work without mod_rewrite / front controller):
 *   GET/POST /api/endpoints/public/forms.php?slug={slug}
 *
 * The pretty URL is the canonical one to embed. The direct file URL exists
 * because the Router simply maps paths onto this file, so both come for free -
 * and an embedded <form action> lives in third-party HTML for years, long enough
 * to outlive a server move where rewrite rules break.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * SECURITY MODEL - THIS ENDPOINT IS INTENTIONALLY UNAUTHENTICATED
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * Anyone on the internet can POST here; that is the entire point of an embeddable
 * form. The defences are therefore:
 *
 *   1. per-form allowed_origins allowlist (optional, empty = any origin)
 *   2. per-form, per-IP SQLite rate limit (FormRateLimiter)
 *   3. honeypot + timing heuristics (FormSpamGuard) - stored as spam, not dropped
 *   4. stateless time-bucket Proof-of-Work (FormPowGuard) - stored as spam, not
 *      dropped; zero server round-trip, zero server secret, zero 3rd party.
 *      Adaptively backed by a GPU-resistant memory-hard "Tier 2" scratchpad
 *      layer the CLIENT switches to on its own (fast submit / no interaction -
 *      see FormPowGuard::contextImpliesTier2()), re-verified server-side with
 *      one deterministic replay of the same walk - never trusted at face
 *      value.
 *   5. hard payload ceilings (body size, field count, key/value length)
 *   6. strict value validation against the form's field schema
 *   7. global panic mode (bootstrap blocks every non-GET while active)
 *
 * Encryption is read from the STORED form definition - never from request
 * headers. The massive slots take their `encrypted` flag from frontend-signed
 * headers (SlotConfigSigning), whose signing key is the caller's JWT; with no
 * JWT here the documented fallback is "unencrypted", which would silently store
 * plaintext personal data. If a form requires encryption and the key is missing,
 * this endpoint returns 503 instead.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * CONTENT TYPES
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *   application/json                     -> JSON response {success:true,id:…}
 *   application/x-www-form-urlencoded    -> 302 redirect or built-in thank-you page
 *   multipart/form-data                  -> same as urlencoded; FILE parts are
 *                                           rejected with 415 (v1 has no upload
 *                                           support - failing loudly beats
 *                                           silently discarding an attachment)
 *
 * @package NomadCMS
 */

declare(strict_types=1);

require_once __DIR__ . '/../../bootstrap.php';

use NomadCMS\Security\InputSanitizer;
use NomadCMS\Services\Forms\CaptchaConfigStore;
use NomadCMS\Services\Forms\CaptchaVerifier;
use NomadCMS\Services\Forms\FormAttachmentService;
use NomadCMS\Services\Forms\FormCryptoException;
use NomadCMS\Services\Forms\FormPowGuard;
use NomadCMS\Services\Forms\FormFileException;
use NomadCMS\Services\Forms\FormFileValidator;
use NomadCMS\Services\Forms\FormNotFoundException;
use NomadCMS\Services\Forms\FormNotifier;
use NomadCMS\Services\Forms\FormRateLimiter;
use NomadCMS\Services\Forms\FormService;
use NomadCMS\Services\Forms\FormSpamGuard;
use NomadCMS\Services\Forms\FormSubmissionService;
use NomadCMS\Services\Forms\FormValidationException;
use NomadCMS\Services\Forms\FormValidator;
use NomadCMS\Services\Forms\FormsSchema;

// =============================================================================
// RESPONSE HELPERS
// =============================================================================

/**
 * Apply per-form CORS headers.
 *
 * Deliberately NOT handlePreflight(): that helper works off the global
 * CORS_ALLOWED_ORIGINS list, which is about the admin SPA. An embeddable form
 * has its own, per-form allowlist. Credentials are never allowed here - the
 * endpoint takes no cookies and no auth, so echoing an origin with
 * Allow-Credentials would only widen the attack surface for nothing.
 *
 * @param array<int, string> $allowedOrigins
 */
function formsApplyCors(array $allowedOrigins, ?string $origin): void
{
    if ($origin === null || $origin === '') {
        return;
    }

    if (empty($allowedOrigins)) {
        // No allowlist configured: the form is meant to be embeddable anywhere.
        header('Access-Control-Allow-Origin: *');
    } elseif (in_array($origin, $allowedOrigins, true)) {
        header('Access-Control-Allow-Origin: ' . $origin);
        header('Vary: Origin');
    }
}

/**
 * @param array<string, mixed> $payload
 */
function formsJson(int $status, array $payload): never
{
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

/**
 * Redirect a classic HTML form submit back to the site.
 *
 * @param array<string, string> $params
 */
function formsRedirect(string $url, array $params): never
{
    $separator = str_contains($url, '?') ? '&' : '?';
    $target = $url . $separator . http_build_query($params);

    http_response_code(302);
    header('Location: ' . $target);
    exit;
}

/**
 * Built-in fallback page for classic form submits with no redirect_url.
 *
 * Self-contained (no CSS/JS from anywhere), and every interpolated value is
 * escaped - the form name is admin-authored but the messages can echo back
 * validation output.
 *
 * @param array<int, string> $messages
 */
function formsHtmlPage(int $status, string $formName, string $heading, array $messages, bool $isError): never
{
    http_response_code($status);
    header('Content-Type: text/html; charset=utf-8');
    header('Cache-Control: no-store');

    $safeName = htmlspecialchars($formName, ENT_QUOTES, 'UTF-8');
    $safeHeading = htmlspecialchars($heading, ENT_QUOTES, 'UTF-8');
    $accent = $isError ? '#b91c1c' : '#111111';

    $list = '';
    foreach ($messages as $message) {
        $list .= '<li>' . htmlspecialchars($message, ENT_QUOTES, 'UTF-8') . '</li>';
    }
    $listBlock = $list === '' ? '' : "<ul>$list</ul>";

    echo <<<HTML
<!DOCTYPE html>
<html lang="hu">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex, nofollow">
<title>{$safeHeading} – {$safeName}</title>
<style>
    :root { color-scheme: light dark; }
    body { margin:0; min-height:100vh; display:flex; align-items:center; justify-content:center;
           font-family: ui-sans-serif, system-ui, -apple-system, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
           background:#fafafa; color:#111; padding:24px; }
    main { max-width:32rem; width:100%; border:1px solid #e5e5e5; background:#fff; padding:2rem; }
    h1 { font-size:1.5rem; margin:0 0 .5rem; letter-spacing:-.02em; color:{$accent}; }
    p { margin:0 0 1rem; line-height:1.6; }
    ul { margin:0 0 1rem 1.25rem; padding:0; line-height:1.6; }
    small { display:block; margin-top:1.5rem; font-size:.75rem; letter-spacing:.08em;
            text-transform:uppercase; opacity:.5; }
    @media (prefers-color-scheme: dark) {
        body { background:#0a0a0a; color:#f5f5f5; }
        main { background:#111; border-color:#262626; }
    }
</style>
</head>
<body>
<main>
    <h1>{$safeHeading}</h1>
    <p>{$safeName}</p>
    {$listBlock}
    <small>NOMAD CMS</small>
</main>
</body>
</html>
HTML;
    exit;
}

/**
 * Fail either as JSON or as a redirect/HTML page, matching how the form was sent.
 *
 * @param array<string, string> $errors
 */
function formsFail(
    bool $wantsJson,
    int $status,
    string $code,
    string $message,
    array $errors = [],
    ?string $redirectUrl = null,
    string $formName = 'Űrlap'
): never {
    if ($wantsJson) {
        formsJson($status, [
            'success' => false,
            'error' => $message,
            'code' => $code,
            'errors' => $errors,
        ]);
    }

    if ($redirectUrl !== null) {
        formsRedirect($redirectUrl, ['nomad_form' => 'error', 'nomad_code' => $code]);
    }

    $messages = empty($errors) ? [$message] : array_values($errors);
    formsHtmlPage($status, $formName, 'A beküldés nem sikerült', $messages, true);
}

/**
 * Client IP, honouring proxy headers only from configured TRUSTED_PROXIES.
 *
 * Mirrors RateLimitMiddleware's logic: an untrusted X-Forwarded-For would let
 * anyone bypass the rate limiter by rotating a header value.
 */
function formsClientIp(): string
{
    $directIp = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';

    $trustedProxies = array_filter(array_map('trim', explode(',', $_ENV['TRUSTED_PROXIES'] ?? '')));
    if (empty($trustedProxies) || !in_array($directIp, $trustedProxies, true)) {
        return $directIp;
    }

    foreach (['HTTP_CF_CONNECTING_IP', 'HTTP_X_FORWARDED_FOR', 'HTTP_X_REAL_IP'] as $header) {
        if (!empty($_SERVER[$header])) {
            $candidate = trim(explode(',', (string) $_SERVER[$header])[0]);
            if (filter_var($candidate, FILTER_VALIDATE_IP)) {
                return $candidate;
            }
        }
    }

    return $directIp;
}

// =============================================================================
// REQUEST SETUP
// =============================================================================

$method = strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET');
$origin = $_SERVER['HTTP_ORIGIN'] ?? null;
$contentType = strtolower(trim((string) ($_SERVER['CONTENT_TYPE'] ?? $_SERVER['HTTP_CONTENT_TYPE'] ?? '')));
$accept = strtolower((string) ($_SERVER['HTTP_ACCEPT'] ?? ''));

$isJsonRequest = str_contains($contentType, 'application/json');
$isMultipart = str_contains($contentType, 'multipart/form-data');
$isUrlEncoded = str_contains($contentType, 'application/x-www-form-urlencoded');

// A classic <form> POST sends urlencoded/multipart and expects a page back.
// Anything else (fetch/XHR/curl) gets JSON.
$wantsJson = $isJsonRequest
    || (!$isMultipart && !$isUrlEncoded)
    || (str_contains($accept, 'application/json') && !str_contains($accept, 'text/html'));

$slug = InputSanitizer::slug($_GET['slug'] ?? '', 64);

if ($slug === null || $slug === '') {
    formsApplyCors([], $origin);
    formsFail($wantsJson, 400, 'MISSING_SLUG', 'Hiányzó űrlap azonosító.');
}

// Load the definition first: CORS, rate limit and encryption all depend on it.
try {
    $form = FormService::requireBySlug($slug);
} catch (FormNotFoundException) {
    formsApplyCors([], $origin);
    formsFail($wantsJson, 404, 'FORM_NOT_FOUND', 'Nincs ilyen űrlap.');
}

$allowedOrigins = FormService::allowedOrigins($form);
$formName = (string) ($form['data']['name'] ?? 'Űrlap');
$redirectUrl = $form['data']['settings']['redirect_url'] ?? null;
$redirectUrl = is_string($redirectUrl) && $redirectUrl !== '' ? $redirectUrl : null;

formsApplyCors($allowedOrigins, $origin);

// =============================================================================
// OPTIONS - CORS PREFLIGHT
// =============================================================================

if ($method === 'OPTIONS') {
    header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
    header('Access-Control-Allow-Headers: Content-Type, Accept');
    header('Access-Control-Max-Age: 86400');
    http_response_code(204);
    exit;
}

// An inactive form behaves exactly like a non-existent one, so an outsider
// cannot tell the difference (and cannot enumerate paused forms).
if (!FormService::isActive($form)) {
    formsFail($wantsJson, 404, 'FORM_NOT_FOUND', 'Nincs ilyen űrlap.');
}

// =============================================================================
// GET - PUBLIC SCHEMA
// =============================================================================

if ($method === 'GET') {
    formsJson(200, [
        'success' => true,
        'form' => FormService::publicSchema($form),
    ]);
}

if ($method !== 'POST') {
    header('Allow: GET, POST, OPTIONS');
    formsFail($wantsJson, 405, 'METHOD_NOT_ALLOWED', 'Nem támogatott HTTP metódus.');
}

// =============================================================================
// POST - SUBMIT
// =============================================================================

// ── Origin allowlist ────────────────────────────────────────────────────────
// Only enforced when the request actually carries an Origin. Server-to-server
// posts and plain HTML form submits legitimately have none, and rejecting those
// would break the primary use case.
if (!empty($allowedOrigins) && $origin !== null && $origin !== '') {
    $normalizedOrigin = FormService::normalizeOrigin($origin);
    if ($normalizedOrigin === null || !in_array($normalizedOrigin, $allowedOrigins, true)) {
        formsFail(
            $wantsJson,
            403,
            'ORIGIN_NOT_ALLOWED',
            'Ez a domain nincs engedélyezve ehhez az űrlaphoz.',
            [],
            null,
            $formName
        );
    }
}

// ── Rate limit ──────────────────────────────────────────────────────────────
$clientIp = formsClientIp();
$rate = FormRateLimiter::hit($slug, $clientIp, FormService::rateLimitPerMinute($form));

header('X-RateLimit-Limit: ' . $rate['limit']);
header('X-RateLimit-Remaining: ' . $rate['remaining']);

if (!$rate['allowed']) {
    header('Retry-After: ' . $rate['retry_after']);
    if ($wantsJson) {
        formsJson(429, [
            'success' => false,
            'error' => 'Túl sok beküldés rövid idő alatt. Kérlek próbáld újra később.',
            'code' => 'RATE_LIMIT_EXCEEDED',
            'retry_after' => $rate['retry_after'],
        ]);
    }
    formsFail($wantsJson, 429, 'RATE_LIMIT_EXCEEDED', 'Túl sok beküldés rövid idő alatt.', [], $redirectUrl, $formName);
}

// ── Payload parsing (VALUES ONLY - no file writes happen here) ─────────────
//
// Deliberately built BEFORE any attachment is written to disk. The captcha
// gate right after this block needs the raw values (to find the token) and
// must be able to reject a request without ever touching the filesystem -
// otherwise a bot could cause a file write before proving it isn't a bot.
$rawValues = [];

/**
 * Attachments written to disk during this request.
 *
 * Declared here (empty) so every failure path below - including the captcha
 * gate, which runs before any file is ever written - can safely call
 * rollback() unconditionally. Populated further down, only once the captcha
 * gate has passed.
 *
 * @var array<int, array<string, mixed>> $storedAttachments
 */
$storedAttachments = [];

if ($isJsonRequest) {
    $raw = file_get_contents('php://input');
    $raw = $raw === false ? '' : $raw;

    if (strlen($raw) > FormsSchema::MAX_BODY_BYTES) {
        formsFail($wantsJson, 413, 'PAYLOAD_TOO_LARGE', 'A beküldött adat túl nagy.');
    }

    $decoded = json_decode($raw, true);
    if (!is_array($decoded)) {
        formsFail($wantsJson, 400, 'INVALID_JSON', 'Érvénytelen JSON törzs.');
    }

    // Accept both a flat object and {"values": {...}} for convenience
    $rawValues = isset($decoded['values']) && is_array($decoded['values']) ? $decoded['values'] : $decoded;
} else {
    // PHP has already parsed $_POST (text fields) and $_FILES (file parts)
    // separately by the time this script runs - reading $_POST here does NOT
    // write anything to disk. Only FormAttachmentService::intake() further
    // down does that, and only after the captcha gate has passed.
    $rawValues = $_POST;
}

if (!is_array($rawValues)) {
    formsFail($wantsJson, 400, 'INVALID_PAYLOAD', 'Érvénytelen beküldött adat.');
}

// ── Ceilings (before any per-field work, still before any file write) ──────
try {
    FormValidator::enforceCeilings($rawValues);
} catch (FormValidationException $e) {
    formsFail($wantsJson, 413, 'PAYLOAD_TOO_LARGE', $e->getMessage(), $e->getErrors(), $redirectUrl, $formName);
}

// ── Captcha gate (BEFORE file intake, before persist) ───────────────────────
//
// Resolved from api/external/captcha.json - never from the form definition's
// settings JSON (see CaptchaConfigStore). provider === 'none' is the default
// for every form that never configured captcha, so this is a no-op for them.
$captchaConfig = CaptchaConfigStore::resolveForForm($form);
$captchaProvider = $captchaConfig['provider'];

// Merged into the spam verdict below; captcha failures answer with their own
// dedicated error codes/messages instead, since - unlike honeypot/timing -
// they are not silent bot-bait: the visitor is explicitly told to retry.
$captchaSpamOverride = ['is_spam' => false, 'reason' => null];

if ($captchaProvider !== 'none') {
    $captchaToken = FormSpamGuard::extractToken($rawValues, $captchaProvider);

    if ($captchaToken === null) {
        formsFail($wantsJson, 400, 'CAPTCHA_REQUIRED', 'Kérjük, igazold, hogy nem vagy robot!', [], $redirectUrl, $formName);
    }

    $captchaResult = CaptchaVerifier::verify(
        $captchaProvider,
        $captchaToken,
        (string) $captchaConfig['secret_key'],
        $clientIp
    );

    if ($captchaResult['state'] === CaptchaVerifier::STATE_FAILED) {
        formsFail($wantsJson, 400, 'CAPTCHA_FAILED', 'Sikertelen captcha ellenőrzés.', [], $redirectUrl, $formName);
    }

    if ($captchaResult['state'] === CaptchaVerifier::STATE_UNREACHABLE) {
        // Fail-OPEN: the provider being unreachable is not the visitor's
        // fault, and rejecting outright would lose a real lead. Instead the
        // submission is saved as spam for manual review - never silently
        // dropped, same rationale as the honeypot's own "store, don't drop".
        $captchaSpamOverride = ['is_spam' => true, 'reason' => FormSpamGuard::REASON_CAPTCHA_UNVERIFIED];
    }
}

// ── Spam heuristics (honeypot + timing + Proof-of-Work) ─────────────────────
$honeypotField = FormService::honeypotField($form);
$honeypotEnabled = FormService::honeypotEnabled($form);

// Stateless time-bucket PoW (see FormPowGuard) is evaluated BEFORE the timing
// heuristic below on purpose: a successful Tier 2 (memory-hard) proof is
// itself strong evidence that a fast submission was not a bot cutting
// corners - it paid a real, deliberate memory-bandwidth cost to get there.
// Without this ordering, FormSpamGuard::inspect()'s own `_nomad_ts` timing
// check (REASON_TOO_FAST, unconditionally < 2s) would flag the SAME fast
// submission as spam even though the more expensive Tier 2 layer just
// vouched for it - defeating the entire point of the adaptive scheme. Same
// fail-SOFT contract as the captcha-unreachable case above: a missing/
// invalid proof does not reject the request outright, it only marks the
// submission as spam - a JS-disabled visitor, a blocked script, or a stale
// pre-PoW embed snippet are none of them actually bots, and none of them
// should silently lose their lead.
$powSpamOverride = ['is_spam' => false, 'reason' => null];
$tier2Verified = false;
if (FormService::powEnabled($form)) {
    $powResult = FormPowGuard::verify($rawValues, $slug, $honeypotField, FormService::powDifficulty($form));
    if (!$powResult['ok']) {
        $powSpamOverride = ['is_spam' => true, 'reason' => $powResult['reason']];
    } elseif (FormPowGuard::submittedTier($rawValues) === 2) {
        $tier2Verified = true;
    }
}

// The timing heuristic is skipped when a Tier 2 proof already verified this
// exact submission - see the comment above. The honeypot check always runs
// regardless: solving Tier 2 says nothing about whether the hidden field was
// filled in, so it must not suppress that independent signal.
$verdict = FormSpamGuard::inspect($rawValues, $honeypotField, !$tier2Verified, $honeypotEnabled);

// Any signal being a hit makes the submission spam. Precedence: captcha,
// then PoW/Tier2 (most specific - e.g. REASON_TIER2_REQUIRED_BUT_MISSING
// already implies the timing heuristic below would also have fired, so
// reporting the PoW-specific reason is strictly more informative), then
// honeypot/timing. A PoW verdict therefore overrides an already-set timing
// verdict, not just an empty one - see the reassignment below.
if ($captchaSpamOverride['is_spam'] && !$verdict['is_spam']) {
    $verdict = $captchaSpamOverride;
}
if ($powSpamOverride['is_spam'] && (!$verdict['is_spam'] || $verdict['reason'] === FormSpamGuard::REASON_TOO_FAST)) {
    $verdict = $powSpamOverride;
}

$values = FormSpamGuard::stripGuardFields($rawValues, $honeypotField);

// ── File uploads (AFTER the captcha gate) ───────────────────────────────────
// Files can only arrive via multipart, so this is the only branch that can
// see them. They are validated and written to disk BEFORE the submission
// row, because the envelope lists them - and rolled back completely if
// anything later in the request fails. Reaching this point already proves
// the request passed the captcha gate (or captcha is off for this form), so
// a bot can no longer cause a file write before proving it isn't a bot.
if (!$isJsonRequest && FormFileValidator::hasFiles($_FILES)) {
    try {
        $storedAttachments = FormAttachmentService::intake($form, $_FILES);
    } catch (FormFileException $e) {
        // The exception carries the right status: 415 when the form does not
        // accept uploads, 413 for size/quota, 400 for a rejected type, 503
        // when an encrypted form has no key.
        formsFail(
            $wantsJson,
            $e->getStatusCode(),
            $e->getErrorCode(),
            $e->getMessage(),
            $e->getErrors(),
            $e->getStatusCode() === 413 || $e->getStatusCode() === 400 ? $redirectUrl : null,
            $formName
        );
    }
}

// ── Validation ──────────────────────────────────────────────────────────────
$strictSchema = (bool) ($form['data']['settings']['strict_schema'] ?? false);

try {
    if ($verdict['is_spam']) {
        // Spam is stored for review, so it must not be rejected by validation
        // (a bot rarely fills required fields correctly). Values are still
        // sanitized and capped - they just skip the schema rules.
        $cleanValues = [];
        foreach ($values as $key => $value) {
            $normalizedKey = FormValidator::normalizeFieldName($key);
            if ($normalizedKey === null) {
                continue;
            }
            $cleanValues[$normalizedKey] = is_array($value)
                ? FormValidator::sanitizeText(implode(', ', array_map('strval', array_filter($value, 'is_scalar'))), FormsSchema::MAX_VALUE_LENGTH)
                : FormValidator::sanitizeText($value, FormsSchema::MAX_VALUE_LENGTH);
        }
        $values = $cleanValues;
    } else {
        $values = FormValidator::validateValues($values, FormService::fields($form), $strictSchema);
    }
} catch (FormValidationException $e) {
    FormAttachmentService::rollback($storedAttachments);
    formsFail($wantsJson, 400, 'VALIDATION_FAILED', $e->getMessage(), $e->getErrors(), $redirectUrl, $formName);
}

// ── Required file fields ────────────────────────────────────────────────────
// Checked after the attachments are stored, because that is when we know which
// fields actually received a file. Spam submissions skip it for the same reason
// they skip schema validation: a bot rarely fills anything correctly, and we
// still want the row for review.
if (!$verdict['is_spam']) {
    try {
        FormValidator::assertRequiredFilesPresent(FormService::fields($form), $storedAttachments);
    } catch (FormValidationException $e) {
        FormAttachmentService::rollback($storedAttachments);
        formsFail($wantsJson, 400, 'VALIDATION_FAILED', $e->getMessage(), $e->getErrors(), $redirectUrl, $formName);
    }
}

// ── Persist ─────────────────────────────────────────────────────────────────
try {
    $submission = FormSubmissionService::create($form, $values, [
        'status' => $verdict['is_spam'] ? FormsSchema::STATUS_SPAM : FormsSchema::STATUS_UNREAD,
        'ip' => $clientIp,
        'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? null,
        'origin' => $origin,
        'content_type' => $isJsonRequest ? 'json' : ($isMultipart ? 'multipart' : 'urlencoded'),
        'spam_reason' => $verdict['reason'],
        'attachments' => FormAttachmentService::envelopeSummary($storedAttachments),
    ]);
} catch (FormCryptoException $e) {
    // Fail-closed: the form demands encryption but the server cannot provide it.
    // Storing the submission in the clear here would be the one outcome we must
    // never allow.
    FormAttachmentService::rollback($storedAttachments);

    error_log('[Forms] Encrypted submission refused for form "' . $slug . '": ' . $e->getMessage());
    formsFail(
        $wantsJson,
        503,
        'ENCRYPTION_UNAVAILABLE',
        'Az űrlap jelenleg nem tud beküldést fogadni (titkosítási hiba). Kérlek próbáld később.',
        [],
        null,
        $formName
    );
} catch (Throwable $e) {
    // Files were written before the submission; without this the request would
    // leave personal data on disk that no screen can reach.
    FormAttachmentService::rollback($storedAttachments);

    error_log('[Forms] Submission failed for form "' . $slug . '": ' . $e->getMessage());
    formsFail($wantsJson, 500, 'SUBMISSION_FAILED', 'A beküldés mentése nem sikerült.', [], null, $formName);
}

// Adopt the files now that the submission exists.
if (!empty($storedAttachments)) {
    FormAttachmentService::attach($storedAttachments, (int) $submission['id']);
}
// ── Notifications (never block the response on these) ───────────────────────
if (!$verdict['is_spam']) {
    FormNotifier::sendEmail($form, (int) $submission['id'], $values);
    FormNotifier::dispatchWebhook($form, $submission, $values);
}

// ── Respond ─────────────────────────────────────────────────────────────────
// A honeypot hit gets the SAME successful-looking response as a real submission,
// so a bot learns nothing about which field betrayed it.
if ($wantsJson) {
    formsJson(200, [
        'success' => true,
        'id' => $submission['id'],
        'message' => 'Köszönjük a beküldést!',
        // Count only: the visitor already knows what they sent, and echoing
        // filenames back would reflect their own input into the response.
        'attachments' => count($storedAttachments),
    ]);
}

if ($redirectUrl !== null) {
    formsRedirect($redirectUrl, ['nomad_form' => 'ok']);
}

formsHtmlPage(200, $formName, 'Köszönjük a beküldést!', ['Az üzenetedet megkaptuk.'], false);
