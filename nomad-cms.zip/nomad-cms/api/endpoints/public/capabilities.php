<?php

/**
 * NOMAD CMS - Public Client Capability Flags
 *
 *   GET /api/endpoints/public/capabilities.php
 *
 * Tells an unauthenticated frontend (the login screen, chiefly) which optional
 * UI affordances it may show, without revealing WHY. This endpoint answers with
 * plain feature flags - never subsystem names, provider details, or configuration
 * state. In particular it must never mention "mail", "smtp", or the mail
 * subsystem's internal states (unverified/disabled/no_default): the shape here
 * is deliberately generic so scanning for this file, or reading its response,
 * does not tell an attacker anything about what backs a given flag today or
 * what might back it tomorrow.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * CURRENT FLAGS
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *   password_recovery_available
 *     Whether the self-service "forgot password" flow (auth/ar-request.php)
 *     can actually deliver a link right now. Backed today by
 *     MailProfileStore::isSendable() (a verified, non-disabled default SMTP
 *     profile) - but the frontend must treat it as an opaque capability, not
 *     as "SMTP is configured".
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * WHY THIS IS SAFE TO EXPOSE WITHOUT AUTH
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * A boolean UI affordance flag is not a secret: the same information is
 * trivially inferable by anyone who actually attempts the recovery flow and
 * observes whether a link arrives. This endpoint only saves them the round
 * trip - it grants no capability of its own and touches no user data.
 *
 * @package NomadCMS
 */

declare(strict_types=1);

require_once __DIR__ . '/../../bootstrap.php';

use NomadCMS\Services\Mail\MailProfileStore;

handlePreflight();
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate');

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'GET') {
    header('Allow: GET');
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Method not allowed']);
    exit;
}

try {
    echo json_encode([
        'success' => true,
        'password_recovery_available' => MailProfileStore::isSendable(),
    ], JSON_UNESCAPED_UNICODE);
} catch (Throwable $e) {
    error_log('[capabilities] ' . $e->getMessage());

    // Fail closed: an error here must hide the affordance, not crash the
    // login screen or leak a stack trace.
    http_response_code(200);
    echo json_encode([
        'success' => true,
        'password_recovery_available' => false,
    ]);
}
