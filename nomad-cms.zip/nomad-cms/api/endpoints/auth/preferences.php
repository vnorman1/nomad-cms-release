<?php
/**
 * NOMAD CMS - User Preferences Endpoint
 * 
 * GET  - Get current user preferences
 * PUT  - Update user preferences
 */

declare(strict_types=1);

require_once __DIR__ . '/../../bootstrap.php';

use NomadCMS\Auth\AuthHttp;
use NomadCMS\Auth\AuthException;
use NomadCMS\Auth\AuthSessionService;
use NomadCMS\Auth\AuthTransaction;
use NomadCMS\Database\AuthDatabase;
use NomadCMS\Middleware\AuthMiddleware;
use NomadCMS\Middleware\CSRFMiddleware;

header('Content-Type: application/json');
// Per-user data that changes via this same endpoint - must never be served
// from an intermediary/browser cache, or a stale GET after a fresh PUT can
// clobber the just-saved preference (e.g. theme flips back to default when
// re-visiting the Preferences tab, since a stale cached response overwrites
// the freshly-saved value in memory until the tab unmounts again).
header('Cache-Control: no-store, no-cache, must-revalidate');
header('Pragma: no-cache');

$method = $_SERVER['REQUEST_METHOD'];

// Handle CORS preflight
if ($method === 'OPTIONS') {
    http_response_code(204);
    exit;
}

/**
 * Validate an HSL triple: h in [0,360], s/l in [0,100], all numeric.
 * Returns a normalized array (floats) or null if invalid.
 */
function validateHslTriple(mixed $value): ?array
{
    if (!is_array($value)) {
        return null;
    }

    foreach (['h', 's', 'l'] as $field) {
        if (!array_key_exists($field, $value) || !is_numeric($value[$field])) {
            return null;
        }
    }

    $h = (float) $value['h'];
    $s = (float) $value['s'];
    $l = (float) $value['l'];

    if ($h < 0 || $h > 360 || $s < 0 || $s > 100 || $l < 0 || $l > 100) {
        return null;
    }

    return ['h' => $h, 's' => $s, 'l' => $l];
}

/**
 * Validate a full color profile payload: { light: HslTriple, dark: HslTriple }.
 *
 * SECURITY: this is written verbatim into the client's inline
 * document.documentElement style on next load (see colorProfiles.ts /
 * applyColorProfile). Rejecting anything malformed here (rather than
 * clamping or coercing) keeps the stored preference guaranteed-safe to
 * re-apply without further validation on read.
 *
 * Returns a normalized array, or null if the payload is invalid.
 */
function validateColorProfilePayload(mixed $value): ?array
{
    if (!is_array($value) || !isset($value['light'], $value['dark'])) {
        return null;
    }

    $light = validateHslTriple($value['light']);
    $dark = validateHslTriple($value['dark']);

    if ($light === null || $dark === null) {
        return null;
    }

    return ['light' => $light, 'dark' => $dark];
}

try {
    // Authenticate user
    $user = AuthMiddleware::requireInteractiveAuth();
    
    $db = AuthDatabase::getInstance();
    
    switch ($method) {
        case 'GET':
            // Get preferences
            $stmt = $db->prepare("SELECT preferences FROM users WHERE uuid = ?");
            $stmt->execute([$user->uuid]);
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            
            $preferences = $row['preferences'] ? json_decode($row['preferences'], true) : [];
            
            echo json_encode([
                'success' => true,
                'preferences' => $preferences,
            ]);
            break;
            
        case 'PUT':
            // SECURITY: Validate CSRF token for session-based requests
            CSRFMiddleware::validateForSession();
            
            // Update preferences
            $input = AuthHttp::body();
            
            // Get current preferences
            $stmt = $db->prepare("SELECT preferences FROM users WHERE uuid = ?");
            $stmt->execute([$user->uuid]);
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            
            $current = $row['preferences'] ? json_decode($row['preferences'], true) : [];
            
            // Merge with new values (only allow specific keys)
            $allowedKeys = ['theme', 'language', 'sidebar_collapsed', 'compact_mode', 'notification_level', 'notification_badge_muted', 'color_profile'];
            
            foreach ($allowedKeys as $key) {
                if (array_key_exists($key, $input)) {
                    $value = $input[$key];
                    
                    // Validate theme value
                    if ($key === 'theme') {
                        if ($value === 'system' || $value === null) {
                            // Remove from preferences (use system default)
                            unset($current['theme']);
                        } elseif (in_array($value, ['light', 'dark'])) {
                            $current['theme'] = $value;
                        }
                    }
                    // Validate language
                    elseif ($key === 'language') {
                        if ($value === null) {
                            unset($current['language']);
                        } elseif (in_array($value, ['hu', 'en'])) {
                            $current['language'] = $value;
                        }
                    }
                    // Boolean values
                    elseif (in_array($key, ['sidebar_collapsed', 'compact_mode', 'notification_badge_muted'])) {
                        if ($value === null || $value === false) {
                            unset($current[$key]);
                        } else {
                            $current[$key] = (bool) $value;
                        }
                    }
                    // Notification level
                    elseif ($key === 'notification_level') {
                        if ($value === null || $value === 'all') {
                            // 'all' is the default, no need to store
                            unset($current['notification_level']);
                        } elseif (in_array($value, ['all', 'normal', 'critical', 'none'])) {
                            $current['notification_level'] = $value;
                        }
                    }
                    // Color profile: { light: {h,s,l}, dark: {h,s,l} }.
                    // Fail-closed - anything that doesn't pass validation is
                    // silently dropped rather than partially stored, since a
                    // malformed profile would be written straight into
                    // document.documentElement's inline style on load.
                    elseif ($key === 'color_profile') {
                        if ($value === null) {
                            unset($current['color_profile']);
                        } else {
                            $validated = validateColorProfilePayload($value);
                            if ($validated !== null) {
                                $current['color_profile'] = $validated;
                            }
                        }
                    }
                }
            }
            
            // Store as JSON (empty object becomes null)
            $jsonValue = empty($current) ? null : json_encode($current);
            
            $stmt = $db->prepare("UPDATE users SET preferences = ?, updated_at = datetime('now') WHERE uuid = ?");
            $stmt->execute([$jsonValue, $user->uuid]);
            
            echo json_encode([
                'success' => true,
                'message' => 'Preferences updated',
                'preferences' => $current,
            ]);
            break;
            
        default:
            http_response_code(405);
            echo json_encode(['success' => false, 'error' => 'Method not allowed']);
    }
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'Server error: ' . $e->getMessage(),
    ]);
}
