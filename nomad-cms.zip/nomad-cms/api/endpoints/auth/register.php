<?php
/**
 * NOMAD CMS - Register Endpoint
 * Handles new user registration
 */

declare(strict_types=1);

require_once __DIR__ . '/../../bootstrap.php';

use NomadCMS\Auth\AuthHttp;
use NomadCMS\Auth\AuthException;
use NomadCMS\Auth\AuthSessionService;
use NomadCMS\Auth\AuthTransaction;
use NomadCMS\Auth\JWTService;
use NomadCMS\Auth\PasswordPolicy;
use NomadCMS\Config\Security;
use NomadCMS\Database\AuthDatabase;
use NomadCMS\Database\UserRepository;
use NomadCMS\Middleware\RateLimitMiddleware;

// CORS
handlePreflight();

// Check if registration is enabled
if (!Security::isFeatureEnabled('registration')) {
    http_response_code(403);
    header('Content-Type: application/json');
    echo json_encode([
        'success' => false,
        'error' => 'Registration is currently disabled',
        'code' => 'REGISTRATION_DISABLED',
    ]);
    exit;
}

// Rate limit (uses dynamic settings)
RateLimitMiddleware::checkRegistration();

// Only accept POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Method not allowed']);
    exit;
}

// Get JSON body
$body = AuthHttp::body();

if (!$body) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Invalid JSON body']);
    exit;
}

$email = trim(AuthHttp::string($body, 'email', 254));
$password = AuthHttp::string($body, 'password');
$confirmPassword = AuthHttp::string($body, 'confirm_password');

// Validate input
$errors = [];

if (empty($email)) {
    $errors[] = 'Email is required';
} elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $errors[] = 'Invalid email format';
}

if (empty($password)) {
    $errors[] = 'Password is required';
} else {
    // SECURITY: use the single shared strong-password policy (min. 12 chars +
    // upper/lower/digit/special) instead of a weaker inline rule, so public
    // self-registration cannot create accounts with weaker passwords than
    // the installer/onboarding flows require.
    $errors = array_merge($errors, PasswordPolicy::validate($password));
}

if ($password !== $confirmPassword) {
    $errors[] = 'Passwords do not match';
}

if (!empty($errors)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'errors' => $errors]);
    exit;
}

try {
    AuthHttp::checkOrigin();
    // Initialize database
    $db = AuthDatabase::getInstance();
    
    // SECURITY FIX: Use transaction to prevent race condition attacks
    // This ensures atomic check-and-create operation
    $db->beginTransaction();
    
    try {
        // Check if email exists (inside transaction with EXCLUSIVE lock)
        $existing = UserRepository::findByEmail($email);
        if ($existing) {
            $db->rollBack();
            // SECURITY FIX: Generic error message to prevent user enumeration
            // Don't reveal whether email exists - attackers could use this
            // to harvest valid email addresses for phishing or credential stuffing
            http_response_code(400);
            echo json_encode([
                'success' => false, 
                'error' => 'Registration failed. Please try again or contact support.',
                // Log the real reason for debugging (not exposed to user)
            ]);
            error_log('[SECURITY] Registration attempt for existing email: ' . hash('sha256', $email));
            exit;
        }
        
        // Create user (first user is admin)
        $userCount = $db->query("SELECT COUNT(*) FROM users")->fetchColumn();
        $isAdmin = $userCount === 0;
        
        $user = UserRepository::create($email, $password, $isAdmin);
        
        if (!$user) {
            $db->rollBack();
            throw new \Exception('Failed to create user');
        }
        
        // Generate and store one scope-bound, revocable session.
        $issued = AuthSessionService::issue($user, 'password', true);
        $accessToken = $issued['access_token'];
        $refreshTokenData = $issued['refresh'];

        $db->commit();
        
    } catch (\PDOException $e) {
        $db->rollBack();
        
        // Handle unique constraint violation (race condition fallback)
        if (strpos($e->getMessage(), 'UNIQUE constraint failed') !== false ||
            strpos($e->getMessage(), 'users.email') !== false) {
            http_response_code(400);
            echo json_encode([
                'success' => false, 
                'error' => 'Registration failed. Please try again or contact support.',
            ]);
            error_log('[SECURITY] Race condition in registration for email hash: ' . hash('sha256', $email));
            exit;
        }
        
        throw $e;
    }
    
    // Log registration
    UserRepository::logLoginAttempt($email, true, 'registration');
    
    // SECURITY: Start session and regenerate ID to prevent session fixation attacks
    session_start();
    $_SESSION = [];
    session_regenerate_id(true);
    
    http_response_code(201);
    header('Content-Type: application/json');
    
    // SECURITY: Refresh token ONLY in httpOnly cookie - NEVER in response body
    $refreshTokenTTL = (int) ($_ENV['JWT_REFRESH_TOKEN_TTL'] ?? 604800);
    setSecureRefreshCookie('nomad_refresh_token', $refreshTokenData['plain_token'], $refreshTokenTTL);
    
    echo json_encode([
        'success' => true,
        'message' => 'Registration successful' . ($isAdmin ? ' (Admin account created)' : ''),
        'access_token' => $accessToken,
        'token_type' => 'Bearer',
        'expires_in' => (int) ($_ENV['JWT_ACCESS_TOKEN_TTL'] ?? 900),
        'user' => [
            'uuid' => $user['uuid'],
            'email' => $user['email'],
            'is_admin' => (bool) $user['is_admin'],
        ],
    ]);
    
} catch (AuthException $e) {
    AuthHttp::respond($e);
} catch (\Throwable $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => $_ENV['APP_DEBUG'] === 'true' ? $e->getMessage() : 'Internal server error',
    ]);
}
