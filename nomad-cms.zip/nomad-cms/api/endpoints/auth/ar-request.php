<?php

/**
 * NOMAD CMS - Self-Service Account Recovery Request
 *
 *   POST /api/endpoints/auth/ar-request.php
 *   Body: { "email": "user@example.com" }
 *
 * Public, unauthenticated entry point for the "forgot password" flow on the
 * login screen. On success it issues a SHORT-LIVED (15 minute, fixed - see
 * MagicLinkService::SELF_SERVICE_RESET_TTL) magic link and e-mails it through
 * the verified default SMTP profile, reusing the same /welcome redemption flow
 * as an admin-issued invitation (the frontend also serves it at
 * /reset-password - same component, same token format, same endpoint).
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * WHY THE RESPONSE NEVER VARIES
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * This endpoint answers with the SAME generic 200 in every case: unknown
 * e-mail, locked account, no sendable mail profile, or a genuine send failure.
 * Branching the HTTP response on any of those would let a caller enumerate
 * registered e-mail addresses or probe account lockout state from a page that
 * requires no authentication at all. The only caller-visible signal is the
 * message text, which is deliberately noncommittal ("if that address exists,
 * a link is on its way").
 *
 * Real failures (mail send errors, missing profile, DB errors) are logged
 * server-side for the admin to diagnose - never surfaced to the requester.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * WHY THE FILENAME IS "ar-request"
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * Deliberately not named forgot-password.php / reset-password.php: this file
 * is reachable by anyone on the internet, and "account recovery request"
 * abbreviated avoids handing automated endpoint scanners (which frequently
 * carry wordlists of exactly those common names) an easy hit. The rate limiter
 * and generic response are the real defences; the name is only friction.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * SECURITY CONTROLS
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *   - RateLimitMiddleware::checkPasswordReset() - IP-scoped, strict (default
 *     3 requests/hour, see AUTH_RATE_LIMIT_PASSWORD_RESET*)
 *   - Fixed 15-minute link lifetime, not caller- or env-configurable
 *   - Issuing a link revokes any other outstanding invitation for that user
 *     (admin-issued or self-service) - MagicLinkService's existing invariant
 *   - Locked accounts are silently skipped (no link is issued, no mail sent),
 *     without changing the response
 *   - Gated on MailProfileStore::isSendable() - if the system cannot actually
 *     deliver mail right now, nothing is issued or attempted
 *
 * @package NomadCMS
 */

declare(strict_types=1);

require_once __DIR__ . '/../../bootstrap.php';

use NomadCMS\Auth\MagicLinkService;
use NomadCMS\Database\UserRepository;
use NomadCMS\Middleware\RateLimitMiddleware;
use NomadCMS\Security\InputSanitizer;
use NomadCMS\Services\Mail\MailProfileStore;
use NomadCMS\Services\Mail\MailService;
use NomadCMS\Services\Mail\MailTemplates;

handlePreflight();
header('Content-Type: application/json; charset=utf-8');

/** The one response shape this endpoint ever returns on a well-formed request. */
function arGenericSuccess(): never
{
    http_response_code(200);
    echo json_encode([
        'success' => true,
        'message' => 'Ha ehhez az e-mail címhez tartozik fiók, hamarosan kapsz egy hivatkozást a jelszó beállításához.',
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

/**
 * Absolute origin of the admin/frontend SPA, for building the reset link.
 *
 * Mirrors MailUrlResolver::adminBaseUrl(): prefers ADMIN_URL, falls back to
 * SITE_URL only when it is not the API's own origin. Duplicated rather than
 * imported because MailUrlResolver's public surface is about the MAIL admin
 * verification flow specifically; this endpoint has no business reaching into
 * that class's internals for an unrelated URL.
 */
function arFrontendOrigin(): ?string
{
    return \NomadCMS\Services\Mail\MailUrlResolver::adminBaseUrl();
}

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
    header('Allow: POST');
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Method not allowed']);
    exit;
}

// Strict, IP-scoped bucket - independent of the login and magic-link buckets,
// so this flow cannot be used to lock legitimate logins out and vice versa.
RateLimitMiddleware::checkPasswordReset();

$body = json_decode(file_get_contents('php://input'), true);
$email = is_array($body) ? InputSanitizer::email($body['email'] ?? null) : null;

if (!$email) {
    // Even a malformed request gets the generic answer: format validation
    // failures are the one thing that is safe to reject explicitly (it reveals
    // nothing about any account), but keeping it uniform removes any need for
    // the frontend to special-case this endpoint's error shape.
    arGenericSuccess();
}

try {
    if (!MailProfileStore::isSendable()) {
        // System cannot deliver mail at all right now. Nothing to attempt.
        arGenericSuccess();
    }

    $user = UserRepository::findByEmail($email);

    if (!$user || UserRepository::isLocked($user)) {
        arGenericSuccess();
    }

    $link = MagicLinkService::createSelfServiceReset((int) $user['id']);

    $origin = arFrontendOrigin();
    if ($origin === null) {
        error_log('[ar-request] No usable ADMIN_URL/SITE_URL configured - cannot build reset link.');
        arGenericSuccess();
    }

    $resetUrl = $origin . '/reset-password#t=' . rawurlencode($link['token']);
    $ttlMinutes = (int) (MagicLinkService::SELF_SERVICE_RESET_TTL / 60);

    $userName = trim(($user['first_name'] ?? '') . ' ' . ($user['last_name'] ?? ''));
    $template = MailTemplates::passwordReset($resetUrl, $userName !== '' ? $userName : null, $ttlMinutes);

    try {
        MailService::send($user['email'], $template['subject'], $template['text'], $template['html']);
    } catch (\Throwable $e) {
        // Delivery failure must not surface to the caller - see the class
        // docblock. The link was already issued; the admin can diagnose via
        // the mail diagnostics on the profile itself.
        error_log('[ar-request] Mail send failed for user #' . $user['id'] . ': ' . $e->getMessage());
    }

    arGenericSuccess();
} catch (\Throwable $e) {
    error_log('[ar-request] ' . $e->getMessage());
    // Still the generic success shape - an internal error here must not leak
    // as a distinguishable response either.
    arGenericSuccess();
}
