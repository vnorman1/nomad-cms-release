<?php
/**
 * NOMAD CMS - Magic Link Redemption Endpoint
 *
 * Public endpoint that turns a one-time onboarding link into an
 * ONBOARDING-SCOPED session. Called by the /welcome page.
 *
 * POST { "token": "<selector>.<verifier>" }
 *
 * ─────────────────────────────────────────────────────────────────────────────
 * SECURITY MODEL
 * ─────────────────────────────────────────────────────────────────────────────
 * - Strictly rate limited (own bucket, see RateLimitMiddleware::checkMagicLink)
 * - Every failure mode returns the SAME generic 401 so the endpoint cannot be
 *   used to enumerate valid selectors, users or link states
 * - The issued access token carries `onboarding: true`, which AuthMiddleware
 *   rejects everywhere except the endpoints that explicitly opt in. Redeeming a
 *   link therefore grants exactly enough access to finish onboarding - it can
 *   NOT read or write content, manage users, or touch any other API surface.
 * - Redemption flips the user into is_new_user = 1. For a link generated for an
 *   EXISTING user this is the moment their old password stops being enough:
 *   from here on they must set a new one. (Generating the link did not touch
 *   their account at all - see admin/user-invitations.php.)
 * - The invitation is NOT consumed here, only stamped with first_used_at. It is
 *   consumed when onboarding actually completes, so a user who abandons the
 *   flow can re-open the same link until it expires.
 */

declare(strict_types=1);

require_once __DIR__ . '/../../bootstrap.php';

use NomadCMS\Auth\AuthHttp;
use NomadCMS\Auth\AuthException;
use NomadCMS\Auth\AuthSessionService;
use NomadCMS\Auth\AuthTransaction;
use NomadCMS\Auth\JWTService;
use NomadCMS\Auth\MagicLinkService;
use NomadCMS\Database\AuthDatabase;
use NomadCMS\Database\RoleRepository;
use NomadCMS\Database\UserRepository;
use NomadCMS\Middleware\CSRFMiddleware;
use NomadCMS\Middleware\RateLimitMiddleware;

// CORS
handlePreflight();

// Dedicated, strict rate limit for link redemption
RateLimitMiddleware::checkMagicLink();

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Method not allowed']);
    exit;
}

/**
 * Uniform rejection. Deliberately identical for "unknown token", "expired",
 * "revoked", "already used" and "malformed" so nothing can be inferred.
 */
function rejectToken(): never
{
    http_response_code(401);
    echo json_encode([
        'success' => false,
        'error' => 'A megadott hivatkozás érvénytelen vagy lejárt. Kérj újat az adminisztrátortól.',
        'code' => 'INVALID_MAGIC_LINK',
    ]);
    exit;
}

$body = AuthHttp::body();
$token = is_array($body) ? ($body['token'] ?? null) : null;

if (!is_string($token) || $token === '') {
    rejectToken();
}

try {
    AuthHttp::checkOrigin();
    $db = AuthDatabase::getInstance();

    $invitation = MagicLinkService::findActiveByToken($token);

    if ($invitation === null) {
        UserRepository::logLoginAttempt('magic-link', false, 'invalid_magic_link');
        rejectToken();
    }

    $user = UserRepository::findById((int) $invitation['user_id']);

    if (!$user) {
        // Orphaned invitation (user deleted) - treat exactly like an invalid token
        rejectToken();
    }

    // A locked/suspended account must not be revivable through an invitation.
    if (UserRepository::isLocked($user)) {
        UserRepository::logLoginAttempt($user['email'], false, 'magic_link_account_locked');

        $remainingSeconds = UserRepository::getLockoutRemaining($user);
        $remainingMinutes = (int) ceil($remainingSeconds / 60);

        http_response_code(423);
        echo json_encode([
            'success' => false,
            'error' => "A fiók ideiglenesen zárolva. Próbáld újra {$remainingMinutes} perc múlva.",
            'code' => 'ACCOUNT_LOCKED',
            'lockout_remaining' => $remainingSeconds,
            'lockout_remaining_minutes' => $remainingMinutes,
        ]);
        exit;
    }

    $issued = AuthTransaction::run(function () use ($token, $user): array {
        $invitation = MagicLinkService::findActiveByToken($token);
        if ($invitation === null) {
            throw new AuthException('INVALID_MAGIC_LINK', 'Invitation expired or revoked.');
        }
        $current = UserRepository::findById((int) $user['id']);
        AuthSessionService::assertUser($current);
        // Audit: first redemption timestamp (does NOT consume the invitation).
        MagicLinkService::markFirstUse((int) $invitation['id']);
        // The account must finish onboarding before any normal API access.
        AuthSessionService::revokeUser((int) $user['id']);
        AuthDatabase::getInstance()->prepare("UPDATE users SET is_new_user=1,updated_at=datetime('now') WHERE id=?")
            ->execute([(int) $user['id']]);
        return AuthSessionService::issue($current, 'magic', true, (int) $invitation['id']);
    });
    $user = UserRepository::findById((int) $user['id']);
    $accessToken = $issued['access_token'];
    $refreshTokenData = $issued['refresh'];
    $clientIp = \NomadCMS\Security\ClientIpResolver::resolve();

    // A refresh cookie is issued so a page reload mid-onboarding does not kill
    // the flow. It confers no extra power: AuthMiddleware re-reads is_new_user
    // from the database on every request, so refreshed tokens stay gated until
    // onboarding is actually completed.
    $refreshTokenTTL = (int) ($_ENV['JWT_REFRESH_TOKEN_TTL'] ?? 604800);
    setSecureRefreshCookie('nomad_refresh_token', $refreshTokenData['plain_token'], $refreshTokenTTL);

    // SECURITY: fresh session id + CSRF token, same as a normal login
    session_start();
    $_SESSION = [];
    session_regenerate_id(true);
    CSRFMiddleware::regenerate();

    UserRepository::logLoginAttempt($user['email'], true, 'magic_link_used');

    $roleInfo = null;
    try {
        $roleInfo = RoleRepository::getUserRole($user);
    } catch (\Exception $e) {
        error_log('[magic-login] Role resolution failed: ' . $e->getMessage());
    }

    http_response_code(200);
    echo json_encode([
        'success' => true,
        'message' => 'Magic link accepted',
        'access_token' => $accessToken,
        'token_type' => 'Bearer',
        'expires_in' => (int) ($_ENV['JWT_ACCESS_TOKEN_TTL'] ?? 900),
        // Tells the frontend this session may ONLY finish onboarding
        'onboarding' => true,
        'mfa_methods' => AuthSessionService::recoveryMethods($user),
        'purpose' => $invitation['purpose'],
        'user' => [
            'uuid' => $user['uuid'],
            'email' => $user['email'],
            'first_name' => $user['first_name'] ?? null,
            'last_name' => $user['last_name'] ?? null,
            'is_admin' => (bool) $user['is_admin'],
            'totp_enabled' => (bool) $user['totp_enabled'],
            'is_new_user' => true,
            'has_password' => !empty($user['password_hash']),
            'role_slug' => $roleInfo['slug'] ?? null,
            'role_name' => $roleInfo['name'] ?? null,
        ],
    ]);

} catch (AuthException $e) {
    AuthHttp::respond($e);
} catch (\Throwable $e) {
    error_log('[magic-login] ' . $e->getMessage());
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => ($_ENV['APP_DEBUG'] ?? 'false') === 'true' ? $e->getMessage() : 'Internal server error',
    ]);
}
