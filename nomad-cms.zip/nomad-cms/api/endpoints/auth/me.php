<?php
/**
 * NOMAD CMS - Current User Endpoint
 * Get current authenticated user info
 */

declare(strict_types=1);

require_once __DIR__ . '/../../bootstrap.php';

use NomadCMS\Auth\WebAuthnService;
use NomadCMS\Database\AuthDatabase;
use NomadCMS\Database\UserRepository;
use NomadCMS\Database\RoleRepository;
use NomadCMS\Middleware\AuthMiddleware;

// CORS
handlePreflight();

// Only accept GET
if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Method not allowed']);
    exit;
}

try {
    $currentUser = AuthMiddleware::requireInteractiveAuth(true);
    
    AuthDatabase::getInstance();
    $user = UserRepository::findByUuid($currentUser->uuid);
    
    if (!$user) {
        http_response_code(404);
        echo json_encode(['success' => false, 'error' => 'User not found']);
        exit;
    }
    
    // Get passkey count
    $passkeys = WebAuthnService::getUserCredentials($user['id']);
    
    // Extended RBAC: resolve full role info (full permission list - not embedded in JWT)
    $roleInfo = null;
    try {
        $roleInfo = RoleRepository::getUserRole($user);
    } catch (\Exception $e) {
        error_log('[auth/me] Role resolution failed: ' . $e->getMessage());
    }
    
    http_response_code(200);
    header('Content-Type: application/json');
    echo json_encode([
        'success' => true,
        'mfa_methods' => !empty($currentUser->onboarding) ? \NomadCMS\Auth\AuthSessionService::recoveryMethods($user) : [],
        'user' => [
            'uuid' => $user['uuid'],
            'email' => $user['email'],
            'first_name' => $user['first_name'] ?? null,
            'last_name' => $user['last_name'] ?? null,
            'is_admin' => (bool) $user['is_admin'],
            'panic_recovery' => !empty($currentUser->panic_recovery),
            'is_new_user' => (bool) ($user['is_new_user'] ?? false),
            'email_verified' => (bool) $user['email_verified'],
            'totp_enabled' => (bool) $user['totp_enabled'],
            'passkey_count' => count($passkeys),
            'has_password' => !empty($user['password_hash']),
            'created_at' => $user['created_at'],
            'last_login_at' => $user['last_login_at'],
            'role_slug' => $roleInfo['slug'] ?? null,
            'role_name' => $roleInfo['name'] ?? null,
            'slot_access' => $roleInfo['slot_access'] ?? [],
            'permissions' => $roleInfo['permissions'] ?? [],
        ],
        'passkeys' => array_map(fn($p) => [
            'id' => $p['id'],
            'friendly_name' => $p['friendly_name'],
            'created_at' => $p['created_at'],
            'last_used_at' => $p['last_used_at'],
        ], $passkeys),
    ]);
    
} catch (\Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => $_ENV['APP_DEBUG'] === 'true' ? $e->getMessage() : 'Internal server error',
    ]);
}
