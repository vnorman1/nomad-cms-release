<?php
/**
 * NOMAD CMS - User Settings Endpoint
 * Update email, password, and auth method preferences
 */

declare(strict_types=1);

require_once __DIR__ . '/../../bootstrap.php';

use NomadCMS\Auth\AuthHttp;
use NomadCMS\Auth\AuthException;
use NomadCMS\Auth\AuthSessionService;
use NomadCMS\Auth\AuthTransaction;
use NomadCMS\Auth\TOTPService;
use NomadCMS\Database\UserRepository;
use NomadCMS\Middleware\AuthMiddleware;
use NomadCMS\Middleware\CSRFMiddleware;
use NomadCMS\Middleware\RateLimitMiddleware;

// CORS
handlePreflight();

// Rate limit
RateLimitMiddleware::check();

// Require authentication
session_start();
$currentUser = AuthMiddleware::requireInteractiveAuth(true);

$method = $_SERVER['REQUEST_METHOD'];

// Set JSON content type
header('Content-Type: application/json');

try {
    AuthHttp::checkOrigin();
    $user = UserRepository::findByUuid($currentUser->uuid);
    
    if (!$user) {
        http_response_code(404);
        echo json_encode(['success' => false, 'error' => 'User not found']);
        exit;
    }
    
    switch ($method) {
        case 'GET':
            // Get current user settings
            http_response_code(200);
            echo json_encode([
                'success' => true,
                'settings' => [
                    'email' => $user['email'],
                    'first_name' => $user['first_name'] ?? null,
                    'last_name' => $user['last_name'] ?? null,
                    'totp_enabled' => (bool) $user['totp_enabled'],
                    'totp_allowed' => (bool) ($user['totp_allowed'] ?? true),
                    'webauthn_allowed' => (bool) ($user['webauthn_allowed'] ?? true),
                    'password_allowed' => (bool) ($user['password_allowed'] ?? true),
                    'has_password' => !empty($user['password_hash']),
                    'recovery_email' => $user['recovery_email'] ?? null,
                ],
            ]);
            break;
            
        case 'PATCH':
        case 'PUT':
            // SECURITY: Validate CSRF token for session-based requests
            CSRFMiddleware::validateForSession();
            
            $body = AuthHttp::body();
            
            if ((!empty($currentUser->onboarding) || !empty($user['is_new_user']))
                && array_diff(array_keys($body), ['first_name', 'last_name', '_csrf_token']) !== []) {
                throw new AuthException('ONBOARDING_ENDPOINT_REQUIRED', 'Finish onboarding before changing security settings.', 403);
            }
            foreach (['email', 'new_password', 'current_password', 'confirm_password', 'totp_code', 'recovery_email'] as $field) {
                if (isset($body[$field])) {
                    AuthHttp::string($body, $field);
                }
            }
            foreach (['totp_allowed', 'webauthn_allowed', 'password_allowed'] as $field) {
                if (isset($body[$field]) && !is_bool($body[$field])) {
                    throw new AuthException('INVALID_INPUT', 'Authentication settings must be booleans.', 400);
                }
            }
            // Check if TOTP is required for sensitive changes
            $sensitiveChange = isset($body['email']) || isset($body['new_password']) || isset($body['recovery_email']) || isset($body['totp_allowed']) || isset($body['webauthn_allowed']) || isset($body['password_allowed']);
            
            if ($sensitiveChange && $user['totp_enabled']) {
                $totpCode = $body['totp_code'] ?? '';
                if (empty($totpCode)) {
                    http_response_code(400);
                    echo json_encode([
                        'success' => false,
                        'error' => 'TOTP code required for this operation',
                        'requires_totp' => true,
                    ]);
                    exit;
                }
                
                // User verification consumes the step and applies account/IP limits.
                
                if (!TOTPService::verifyUserCode((int) $user['id'], $totpCode)) {
                    http_response_code(401);
                    echo json_encode(['success' => false, 'error' => 'Invalid TOTP code']);
                    exit;
                }
            }
            
            $updated = [];
            $response = [];
            
            // Update email
            if (isset($body['email']) && $body['email'] !== $user['email']) {
                $newEmail = filter_var($body['email'], FILTER_VALIDATE_EMAIL);
                if (!$newEmail) {
                    http_response_code(400);
                    echo json_encode(['success' => false, 'error' => 'Invalid email format']);
                    exit;
                }
                
                // Check if email already taken
                if (UserRepository::findByEmail($newEmail)) {
                    http_response_code(409);
                    echo json_encode(['success' => false, 'error' => 'Email already in use']);
                    exit;
                }
                
                UserRepository::updateEmail($user['id'], $newEmail);
                $updated[] = 'email';
            }
            
            // Update password
            if (isset($body['new_password']) && !empty($body['new_password'])) {
                $currentPassword = $body['current_password'] ?? '';
                $newPassword = $body['new_password'];
                $confirmPassword = $body['confirm_password'] ?? '';
                
                // Verify current password (if user has one AND is not a new user)
                if (!empty($user['password_hash']) && empty($user['is_new_user'])) {
                    if (empty($currentPassword)) {
                        http_response_code(400);
                        echo json_encode(['success' => false, 'error' => 'Current password is required']);
                        exit;
                    }
                    
                    if (!UserRepository::verifyPassword($user, $currentPassword)) {
                        http_response_code(401);
                        echo json_encode(['success' => false, 'error' => 'Current password is incorrect']);
                        exit;
                    }
                }
                
                // Validate new password
                if (\NomadCMS\Auth\PasswordPolicy::validate($newPassword) !== []) {
                    http_response_code(400);
                    echo json_encode(['success' => false, 'error' => 'Password does not meet the password policy.']);
                    exit;
                }
                
                if ($newPassword !== $confirmPassword) {
                    http_response_code(400);
                    echo json_encode(['success' => false, 'error' => 'Passwords do not match']);
                    exit;
                }
                
                // Update password
                // Password changes invalidate every previous JWT and refresh token.
                $issued = AuthTransaction::run(function () use ($user, $newPassword): array {
                    UserRepository::updatePassword((int) $user['id'], $newPassword);
                    return AuthSessionService::issue(UserRepository::findById((int) $user['id']), 'password');
                });
                setSecureRefreshCookie('nomad_refresh_token', $issued['refresh']['plain_token'], (int) ($_ENV['JWT_REFRESH_TOKEN_TTL'] ?? 604800));
                $updated[] = 'password';

                // Regenerate token to reflect is_new_user = false
                $user['is_new_user'] = 0; // Update local user array
                $newToken = $issued['access_token'];
                $response['access_token'] = $newToken;
                $response['token_update'] = true;
            }
            
            // Update names. Deliberately NOT treated as a "sensitive change":
            // changing your own display name cannot be used to take over an
            // account, so requiring a TOTP code for it would only add friction.
            // Sending an empty string clears the name (mapped to NULL).
            $nameUpdates = [];
            foreach (['first_name', 'last_name'] as $nameField) {
                if (!isset($body[$nameField]) || !is_string($body[$nameField])) {
                    continue;
                }

                if (trim($body[$nameField]) === '') {
                    $nameUpdates[$nameField] = '';
                    continue;
                }

                $clean = \NomadCMS\Security\InputSanitizer::personName($body[$nameField]);
                if ($clean === null) {
                    http_response_code(400);
                    echo json_encode(['success' => false, 'error' => 'Érvénytelen név formátum.']);
                    exit;
                }
                $nameUpdates[$nameField] = $clean;
            }

            if (!empty($nameUpdates)) {
                UserRepository::update((int) $user['id'], $nameUpdates);
                $updated[] = 'name';
            }
            
            // Update auth method toggles
            $authSettings = [];
            if (isset($body['totp_allowed'])) {
                $authSettings['totp_allowed'] = (bool) $body['totp_allowed'];
            }
            if (isset($body['webauthn_allowed'])) {
                $authSettings['webauthn_allowed'] = (bool) $body['webauthn_allowed'];
            }
            if (isset($body['password_allowed'])) {
                $authSettings['password_allowed'] = (bool) $body['password_allowed'];
            }
            
            if (!empty($authSettings)) {
                UserRepository::updateAuthSettings($user['id'], $authSettings);
                $updated[] = 'auth_settings';
            }
            
            // Update recovery email
            if (isset($body['recovery_email'])) {
                $recoveryEmail = $body['recovery_email'] ? filter_var($body['recovery_email'], FILTER_VALIDATE_EMAIL) : null;
                UserRepository::setRecoveryEmail($user['id'], $recoveryEmail ?: null);
                $updated[] = 'recovery_email';
            }
            
            http_response_code(200);
            echo json_encode(array_merge([
                'success' => true,
                'message' => 'Settings updated',
                'updated_fields' => $updated,
            ], $response));
            break;
            
        default:
            http_response_code(405);
            echo json_encode(['success' => false, 'error' => 'Method not allowed']);
    }
    
} catch (AuthException $e) {
    AuthHttp::respond($e);
} catch (\Throwable $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => $_ENV['APP_DEBUG'] === 'true' ? $e->getMessage() : 'Internal server error',
    ]);
}
