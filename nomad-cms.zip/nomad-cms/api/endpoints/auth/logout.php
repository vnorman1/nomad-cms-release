<?php
/**
 * NOMAD CMS - Logout Endpoint
 * Revokes refresh tokens and clears session
 */

declare(strict_types=1);

require_once __DIR__ . '/../../bootstrap.php';

use NomadCMS\Auth\AuthHttp;
use NomadCMS\Auth\AuthException;
use NomadCMS\Auth\AuthSessionService;
use NomadCMS\Auth\AuthTransaction;
use NomadCMS\Database\AuthDatabase;
use NomadCMS\Middleware\AuthMiddleware;

// CORS
handlePreflight();

// Only accept POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Method not allowed']);
    exit;
}

session_start();

try {
    $db = AuthDatabase::getInstance();
    
    AuthHttp::checkOrigin();
    $body = AuthHttp::body();
    // $allowOnboarding = true: finishing onboarding is never a prerequisite
    // for ending the user's own session. API keys cannot perform logout-all.
    $user = AuthMiddleware::optionalAuth(true);
    if ($user && ($user->source ?? '') !== 'api_key' && ($body['logout_all'] ?? false) === true) {
        AuthSessionService::revokeUser((int) $user->id);
    } else {
        AuthTransaction::run(function () use ($body, $user, $db): void {
            if ($user && ($user->source ?? '') !== 'api_key' && !empty($user->session_id)) {
                AuthSessionService::revokeSession($user->session_id);
            }
            // Cookie is authoritative; compatibility body values cannot shadow it.
            $refreshToken = $_COOKIE['nomad_refresh_token'] ?? AuthHttp::string($body, 'refresh_token', 128);
            if (is_string($refreshToken) && preg_match('/^[a-f0-9]{128}$/D', $refreshToken)) {
                $stmt = $db->prepare('SELECT auth_session_id,family FROM refresh_tokens WHERE token_hash=?');
                $stmt->execute([hash('sha256', $refreshToken)]);
                $tokenData = $stmt->fetch();
                if ($tokenData && !empty($tokenData['auth_session_id'])) {
                    AuthSessionService::revokeSession($tokenData['auth_session_id']);
                }
            }
        });
    }

    // Clear session
    $_SESSION = [];
    
    if (session_id()) {
        session_destroy();
    }
    
    // Clear CSRF cookie
    setcookie('XSRF-TOKEN', '', [
        'expires' => time() - 3600,
        'path' => '/',
        'samesite' => 'Lax',
    ]);
    
    // Clear refresh token cookie
    setSecureRefreshCookie('nomad_refresh_token', '', 0, true);
    
    http_response_code(200);
    header('Content-Type: application/json');
    echo json_encode([
        'success' => true,
        'message' => 'Logged out successfully',
    ]);
    
} catch (AuthException $e) {
    AuthHttp::respond($e);
} catch (\Throwable $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => $_ENV['APP_DEBUG'] === 'true' ? $e->getMessage() : 'Internal server error',
    ]);
}
