<?php
/**
 * NOMAD CMS - TOTP Setup Endpoint
 * Enable/disable two-factor authentication
 */

declare(strict_types=1);

require_once __DIR__ . '/../../bootstrap.php';

use NomadCMS\Auth\AuthHttp;
use NomadCMS\Auth\AuthException;
use NomadCMS\Auth\AuthSessionService;
use NomadCMS\Auth\AuthTransaction;
use NomadCMS\Auth\TOTPService;
use NomadCMS\Config\Security;
use NomadCMS\Database\AuthDatabase;
use NomadCMS\Database\UserRepository;
use NomadCMS\Middleware\AuthMiddleware;
use NomadCMS\Middleware\CSRFMiddleware;
use NomadCMS\Middleware\RateLimitMiddleware;

// CORS
handlePreflight();

// Check if TOTP is enabled globally
if (!Security::isFeatureEnabled('totp')) {
    http_response_code(403);
    header('Content-Type: application/json');
    echo json_encode([
        'success' => false,
        'error' => 'TOTP/2FA is disabled on this server',
        'code' => 'TOTP_DISABLED',
    ]);
    exit;
}

// Rate limit
RateLimitMiddleware::check();

// Require authentication
session_start();
$currentUser = AuthMiddleware::requireInteractiveAuth();

$method = $_SERVER['REQUEST_METHOD'];

// Set JSON content type for all responses
header('Content-Type: application/json');

try {
    AuthHttp::checkOrigin();
    $db = AuthDatabase::getInstance();
    $user = UserRepository::findByUuid($currentUser->uuid);
    
    if (!$user) {
        http_response_code(404);
        echo json_encode(['success' => false, 'error' => 'User not found']);
        exit;
    }
    
    if (!UserRepository::canUseTotp($user)) {
        throw new AuthException('TOTP_DISABLED', 'TOTP is disabled for this account.', 403);
    }
    header('Cache-Control: no-store');

    switch ($method) {
        case 'GET':
            // Get TOTP status and generate new secret if not enabled
            if ($user['totp_enabled']) {
                http_response_code(200);
                echo json_encode([
                    'success' => true,
                    'totp_enabled' => true,
                    'message' => 'TOTP is already enabled',
                ]);
            } else {
                // Generate new secret (server-side QR image skipped - frontend renders via client-side SVG for instant speed)
                $totpData = TOTPService::generateSecret($user['email'], false);
                
                // Store temporarily in session until verified
                $_SESSION['pending_totp_secret'] = [
                    'secret' => $totpData['secret'], 'algorithm' => $totpData['algorithm'],
                    'user_id' => (int) $user['id'], 'session_id' => $currentUser->session_id,
                    'expires_at' => time() + 600,
                ];
                
                // Immediately release exclusive session lock to prevent blocking concurrent requests
                session_write_close();
                
                http_response_code(200);
                echo json_encode([
                    'success' => true,
                    'totp_enabled' => false,
                    'provisioning_uri' => $totpData['provisioning_uri'],
                    'qr_code' => $totpData['qr_code_data_uri'], // null - client renders SVG from provisioning_uri
                    'secret' => $totpData['secret'], // For manual entry
                    'message' => 'Scan QR code with authenticator app, then POST verification code',
                ]);
            }
            break;
            
        case 'POST':
            // SECURITY: Validate CSRF token for session-based requests
            CSRFMiddleware::validateForSession();
            
            // Enable TOTP - verify code first
            $body = AuthHttp::body();
            $code = AuthHttp::string($body, 'code', 10);
            
            if (empty($code)) {
                http_response_code(400);
                echo json_encode(['success' => false, 'error' => 'Verification code is required']);
                exit;
            }
            
            if ($user['totp_enabled']) {
                http_response_code(400);
                echo json_encode(['success' => false, 'error' => 'TOTP is already enabled']);
                exit;
            }
            
             $pending = $_SESSION['pending_totp_secret'] ?? null;
            $pendingSecret = is_array($pending) ? ($pending['secret'] ?? null) : null;
            
            if (!$pendingSecret || $pending['user_id'] !== (int) $user['id']
                || $pending['session_id'] !== $currentUser->session_id || $pending['expires_at'] <= time()) {
                unset($_SESSION['pending_totp_secret']);
                http_response_code(400);
                echo json_encode([
                    'success' => false,
                    'error' => 'No pending TOTP setup. GET this endpoint first to generate a secret.',
                ]);
                exit;
            }
            
            // Verify code
            RateLimitMiddleware::checkTOTP((int) $user['id']);
            
            $step = TOTPService::matchingStep($pendingSecret, $code, 1, $pending['algorithm']);
            if ($step === null) {
                http_response_code(401);
                echo json_encode(['success' => false, 'error' => 'Invalid verification code']);
                exit;
            }
            
            // Enable TOTP and publish backup hashes in the same atomic write.
            $backupCodes = TOTPService::generateBackupCodes();
            AuthTransaction::run(function () use ($user, $pendingSecret, $pending, $step, $backupCodes): void {
                $current = UserRepository::findById((int) $user['id']);
                if (!empty($current['totp_enabled'])) {
                    throw new AuthException('TOTP_ALREADY_ENABLED', 'TOTP is already enabled.', 409);
                }
                UserRepository::enableTotp((int) $user['id'], $pendingSecret, $pending['algorithm'], $step);
                // Store ONLY the hashes in database - NEVER store plain text!
                UserRepository::setBackupCodes((int) $user['id'], $backupCodes['hashes']);
            });
            unset($_SESSION['pending_totp_secret']);

            http_response_code(200);
            echo json_encode([
                'success' => true,
                'message' => 'TOTP enabled successfully',
                'backup_codes' => $backupCodes['codes'], // Plain codes for user to save
                'warning' => 'Save these backup codes securely. They will not be shown again.',
            ]);
            break;
        
        case 'PATCH':
            // SECURITY: Validate CSRF token for session-based requests
            CSRFMiddleware::validateForSession();
            
            // Regenerate backup codes - require current TOTP code
            $body = AuthHttp::body();
            $code = AuthHttp::string($body, 'code', 10);
            
            if (!$user['totp_enabled']) {
                http_response_code(400);
                echo json_encode(['success' => false, 'error' => 'TOTP is not enabled']);
                exit;
            }
            
            if (empty($code)) {
                http_response_code(400);
                echo json_encode(['success' => false, 'error' => 'Current TOTP code is required']);
                exit;
            }
            
            // verifyUserCode consumes the step and checks both rate limits.
            
            // Get decrypted secret for verification
            $totpSecret = UserRepository::getTotpSecret($user);
            if (!$totpSecret || !TOTPService::verifyUserCode((int) $user['id'], $code)) {
                http_response_code(401);
                echo json_encode(['success' => false, 'error' => 'Invalid TOTP code']);
                exit;
            }
            
            // Generate new backup codes
            $newBackupCodes = TOTPService::generateBackupCodes();
            
            // Store ONLY the hashes
            UserRepository::setBackupCodes($user['id'], $newBackupCodes['hashes']);
            
            http_response_code(200);
            echo json_encode([
                'success' => true,
                'message' => 'Backup codes regenerated successfully',
                'backup_codes' => $newBackupCodes['codes'],
                'warning' => 'Save these backup codes securely. Old codes are now invalid.',
            ]);
            break;
            
        case 'DELETE':
            // SECURITY: Validate CSRF token for session-based requests
            CSRFMiddleware::validateForSession();
            
            // Disable TOTP - require current TOTP code
            $body = AuthHttp::body();
            $code = AuthHttp::string($body, 'code', 10);
            
            if (!$user['totp_enabled']) {
                http_response_code(400);
                echo json_encode(['success' => false, 'error' => 'TOTP is not enabled']);
                exit;
            }
            
            if (empty($code)) {
                http_response_code(400);
                echo json_encode(['success' => false, 'error' => 'Current TOTP code is required to disable']);
                exit;
            }
            
            // verifyUserCode consumes the step and checks both rate limits.
            
            // Get decrypted secret for verification
            $totpSecret = UserRepository::getTotpSecret($user);
            if (!$totpSecret || !TOTPService::verifyUserCode((int) $user['id'], $code)) {
                http_response_code(401);
                echo json_encode(['success' => false, 'error' => 'Invalid TOTP code']);
                exit;
            }
            
            UserRepository::disableTotp($user['id']);
            
            http_response_code(200);
            echo json_encode([
                'success' => true,
                'message' => 'TOTP disabled successfully',
            ]);
            break;
            
        default:
            http_response_code(405);
            echo json_encode(['success' => false, 'error' => 'Method not allowed']);
    }
    
} catch (AuthException $e) {
    AuthHttp::respond($e);
} catch (\Throwable $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => $_ENV['APP_DEBUG'] === 'true' ? $e->getMessage() : 'Internal server error',
    ]);
}
