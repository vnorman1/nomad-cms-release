<?php
/**
 * NOMAD CMS - Token Refresh Endpoint
 * Handles access token renewal using refresh token
 */

declare(strict_types=1);

require_once __DIR__ . '/../../bootstrap.php';

use NomadCMS\Auth\AuthHttp;
use NomadCMS\Auth\AuthException;
use NomadCMS\Auth\AuthSessionService;
use NomadCMS\Auth\AuthTransaction;
use NomadCMS\Auth\JWTService;
use NomadCMS\Database\AuthDatabase;
use NomadCMS\Database\UserRepository;
use NomadCMS\Middleware\RateLimitMiddleware;

// CORS
handlePreflight();

// Never cache auth token refresh responses
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');

// Rate limit
RateLimitMiddleware::check(
    key: 'refresh:' . \NomadCMS\Security\ClientIpResolver::resolve(),
    maxRequests: 30,
    windowSeconds: 60
);

// Only accept POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Method not allowed']);
    exit;
}

// Get JSON body
$body = AuthHttp::body();

// HttpOnly cookie is authoritative. The body remains a compatibility fallback
// for non-browser clients; a body value cannot shadow a valid browser cookie.
$refreshToken = $_COOKIE['nomad_refresh_token'] ?? AuthHttp::string($body, 'refresh_token', 128);
if (!is_string($refreshToken) || !preg_match('/^[a-f0-9]{128}$/D', $refreshToken)) {
    AuthHttp::respond(new AuthException('INVALID_REFRESH_TOKEN', 'Refresh token is required.', 400));
}

try {
    AuthHttp::checkOrigin();
    $issued = AuthSessionService::rotate($refreshToken);
    $accessToken = $issued['access_token'];
    $newRefreshToken = $issued['refresh'];

    http_response_code(200);
    header('Content-Type: application/json');
    
    // SECURITY: Refresh token ONLY in httpOnly cookie - NEVER in response body
    $refreshTokenTTL = (int) ($_ENV['JWT_REFRESH_TOKEN_TTL'] ?? 604800);
    setSecureRefreshCookie('nomad_refresh_token', $newRefreshToken['plain_token'], $refreshTokenTTL);
    
    echo json_encode([
        'success' => true,
        'message' => 'Token refreshed',
        'access_token' => $accessToken,
        'token_type' => 'Bearer',
        'expires_in' => (int) ($_ENV['JWT_ACCESS_TOKEN_TTL'] ?? 900),
    ]);

    // Garbage Collection (Probabilistic: 2% chance)
    // Run after sending response if possible, or just accept the tiny delay
    if (rand(1, 50) === 1) {
        try {
            AuthDatabase::cleanupTokens();
            AuthDatabase::cleanupSessions();
        } catch (\Throwable $cleanupError) {
            error_log('[Auth] Token cleanup failed: ' . $cleanupError->getMessage());
        }
    }
    
} catch (AuthException $e) {
    AuthHttp::respond($e);
} catch (\Throwable $e) {
    if (isset($db) && $db instanceof \PDO && $db->inTransaction()) {
        $db->rollBack();
    }
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => $_ENV['APP_DEBUG'] === 'true' ? $e->getMessage() : 'Internal server error',
    ]);
}
