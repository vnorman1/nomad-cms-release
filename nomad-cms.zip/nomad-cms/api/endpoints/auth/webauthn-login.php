<?php
/**
 * NOMAD CMS - WebAuthn Login Endpoint
 * Passkey authentication flow
 */

declare(strict_types=1);

require_once __DIR__ . '/../../bootstrap.php';

use NomadCMS\Auth\AuthHttp;
use NomadCMS\Auth\AuthException;
use NomadCMS\Auth\AuthSessionService;
use NomadCMS\Auth\AuthTransaction;
use NomadCMS\Auth\JWTService;
use NomadCMS\Auth\WebAuthnService;
use NomadCMS\Database\AuthDatabase;
use NomadCMS\Database\UserRepository;
use NomadCMS\Middleware\RateLimitMiddleware;
use NomadCMS\Middleware\CSRFMiddleware;

// CORS
handlePreflight();

// Rate limit for auth
RateLimitMiddleware::checkAuth();

session_start();

$method = $_SERVER['REQUEST_METHOD'];

try {
    AuthHttp::checkOrigin();
    AuthDatabase::getInstance();
    $body = $method === 'POST' ? AuthHttp::body() : [];
    $purpose = $method === 'GET' ? ($_GET['purpose'] ?? 'login') : AuthHttp::string($body, 'purpose', 20, 'login');
    if (!is_string($purpose) || !in_array($purpose, ['login', 'onboarding'], true)) {
        throw new AuthException('INVALID_WEBAUTHN_PURPOSE', 'Invalid credential operation.', 400);
    }
    if ($purpose !== 'login') {
        $currentUser = \NomadCMS\Middleware\AuthMiddleware::requireInteractiveAuth(true);
        $owner = UserRepository::findById((int) $currentUser->id);
        $authSession = AuthSessionService::currentSession($currentUser);
        if ($authSession['scope'] !== 'onboarding') {
            throw new AuthException('INVALID_SESSION_SCOPE', 'Onboarding session required.', 403);
        }
    }
    if (!\NomadCMS\Config\Security::isFeatureEnabled('webauthn')) {
        throw new AuthException('WEBAUTHN_DISABLED', 'Passkey authentication is disabled.', 403);
    }

    switch ($method) {
        case 'GET':
            // Get authentication options (assertion)
            $email = $purpose === 'onboarding' ? $owner['email'] : ($_GET['email'] ?? null);
            if ($email !== null && (!is_string($email) || strlen($email) > 254)) {
                throw new AuthException('INVALID_INPUT', 'Invalid email.', 400);
            }

            $options = WebAuthnService::getAuthenticationOptions($email, $purpose, $purpose === 'onboarding' ? (int) $owner['id'] : null, $purpose === 'onboarding' ? $currentUser->session_id : null);

            http_response_code(200);
            header('Content-Type: application/json');
            echo json_encode([
                'success' => true,
                'options' => $options['options'],
                'message' => 'Use these options with navigator.credentials.get()',
            ]);
            break;

        case 'POST':
            // Verify authentication and login
            $body = AuthHttp::body();

            $credentialId = AuthHttp::string($body, isset($body['rawId']) ? 'rawId' : 'id', 4096);
            $clientDataJSON = AuthHttp::string($body, 'clientDataJSON', 16384);
            $authenticatorData = AuthHttp::string($body, 'authenticatorData', 16384);
            $signature = AuthHttp::string($body, 'signature', 16384);
            $userHandle = isset($body['userHandle']) ? AuthHttp::string($body, 'userHandle', 1024) : null;

            if (empty($credentialId) || empty($clientDataJSON) || empty($authenticatorData) || empty($signature)) {
                http_response_code(400);
                echo json_encode([
                    'success' => false,
                    'error' => 'Missing required WebAuthn response fields',
                ]);
                exit;
            }

            // Verify and get user
            $user = WebAuthnService::verifyAuthentication(
                $credentialId,
                $clientDataJSON,
                $authenticatorData,
                $signature,
                $userHandle,
                $purpose,
                $purpose === 'onboarding' ? (int) $owner['id'] : null,
                $purpose === 'onboarding' ? $currentUser->session_id : null
            );

            if ($purpose === 'onboarding') {
                throw new AuthException('INVALID_WEBAUTHN_PURPOSE', 'Submit the assertion with onboarding completion.', 400);
            }
            // Extended RBAC: resolve full role info (full permission list is
            // deliberately NOT embedded in the JWT, so send it in the response)
            $roleInfo = null;
            try {
                $roleInfo = \NomadCMS\Database\RoleRepository::getUserRole($user);
            } catch (\Exception $e) {
                error_log('[webauthn-login] Role resolution failed: ' . $e->getMessage());
            }

            // Generate tokens
            $isRecovery = \NomadCMS\Security\PanicModeService::isActive();
            if ($isRecovery) {
                $accessToken = JWTService::generateAccessToken($user, false, true);
                $refreshTokenData = null;
            } else {
                $issued = AuthSessionService::issue($user, 'webauthn');
                $accessToken = $issued['access_token'];
                $refreshTokenData = $issued['refresh'];
            }

            // Log successful login
            UserRepository::logLoginAttempt($user['email'], true, 'webauthn');
            UserRepository::resetFailedLogins($user['id']);

            // SECURITY: Regenerate session ID to prevent session fixation attacks
            $_SESSION = [];
            session_regenerate_id(true);

            // Regenerate CSRF
            CSRFMiddleware::regenerate();

            // SECURITY: Set refresh token ONLY in httpOnly cookie (XSS-safe)
            // ZERO TRUST: Refresh token NEVER in response body
            $refreshTokenTTL = (int) ($_ENV['JWT_REFRESH_TOKEN_TTL'] ?? 604800);
            setSecureRefreshCookie('nomad_refresh_token', $refreshTokenData['plain_token'] ?? '', $refreshTokenTTL, $isRecovery);

            http_response_code(200);
            header('Content-Type: application/json');
            echo json_encode([
                'success' => true,
                'message' => 'Login successful via passkey',
                'access_token' => $accessToken,
                // ZERO TRUST: refresh_token NEVER in response body - cookie only!
                'token_type' => 'Bearer',
                'expires_in' => $isRecovery ? 300 : (int) ($_ENV['JWT_ACCESS_TOKEN_TTL'] ?? 900),
                'panic_recovery' => $isRecovery,
                'user' => [
                    'uuid' => $user['uuid'],
                    'email' => $user['email'],
                    'is_admin' => (bool) $user['is_admin'],
                    'panic_recovery' => $isRecovery,
                    // Extended RBAC: passkey logins must receive the same role +
                    // full permission list as password logins, otherwise the
                    // frontend sees an empty permission array and hides every
                    // permission-gated UI element for non-admin users.
                    'role_slug' => $roleInfo['slug'] ?? null,
                    'role_name' => $roleInfo['name'] ?? null,
                    'slot_access' => $roleInfo['slot_access'] ?? [],
                    'permissions' => $roleInfo['permissions'] ?? [],
                ],
            ]);
            break;

        default:
            http_response_code(405);
            echo json_encode(['success' => false, 'error' => 'Method not allowed']);
    }

 } catch (\NomadCMS\Security\PanicModeException $e) {
    \NomadCMS\Middleware\PanicModeMiddleware::respond($e);
} catch (AuthException $e) {
    AuthHttp::respond($e);
} catch (\Throwable $e) {
    // Log failed attempt if we can identify email
    if (isset($body['email'])) {
        UserRepository::logLoginAttempt($body['email'], false, 'webauthn_' . $e->getMessage());
    }

    http_response_code(401);
    echo json_encode([
        'success' => false,
        'error' => $_ENV['APP_DEBUG'] === 'true' ? $e->getMessage() : 'WebAuthn authentication failed',
    ]);
}
