<?php
/**
 * NOMAD CMS - Onboarding Completion Endpoint
 *
 * Finishes the mandatory onboarding step for a user who either
 *   (a) redeemed a magic link (onboarding-scoped session), or
 *   (b) was created with an admin-set password (is_new_user = 1).
 *
 * POST {
 *   "password": "...", "confirm_password": "...",
 *   "first_name": "...", "last_name": "..."   // optional corrections
 * }
 *
 * ─────────────────────────────────────────────────────────────────────────────
 * WHY A DEDICATED ENDPOINT (instead of reusing auth/settings.php)
 * ─────────────────────────────────────────────────────────────────────────────
 * Completing onboarding is more than "set a password": it must also consume the
 * invitation, evict every other session of that account, and hand back a token
 * WITHOUT the onboarding claim. Keeping that in one place means the security
 * steps cannot be forgotten by a caller.
 *
 * Password strength here follows the STRONG policy (PasswordPolicy: min. 12 +
 * complexity) - the same rules the installer applies to the first super admin.
 */

declare(strict_types=1);

require_once __DIR__ . '/../../bootstrap.php';

use NomadCMS\Auth\AuthHttp;
use NomadCMS\Auth\AuthException;
use NomadCMS\Auth\AuthSessionService;
use NomadCMS\Auth\AuthTransaction;
use NomadCMS\Auth\JWTService;
use NomadCMS\Auth\MagicLinkService;
use NomadCMS\Auth\PasswordPolicy;
use NomadCMS\Database\AuthDatabase;
use NomadCMS\Database\RoleRepository;
use NomadCMS\Database\UserRepository;
use NomadCMS\Middleware\AuthMiddleware;
use NomadCMS\Middleware\CSRFMiddleware;
use NomadCMS\Middleware\RateLimitMiddleware;
use NomadCMS\Security\InputSanitizer;
use NomadCMS\Security\WebhookService;

// CORS
handlePreflight();

RateLimitMiddleware::check();

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Method not allowed']);
    exit;
}

session_start();

// true = this endpoint is one of the few that may run during onboarding
$currentUser = AuthMiddleware::requireInteractiveAuth(true);

// SECURITY: CSRF for cookie/session based callers (Bearer requests are exempt)
CSRFMiddleware::validateForSession();

try {
    $db = AuthDatabase::getInstance();
    $user = UserRepository::findByUuid($currentUser->uuid);

    if (!$user) {
        http_response_code(404);
        echo json_encode(['success' => false, 'error' => 'User not found']);
        exit;
    }

    // Only accounts that are actually mid-onboarding may use this endpoint.
    // An already-onboarded user must go through auth/settings.php, which
    // requires their current password.
    if (empty($user['is_new_user'])) {
        http_response_code(409);
        echo json_encode([
            'success' => false,
            'error' => 'Az onboarding már befejeződött.',
            'code' => 'ONBOARDING_ALREADY_COMPLETE',
        ]);
        exit;
    }

    $body = AuthHttp::body();

    $password = AuthHttp::string($body, 'password');
    $confirmPassword = AuthHttp::string($body, 'confirm_password');

    if (!is_string($password) || $password === '') {
        http_response_code(400);
        echo json_encode(['success' => false, 'error' => 'A jelszó megadása kötelező.']);
        exit;
    }

    if (!is_string($confirmPassword) || !hash_equals($password, $confirmPassword)) {
        http_response_code(400);
        echo json_encode(['success' => false, 'error' => 'A két jelszó nem egyezik.']);
        exit;
    }

    $violations = PasswordPolicy::validateLocalized($password);
    if ($violations !== []) {
        http_response_code(400);
        echo json_encode([
            'success' => false,
            'error' => implode(', ', $violations),
            'errors' => $violations,
        ]);
        exit;
    }

    // Optional name corrections. The admin already supplied names at creation
    // time; the user may fix spelling here. Empty/absent values keep the
    // existing ones rather than wiping them.
    $nameUpdates = [];
    $firstName = InputSanitizer::personName($body['first_name'] ?? null);
    $lastName = InputSanitizer::personName($body['last_name'] ?? null);

    if ($firstName !== null && $firstName !== ($user['first_name'] ?? null)) {
        $nameUpdates['first_name'] = $firstName;
    }
    if ($lastName !== null && $lastName !== ($user['last_name'] ?? null)) {
        $nameUpdates['last_name'] = $lastName;
    }

    AuthHttp::checkOrigin();
    $issued = AuthTransaction::run(function () use ($user, $currentUser, $body, $password, $nameUpdates): array {
        $current = UserRepository::findById((int) $user['id']);
        AuthSessionService::assertUser($current);
        $authSession = AuthSessionService::currentSession($currentUser);
        if (empty($current['is_new_user']) || $authSession['scope'] !== 'onboarding') {
            throw new AuthException('ONBOARDING_ALREADY_COMPLETE', 'Onboarding already completed.', 409);
        }
        $completedMethod = $authSession['auth_method'] === 'webauthn' ? 'webauthn' : 'password';
        if ($authSession['auth_method'] === 'magic') {
            $methods = AuthSessionService::recoveryMethods($current);
            $hasPasskeys = AuthDatabase::getInstance()->prepare('SELECT 1 FROM webauthn_credentials WHERE user_id=? LIMIT 1');
            $hasPasskeys->execute([$current['id']]);
            $requiresMfa = !empty($current['totp_enabled']) || $hasPasskeys->fetchColumn();
            if ($requiresMfa) {
                $verified = false;
                if (isset($body['webauthn']) && is_array($body['webauthn']) && in_array('webauthn', $methods, true)) {
                    $proof = $body['webauthn'];
                    $verifiedUser = \NomadCMS\Auth\WebAuthnService::verifyAuthentication(
                        AuthHttp::string($proof, 'rawId', 4096),
                        AuthHttp::string($proof, 'clientDataJSON', 16384),
                        AuthHttp::string($proof, 'authenticatorData', 16384),
                        AuthHttp::string($proof, 'signature', 16384),
                        isset($proof['userHandle']) ? AuthHttp::string($proof, 'userHandle', 1024) : null,
                        'onboarding', (int) $current['id'], $currentUser->session_id
                    );
                    $verified = $verifiedUser['id'] === $current['id'];
                    $completedMethod = 'webauthn';
                } elseif (in_array('totp', $methods, true)) {
                    $verified = \NomadCMS\Auth\TOTPService::verifyUserCode(
                        (int) $current['id'], AuthHttp::string($body, 'totp_code', 10), true
                    );
                }
                if (!$verified) {
                    throw new AuthException('MFA_REQUIRED', 'Verify your existing authenticator or passkey to finish recovery.', 403);
                }
            }
        }
        if ($nameUpdates !== []) {
            UserRepository::update((int) $user['id'], $nameUpdates);
        }
        if ($completedMethod === 'password' && !UserRepository::canUsePassword($current)) {
            $completedMethod = 'magic';
        }
        $count = AuthDatabase::getInstance()->prepare('SELECT COUNT(*) FROM auth_sessions WHERE user_id=? AND revoked_at IS NULL');
        $count->execute([$user['id']]);
        $revoked = (int) $count->fetchColumn();
        // Sets the password and revokes every previous access/refresh session.
        UserRepository::updatePassword((int) $user['id'], $password);
        // Consume all outstanding invitations atomically with the credential reset.
        AuthDatabase::getInstance()->prepare("UPDATE user_invitations SET consumed_at=datetime('now') WHERE user_id=? AND consumed_at IS NULL")
            ->execute([(int) $user['id']]);
        return AuthSessionService::issue(UserRepository::findById((int) $user['id']), $completedMethod) + ['revoked_sessions' => $revoked];
    });
    $user = UserRepository::findById((int) $user['id']);
    $accessToken = $issued['access_token'];
    $revokedSessions = $issued['revoked_sessions'];
    setSecureRefreshCookie('nomad_refresh_token', $issued['refresh']['plain_token'], (int) ($_ENV['JWT_REFRESH_TOKEN_TTL'] ?? 604800));

    // SECURITY: new session id + CSRF token after a credential change
    $_SESSION = [];
    session_regenerate_id(true);
    CSRFMiddleware::regenerate();

    UserRepository::logLoginAttempt($user['email'], true, 'onboarding_completed');

    error_log(sprintf(
        '[Onboarding] completed for user #%d (%s); %d other session(s) revoked',
        (int) $user['id'],
        $user['email'],
        $revokedSessions
    ));

    try {
        $webhookService = new WebhookService();
        $webhookService->dispatchEventAsync('user.onboarded', [
            'user_id' => $user['uuid'],
            'email' => $user['email'],
            'first_name' => $user['first_name'] ?? null,
            'last_name' => $user['last_name'] ?? null,
            'timestamp' => date('c'),
        ]);
    } catch (\Exception $e) {
        error_log('Webhook dispatch failed for user.onboarded: ' . $e->getMessage());
    }

    $roleInfo = null;
    try {
        $roleInfo = RoleRepository::getUserRole($user);
    } catch (\Exception $e) {
        error_log('[onboarding] Role resolution failed: ' . $e->getMessage());
    }

    http_response_code(200);
    echo json_encode([
        'success' => true,
        'message' => 'Onboarding completed',
        'access_token' => $accessToken,
        'token_type' => 'Bearer',
        'expires_in' => (int) ($_ENV['JWT_ACCESS_TOKEN_TTL'] ?? 900),
        'revoked_sessions' => $revokedSessions,
        'user' => [
            'uuid' => $user['uuid'],
            'email' => $user['email'],
            'first_name' => $user['first_name'] ?? null,
            'last_name' => $user['last_name'] ?? null,
            'is_admin' => (bool) $user['is_admin'],
            'is_new_user' => false,
            'totp_enabled' => (bool) $user['totp_enabled'],
            'role_slug' => $roleInfo['slug'] ?? null,
            'role_name' => $roleInfo['name'] ?? null,
            'slot_access' => $roleInfo['slot_access'] ?? [],
            'permissions' => $roleInfo['permissions'] ?? [],
        ],
    ]);

} catch (AuthException $e) {
    AuthHttp::respond($e);
} catch (\Throwable $e) {
    error_log('[onboarding] ' . $e->getMessage());
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => ($_ENV['APP_DEBUG'] ?? 'false') === 'true' ? $e->getMessage() : 'Internal server error',
    ]);
}
