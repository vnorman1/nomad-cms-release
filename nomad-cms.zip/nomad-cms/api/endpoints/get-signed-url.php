<?php
/**
 * NOMAD CMS - Get Signed URL for Secure File Download
 * Generates a time-limited signed URL for secure file access
 */

declare(strict_types=1);

require_once __DIR__ . '/../bootstrap.php';
require_once __DIR__ . '/../lib/file.php';

use NomadCMS\Middleware\AuthMiddleware;

// Handle CORS preflight
handlePreflight();

header('Content-Type: application/json');

try {
    // 1. Ensure only GET/POST requests
    if (!in_array($_SERVER['REQUEST_METHOD'], ['GET', 'POST'])) {
        http_response_code(405);
        throw new Exception('Method not allowed');
    }

    // 2. Authenticate - user must be logged in AND have media read permission
    // to get a signed URL for secure file access.
    //
    // ABAC: media:read:* grants signed URLs for any file, media:read:own only
    // for files this user uploaded. Grant detection uses hasGrantedScope()
    // because media ownership lives in media_meta.uploaded_by rather than the
    // content-slot ownership table hasPermission() consults. Signed URLs are a
    // read capability, so they must respect exactly the same visibility rule
    // as media.php's GET - otherwise an own-scoped role that cannot even list
    // another user's file could still mint a working download URL for it.
    AuthMiddleware::requireAuth();
    AuthMiddleware::requireAnyGrantedScope(['media:read:*', 'media:read:own']);
    $readOwnOnly = !AuthMiddleware::hasGrantedScope('media:read:*');

    /** Fail-closed per-file ownership gate for own-scoped readers. */
    $assertMayReadFile = static function (string $file) use ($readOwnOnly): void {
        if (!$readOwnOnly) {
            return;
        }
        $meta = \NomadCMS\Database\ContentDatabase::getMediaMeta($file);
        $owner = $meta['uploaded_by'] ?? null;
        $currentUserUuid = AuthMiddleware::getCurrentUser()->uuid ?? null;
        if ($owner === null || $currentUserUuid === null || !hash_equals($owner, $currentUserUuid)) {
            http_response_code(403);
            echo json_encode(['success' => false, 'error' => 'Nincs jogosultságod ehhez a fájlhoz.', 'code' => 'FORBIDDEN_MEDIA_READ']);
            exit;
        }
    };

    // Parse input
    $input = [];
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $input = json_decode(file_get_contents('php://input'), true) ?: [];
    }
    
    $filename = $_GET['file'] ?? $input['file'] ?? '';
    $prettyUrl = $input['prettyUrl'] ?? '';

    // Handle pretty URL request
    if (!empty($prettyUrl)) {
        $mapping = resolveUrlMapping($prettyUrl);
        if (!$mapping) {
            http_response_code(404);
            throw new Exception('File not found');
        }
        
        $filename = $mapping['filename'];
        $assertMayReadFile($filename);
        $signedParams = generateSignedUrlParams($filename, 3600);
        
        echo json_encode([
            'success' => true,
            'signedPath' => $prettyUrl . '?' . $signedParams,
            'expiresIn' => 3600,
        ]);
        exit;
    }

    // Handle legacy filename request
    if (empty($filename)) {
        http_response_code(400);
        throw new Exception('No filename provided');
    }

    // Security: prevent path traversal
    if (strpos($filename, '..') !== false || strpos($filename, '/') !== false) {
        http_response_code(400);
        throw new Exception('Invalid filename');
    }

    $assertMayReadFile($filename);

    // Check file exists
    $fileInfo = getFileInfo('/api/files/secure/' . $filename);
    if (!$fileInfo) {
        http_response_code(404);
        throw new Exception('File not found');
    }

    // Generate signed URL (valid for 1 hour)
    $signedUrl = getSecureDownloadUrl($filename, 3600);

    echo json_encode([
        'success' => true,
        'url' => $signedUrl,
        'expiresIn' => 3600,
    ]);

} catch (Exception $e) {
    if (http_response_code() === 200) {
        http_response_code(400);
    }
    
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage(),
    ]);
}
