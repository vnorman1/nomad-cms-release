<?php
/**
 * NOMAD CMS - Installation Execute Endpoint
 * Execute installation (protected by rate limiting)
 * 
 * POST /api/endpoints/install/execute.php
 * 
 * Request:
 * { "email": "admin@example.com", "password": "SecurePassword123!" }
 * 
 * Success Response:
 * { "success": true, "message": "Installation complete", "redirect": "/login" }
 * 
 * Error Response:
 * { "success": false, "error": "Installation already completed" }
 */

declare(strict_types=1);

// Load bootstrap (env, security headers, allowlist-based CORS) and helpers
require_once __DIR__ . '/../../bootstrap.php';
require_once __DIR__ . '/../../lib/response.php';

use NomadCMS\Installer\InstallerService;
use NomadCMS\Middleware\InstallationMiddleware;

// Handle CORS preflight (allowlist-based, see bootstrap.php::handlePreflight)
handlePreflight();

// Only allow POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    sendError('Method not allowed', 405);
}

try {
    // Rate limit installation attempts (5 attempts per 5 minutes)
    InstallationMiddleware::rateLimit(5, 300);
    
    // Block if already installed
    InstallationMiddleware::requireNotInstalled();
    
    // Get request body
    $body = getJsonBody();
    
    if (!$body) {
        sendError('Invalid request body', 400);
    }
    
    // Validate required fields
    if (empty($body['email'])) {
        sendError('Email is required', 400);
    }
    
    if (empty($body['password'])) {
        sendError('Password is required', 400);
    }
    
    $email = trim($body['email']);
    $password = $body['password'];
    
    // Validate email format
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        sendError('Invalid email format', 400);
    }
    
    // Optional config overrides
    $config = [];

    if (!empty($body['app_url'])) {
        $config['app_url'] = $body['app_url'];
    }

    if (!empty($body['site_url']) && is_string($body['site_url']) && trim($body['site_url']) !== '') {
        $rawSiteUrl = trim($body['site_url']);
        if (!preg_match('~^https?://~i', $rawSiteUrl)) {
            $rawSiteUrl = 'https://' . $rawSiteUrl;
        }
        $normalizedSiteUrl = \NomadCMS\Services\Mail\MailUrlResolver::normalizeBase($rawSiteUrl);
        if ($normalizedSiteUrl === null) {
            sendError('Érvénytelen weboldal cím (Site URL)', 400);
        }
        $config['site_url'] = $normalizedSiteUrl;
    }

    // ADMIN_URL is MANDATORY: it is the only reliable way the backend can build
    // links back to the admin SPA (e.g. the form-submission notification e-mail,
    // see MailUrlResolver::adminBaseUrl()) on installs where the admin frontend
    // lives on its own domain/subdomain rather than the API's own origin.
    //
    // InstallPage resolves and sends this automatically (window.location.origin +
    // the Vite base path) - there is no manual field for it, on purpose: a typed
    // value is both an unnecessary step and a way to get this wrong, while the
    // browser already knows exactly where it is running. A missing/invalid value
    // here therefore indicates a frontend bug or a non-standard API caller, not
    // an operator mistake - but the request is still rejected rather than
    // silently defaulting, since a wrong ADMIN_URL would degrade every link this
    // install ever sends for its entire lifetime.
    if (empty($body['admin_url']) || !is_string($body['admin_url'])) {
        sendError('Admin URL is required', 400);
    }

    $adminUrl = \NomadCMS\Services\Mail\MailUrlResolver::normalizeBase($body['admin_url']);
    if ($adminUrl === null) {
        sendError('Admin URL must be an absolute http:// or https:// URL', 400);
    }

    $config['admin_url'] = $adminUrl;
    
    // Optional admin name. Not mandatory at install time - the operator may fill
    // it in later under Settings -> General - but if supplied it must be clean.
    foreach (['first_name', 'last_name'] as $nameField) {
        if (empty($body[$nameField]) || !is_string($body[$nameField])) {
            continue;
        }
        $clean = \NomadCMS\Security\InputSanitizer::personName($body[$nameField]);
        if ($clean !== null) {
            $config[$nameField] = $clean;
        }
    }
    
    // User entropy - already SHA-256 hashed client-side
    $userEntropy = null;
    if (!empty($body['user_entropy']) && is_string($body['user_entropy'])) {
        // Validate it looks like a hex hash (64 chars for SHA-256)
        if (preg_match('/^[a-f0-9]{64}$/i', $body['user_entropy'])) {
            $userEntropy = $body['user_entropy'];
        }
    }

    // Optional Analytics (0-PII) module install-time choice. Absent means
    // "use the module's own defaults" (enabled, keep aggregates forever) -
    // this step is not mandatory, an operator can also change it later from
    // the admin Settings panel without reinstalling.
    if (array_key_exists('analytics_enabled', $body)) {
        $config['analytics_enabled'] = (bool) $body['analytics_enabled'];
    }
    if (isset($body['analytics_retention_daily_days']) && is_numeric($body['analytics_retention_daily_days'])) {
        $config['analytics_retention_daily_days'] = (int) $body['analytics_retention_daily_days'];
    }

    // Optional Cloudflare proxy toggle (defaults to false)
    if (array_key_exists('cloudflare_proxy', $body)) {
        $config['cloudflare_proxy'] = (bool) $body['cloudflare_proxy'];
    }

    // Execute installation with optional user entropy
    $result = InstallerService::install($email, $password, $config, $userEntropy);
    
    // Log successful installation
    error_log('[Install] Installation completed successfully for: ' . $email);
    
    sendResponse($result);
    
} catch (\InvalidArgumentException $e) {
    // Validation errors (password strength, email format)
    sendError($e->getMessage(), 400);
    
} catch (\RuntimeException $e) {
    // Runtime errors (already installed, file write failures)
    error_log('[Install] Runtime error: ' . $e->getMessage());
    sendError($e->getMessage(), 409);
    
} catch (\Throwable $e) {
    // Unexpected errors
    error_log('[Install] Unexpected error: ' . $e->getMessage());
    sendError($e->getMessage(), 500);
}
