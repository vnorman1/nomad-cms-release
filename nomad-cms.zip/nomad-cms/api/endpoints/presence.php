<?php
/**
 * NOMAD CMS - Presence & Soft Collision Warning API Endpoint
 * 
 * Manages active editor presence tracking per entity (slot or item) using HTTP polling.
 * Zero external dependencies, backed by system.sqlite.
 * 
 * Endpoints & Methods:
 * - POST /api/presence          - Register/heartbeat presence & retrieve other active editors
 * - DELETE /api/presence        - Remove presence on editor exit/unmount
 * 
 * Entity Key format:
 * - Object / Singleton slot:    slot:{slot_key}          (e.g., slot:hero)
 * - Collection / Massive item:  item:{slot_key}:{item_id} (e.g., item:articles:post-123)
 */

declare(strict_types=1);

require_once __DIR__ . '/../bootstrap.php';

use NomadCMS\Database\Database;
use NomadCMS\Database\UserRepository;
use NomadCMS\Middleware\AuthMiddleware;
use NomadCMS\Services\RBACService;

// Apply CORS headers
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-API-Key');
header('Content-Type: application/json; charset=utf-8');

// Handle preflight
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

// Authenticate request
try {
    $currentUser = AuthMiddleware::requireAuth();
} catch (\Throwable $e) {
    http_response_code(401);
    echo json_encode([
        'success' => false,
        'error' => 'Authentication required',
        'code' => 'UNAUTHORIZED',
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

$db = Database::getSystemConnection();

// Ensure presence table exists with client_id granularity
try {
    $columns = $db->query("PRAGMA table_info(system_presence)")->fetchAll(\PDO::FETCH_COLUMN, 1);
    if (!in_array('client_id', $columns, true)) {
        $db->exec("DROP TABLE IF EXISTS system_presence");
        $db->exec("
            CREATE TABLE system_presence (
                entity_key TEXT NOT NULL,
                client_id TEXT NOT NULL,
                user_id TEXT NOT NULL,
                user_name TEXT NOT NULL,
                last_seen INTEGER NOT NULL,
                PRIMARY KEY (entity_key, client_id)
            )
        ");
    }
} catch (\Throwable $e) {
    error_log('[Presence] Schema check/migration failed: ' . $e->getMessage());
}

// TTL Cleanup: Automatically purge records older than 65 seconds (for 10s-30s heartbeat buffer)
$now = time();
$ttlCutoff = $now - 65;

try {
    $cleanupStmt = $db->prepare("DELETE FROM system_presence WHERE last_seen < ?");
    $cleanupStmt->execute([$ttlCutoff]);
} catch (\Throwable $e) {
    error_log('[Presence] TTL cleanup failed: ' . $e->getMessage());
}

// Resolve user information
$userId = (string) ($currentUser->uuid ?? $currentUser->id ?? 'unknown');
$userName = 'Admin';

try {
    if (!empty($currentUser->uuid)) {
        $userRecord = UserRepository::findByUuid($currentUser->uuid);
        if ($userRecord) {
            $firstName = trim((string) ($userRecord['first_name'] ?? ''));
            $lastName = trim((string) ($userRecord['last_name'] ?? ''));
            $full = trim("$firstName $lastName");
            if (!empty($full)) {
                $userName = $full;
            } elseif (!empty($userRecord['email'])) {
                $userName = $userRecord['email'];
            }
        }
    }
} catch (\Throwable $e) {
    // Fallback to token email or default
    $userName = $currentUser->email ?? 'Admin';
}

// Parse request payload
$body = getJsonBody() ?? [];
$slotKey = trim((string) ($body['slot_key'] ?? $body['slot_id'] ?? $body['slot'] ?? $_GET['slot_key'] ?? $_GET['slot_id'] ?? $_GET['slot'] ?? ''));
$itemId = isset($body['item_id']) ? trim((string) $body['item_id']) : (isset($_GET['item_id']) ? trim((string) $_GET['item_id']) : (isset($body['item']) ? trim((string) $body['item']) : (isset($_GET['item']) ? trim((string) $_GET['item']) : null)));
$entityKey = trim((string) ($body['entity_key'] ?? $_GET['entity_key'] ?? ''));
$clientId = trim((string) ($body['client_id'] ?? $_GET['client_id'] ?? ''));
if (empty($clientId)) {
    $clientId = $userId;
}

// Construct entity key if not provided directly
if (empty($entityKey) && !empty($slotKey)) {
    if ($itemId !== null && $itemId !== '') {
        $entityKey = "item:{$slotKey}:{$itemId}";
    } else {
        $entityKey = "slot:{$slotKey}";
    }
}

if (empty($entityKey)) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'error' => 'Missing entity_key or slot_key parameter',
        'code' => 'INVALID_ENTITY',
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

$method = $_SERVER['REQUEST_METHOD'];
$action = strtolower((string) ($body['action'] ?? $_GET['action'] ?? ''));

// Permission / Write Gating
if (!empty($slotKey) && empty($currentUser->is_admin)) {
    // Verify slot access
    if (!RBACService::canAccessSlot($currentUser, $slotKey)) {
        http_response_code(403);
        echo json_encode([
            'success' => false,
            'error' => "Access denied to slot: {$slotKey}",
            'code' => 'SLOT_ACCESS_DENIED',
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }
    
    // For mutating methods (POST / DELETE), verify write permissions
    if ($method === 'POST' || $method === 'DELETE' || ($method === 'POST' && $action === 'delete')) {
        $hasWritePermission = RBACService::hasPermission($currentUser, 'content:update:*', $slotKey, $itemId)
            || RBACService::hasPermission($currentUser, 'content:create:*', $slotKey, $itemId)
            || RBACService::hasPermission($currentUser, 'content:manage:*', $slotKey, $itemId)
            || RBACService::hasPermission($currentUser, 'content:update', $slotKey, $itemId)
            || RBACService::hasPermission($currentUser, 'content:create', $slotKey, $itemId)
            || RBACService::hasPermission($currentUser, 'content:manage', $slotKey, $itemId)
            || RBACService::hasGrantedScope($currentUser, 'content:update:own')
            || RBACService::hasGrantedScope($currentUser, 'content:create:own');

        if (!$hasWritePermission) {
            http_response_code(403);
            echo json_encode([
                'success' => false,
                'error' => 'Write permission required for presence heartbeat',
                'code' => 'FORBIDDEN_READ_ONLY',
            ], JSON_UNESCAPED_UNICODE);
            exit;
        }
    }
}

// Support POST action=delete (used by navigator.sendBeacon fallback)
if ($method === 'DELETE' || ($method === 'POST' && $action === 'delete')) {
    try {
        $deleteStmt = $db->prepare("DELETE FROM system_presence WHERE entity_key = ? AND client_id = ?");
        $deleteStmt->execute([$entityKey, $clientId]);

        echo json_encode([
            'success' => true,
            'entity_key' => $entityKey,
        ], JSON_UNESCAPED_UNICODE);
        exit;
    } catch (\Throwable $e) {
        http_response_code(500);
        echo json_encode([
            'success' => false,
            'error' => 'Failed to delete presence',
            'details' => $e->getMessage(),
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }
}

if ($method === 'POST') {
    try {
        // Upsert current user's presence record keyed by (entity_key, client_id)
        $upsertStmt = $db->prepare("
            INSERT INTO system_presence (entity_key, client_id, user_id, user_name, last_seen)
            VALUES (:entity_key, :client_id, :user_id, :user_name, :last_seen)
            ON CONFLICT(entity_key, client_id) DO UPDATE SET
                user_id = excluded.user_id,
                user_name = excluded.user_name,
                last_seen = excluded.last_seen
        ");
        $upsertStmt->execute([
            ':entity_key' => $entityKey,
            ':client_id' => $clientId,
            ':user_id' => $userId,
            ':user_name' => $userName,
            ':last_seen' => $now,
        ]);

        // Query all OTHER active editors on the same entity within TTL window
        $queryStmt = $db->prepare("
            SELECT user_name, user_id, client_id, last_seen
            FROM system_presence
            WHERE entity_key = :entity_key
              AND client_id != :client_id
              AND last_seen >= :ttl_cutoff
            ORDER BY last_seen DESC
        ");
        $queryStmt->execute([
            ':entity_key' => $entityKey,
            ':client_id' => $clientId,
            ':ttl_cutoff' => $ttlCutoff,
        ]);
        $rows = $queryStmt->fetchAll(\PDO::FETCH_ASSOC);

        $editors = [];
        foreach ($rows as $row) {
            $name = (string) $row['user_name'];
            if ((string) $row['user_id'] === $userId) {
                $name .= ' (' . ($row['user_name'] === 'Admin' ? 'másik ablak' : 'másik munkamenet') . ')';
            }
            $editors[] = [
                'user_name' => $name,
                'last_seen' => (int) $row['last_seen'],
            ];
        }

        echo json_encode([
            'success' => true,
            'entity_key' => $entityKey,
            'editors' => $editors ?: [],
            'is_concurrent' => count($editors) > 0,
        ], JSON_UNESCAPED_UNICODE);
        exit;
    } catch (\Throwable $e) {
        http_response_code(500);
        echo json_encode([
            'success' => false,
            'error' => 'Failed to update presence',
            'details' => $e->getMessage(),
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }
}

if ($method === 'GET') {
    try {
        // Query all active editors on the same entity within TTL window
        $queryStmt = $db->prepare("
            SELECT user_name, user_id, client_id, last_seen
            FROM system_presence
            WHERE entity_key = :entity_key
              AND client_id != :client_id
              AND last_seen >= :ttl_cutoff
            ORDER BY last_seen DESC
        ");
        $queryStmt->execute([
            ':entity_key' => $entityKey,
            ':client_id' => $clientId,
            ':ttl_cutoff' => $ttlCutoff,
        ]);
        $rows = $queryStmt->fetchAll(\PDO::FETCH_ASSOC);

        $editors = [];
        foreach ($rows as $row) {
            $name = (string) $row['user_name'];
            if ((string) $row['user_id'] === $userId) {
                $name .= ' (' . ($row['user_name'] === 'Admin' ? 'másik ablak' : 'másik munkamenet') . ')';
            }
            $editors[] = [
                'user_name' => $name,
                'last_seen' => (int) $row['last_seen'],
            ];
        }

        echo json_encode([
            'success' => true,
            'entity_key' => $entityKey,
            'editors' => $editors ?: [],
            'is_concurrent' => count($editors) > 0,
        ], JSON_UNESCAPED_UNICODE);
        exit;
    } catch (\Throwable $e) {
        http_response_code(500);
        echo json_encode([
            'success' => false,
            'error' => 'Failed to retrieve presence',
            'details' => $e->getMessage(),
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }
}

http_response_code(405);
echo json_encode([
    'success' => false,
    'error' => 'Method not allowed',
    'code' => 'METHOD_NOT_ALLOWED',
], JSON_UNESCAPED_UNICODE);
