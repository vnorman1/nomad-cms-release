<?php

/**
 * NOMAD CMS - Personal notification preferences endpoint.
 * Keeps scoped, versioned notification overrides separate from general UI preferences.
 * Authentication and session CSRF checks are enforced by the central controller.
 */

declare(strict_types=1);

require_once __DIR__ . '/../bootstrap.php';
handlePreflight();
\NomadCMS\Services\NotificationService\HttpController::dispatch('preferences');
