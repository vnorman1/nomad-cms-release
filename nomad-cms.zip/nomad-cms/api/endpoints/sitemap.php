<?php
/**
 * Sitemap Endpoint Logic
 * Generates XML sitemap dynamically from schema configuration with Dirty Flag + Lazy Build architecture.
 *
 * Performance & Concurrency:
 * - Clean cache fast path: Zero database connections, direct readfile() with 304 Not Modified support.
 * - Dirty / Missing cache: Non-blocking flock(LOCK_EX | LOCK_NB) protects against DDoS and Cache Stampede.
 * - Stale fallback: Concurrent requests during generation are served existing cache immediately.
 * - Cold start: bounded build steps return 503/Retry-After until the first complete generation.
 */

declare(strict_types=1);

require_once dirname(__DIR__, 1) . '/update-guard.php';

use NomadCMS\Database\ContentDatabase;
use NomadCMS\Middleware\RateLimitMiddleware;

// Sitemap, robots and llms keep their own schema-driven file caches independently of SEO Studio.

$cacheDir  = dirname(__DIR__) . '/storage/cache';
$cacheFile = $cacheDir . '/sitemap.xml';
$dirtyFile = $cacheDir . '/sitemap.dirty';
$lockFile  = $cacheDir . '/sitemap.lock';

/**
 * Serve static sitemap file with HTTP headers and 304 Not Modified support
 */
function serveStaticSitemap(string $filePath): void
{
    $mtime = filemtime($filePath);
    $size  = filesize($filePath);
    $etag  = sprintf('"%x-%x"', $mtime, $size);

    if (!headers_sent()) {
        header('Content-Type: application/xml; charset=utf-8');
        header('Cache-Control: public, max-age=300, must-revalidate');
        header('ETag: ' . $etag);
        header('Last-Modified: ' . gmdate('D, d M Y H:i:s', $mtime) . ' GMT');

        $ifNoneMatch     = isset($_SERVER['HTTP_IF_NONE_MATCH']) ? trim($_SERVER['HTTP_IF_NONE_MATCH']) : null;
        $ifModifiedSince = isset($_SERVER['HTTP_IF_MODIFIED_SINCE']) ? strtotime($_SERVER['HTTP_IF_MODIFIED_SINCE']) : false;

        if (($ifNoneMatch && $ifNoneMatch === $etag) || ($ifModifiedSince && $ifModifiedSince >= $mtime)) {
            http_response_code(304);
            exit;
        }
    }

    if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'HEAD') {
        readfile($filePath);
    }
    exit;
}

/**
 * Serve static llms.txt file with HTTP headers and 304 Not Modified support
 */
function serveStaticLlms(string $filePath): void
{
    $mtime = filemtime($filePath);
    $size  = filesize($filePath);
    $etag  = sprintf('"%x-%x"', $mtime, $size);

    if (!headers_sent()) {
        header('Content-Type: text/plain; charset=utf-8');
        header('Cache-Control: public, max-age=300, must-revalidate');
        header('ETag: ' . $etag);
        header('Last-Modified: ' . gmdate('D, d M Y H:i:s', $mtime) . ' GMT');

        $ifNoneMatch     = isset($_SERVER['HTTP_IF_NONE_MATCH']) ? trim($_SERVER['HTTP_IF_NONE_MATCH']) : null;
        $ifModifiedSince = isset($_SERVER['HTTP_IF_MODIFIED_SINCE']) ? strtotime($_SERVER['HTTP_IF_MODIFIED_SINCE']) : false;

        if (($ifNoneMatch && $ifNoneMatch === $etag) || ($ifModifiedSince && $ifModifiedSince >= $mtime)) {
            http_response_code(304);
            exit;
        }
    }

    readfile($filePath);
    exit;
}

/**
 * Serve static robots.txt file with HTTP headers and 304 Not Modified support
 */
function serveStaticRobots(string $filePath): void
{
    $mtime = filemtime($filePath);
    $size  = filesize($filePath);
    $etag  = sprintf('"%x-%x"', $mtime, $size);

    if (!headers_sent()) {
        header('Content-Type: text/plain; charset=utf-8');
        header('Cache-Control: public, max-age=300, must-revalidate');
        header('ETag: ' . $etag);
        header('Last-Modified: ' . gmdate('D, d M Y H:i:s', $mtime) . ' GMT');

        $ifNoneMatch     = isset($_SERVER['HTTP_IF_NONE_MATCH']) ? trim($_SERVER['HTTP_IF_NONE_MATCH']) : null;
        $ifModifiedSince = isset($_SERVER['HTTP_IF_MODIFIED_SINCE']) ? strtotime($_SERVER['HTTP_IF_MODIFIED_SINCE']) : false;

        if (($ifNoneMatch && $ifNoneMatch === $etag) || ($ifModifiedSince && $ifModifiedSince >= $mtime)) {
            http_response_code(304);
            exit;
        }
    }

    readfile($filePath);
    exit;
}

/**
 * Resolve the shared site origin without requiring any SEO Studio configuration.
 * Existing environment URLs remain authoritative; local requests also work without them.
 */
function sitemapSiteUrl(): string
{
    foreach (['SITE_URL', 'APP_URL'] as $key) {
        $value = trim((string) ($_ENV[$key] ?? ''));
        if ($value !== '') {
            return rtrim($value, '/');
        }
    }

    $authority = strtolower((string) ($_SERVER['HTTP_HOST'] ?? ''));
    $parts = parse_url('http://' . $authority);
    $host = $parts['host'] ?? '';
    $local = $host === 'localhost' || $host === '[::1]'
        || (filter_var($host, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4) !== false && str_starts_with($host, '127.'));
    if ($local && $authority === $host . (isset($parts['port']) ? ':' . $parts['port'] : '')) {
        $secure = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || (string) ($_SERVER['SERVER_PORT'] ?? '') === '443';
        return ($secure ? 'https://' : 'http://') . $authority;
    }

    return 'https://yourdomain.com';
}

/**
 * Load sitemap configuration dynamically from nomad.schema.json
 */
function loadSitemapConfigFromSchema(): array
{
    $schemaPath = __DIR__ . '/../data/nomad.schema.json';

    if (!\NomadCMS\Services\Schema\SchemaProvider::initialized() && !file_exists($schemaPath)) {
        return [];
    }

    $schema = \NomadCMS\Services\Schema\SchemaProvider::schema();
    if (!$schema || !isset($schema['slots'])) {
        return [];
    }

    $sitemapConfig = [];

    foreach ($schema['slots'] as $key => $slot) {
        if (empty($slot['isSitemap'])) {
            continue;
        }

        $type = $slot['type'] ?? 'object';
        if (!in_array($type, ['collection', 'massive', 'list'])) {
            continue;
        }

        $slugField      = $slot['slugField'] ?? 'slug';
        $publishedField = $slot['publishedField'] ?? null;
        $lastmodField   = $slot['lastmodField'] ?? null;
        $urlPattern     = $slot['urlPattern'] ?? ('/' . $key . '/{slug}');

        $sitemapConfig[$key] = [
            'label'          => $slot['label'] ?? ucfirst($key),
            'slugField'      => $slugField,
            'publishedField' => $publishedField,
            'lastmodField'   => $lastmodField,
            'includeLastmod' => $slot['includeLastmod'] ?? true,
            'urlPattern'     => $urlPattern,
            'priority'       => '0.7',
            'changefreq'     => 'weekly',
            'type'           => $type,
            'summaryField'   => $slot['summaryField'] ?? null,
            'titleField'     => $slot['titleField'] ?? null,
            'isLlms'         => $slot['isLlms'] ?? true,
        ];
    }

    return $sitemapConfig;
}

/**
 * Load static pages from schema's staticPages array
 */
function loadStaticPagesFromSchema(): array
{
    $schemaPath = __DIR__ . '/../data/nomad.schema.json';

    if (!\NomadCMS\Services\Schema\SchemaProvider::initialized() && !file_exists($schemaPath)) {
        return [
            ['path' => '/', 'priority' => '1.0', 'changefreq' => 'daily'],
        ];
    }

    $schema = \NomadCMS\Services\Schema\SchemaProvider::schema();

    if (!empty($schema['staticPages']) && is_array($schema['staticPages'])) {
        return $schema['staticPages'];
    }

    return [
        ['path' => '/', 'priority' => '1.0', 'changefreq' => 'daily'],
    ];
}

/**
 * Load i18n configuration from schema
 */
function loadI18nConfig(): ?array
{
    $schemaPath = __DIR__ . '/../data/nomad.schema.json';

    if (!\NomadCMS\Services\Schema\SchemaProvider::initialized() && !file_exists($schemaPath)) {
        return null;
    }

    $schema = \NomadCMS\Services\Schema\SchemaProvider::schema();
    $i18n   = $schema['i18n'] ?? null;

    if (!$i18n || empty($i18n['enabled'])) {
        return null;
    }

    $languages        = $i18n['languages'] ?? [];
    $defaultLanguage  = $i18n['defaultLanguage'] ?? 'hu';
    $xDefaultLanguage = $i18n['xDefaultLanguage'] ?? $defaultLanguage;

    if (count($languages) < 2) {
        return null;
    }

    return [
        'enabled'          => true,
        'defaultLanguage'  => $defaultLanguage,
        'languages'        => $languages,
        'xDefaultLanguage' => $xDefaultLanguage,
    ];
}

/**
 * Build i18n URL blocks for a single base path
 */
function buildI18nUrlBlock(
    string $basePath,
    string $siteUrl,
    array $languages,
    string $xDefaultLang,
    string $priority,
    string $changefreq,
    ?string $lastmod = null
): string {
    $xml = '';
    $basePath = ($basePath === '/' || $basePath === '') ? '' : $basePath;

    foreach ($languages as $lang) {
        $loc = $siteUrl . '/' . $lang . $basePath;

        $xml .= '  <url>' . PHP_EOL;
        $xml .= '    <loc>' . htmlspecialchars($loc) . '</loc>' . PHP_EOL;

        foreach ($languages as $altLang) {
            $altHref = $siteUrl . '/' . $altLang . $basePath;
            $xml .= '    <xhtml:link rel="alternate" hreflang="' . $altLang
                  . '" href="' . htmlspecialchars($altHref) . '" />' . PHP_EOL;
        }

        $xDefaultHref = $siteUrl . '/' . $xDefaultLang . $basePath;
        $xml .= '    <xhtml:link rel="alternate" hreflang="x-default" href="'
              . htmlspecialchars($xDefaultHref) . '" />' . PHP_EOL;

        if ($lastmod) {
            $xml .= '    <lastmod>' . $lastmod . '</lastmod>' . PHP_EOL;
        }
        $xml .= '    <changefreq>' . $changefreq . '</changefreq>' . PHP_EOL;
        $xml .= '    <priority>' . $priority . '</priority>' . PHP_EOL;
        $xml .= '  </url>' . PHP_EOL;
    }

    return $xml;
}

/**
 * Generate robots.txt
 */
function generateRobotsTxt(): string
{
    $siteUrl = sitemapSiteUrl();

    $robots  = "# NOMAD CMS - Robots.txt\n";
    $robots .= "# Generated automatically\n\n";
    $robots .= "User-agent: *\n";
    $robots .= "Allow: /\n\n";
    $robots .= "# Admin areas\n";
    $robots .= "Disallow: /nomad/\n";
    $robots .= "Disallow: /api/\n";
    $robots .= "Allow: /api/uploads/\n\n";
    $robots .= "Allow: /api/static/\n\n";
    $robots .= "# Sensitive paths\n";
    $robots .= "Disallow: /*.json$\n";
    $robots .= "Disallow: /*.php$\n\n";
    $robots .= "# Sitemap\n";
    $robots .= "Sitemap: " . rtrim($siteUrl, '/') . "/sitemap.xml\n";

    return $robots;
}

/**
 * Clean text value for llms.txt (strips HTML, collapses whitespace, truncates)
 */
function cleanTextForLlms(mixed $value, int $maxLength = 250): string
{
    if (is_array($value)) {
        $text = '';
        array_walk_recursive($value, function ($val) use (&$text) {
            if (is_string($val) && strlen($val) > 0) {
                $text .= ' ' . $val;
            }
        });
    } elseif (is_string($value) || is_numeric($value)) {
        $text = (string) $value;
    } else {
        return '';
    }

    $text = strip_tags($text);
    $text = html_entity_decode($text, ENT_QUOTES | ENT_HTML5, 'UTF-8');
    $text = preg_replace('/\s+/', ' ', $text);
    $text = trim($text ?? '');

    if (mb_strlen($text, 'UTF-8') > $maxLength) {
        $text = mb_substr($text, 0, $maxLength - 3, 'UTF-8') . '...';
    }

    return $text;
}

// =========================================================================
// MAIN EXECUTION FLOW — bounded generations replace the former monolithic lazy rebuild.
// Clean cache fast path: zero database connections, readfile() and ETag/304.
// Dirty / missing cache: non-blocking flock prevents stampedes; stale fallback stays available.
// Cold start: return Retry-After instead of waiting on another writer's shared lock.
// =========================================================================

require_once __DIR__ . '/../src/Services/DiscoveryService.php';

$discovery = \NomadCMS\Services\DiscoveryService::production($cacheDir, static function (): void {
    require_once __DIR__ . '/../bootstrap.php';
});
$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
if (!in_array($method, ['GET', 'HEAD'], true)) {
    header('Allow: GET, HEAD');
    http_response_code(405);
    exit;
}

/** Check the control plane only when this request would mutate discovery. */
function nomadDiscoveryMayWrite(): bool
{
    require_once dirname(__DIR__) . '/vendor/autoload.php';
    if (is_file(dirname(__DIR__) . '/.env')) {
        \Dotenv\Dotenv::createImmutable(dirname(__DIR__))->safeLoad();
    }
    if (\NomadCMS\Security\PanicModeService::isActive()) {
        return false;
    }
    try {
        \NomadCMS\Security\PanicMutationGuard::beginRequest();
        register_shutdown_function(\NomadCMS\Security\PanicMutationGuard::releaseRequest(...));
        return true;
    } catch (\NomadCMS\Security\PanicModeException) {
        return false;
    }
}

/** Send complete immutable discovery files without bootstrap or SQLite. */
function serveDiscoveryFile(string $path, string $type): never
{
    $mtime = (int) filemtime($path);
    $etag = '"' . hash('sha256', realpath($path) . ':' . filesize($path) . ':' . $mtime) . '"';
    header('Content-Type: ' . $type . '; charset=utf-8');
    header('Cache-Control: public, max-age=300, must-revalidate');
    header('ETag: ' . $etag);
    header('Last-Modified: ' . gmdate('D, d M Y H:i:s', $mtime) . ' GMT');
    $condition = $_SERVER['HTTP_IF_NONE_MATCH'] ?? null;
    $matches = $condition !== null && ($condition === '*' || in_array($etag,
        array_map(static fn ($value) => preg_replace('/^W\//', '', trim($value)), explode(',', $condition)), true));
    $since = strtotime($_SERVER['HTTP_IF_MODIFIED_SINCE'] ?? '');
    if ($matches || ($condition === null && $since !== false && $since >= $mtime)) {
        http_response_code(304);
        exit;
    }
    header('Content-Length: ' . filesize($path));
    if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'HEAD') {
        readfile($path);
    }
    exit;
}

if (isset($_GET['discovery_kind'])) {
    $kind = $_GET['discovery_kind'];
    $generation = $_GET['generation'] ?? '';
    $part = $_GET['discovery_path'] ?? null;
    if ($part === null) {
        $segments = [];
        foreach (['index_a', 'index_b', 'index_c', 'index_d'] as $segment) {
            if (isset($_GET[$segment])) {
                $segments[] = $_GET[$segment];
            }
        }
        if (count(array_filter($segments, 'is_string')) !== count($segments)) {
            http_response_code(400);
            exit;
        }
        $part = implode('/', $segments) . ($kind === 'md' ? '.md' : '.xml');
    }
    $path = is_string($generation) && is_string($part) && in_array($kind, ['md', 'xml'], true)
        ? $discovery->file($generation, $kind . '/' . $part) : null;
    if ($path === null) {
        http_response_code(404);
        exit;
    }
    serveDiscoveryFile($path, $kind === 'md' ? 'text/markdown' : 'application/xml');
}

if (($_GET['robots'] ?? null) === '1') {
    $path = $cacheDir . '/robots.txt';
    if ((!is_file($path) || is_file($cacheDir . '/robots.dirty'))
        && nomadDiscoveryMayWrite()) {
        if (!is_dir($cacheDir)) {
            mkdir($cacheDir, 0700, true);
        }
        $lock = fopen($cacheDir . '/robots.lock', 'c+');
        if ($lock !== false && flock($lock, LOCK_EX | LOCK_NB)) {
            $revisionLock = fopen($cacheDir . '/discovery-invalidation.lock', 'c+');
            if ($revisionLock === false || !flock($revisionLock, LOCK_EX)) {
                flock($lock, LOCK_UN);
                fclose($lock);
                http_response_code(503);
                header('Retry-After: 30');
                exit;
            }
            try {
                $robots = generateRobotsTxt();
                $manifest = $discovery->manifest();
                foreach ($manifest['roots'] ?? [] as $name => $relative) {
                    if (str_starts_with($name, 'xml:') && $name !== 'xml:') {
                        $robots .= 'Sitemap: ' . $manifest['origin'] . '/sitemap-'
                            . $manifest['generation'] . '-' . substr($relative, 4) . "\n";
                    }
                }
                \NomadCMS\Services\DiscoveryService::atomic($path, $robots);
                if (is_file($cacheDir . '/robots.dirty')) {
                    unlink($cacheDir . '/robots.dirty');
                }
            } finally {
                flock($revisionLock, LOCK_UN);
                fclose($revisionLock);
                flock($lock, LOCK_UN);
                fclose($lock);
            }
        } elseif ($lock !== false) {
            fclose($lock);
        }
    }
    if (is_file($path)) {
        serveDiscoveryFile($path, 'text/plain');
    }
} else {
    $kind = ($_GET['llms'] ?? null) === '1' ? 'md' : 'xml';
    $locale = $kind === 'md' ? ($_GET['lang'] ?? null) : null;
    $locale = $locale === '' ? null : $locale;
    if ($locale !== null && (!is_string($locale) || !preg_match('/^[a-zA-Z0-9_-]{1,32}$/D', $locale))) {
        http_response_code(400);
        exit;
    }
    if ($discovery->dirty() && nomadDiscoveryMayWrite()) {
        try {
            $discovery->work(1.0);
        } catch (\Throwable $error) {
            error_log('[Discovery] ' . $error->getMessage());
        }
    }
    $path = $discovery->root($kind, $locale);
    // Preserve the previous behavior for unknown language filters: return the complete index.
    $path ??= $discovery->root($kind);
    if ($path !== null) {
        serveDiscoveryFile($path, $kind === 'md' ? 'text/plain' : 'application/xml');
    }
    // During the first upgrade build, the existing complete cache remains a valid stale fallback.
    $legacy = $cacheDir . '/' . ($kind === 'md' ? 'llms.txt' : 'sitemap.xml');
    if (is_file($legacy)) {
        serveDiscoveryFile($legacy, $kind === 'md' ? 'text/plain' : 'application/xml');
    }
}
http_response_code(503);
header('Retry-After: 30');
header('Cache-Control: no-store');
if ($method !== 'HEAD') {
    echo 'Discovery indexes are being generated. Retry later.';
}
