<?php

/**
 * NOMAD CMS - Cron Tokens Management API Endpoint
 *
 * Provides CRUD operations for Web-Cron tokens with fine-grained task permissions.
 *
 * Security: Requires Admin / system:manage:* permission.
 *
 * Endpoints:
 * - GET    /api/endpoints/system/cron-tokens.php          - List all tokens
 * - POST   /api/endpoints/system/cron-tokens.php          - Create new token (generates plain token)
 * - DELETE /api/endpoints/system/cron-tokens.php?id=123   - Delete token
 * - PATCH  /api/endpoints/system/cron-tokens.php          - Toggle token active status
 */

declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/bootstrap.php';

use NomadCMS\Cron\CronTokenService;
use NomadCMS\Middleware\AuthMiddleware;

header('Content-Type: application/json; charset=utf-8');

// Handle CORS preflight
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

// 1. Authenticate & Authorize
$currentUser = AuthMiddleware::requireAuth();

$hasPermission = AuthMiddleware::hasGrantedScope('system:manage:*')
    || !empty($currentUser->is_admin);

if (!$hasPermission) {
    http_response_code(403);
    echo json_encode([
        'success' => false,
        'error' => 'Nincs jogosultságod a Web-Cron tokenek kezeléséhez.',
        'code' => 'FORBIDDEN',
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

$tokenService = new CronTokenService();
$method = $_SERVER['REQUEST_METHOD'];

try {
    switch ($method) {
        case 'GET':
            $tokens = $tokenService->listTokens();
            echo json_encode([
                'success' => true,
                'tokens' => $tokens,
            ], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
            break;

        case 'POST':
            $input = getJsonBody() ?? [];
            $name = trim((string)($input['name'] ?? ''));
            $allowedTasks = isset($input['allowed_tasks']) && is_array($input['allowed_tasks'])
                ? $input['allowed_tasks']
                : ['*'];

            if ($name === '') {
                http_response_code(400);
                echo json_encode([
                    'success' => false,
                    'error' => 'A token nevének megadása kötelező.',
                    'code' => 'VALIDATION_ERROR',
                ], JSON_UNESCAPED_UNICODE);
                exit;
            }

            $userId = isset($currentUser->id) ? (int)$currentUser->id : null;
            $created = $tokenService->createToken($name, $allowedTasks, $userId);

            // Construct full Web-Cron URL
            $appUrl = rtrim((string)($_ENV['APP_URL'] ?? ''), '/');
            if ($appUrl === '') {
                $isHttps = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || (isset($_SERVER['SERVER_PORT']) && $_SERVER['SERVER_PORT'] == 443);
                $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
                $appUrl = ($isHttps ? 'https://' : 'http://') . $host;
            }

            $cronUrl = $appUrl . '/api/cron?token=' . $created['plain_token'];
            $cpanelCommand = "* * * * * curl -s -f \"" . $cronUrl . "\" > /dev/null 2>&1";

            http_response_code(201);
            echo json_encode([
                'success' => true,
                'message' => 'Web-Cron token sikeresen létrehozva.',
                'token' => $created,
                'cron_url' => $cronUrl,
                'cpanel_command' => $cpanelCommand,
            ], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
            break;

        case 'PUT':
        case 'PATCH':
            $input = getJsonBody() ?? [];
            $id = isset($input['id']) ? (int)$input['id'] : (isset($_GET['id']) ? (int)$_GET['id'] : 0);

            if ($id <= 0) {
                http_response_code(400);
                echo json_encode(['success' => false, 'error' => 'Érvénytelen token azonosító.'], JSON_UNESCAPED_UNICODE);
                exit;
            }

            $name = isset($input['name']) ? trim((string)$input['name']) : null;
            $allowedTasks = isset($input['allowed_tasks']) && is_array($input['allowed_tasks'])
                ? $input['allowed_tasks']
                : null;
            $isActive = isset($input['is_active']) ? (bool)$input['is_active'] : null;

            $ok = $tokenService->updateToken($id, $name, $allowedTasks, $isActive);
            echo json_encode([
                'success' => $ok,
                'message' => $ok ? 'Web-Cron token sikeresen frissítve.' : 'A token nem található vagy nem történt módosítás.',
            ], JSON_UNESCAPED_UNICODE);
            break;

        case 'DELETE':
            $input = getJsonBody() ?? [];
            $id = isset($_GET['id']) ? (int)$_GET['id'] : (int)($input['id'] ?? 0);

            if ($id <= 0) {
                http_response_code(400);
                echo json_encode(['success' => false, 'error' => 'Érvénytelen token azonosító.'], JSON_UNESCAPED_UNICODE);
                exit;
            }

            $ok = $tokenService->deleteToken($id);
            echo json_encode([
                'success' => $ok,
                'message' => $ok ? 'Token törölve.' : 'A token nem található.',
            ], JSON_UNESCAPED_UNICODE);
            break;

        default:
            http_response_code(405);
            echo json_encode(['success' => false, 'error' => 'Method not allowed'], JSON_UNESCAPED_SLASHES);
            break;
    }
} catch (\Throwable $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage(),
    ], JSON_UNESCAPED_UNICODE);
}
