<?php

/**
 * NOMAD CMS - Cron Status & Health API Endpoint
 *
 * Provides administrative visibility into scheduled tasks, recent execution logs,
 * active locks, and background worker health.
 *
 * Security: Requires Admin authentication.
 *
 * Usage:
 *   GET /api/endpoints/system/cron-status.php
 */

declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/bootstrap.php';

use NomadCMS\Cron\CronContext;
use NomadCMS\Cron\CronSchema;
use NomadCMS\Cron\LockManager;
use NomadCMS\Cron\TaskManager;
use NomadCMS\Middleware\AuthMiddleware;

// Set response headers
header('Content-Type: application/json; charset=utf-8');

// Apply CORS preflight if needed
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

// 1. Require Authentication & RBAC Permission
$currentUser = AuthMiddleware::requireAuth();

$hasPermission = AuthMiddleware::hasGrantedScope('system:manage:*') 
    || AuthMiddleware::hasGrantedScope('logs:read:*') 
    || !empty($currentUser->is_admin);

if (!$hasPermission) {
    http_response_code(403);
    echo json_encode(['success' => false, 'error' => 'Nincs jogosultságod a művelet végrehajtásához.', 'code' => 'FORBIDDEN_ACTION'], JSON_UNESCAPED_UNICODE);
    exit;
}

CronSchema::ensureTables();
$taskManager = TaskManager::getInstance();
$taskManager->syncTasksWithDatabase();
$db = CronSchema::db();

$method = $_SERVER['REQUEST_METHOD'];

// Handle Manual Task Execution
if ($method === 'POST') {
    $input = getJsonBody() ?? [];
    $taskName = isset($input['task_name']) ? trim((string)$input['task_name']) : (isset($_GET['task']) ? trim((string)$_GET['task']) : null);
    $force = isset($input['force']) ? (bool)$input['force'] : true;

    $context = new CronContext('web', 25, false, false);
    $summary = $taskManager->runDueTasks($context, $taskName, $force, ['*']);

    http_response_code(200);
    echo json_encode([
        'success' => true,
        'message' => 'Feladat sikeresen végrehajtva.',
        'summary' => $summary,
    ], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
    exit;
}

// Handle Scheduled Task Configuration Update (Enable/Disable, Interval)
if ($method === 'PATCH' || $method === 'PUT') {
    $input = getJsonBody() ?? [];
    $taskName = isset($input['task_name']) ? trim((string)$input['task_name']) : '';

    if ($taskName === '') {
        http_response_code(400);
        echo json_encode(['success' => false, 'error' => 'A feladat nevének megadása kötelező.'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    $fields = [];
    $params = [':task_name' => $taskName, ':updated_at' => time()];

    if (isset($input['is_enabled'])) {
        $fields[] = 'is_enabled = :is_enabled';
        $params[':is_enabled'] = $input['is_enabled'] ? 1 : 0;
    }

    if (isset($input['interval_seconds']) && is_numeric($input['interval_seconds'])) {
        $newInterval = max(10, (int)$input['interval_seconds']);
        $fields[] = 'interval_seconds = :interval_seconds';
        $params[':interval_seconds'] = $newInterval;

        // Immediately recalculate next_due_at so UI and backend reflect the new frequency instantly
        $currentTaskStmt = $db->prepare('SELECT last_run_at FROM ' . CronSchema::TABLE_TASKS . ' WHERE task_name = :task_name');
        $currentTaskStmt->execute([':task_name' => $taskName]);
        $lastRun = $currentTaskStmt->fetchColumn();
        $lastRunTs = ($lastRun !== false && is_numeric($lastRun) && (int)$lastRun > 0) ? (int)$lastRun : null;

        $newNextDueAt = $lastRunTs !== null ? max(time() + 1, $lastRunTs + $newInterval) : (time() + $newInterval);
        $fields[] = 'next_due_at = :next_due_at';
        $params[':next_due_at'] = $newNextDueAt;
    }

    if (!empty($fields)) {
        $fields[] = 'updated_at = :updated_at';
        $sql = 'UPDATE ' . CronSchema::TABLE_TASKS . ' SET ' . implode(', ', $fields) . ' WHERE task_name = :task_name';
        $stmt = $db->prepare($sql);
        $stmt->execute($params);
    }

    http_response_code(200);
    echo json_encode([
        'success' => true,
        'message' => 'Időzített feladat beállításai frissítve.',
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

// 2. Fetch Tasks & Health (GET Request)
$now = time();

$states = $taskManager->fetchTaskStates();
$allTasks = $taskManager->getAllTasks();
$tasksList = [];

foreach ($allTasks as $name => $task) {
    $state = $states[$name] ?? [];
    $interval = (int)($state['interval_seconds'] ?? $task->getDefaultInterval());
    $lastRunAt = isset($state['last_run_at']) ? (int)$state['last_run_at'] : null;
    $nextDueAt = isset($state['next_due_at']) ? (int)$state['next_due_at'] : null;

    $tasksList[] = [
        'name' => $name,
        'description' => $task->getDescription(),
        'interval_seconds' => $interval,
        'is_enabled' => (bool)($state['is_enabled'] ?? $task->isEnabled()),
        'last_run_at' => $lastRunAt,
        'last_run_formatted' => $lastRunAt ? date('Y-m-d H:i:s', $lastRunAt) : null,
        'next_due_at' => $nextDueAt,
        'seconds_until_due' => $nextDueAt ? max(0, $nextDueAt - $now) : 0,
        'last_duration_ms' => isset($state['last_duration_ms']) ? (float)$state['last_duration_ms'] : 0,
        'last_status' => (string)($state['last_status'] ?? 'pending'),
        'last_error' => $state['last_error'] ?? null,
        'consecutive_failures' => (int)($state['consecutive_failures'] ?? 0),
        'total_runs' => (int)($state['total_runs'] ?? 0),
    ];
}

// 3. Fetch Recent Logs
$logStmt = $db->query('
    SELECT task_name, runner_mode, started_at, duration_ms, status, items_processed, memory_peak_bytes, message, created_at
    FROM ' . CronSchema::TABLE_LOGS . '
    ORDER BY id DESC
    LIMIT 25
');
$recentLogs = $logStmt->fetchAll(PDO::FETCH_ASSOC);

// 4. Lock & Heartbeat Status
$lockManager = new LockManager();
$isLocked = $lockManager->isGlobalLocked();
$lockInfo = $lockManager->getActiveLockInfo();
$lastHeartbeat = $taskManager->getLastHeartbeatTime();
$cronActive = $taskManager->isExternalCronActive();

http_response_code(200);
echo json_encode([
    'success' => true,
    'health' => [
        'is_active' => $cronActive,
        'mode' => $cronActive ? 'external_cron' : 'piggyback_fallback',
        'last_heartbeat_at' => $lastHeartbeat,
        'last_heartbeat_formatted' => $lastHeartbeat ? date('Y-m-d H:i:s', $lastHeartbeat) : null,
        'seconds_since_heartbeat' => $lastHeartbeat ? ($now - $lastHeartbeat) : null,
        'is_locked' => $isLocked,
        'lock_info' => $lockInfo,
    ],
    'tasks' => $tasksList,
    'recent_logs' => $recentLogs,
], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);

