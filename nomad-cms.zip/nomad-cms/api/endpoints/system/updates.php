<?php
/**
 * NOMAD CMS — human administrator update API.
 * Issues operation-bound worker capabilities after authoritative authorization.
 * Mutable application endpoints are never needed during code activation/rescue.
 */
declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/bootstrap.php';
require_once dirname(__DIR__, 3) . '/api/updater/load.php';

use NomadCMS\Middleware\AuthMiddleware;
use NomadCMS\Auth\AuthHttp;
use NomadCMS\Auth\AuthException;
use NomadCMS\Middleware\CSRFMiddleware;
use NomadUpdate\Controller;
use NomadUpdate\Engine;
use NomadUpdate\Files;
use NomadUpdate\Store;
use NomadUpdate\UpdateException;

try {
    $user = AuthMiddleware::requireInteractiveAuth();
    AuthMiddleware::requirePermission('system:admin:*');
    $store = new Store(dirname(__DIR__, 3));
    $engine = new Engine($store);
    $method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
    if ($method === 'GET') {
        $source = $_GET['source'] ?? 'official';
        if (!is_string($source)) {
            throw new UpdateException('INVALID_SOURCE', 'Invalid source identifier.');
        }
        Controller::json(['success' => true] + $engine->status() + ['catalog' => $engine->catalog($source)]);
    }
    if ($method !== 'POST') {
        throw new UpdateException('METHOD_NOT_ALLOWED', 'Use GET or POST.', 405);
    }
    CSRFMiddleware::validateForSession();
    try {
        AuthHttp::checkOrigin();
    } catch (AuthException) {
        throw new UpdateException('FORBIDDEN_ORIGIN', 'Cross-origin update requests are forbidden.', 403);
    }
    if (isset($_SERVER['HTTP_ORIGIN'])) {
        // Preserve the authenticated browser origin through a trusted reverse
        // proxy/dev proxy without trusting arbitrary forwarded-host headers.
        Files::writeJson($store->path . '/browser-origin.json', ['origin' => $_SERVER['HTTP_ORIGIN']]);
    }
    $input = Controller::input();
    $action = $input['action'] ?? '';
    if (!is_string($action)) {
        throw new UpdateException('INVALID_ACTION', 'Invalid update action.');
    }
    if ($action === 'settings') {
        if (!is_array($input['settings'] ?? null)) {
            throw new UpdateException('INVALID_SETTINGS', 'A settings object is required.');
        }
        Controller::json(['success' => true, 'settings' => $store->configure($input['settings'])]);
    }
    if ($action === 'rescue_token') {
        Controller::json(['success' => true, 'token' => $store->rotateRescue()]);
    }
    if ($action === 'protection') {
        $proof = Files::json($store->path . '/protection.json');
        if (isset($input['nonce'])) {
            if (!is_string($input['nonce']) || !hash_equals($proof['nonce'] ?? '', $input['nonce'])
                || !in_array($input['status'] ?? null, [403, 404], true)) {
                throw new UpdateException('PROTECTION_FAILED', 'Private update storage is not protected.');
            }
            @unlink($store->path . '/probe-' . $proof['nonce'] . '.txt');
            Files::writeJson($store->path . '/protection.json', ['verified_at' => time()]);
            Controller::json(['success' => true]);
        }
        $nonce = bin2hex(random_bytes(16));
        Files::write($store->path . '/probe-' . $nonce . '.txt', $nonce, 0644);
        Files::writeJson($store->path . '/protection.json', ['nonce' => $nonce, 'verified_at' => 0]);
        Controller::json(['success' => true, 'nonce' => $nonce, 'url' => '/api/storage/updates/probe-' . $nonce . '.txt']);
    }
    if ($action === 'check') {
        $source = $input['source'] ?? 'official';
        if (!is_string($source)) {
            throw new UpdateException('INVALID_SOURCE', 'Invalid source identifier.');
        }
        Controller::json(['success' => true, 'catalog' => $engine->catalog($source, true)]);
    }
    if ($action === 'start' || $action === 'resume') {
        $id = $input['id'] ?? null;
        if (!is_string($id)) {
            throw new UpdateException('INVALID_OPERATION', 'An operation identifier is required.');
        }
        $issued = $engine->issueCapability($id, (string) $user->uuid);
        Controller::cookie($id, $issued['ticket']);
        $operation = $action === 'start' ? $engine->start($id, (string) $user->uuid) : $issued['operation'];
        Controller::json(['success' => true, 'operation' => $operation]);
    }
    if ($action === 'prepare' || $action === 'rollback') {
        if (\NomadCMS\Security\PanicModeService::isActive()) {
            throw new UpdateException('PANIC_ACTIVE', 'Leave panic mode before updating.', 409);
        }
        $source = $input['source'] ?? 'official';
        $id = $input['id'] ?? null;
        if (!is_string($source) || !is_string($id)) {
            throw new UpdateException('INVALID_INPUT', 'A source and release/slot identifier are required.');
        }
        $prepared = $action === 'rollback' ? $engine->prepareRollback($id, $user->uuid) : $engine->prepare($source, $id, $user->uuid);
        Controller::cookie($prepared['operation']['id'], $prepared['ticket']);
        Controller::json(['success' => true, 'operation' => $prepared['operation']]);
    }
    throw new UpdateException('INVALID_ACTION', 'Unknown update action.');
} catch (Throwable $error) {
    Controller::json(['success' => false, 'error' => $error->getMessage(), 'code' => $error instanceof UpdateException ? $error->errorCode : 'UPDATE_FAILED'], $error instanceof UpdateException ? max(400, $error->getCode()) : 500);
}
