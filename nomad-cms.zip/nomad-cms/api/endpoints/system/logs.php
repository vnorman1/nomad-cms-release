<?php
/**
 * NOMAD CMS - System Logs API
 * Admin-only endpoint for viewing and managing logs
 */

declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/bootstrap.php';
handlePreflight();

require_once dirname(__DIR__, 2) . '/src/Middleware/AuthMiddleware.php';
require_once dirname(__DIR__, 2) . '/src/Services/LoggerService.php';

use NomadCMS\Middleware\AuthMiddleware;
use NomadCMS\Services\LoggerService;

header('Content-Type: application/json');

// Authenticate. Per-method RBAC:
//   GET    -> logs:read:*
//   DELETE -> logs:delete:* (clearing logs is destructive and must not be
//             reachable with mere read access)
$user = AuthMiddleware::requireAuth();

$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case 'GET':
        // NOTE: log ownership is derived from user_id embedded in the log
        // line's JSON context (RequestLoggerMiddleware), not content-slot
        // ownership - so grant detection uses hasGrantedScope() (pure "does
        // the role have this grant" check, no slot ownership lookup), same
        // rationale as media.php.
        $hasLogsReadAll = AuthMiddleware::hasGrantedScope('logs:read:*');
        $hasLogsReadOwn = AuthMiddleware::hasGrantedScope('logs:read:own');
        if (!$hasLogsReadAll && !$hasLogsReadOwn) {
            http_response_code(403);
            echo json_encode(['success' => false, 'error' => 'Nincs jogosultságod a művelet végrehajtásához.', 'code' => 'FORBIDDEN_ACTION']);
            exit;
        }

        // ABAC 'own' scope: if the user only has logs:read:own (not the
        // global logs:read:*), restrict results to log lines whose embedded
        // context carries this user's id (see LoggerService::readLogs()).
        $logsOwnOnly = !$hasLogsReadAll && $hasLogsReadOwn;
        $currentUserId = $logsOwnOnly ? ($user->id ?? null) : null;

        // Get logs with optional filters
        $level = $_GET['level'] ?? null;
        $search = $_GET['search'] ?? null;
        $limit = (int) ($_GET['limit'] ?? 100);
        $offset = (int) ($_GET['offset'] ?? 0);
        
        $result = LoggerService::readLogs($level, $search, $limit, $offset, $currentUserId);
        $stats = LoggerService::getStats();
        
        echo json_encode([
            'success' => true,
            'logs' => $result['logs'],
            'total' => $result['total'],
            'hasMore' => $result['hasMore'],
            'stats' => $stats,
            'scope' => $logsOwnOnly ? 'own' : 'all',
        ]);
        break;

    case 'DELETE':
        AuthMiddleware::requirePermission('logs:delete:*');

        // Clear logs (destructive - requires logs:delete:*, checked above)
        try {
            $success = LoggerService::clearLogs();
            
            // Note: We don't log immediately after clearing to avoid handler issues
            // The next request will log the cleared state naturally
            
            echo json_encode([
                'success' => $success,
                'message' => $success ? 'Napló törölve' : 'Hiba a napló törlésénél',
            ]);
        } catch (\Throwable $e) {
            http_response_code(500);
            echo json_encode([
                'success' => false,
                'message' => 'Hiba a napló törlésénél: ' . $e->getMessage(),
            ]);
        }
        break;

    default:
        http_response_code(405);
        echo json_encode(['success' => false, 'error' => 'Method not allowed']);
}
