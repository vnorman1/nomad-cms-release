<?php

/**
 * NOMAD CMS - Web-Cron HTTP Endpoint
 *
 * Dedicated endpoint for external web-cron services (cPanel Cron, EasyCron,
 * Cron-Job.org, UptimeRobot, or curl triggers).
 *
 * Security:
 * - Requires matching CRON_SECRET token via Header or Query param.
 * - Constant-time comparison to prevent timing attacks.
 * - Rate limiting and timeout protection.
 *
 * Usage:
 *   GET  /api/endpoints/system/cron.php?token=YOUR_CRON_SECRET
 *   POST /api/endpoints/system/cron.php with Header: X-Cron-Secret: YOUR_CRON_SECRET
 */

declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/bootstrap.php';

use NomadCMS\Cron\CronContext;
use NomadCMS\Cron\CronSchema;
use NomadCMS\Cron\CronTokenService;
use NomadCMS\Cron\TaskManager;

// Apply JSON header & prevent CDN/proxy caching
header('Content-Type: application/json; charset=utf-8');
header('X-Robots-Tag: noindex, nofollow, noarchive');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');

// 1. Extract provided token from Headers or Query
$providedToken = '';

if (!empty($_SERVER['HTTP_X_CRON_SECRET'])) {
    $providedToken = trim((string)$_SERVER['HTTP_X_CRON_SECRET']);
} elseif (!empty($_SERVER['HTTP_AUTHORIZATION'])) {
    $authHeader = trim((string)$_SERVER['HTTP_AUTHORIZATION']);
    if (preg_match('/Bearer\s+(.*)$/i', $authHeader, $matches)) {
        $providedToken = trim($matches[1]);
    }
} elseif (!empty($_GET['token'])) {
    $providedToken = trim((string)$_GET['token']);
}

if ($providedToken === '') {
    http_response_code(401);
    echo json_encode([
        'success' => false,
        'error' => 'Missing cron authentication token. Pass via ?token=..., X-Cron-Secret header, or Bearer token.',
        'code' => 'TOKEN_MISSING',
    ], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
    exit;
}

// 2. Validate token against Database tokens or fallback .env secret
$tokenService = new CronTokenService();
$tokenData = $tokenService->verifyToken($providedToken);

if ($tokenData === null) {
    http_response_code(401);
    echo json_encode([
        'success' => false,
        'error' => 'Invalid or inactive cron authentication token',
        'code' => 'UNAUTHORIZED',
    ], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
    exit;
}

// 3. Configure Execution Environment
@set_time_limit(35);
ignore_user_abort(true);

$maxTime = CronSchema::WEB_MAX_EXECUTION_TIME;
$specificTask = isset($_GET['task']) && is_string($_GET['task']) ? trim($_GET['task']) : null;
$force = isset($_GET['force']) && ($_GET['force'] === '1' || $_GET['force'] === 'true');

$context = new CronContext(
    runnerMode: CronSchema::MODE_WEB,
    maxExecutionTime: $maxTime,
    isDryRun: false,
    isVerbose: false
);

// 4. Execute Scheduled Tasks scoped by token permissions
try {
    $taskManager = TaskManager::getInstance();
    $allowedTasks = $tokenData['allowed_tasks'] ?? ['*'];
    $summary = $taskManager->runDueTasks($context, $specificTask, $force, $allowedTasks);

    if (($summary['status'] ?? '') === 'locked') {
        http_response_code(423); // 423 Locked
        echo json_encode([
            'success' => false,
            'status' => 'locked',
            'token_name' => $tokenData['name'] ?? null,
            'message' => 'Another worker process is currently running',
            'lock_info' => $summary['lock_info'] ?? null,
        ], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
        exit;
    }

    $isVerbose = isset($_GET['verbose']) && ($_GET['verbose'] === '1' || $_GET['verbose'] === 'true' || $_GET['verbose'] === 'details');

    http_response_code(200);
    if (!$isVerbose) {
        echo json_encode([
            'success' => true,
            'status' => 'ok',
            'message' => 'Cron executed successfully',
        ], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
        exit;
    }

    echo json_encode([
        'success' => true,
        'status' => 'completed',
        'mode' => 'web',
        'token_name' => $tokenData['name'] ?? null,
        'scoped_tasks' => $allowedTasks,
        'timestamp' => time(),
        'duration_ms' => $summary['duration_ms'] ?? 0,
        'executed_count' => $summary['executed_count'] ?? 0,
        'total_scanned' => $summary['total_scanned'] ?? 0,
        'results' => $summary['results'] ?? [],
    ], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);

} catch (\Throwable $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'status' => 'error',
        'error' => $e->getMessage(),
    ], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
}
