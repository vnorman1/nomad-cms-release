<?php
/**
 * NOMAD CMS - Dynamic LLM Markdown Item Endpoint
 * 
 * Serves an individual collection/list item as clean, on-the-fly generated Markdown
 * for AI models (Perplexity, ChatGPT, Claude, Cursor) with zero JavaScript overhead.
 * 
 * Performance:
 * - Direct static file serving with ETag and HTTP 304 Not Modified support.
 * - Atomic write to local cache storage.
 * - Automatically falls back to on-the-fly generation if cache is missing or dirty.
 */

declare(strict_types=1);

require_once __DIR__ . '/../bootstrap.php';

use NomadCMS\Services\LlmsService;
use NomadCMS\Services\SitemapService;

// CORS headers for public AI indexing
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, If-None-Match, If-Modified-Since');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);
    header('Content-Type: text/plain; charset=utf-8');
    exit('Method Not Allowed');
}

// 1. Parse parameters
$slotParam = $_GET['slot'] ?? null;
$slugParam = $_GET['slug'] ?? null;
$langParam = !empty($_GET['lang']) ? preg_replace('/[^a-z0-9_-]/i', '', (string)$_GET['lang']) : null;

// Allow .md suffix in slugParam if passed directly (e.g. "valamimunka.md")
if ($slugParam !== null && str_ends_with($slugParam, '.md')) {
    $slugParam = substr($slugParam, 0, -3);
}

// Allow .md suffix in slotParam if passed directly (e.g. "about.md")
if ($slotParam !== null && str_ends_with($slotParam, '.md')) {
    $slotParam = substr($slotParam, 0, -3);
}

// Disambiguate if 2-segment route assigned lang to slotParam (e.g. slot=en, slug=about)
if ($langParam === null && $slugParam !== null && preg_match('/^[a-z]{2}$/i', (string)$slotParam)) {
    $langParam = strtolower((string)$slotParam);
    $slotParam = $slugParam;
    $slugParam = null;
}

if (empty($slotParam)) {
    http_response_code(400);
    header('Content-Type: text/plain; charset=utf-8');
    exit("Missing required parameter: 'slot'.");
}

// 2. Load schema
$schemaPath = __DIR__ . '/../data/nomad.schema.json';
if (!\NomadCMS\Services\Schema\SchemaProvider::initialized() && !file_exists($schemaPath)) {
    http_response_code(500);
    header('Content-Type: text/plain; charset=utf-8');
    exit("Schema definition not found.");
}

$schema = \NomadCMS\Services\Schema\SchemaProvider::schema();

// 3. Resolve slot key
$slotKey = LlmsService::resolveSlotKey((string)$slotParam, $schema);
if ($slotKey === null || !isset($schema['slots'][$slotKey])) {
    http_response_code(404);
    header('Content-Type: text/markdown; charset=utf-8');
    echo "# 404 Not Found\n\nCollection or slot '" . htmlspecialchars((string)$slotParam, ENT_QUOTES) . "' not found.\n";
    exit;
}

$slotConfig = $schema['slots'][$slotKey];
$slotType   = $slotConfig['type'] ?? 'object';

// Check if slot has LLMS indexing disabled explicitly
if (isset($slotConfig['isLlms']) && $slotConfig['isLlms'] === false) {
    http_response_code(403);
    header('Content-Type: text/markdown; charset=utf-8');
    echo "# 403 Forbidden\n\nAI indexing is disabled for this section.\n";
    exit;
}

// 4. Handle Object Slots & Static Pages (when slug is not provided or slot is object)
if ($slotType === 'object' || empty($slugParam)) {
    $markdown = LlmsService::generateObjectSlotMarkdown($slotKey, $slotConfig, $langParam, $schema);
    if ($markdown === null) {
        http_response_code(404);
        header('Content-Type: text/markdown; charset=utf-8');
        echo "# 404 Not Found\n\nContent for '" . htmlspecialchars((string)$slotParam, ENT_QUOTES) . "' not found.\n";
        exit;
    }

    $staticManifest = dirname(__DIR__, 2) . '/static/content/' . $slotKey . '/manifest.json';
    $mtime = is_file($staticManifest) ? filemtime($staticManifest) : null;
    $etag = is_file($staticManifest) ? sprintf('"%x-%x"', $mtime, filesize($staticManifest)) : null;

    LlmsService::sendMarkdownResponse($markdown, $mtime, $etag);
}

// 4. Resolve item: First try pre-generated static JSON cache (Zero-DB, zero disk write)
$item = LlmsService::resolveItemFromStaticJson($slotKey, $slugParam, $langParam);

// If not present in static JSON cache, fallback to database resolution
if ($item === null) {
    $item = LlmsService::resolveItem($slotKey, $slugParam, $langParam, $slotConfig);
}

if ($item === null) {
    http_response_code(404);
    header('Content-Type: text/markdown; charset=utf-8');
    echo "# 404 Not Found\n\nItem '" . htmlspecialchars($slugParam, ENT_QUOTES) . "' was not found or is unpublished.\n";
    exit;
}

// 5. Generate fresh Markdown on-the-fly in memory
$markdown = LlmsService::generateItemMarkdown($slotKey, $item, $slotConfig, $langParam, $schema);

// 6. Serve directly from memory with ETag / HTTP 304 - ZERO .md files written to disk
$mtime = $item['_static_mtime'] ?? null;
$etag  = isset($item['_static_mtime'], $item['_static_file'])
    ? sprintf('"%x-%x"', $item['_static_mtime'], filesize($item['_static_file']))
    : sprintf('"%x-%x"', time(), strlen($markdown));

LlmsService::sendMarkdownResponse($markdown, $mtime, $etag);
