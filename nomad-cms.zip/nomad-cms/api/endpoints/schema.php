<?php
/**
 * Schema Endpoint
 * 
 * Serves the CMS configuration schema (nomad.schema.json).
 * Does not require authentication - schema structure is not sensitive data.
 * 
 * GET /api/endpoints/schema.php - Returns the full schema with caching headers
 */

declare(strict_types=1);

require_once __DIR__ . '/../bootstrap.php';

// Allow CORS for all origins (schema is public)
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, If-None-Match, If-Modified-Since');

// Handle preflight
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

// Only accept GET requests
if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);
    header('Content-Type: application/json');
    echo json_encode(['error' => 'Method not allowed. Use GET.']);
    exit;
}

// Schema file path remains the read-only bootstrap source.
// The active registry is the sole source after explicit initialization.
try {
    $schema = \NomadCMS\Services\Schema\SchemaProvider::schema();
    $encoded = \NomadCMS\Services\Schema\SchemaDefinition::json($schema);
    $etag = '"' . hash('sha256', $encoded) . '"';
    header('Content-Type: application/json; charset=utf-8');
    header('ETag: ' . $etag);
    header('Cache-Control: public, max-age=0, must-revalidate');
    header('Access-Control-Expose-Headers: ETag, X-Schema-Revision');
    header('X-Schema-Revision: ' . ($schema['_revision'] ?? '0'));
    if (($_SERVER['HTTP_IF_NONE_MATCH'] ?? '') === $etag) {
        http_response_code(304);
        exit;
    }
    echo $encoded;
} catch (\Throwable $error) {
    http_response_code(503);
    header('Content-Type: application/json');
    echo json_encode(['error' => 'Schema unavailable.']);
}
