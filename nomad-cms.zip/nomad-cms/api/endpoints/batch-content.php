<?php
/**
 * Batch Content Endpoint
 * Optimized endpoint for fetching multiple slot data or slot summaries in a single request.
 * 
 * Features:
 * - Summary mode for login/dashboard (microsecond SQLite aggregation, < 2KB payload)
 * - Collection overload protection ("csak annyit amennyi szükséges" - strips heavy blocks, bounds items)
 * - Massive slot pagination and stat retrieval
 * - Strict RBAC (content:read:* required)
 * - Rate limiting (5 requests/minute per client IP)
 */

declare(strict_types=1);

require_once __DIR__ . '/../bootstrap.php';

use NomadCMS\Services\BatchContentService;
use NomadCMS\Middleware\AuthMiddleware;
use NomadCMS\Middleware\RequestLoggerMiddleware;

// Handle CORS preflight
handlePreflight();

// Set JSON content type
header('Content-Type: application/json');

// Only POST allowed
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Method not allowed']);
    exit;
}

// SECURITY: require authentication + read permission
AuthMiddleware::requireAuth();
AuthMiddleware::requirePermission('content:read:*');

// Configuration
const RATE_LIMIT_REQUESTS = 5;
const RATE_LIMIT_WINDOW = 60; // seconds
const MAX_EXECUTION_TIME = 10; // seconds

set_time_limit(MAX_EXECUTION_TIME);

try {
    // Parse request body with fallback to cached body or getJsonBody()
    $input = file_get_contents('php://input');
    if (empty($input)) {
        if (class_exists(RequestLoggerMiddleware::class)) {
            $input = RequestLoggerMiddleware::getRawBody() ?? '';
        }
    }

    $body = null;
    if (!empty($input)) {
        $body = json_decode((string)$input, true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            http_response_code(400);
            echo json_encode([
                'success' => false, 
                'error' => 'Invalid JSON: ' . json_last_error_msg()
            ]);
            exit;
        }
    } elseif (function_exists('getJsonBody')) {
        $body = getJsonBody();
    }

    if (empty($body) || !is_array($body)) {
        http_response_code(400);
        echo json_encode(['success' => false, 'error' => 'Empty request body']);
        exit;
    }

    if (!isset($body['keys']) || !is_array($body['keys'])) {
        http_response_code(400);
        echo json_encode(['success' => false, 'error' => 'Missing or invalid keys array']);
        exit;
    }

    // Rate limiting (using APCu if available)
    $clientIp = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
    $rateLimitKey = 'batch_rate_' . md5($clientIp);

    if (function_exists('apcu_enabled') && apcu_enabled()) {
        $currentCount = apcu_fetch($rateLimitKey) ?: 0;
        
        if ($currentCount >= RATE_LIMIT_REQUESTS) {
            http_response_code(429);
            echo json_encode([
                'success' => false, 
                'error' => 'Rate limit exceeded. Please wait before making more batch requests.',
                'retry_after' => RATE_LIMIT_WINDOW
            ]);
            exit;
        }
        
        if ($currentCount === 0) {
            apcu_store($rateLimitKey, 1, RATE_LIMIT_WINDOW);
        } else {
            apcu_inc($rateLimitKey);
        }
    }

    // Process via BatchContentService
    $result = BatchContentService::process($body['keys'], $body);

    if (isset($result['status']) && $result['status'] >= 400) {
        http_response_code($result['status']);
    }

    echo json_encode($result, JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR);

} catch (\JsonException $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'JSON encoding error'
    ]);
} catch (\Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => ($_ENV['APP_DEBUG'] ?? 'false') === 'true' ? $e->getMessage() : 'Internal server error'
    ]);
}
