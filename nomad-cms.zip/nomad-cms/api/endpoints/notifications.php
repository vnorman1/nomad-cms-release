<?php

/**
 * NOMAD CMS - Personal notification inbox endpoint.
 * Delegates authenticated, owner-scoped operations to the central backend module.
 * Includes no schema migration or synchronous transport work.
 */

declare(strict_types=1);

require_once __DIR__ . '/../bootstrap.php';
handlePreflight();
\NomadCMS\Services\NotificationService\HttpController::dispatch('inbox');
