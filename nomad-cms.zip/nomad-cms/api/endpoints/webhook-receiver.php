<?php
/**
 * Webhook Receiver Endpoint
 * 
 * Receives incoming webhooks from external services.
 * Validates HMAC signatures and routes to appropriate handlers.
 * 
 * OPTIMIZATION: Uses early response pattern + idempotency protection
 * - Returns 200 OK immediately after validation
 * - Processes webhook in background (after response sent)
 * - Prevents duplicate processing via idempotency keys
 * 
 * URL Format:
 *   POST /api/webhooks/ENDPOINT_KEY                        (preferred, pretty)
 *   POST /endpoints/webhook-receiver.php?endpoint=KEY      (original, still supported)
 * 
 * INGEST MODE (see EventIngestService for the full gate table):
 *   learning  accepts unsigned traffic, STORES the raw body for the mapper UI,
 *             and never writes to the CMS
 *   live      requires a valid signature; a verified event is mapped into the
 *             endpoint's configured target
 * 
 * Required Headers (live mode):
 *   X-Nomad-Signature: t=TIMESTAMP,v1=SIGNATURE (preferred)
 *   - OR - the provider's own header (x-cal-signature-256, Typeform-Signature,
 *     Stripe-Signature, X-Hub-Signature-256, ...)
 * 
 * Optional Headers:
 *   X-Idempotency-Key: UNIQUE_KEY (for deduplication)
 *   X-Webhook-ID: UNIQUE_ID (alternative idempotency key)
 * 
 * Example:
 *   curl -X POST https://your-cms.com/api/webhooks/stripe-payments \
 *     -H "Content-Type: application/json" \
 *     -H "X-Nomad-Signature: t=1234567890,v1=abc123..." \
 *     -d '{"event":"payment.completed","data":{...}}'
 */

require_once __DIR__ . '/../bootstrap.php';

use NomadCMS\Middleware\WebhookMiddleware;
use NomadCMS\Webhooks\Mapping\EventIngestService;

header('Content-Type: application/json');

// Only allow POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Method not allowed']);
    exit;
}

// Get endpoint key from URL
$endpointKey = $_GET['endpoint'] ?? null;

if (!$endpointKey) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Missing endpoint parameter']);
    exit;
}

try {
    // =========================================================================
    // STORE-FIRST INGEST
    //
    // EventIngestService owns the whole policy: slug resolution, rate limit,
    // size ceiling, JSON validation, signature classification, the
    // learning/live gate and the actual persistence. This script only turns its
    // verdict into an HTTP response and, when allowed, drives the background
    // work. Keeping the policy in one testable class is what lets the suite
    // assert "unsigned request on a live endpoint stores NOTHING" without
    // standing up a web server.
    // =========================================================================
    $ingest = new EventIngestService();
    $result = $ingest->ingest((string) $endpointKey);

    if ($result->retryAfter !== null) {
        header('Retry-After: ' . $result->retryAfter);
    }

    // =========================================================================
    // EARLY RESPONSE PATTERN
    // Answer immediately, then keep working after the connection is released.
    // =========================================================================
    http_response_code($result->httpStatus);
    echo json_encode($result->body);

    if (function_exists('fastcgi_finish_request')) {
        fastcgi_finish_request();
    } else {
        // Fallback for non-FPM environments
        if (ob_get_level() > 0) {
            ob_end_flush();
        }
        flush();
    }

    // Nothing further to do unless this was a verified event on a live
    // endpoint. In learning mode the event is stored and that is ALL - the
    // whole point is that discovery cannot mutate content.
    if (!$result->shouldProcess) {
        exit;
    }

    $endpoint = $result->endpoint ?? [];
    $payload = $result->payload ?? [];

    $endpoint = $result->endpoint ?? [];
    $payload = $result->payload ?? [];
    $clientIp = WebhookMiddleware::getClientIp();

    // =========================================================================
    // AUTOMAPPER: write the event into the endpoint's configured destination
    //
    // Runs FIRST, and gated on the EVENT's own identity - not on the legacy
    // action-level idempotency key below.
    //
    // WHY THAT DISTINCTION MATTERS (a bug this ordering fixes):
    // WebhookMiddleware::checkIdempotency() derives its key from
    // `eventType : (data.id ?? id) : (timestamp ?? created_at)`. A Cal.com
    // payload has none of those at the top level - it uses `uid` and `createdAt` -
    // so EVERY BOOKING_CREATED hashes to the same key. Gating the mapping behind
    // it meant the first booking mapped and every later one was silently
    // discarded as a "duplicate", with no error anywhere.
    //
    // MappingExecutor::alreadyMapped() is the right gate: it asks whether THIS
    // stored event has already been written, which is precise per event and needs
    // no key derivation at all.
    //
    // A mapping failure is logged and does NOT abort the rest: an endpoint can
    // legitimately have both a mapping and a Slack notification, and losing the
    // notification because a required field was unmapped would be a worse trade.
    // =========================================================================
    try {
        $executor = new \NomadCMS\Webhooks\Mapping\MappingExecutor();
        $eventId = $result->eventId;

        if ($eventId !== null && $executor->alreadyMapped($eventId)) {
            error_log(sprintf('[Webhook] Mapping skipped, event %d already mapped', $eventId));
        } else {
            $mapping = $executor->execute($endpoint, $payload, $eventId, $result->eventType);

            if ($mapping->skipped) {
                error_log(sprintf('[Webhook] Mapping skipped for %s: %s', $endpointKey, (string) $mapping->error));
            } elseif ($mapping->success) {
                error_log(sprintf(
                    '[Webhook] Mapped %s -> %s (record %s, %d rules)',
                    $endpointKey,
                    (string) $mapping->target,
                    (string) $mapping->recordId,
                    $mapping->rulesApplied
                ));

                // Forward the mapped values to this endpoint's single outgoing
                // webhook (if one is configured), through the existing
                // dispatchEventAsync -> webhook_queue -> WebhookQueueService
                // pipeline. slot_key=$endpointKey lets exactly one `webhooks`
                // row (the one whose slot_filters names this endpoint) match,
                // instead of fanning out to every webhook.forwarded subscriber.
                try {
                    $webhookService = new \NomadCMS\Security\WebhookService();
                    $webhookService->dispatchEventAsync('webhook.forwarded', $mapping->values, $endpointKey);
                } catch (\Throwable $e) {
                    error_log(sprintf('[Webhook] Forward dispatch error for %s: %s', $endpointKey, $e->getMessage()));
                }
            } else {
                error_log(sprintf('[Webhook] Mapping FAILED for %s: %s', $endpointKey, (string) $mapping->error));
            }
        }
    } catch (\Throwable $e) {
        error_log(sprintf('[Webhook] Mapping error for %s: %s', $endpointKey, $e->getMessage()));
    }

    // =========================================================================
    // ACTION-LEVEL IDEMPOTENCY
    //
    // Guards the LEGACY handler and the action chain only, with their original
    // semantics preserved (including the body-hash fallback). Those side effects
    // may be external and irreversible - re-posting to Slack, re-charging a
    // card - so they keep the stricter, coarser key even though it over-matches
    // for some providers.
    // =========================================================================
    $idempotency = WebhookMiddleware::checkIdempotency($payload);
    if ($idempotency['isDuplicate']) {
        error_log(sprintf(
            '[Webhook] Legacy handler + actions skipped for duplicate: endpoint=%s key=%s',
            $endpointKey,
            substr((string) $idempotency['idempotencyKey'], 0, 16) . '...'
        ));
        exit;
    }

    $idempotencyKey = (string) $idempotency['idempotencyKey'];

    error_log(sprintf(
        "[Webhook] Verified: endpoint=%s handler=%s ip=%s event=%s",
        $endpointKey,
        (string) ($endpoint['handler'] ?? 'default'),
        $clientIp,
        (string) ($result->eventType ?? 'unknown')
    ));

    // =========================================================================
    // BACKGROUND PROCESSING (after response sent)
    // =========================================================================
    
    // Route to appropriate handler
    $handlerResult = handleWebhook((string) ($endpoint['handler'] ?? 'default'), $payload, $endpoint);
    
    // =========================================================================
    // WEBHOOK ACTION SYSTEM INTEGRATION
    // Execute configured actions for this endpoint
    // =========================================================================
    try {
        $actionService = new \NomadCMS\Webhooks\WebhookActionService();
        
        // Execute actions for this endpoint (by endpoint_id or endpoint_key)
        $headers = getallheaders() ?: [];
        $actionResults = $actionService->executeWebhookActions(
            (string)($endpoint['id'] ?? $endpointKey),
            $payload,
            $headers
        );
        
        // Log action results
        if (!empty($actionResults['actions_executed'])) {
            error_log(sprintf(
                "[Webhook] Actions executed: %d, success: %d",
                count($actionResults['actions_executed']),
                count(array_filter($actionResults['actions_executed'], fn($a) => $a['success'] ?? false))
            ));
        }
    } catch (\Exception $e) {
        error_log(sprintf("[Webhook] Action execution error: %s", $e->getMessage()));
    }
    
    // Record as processed (idempotency)
    WebhookMiddleware::recordProcessedEvent($idempotencyKey, (string) ($result->eventType ?? 'unknown'));
    
    // Log successful processing
    error_log(sprintf(
        "[Webhook] Processed: endpoint=%s, handler=%s, result=%s",
        $endpointKey,
        (string) ($endpoint['handler'] ?? 'default'),
        json_encode($handlerResult)
    ));

} catch (\Exception $e) {
    // Log error
    error_log(sprintf(
        "[Webhook] Error processing %s: %s",
        $endpointKey,
        $e->getMessage()
    ));
    
    // Only return error if we haven't sent response yet
    if (!headers_sent()) {
        http_response_code(500);
        echo json_encode([
            'success' => false,
            'error' => 'Internal server error'
        ]);
    }
}

/**
 * Route webhook to appropriate handler
 * 
 * @param string $handler Handler identifier
 * @param array $payload Webhook payload
 * @param array $endpoint Endpoint configuration
 * @return array Handler result
 */
function handleWebhook(string $handler, array $payload, array $endpoint): array
{
    // Built-in handlers
    switch ($handler) {
        case 'default':
            return handleDefaultWebhook($payload, $endpoint);
            
        case 'content':
            // Content handler for CMS CRUD operations
            $contentHandler = new \NomadCMS\Webhooks\Handlers\ContentHandler();
            return $contentHandler->handle($payload, $endpoint);
            
        case 'stripe':
            return handleStripeWebhook($payload, $endpoint);
            
        case 'github':
            return handleGithubWebhook($payload, $endpoint);
            
        case 'zapier':
            return handleZapierWebhook($payload, $endpoint);
            
        case 'custom':
            return handleCustomWebhook($payload, $endpoint);
            
        default:
            // Try to load custom handler class
            $handlerClass = "\\NomadCMS\\Webhooks\\Handlers\\" . ucfirst($handler) . "Handler";
            if (class_exists($handlerClass)) {
                $instance = new $handlerClass();
                return $instance->handle($payload, $endpoint);
            }
            
            // Fall back to default
            return handleDefaultWebhook($payload, $endpoint);
    }
}

/**
 * Default webhook handler - just logs the payload
 */
function handleDefaultWebhook(array $payload, array $endpoint): array
{
    // Log payload for debugging
    error_log(sprintf(
        "[Webhook][Default] Endpoint: %s, Payload: %s",
        $endpoint['name'],
        json_encode($payload)
    ));
    
    return [
        'handler' => 'default',
        'received' => true
    ];
}

/**
 * Stripe webhook handler
 * Processes Stripe events (payments, subscriptions, etc.)
 */
function handleStripeWebhook(array $payload, array $endpoint): array
{
    $eventType = $payload['type'] ?? 'unknown';
    $data = $payload['data']['object'] ?? [];
    
    error_log(sprintf(
        "[Webhook][Stripe] Event: %s",
        $eventType
    ));
    
    // Handle specific Stripe events
    switch ($eventType) {
        case 'payment_intent.succeeded':
            // Handle successful payment
            break;
            
        case 'customer.subscription.created':
        case 'customer.subscription.updated':
        case 'customer.subscription.deleted':
            // Handle subscription changes
            break;
            
        case 'invoice.paid':
        case 'invoice.payment_failed':
            // Handle invoice events
            break;
    }
    
    return [
        'handler' => 'stripe',
        'event' => $eventType,
        'processed' => true
    ];
}

/**
 * GitHub webhook handler
 * Processes GitHub events (push, pull request, etc.)
 */
function handleGithubWebhook(array $payload, array $endpoint): array
{
    // GitHub sends event type in X-GitHub-Event header
    $eventType = $_SERVER['HTTP_X_GITHUB_EVENT'] ?? 'unknown';
    
    error_log(sprintf(
        "[Webhook][GitHub] Event: %s, Repo: %s",
        $eventType,
        $payload['repository']['full_name'] ?? 'unknown'
    ));
    
    // Handle specific GitHub events
    switch ($eventType) {
        case 'push':
            // Handle push events
            break;
            
        case 'pull_request':
            // Handle PR events
            break;
            
        case 'release':
            // Handle release events
            break;
    }
    
    return [
        'handler' => 'github',
        'event' => $eventType,
        'processed' => true
    ];
}

/**
 * Zapier webhook handler
 */
function handleZapierWebhook(array $payload, array $endpoint): array
{
    error_log(sprintf(
        "[Webhook][Zapier] Received: %s",
        json_encode($payload)
    ));
    
    return [
        'handler' => 'zapier',
        'received' => true
    ];
}

/**
 * Custom webhook handler - can be extended
 */
function handleCustomWebhook(array $payload, array $endpoint): array
{
    // Custom logic can be implemented here
    // Or handlers can be registered dynamically
    
    error_log(sprintf(
        "[Webhook][Custom] Endpoint: %s, Payload: %s",
        $endpoint['name'],
        json_encode($payload)
    ));
    
    return [
        'handler' => 'custom',
        'received' => true
    ];
}
