<?php
/**
 * NOMAD CMS — immutable update, maintenance and cron entry point.
 * Remains executable when application code or Composer dependencies are broken.
 * Ordinary release packages cannot overwrite this bootstrap entry point.
 */
declare(strict_types=1);

require_once __DIR__ . '/updater/load.php';
\NomadUpdate\Controller::dispatch(dirname(__DIR__));
