<?php

/**
 * NOMAD CMS — shared service migration entry point.
 * Upgrades notifications, Editorials Hub and SEO in dependency order using their
 * native version ledgers. CLI execution is explicit; including this file only
 * returns the injectable runner. Fresh installation uses module install methods.
 *
 * @package NomadCMS\Integrations
 */

declare(strict_types=1);

use NomadCMS\Database\AuthDatabase;
use NomadCMS\Database\ContentDatabase;
use NomadCMS\Database\MassiveDatabase;

/**
 * Each database commits independently; native ledgers make failed runs resumable.
 * Tests and custom hosts can inject connections and private storage without bootstrap.
 *
 * @param array{content?: PDO, massive?: PDO, auth?: PDO,
 *     hub_storage?: \NomadCMS\Services\EditorialsHub\Media\ProtectedAttachmentStorage,
 *     seo_files?: \NomadCMS\Services\Seo\FileStore, seo_schema?: array} $context
 * @return array<string, array{status: string}>
 */
$run = static function (array $context = []): array {
    $context['content'] ??= ContentDatabase::getInstance(false);
    $context['massive'] ??= MassiveDatabase::getInstance(false);
    $context['auth'] ??= AuthDatabase::getInstance(false);
    $results = [];
    $files = glob(__DIR__ . '/migrations/[0-9]*.php');
    if ($files === false || $files === []) {
        throw new RuntimeException('Service migration files are unavailable.');
    }
    sort($files, SORT_STRING);
    foreach ($files as $file) {
        $migration = require $file;
        if (!$migration instanceof Closure) {
            throw new RuntimeException('Invalid service migration: ' . basename($file));
        }
        // Stop on failure. Previously committed modules can safely be retried.
        $migration($context);
        $results[basename($file)] = ['status' => 'success'];
    }
    return $results;
};

if (realpath($_SERVER['SCRIPT_FILENAME'] ?? '') !== __FILE__) {
    return $run;
}
if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}
$command = $argv[1] ?? 'migrate';
if (in_array($command, ['--help', '-h'], true)) {
    fwrite(STDOUT, "Usage: php api/integrations/migrate.php [migrate]\nFor existing installations only. Fresh installs provision the current schema automatically.\n");
    exit(0);
}
if ($command !== 'migrate' || count($argv) > 2) {
    fwrite(STDERR, "Usage: php api/integrations/migrate.php [migrate]\n");
    exit(1);
}
try {
    $_SERVER['REQUEST_METHOD'] = 'GET';
    $_SERVER['REQUEST_URI'] = '/internal/service-migrations';
    require dirname(__DIR__) . '/bootstrap.php';
    fwrite(STDOUT, json_encode($run(), JSON_THROW_ON_ERROR | JSON_PRETTY_PRINT) . PHP_EOL);
} catch (Throwable $error) {
    fwrite(STDERR, 'Service migration failed: ' . $error->getMessage() . PHP_EOL);
    exit(1);
}
