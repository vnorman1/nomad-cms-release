# Service database updates

Existing installations can update all three services with:

```sh
php api/integrations/migrate.php
```

The runner loads numbered PHP integrations in filename order: notifications,
Editorials Hub, then SEO Social. It covers `system.sqlite`, `massive.sqlite` and
`database.sqlite`, including notification source outboxes and Hub destination
receipts. Each service keeps its existing version ledger and one-time RBAC grants.
The original `api/bin/*` migration commands remain supported.

Run this command with the site's normal PHP runtime after uploading updated API
files. Back up the databases first. The runner stops on the first failure and
returns exit code 1; completed service transactions remain committed. Fix the
reported failure and rerun the same command.

Fresh installations need no migration command. `InstallerService` calls each
module's `install()` method, creates the current schema directly, and records the
current baseline. No legacy `ALTER TABLE`, historical mention conversion, audit
cancellation or projection rebuild migration runs during installation.

When adding a service schema change, update both the native upgrade path and its
current install definitions (`EditorialsHub/Schema.php`, `Seo/Schema.php`, or
`NotificationService/Migrations/Schema.php`). Add numbered integrations here for
new services. Do not invoke the runner from ordinary HTTP requests.
