<?php

/**
 * NOMAD CMS — SEO Social upgrade integration.
 * Applies core, statistics and auth schema updates through the native SEO ledger.
 * Seeds templates and synchronizes CMS targets through the module composition root.
 */

declare(strict_types=1);

use NomadCMS\Services\Seo\SeoModule;

/** @param array<string, mixed> $context Injected storage for the shared runner. */
return static function (array $context): void {
    SeoModule::migrate(
        $context['content'],
        $context['massive'],
        $context['auth'],
        $context['seo_files'] ?? null,
        $context['seo_schema'] ?? null
    );
};
