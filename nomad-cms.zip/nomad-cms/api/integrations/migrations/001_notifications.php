<?php

/**
 * NOMAD CMS — central notification upgrade integration.
 * Preserves the system database version, secrets, preferences and one-time grants.
 * Installs source-local outboxes in both content and massive storage.
 */

declare(strict_types=1);

use NomadCMS\Services\NotificationService\Migrations\Schema;
use NomadCMS\Services\NotificationService\NotificationModule;

/** @param array<string, mixed> $context Injected storage for the shared runner. */
return static function (array $context): void {
    NotificationModule::migrate($context['auth']);
    Schema::source($context['content']);
    Schema::source($context['massive']);
};
