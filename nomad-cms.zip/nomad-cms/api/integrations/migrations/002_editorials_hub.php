<?php

/**
 * NOMAD CMS — Editorials Hub upgrade integration.
 * Uses native Hub migrations, destination receipts and one-time permission grants.
 * Historical mentions remain receipts and never cause a notification replay.
 */

declare(strict_types=1);

use NomadCMS\Services\EditorialsHub\EditorialsHubModule;

/** @param array<string, mixed> $context Injected storage for the shared runner. */
return static function (array $context): void {
    EditorialsHubModule::migrate(
        $context['massive'],
        $context['auth'],
        $context['content'],
        true,
        $context['hub_storage'] ?? null
    );
};
