<?php
/**
 * NOMAD CMS — isolated application migration and health probe.
 * Only the immutable engine can invoke this file. Each invocation runs in a
 * fresh request so PHP fatals and stale classes cannot disable code recovery.
 */
declare(strict_types=1);

if (!defined('NOMAD_UPDATE_PROBE')) {
    http_response_code(404);
    exit;
}

return static function (string $action, array $release, int $cursor): array {
    require_once dirname(__DIR__) . '/bootstrap.php';
    if ($action === 'migrate') {
        return \NomadCMS\Services\UpdateMigrationRunner::step($release, $cursor);
    }
    $root = dirname(__DIR__, 2);
    $version = json_decode((string) file_get_contents($root . '/version.json'), true, 32, JSON_THROW_ON_ERROR);
    if (($version['version'] ?? null) !== $release['version'] || ($version['buildId'] ?? null) !== $release['build_id']
        || \NomadCMS\Config\Version::VERSION !== $release['version'] || \NomadCMS\Config\Version::BUILD_ID !== $release['build_id']) {
        throw new RuntimeException('Installed PHP/version metadata mismatch; check OPcache.');
    }
    if (!\NomadCMS\Installer\InstallerService::isInstalled()) {
        throw new RuntimeException('Installation lock is unavailable.');
    }
    foreach ([
        \NomadCMS\Database\AuthDatabase::getInstance(false),
        \NomadCMS\Database\ContentDatabase::getInstance(false),
        \NomadCMS\Database\MassiveDatabase::getInstance(true),
    ] as $db) {
        $db->query('SELECT 1')->fetchColumn();
    }
    $schema = \NomadCMS\Services\Schema\SchemaStore::path();
    if (is_file($schema)) {
        $db = new PDO('sqlite:file:' . $schema . '?mode=ro');
        $db->query('SELECT 1')->fetchColumn();
    }
    $html = is_file($root . '/nomad/index.html') ? file_get_contents($root . '/nomad/index.html') : false;
    if (!is_string($html) || !preg_match_all('~(?:src|href)="(/nomad/(?:assets|fonts)/[^"]+)"~', $html, $matches)) {
        throw new RuntimeException('Production admin assets are unavailable.');
    }
    foreach ($matches[1] as $asset) {
        if (!is_file($root . $asset)) {
            throw new RuntimeException('A required frontend asset is missing.');
        }
    }
    return ['done' => true, 'cursor' => 0];
};
