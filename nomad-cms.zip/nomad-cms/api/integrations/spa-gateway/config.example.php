<?php
/**
 * NOMAD CMS — standalone SPA gateway configuration.
 * Copy to config.php, configure the build/CMS paths, then explicitly enable on PHP hosting.
 * Keep the cache outside the public document root; no user session is forwarded to the CMS.
 * @package NomadCMS\Integrations\SpaGateway
 */
declare(strict_types=1);

return [
    'enabled' => false,
    'mode' => 'remote',
    'htmlFile' => __DIR__ . '/index.html',
    'cacheDir' => dirname(__DIR__) . '/private-seo-gateway',
    'metaUrl' => 'https://cms.example.com/api/seo/meta',
    'cmsRoot' => '',
    'basePath' => '',
    'ttl' => 60,
    'quotaBytes' => 33554432,
    'excludedPrefixes' => ['/api/', '/nomad/', '/assets/'],
];
