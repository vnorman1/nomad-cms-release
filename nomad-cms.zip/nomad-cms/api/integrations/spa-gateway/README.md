# Nomad SPA-kapu

PHP 8.2+, JSON és mbstring szükséges. Távoli módhoz cURL, helyi módhoz a telepített CMS szükséges. Az adapter alapból kikapcsolt. A React buildet és forráskódot nem módosítja.

1. Csomagold ki a csomagot a publikus React build mellé. Az eredeti `index.html` maradjon meg.
2. Másold a `config.example.php` fájlt `config.php` névre. Állítsd be a `htmlFile`, `cacheDir`, `mode`, `metaUrl` vagy `cmsRoot` értékeket. Alkötetbe telepített webhelynél a `basePath` a publikus URL előtagja. A cache legyen a dokumentumgyökéren kívül.
3. Regisztráld a tényleges publikus útvonalakat és URL-eket a CMS SEO-moduljában. Helyi módban a CMS `spaGatewayEnabled` kapcsolóját is engedélyezni kell.
4. Kösd a HTML-oldalkéréseket az adapterre, és állítsd az `enabled` értéket `true`-ra. A beállítás után minden látogató ugyanazt a SEO-fejlécet kapja.

Apache: az API/admin saját szabályai után, a meglévő `index.html` SPA-fallback helyére:

```apache
DirectoryIndex index.php
RewriteEngine On
RewriteRule ^(?:lib|private-seo-gateway)(?:/|$) - [F,L]
RewriteCond %{REQUEST_FILENAME} -f [OR]
RewriteCond %{REQUEST_FILENAME} -d
RewriteRule ^ - [L]
RewriteRule ^ index.php [L,QSA]
```

Az `/index.html` közvetlen URL-jét igény szerint külön irányítsd az adapterre. Az `/api`, `/nomad`, a statikus assetek és a saját PHP-végpontok meglévő szabályai maradjanak az SPA-fallback előtt. Ne telepítsd ezt a CMS admin React-buildje elé.

Nginx:

```nginx
index index.php;
location / { try_files $uri $uri/ /index.php?$query_string; }
location ^~ /lib/ { deny all; }
location ~ \.php$ {
    include fastcgi_params;
    fastcgi_param SCRIPT_FILENAME $document_root$fastcgi_script_name;
    fastcgi_pass unix:/run/php/php-fpm.sock;
}
```

A PHP-FPM socket és az API/admin location blokkok tárhelyenként eltérnek. A szerver meglévő CSP-fejléce megmarad. A kapu nem hoz létre új scriptet és nem változtat nonce-on.

Távoli mód: 60 másodpercen belüli friss cache, ETag-es újraellenőrzés, 2 másodperces teljes HTTP-időkeret és 64 KiB metaadatlimit. Hiba esetén az eredeti shell és `no-store` érkezik; lejárt SEO-adatot nem szolgál ki. Ismerten visszavont route: 404 és noindex. Ismeretlen route: megmarad az SPA-fallback. GET és HEAD támogatott; Range-kérés teljes, 200-as HTML-választ kap, így a tagek a válasz elején vannak.

A fejléctagek szerveroldalon jelennek meg, a törzstartalom továbbra is kliensoldali. Teljes tartalmi indexeléshez SSR/SSG szükséges. A megosztási szolgáltatók saját cache-einek frissítése külön történik.
