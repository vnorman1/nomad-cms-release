<?php
/**
 * NOMAD CMS — portable PHP entrypoint for React/Vite/CRA SPA builds.
 * Preserves the build and existing server headers, injects only SEO metadata, ignores Range with HTTP 200.
 * Local integration uses the anonymous public service directly; remote mode uses pinned bounded HTTP.
 * @package NomadCMS\Integrations\SpaGateway
 */
declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/update-guard.php';

use NomadCMS\Services\Seo\FileStore;
use NomadCMS\Services\Seo\HttpClient;
use NomadCMS\Services\Seo\SeoModule;
use NomadCMS\Services\Seo\SpaGateway;

$config = require __DIR__ . '/config.php';
spl_autoload_register(static function (string $class): void {
    $prefix = 'NomadCMS\\Services\\Seo\\';
    if (str_starts_with($class, $prefix)) {
        $name = substr($class, strlen($prefix));
        if (preg_match('/^[A-Za-z]+$/D', $name) && is_file(__DIR__ . '/lib/' . $name . '.php')) {
            require_once __DIR__ . '/lib/' . $name . '.php';
        }
    }
});

if (!is_file($config['htmlFile']) || filesize($config['htmlFile']) > 8388608) {
    http_response_code(503);
    header('Cache-Control: no-store');
    exit;
}
$shell = file_get_contents($config['htmlFile']);
$local = null;
$http = null;
try {
    if (!empty($config['enabled']) && ($config['mode'] ?? 'remote') === 'local') {
        require_once rtrim($config['cmsRoot'], '/') . '/vendor/autoload.php';
        if (is_file(rtrim($config['cmsRoot'], '/') . '/.env')) {
            \Dotenv\Dotenv::createImmutable($config['cmsRoot'])->safeLoad();
        }
        $module = SeoModule::production();
        // The CMS switch is authoritative too; a stale deployment cannot accidentally enable injection.
        $config['enabled'] = $module->settings->get()['data']['spaGatewayEnabled'];
        $config['basePath'] = $config['basePath'] ?: (parse_url($module->settings->get()['data']['publicSiteUrl'], PHP_URL_PATH) ?? '');
        $local = static fn (string $path): array => $module->metadata->forPath($path);
    } elseif (!empty($config['enabled'])) {
        $host = parse_url($config['metaUrl'] ?? '', PHP_URL_HOST);
        $http = new HttpClient($host ? [$host] : []);
    }
} catch (\Throwable $error) {
    error_log('[seo.gateway] local_cms_unavailable');
    header('Cache-Control: no-store');
    header('Content-Type: text/html; charset=utf-8');
    header('X-Nomad-SEO: unavailable');
    if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'HEAD') {
        echo $shell;
    }
    exit;
}
$gateway = new SpaGateway($config, new FileStore($config['cacheDir']), $http, $local);
$response = $gateway->handle($_SERVER['REQUEST_URI'] ?? '/', $shell, $_SERVER['REQUEST_METHOD'] ?? 'GET', isset($_COOKIE['nomad_draft']) || isset($_SERVER['HTTP_X_NOMAD_DRAFT']));
http_response_code($response['status']);
foreach ($response['headers'] as $name => $value) {
    header($name . ': ' . $value);
}
echo $response['body'];
