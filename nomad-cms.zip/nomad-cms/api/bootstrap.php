<?php
/**
 * NOMAD CMS - Application Bootstrap
 * Autoloader, environment loader, error handling
 */

declare(strict_types=1);

require_once __DIR__ . '/update-guard.php';

// Composer autoloader
require_once __DIR__ . '/vendor/autoload.php';

use Dotenv\Dotenv;

// Load environment variables if .env exists (may not exist before installation)
$envFileExists = file_exists(__DIR__ . '/.env');

if ($envFileExists) {
    $dotenv = Dotenv::createImmutable(__DIR__);
    $dotenv->safeLoad();

    // Required environment variables validation
    $dotenv->required([
        'APP_ENV',
        'JWT_ALGORITHM',
        'ENCRYPTION_KEY',
        'PASSWORD_PEPPER',
    ])->notEmpty();

    // SECURITY: JWT_SECRET is only required when a symmetric JWT algorithm
    // (HS256/HS384/HS512) is configured. Asymmetric algorithms (RS/ES/PS) use
    // the RSA key pair under keys/ instead and must not require a JWT_SECRET to
    // be present in the environment - forcing it unconditionally would keep an
    // unused shared secret alive as unnecessary attack surface (see
    // Security::getJwtSecret() for the runtime warning if it's set anyway).
    $jwtAlgorithm = $_ENV['JWT_ALGORITHM'] ?? '';
    $isSymmetricJwt = str_starts_with($jwtAlgorithm, 'HS');
    if ($isSymmetricJwt && empty($_ENV['JWT_SECRET'] ?? '')) {
        throw new \RuntimeException('JWT_SECRET is required when JWT_ALGORITHM is a symmetric algorithm (HS256/HS384/HS512).');
    }
} else {
    // Pre-installation defaults
    $_ENV['APP_ENV'] = $_ENV['APP_ENV'] ?? 'production';
    $_ENV['APP_DEBUG'] = $_ENV['APP_DEBUG'] ?? 'false';
    $_ENV['SESSION_SAME_SITE'] = $_ENV['SESSION_SAME_SITE'] ?? 'Lax';
    $_ENV['SESSION_SECURE_COOKIE'] = $_ENV['SESSION_SECURE_COOKIE'] ?? 'false';
    $_ENV['FORGE_PIGGYBACK_PROCESSING'] = 'false';
    $_ENV['WEBHOOK_PIGGYBACK_PROCESSING'] = 'false';
    $_ENV['FORMS_PIGGYBACK_PROCESSING'] = 'false';
    $_ENV['ANALYTICS_PIGGYBACK_PROCESSING'] = 'false';
}

// ═══════════════════════════════════════════════════════════════════════════
// DRAFT PREVIEW: ?draftkey= Cookie Engine (PHP fallback)
// ═══════════════════════════════════════════════════════════════════════════
// Guarantees support in environments without Apache mod_headers
// (PHP built-in server, Nginx reverse proxy, Docker, Node.js SSR).
// The .htaccess mod_headers engine handles this at the web-server level for
// Apache; this PHP fallback ensures $_COOKIE is populated for the current
// request even when the header hasn't been sent yet.
if (isset($_GET['draftkey'])) {
    $keyVal = trim((string)$_GET['draftkey']);
    $isSecure = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
        || (isset($_SERVER['SERVER_PORT']) && (int)$_SERVER['SERVER_PORT'] === 443)
        || (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] === 'https');

    if (in_array(strtolower($keyVal), ['clear', 'exit', '0', 'off', 'false', ''], true)) {
        setcookie('nomad_draft', '', [
            'expires'  => time() - 3600,
            'path'     => '/',
            'samesite' => 'Lax',
            'secure'   => $isSecure,
            'httponly' => false,
        ]);
        unset($_COOKIE['nomad_draft']);
    } elseif ($keyVal !== '') {
        setcookie('nomad_draft', $keyVal, [
            'expires'  => 0, // Session cookie (until browser closes)
            'path'     => '/',
            'samesite' => 'Lax',
            'secure'   => $isSecure,
            'httponly' => false,
        ]);
        $_COOKIE['nomad_draft'] = $keyVal;
    }
}

// Error reporting based on environment
// Exclude E_DEPRECATED to prevent library warnings from breaking JSON responses
if (($_ENV['APP_DEBUG'] ?? 'false') === 'true') {
    error_reporting(E_ALL & ~E_DEPRECATED);
    ini_set('display_errors', '0'); // Don't display, log instead in API
} else {
    error_reporting(0);
    ini_set('display_errors', '0');
}

// Set timezone
date_default_timezone_set('Europe/Budapest');

// Remove PHP version disclosure header (Security through Obscurity)
header_remove('X-Powered-By');

// Session security settings
if (session_status() === PHP_SESSION_NONE) {
    $isDev = (($_ENV['APP_DEBUG'] ?? 'false') === 'true') && (($_ENV['APP_ENV'] ?? 'development') === 'development');
    $isHttps = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
        || (($_SERVER['SERVER_PORT'] ?? '') === '443')
        || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https');
    
    // Cookie name: __Secure-nomad_session by default / production.
    // RFC 6265bis: __Secure- cookies MUST have Secure attribute and be sent over HTTPS.
    // Only fall back to nomad_session without prefix if explicitly in development mode and on plain HTTP.
    $cookiePrefix = ($isDev && !$isHttps) ? '' : '__Secure-';
    $baseCookieName = 'nomad_session';
    $sessionCookieName = str_starts_with($baseCookieName, '__Secure-') 
        ? $baseCookieName 
        : ($cookiePrefix . $baseCookieName);

    session_name($sessionCookieName);
    ini_set('session.cookie_httponly', '1');
    ini_set('session.cookie_samesite', $_ENV['SESSION_SAME_SITE'] ?? 'Lax');
    ini_set('session.use_strict_mode', '1');
    
    $secureCookie = !($isDev && !$isHttps) || (($_ENV['SESSION_SECURE_COOKIE'] ?? 'false') === 'true');
    if ($secureCookie) {
        ini_set('session.cookie_secure', '1');
    }
}

// NOTE: Access-Control-Allow-Credentials is set later, per-request, only
// after the Origin has been validated against the allowlist (see
// handlePreflight() below). Sending it unconditionally for every response
// regardless of Origin is unnecessary and was previously done here.

// Content Security Policy - Prevent XSS and other attacks
$cspDirectives = [
    "default-src 'self'",
    "script-src 'self' 'unsafe-inline' 'unsafe-eval'", // May need unsafe for some React features
    "style-src 'self' 'unsafe-inline'",  // Tailwind/inline styles
    "img-src 'self' data: https: blob:",
    "font-src 'self' data:",
    "connect-src 'self' ws: wss:",  // WebSocket for dev tools
    "frame-ancestors 'self'",
    "base-uri 'self'",
    "form-action 'self'",
];
header('Content-Security-Policy: ' . implode('; ', $cspDirectives));

// Other security headers
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: SAMEORIGIN');
header('Referrer-Policy: strict-origin-when-cross-origin');
header('Permissions-Policy: geolocation=(), microphone=(), camera=()');

// Initialize request logging (captures the entire request/response cycle)
require_once __DIR__ . '/src/Middleware/RequestLoggerMiddleware.php';
\NomadCMS\Middleware\RequestLoggerMiddleware::start();

// Define getJsonBody if not already defined (response.php may define it later)
if (!function_exists('getJsonBody')) {
    /**
     * Get JSON body from request
     * @return array|null Decoded JSON or null
     */
    function getJsonBody(): ?array {
        $input = file_get_contents('php://input');
        if ((empty($input) || $input === false) && PHP_SAPI === 'cli') {
            $input = file_get_contents('php://stdin');
        }
        if (empty($input)) {
            return null;
        }
        return json_decode((string)$input, true);
    }
}

/**
 * Set a secure HttpOnly cookie for refresh token
 * 
 * SECURITY NOTES:
 * - HttpOnly: JavaScript cannot access the cookie (XSS protection)
 * - Secure: Cookie only sent over HTTPS (in production)
 * - SameSite: CSRF protection (Lax or Strict)
 * - Path restricted to auth endpoints only
 * 
 * @param string $name Cookie name
 * @param string $value Cookie value (refresh token)
 * @param int $maxAge Max age in seconds
 * @param bool $clear If true, clears the cookie
 */
function setSecureRefreshCookie(string $name, string $value, int $maxAge = 604800, bool $clear = false): void {
    // Determine environment
    $isDev = ($_ENV['APP_DEBUG'] ?? 'false') === 'true';
    $isProduction = ($_ENV['APP_ENV'] ?? 'development') === 'production';
    
    // SECURITY: In production, ALWAYS enforce Secure flag
    // In development, allow non-secure for local proxy setups
    $secure = $isProduction || (($_ENV['SESSION_SECURE_COOKIE'] ?? 'false') === 'true');
    if ($isDev && !$isProduction) {
        $secure = false; // Allow HTTP in dev only
    }
    
    // SameSite: Strict is more secure but may break some flows
    $sameSite = $_ENV['SESSION_SAME_SITE'] ?? 'Lax';
    
    $domain = $_ENV['COOKIE_DOMAIN'] ?? '';
    
    $options = [
        'expires' => $clear ? 1 : time() + $maxAge, // 1 for past = delete
        'path' => '/api/endpoints/auth/',  // Only sent to auth endpoints
        'domain' => $domain,
        'secure' => $secure,
        'httponly' => true,  // CRITICAL: Not accessible from JavaScript
        'samesite' => $sameSite,
    ];
    
    setcookie($name, $clear ? '' : $value, $options);
}

/**
 * Check and enforce Panic Mode
 * Must be called early in request lifecycle
 */
function checkPanicMode(): void {
    \NomadCMS\Middleware\PanicModeMiddleware::check();
}

// Check panic mode early (after CORS but before any processing)
handlePreflight();
checkPanicMode();

/**
 * SECURITY: Self-healing keys/.htaccess for already-installed instances.
 *
 * generateRSAKeyPair() writes this file when keys/ is first created (fresh
 * installs), but an instance installed before this protection existed - or
 * one whose keys/.htaccess was dropped by a redeploy/rsync that does not
 * preserve dotfiles - would otherwise stay unprotected until the next
 * reinstall, which never happens. Sampled (~2% of requests, same rate as the
 * other piggyback maintenance below) since this is a single is_file() check
 * in the common case (file already correct) and only writes when it differs.
 */
if (!\NomadCMS\Security\PanicModeService::isActive()
    && !\NomadCMS\Services\EditorialsHub\HttpPaths::isHub($_SERVER['REQUEST_URI'] ?? '')
    && !\NomadCMS\Services\NotificationService\BackgroundRunner::isNotificationRequest($_SERVER['REQUEST_URI'] ?? '')
    && mt_rand(1, 100) <= 2) {
    $keysDir = __DIR__ . '/keys';
    if (is_dir($keysDir)) {
        require_once __DIR__ . '/src/Installer/InstallerService.php';
        \NomadCMS\Installer\InstallerService::ensureKeysDenyFile($keysDir);
    }
}

/**
 * Handle CORS preflight requests globally
 */
function handlePreflight(): void {
    $allowedOrigins = array_map('trim', explode(',', $_ENV['CORS_ALLOWED_ORIGINS'] ?? ''));
    $origin = $_SERVER['HTTP_ORIGIN'] ?? '';
    
    // Always set CORS headers for allowed origins
    // SECURITY: With credentials, we MUST specify exact origin (not *)
    if (in_array($origin, $allowedOrigins, true)) {
        header("Access-Control-Allow-Origin: $origin");
        // Allow credentials (cookies) to be sent
        header('Access-Control-Allow-Credentials: true');
    } elseif (empty($origin)) {
        // Same-origin request (no Origin header) - allow but no credentials header needed
        // This happens for non-CORS requests
    } elseif (in_array('*', $allowedOrigins, true)) {
        // Wildcard mode - but cannot use with credentials!
        header("Access-Control-Allow-Origin: *");
        // Note: Cannot set Allow-Credentials with wildcard origin
    } elseif (!file_exists(__DIR__ . '/.env')) {
        // Before installation (.env doesn't exist yet), allow installer origin
        if (!empty($origin)) {
            header("Access-Control-Allow-Origin: $origin");
            header('Access-Control-Allow-Credentials: true');
        }
    }
    
    $corsMethods = $_ENV['CORS_ALLOWED_METHODS'] ?? 'GET, POST, PUT, DELETE, OPTIONS';
    $corsHeaders = ($_ENV['CORS_ALLOWED_HEADERS'] ?? 'Content-Type, Authorization, X-ADMIN-TOKEN, X-CSRF-TOKEN') . ', X-Schema-Revision';
    if (\NomadCMS\Services\EditorialsHub\HttpPaths::isHub($_SERVER['REQUEST_URI'] ?? '')) {
        $corsMethods .= ', PATCH';
        $corsHeaders .= ', Idempotency-Key, X-Document-Epoch, X-Document-Sequence, X-Document-Format, If-None-Match';
        header('Access-Control-Expose-Headers: ETag, Retry-After, X-Document-Epoch, X-Document-Sequence, X-Document-Head, X-Document-Frame-Count, X-Document-Has-More, X-Document-Checksum');
    }
    if (\NomadCMS\Services\NotificationService\BackgroundRunner::isNotificationRequest($_SERVER['REQUEST_URI'] ?? '')) {
        $corsHeaders .= ', Idempotency-Key';
    }
    header('Access-Control-Allow-Methods: ' . $corsMethods);
    header('Access-Control-Allow-Headers: ' . $corsHeaders);
    header('Access-Control-Max-Age: ' . ($_ENV['CORS_MAX_AGE'] ?? '86400'));
    
    if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
        http_response_code(204);
        exit;
    }
}

/**
 * ═══════════════════════════════════════════════════════════════════════════
 * PIGGYBACK QUEUE PROCESSING (No cron/daemon required!)
 * ═══════════════════════════════════════════════════════════════════════════
 * 
 * On shared web hosting without cron access, we process queued images
 * by "piggybacking" on regular HTTP requests. Each request processes
 * 1-2 queue items after sending the response (via shutdown handler).
 * 
 * This is invisible to users - they get their response immediately,
 * then the server processes queue items in the background.
 * 
 * Enable/disable via: FORGE_PIGGYBACK_PROCESSING=true (default: true)
 */
function registerPiggybackProcessing(): void {
    // Skip in CLI mode (cron and tests manage their own execution)
    if (PHP_SAPI === 'cli') {
        return;
    }

    // Hub camera/sync/file requests never dispatch unrelated queue or retention work.
    if (\NomadCMS\Services\EditorialsHub\HttpPaths::isHub($_SERVER['REQUEST_URI'] ?? '')) {
        return;
    }
    if (\NomadCMS\Services\NotificationService\BackgroundRunner::isNotificationRequest($_SERVER['REQUEST_URI'] ?? '')) {
        return;
    }
    // Non-FPM shutdown work still delays the response; FPM work occupies a worker.
    // Keep editor reads, autosaves and publication entirely free of unrelated queues.
    if (\NomadCMS\Services\WebhookBackgroundPolicy::isEditorRequest($_SERVER['REQUEST_URI'] ?? '')) {
        return;
    }

    // Only enable if installed and configured (default: true for shared hosting)
    if (!file_exists(__DIR__ . '/.env')) {
        return;
    }

    if (defined('NOMAD_UPDATE_PROBE')) {
        return;
    }

    $enabled = ($_ENV['FORGE_PIGGYBACK_PROCESSING'] ?? 'true') === 'true';
    if (!$enabled) {
        return;
    }
    
    // Skip for certain request types
    $skipPaths = [
        '/api/endpoints/forge/',  // Don't slow down Forge imports
        '/api/endpoints/system/queue-process.php',  // Dedicated endpoint
        '/api/endpoints/public/collect.php',  // Analytics beacon - never itself piggybacks
        '/api/collect',  // Same endpoint via the pretty Router path
        // Admin form-submissions inbox (status/bulk-status/bulk-status-filters,
        // bulk-delete, erase, ...). Without this exclusion, an admin's own
        // status-change request can coincide with FormWebhookBatchService's
        // due-batch sweep (step 3c below) flushing an UNRELATED, earlier
        // submission's queued `form.submitted` webhook - which looks to the
        // admin exactly like their status change just fired a new webhook
        // event, even though nothing here ever dispatches one. Skipping the
        // sweep on this endpoint does not lose any delivery: the next request
        // to any other endpoint (or the visitor-facing submit endpoint itself)
        // still sweeps and flushes the batch once it's due - it just can no
        // longer appear to originate from an admin's own mutation.
        '/api/endpoints/admin/form-submissions.php',
        '/api/admin/form-submissions',
    ];
    
    $requestUri = $_SERVER['REQUEST_URI'] ?? '';
    foreach ($skipPaths as $skip) {
        if (str_contains($requestUri, $skip)) {
            return;
        }
    }
    
    // Register shutdown handler to process queue after response
    register_shutdown_function(function() {
        // Flush output to client first (response sent immediately)
        if (function_exists('fastcgi_finish_request')) {
            fastcgi_finish_request();
        } else {
            // Fallback for non-FPM environments
            if (ob_get_level() > 0) {
                ob_end_flush();
            }
            flush();
        }
        
        if (\NomadCMS\Security\PanicModeService::isActive()) {
            return;
        }

        // Performance Optimization: If an external CLI Worker or Web-Cron is actively
        // running (heartbeat recorded in last 5 minutes), skip piggyback to save visitor/server resources.
        try {
            if (class_exists(\NomadCMS\Cron\TaskManager::class)
                && \NomadCMS\Cron\TaskManager::getInstance()->isExternalCronActive()) {
                return;
            }
        } catch (\Throwable $e) {
            // If cron check fails, proceed with default piggyback execution
        }

        // Standard, full-featured Piggyback processing (Zero-configuration out-of-the-box engine)
        try {
            \NomadCMS\Security\PanicMutationGuard::run(static function (): void {
                // 1. Forge Image Queue (SmartIngest handles this)
                require_once __DIR__ . '/src/Services/SmartIngestService.php';
                \NomadCMS\Services\SmartIngestService::processPendingQueue(2);
            
                // 2. Webhook Queue (async webhook delivery)
                $webhookPiggyback = (getenv('WEBHOOK_PIGGYBACK_PROCESSING') ?: ($_ENV['WEBHOOK_PIGGYBACK_PROCESSING'] ?? 'true')) === 'true';
                if ($webhookPiggyback) {
                    require_once __DIR__ . '/src/Services/WebhookQueueService.php';
                    $webhookQueue = \NomadCMS\Services\WebhookQueueService::getInstance();
                    $ranWebhookFallback = $webhookQueue->processPiggyback();

                    // Maintenance shares the throttled slice; no COUNT scan per request.
                    if ($ranWebhookFallback && mt_rand(1, 100) <= 5) {
                        $webhookQueue->cleanup(3); // 3 days retention
                        $webhookQueue->cleanupStaleProcessing(5); // 5 min stale timeout
                    }
                }

                // 2b. INCOMING webhook event store retention (automapper).
                if ($webhookPiggyback) {
                    require_once __DIR__ . '/src/Webhooks/Mapping/WebhookEventRetentionService.php';
                    \NomadCMS\Webhooks\Mapping\WebhookEventRetentionService::piggyback();
                }

                // 3. Forms retention sweep (GDPR storage limitation)
                if (($_ENV['FORMS_PIGGYBACK_PROCESSING'] ?? 'true') === 'true') {
                    require_once __DIR__ . '/src/Services/Forms/FormRetentionService.php';
                    \NomadCMS\Services\Forms\FormRetentionService::piggyback();

                    // 3b. Form notification batch safety net.
                    require_once __DIR__ . '/src/Services/Forms/FormNotificationBatchService.php';
                    \NomadCMS\Services\Forms\FormNotificationBatchService::flushAllDue();

                    // 3c. Form WEBHOOK batch safety net.
                    require_once __DIR__ . '/src/Services/Forms/FormWebhookBatchService.php';
                    \NomadCMS\Services\Forms\FormWebhookBatchService::flushAllDue();
                }

                // 4. Analytics ingest + aggregation + retention sweep (0-PII module).
                if (($_ENV['ANALYTICS_PIGGYBACK_PROCESSING'] ?? 'true') === 'true') {
                    require_once __DIR__ . '/src/Services/Analytics/AnalyticsRetentionService.php';
                    \NomadCMS\Services\Analytics\AnalyticsRetentionService::piggyback();
                }
            });
        } catch (\Throwable $e) {
            // Silent fail - don't break user experience
            error_log("[Piggyback] Queue processing error: " . $e->getMessage());
        }
    });
}

// Register piggyback processing for every request
\NomadCMS\Services\NotificationService\BackgroundRunner::registerPiggyback();
registerPiggybackProcessing();



// Slot leases cover the complete request, including nested relation reads.
register_shutdown_function(\NomadCMS\Services\Schema\SchemaProvider::release(...));
